/* ============================================================
   MOON WARS — renderer.js
   Main canvas rendering pipeline.
   Owns the canvas, manages resolution, orchestrates all
   draw calls in correct layer order.
   ============================================================ */

'use strict';

const Renderer = (() => {

  let _canvas  = null;
  let _ctx     = null;
  /* ══ THE SCREEN (update109, 1920×1080 — part 1, the foundation) ══════
   *
   * LOGICAL is the screen the game is laid out for: 1920×1080, 16:9. It is
   * fitted to the window with its proportions kept (the empty strips are
   * the container's background — letterbox), and the canvas BACKING is
   * the real pixels it covers × devicePixelRatio, so nothing is drawn
   * small and stretched up any more: text and lines are sharp at any size.
   *
   * DESIGN is the coordinate space the screens still draw in, 1280×720,
   * until each one is laid out natively (packages 2–4). One transform maps
   * it onto the backing — at Full HD that is ×1.5, at 4K ×3 — and the
   * mouse comes back through the same numbers (`Input.toCanvas`). When a
   * screen goes native, DESIGN becomes LOGICAL and the transform ×1.
   * Every number about the screen's size is here and nowhere else. */
  const LOGICAL = Object.freeze({ W: 1920, H: 1080 });
  const DESIGN  = Object.freeze({ W: 1280, H: 720 });
  let _W       = DESIGN.W;
  let _H       = DESIGN.H;
  let _pixelRatio = 1;
  let _k       = 1;          // backing pixels per design unit

  // Parallax star layers
  const _starLayers = [
    { speed: 0.05, alpha: 0.6 },
    { speed: 0.12, alpha: 0.8 },
  ];
  let _starOffset = 0;

  // ── Init ────────────────────────────────────────────────

  function init(canvasEl) {
    _canvas = canvasEl;
    _ctx    = _canvas.getContext('2d');
    _resize();
    window.addEventListener('resize', _resize);
    return _ctx;
  }

  function _resize() {
    const winW  = window.innerWidth  || LOGICAL.W;
    const winH  = window.innerHeight || LOGICAL.H;
    // Fit the 16:9 screen in the window; the container centres it.
    const fit   = Math.min(winW / LOGICAL.W, winH / LOGICAL.H);
    const cssW  = Math.max(1, Math.round(LOGICAL.W * fit));
    const cssH  = Math.max(1, Math.round(LOGICAL.H * fit));
    _pixelRatio = Math.max(1, window.devicePixelRatio || 1);

    _canvas.style.width  = cssW + 'px';
    _canvas.style.height = cssH + 'px';
    // The backing is the pixels on the glass — 1:1, so nothing is stretched.
    _canvas.width        = Math.max(1, Math.round(cssW * _pixelRatio));
    _canvas.height       = Math.max(1, Math.round(cssH * _pixelRatio));
    _k = _canvas.width / _W;
    _applyBase();

    // Inform input system of CSS→canvas scale
    const rect = _canvas.getBoundingClientRect();
    Input.setScale(
      rect.width  / _W || 1,
      rect.height / _H || 1
    );

    Camera.resize(_W, _H);
  }

  /** Design units → backing pixels. A resize resets the context, and so
   *  does nothing else: every frame starts from this (see `clear`). */
  function _applyBase() {
    if (!_ctx) return;
    _ctx.setTransform(_k, 0, 0, _k, 0, 0);
    _ctx.imageSmoothingEnabled = true;
    try { _ctx.imageSmoothingQuality = 'high'; } catch (e) { /* older engines */ }
  }

  /** How the screen is set up — read by the input mapping and the tests. */
  function screenInfo() {
    return { logical: { ...LOGICAL }, design: { ...DESIGN }, viewScale: LOGICAL.W / _W,
             backing: { w: _canvas?.width ?? 0, h: _canvas?.height ?? 0 },
             pixelRatio: _pixelRatio, k: _k };
  }

  function getCtx()    { return _ctx; }
  function getWidth()  { return _W; }
  function getHeight() { return _H; }

  // ── Clear ───────────────────────────────────────────────

  function clear() {
    _applyBase();          // a frame always starts in design units (update109)
    _ctx.clearRect(0, 0, _W, _H);
    _ctx.fillStyle = '#07080f';
    _ctx.fillRect(0, 0, _W, _H);
  }

  // ── Starfield background ─────────────────────────────────

  function drawBackground(scrollX = 0) {
    const stars = Assets.get('bg_stars');
    const moon  = Assets.get('bg_moon');

    if (stars) {
      // Layer 1: slow parallax
      const off1 = ((-scrollX * 0.05) % _W + _W) % _W;
      _ctx.globalAlpha = 0.7;
      _ctx.drawImage(stars, off1 - _W, 0, _W, _H);
      _ctx.drawImage(stars, off1,      0, _W, _H);

      // Layer 2: faster
      _ctx.globalAlpha = 0.5;
      const off2 = ((-scrollX * 0.15) % _W + _W) % _W;
      _ctx.drawImage(stars, off2 - _W, 0, _W, _H);
      _ctx.drawImage(stars, off2,      0, _W, _H);
      _ctx.globalAlpha = 1;
    } else {
      _ctx.fillStyle = '#07080f';
      _ctx.fillRect(0, 0, _W, _H);
    }

    // Moon in background
    if (moon) {
      _ctx.globalAlpha = 0.18;
      _ctx.drawImage(moon, _W - 260, 30, 200, 200);
      _ctx.globalAlpha = 1;
    }
  }

  // ── HUD ─────────────────────────────────────────────────

  const _powerClickZones = [];
  function getPowerClickZones() { return _powerClickZones; }
  /* The mark strip's hover boxes. A separate list from the click
     zones on purpose: a mark is not a button, and putting it in
     `_powerClickZones` would make every tooltip a thing game.js has to
     remember NOT to act on. */
  const _crewMarkZones = [];
  /* Where the roster window starts (update97), the box the wheel works
     over, and the last selection seen — so the window follows a NEW
     selection and otherwise stays where the wheel left it. */
  let _rosterScroll = 0, _rosterBox = null, _rosterSelSeen = null;
  function rosterBox() { return _rosterBox; }
  /** One notch of the wheel over the roster. Returns true if it moved. */
  function scrollRoster(step) {
    if (!_rosterBox || !_rosterBox.max) return false;
    const was = _rosterScroll;
    _rosterScroll = Utils.clamp(_rosterScroll + Math.sign(step), 0, _rosterBox.max);
    return _rosterScroll !== was;
  }
  /** How tall the rank insignia is in a roster row (twice as wide). */
  const RANK_ROW_H = 9;
  /* The insignia's hover boxes (update96) — their own list: the mark
     strip's list is "what is happening to him", and its tests count it. */
  const _rankZones = [];
  function getRankZones() { return _rankZones; }
  function getCrewMarkZones() { return _crewMarkZones; }

  /** Tiny status icon: 'crew' | 'fire' | 'noO2' — drawn at (x,y), ~12px */
  function _statusIcon(ctx, x, y, type) {
    ctx.save();
    if (type === 'crew') {
      // Little person: head + body
      ctx.fillStyle = '#4db8ff';
      ctx.beginPath(); ctx.arc(x, y - 3, 3, 0, Math.PI * 2); ctx.fill();
      ctx.fillRect(x - 3, y, 6, 6);
    } else if (type === 'fire') {
      // Orange flame triangle with yellow core
      ctx.fillStyle = '#ff7c20';
      ctx.beginPath();
      ctx.moveTo(x, y - 6); ctx.lineTo(x - 5, y + 5); ctx.lineTo(x + 5, y + 5);
      ctx.closePath(); ctx.fill();
      ctx.fillStyle = '#ffd700';
      ctx.beginPath();
      ctx.moveTo(x, y - 1); ctx.lineTo(x - 2, y + 4); ctx.lineTo(x + 2, y + 4);
      ctx.closePath(); ctx.fill();
    } else if (type === 'noO2') {
      // Blue circle with slash
      ctx.strokeStyle = '#4db8ff';
      ctx.lineWidth = 1.5;
      ctx.beginPath(); ctx.arc(x, y, 5.5, 0, Math.PI * 2); ctx.stroke();
      ctx.fillStyle = '#4db8ff';
      ctx.font = '8px monospace';
      ctx.textAlign = 'center';
      ctx.fillText('O', x, y + 3);
      ctx.strokeStyle = '#ff2d44';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(x - 5, y + 5); ctx.lineTo(x + 5, y - 5);
      ctx.stroke();
    }
    ctx.restore();
  }

  /** Status icons for a system's room: crew present, fire, low O2 */
  function _roomStatus(ship, sys) {
    const out = [];
    if (!sys.roomId) return out;
    if (ship.crew.some(c => !c.dead && c.roomId === sys.roomId)) out.push('crew');
    if (ship.fires.hasFireInRoom(sys.roomId)) out.push('fire');
    const ro = ship.oxygen.getRoom(sys.roomId);
    if (ro && ro.isWarning) out.push('noO2');
    return out;
  }

  /**
   * EVERY crew member the player owns, wherever they are standing.
   *
   * The roster used to be a flat `playerShip.crew.forEach`, which got it
   * wrong in both directions (update42): a boarding party is moved OUT
   * of playerShip.crew and INTO enemyShip.crew the moment it casts off,
   * so your away team vanished from the panel — no portrait, no HP bar,
   * no way to select them — for the whole fight they were sent to win;
   * meanwhile enemy boarders, spiders and rats standing on YOUR deck are
   * in playerShip.crew and got rows of their own.
   *
   * Own the list explicitly: our people on our hull, then our people on
   * theirs, flagged so the panel can say where they are.
   */
  /* Men out in the wreckage (update93b) — game.js tells us who. */
  let _evaCrew = () => [];
  function setEvaCrew(fn) { _evaCrew = typeof fn === 'function' ? fn : () => []; }

  function crewRoster(state) {
    const mine = (state.playerShip?.crew ?? []).filter(c => c.isPlayer);
    mine.forEach(c => { c._awayTeam = false; });
    // A survivor on a wreck joins the roster when he is aboard (update90b).
    const away = (state.enemyShip?.crew ?? []).filter(c => c.isPlayer && !c._survivor);
    away.forEach(c => { c._awayTeam = true; });
    const eva = (_evaCrew() ?? []).filter(c => c && !mine.includes(c) && !away.includes(c));
    eva.forEach(c => { c._awayTeam = true; });
    return mine.concat(away, eva);
  }

  /* WHERE THE COMMANDER STRIP IS. Published, because update52a makes
     it clickable from the map and the hit test must be the very
     rectangle that was drawn — two copies of these four numbers would
     drift the first time the HUD moved. */
  /* THE OLD STRIP IS GONE (update104, jj): one commander panel, the bar
     at the top with the Book, and it is up whenever a commander is aboard
     — on the map too, not only in a fight. This rectangle is now the
     bar's WHO corner (his face and name): the click that opened his
     dossier from the strip opens it from here, and the escape pod's
     badge sits right beside it, where it sat beside the strip. */
  function commanderStripRect() {
    return { x: CMD_BAR.x + 4, y: CMD_BAR.y + 4, w: 84, h: 28 };
  }

  /* ══ THE COMMANDER'S DOSSIER (update52a) ═══════════════════
   *
   * Everything about one commander on one panel: who he is, what rank
   * and level, how far to the next, his karma and what it buys him,
   * what he has actually chosen his levels on, his specialisations,
   * and a read-only picture of his CPU board.
   *
   * It lives HERE rather than in the base screen because two places
   * open it — the mess card and the HUD strip out on the map — and a
   * second copy of this layout would be a second thing to keep true.
   * It draws and nothing else: the caller owns whether it is open and
   * where the click came from.
   *
   * Returns the rectangles the caller has to hit-test.
   */
  function drawCommanderDossier(ctx, cap, opts = {}) {
    const W = _W, H = _H;
    /* 600 across since update98 (was 520): the attribute lines say what
       each point buys, and they must clear the CPU board on the right. */
    const PW = 600, PH = 400;
    const px = Math.round(W / 2 - PW / 2), py = Math.round(H / 2 - PH / 2);
    /* RENAME sits beside CLOSE (update54) — the file is where the
       player looks at a commander, so it is where he expects to be able
       to correct his name. Same rectangle list as everything else in
       here: the caller hit-tests exactly what was drawn. */
    const out = { panel: { x: px, y: py, w: PW, h: PH },
                  close:  { x: px + PW - 92,  y: py + PH - 38, w: 80, h: 26 },
                  rename: { x: px + PW - 184, y: py + PH - 38, w: 84, h: 26 } };
    if (!cap) return out;

    // Dim what is behind it, so the panel reads as modal.
    ctx.fillStyle = 'rgba(4,7,14,0.78)';
    ctx.fillRect(0, 0, W, H);

    ctx.fillStyle = 'rgba(13,17,32,0.98)';
    ctx.beginPath(); ctx.roundRect(px, py, PW, PH, 8); ctx.fill();
    ctx.strokeStyle = '#ffd700'; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.roundRect(px, py, PW, PH, 8); ctx.stroke();

    const corp = (typeof CORP_DEFS !== 'undefined' && CORP_DEFS[cap.race]?.label)
      || cap.race || '—';
    const lvl  = cap.level ?? 1;
    const rank = (typeof rankName !== 'undefined') ? rankName(lvl) : '';

    // ── header ──
    ctx.fillStyle = crewColor(cap);
    ctx.fillRect(px + 18, py + 18, 30, 30);
    ctx.fillStyle = '#c8d8f0';
    ctx.fillRect(px + 22, py + 22, 22, 11);          // helmet
    ctx.fillStyle = '#ffd700';
    ctx.font = '16px Orbitron, monospace';
    ctx.textAlign = 'left';
    ctx.fillText(String(cap.name || '—'), px + 58, py + 32);
    ctx.fillStyle = '#7a90a8';
    ctx.font = '11px Share Tech Mono, monospace';
    ctx.fillText(`${corp}   ·   SHIP COMMANDER`, px + 58, py + 48);

    ctx.textAlign = 'right';
    ctx.fillStyle = '#4dd8c0';
    ctx.font = '13px Share Tech Mono, monospace';
    ctx.fillText(rank, px + PW - 18, py + 32);
    // …and his insignia in front of the name of it (update96).
    drawRankInsignia(ctx, lvl, px + PW - 18 - ctx.measureText(rank).width - 30, py + 21, 12);
    ctx.fillStyle = '#7a90a8';
    ctx.font = '10px Share Tech Mono, monospace';
    const maxL = (typeof Commander !== 'undefined') ? Commander.MAX_LEVEL : 24;
    ctx.fillText(`LEVEL ${lvl} / ${maxL}`, px + PW - 18, py + 48);
    ctx.textAlign = 'left';

    /* ── the XP bar, on its own line with nothing beside it.
       Crowding this was exactly what made the mess card unreadable. */
    const need = (typeof Commander !== 'undefined') ? Commander.xpToNext(cap) : 0;
    const prog = (typeof Commander !== 'undefined') ? Commander.xpProgress(cap) : 0;
    ctx.fillStyle = '#0a1018';
    ctx.fillRect(px + 18, py + 62, PW - 36, 8);
    ctx.fillStyle = '#1a8cff';
    ctx.fillRect(px + 18, py + 62, (PW - 36) * Utils.clamp(prog, 0, 1), 8);
    ctx.fillStyle = '#5f7893';
    ctx.font = '9px Share Tech Mono, monospace';
    ctx.fillText(need ? `${Math.round(cap.xp || 0)} / ${need} XP to the next promotion`
                      : 'TOP OF THE LADDER — no promotions left',
                 px + 18, py + 82);

    // ── left column: karma, picks, bonuses ──
    const LX = px + 18;
    let ly = py + 108;
    const head = (t) => {
      ctx.fillStyle = '#4db8ff'; ctx.font = '10px Orbitron, monospace';
      ctx.fillText(t, LX, ly); ly += 16;
    };
    const line = (t, col = '#c8d8f0') => {
      ctx.fillStyle = col; ctx.font = '10px Share Tech Mono, monospace';
      ctx.fillText(t, LX, ly); ly += 14;
    };

    head('KARMA');
    const karma = Math.round(cap.karma ?? 50);
    if (typeof Chips !== 'undefined') {
      const wall = Chips.wallColumn(karma);
      line(`${karma} / 100`, karma >= 66 ? '#4dd8c0' : karma <= 34 ? '#ff9a4d' : '#c8d8f0');
      line(`${wall - 1} Sumerian columns · ${Chips.COLS - wall} Egyptian`, '#7a90a8');
    } else { line(`${karma} / 100`); }

    /* WHAT THE WORLD DOES ABOUT IT (update61). The chip wall used to
       be the only consequence on this card, which made karma read as a
       board-layout stat. These three lines are the ports and the
       barracks, worded in commander.js so the shop banner and this
       card cannot disagree. */
    if (typeof Commander !== 'undefined' && Commander.karmaWorldLines) {
      Commander.karmaWorldLines(karma).forEach(t =>
        line(t, /\+\d|not trade/.test(t) ? '#ff9a4d'
              : /less/.test(t) ? '#4dd8c0' : '#7a90a8'));
    }
    ly += 6;

    /* ── ATTRIBUTES (update98) — what his levels went on, what each is
       worth, and a [+] beside each while points are owed: the file is
       a door to spend them as well as the promotion screen. */
    head('ATTRIBUTES');
    out.attrPlus = [];
    if (typeof Commander !== 'undefined') {
      const owed = Commander.pointsOwed(cap);
      if (owed > 0) line(`${owed} POINT${owed > 1 ? 'S' : ''} TO SPEND — click +`, '#ffd700');
      Commander.ATTRS.forEach(k => {
        const n = Commander.attr(cap, k);
        ctx.fillStyle = '#c8d8f0'; ctx.font = '10px Share Tech Mono, monospace';
        ctx.fillText(`${Commander.ATTR_LABEL[k]} ${n}`, LX + 18, ly);
        ctx.fillStyle = n ? '#1aff8c' : '#4a6080';
        ctx.font = '9px Share Tech Mono, monospace';
        ctx.fillText(Commander.attrLine(cap, k), LX + 130, ly);
        ctx.font = '10px Share Tech Mono, monospace';
        if (owed > 0) {
          const z = { attr: k, x: LX, y: ly - 10, w: 14, h: 13 };
          out.attrPlus.push(z);
          const hot = Utils.pointInRect(Input.mouse.x, Input.mouse.y, z.x, z.y, z.w, z.h);
          ctx.fillStyle = hot ? 'rgba(255,215,0,0.25)' : 'rgba(20,30,50,0.9)';
          ctx.fillRect(z.x, z.y, z.w, z.h);
          ctx.strokeStyle = '#ffd700'; ctx.lineWidth = 1;
          ctx.strokeRect(z.x + 0.5, z.y + 0.5, z.w - 1, z.h - 1);
          ctx.fillStyle = '#ffd700'; ctx.textAlign = 'center';
          ctx.fillText('+', z.x + z.w / 2, z.y + 10);
          ctx.textAlign = 'left';
        }
        ly += 14;
      });
      line(`Knowledge now ${Math.floor(Commander.knowledge(cap))} / ${Commander.knowledgeMax(cap)}`, '#b9a0ff');
      line('Leadership and endurance: his own corporation only', '#5f7893');
    }
    ly += 6;

    /* ── SPECIALISATIONS. The one thing the mess card could not say
       before update52a, and the one the player most needs: a skill
       counts only when it is FULLY mastered, 3 of 3. A crewman with
       three skills at one square each brings NOTHING here, and the
       panel has to say so in words rather than by showing a blank. */
    head('SPECIALISATIONS');
    const spec = Array.isArray(cap.specialties) ? cap.specialties : [];
    if (!spec.length) {
      line('none', '#ff7c20');
      line('a skill counts only at 3/3', '#5f7893');
    } else {
      /* Each with its icon (update96) — the same one the roster, the
         barracks and the mess card draw. */
      spec.forEach(k => {
        drawSpecialties(ctx, [k], LX, ly - 9, 10);
        ctx.fillStyle = '#4dd8c0'; ctx.font = '10px Share Tech Mono, monospace';
        ctx.fillText((typeof SKILL_DEFS !== 'undefined' && SKILL_DEFS[k]?.label) || k, LX + 14, ly);
        ly += 14;
      });
    }

    // ── right column: the CPU board, read-only ──
    if (typeof Chips !== 'undefined') {
      const CELL = 30, GAP = 4;
      const bw = Chips.COLS * CELL + (Chips.COLS - 1) * GAP;
      const bx = px + PW - 18 - bw, by = py + 122;
      ctx.fillStyle = '#4db8ff'; ctx.font = '10px Orbitron, monospace';
      ctx.textAlign = 'left';
      ctx.fillText('DESTINY TABLETS', bx, by - 14);
      ctx.fillStyle = '#5f7893'; ctx.font = '9px Share Tech Mono, monospace';
      ctx.textAlign = 'right';
      ctx.fillText(`${Chips.cellsFor(lvl)}/${Chips.COLS * Chips.ROWS} cells`,
                   bx + bw, by - 14);
      ctx.textAlign = 'left';

      const grid = Chips.board(cap);
      for (let y = 0; y < Chips.ROWS; y++) {
        for (let x = 0; x < Chips.COLS; x++) {
          const cx = bx + x * (CELL + GAP), cy = by + y * (CELL + GAP);
          const open = Chips.cellOpen(cap, x, y);
          const wall = Chips.sideOfColumn(x, cap.karma) === 'wall';
          ctx.fillStyle = !open ? 'rgba(26,28,34,0.95)'
                        : wall  ? 'rgba(40,26,20,0.9)'
                                : 'rgba(13,17,32,0.85)';
          ctx.beginPath(); ctx.roundRect(cx, cy, CELL, CELL, 3); ctx.fill();
          ctx.strokeStyle = !open ? '#39404e' : wall ? '#4a3324' : '#1c2740';
          ctx.lineWidth = 1;
          ctx.beginPath(); ctx.roundRect(cx, cy, CELL, CELL, 3); ctx.stroke();
          if (!open) {
            ctx.fillStyle = 'rgba(150,158,175,0.55)';
            ctx.font = '9px Share Tech Mono, monospace';
            ctx.textAlign = 'center';
            ctx.fillText(String(Chips.cellOpensAt(x, y)), cx + CELL / 2, cy + CELL / 2 + 3);
            ctx.textAlign = 'left';
          }
        }
      }
      // The chips themselves, drawn over the grid.
      (grid?.items || []).forEach(it => {
        const cx = bx + it.x * (CELL + GAP), cy = by + it.y * (CELL + GAP);
        const w = it.w * CELL + (it.w - 1) * GAP, h = it.h * CELL + (it.h - 1) * GAP;
        // Dark = works at nothing: the wall, INT 0 or karma (update99).
        const dead = Chips.itemLevel ? Chips.itemLevel(cap, it) <= 0 : Chips.isInert(cap, it);
        const col = (Chips.FAMILIES[it.def.chipFamily] || {}).col || '#b8c4d4';
        ctx.fillStyle = dead ? 'rgba(60,26,32,0.9)' : 'rgba(20,40,56,0.9)';
        ctx.beginPath(); ctx.roundRect(cx, cy, w, h, 3); ctx.fill();
        ctx.strokeStyle = dead ? '#ff5566' : col; ctx.lineWidth = 1;
        ctx.beginPath(); ctx.roundRect(cx, cy, w, h, 3); ctx.stroke();
        ctx.fillStyle = dead ? '#ff5566' : col;
        ctx.font = '9px Share Tech Mono, monospace';
        ctx.textAlign = 'center';
        const g = Chips.DEFS[it.def.chipKey]?.glyph ?? '';
        ctx.fillText(`${g} ${Chips.roman(it.def.chipLevel ?? 1)}`, cx + w / 2, cy + h / 2 + 3);
        ctx.textAlign = 'left';
      });

      ctx.fillStyle = '#5f7893';
      ctx.font = '9px Share Tech Mono, monospace';
      ctx.fillText('read-only — tablets are moved at base',
                   bx, by + Chips.ROWS * (CELL + GAP) + 12);
    }

    // ── close ──
    const c = out.close;
    const hot = Utils.pointInRect(Input.mouse.x, Input.mouse.y, c.x, c.y, c.w, c.h);
    ctx.fillStyle = hot ? 'rgba(26,140,255,0.25)' : 'rgba(20,30,50,0.9)';
    ctx.beginPath(); ctx.roundRect(c.x, c.y, c.w, c.h, 4); ctx.fill();
    ctx.strokeStyle = '#4db8ff'; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.roundRect(c.x, c.y, c.w, c.h, 4); ctx.stroke();
    ctx.fillStyle = '#4db8ff';
    ctx.font = '11px Share Tech Mono, monospace';
    ctx.textAlign = 'center';
    ctx.fillText('CLOSE', c.x + c.w / 2, c.y + 17);

    const rn = out.rename;
    const rhot = Utils.pointInRect(Input.mouse.x, Input.mouse.y, rn.x, rn.y, rn.w, rn.h);
    ctx.fillStyle = rhot ? 'rgba(122,144,168,0.25)' : 'rgba(20,30,50,0.9)';
    ctx.beginPath(); ctx.roundRect(rn.x, rn.y, rn.w, rn.h, 4); ctx.fill();
    ctx.strokeStyle = '#7a90a8'; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.roundRect(rn.x, rn.y, rn.w, rn.h, 4); ctx.stroke();
    ctx.fillStyle = '#7a90a8';
    ctx.fillText('RENAME', rn.x + rn.w / 2, rn.y + 17);

    ctx.textAlign = 'left';
    return out;
  }


  /* ── WHERE EVERY ORDER BUTTON IS ─────────────────────────
   *
   * One function, one layout. game.js hit-tests BOARD, RECALL and
   * RETREAT against exactly the rectangles drawn here, so a button
   * cannot move on screen without its click moving with it.
   *
   * `top` is remembered from the last HUD frame because the panel
   * hangs under a crew list whose length changes as people die, and
   * the click arrives on the frame AFTER the draw.
   */
  /* ── PIPS INSTEAD OF BARS (update54) ──────────────────────
   *
   * A continuous bar says "some", "most", "nearly none". Pips say a
   * NUMBER: five boxes at twenty hit points each, so a crewman two
   * boxes down is forty off and the player can read that at a glance
   * without hovering. Same reasoning as the power bar, which has been
   * pips since the beginning — this brings the crew readouts in line
   * with the one readout in the game that was already legible.
   *
   * Twenty a box, not ten: ten boxes across a hundred-and-twenty pixel
   * card leaves each one four pixels wide with nothing between them,
   * which is a bar again, only uglier.
   *
   * ONE drawer for all of them, so the crew list, the roster panel and
   * the hover card cannot drift into three different-looking readouts
   * of the same number.
   */
  /* ── THE TWO SICKNESSES, AND THEIR COLOURS (update68) ──────
   *
   * ONE table, read by the crew roster here and by the crewman drawn
   * on the ship in crew.js — two places painting the same illness two
   * different greens is how the player ended up unable to tell a
   * nuisance from a death sentence.
   *
   *   plague — off a rotting body. Unpleasant, not fatal, and a
   *            medkit clears it. GREEN.
   *   virus  — off a void spider. Three fights and he is dead. RED.
   */
  const DISEASE_COL = { plague: '#3fd96b', virus: '#d9463c' };

  /* ══ WHAT IS WRONG WITH HIM, AND WHAT HE IS DOING (update76) ══
   *
   * Three complaints, one answer.
   *
   * ONE AT A TIME. The old drawing asked `c.virus ? … : c.infected ?
   * … : null`, so a man carrying BOTH showed only the virus and the
   * plague was invisible until he was cured of the worse thing. A
   * ladder of `?:` is a fine way to pick one colour and a terrible way
   * to report a condition.
   *
   * BESIDE THE NAME. They were drawn inside a 100px row that already
   * carries a portrait, a name, an HP bar and a star, so there was
   * room for exactly one mark and no room to ever add another. The
   * player asked for them "z boku" — the strip is its own column now,
   * clear of the row, and it grows sideways instead of fighting the
   * name for pixels.
   *
   * AND WHICH MODULE HE IS WORKING. The game has paid its skill bonus
   * to ONE man per module since update43 — the one at slot 0 — and has
   * never drawn that anywhere. Two gunners in a weapons bay look
   * identical to the player and only one of them is doing anything.
   * The mark is read off `consoleOperator`, the same call that pays
   * the bonus, so the picture cannot say one thing while the maths
   * does another.
   *
   * `crewMarks` is a FUNCTION, not a draw: the list can be asked for
   * and checked, which is how "both diseases show" is testable at all.
   */
/* WHERE THE LEFT COLUMN ENDS. The crew detail panel opens at this x
   and the mark strip has to live in the gutter before it, or the panel
   is drawn straight over the marks the moment anybody is selected —
   which is most of the time. Published, and read by ui.js, because
   two hand-written copies of one edge is how the panel came to sit on
   top of the strip in the first place (caught by the screenshot for
   update76, not by any assertion). */
  const CREW_PANEL_X = 142;
  function crewPanelX() { return CREW_PANEL_X; }

  /* ONE ROW, INSIDE THE CARD (update80).
   *
   * It was 2 x 2 in the 28px gutter between the card and the detail
   * panel, which held exactly four marks — and update80 gives a man up
   * to eight things worth saying about him at once. The player's call:
   * "narazie zrob w jednej lini wszytkie, no i wieksze niz sa teraz".
   *
   * So the strip moved DOWN into the card, on its own line under the
   * hit points, and runs from there to `CREW_PANEL_X`. That is 124px,
   * eight marks at fifteen — more than a man can ever have at once.
   * The card is taller for it; the panel is not wider, which is the
   * constraint that mattered, because the board starts where the panel
   * ends.
   *
   * MARK_MAX stays as a fuse, not as a layout rule: nothing should
   * ever produce more than eight, and if something does, the strip
   * stops rather than painting over the board.
   */
  const MARK_STEP = 15, MARK_SIZE = 14, MARK_MAX = 8;

  /**
   * WHERE THE LEFT COLUMN HAS TO STOP (update82).
   *
   * The crew list, the order panel and the REACTOR COLUMN all live in
   * the same 130px strip down the left, and the reactor's pips grow
   * UPWARDS out of the bottom bar: at capacity 16 the topmost one
   * reaches y=412. The crew list grows DOWNWARDS. Nothing ever said
   * which of them gives way, and while a card was 26px tall and a
   * crew was three men they never met.
   *
   * update80 made the card 42px for the mark strip, and this package
   * put seven mouths on a frigate to watch the air go — and the
   * screenshot showed the order panel's heading printed straight
   * THROUGH the reactor pips: "NO S[pips]CIALISATIONS".
   *
   * So the two are told about each other, once, here. The pip geometry
   * is the same arithmetic `_drawPowerBar` draws with; if that moves,
   * this moves with it, because both read `_H`.
   */
  function leftColumnFloor(ship) {
    const cap = ship?.reactor?.capacity ?? ship?.reactor?.ratedPower ?? 8;
    const topPip = (_H - 52) - 20 - 12 - Math.max(0, cap - 1) * 12;
    return topPip - 8;
  }
  /* Where the strip sits inside the card, and how tall the card has
     to be for it. One pair of numbers, read by the draw and by the
     row height, so the strip cannot end up hanging off the bottom. */
  const MARK_TOP = 25, CREW_ROW_H = MARK_TOP + MARK_SIZE + 3;
  /* ── THE MARK STRIP: ONE ROW, ONE ICON SET (update80) ─────
   *
   * Two changes the player asked for, and they are the same change.
   *
   * WHAT IS ON IT. It said: disease, hunger, which module he is at,
   * and (since 78) whether he is bleeding and what his hands are
   * doing. It did not say he is REPAIRING, FIGHTING, PUTTING OUT A
   * FIRE or OUT OF AIR — four of the things a player most needs to
   * see mid-battle, and all four were visible only by finding the man
   * on the deck and working it out from his animation. His words:
   * "wtedy gracz spojzy na zaloganta na liscie i wie wszytko co sie
   * dzieje w danym momecie".
   *
   * WHAT IT IS DRAWN WITH. Every mark is now a key into STAT_ICONS —
   * the game's one pictogram set — instead of a text character here
   * and a hand-drawn shape over his head in `crew.js`. The module
   * mark is the exception and stays a glyph, because "which module"
   * is answered by SYSTEM_GLYPHS, which is itself already one table
   * used everywhere.
   *
   * The pulse still means WARNING and nothing else: it is on the
   * things that get worse if ignored, and off everything that is
   * merely true.
   */
  function crewMarks(c, ship = null) {
    if (!c || c.dead) return [];        // the row itself says DEAD
    const out = [];
    /* IN A SLAB — first, and on its own. Nothing else about him is
       happening while he is under, so nothing else needs saying. */
    if (c.frozen) {
      return [{ key: 'frozen', icon: 'frozen', glyph: '❄', col: '#7fd4ff',
                pulse: false, tip: 'IN CARBONITE — every clock stopped' }];
    }
    if (c.virus)    out.push({ key: 'virus',  icon: 'plague', glyph: '☣',
                               col: DISEASE_COL.virus, pulse: true,
                               tip: 'VOID-SPIDER VIRUS' });
    if (c.infected) out.push({ key: 'plague', icon: 'plague', glyph: '☣',
                               col: DISEASE_COL.plague, pulse: true,
                               tip: 'CORPSE PLAGUE' });

    /* OUT OF AIR (update80). The same question the bottle over his
       head asks — `airFrac` against `LOW_FRACTION` — so the deck and
       the roster cannot disagree about who is suffocating. A man with
       no tank at all (vermin) has nothing to show. */
    if (typeof SUIT_AIR !== 'undefined' && typeof c.airMax === 'function'
        && c.airMax() > 0 && c.airFrac() < SUIT_AIR.LOW_FRACTION) {
      out.push({ key: 'air', icon: 'air', glyph: '◇', col: '#4db8ff', pulse: true,
                 tip: 'OUT OF AIR — his tank is nearly dry' });
    }

    /* Hunger, off the same bands the work speed is read from — not a
       second set of thresholds beside `HUNGER.EFFORT`. A hungry man
       works slower and nothing on this screen said so. */
    /* Not while he is eating (update87): the meal is the answer to the
       hunger, and "hungry" beside "eating" was two food marks at once. */
    if (typeof HUNGER !== 'undefined' && !(c.busy && c._busyAct === 'eat')) {
      const h = c.hunger ?? 100;
      if (h <= HUNGER.STARVING) {
        out.push({ key: 'starving', icon: 'hunger', glyph: '▼', col: '#ff2d44',
                   pulse: true, tip: 'STARVING — half speed' });
      } else if (h < HUNGER.HUNGRY) {
        out.push({ key: 'hungry', icon: 'hunger', glyph: '▼', col: '#ffb020',
                   pulse: false, tip: 'HUNGRY — slower' });
      }
    }

    /* STABLE OR STILL BLEEDING (update78). The row says INJURED for
       both, and until update78 that was the whole story: a man on the
       floor was a man on the floor. Now a bandage stops the clock and
       a medkit stands him up, and the player is being asked to spend
       doses on the difference — so the difference has to be on the
       screen. Without it "who is about to die" is a guess. */
    if (c.down) {
      out.push(c._bandaged
        ? { key: 'stable',   icon: 'medical', glyph: '✚', col: '#7fe08a',
            pulse: false, tip: 'BANDAGED — stable, but still down' }
        : { key: 'bleeding', icon: 'medical', glyph: '✚', col: '#ff2d44',
            pulse: true,  tip: 'BLEEDING OUT — he is on a clock' });
    }

    /* HANDS FULL (update78). Every one of the new orders takes a few
       seconds, and for those seconds the man is off his console —
       `crewOperating` drops him. Without this the row simply lost its
       module glyph and gave no reason, which reads as a bug. */
    if (c.busy) {
      const act = c._busyAct;
      out.push(act === 'eat'
        ? { key: 'eating', icon: 'eating', glyph: '◓', col: '#7fe08a',
            pulse: false, tip: 'EATING — hands full' }
        : { key: 'aiding', icon: 'medical', glyph: '✚', col: '#7fe08a',
            pulse: false, tip: act === 'medkit' ? 'USING A MEDKIT — hands full'
                             : act === 'heal'   ? 'TAKING A DOSE — hands full'
                                                : 'BANDAGING — hands full' });
    }

    /* ── WHAT HE IS DOING (update80) ──────────────────────────
     *
     * FIGHTING FIRST, and it is asked of the SHIP, not of his
     * animation frame: `roomContested` is the same predicate that
     * stops the room's other work, so "he is in a fight" has one
     * answer in the game and on the panel. A man swinging at a
     * boarder is not repairing, whatever his task field still says —
     * the brawl pre-empts every task in `CrewMember.update`, and a
     * panel that showed the stale task would be lying about the one
     * moment the player is watching hardest.
     */
    const fighting = ship && typeof ship.roomContested === 'function'
                  && !c._awayTeam && !c.down && ship.roomContested(c.roomId);
    if (fighting) {
      out.push({ key: 'fighting', icon: 'fight', glyph: '⚔', col: '#ff2d44',
                 pulse: true, tip: 'FIGHTING — a boarder is in the room' });
    } else if (!c.down) {
      if (c.task === TASK.FIRE) {
        out.push({ key: 'firefighting', icon: 'fire', glyph: '▲', col: '#ff7c20',
                   pulse: true, tip: 'PUTTING OUT A FIRE' });
      } else if (c.task === TASK.BREACH) {
        out.push({ key: 'patching', icon: 'breach', glyph: '▣', col: '#4db8ff',
                   pulse: true, tip: 'PATCHING A HULL BREACH' });
      } else if (c.task === TASK.REPAIR) {
        out.push({ key: 'repairing', icon: 'repair', glyph: '✚', col: '#ffb020',
                   pulse: false, tip: 'REPAIRING THE MODULE' });
      }
    }

    if (c._awayTeam) {
      // On the enemy hull, so he is at nobody's console — and asking
      // OUR ship about HIS room id would match by coincidence and put
      // a module mark on a man who is not aboard.
      out.push({ key: 'away', icon: 'away', glyph: '»', col: '#ff7c20',
                 pulse: false, tip: 'ON THE ENEMY HULL' });
    } else if (ship && typeof ship.consoleOperator === 'function'
               && ship.consoleOperator(c.roomId) === c) {
      const room = ship.getRoomById ? ship.getRoomById(c.roomId) : null;
      const type = room?.system?.type ?? null;
      if (type) {
        // The one mark that stays a GLYPH: "which module" is answered
        // by SYSTEM_GLYPHS, which is already one table read everywhere.
        out.push({ key: 'console', glyph: systemGlyph(type), sysType: type, col: '#4db8ff',
                   pulse: false, tip: `WORKING ${String(type).toUpperCase()}` });
      }
    }
    return out.slice(0, MARK_MAX);
  }
  const PIP_HP = 20;          // hit points per box

  function drawPips(ctx, x, y, w, h, value, max, col, per = PIP_HP) {
    const n = Math.max(1, Math.ceil((max || 1) / per));
    const gap = n > 6 ? 1 : 2;
    const bw = Math.max(2, (w - gap * (n - 1)) / n);
    const v = Utils.clamp(value ?? 0, 0, max || 0);
    // A man on his last few points still shows ONE lit box: an empty
    // row would read as dead, and he is not.
    const lit = v <= 0 ? 0 : Math.max(1, Math.round((v / (max || 1)) * n));
    for (let i = 0; i < n; i++) {
      ctx.fillStyle = i < lit ? col : '#1a2030';
      ctx.fillRect(x + i * (bw + gap), y, bw, h);
    }
  }

  let _orderTop = 300;
  /* Narrowed from 58 to 48 in update54 — the panel is 100 across now,
     matching the crew cards above it, and both stopped covering a
     quarter of the player's own hull. */
  const ORDER_BW = 48, ORDER_BH = 18, ORDER_GAP = 4, ORDER_X = 14;

  function orderRects() {
    const x2 = ORDER_X + ORDER_BW + ORDER_GAP;
    const row = (r) => _orderTop + 12 + r * (ORDER_BH + ORDER_GAP);
    const full = ORDER_BW * 2 + ORDER_GAP;
    const out = {
      crewSave:   { x: ORDER_X, y: row(0), w: ORDER_BW, h: ORDER_BH },
      crewReturn: { x: x2,      y: row(0), w: ORDER_BW, h: ORDER_BH },
      doorsOpen:  { x: ORDER_X, y: row(1), w: ORDER_BW, h: ORDER_BH },
      doorsClose: { x: x2,      y: row(1), w: ORDER_BW, h: ORDER_BH },
      board:      { x: ORDER_X, y: row(2), w: ORDER_BW, h: ORDER_BH },
      recall:     { x: x2,      y: row(2), w: ORDER_BW, h: ORDER_BH },
      retreat:    { x: ORDER_X, y: row(3), w: full,     h: ORDER_BH },
    };
    /* The special orders LEFT this panel in update98 — they are on the
       commander bar under the resources row (`commanderBarRects`). */
    return out;
  }

  /**
   * HOW TALL THE ORDER PANEL ACTUALLY IS (update82).
   *
   * Derived from the same arithmetic `orderRects` lays the buttons out
   * with, rather than guessed at as a round number where the crew list
   * is clipped. Since update98 it is four rows and nothing else — the
   * special orders went up to the commander bar, and the crew list
   * gets the room back.
   */
  function orderPanelHeight() {
    // 12 lead-in, four button rows, a little air under RETREAT.
    return 12 + 4 * (ORDER_BH + ORDER_GAP) + 6;
  }

  /* ══ THE COMMANDER BAR (update98) ══════════════════════════
   *
   * jj's layout (makieta v2, 04.10): one strip under the resources row,
   * in a fight — who is in the chair, his KNOWLEDGE, and the special
   * orders he can give. Tablets and the Book join it in update B.
   *
   * One function lays it out and both the drawing and the click read
   * it, the rule from `orderRects`: a rectangle written twice is a
   * button that drifts off its own picture.
   */
  const CMD_BAR = { x: 300, y: 44, w: 615, h: 36 };
  /* Tighter since update99: eight specials, four tablets and the BOOK
     button share the strip (25 px a slot). */
  const CMD_SB = 23, CMD_SGAP = 2;
  function commanderBarRects() {
    const b = { ...CMD_BAR };
    const out = {
      bar:       b,
      portrait:  { x: b.x + 4,   y: b.y + 4, w: 28, h: 28 },
      knowledge: { x: b.x + 124, y: b.y + 20, w: 116, h: 8 },
      specials:  [],
      specialsX: b.x + 256,
      tablets:   [],
      tabletsX:  b.x + 470,
      book:      { x: b.x + 576, y: b.y + 5, w: 35, h: CMD_SB },
    };
    const cap = (typeof Commander !== 'undefined' && Commander.active) ? Commander.active() : null;
    const list = cap ? Commander.ordersFor(cap) : [];
    list.forEach((def, n) => {
      out.specials.push({
        key: def.key, def,
        x: out.specialsX + n * (CMD_SB + CMD_SGAP), y: b.y + 6,
        w: CMD_SB, h: CMD_SB,
      });
    });
    /* THE QUICK BAR (update99): his chosen tablets, up to four. */
    const quick = (cap && typeof Chips !== 'undefined' && Chips.quick) ? Chips.quick(cap) : [];
    quick.forEach((t, n) => {
      out.tablets.push({
        key: t.key, t,
        x: out.tabletsX + n * (CMD_SB + CMD_SGAP), y: b.y + 6,
        w: CMD_SB, h: CMD_SB,
      });
    });
    return out;
  }

  /** Is the bar up? Whenever somebody is in the chair (update104 — it
   *  used to be a fight only, and vanished with the last shot). */
  function _commanderBarShown(state) {
    return typeof Commander !== 'undefined'
      && !!Commander.active && !!Commander.active();
  }

  function _drawCommanderBar(ctx, state) {
    const cap = Commander.active();
    const R = commanderBarRects();
    const b = R.bar;
    const has = (typeof Game !== 'undefined' && Game.hasCommander) ? Game.hasCommander() : true;

    ctx.fillStyle = 'rgba(13,17,32,0.88)';
    ctx.beginPath(); ctx.roundRect(b.x, b.y, b.w, b.h, 4); ctx.fill();
    ctx.strokeStyle = '#3a3320'; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.roundRect(b.x, b.y, b.w, b.h, 4); ctx.stroke();

    // ── who ──
    const p = R.portrait;
    ctx.fillStyle = crewColor(cap);
    ctx.fillRect(p.x, p.y, p.w, p.h);
    ctx.fillStyle = '#c8d8f0';
    ctx.fillRect(p.x + 5, p.y + 5, p.w - 10, 10);          // helmet
    ctx.strokeStyle = '#ffd700'; ctx.lineWidth = 1;
    ctx.strokeRect(p.x + 0.5, p.y + 0.5, p.w - 1, p.h - 1);
    ctx.fillStyle = '#ffd700';
    ctx.font = '10px Share Tech Mono, monospace';
    ctx.textAlign = 'left';
    ctx.fillText(_clipTo(ctx, String(cap.name || '—'), 50), b.x + 38, b.y + 14);   // the pod sits after it (update104)
    drawRankInsignia(ctx, cap.level ?? 1, b.x + 38, b.y + 19, 10);
    ctx.fillStyle = '#7a90a8';
    ctx.font = '9px Share Tech Mono, monospace';
    ctx.fillText(`L${cap.level ?? 1}`, b.x + 62, b.y + 28);

    // ── knowledge ──
    const k = R.knowledge;
    const have = Commander.knowledge(cap), max = Commander.knowledgeMax(cap);
    ctx.fillStyle = '#9a7fd0';
    ctx.font = '8px Share Tech Mono, monospace';
    ctx.fillText('KNOWLEDGE', k.x, b.y + 13);
    ctx.textAlign = 'right';
    ctx.fillStyle = have <= 0 ? '#ff7c20' : '#d8c4ff';
    ctx.font = '11px Share Tech Mono, monospace';
    ctx.fillText(`${Math.floor(have)}/${max}`, k.x + k.w, b.y + 14);
    ctx.textAlign = 'left';
    ctx.fillStyle = '#0a1018';
    ctx.fillRect(k.x, k.y, k.w, k.h);
    ctx.fillStyle = '#9a6bff';
    ctx.fillRect(k.x, k.y, k.w * Utils.clamp(max ? have / max : 0, 0, 1), k.h);
    // One tick per 5 — a bar of 35 should read as "seven fives".
    ctx.fillStyle = 'rgba(13,17,32,0.9)';
    for (let v = 5; v < max; v += 5) ctx.fillRect(k.x + Math.round(k.w * v / max), k.y, 1, k.h);

    // ── the special orders ──
    ctx.fillStyle = '#2a3346';
    ctx.fillRect(b.x + 248, b.y + 5, 1, b.h - 10);
    ctx.fillRect(b.x + 463, b.y + 5, 1, b.h - 10);
    if (!R.specials.length) {
      ctx.fillStyle = '#3a4560';
      ctx.font = '9px Share Tech Mono, monospace';
      ctx.fillText('NO SPECIALISATIONS', R.specialsX, b.y + 22);
    }
    const inFight = !!state.enemyShip;
    R.specials.forEach(sp => {
      const used = Commander.orderUsed(sp.key);
      const cost = Commander.orderCost(sp.key);
      const afford = have >= cost;
      // Out of a fight the orders wait — drawn dark, never hidden (update104).
      const live = has && !used && afford && inFight;
      const running = sp.def.effect ? Commander.orderLeft(sp.def.effect) > 0 : 0;
      const col = used ? '#3a4560' : live ? '#4dd8c0' : '#2c5f57';
      ctx.fillStyle = running ? 'rgba(77,216,192,0.22)' : 'rgba(13,17,32,0.9)';
      ctx.beginPath(); ctx.roundRect(sp.x, sp.y, sp.w, sp.h, 3); ctx.fill();
      ctx.strokeStyle = running ? '#4dd8c0' : col; ctx.lineWidth = running ? 2 : 1;
      ctx.beginPath(); ctx.roundRect(sp.x, sp.y, sp.w, sp.h, 3); ctx.stroke();
      ctx.fillStyle = col;
      ctx.font = '12px Share Tech Mono, monospace';
      ctx.textAlign = 'center';
      ctx.fillText(sp.def.glyph, sp.x + sp.w / 2, sp.y + sp.h / 2 + 3);
      // What it costs, in the corner — purple like the pool it comes from.
      ctx.font = '7px Share Tech Mono, monospace';
      ctx.textAlign = 'right';
      ctx.fillStyle = used ? '#3a4560' : afford ? '#b9a0ff' : '#ff7c20';
      ctx.fillText(String(cost), sp.x + sp.w - 2, sp.y + sp.h - 2);
      ctx.textAlign = 'left';
      /* A SPENT ORDER IS STRUCK THROUGH. Grey alone reads as "not yet"
         and this one is never coming back until the next fight. */
      if (used) {
        ctx.strokeStyle = '#5a6478'; ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(sp.x + 4, sp.y + sp.h - 4);
        ctx.lineTo(sp.x + sp.w - 4, sp.y + 4);
        ctx.stroke();
      }
      _powerClickZones.push({ ...sp, specialOrder: sp.key });
    });

    // ── the quick bar: his tablets (update99) ──
    if (!R.tablets.length) {
      ctx.fillStyle = '#3a4560';
      ctx.font = '8px Share Tech Mono, monospace';
      ctx.fillText('NO TABLETS', R.tabletsX, b.y + 22);
    }
    R.tablets.forEach(sl => {
      const t = sl.t, def = t.def;
      const fam = Chips.FAMILIES[def.family] || {};
      const no = Chips.useRefusal(cap, t.key, inFight ? 'combat' : 'map');
      const on = Chips.running(t.key);
      const live = has && !no;
      const col = t.eff <= 0 ? '#3a4560' : live ? fam.col : '#5a5f70';
      ctx.fillStyle = on ? 'rgba(185,166,232,0.25)' : 'rgba(13,17,32,0.9)';
      ctx.beginPath(); ctx.roundRect(sl.x, sl.y, sl.w, sl.h, 3); ctx.fill();
      ctx.strokeStyle = on ? fam.col : col; ctx.lineWidth = on ? 2 : 1;
      ctx.beginPath(); ctx.roundRect(sl.x, sl.y, sl.w, sl.h, 3); ctx.stroke();
      ctx.fillStyle = col;
      ctx.font = (def.glyph.length > 1 ? '9px' : '12px') + ' Share Tech Mono, monospace';
      ctx.textAlign = 'center';
      ctx.fillText(def.glyph, sl.x + sl.w / 2, sl.y + sl.h / 2 + 3);
      if (t.eff > 0) {
        ctx.font = '7px Share Tech Mono, monospace';
        ctx.textAlign = 'right';
        const cost = Chips.costOf(t.key, t.eff);
        ctx.fillStyle = have >= cost ? '#b9a0ff' : '#ff7c20';
        ctx.fillText(String(cost), sl.x + sl.w - 2, sl.y + sl.h - 2);
        ctx.textAlign = 'left';
        ctx.fillStyle = col;
        ctx.fillText(Chips.roman(t.eff), sl.x + 2, sl.y + 8);
      }
      ctx.textAlign = 'left';
      _powerClickZones.push({ ...sl, tablet: t.key });
    });

    // ── THE BOOK ──
    const bk = R.book;
    const bhot = Utils.pointInRect(Input.mouse.x, Input.mouse.y, bk.x, bk.y, bk.w, bk.h);
    ctx.fillStyle = bhot ? 'rgba(185,166,232,0.2)' : 'rgba(13,17,32,0.9)';
    ctx.beginPath(); ctx.roundRect(bk.x, bk.y, bk.w, bk.h, 3); ctx.fill();
    ctx.strokeStyle = '#b9a6e8'; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.roundRect(bk.x, bk.y, bk.w, bk.h, 3); ctx.stroke();
    ctx.fillStyle = '#d8c4ff';
    ctx.font = '8px Share Tech Mono, monospace';
    ctx.textAlign = 'center';
    ctx.fillText('BOOK', bk.x + bk.w / 2, bk.y + 11);
    ctx.fillText('[B]', bk.x + bk.w / 2, bk.y + 20);
    ctx.textAlign = 'left';
    _powerClickZones.push({ ...bk, bookOpen: true });
  }

  /** What the order under the cursor is, drawn LAST so nothing covers it. */
  function _drawCommanderBarTip(ctx, inFight = true) {
    const R = commanderBarRects();
    const tab = R.tablets.find(sl =>
      Utils.pointInRect(Input.mouse.x, Input.mouse.y, sl.x, sl.y, sl.w, sl.h));
    if (tab) { _drawTabletTip(ctx, R, tab, inFight ? 'combat' : 'map'); return; }
    const hov = R.specials.find(sp =>
      Utils.pointInRect(Input.mouse.x, Input.mouse.y, sp.x, sp.y, sp.w, sp.h));
    if (!hov) return;
    const cap = Commander.active();
    const cost = Commander.orderCost(hov.key);
    const used = Commander.orderUsed(hov.key);
    const short = Commander.knowledge(cap) < cost;
    const TW = 250;
    const tx = Utils.clamp(hov.x - 10, 8, _W - TW - 8), ty = R.bar.y + R.bar.h + 4;
    ctx.font = '8px Share Tech Mono, monospace';
    const lines = [];
    let line = '';
    String(hov.def.desc).split(' ').forEach(w => {
      const test = line + w + ' ';
      if (ctx.measureText(test).width > TW - 16) { lines.push(line); line = w + ' '; }
      else line = test;
    });
    if (line) lines.push(line);
    const th = 34 + lines.length * 10 + 14;
    ctx.fillStyle = 'rgba(8,12,22,0.96)';
    ctx.beginPath(); ctx.roundRect(tx, ty, TW, th, 4); ctx.fill();
    ctx.strokeStyle = '#4dd8c0'; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.roundRect(tx, ty, TW, th, 4); ctx.stroke();
    ctx.textAlign = 'left';
    ctx.fillStyle = '#4dd8c0';
    ctx.font = '10px Share Tech Mono, monospace';
    ctx.fillText(hov.def.label, tx + 8, ty + 14);
    ctx.fillStyle = '#b9a0ff';
    ctx.font = '9px Share Tech Mono, monospace';
    ctx.fillText(`${cost} KNOWLEDGE · once per fight`, tx + 8, ty + 27);
    ctx.fillStyle = '#7a90a8';
    ctx.font = '8px Share Tech Mono, monospace';
    lines.forEach((l, i) => ctx.fillText(l, tx + 8, ty + 40 + i * 10));
    const ly = ty + 40 + lines.length * 10;
    ctx.fillStyle = used || short || !inFight ? '#ff7c20' : '#1aff8c';
    ctx.fillText(!inFight ? 'IN A FIGHT ONLY'
               : used ? 'ALREADY GIVEN THIS FIGHT' : short ? 'NOT ENOUGH KNOWLEDGE' : 'READY',
                 tx + 8, ly + 4);
  }

  /** Word-wrap to a width — one helper for the tips and the Book. */
  function _wrap(ctx, text, max) {
    const out = [];
    let line = '';
    String(text).split(' ').forEach(w => {
      const test = line ? line + ' ' + w : w;
      if (line && ctx.measureText(test).width > max) { out.push(line); line = w; }
      else line = test;
    });
    if (line) out.push(line);
    return out;
  }

  /** A quick-bar tablet explains itself (update99). */
  function _drawTabletTip(ctx, R, sl, where = 'combat') {
    const cap = Commander.active();
    const t = sl.t, def = t.def;
    const fam = Chips.FAMILIES[def.family] || {};
    const no = Chips.useRefusal(cap, t.key, where);
    const TW = 260;
    const tx = Utils.clamp(sl.x - 40, 8, _W - TW - 8), ty = R.bar.y + R.bar.h + 4;
    ctx.font = '8px Share Tech Mono, monospace';
    const what = t.eff > 0 ? def.levels[t.eff - 1] : t.why;
    const lines = _wrap(ctx, what, TW - 16);
    const state = no ? _wrap(ctx, no, TW - 16) : ['READY'];
    const th = 30 + (lines.length + state.length) * 10 + 8;
    ctx.fillStyle = 'rgba(8,12,22,0.96)';
    ctx.beginPath(); ctx.roundRect(tx, ty, TW, th, 4); ctx.fill();
    ctx.strokeStyle = fam.col || '#b9a6e8'; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.roundRect(tx, ty, TW, th, 4); ctx.stroke();
    ctx.textAlign = 'left';
    ctx.fillStyle = fam.col || '#b9a6e8';
    ctx.font = '10px Share Tech Mono, monospace';
    ctx.fillText(`${def.label} ${Chips.roman(t.eff)}`, tx + 8, ty + 14);
    ctx.fillStyle = '#b9a0ff';
    ctx.font = '9px Share Tech Mono, monospace';
    ctx.fillText(t.eff > 0 ? `${Chips.costOf(t.key, t.eff)} KNOWLEDGE · ${fam.label}` : `${fam.label} · dark`,
                 tx + 8, ty + 26);
    ctx.font = '8px Share Tech Mono, monospace';
    ctx.fillStyle = '#7a90a8';
    lines.forEach((l, i) => ctx.fillText(l, tx + 8, ty + 38 + i * 10));
    ctx.fillStyle = no ? '#ff7c20' : '#1aff8c';
    state.forEach((l, i) => ctx.fillText(l, tx + 8, ty + 38 + (lines.length + i) * 10));
  }

  /* ══ THE BOOK (update99) ═══════════════════════════════════
   *
   * jj's "Księga jak w Heroes": one window over a paused fight, tabs by
   * family and one for the orders, a card per tablet kind. It DRAWS and
   * hands back its rectangles; game.js hit-tests exactly those (through
   * a context that paints nothing), so a card cannot move without its
   * click moving with it.
   */
  const BOOK_TABS = [
    { key: 'all',     label: 'ALL' },
    { key: 'neutral', label: 'NEUTRAL' },
    { key: 'egypt',   label: 'EGYPTIAN' },
    { key: 'sumer',   label: 'SUMERIAN' },
    { key: 'orders',  label: 'ORDERS' },
  ];
  function drawTabletBook(ctx, cap, st = {}) {
    const PW = 860, PH = 500;
    const px = Math.round(_W / 2 - PW / 2), py = Math.round(_H / 2 - PH / 2);
    const out = { panel: { x: px, y: py, w: PW, h: PH },
                  close: { x: px + PW - 92, y: py + PH - 36, w: 80, h: 24 },
                  tabs: [], cards: [] };
    if (!cap || typeof Chips === 'undefined') return out;
    const tab = st.tab || 'all';
    const where = st.where || 'combat';

    ctx.fillStyle = 'rgba(4,7,14,0.72)';
    ctx.fillRect(0, 0, _W, _H);
    ctx.fillStyle = 'rgba(16,14,26,0.98)';
    ctx.beginPath(); ctx.roundRect(px, py, PW, PH, 8); ctx.fill();
    ctx.strokeStyle = '#b9a6e8'; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.roundRect(px, py, PW, PH, 8); ctx.stroke();

    ctx.textAlign = 'left';
    ctx.fillStyle = '#d8c4ff';
    ctx.font = '16px Orbitron, monospace';
    ctx.fillText('THE BOOK', px + 20, py + 30);
    ctx.fillStyle = '#7a90a8';
    ctx.font = '10px Share Tech Mono, monospace';
    const have = Commander.knowledge(cap), max = Commander.knowledgeMax(cap);
    ctx.fillText(`${cap.name} · INT ${Commander.attr(cap, 'intelligence')} reads up to `
               + `Lv ${Chips.roman(Commander.tabletCap(cap))} · karma ${Math.round(cap.karma ?? 50)}`,
                 px + 150, py + 28);
    ctx.textAlign = 'right';
    ctx.fillStyle = '#d8c4ff';
    ctx.font = '12px Share Tech Mono, monospace';
    ctx.fillText(`KNOWLEDGE ${Math.floor(have)}/${max}`, px + PW - 20, py + 28);
    if (st.inCombat) {
      ctx.fillStyle = '#ffd700';
      ctx.font = '9px Share Tech Mono, monospace';
      ctx.fillText('THE FIGHT IS PAUSED', px + PW - 20, py + 42);
    }
    ctx.textAlign = 'left';

    // ── tabs ──
    BOOK_TABS.forEach((t, i) => {
      const r = { key: t.key, x: px + 20 + i * 116, y: py + 50, w: 110, h: 22 };
      out.tabs.push(r);
      const on = t.key === tab;
      ctx.fillStyle = on ? 'rgba(185,166,232,0.22)' : 'rgba(20,24,40,0.9)';
      ctx.beginPath(); ctx.roundRect(r.x, r.y, r.w, r.h, 3); ctx.fill();
      ctx.strokeStyle = on ? '#d8c4ff' : '#3a3f58'; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.roundRect(r.x, r.y, r.w, r.h, 3); ctx.stroke();
      ctx.fillStyle = on ? '#d8c4ff' : '#7a90a8';
      ctx.font = '10px Share Tech Mono, monospace';
      ctx.textAlign = 'center';
      ctx.fillText(t.label, r.x + r.w / 2, r.y + 15);
      ctx.textAlign = 'left';
    });

    const COLS = 4, GAP = 12, CX = px + 20, CY = py + 86;
    const CW = Math.floor((PW - 40 - GAP * (COLS - 1)) / COLS);
    const card = (n, h) => ({ x: CX + (n % COLS) * (CW + GAP), y: CY + Math.floor(n / COLS) * (h + 10), w: CW, h });
    const frame = (r, col, hot) => {
      ctx.fillStyle = hot ? 'rgba(185,166,232,0.12)' : 'rgba(10,12,22,0.95)';
      ctx.beginPath(); ctx.roundRect(r.x, r.y, r.w, r.h, 4); ctx.fill();
      ctx.strokeStyle = col; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.roundRect(r.x, r.y, r.w, r.h, 4); ctx.stroke();
    };

    if (tab !== 'orders') {
      const quickKeys = Chips.quick(cap).map(t => t.key);
      const list = Chips.tablets(cap).filter(t => tab === 'all' || t.def.family === tab);
      if (!list.length) {
        ctx.fillStyle = '#7a90a8';
        ctx.font = '11px Share Tech Mono, monospace';
        ctx.fillText(tab === 'all' ? 'No Destiny Tablets mounted. Mount them at base: MESS → DESTINY TABLETS.'
                                   : 'None of this family among his Destiny Tablets.', CX, CY + 20);
      }
      list.forEach((t, n) => {
        const r = card(n, 112);
        const fam = Chips.FAMILIES[t.def.family] || {};
        const no = Chips.useRefusal(cap, t.key, where);
        const hot = Utils.pointInRect(Input.mouse.x, Input.mouse.y, r.x, r.y, r.w, r.h);
        out.cards.push({ kind: 'tablet', key: t.key, ...r });
        frame(r, t.eff > 0 ? fam.col : '#3a3f58', hot);
        ctx.fillStyle = t.eff > 0 ? fam.col : '#5a5f70';
        ctx.font = '14px Share Tech Mono, monospace';
        ctx.fillText(t.def.glyph, r.x + 8, r.y + 20);
        ctx.font = '11px Share Tech Mono, monospace';
        ctx.fillText(_clipTo(ctx, t.def.label, r.w - 70), r.x + 34, r.y + 16);
        ctx.fillStyle = '#5f7893';
        ctx.font = '8px Share Tech Mono, monospace';
        ctx.fillText(_clipTo(ctx, `${fam.label} · ${t.def.title}`, r.w - 44), r.x + 34, r.y + 27);
        if (quickKeys.includes(t.key)) {
          ctx.textAlign = 'right'; ctx.fillStyle = '#ffd700';
          ctx.fillText('QUICK', r.x + r.w - 6, r.y + 13);
          ctx.textAlign = 'left';
        }
        // The level it works at, and what caps it.
        const note = Chips.capNote(cap, t);
        ctx.fillStyle = '#c8d8f0';
        ctx.font = '9px Share Tech Mono, monospace';
        ctx.fillText(t.eff > 0
          ? `Lv ${Chips.roman(t.level)}${t.eff < t.level ? ` → ${Chips.roman(t.eff)} (${note})` : ''}`
            + `   ${Chips.costOf(t.key, t.eff)} KN`
          : `Lv ${Chips.roman(t.level)} — DARK`, r.x + 8, r.y + 44);
        ctx.fillStyle = '#7a90a8';
        ctx.font = '8px Share Tech Mono, monospace';
        _wrap(ctx, t.eff > 0 ? t.def.levels[t.eff - 1] : t.why, r.w - 16).slice(0, 3)
          .forEach((l, i) => ctx.fillText(l, r.x + 8, r.y + 58 + i * 10));
        const pas = t.eff > 0 && Chips.passiveNote ? Chips.passiveNote(cap, t.key) : null;
        if (pas) {                      // update104: Re-Atum says whether the pod is there
          ctx.fillStyle = pas.ready ? '#1aff8c' : '#ff7c20';
          ctx.fillText(_clipTo(ctx, pas.text, r.w - 16), r.x + 8, r.y + r.h - 8);
        } else if (t.eff > 0) {         // a dark one already said why above
          ctx.fillStyle = no ? '#ff7c20' : '#1aff8c';
          ctx.fillText(_clipTo(ctx, no ? no.replace(/^[^—]*— /, '') : 'READY — click to use', r.w - 16),
                       r.x + 8, r.y + r.h - 8);
        }
      });
    } else {
      // ── the orders: what each costs, and whether he can give it ──
      const routine = Object.values(Commander.ROUTINE || {});
      const specials = Commander.ordersFor(cap);
      [...routine.map(d => ({ d, kind: 'routine' })), ...specials.map(d => ({ d, kind: 'order' }))]
        .forEach(({ d, kind }, n) => {
          const r = card(n, 76);
          const hot = kind === 'order' && Utils.pointInRect(Input.mouse.x, Input.mouse.y, r.x, r.y, r.w, r.h);
          if (kind === 'order') out.cards.push({ kind: 'order', key: d.key, ...r });
          const no = kind === 'order' ? Commander.orderRefusal(d.key, cap) : null;
          frame(r, kind === 'order' ? '#4dd8c0' : '#3a4560', hot);
          ctx.fillStyle = kind === 'order' ? '#4dd8c0' : '#c8d8f0';
          ctx.font = '11px Share Tech Mono, monospace';
          ctx.fillText(_clipTo(ctx, `${d.glyph ? d.glyph + ' ' : ''}${d.label}`, r.w - 16), r.x + 8, r.y + 16);
          ctx.fillStyle = '#b9a0ff';
          ctx.font = '9px Share Tech Mono, monospace';
          ctx.fillText(`${d.cost} KNOWLEDGE${kind === 'order' ? ' · once per fight' : ' · as often as it lasts'}`,
                       r.x + 8, r.y + 30);
          ctx.fillStyle = '#7a90a8';
          ctx.font = '8px Share Tech Mono, monospace';
          ctx.fillText(_clipTo(ctx, kind === 'order' ? d.desc : 'from the order panel on the left', r.w - 16),
                       r.x + 8, r.y + 44);
          if (kind === 'order') {
            ctx.fillStyle = no || !st.inCombat ? '#ff7c20' : '#1aff8c';
            ctx.fillText(_clipTo(ctx, !st.inCombat ? 'in a fight only'
                                      : no ? no.replace(/^[^—]*— /, '') : 'READY — click to give', r.w - 16),
                         r.x + 8, r.y + r.h - 8);
          }
        });
    }

    // ── foot ──
    ctx.fillStyle = '#5f7893';
    ctx.font = '9px Share Tech Mono, monospace';
    ctx.fillText('click: use   ·   right click: on/off the quick bar   ·   B or Esc: close',
                 px + 20, py + PH - 20);
    const c = out.close;
    const hotC = Utils.pointInRect(Input.mouse.x, Input.mouse.y, c.x, c.y, c.w, c.h);
    ctx.fillStyle = hotC ? 'rgba(185,166,232,0.25)' : 'rgba(20,24,40,0.9)';
    ctx.beginPath(); ctx.roundRect(c.x, c.y, c.w, c.h, 4); ctx.fill();
    ctx.strokeStyle = '#b9a6e8'; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.roundRect(c.x, c.y, c.w, c.h, 4); ctx.stroke();
    ctx.fillStyle = '#d8c4ff';
    ctx.font = '11px Share Tech Mono, monospace';
    ctx.textAlign = 'center';
    ctx.fillText('CLOSE', c.x + c.w / 2, c.y + 16);
    ctx.textAlign = 'left';
    return out;
  }

  /* ── THE BODY MENU (update65) ─────────────────────────────
   *
   * ONE function describes it, and both the drawing below and the
   * click test in game.js read this — the rule that came out of the
   * BOARD button and `orderRects` above. A rectangle written out twice
   * is a button that drifts off the thing it is under.
   *
   * Anchored so it never runs off the canvas: a menu that opens half
   * outside the window is a menu the player cannot use, and the body
   * it belongs to can be anywhere on either hull.
   */
  /* NARROWER AND SHORTER (update68). 150x20 rows carried the full
     refusal text and the player's verdict was that the whole thing is
     "za duże za długie ze wszystkimi napisami" — a context menu that
     covers the room you are looking at.
     The reason now goes to the NOTIFICATION line instead of onto the
     row: a greyed row still tells you it is refused, and the sentence
     shows up where every other refusal in this game already shows up
     when you click it. */
  /* AND IT HANGS UNDER HIM (update69). Opening it to the SIDE put it
     on the wall — which is where the doors are — so the click that was
     meant for VENT toggled a hatch instead. Under his feet there is
     nothing but floor: the menu belongs to the man, so it sits on the
     man. Narrower again (50px) now that nothing but four short words
     has ever been drawn on a row. */
  const BODY_MENU_W = 50, BODY_MENU_ROW = 15, BODY_MENU_PAD = 3;
  const BODY_MENU_DROP = 12;              // below his feet, clear of the sprite
  function bodyMenuRects(x, y, acts = ['treat', 'eject', 'bag']) {
    const h = BODY_MENU_PAD * 2 + acts.length * BODY_MENU_ROW;
    const px = Utils.clamp(x - BODY_MENU_W / 2, 4, _W - BODY_MENU_W - 4);
    const py = Utils.clamp(y + BODY_MENU_DROP, 4, _H - h - 4);
    const out = { panel: { x: px, y: py, w: BODY_MENU_W, h }, items: [] };
    acts.forEach((act, i) => {
      out.items.push({
        act,
        x: px + BODY_MENU_PAD,
        y: py + BODY_MENU_PAD + i * BODY_MENU_ROW,
        w: BODY_MENU_W - BODY_MENU_PAD * 2,
        h: BODY_MENU_ROW - 2,
      });
    });
    return out;
  }

  /**
   * Draw it. `refusal(act)` is asked for EVERY row — the same question
   * the click will answer — so a row can never look live and then do
   * nothing, and the reason is printed rather than left to be guessed.
   */
  function drawBodyMenu(ctx, x, y, name, refusal, acts) {
    const R = bodyMenuRects(x, y, acts);
    const p = R.panel;
    ctx.fillStyle = 'rgba(8,12,22,0.96)';
    ctx.beginPath(); ctx.roundRect(p.x, p.y, p.w, p.h, 4); ctx.fill();
    ctx.strokeStyle = '#4db8ff'; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.roundRect(p.x, p.y, p.w, p.h, 4); ctx.stroke();

    /* EJECT, not VENT (update75). Since update73 the ship has a real
       ventilation duct along every ceiling — fire moves through it,
       vermin live in it, and the player reads "vent" as that. This
       button is the airlock: the body goes out into the black and does
       not come back. Two different things had one word, on one screen.

       EJECT and not JETTISON because the row is 44px of 9px monospace:
       the longer word runs off the end of its own button. */
    const LABEL = { treat: 'TREAT', eject: 'EJECT', bag: 'BAG', feed: 'FEED',
                    cell: 'CELL', freeze: 'FREEZE', thaw: 'THAW', medkit: 'MEDKIT',
                    heal: 'HEAL' };
    /* HEAL blue, FEED green when they are live (update104, jj): the two
       sat side by side, FEED grey like a dead button and HEAL the same
       green as TREAT. */
    const COL   = { treat: '#1aff8c', eject: '#ff5566', bag: '#ffd700',
                    feed: '#1aff8c', cell: '#4db8ff',
                    freeze: '#7fd4ff', thaw: '#ffb020', medkit: '#1aff8c',
                    heal: '#4db8ff' };
    ctx.textAlign = 'left';
    R.items.forEach(it => {
      const why = refusal ? refusal(it.act) : null;
      const col = why ? '#3a4560' : COL[it.act];
      ctx.fillStyle = why ? 'rgba(13,17,32,0.6)' : 'rgba(20,30,50,0.9)';
      ctx.fillRect(it.x, it.y, it.w, it.h);
      ctx.strokeStyle = col; ctx.lineWidth = 1;
      ctx.strokeRect(it.x + 0.5, it.y + 0.5, it.w - 1, it.h - 1);
      ctx.fillStyle = col;
      ctx.font = '9px Share Tech Mono, monospace';
      ctx.fillText(LABEL[it.act], it.x + 4, it.y + 10);
    });
    return R;
  }

  /** Trim a string to fit a width — small local helper, no ellipsis
   *  library, and it never returns something wider than asked for. */
  function _clipTo(ctx, text, max) {
    let t = String(text);
    if (ctx.measureText(t).width <= max) return t;
    while (t.length > 1 && ctx.measureText(t + '…').width > max) t = t.slice(0, -1);
    return t + '…';
  }

  function _drawOrderPanel(ctx, top, inCombat) {
    _orderTop = top;
    const R = orderRects();
    /* update51: these ARE the commander's orders. Without a commander
       the clicks are refused, so they must not look live — and the
       question asked here is the very one game.js answers when the
       click arrives, not a second guess at it. */
    const has = (typeof Game !== 'undefined' && Game.hasCommander)
      ? Game.hasCommander() : true;
    const DEAD = '#3a4560';

    ctx.fillStyle = has ? '#4a6080' : '#ff7c20';
    ctx.font = '8px Share Tech Mono, monospace';
    ctx.textAlign = 'left';
    /* EVERY ORDER COSTS KNOWLEDGE (update98), so the heading says how
       much — a button that greys out with no word why is a riddle. */
    ctx.fillText(has ? 'ORDERS · 1 KN (BOARD 5)' : 'ORDERS — NO COMMANDER', ORDER_X, top + 8);

    /* Can he PAY for it? The same question game.js asks on the click. */
    const cap = (typeof Commander !== 'undefined' && Commander.active) ? Commander.active() : null;
    const pays = (key) => !cap || Commander.knowledge(cap) >= Commander.orderCost(key);

    const btn = (rect, label, colour, live) => {
      const col = live ? colour : DEAD;
      ctx.fillStyle = 'rgba(13,17,32,0.9)';
      ctx.beginPath(); ctx.roundRect(rect.x, rect.y, rect.w, rect.h, 3); ctx.fill();
      ctx.strokeStyle = col; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.roundRect(rect.x, rect.y, rect.w, rect.h, 3); ctx.stroke();
      ctx.fillStyle = col;
      ctx.font = '9px Share Tech Mono, monospace';
      ctx.textAlign = 'center';
      ctx.fillText(label, rect.x + rect.w / 2, rect.y + 12);
      ctx.textAlign = 'left';
    };

    btn(R.crewSave,   'SAVE POS',  '#4db8ff', has && pays('save'));
    btn(R.crewReturn, 'RETURN',    '#1aff8c', has && pays('return'));
    btn(R.doorsOpen,  'OPEN ALL',  '#1aff8c', has && pays('doorsOpen'));
    btn(R.doorsClose, 'CLOSE ALL', '#ff5566', has && pays('doorsClose'));
    _powerClickZones.push({ ...R.crewSave,   crewSave: true });
    _powerClickZones.push({ ...R.crewReturn, crewReturn: true });
    _powerClickZones.push({ ...R.doorsOpen,  doorsOpen: true });
    _powerClickZones.push({ ...R.doorsClose, doorsClose: true });

    /* BOARD, RECALL and RETREAT are fight-only, and they are drawn
       DARK rather than hidden out of combat — a panel that changes
       shape between the map and a fight is a panel the player has to
       relearn every jump. game.js owns their clicks, against these
       very rectangles. */
    const boardN = (typeof UI !== 'undefined' && UI.getSelectedCrewAll)
      ? UI.getSelectedCrewAll().filter(c => c.alive).length : 0;
    btn(R.board,   boardN ? `BOARD ${Math.min(boardN, 3)}` : 'BOARD',
        '#ff2d44', has && inCombat && pays('board'));
    btn(R.recall,  'RECALL',  '#4db8ff', has && inCombat && pays('recall'));
    btn(R.retreat, 'RETREAT [R]', '#ff7c20', has && inCombat);
  }

  function drawHUD(state) {
    _enemyStripBottom = 0; _enemyHeatBar = null;
    _powerClickZones.length = 0;
    _crewMarkZones.length = 0;
    _rankZones.length = 0;
    if (!state.playerShip) return;
    const ship = state.playerShip;
    const run  = Save.getRun();
    if (!run) return;
    const ctx  = _ctx;

    // ════ TOP-LEFT: Player hull bar (segmented, FTL style) ════
    _drawHeartBar(ctx, 14, 14, ship.hull, ship.hullMax, '#1aff8c', '#0a3018', 360);

    // ONE status row under the hull: EVADE → OXYGEN → shield bubbles
    // (the old dark "evasion badge" circle looked like a phantom empty
    //  bubble — gone; pills no longer touch the crew list either)
    const shieldY = 58;
    const o2avg = ship.oxygen.averageO2();
    const o2col = o2avg < 0.25 ? '#ff2d44' : o2avg < 0.6 ? '#ffd700' : '#4db8ff';
    _statPill(ctx, 14, shieldY, 'EVADE',  Math.round(ship.evasion * 100) + '%', '#1aff8c');
    _statPill(ctx, 92, shieldY, 'OXYGEN', Math.round(o2avg * 100) + '%', o2col);
    {
      const ss = ship.getSystem('shields');
      const prog = ss ? ss.shieldChargeProgress : 0;
      for (let i = 0; i < ship.shieldMax; i++) {
        const lit = i < ship.shieldBars;
        _shieldBubble(ctx, 184 + i * 30, shieldY + 12, 11, lit,
                      i === ship.shieldBars ? prog : 0);
      }
    }

    /* ════ THE COMMANDER (update43) ════ — the strip above the crew list
       is gone (update104): the commander bar at the top took over his
       face, his name, the dossier click and the pod. */

    /* ── AND THEIRS (update50) ──
       The player is told a corporation and a level, and nothing else:
       no board, no chip list. That is the whole of what the spec
       allows him to see, and it is enough to read a fight — a level 7
       Phoenix commander means their boarders hit harder, and you find
       that out from the badge rather than from a surprise. */
    /* THE BADGE HANGS ON THE HULL, NOT ON A FLAG (update54).
       `Commander.setEnemy(null)` had to be remembered at FIVE exits
       from a fight — win, lose, jump away, evacuate, boss defeated —
       and the boss path forgot, so a beaten commander's badge sat on
       the HUD over empty space until the next battle overwrote it.
       The badge is not a fact of its own: it is "there is an enemy ship
       in front of me and somebody is commanding it". Asking the hull
       cannot go stale, because when the hull is gone so is the badge —
       and no future exit has to remember anything. */
    const foeShip = state.enemyShip;
    // A wreck has no commander, whatever was left set (update90b).
    const foeAlive = !!foeShip && !foeShip.destroyed && foeShip.hull > 0 && !foeShip.isDerelict;
    if (foeAlive && typeof Commander !== 'undefined' && Commander.enemy && Commander.enemy()) {
      const foe = Commander.enemy();
      const w2 = 118, x2 = _W - w2 - 14, y2 = 84;
      ctx.fillStyle = 'rgba(28,10,14,0.85)';
      ctx.beginPath(); ctx.roundRect(x2, y2, w2, 20, 3); ctx.fill();
      ctx.strokeStyle = '#ff5566'; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.roundRect(x2, y2, w2, 20, 3); ctx.stroke();
      ctx.fillStyle = crewColor(foe);
      ctx.fillRect(x2 + 3, y2 + 3, 14, 14);
      ctx.fillStyle = '#ff8a95';
      ctx.font = '9px Share Tech Mono, monospace';
      ctx.textAlign = 'left';
      const corp = (typeof CORP_DEFS !== 'undefined' && CORP_DEFS[foe.race]?.label)
        || foe.race || '?';
      ctx.fillText(`${String(corp).slice(0, 8)} L${foe.level}`, x2 + 21, y2 + 13);
    }

    // ════ LEFT: Crew portraits with HP bars & CONDITION tags ════
    let crewY = 108;
    const roster = crewRoster(state);
    /* HOW MANY CARDS FIT ABOVE THE ORDER PANEL. The panel is anchored
       to the floor rather than trailing the list, which also stops the
       buttons wandering up and down the screen every time somebody is
       recruited or dies — a fixed target for the hand. */
    const FLOOR    = leftColumnFloor(ship);
    const listEnd  = FLOOR - orderPanelHeight();
    const rowPitch = CREW_ROW_H + 4;
    const fits     = Math.max(1, Math.floor((listEnd - crewY) / rowPitch));
    /* THE LIST SCROLLS (update97). It used to end at whoever fitted and
       say "+2 MORE" — two men you could see were there and could not
       click. Now the wheel over the list moves a window down it; the
       line under it says how many are above and below. The selected man
       is always kept in the window, so TAB and a click on the deck never
       select somebody you cannot see. */
    const win      = roster.length > fits ? Math.max(1, fits - 1) : fits;
    const maxScroll = Math.max(0, roster.length - win);
    const selNow   = UI.getSelectedCrew?.();
    const selIdx   = selNow ? roster.indexOf(selNow) : -1;
    if (selIdx >= 0 && selNow !== _rosterSelSeen) {
      if (selIdx < _rosterScroll) _rosterScroll = selIdx;
      if (selIdx >= _rosterScroll + win) _rosterScroll = selIdx - win + 1;
    }
    _rosterSelSeen = selNow;
    _rosterScroll  = Utils.clamp(_rosterScroll, 0, maxScroll);
    _rosterBox     = { x: 14, y: crewY, w: 100, h: win * rowPitch, max: maxScroll };
    const shown    = roster.slice(_rosterScroll, _rosterScroll + win);
    const above    = _rosterScroll;
    const below    = roster.length - shown.length - above;
    const hidden   = above + below;
    shown.forEach((c, i) => {
      const cx = 14, cw = 100, ch = CREW_ROW_H;   // update54: was 120
      const away = c._awayTeam;
      // Condition tag (drawn after the row background below)
      /* ── SICK IS NOT A CONDITION THAT HIDES HIS HP (update68) ──
       *
       * The corpse plague used to replace the whole HP row with the
       * word SICK, so the one thing a player needs to decide anything —
       * how close to dead the man is — vanished the moment he caught
       * something. His words: "jak jest sick to zniknęło hp info z
       * listy załogantów".
       *
       * A tag REPLACES the bar only when hit points are meaningless:
       * he is dead, he is rotting, or he is on the floor. Being ill is
       * a mark beside the bar, not instead of it. */
      const tag = c.decaying          ? { t: 'DECAYING', col: DISEASE_COL.plague }
                : c.dead              ? { t: 'DEAD',     col: '#98a0b8' }
                : c.state === 'injured' ? { t: 'INJURED',  col: '#ffd700' }
                : null;
      c._rosterTag = tag;
      const sel = UI.getSelectedCrew && UI.getSelectedCrew() === c;

      ctx.fillStyle = sel ? 'rgba(26,140,255,0.25)' : 'rgba(13,17,32,0.85)';
      ctx.beginPath(); ctx.roundRect(cx, crewY, cw, ch, 3); ctx.fill();
      ctx.strokeStyle = sel ? '#4db8ff' : away ? '#ff7c20' : '#1e2d4a';
      ctx.lineWidth = sel || away ? 1.5 : 1;
      ctx.stroke();

      // Mini portrait square — corporation color
      ctx.fillStyle = crewColor(c);
      ctx.fillRect(cx + 3, crewY + 3, 20, 20);
      ctx.fillStyle = '#c8d8f0';
      ctx.fillRect(cx + 6, crewY + 5, 14, 8); // helmet

      // Name (greyed out for the dead)
      ctx.fillStyle = c.dead ? '#7a8298' : '#c8d8f0';
      ctx.font = '10px Share Tech Mono, monospace';
      ctx.textAlign = 'left';
      ctx.fillText(c.name.slice(0, 7), cx + 28, crewY + 12);
      /* The away-team chevron used to be painted over the portrait
         here. It is a MARK — it says something is true of the man —
         so it lives with the other marks now, in the strip beside the
         row, and there is one place to look instead of three. */

      // Condition tag OR the HP bar
      if (c._rosterTag) {
        ctx.fillStyle = c._rosterTag.col;
        ctx.font = 'bold 9px Share Tech Mono, monospace';
        ctx.fillText(c._rosterTag.t, cx + 28, crewY + 23);
      } else {
        drawPips(ctx, cx + 28, crewY + 16, cw - 34, 6, c.hp, c.maxHp,
                 c.hp / c.maxHp > 0.5 ? '#1aff8c'
                   : c.hp / c.maxHp > 0.25 ? '#ffd700' : '#ff2d44');
      }

      /* HIS RANK, IN THE ROW (update96). It is what he is worth, not
         what is happening to him, so it stays here rather than in the
         mark strip. It used to be one star in two colours for all
         twenty-five ranks; it is his own insignia now, and pointing at
         it says the rank by name and what he is a specialist in —
         the row has no room to spell those out. */
      {
        const IH = RANK_ROW_H, iw = IH * 2;
        const ix = cx + cw - 3 - iw, iy = crewY + 4;
        drawRankInsignia(ctx, c.rankLevel ? c.rankLevel() : 0, ix, iy, IH);
        _rankZones.push({ x: ix - 1, y: iy - 1, w: iw + 2, h: IH + 2, tip: rankTip(c), crew: c });
      }

      /* ── THE MARK STRIP, BESIDE THE ROW (update76) ───────────
       *
       * Everything that is TRUE OF THE MAN rather than part of his
       * identity: both diseases at once, hunger, whether he is off the
       * ship, and which module he is actually working. The list comes
       * from `crewMarks` so the picture and the test read the same
       * sentence.
       *
       * The pulse still means WARNING and nothing else — it is on the
       * two things that get worse if ignored (a disease, and a man who
       * has stopped eating), and off everything that is merely true. */
      const marks = crewMarks(c, ship);
      const my = crewY + MARK_TOP;
      marks.forEach((m, mi) => {
        const mx = cx + 4 + mi * MARK_STEP;
        const pulse = m.pulse
          ? 0.55 + 0.45 * (0.5 + 0.5 * Math.sin((c._rosterPulse = (c._rosterPulse ?? 0) + 0.02)))
          : 1;
        ctx.globalAlpha = pulse;
        ctx.fillStyle = m.col;
        /* A KEY INTO ONE ICON SET, with the glyph as the fallback.
           The module mark has no icon — "which module" is SYSTEM_GLYPHS
           and that is already one table — so the two live side by side
           rather than one of them being reinvented as a shape. */
        if (m.icon) {
          ctx.strokeStyle = m.col;
          drawStatIcon(ctx, m.icon, mx, my, MARK_SIZE, m.col);
        } else if (m.sysType) {
          drawSystemIcon(ctx, m.sysType, mx + MARK_SIZE / 2, my + MARK_SIZE / 2, MARK_SIZE + 2, m.col);
        } else {
          ctx.font = `bold ${MARK_SIZE}px monospace`;
          ctx.textAlign = 'left';
          ctx.fillText(m.glyph, mx, my + MARK_SIZE - 2);
        }
        ctx.globalAlpha = 1;
        _crewMarkZones.push({ x: mx - 1, y: my - 1, w: MARK_STEP, h: MARK_SIZE + 2,
                              tip: m.tip });
      });

      // Click zone — select crew member. `crewRef` is the crew member
      // himself: the row used to carry only an index into
      // _playerShip.crew, which stopped being the roster the moment
      // boarders started appearing in it from the enemy hull.
      _powerClickZones.push({ x: cx, y: crewY, w: cw, h: ch, crewIndex: i, crewRef: c });

      crewY += ch + 4;
    });

    /* ════ THE ORDER PANEL (rebuilt in update53) ═══════════
     *
     * EVERY order the commander can give, in ONE place, under the
     * crew he is giving them to. Until update53 the doors and the
     * saved stations were here while BOARD, RECALL and RETREAT sat
     * across the top of the screen — three buttons that were orders
     * in every sense except where they were drawn. The player had to
     * know two places to look, and the two drifted: the BOARD
     * rectangle was written out by hand at the draw site AND at the
     * click site, which is a bug waiting for the first time somebody
     * moves one of them.
     *
     * `orderRects()` is now the single source of that geometry and
     * both the picture and the hit test read it.
     */
    /* AND WHOEVER DID NOT FIT IS COUNTED, not silently dropped. A
       roster that quietly ends at six is a roster the player cannot
       trust; a line that says "+2 MORE" is one he can. */
    if (hidden > 0) {
      ctx.fillStyle = '#7a8298';
      ctx.font = '9px Share Tech Mono, monospace';
      ctx.textAlign = 'left';
      ctx.fillText(`▲${above} ▼${below} · WHEEL`, 14, crewY + 9);
      crewY += 14;
    }
    /* NO `Math.min(crewY + 2, listEnd)` HERE, and that is deliberate.
       The first version clamped the panel as a belt to the braces
       above — and the breaking run could not break it, because the
       clamp can never bind: `fits` is derived from `listEnd`, so the
       last card plus the "+N MORE" line always stop short of it by the
       remainder of that division. A second guard that cannot fire is a
       line the next reader has to disprove. The list is what keeps the
       panel on screen; it is tested, and it is enough. */
    if (roster.length) {
      _drawOrderPanel(ctx, crewY + 2, !!state.enemyShip);
    }

    /* WHAT THAT LITTLE SYMBOL MEANS. Drawn after the whole left column,
       so the tip is never painted under the next row. A mark that needs
       a legend elsewhere on the screen is a mark the player will ignore
       — this one explains itself where his hand already is. */
    /* The rank zones are NOT hovered (update97): his rank is in the
       crew panel that opens beside the roster, and a second box over
       it was the overlap jj reported. */
    const hov = _crewMarkZones.find(z => z.tip &&
      Utils.pointInRect(Input.mouse.x, Input.mouse.y, z.x, z.y, z.w, z.h));
    if (hov) {
      ctx.font = '10px Share Tech Mono, monospace';
      const tw = ctx.measureText(hov.tip).width + 12;
      const tx = Math.min(hov.x + 14, _W - tw - 4);
      const ty = hov.y - 2;
      ctx.fillStyle = 'rgba(8,12,22,0.96)';
      ctx.beginPath(); ctx.roundRect(tx, ty, tw, 16, 3); ctx.fill();
      ctx.strokeStyle = '#4db8ff'; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.roundRect(tx, ty, tw, 16, 3); ctx.stroke();
      ctx.fillStyle = '#c8d8f0';
      ctx.textAlign = 'left';
      ctx.fillText(hov.tip, tx + 6, ty + 11);
    }

    // The reactor used to have its own tall column over here, wired to
    // every module with an orange rail. It is a module like any other
    // now and lives in the bottom row with the rest — see _drawPowerBar.

    // ════ BOTTOM BAR: power management (FTL style) ════
    _drawPowerBar(ctx, ship, run);

    // ════ TOP-RIGHT: Enemy hull (if combat) ════
    // The whole enemy readout disappears the moment the ship is destroyed.
    if (state.enemyShip && state.enemyShip.hull > 0 && !state.enemyShip.destroyed) {
      const e = state.enemyShip;
      /* RIGHT-ANCHORED (update40). A fixed left edge at _W − 320 sent a
         big enemy hull bar straight off the canvas; measure it and hang
         it off the right margin instead, so it always ends on screen
         whatever the hull. The status row below follows the bar. */
      const eBarW = _heartBarWidth(e.hullMax, 300);
      const eX    = Math.min(_W - 14 - eBarW, _W - 320);
      _drawHeartBar(ctx, eX, 14, e.hull, e.hullMax, '#ff7c20', '#301505', 300);

      // Enemy status: ONE row — EVADE → OXYGEN → bubbles (same style)
      const eo2  = e.oxygen.averageO2();
      const eCol = eo2 < 0.25 ? '#ff2d44' : eo2 < 0.6 ? '#ffd700' : '#4db8ff';
      _statPill(ctx, eX, 52, 'EVADE',  Math.round(e.evasion * 100) + '%', '#ff7c20');
      _statPill(ctx, eX + 78, 52, 'OXYGEN', Math.round(eo2 * 100) + '%', eCol);
      /* ARMOUR (update94): a third pill, only on what wears it — where
         shield bubbles would be, since a bunker has none. */
      if ((e.armor ?? 0) > 0) _statPill(ctx, eX + 156, 52, 'ARMOUR', `-${e.armor} / hit`, '#c8d8f0');
      {
        const es = e.getSystem('shields');
        const eprog = es ? es.shieldChargeProgress : 0;
        /* THE LAST BUBBLE WAS BEING SHAVED OFF (update42). The row hung
           off a hardcoded `_W - 150` while everything around it is
           right-anchored off eX, so the pips grew RIGHTWARD into the
           canvas edge: the 6th one started at x=1270 on a 1280 canvas
           and the charge ring on the partly-charged pip clipped even
           earlier. Anchor the row's RIGHT edge instead and it grows
           leftward, staying on screen at any shield count. */
        const R = 10, PITCH = 28;
        const edge = R + 5;                   // stroke + 2.5px charge ring at r+3
        const lastCx = _W - 14 - edge;
        for (let i = 0; i < e.shieldMax; i++) {
          const lit = i < e.shieldBars;
          const cx  = lastCx - (e.shieldMax - 1 - i) * PITCH;
          _shieldBubble(ctx, cx, 64, R, lit,
                        i === e.shieldBars ? eprog : 0);
        }
      }

      // ── Enemy module panel: BELOW the enemy ship, centered ──
      _drawEnemyModules(ctx, e);
    }

    // ════ Resources row (scrap/fuel/missiles/sector) top-center ════
    const resX = 470;
    ctx.fillStyle = 'rgba(13,17,32,0.85)';
    // Widened in update58 for the ore readout, and again in update80
    // for the doses and the rations.
    ctx.beginPath(); ctx.roundRect(resX, 10, 466, 26, 4); ctx.fill();
    ctx.strokeStyle = '#1e2d4a'; ctx.lineWidth = 1; ctx.stroke();
    ctx.font = '12px Share Tech Mono, monospace';
    ctx.textAlign = 'left';
    // CC green (money), He2 red (the thing that strands you)
    ctx.fillStyle = '#1aff8c';
    ctx.fillText(`${run.scrap} CC`, resX + 12, 28);
    ctx.fillStyle = run.fuel <= 2 ? '#ff2d44' : '#ff5566';
    ctx.fillText(`He2 ${run.fuel}`, resX + 82, 28);
    // A WARHEAD, not just the letters MSL. The pictogram already
    // existed (STAT_ICONS.ammo) and had exactly one caller in the whole
    // game — the base armoury — so the readout the player watches in a
    // fight was the one place it never appeared.
    const mslCol = run.missiles <= 0 ? '#7a5030' : '#ff7c20';
    drawStatIcon(ctx, 'ammo', resX + 166, 18, 11, mslCol);
    ctx.fillStyle = mslCol;
    ctx.fillText(`${run.missiles}`, resX + 182, 28);
    /* TORPEDOES (update94), beside the warheads — only once there is a
       tube or a rack aboard, so the bar does not grow for nothing. */
    {
      const trp = ship.cargo?.countOf ? ship.cargo.countOf('torpedoes') : 0;
      const tube = (ship.weapons ?? []).some(w => w && w.def?.torpedoUse);
      if (trp > 0 || tube) {
        ctx.fillStyle = trp > 0 ? '#4dd8c0' : '#2f5a54';
        ctx.fillText(`T${trp}`, resX + 204, 28);
      }
    }
    /* He-3 ORE (update58). The player asked why the mineral he is
       carrying is invisible, and he was right: it lived in the hold and
       nowhere else on screen. Read STRAIGHT OFF THE HOLD — the cells
       ARE the amount, exactly like the He2 cells and the missile racks,
       so there is no second number to keep in step.
       Drawn dim at zero rather than hidden: a readout that appears and
       disappears is a readout the player never learns to look at. */
    {
      const ore = ship.cargo?.countOfTag ? ship.cargo.countOfTag('he3') : 0;
      const oreCol = ore > 0 ? '#cfe4ff' : '#3d4a63';
      drawStatIcon(ctx, 'ore', resX + 232, 18, 11, oreCol);
      ctx.fillStyle = oreCol;
      ctx.fillText(`He3 ${ore}`, resX + 248, 28);
    }
    /* ── WHAT IS IN THE HOLD THAT KEEPS PEOPLE ALIVE (update80) ──
     *
     * The bar has always carried the two things that strand you —
     * fuel and warheads — and not the two things that kill your crew:
     * doses and rations. The player's words: "dobrze bylo by dodac na
     * gorze rowniez info ile jest opatrunkow i jedzenia, tak jak mamy
     * info ile rakiet i paliwa, aby gracz nie musial wchodzic do
     * inwentory aby to sprawdzic."
     *
     * Read STRAIGHT OFF THE HOLD, like the ore readout since update58
     * and for the same reason: the cells ARE the amount, so there is
     * no second number to keep in step. Doses come from the ship's own
     * `doseCount`, which is the function the bandage and the medkit
     * spend against — the readout and the rule cannot disagree.
     *
     * Dim at zero rather than hidden. A readout that appears and
     * disappears is a readout the player never learns to look at, and
     * "no doses aboard" is exactly the moment he needs to see it.
     */
    {
      const doses = typeof ship.doseCount === 'function' ? ship.doseCount() : 0;
      const dCol  = doses > 0 ? '#7fe08a' : '#3d4a63';
      drawStatIcon(ctx, 'medical', resX + 300, 18, 11, dCol);
      ctx.fillStyle = dCol;
      ctx.fillText(`${doses}`, resX + 316, 28);

      const food = ship.cargo?.countOfTag ? ship.cargo.countOfTag('food') : 0;
      const fCol = food > 0 ? '#ffb020' : '#3d4a63';
      drawStatIcon(ctx, 'eating', resX + 348, 18, 11, fCol);
      ctx.fillStyle = fCol;
      ctx.fillText(`${food}`, resX + 364, 28);
    }
    ctx.fillStyle = '#4db8ff';
    ctx.fillText(`SEC ${run.sector}`, resX + 396, 28);

    /* THE CELLS, ONLY WHEN THERE ARE ANY (update63).
     *
     * Unlike the ore readout above, this one DOES appear and vanish —
     * and for the opposite reason: a permanent 0/0 on a hull with no
     * brig would be noise on every run for a feature most runs never
     * touch. What must never be silent is a man about to walk, so the
     * moment the brig loses power the readout goes red and counts the
     * clock down in seconds the player can act on.
     */
    const cells = ship.carboniteCapacity ? ship.carboniteCapacity() : 0;
    /* BOTH KINDS OF OCCUPANT (update77). A slab is a slab whether the
       man in it is a convict you are hauling in or your own gunner
       with a bite. Counting only prisoners would have shown 0/3 on a
       bay with three of your own crew in it. */
    const held  = (ship.prisoners ? ship.prisoners.length : 0)
                + (ship.frozenCrew ? ship.frozenCrew().length : 0);
    if (cells > 0 || held > 0) {
      const brig    = ship.getSystem('carbonite');
      // Only a PRISONER works a lock. A frozen man whose slab goes
      // cold simply wakes up, which is `carboniteTick`, not an escape.
      const locks    = ship.prisoners ? ship.prisoners.length : 0;
      const slipping = locks > 0 && (!brig || brig.isDisabled());
      const worst   = slipping
        ? Math.max(...ship.prisoners.map(p => p.escapeT ?? 0)) : 0;
      const left    = Math.max(0, Math.ceil(Ship.ESCAPE_SECONDS - worst));
      const col     = slipping ? '#ff2d44' : held > 0 ? '#ffd700' : '#3d4a63';
      ctx.fillStyle = 'rgba(13,17,32,0.85)';
      ctx.beginPath(); ctx.roundRect(resX + 396, 10, 118, 26, 4); ctx.fill();
      ctx.strokeStyle = slipping ? '#ff2d44' : '#1e2d4a';
      ctx.lineWidth = 1; ctx.stroke();
      ctx.fillStyle = col;
      ctx.font = '12px Share Tech Mono, monospace';
      ctx.fillText(slipping ? `CARB ${left}s!` : `CARB ${held}/${cells}`, resX + 406, 28);
    }

    /* THE COMMANDER BAR (update98) — always, with a commander aboard
       (update104). The objective line lives where the bar now is, so
       it drops under it. */
    const barUp = _commanderBarShown(state);
    if (barUp) _drawCommanderBar(ctx, state);
    _drawRunGoals(ctx, resX, barUp ? CMD_BAR.y + CMD_BAR.h + 4 : RUN_GOALS_BOX.y);
    if (barUp) _drawCommanderBarTip(ctx, !!state.enemyShip);
  }

  /* ── WHAT ELSE THIS RUN IS BEING ASKED FOR (update71) ────────
   *
   * ONE LINE, under the resources row, and it is the whole of the
   * side-objective UI — the design says so in as many words: "jedna
   * linia na HUD… nie robimy z tego drugiego ekranu". A goal is a
   * counter with a price on it; a screen would make it look like a
   * system.
   *
   * It draws nothing at all when the contract carries no goals, so a
   * player who never looks at it never has it in the way.
   */
  /* WHERE THAT LINE LIVES, as a rectangle anybody can ask for
     (update74). The map/cargo buttons sit in the same strip of screen
     and were drawn straight through it — the player's report was
     "OBJ nachodzi na SHOW MAP i CARGO". Giving the line a published
     box means the buttons can be placed BELOW it and a test can say
     so, instead of two sets of coordinates being nudged past each
     other by eye until they happen to miss. */
  const RUN_GOALS_BOX = { y: 40, h: 17, w: 390 };
  /** WHERE the line lives, always — whether or not this contract has
   *  anything to put on it. Anything laid out AROUND the line wants
   *  this one, so that the layout does not move when a contract
   *  happens to carry no objectives. */
  function runGoalsBox() { return { ...RUN_GOALS_BOX }; }
  /** The line as drawn RIGHT NOW, or null when there is nothing on it. */
  function runGoalsRect(resX = 470) {
    const goals = (typeof Save !== 'undefined' && Save.runGoals) ? Save.runGoals() : [];
    if (!goals.length) return null;
    return { x: resX, y: RUN_GOALS_BOX.y, w: RUN_GOALS_BOX.w, h: RUN_GOALS_BOX.h };
  }

  function _drawRunGoals(ctx, resX, y = RUN_GOALS_BOX.y) {
    const goals = (typeof Save !== 'undefined' && Save.runGoals) ? Save.runGoals() : [];
    if (!goals.length) return;
    const h = RUN_GOALS_BOX.h;
    ctx.fillStyle = 'rgba(13,17,32,0.85)';
    ctx.beginPath(); ctx.roundRect(resX, y, RUN_GOALS_BOX.w, h, 3); ctx.fill();
    ctx.strokeStyle = '#1e2d4a'; ctx.lineWidth = 1; ctx.stroke();
    ctx.font = '9px Share Tech Mono, monospace';
    ctx.textAlign = 'left';
    ctx.fillStyle = '#4a6080';
    ctx.fillText('OBJ', resX + 8, y + 12);
    let x = resX + 30;
    goals.forEach((g, i) => {
      /* A FINISHED JOB STAYS ON THE LINE, greyed and ticked. Taking it
         away the moment it pays would leave the player wondering
         whether he imagined it — and the line is the only place the
         run's own bookkeeping is ever shown. */
      const col = g.done ? '#3d4a63' : (g.n > 0 ? '#ffd700' : '#7a90a8');
      const txt = g.done ? `✓ ${g.label}` : `${g.label} ${g.n}/${g.need}`;
      if (i > 0) {
        ctx.fillStyle = '#2a3346';
        ctx.fillText('·', x - 7, y + 12);
      }
      ctx.fillStyle = col;
      ctx.fillText(txt, x, y + 12);
      x += ctx.measureText(txt).width + 14;
    });
  }

  /** One shield bubble — shared style for player AND enemy.
   *  `chargeProg` (0-1) draws a progress arc while this layer charges. */
  function _shieldBubble(ctx, x, y, r, lit, chargeProg = 0) {
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    if (lit) {
      const g = ctx.createRadialGradient(x - r*0.3, y - r*0.3, 1, x, y, r);
      g.addColorStop(0, '#d8f2ff');
      g.addColorStop(0.45, '#4db8ff');
      g.addColorStop(1, '#134a80');
      ctx.fillStyle = g;
    } else {
      ctx.fillStyle = 'rgba(16,30,52,0.75)';
    }
    ctx.fill();
    ctx.strokeStyle = lit ? '#9fdcff' : '#28486e';
    ctx.lineWidth = 1.5;
    ctx.stroke();
    if (lit) {   // inner glint
      ctx.beginPath();
      ctx.arc(x - r*0.35, y - r*0.35, r*0.22, 0, Math.PI*2);
      ctx.fillStyle = 'rgba(255,255,255,0.55)';
      ctx.fill();
    }
    // Recharge progress ring (like the crew repair ring)
    if (!lit && chargeProg > 0) {
      ctx.beginPath();
      ctx.arc(x, y, r + 3, -Math.PI/2, -Math.PI/2 + chargeProg * Math.PI * 2);
      ctx.strokeStyle = '#8fd4ff';
      ctx.lineWidth = 2.5;
      ctx.stroke();
    }
  }

  /** Readable stat pill: dark rounded badge, label + colored value */
  function _statPill(ctx, x, y, label, value, color) {
    const w = 74, h = 24;
    ctx.fillStyle = 'rgba(13,17,32,0.92)';
    ctx.beginPath(); ctx.roundRect(x, y, w, h, 5); ctx.fill();
    ctx.strokeStyle = color; ctx.lineWidth = 1; ctx.stroke();
    ctx.font = '8px Share Tech Mono, monospace';
    ctx.textAlign = 'left';
    ctx.fillStyle = '#7a90a8';
    ctx.fillText(label, x + 7, y + 9);
    ctx.font = 'bold 12px Share Tech Mono, monospace';
    ctx.fillStyle = color;
    ctx.fillText(value, x + 7, y + 20);
    return w;
  }

  /** FTL-style segmented health bar with heart icon */
  /**
   * How wide a heart bar actually comes out, for a given pip count.
   *
   * `Math.max(7, …)` is a FLOOR on the segment width, so the bar does
   * NOT in fact "never exceed 360px" the way the old comment claimed:
   * a 28-pip gunship hull came out 376px wide, and the enemy copy is
   * anchored at _W − 320, so the last five pips were drawn off the
   * right-hand edge of the canvas. Callers ask for the width now and
   * place the bar accordingly.
   */
  function _heartBarWidth(max, budget = 360) {
    const gap  = 2;
    const segW = Math.max(5, Math.min(15, Math.floor(budget / Math.max(1, max)) - gap));
    return 40 + max * (segW + gap);
  }

  function _drawHeartBar(ctx, x, y, val, max, color, dimColor, budget = 360) {
    // Heart circle
    ctx.fillStyle = '#0d1120';
    ctx.beginPath(); ctx.arc(x + 16, y + 16, 17, 0, Math.PI*2); ctx.fill();
    ctx.strokeStyle = color; ctx.lineWidth = 2; ctx.stroke();
    ctx.fillStyle = color;
    ctx.font = '16px monospace';
    ctx.textAlign = 'center';
    ctx.fillText('♥', x + 16, y + 22);

    // Segments — sized to the budget the caller gave us.
    const gap  = 2;
    const segW = Math.max(5, Math.min(15, Math.floor(budget / Math.max(1, max)) - gap));
    const segH = 18;
    const startX = x + 40;
    for (let i = 0; i < max; i++) {
      const sx  = startX + i * (segW + gap);
      const lit = i < val;
      ctx.fillStyle = lit ? color : dimColor;
      ctx.beginPath();
      ctx.roundRect(sx, y + 7, segW, segH, 2);
      ctx.fill();
      if (lit && segW > 9) {
        ctx.fillStyle = 'rgba(255,255,255,0.25)';
        ctx.fillRect(sx + 2, y + 9, segW - 4, 3);
      }
    }
  }

  /**
   * FTL-style bottom power bar.
   * Icons in circles, clickable power pips above each icon,
   * weapons with charge segments, all connected by power line.
   * Click zones stored in _powerClickZones for game.js to consume.
   */

  /**
   * Compact FTL-style enemy systems readout, drawn BELOW the enemy ship.
   * Per column (one per system): status icons on top, power pips
   * (growing upward from a common baseline), system icon underneath.
   */
  /* WHERE THE ENEMY'S MODULE STRIP ENDS, this frame (update91). The log
     window in the bottom-right corner (update88) was drawn over it when
     the enemy hull sat low — a screenshot showed their reactor and guns
     under the log. drawHUD resets it; UI reads it after. */
  let _enemyStripBottom = 0;
  /* Where the enemy's heat bar was drawn last frame (update97) — for the
     tests, which ask the picture rather than the number. */
  let _enemyHeatBar = null;
  function enemyHeatBar() { return _enemyHeatBar; }
  function enemyStripBottom() { return _enemyStripBottom; }

  function _drawEnemyModules(ctx, ship) {
    const _es = ship.systems.filter(s => s.maxPower > 0);
    // Reactor FIRST (leftmost): its tall stack no longer climbs over
    // the hull of tall ships like the Apophis station.
    const systems = [..._es.filter(s => s.type === 'reactor'),
                     ..._es.filter(s => s.type !== 'reactor')];
    if (!systems.length) return;
    const glyphs = {
      shields: '◙', weapons: '▲', engines: '≋',
      oxygen: 'O₂', medbay: '+', piloting: '◎', artillery: '✦',
      reactor: '⚡',
    };

    const colW = 34;
    const pw = 12, ph = 5, pg = 2;
    const step = ph + pg;                       // 7px per pip
    const maxPips = Math.max(...systems.map(s => s.maxPower));

    // Anchor: centered under the ship hull, below the plate (+14) and
    // weapon mounts; clamped to stay above the bottom power bar.
    const b  = ship.roomBounds();
    const x  = Utils.clamp(b.x + b.w / 2 - (systems.length * colW) / 2,
                           10, _W - systems.length * colW - 10);
    let  y   = b.y + b.h + 34;                  // top of the tallest pip stack
    const panelH = maxPips * step + 30;         // pips + icon circle
    y = Math.min(y, _H - 110 - panelH);         // keep clear of the bottom bar

    const baseline = y + maxPips * step;        // bottom edge of every stack
    // Published for the log window, which must start below it (update91).
    _enemyStripBottom = Math.max(_enemyStripBottom, baseline + 34);

    let ix = x + colW / 2;
    systems.forEach(sys => {
      /* THEIR REACTOR READS LIKE OURS (update97). jj watched an enemy
         hand stop at a gun in a nebula and could not see why: the cloud
         was holding two of their units back, and their column drew those
         as plain dark pips. Bottom to top, the same grammar as our own
         bar: their working units, then the nebula's share in violet, then
         what is shot out in red. */
      const reactorCol = sys.type === 'reactor' && ship.reactor;
      const capR  = reactorCol ? (ship.reactor.capacity ?? sys.maxPower) : 0;
      const dmgR  = reactorCol ? Math.min(capR, sys.damagedLevels) : 0;
      const penR  = reactorCol ? Math.min(capR - dmgR, ship.reactor.penalty ?? 0) : 0;
      const ownR  = capR - dmgR - penR;
      // Mini power pips — p=0 sits on the baseline, stack grows upward
      for (let p = 0; p < sys.maxPower; p++) {
        const py      = baseline - (p + 1) * step;
        const nebula  = reactorCol && p >= ownR && p < ownR + penR;
        const damaged = reactorCol ? p >= ownR + penR : p >= sys.maxPower - sys.damagedLevels;
        const lit     = !damaged && !nebula && (reactorCol ? !ship.reactor.offline : p < sys.power);
        ctx.fillStyle = damaged ? '#cc2233'
                      : nebula  ? '#8a3fbf'
                      : lit     ? '#ff9040'
                      : 'rgba(50,40,40,0.85)';
        ctx.fillRect(ix - pw/2, py, pw, ph);
        ctx.strokeStyle = damaged ? '#ff5566' : nebula ? '#cc44ff' : '#07080f';
        ctx.lineWidth = 0.5;
        ctx.strokeRect(ix - pw/2, py, pw, ph);
      }
      /* …and the heat bar beside it (update97), the player's bar in
         small: it fills from the bottom and changes colour at the same
         lines, so "their core is about to blow" reads the same way. */
      if (reactorCol) {
        const H = (typeof REACTOR_HEAT_CONFIG !== 'undefined') ? REACTOR_HEAT_CONFIG : null;
        const heat = Utils.clamp(ship.reactorHeat ?? 0, 0, 100);
        const crit = H ? H.criticalHeat : 90, warn = H ? H.warnHeat : 70;
        const col = heat >= crit ? '#ff2d44' : heat >= 80 ? '#ff7c20' : heat >= warn ? '#ffb020' : '#4d8fbf';
        const bx = ix + pw / 2 + 2, bw = 3;
        const bTop = baseline - sys.maxPower * step, bh = baseline - bTop;
        ctx.fillStyle = 'rgba(20,24,36,0.95)';
        ctx.fillRect(bx, bTop, bw, bh);
        ctx.fillStyle = col;
        ctx.fillRect(bx, baseline - bh * heat / 100, bw, bh * heat / 100);
        _enemyHeatBar = { x: bx, y: bTop, w: bw, h: bh, heat };
      }

      // Status icons (crew / fire / no-O2) just ABOVE this stack's top pip
      const topPipTop = baseline - sys.maxPower * step;
      const status = _roomStatus(ship, sys);
      status.forEach((st, si) => {
        _statusIcon(ctx, ix, topPipTop - 9 - si * 14, st);
      });

      // Icon below the baseline
      // Same three states as the player's bar (update90a): red is broken,
      // not merely off.
      const st = moduleIconState(sys);
      const broken = st === 'broken', running = st === 'running';
      const iy = baseline + 15;
      ctx.fillStyle = '#0d1120';
      ctx.beginPath(); ctx.arc(ix, iy, 11, 0, Math.PI*2); ctx.fill();
      ctx.strokeStyle = broken ? '#663333' : running ? '#aa5522' : '#4a6080';
      ctx.lineWidth = 1.5; ctx.stroke();
      drawSystemIcon(ctx, sys.type, ix, iy, 18, broken ? '#884444' : running ? '#ffb080' : '#7a90a8');
      // Their reactor running hot (update92): from 80%, in its colour.
      /* Their core's temperature under the icon, always (update97) —
         in degrees, like ours; it turns hot colours from the warn line. */
      if (sys.type === 'reactor') {
        const h = ship.reactorHeat ?? 0;
        const warn = (typeof REACTOR_HEAT_CONFIG !== 'undefined') ? REACTOR_HEAT_CONFIG.warnHeat : 70;
        ctx.fillStyle = h >= 90 ? '#ff2d44' : h >= 80 ? '#ff7c20' : h >= warn ? '#ffb020' : '#7a90a8';
        ctx.font = '8px Share Tech Mono, monospace';
        ctx.textAlign = 'center';
        ctx.fillText(`${heatCelsius(h)}°C`, ix, iy + 20);
        if ((ship.reactor?.penalty ?? 0) > 0) {
          ctx.fillStyle = '#cc44ff';
          ctx.fillText(`NEB −${ship.reactor.penalty}`, ix, iy + 29);
        }
      }
      // Their gravity too (update91): only when it is gone — that is the news.
      if (sys.type === 'engines' && ship.zeroG) {
        ctx.fillStyle = '#ff7c20';
        ctx.font = '8px Share Tech Mono, monospace';
        ctx.textAlign = 'center';
        ctx.fillText('0-G', ix, iy + 20);
      }

      ix += colW;
    });
  }

  /** Violet nebula clouds drifting behind the battle */
  function drawNebula(ctx, t) {
    ctx.save();
    for (let i = 0; i < 7; i++) {
      const cx = ((i * 231 + t * 18 * (1 + i * 0.13)) % (_W + 400)) - 200;
      const cy = 90 + ((i * 173) % (_H - 220));
      const r  = 140 + (i % 3) * 70;
      const g  = ctx.createRadialGradient(cx, cy, 0, cx, cy, r);
      g.addColorStop(0, 'rgba(150,60,210,0.10)');
      g.addColorStop(1, 'rgba(150,60,210,0)');
      ctx.fillStyle = g;
      ctx.fillRect(cx - r, cy - r, r * 2, r * 2);
    }
    ctx.restore();
  }

  /** The rocks of an asteroid field drifting behind the battle (update100). */
  function drawAsteroidField(ctx, t) {
    ctx.save();
    for (let i = 0; i < 16; i++) {
      const sp = 10 + (i % 5) * 6;
      const x = ((i * 157 + t * sp) % (_W + 120)) - 60;
      const y = 70 + ((i * 211) % (_H - 160));
      const r = 3 + (i % 4) * 2.5;
      ctx.fillStyle = i % 3 ? 'rgba(122,100,72,0.55)' : 'rgba(160,130,90,0.45)';
      ctx.beginPath();
      ctx.moveTo(x + r, y);
      ctx.lineTo(x + r * 0.4, y + r * 0.9);
      ctx.lineTo(x - r * 0.8, y + r * 0.5);
      ctx.lineTo(x - r, y - r * 0.3);
      ctx.lineTo(x - r * 0.2, y - r);
      ctx.lineTo(x + r * 0.7, y - r * 0.6);
      ctx.closePath(); ctx.fill();
    }
    ctx.restore();
  }

  /** A module's icon colour on the power bars (update90a), ONE rule for
   *  ours and theirs: 'broken' (no working level, or ion-locked) is red,
   *  'running' (any effective power — a cyborg's +1 counts) is orange,
   *  'off' is grey. */
  function moduleIconState(sys) {
    if (sys.workingLevels <= 0 || (sys.ionDamage > 0 && sys.effectivePower() <= 0)) return 'broken';
    return sys.effectivePower() > 0 ? 'running' : 'off';
  }

  function _drawPowerBar(ctx, ship, run) {

    const barY   = _H - 96;
    const iconR  = 20;
    let   ix     = 44;
    // Reactor is excluded — it's the SOURCE (shown as the left column),
    // not a power consumer you can allocate bars to.
    // Weapon modules are grouped at the END of the row, adjacent to
    // each other and to the gun cards on the right.
    const _all    = ship.systems.filter(s => s.maxPower > 0 && s.type !== 'reactor');
    const systems = [..._all.filter(s => s.type !== 'weapons'),
                     ..._all.filter(s => s.type === 'weapons')];

    // No plumbing. The orange rail that snaked from the reactor to every
    // module added nothing but clutter — the pips already say who is
    // drawing power.
    const iconGlyphs = SYSTEM_GLYPHS;

    // ── The reactor sits IN the row, on the same baseline as every
    //    other module: same circle, same pips, same click-to-toggle.
    {
      const r  = ship.reactor;
      const cy = _H - 52;
      const off = !!r.offline;
      const rated = r.ratedPower ?? r.totalPower;
      const free  = r.totalPower - (r.totalPower - ship.availablePower());

      ctx.fillStyle = '#0d1120';
      ctx.beginPath(); ctx.arc(ix, cy, iconR, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = off ? '#663333' : '#ffb020';
      ctx.lineWidth = 2; ctx.stroke();
      drawSystemIcon(ctx, 'reactor', ix, cy, iconR * 1.7, off ? '#884444' : '#ffd780');

      // Pips = capacity. Lit = still unspent, dark = handed out,
      // red = knocked out. Same visual grammar as the modules.
      const pipW = 22, pipH = 9, pipGap = 3;
      /* WHAT EACH PIP IS (update93a), bottom to top:
           the core's own working units — lit while unspent (lift blue
             for the spares a lit lift is drawing, update90);
           a Terra cyborg's unit at the console — always cyan;
           units the NEBULA is holding back — violet, the nebula's colour;
           broken levels — red, and they stay red until a level is
             actually repaired.
         The cyborg's unit used to be folded into `rated`, so the red pip
         turned orange the moment a Terra walked in to repair it — "as if
         it were fixed, and it is not" — and the nebula's units were drawn
         as broken. */
      const capBase = r.capacity ?? rated;
      const dmgN  = r.sys ? Math.min(capBase, r.sys.damagedLevels) : 0;
      const penN  = Math.min(capBase - dmgN, r.penalty ?? 0);
      const own   = Math.max(0, capBase - dmgN - penN);
      const bonus = r.cyborgBonus ?? 0;
      const cap   = capBase + bonus;
      const lifts = off ? 0 : Math.min(free, (ship.liftsPowered?.() ?? 0) * (Ship.LIFT_POWER ?? 1));
      const units = own + bonus;                   // what can be spent, in this order
      for (let p = 0; p < cap; p++) {
        const py      = cy - iconR - 12 - p * (pipH + pipGap);
        const unit    = p < units;
        const cyb     = unit && bonus > 0 && p === units - 1;
        const nebula  = !unit && p < units + penN;
        const damaged = !unit && !nebula;
        /* His unit is spent first in the picture (it is the one that
           came last), so the core's own units read lit for what is left. */
        const ownFree = Math.max(0, free - bonus);
        const lit     = !off && unit && !cyb && p < ownFree;
        const lift    = lit && p >= ownFree - lifts;
        ctx.fillStyle = damaged ? '#cc2233' : nebula ? '#8a3fbf'
                      : cyb ? (off ? '#1f6f63' : '#4dffd8')
                      : lift ? '#4db8ff' : lit ? '#ffb020' : 'rgba(40,44,60,0.9)';
        ctx.fillRect(ix - pipW / 2, py, pipW, pipH);
        ctx.strokeStyle = damaged ? '#ff5566' : nebula ? '#cc44ff' : cyb ? '#0affc8' : '#07080f';
        ctx.lineWidth = 1;
        ctx.strokeRect(ix - pipW / 2, py, pipW, pipH);
      }

      ctx.fillStyle = off ? '#ff5566' : '#7a90a8';
      ctx.font = '9px Share Tech Mono, monospace';
      ctx.fillText(off ? 'SCRAMMED' : 'REACTOR', ix, cy + iconR + 12);
      ctx.fillStyle = off ? '#884444' : '#ffb020';
      ctx.fillText(`${free}/${rated}`, ix, cy + iconR + 23);
      if ((r.penalty ?? 0) > 0) {
        ctx.fillStyle = '#cc44ff';
        ctx.fillText(`NEBULA −${r.penalty}`, ix, cy + iconR + 34);
      }

      /* ── THE HEAT BAR (update92) ─────────────────────────────
         A thin bar to the right of the pips, as tall as the stack, filling
         from the bottom. Colour and pulse say how close the core is to an
         overheat; at 100% the word itself. */
      {
        const H = (typeof REACTOR_HEAT_CONFIG !== 'undefined') ? REACTOR_HEAT_CONFIG : null;
        const heat = Utils.clamp(ship.reactorHeat ?? 0, 0, 100);
        const pipW = 22, pitch = 12;
        const bx = ix + pipW / 2 + 3, bw = 5;
        const bBot = cy - iconR - 12 + 9;
        const bTop = cy - iconR - 12 - (Math.max(1, cap) - 1) * pitch;
        const bh = bBot - bTop;
        const t = (typeof performance !== 'undefined' ? performance.now() : 0) / 1000;
        const crit = H ? H.criticalHeat : 90, warn = H ? H.warnHeat : 70;
        const col = heat >= crit ? '#ff2d44' : heat >= 80 ? '#ff7c20' : heat >= warn ? '#ffb020' : '#4d8fbf';
        const pulse = heat >= crit ? 0.55 + 0.45 * Math.sin(t * 10)
                    : heat >= 80   ? 0.7 + 0.3 * Math.sin(t * 6)
                    : heat >= warn ? 0.85 + 0.15 * Math.sin(t * 3) : 1;
        ctx.fillStyle = 'rgba(20,24,36,0.95)';
        ctx.fillRect(bx, bTop, bw, bh);
        ctx.globalAlpha = pulse;
        ctx.fillStyle = col;
        const fh = bh * heat / 100;
        ctx.fillRect(bx, bBot - fh, bw, fh);
        ctx.globalAlpha = 1;
        ctx.strokeStyle = heat >= warn ? col : '#2a3550';
        ctx.lineWidth = 1;
        ctx.strokeRect(bx + 0.5, bTop + 0.5, bw - 1, bh - 1);
        // The 70 / 90 lines on the bar.
        ctx.fillStyle = 'rgba(255,255,255,0.35)';
        [warn, crit].forEach(v => ctx.fillRect(bx - 1, bBot - bh * v / 100, bw + 2, 1));
        ctx.font = '8px Share Tech Mono, monospace';
        ctx.textAlign = 'left';
        ctx.fillStyle = heat >= warn ? col : '#5f7893';
        ctx.fillText(`${heatCelsius(heat)}°C`, bx - 1, bTop - 3);
        ctx.textAlign = 'center';
        if ((ship._overheatFlashT ?? 0) > 0) {
          ctx.fillStyle = `rgba(255,45,68,${0.6 + 0.4 * Math.sin(t * 14)})`;
          ctx.font = 'bold 10px Share Tech Mono, monospace';
          ctx.textAlign = 'left';
          ctx.fillText('REACTOR OVERHEAT', ix - iconR, bTop - 14);
          ctx.textAlign = 'center';
        }
      }

      _powerClickZones.push({
        x: ix - iconR, y: cy - iconR, w: iconR * 2, h: iconR * 2,
        reactorToggle: true,
      });
      ix += 62;
    }

    systems.forEach(sys => {
      const cy = _H - 52;

      /* THREE STATES, THREE COLOURS (update90a). Red was used for
         "no power" as well as "broken", so a module simply switched off
         looked wrecked; and a module running on a Terra cyborg's +1 with
         no reactor units looked switched off, because the colour asked
         the reactor allocation and not the module's real output.
           broken (no working level) or ion-locked → red
           running (any effective power, a cyborg's counts) → orange
           off → grey */
      const disabled = sys.isDisabled();      // the cloak button below still asks this
      const st = moduleIconState(sys);
      const broken = st === 'broken', running = st === 'running';
      ctx.fillStyle = '#0d1120';
      ctx.beginPath(); ctx.arc(ix, cy, iconR, 0, Math.PI*2); ctx.fill();
      ctx.strokeStyle = broken ? '#663333' : running ? '#ffb020' : '#4a6080';
      ctx.lineWidth = 2;
      ctx.stroke();

      drawSystemIcon(ctx, sys.type, ix, cy, iconR * 1.7,
                     broken ? '#884444' : running ? '#ffd780' : '#7a90a8');

      // ── CLOAK: the module icon IS the activate button (FTL style) ──
      // Ring around the icon = active countdown, then recharge. The
      // seconds sit right under it, so the whole ability lives with the
      // module it belongs to instead of a stray button at the top.
      if (sys.type === 'cloaking') {
        const dur = sys.cloakSecs ? sys.cloakSecs() : (sys.def.cloakDuration ?? 6);
        const cd  = sys.cloakRecharge ? sys.cloakRecharge() : (sys.def.cloakCooldown ?? 22);
        let ringCol = null, ringProg = 0, subLabel = '';
        if (sys.cloakActive) {
          ringCol = '#cc44ff'; ringProg = Utils.clamp(sys.cloakTimer / dur, 0, 1);
          subLabel = `${Math.ceil(sys.cloakTimer)}s`;
        } else if (disabled) {
          subLabel = 'NO PWR';          // dark: its charge is lost (update105)
        } else if (sys.cloakCd > 0) {
          ringCol = '#4a6080'; ringProg = Utils.clamp(1 - sys.cloakCd / cd, 0, 1);
          subLabel = `${Math.ceil(sys.cloakCd)}s`;
        } else {
          ringCol = '#cc44ff'; ringProg = 1; subLabel = 'READY [C]';
        }
        if (ringCol && ringProg > 0) {
          ctx.strokeStyle = ringCol;
          ctx.lineWidth = 3;
          ctx.beginPath();
          ctx.arc(ix, cy, iconR + 4, -Math.PI / 2, -Math.PI / 2 + ringProg * Math.PI * 2);
          ctx.stroke();
        }
        if (sys.cloakActive) {
          ctx.fillStyle = 'rgba(204,68,255,0.18)';
          ctx.beginPath(); ctx.arc(ix, cy, iconR, 0, Math.PI * 2); ctx.fill();
        }
        ctx.fillStyle = sys.cloakActive ? '#cc44ff' : (sys.cloakCd > 0 ? '#4a6080' : (disabled ? '#884444' : '#cc44ff'));
        ctx.font = '8px Share Tech Mono, monospace';
        ctx.fillText(subLabel, ix, cy + iconR + 22);
      }

      // Power pips ABOVE icon (click to add/remove)
      // Damaged levels render as RED squares at the top of the stack.
      const pipW = 22, pipH = 9, pipGap = 3;
      /* THE CYBORG'S UNIT IS ALWAYS HIS COLOUR (update93a). The pips
         used to be "power allocated", so on a FULL module — where his +1
         stands in for a reactor unit — every pip was orange, and on a
         module one short there was an extra cyan one; clicking the top
         pip flipped between the two pictures of the same state. Now the
         stack is what actually runs it: reactor units orange, then his
         unit cyan, whatever the allocation says. */
      const alloc = Math.min(sys.power, sys.workingLevels);
      const fromReactor = sys.reactorDraw(alloc);
      const hisUnit = sys.ionDamage <= 0 && sys.effectivePower() > fromReactor;
      for (let p = 0; p < sys.maxPower; p++) {
        const py       = cy - iconR - 12 - p * (pipH + pipGap);
        const damaged  = p >= sys.maxPower - sys.damagedLevels;   // top slots break first
        const lit      = !damaged && p < fromReactor;
        const cyb      = !damaged && hisUnit && p === fromReactor;
        // ion locks the TOP units it hit, one per bolt (update93c)
        const ion      = sys.ionDamage > 0 && !damaged && p < alloc && p >= alloc - sys.ionDamage;

        ctx.fillStyle = damaged ? '#cc2233'
                      : ion     ? '#4db8ff'
                      : cyb     ? '#4dffd8'
                      : lit     ? '#ffb020'
                      : 'rgba(40,44,60,0.9)';
        ctx.fillRect(ix - pipW/2, py, pipW, pipH);
        ctx.strokeStyle = damaged ? '#ff5566' : cyb ? '#0affc8' : '#07080f';
        ctx.lineWidth = 1;
        ctx.strokeRect(ix - pipW/2, py, pipW, pipH);

        if (!damaged) {
          _powerClickZones.push({
            x: ix - pipW/2 - 2, y: py - 2, w: pipW + 4, h: pipH + 4,
            sysIndex: ship.systems.indexOf(sys), pip: p,
          });
        }
      }

      // System label below icon (weapon modules are numbered)
      let label = sys.label;
      if (sys.type === 'weapons') {
        const wsysArr = systems.filter(s => s.type === 'weapons');
        if (wsysArr.length > 1) label = `WPN ${wsysArr.indexOf(sys) + 1}`;
      }
      ctx.fillStyle = '#7a90a8';
      ctx.font = '9px Share Tech Mono, monospace';
      ctx.fillText(label, ix, cy + iconR + 12);
      /* GRAVITY RIDES ON THE ENGINES (update91) — said under their icon,
         compact: a quiet "GRAV ON", or a pulsing "⚠ ZERO-G". */
      if (sys.type === 'engines' && sys === ship.getSystem('engines')) {
        ctx.font = '8px Share Tech Mono, monospace';
        if (ship.gravityActive) {
          ctx.fillStyle = '#4a8a6a';
          ctx.fillText('GRAV ON', ix, cy + iconR + 22);
        } else {
          const p = 0.6 + 0.4 * Math.sin((typeof performance !== 'undefined' ? performance.now() : 0) * 0.008);
          ctx.fillStyle = `rgba(255,124,32,${p})`;
          ctx.fillText('⚠ ZERO-G', ix, cy + iconR + 22);
        }
      }


      // Status icons just ABOVE the topmost pip (crew manning / fire / no O2)
      {
        const topPipTop = cy - iconR - 12 - (sys.maxPower - 1) * (pipH + pipGap);
        const status = _roomStatus(ship, sys);
        status.forEach((st, si) => {
          _statusIcon(ctx, ix, topPipTop - 10 - si * 14, st);
        });
      }

      // Icon click = toggle whole module on/off (power returns to
      // reactor) — EXCEPT the cloak, whose icon fires the ability
      // (its power is still set with the pips above it).
      _powerClickZones.push({
        x: ix - iconR, y: cy - iconR, w: iconR * 2, h: iconR * 2,
        ...(sys.type === 'cloaking'
          ? { sysActivateIndex: ship.systems.indexOf(sys) }
          : { sysToggleIndex: ship.systems.indexOf(sys) }),
      });

      ix += 62;
    });

    // ── Weapons section (right of systems) ──
    ix += 20;
    ship.weapons.forEach((w, i) => {
      if (!w) return;
      const wy = _H - 84;
      const wcol = weaponStyleColor(w.defKey, w.def.type);
      // The card is as wide as its charge strip needs — a nine-second
      // gun simply gets a wider card than a six-second one.
      // The count comes from the CREW-ADJUSTED time: put a good gunner
      // on a 10s laser and it shows eight boxes and says 8s, instead of
      // ten boxes that mysteriously filled in eight seconds.
      const secs = (typeof w.chargeSeconds === 'function')
        ? w.chargeSeconds()
        : Math.max(1, Math.round(w.def.chargeTime ?? 1));
      const boosted = !!w.chargeBoosted;
      const segW = 9, segGap = 3;
      const ww = Math.max(140, 16 + secs * (segW + segGap));
      const wh = 52;

      // Weapon card
      const armed = w.armed;
      ctx.fillStyle = armed ? 'rgba(26,255,140,0.10)' : 'rgba(13,17,32,0.92)';
      ctx.beginPath(); ctx.roundRect(ix, wy, ww, wh, 4); ctx.fill();
      ctx.strokeStyle = armed ? '#1aff8c' : (w.powered ? wcol : '#3a4455');
      ctx.lineWidth = armed ? 2 : 1;
      ctx.stroke();

      // THE GUN ITSELF, in its own colour — you pick weapons by shape
      // here, not by reading four truncated words.
      drawWeaponIcon(ctx, w.defKey, ix + 6, wy + 5, 40, 16,
                     { dir: 1, powered: w.powered, type: w.def.type });

      /* OUT OF AMMO IS A STATE OF THE GUN, and it belongs on the gun's
         own card (update59). A weapon that eats warheads and has none
         left is charged, powered, manned — and completely inert, which
         is indistinguishable from "ready" unless the card says so. The
         card asks CombatManager, the same voice that refuses the shot,
         so the label and the refusal can never disagree. */
      const dry = (() => {
        // `ship` is the hull this bar belongs to — _drawPowerBar's own
        // argument. `state` is drawHUD's and does not reach in here.
        const a = weaponAmmo(w.def);
        if (!a) return false;
        const hold = ship?.cargo;
        const have = hold ? hold.countOf(a.kind) : (a.kind === 'missiles' ? (run?.missiles ?? 0) : 0);
        return have < a.use;
      })();

      // Number + name + power requirement
      ctx.fillStyle = w.unmanned ? '#ff5566' : dry ? '#ff7c20'
                    : armed ? '#1aff8c' : '#c8d8f0';
      ctx.font = '10px Share Tech Mono, monospace';
      ctx.textAlign = 'left';
      ctx.fillText(w.unmanned ? `${i+1}· NO CREW!`
                 : dry        ? `${i+1}· NO AMMO!`
                              : `${i+1}· ${w.label.slice(0,14)}`,
                   ix + 50, wy + 16);
      ctx.textAlign = 'right';
      ctx.fillStyle = w.powered ? '#ffb020' : '#4a6080';
      ctx.fillText(`⚡${w.powerCost}`, ix + ww - 6, wy + 16);
      ctx.textAlign = 'left';

      // ── Charge in SECONDS, in the gun's colour ──
      const done = (w.powered ? Math.max(0, Math.min(1, w.charge)) : 0) * secs;
      for (let sI = 0; sI < secs; sI++) {
        const sx = ix + 8 + sI * (segW + segGap);
        const full = sI < Math.floor(done);
        const part = !full && sI === Math.floor(done) ? done - Math.floor(done) : 0;
        ctx.fillStyle = 'rgba(6,9,16,0.9)';
        ctx.fillRect(sx, wy + 28, segW, 13);
        if (full || part > 0) {
          ctx.fillStyle = armed ? '#c8ffe0' : wcol;
          ctx.fillRect(sx, wy + 28, full ? segW : Math.max(1, segW * part), 13);
        }
        ctx.strokeStyle = armed ? '#1aff8c' : 'rgba(120,140,170,0.35)';
        ctx.lineWidth = 1;
        ctx.strokeRect(sx + 0.5, wy + 28.5, segW - 1, 12);
      }
      // Green when the gunner is shortening the wait, with the factory
      // figure struck through beside it so the gain is legible.
      ctx.font = '8px Share Tech Mono, monospace';
      ctx.textAlign = 'right';
      ctx.fillStyle = boosted ? '#1aff8c' : '#5f7893';
      ctx.fillText(`${secs}s`, ix + ww - 6, wy + 49);
      if (boosted) {
        const base = `${Math.max(1, Math.round(w.def.chargeTime ?? 1))}s`;
        const sw = ctx.measureText?.(`${secs}s`)?.width ?? 12;
        const bw = ctx.measureText?.(base)?.width ?? 12;
        const bx = ix + ww - 10 - sw;
        ctx.fillStyle = '#4a6080';
        ctx.fillText(base, bx, wy + 49);
        ctx.strokeStyle = '#4a6080'; ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(bx - bw, wy + 46.5); ctx.lineTo(bx, wy + 46.5);
        ctx.stroke();
      }
      ctx.textAlign = 'left';

      // Click zone to select/fire
      _powerClickZones.push({
        x: ix, y: wy, w: ww, h: wh,
        weapon: i,
      });

      // AUTO toggle button under the card
      const abW = 52, abH = 16;
      const abX = ix + ww/2 - abW/2, abY = wy + wh + 3;
      ctx.fillStyle = w.autoFire ? 'rgba(26,255,140,0.25)' : 'rgba(13,17,32,0.9)';
      ctx.beginPath(); ctx.roundRect(abX, abY, abW, abH, 3); ctx.fill();
      ctx.strokeStyle = w.autoFire ? '#1aff8c' : '#3a4455';
      ctx.lineWidth = 1; ctx.stroke();
      ctx.fillStyle = w.autoFire ? '#1aff8c' : '#7a90a8';
      ctx.font = '9px Share Tech Mono, monospace';
      ctx.textAlign = 'center';
      ctx.fillText(w.autoFire ? 'AUTO ON' : 'AUTO OFF', abX + abW/2, abY + 12);

      _powerClickZones.push({
        x: abX, y: abY, w: abW, h: abH,
        weaponAuto: i,
      });

      ix += ww + 12;
    });
  }

  // ── Panel (dark rounded rect) ─────────────────────────

  function _drawPanel(ctx, x, y, w, h) {
    ctx.fillStyle = 'rgba(13,17,32,0.88)';
    ctx.beginPath();
    ctx.roundRect(x, y, w, h, 6);
    ctx.fill();
    ctx.strokeStyle = 'rgba(30,45,74,0.8)';
    ctx.lineWidth   = 1;
    ctx.stroke();
  }

  function _drawLabelBar(ctx, x, y, w, label, val, max, barColor, labelColor) {
    ctx.fillStyle = labelColor ?? '#4db8ff';
    ctx.font      = '11px Share Tech Mono, monospace';
    ctx.textAlign = 'left';
    ctx.fillText(label, x, y + 10);

    const barX = x + 44, bw = w - 50, bh = 8;
    ctx.fillStyle = '#0a1020';
    ctx.fillRect(barX, y + 2, bw, bh);
    ctx.fillStyle = barColor;
    ctx.fillRect(barX, y + 2, bw * Utils.clamp(val / max, 0, 1), bh);
    ctx.strokeStyle = '#1e2d4a';
    ctx.lineWidth   = 0.5;
    ctx.strokeRect(barX, y + 2, bw, bh);

    // Value text
    ctx.fillStyle = '#c8d8f0';
    ctx.fillText(`${Math.ceil(val)}/${max}`, barX + bw + 4, y + 10);
  }

  function _drawShieldBars(ctx, x, y, bars, max) {
    ctx.fillStyle = '#4a6080';
    ctx.font      = '11px Share Tech Mono, monospace';
    ctx.textAlign = 'left';
    ctx.fillText('SHIELDS', x, y + 9);

    for (let i = 0; i < max; i++) {
      const lit = i < bars;
      ctx.fillStyle = lit ? '#4db8ff' : '#0a1828';
      ctx.beginPath();
      ctx.arc(x + 55 + i * 18, y + 5, 6, 0, Math.PI * 2);
      ctx.fill();
      if (lit) {
        ctx.strokeStyle = '#1a8cff';
        ctx.lineWidth   = 1;
        ctx.stroke();
      }
    }
  }

  // ── Main menu screen ─────────────────────────────────────

  function drawMainMenu(hoverBtn) {
    clear();
    drawBackground(Date.now() * 0.015);

    const ctx = _ctx;
    const cx  = _W / 2, cy = _H / 2;

    // Logo
    ctx.save();
    ctx.shadowBlur  = 24;
    ctx.shadowColor = '#1a8cff';
    ctx.fillStyle   = '#4db8ff';
    ctx.font        = '72px Orbitron, monospace';
    ctx.textAlign   = 'center';
    ctx.fillText('MOON WARS', cx, cy - 140);
    ctx.restore();

    // Subtitle
    ctx.fillStyle = '#4a6080';
    ctx.font      = '11px Share Tech Mono, monospace';
    ctx.textAlign = 'center';
    ctx.fillText('A TACTICAL SPACE SURVIVAL GAME', cx, cy - 108);

    // Buttons
    /* TWO DOORS (update57). CONTINUE moved into the base — see the note
       on MENU_ITEMS in game.js. The ids and the order here must match
       MENU_ITEMS, because game.js dispatches on the INDEX. */
    const buttons = [
      { id: 'new_game',  label: 'ENTER BASE' },
      { id: 'settings',  label: 'SETTINGS' },
    ];

    buttons.forEach((b, i) => {
      const bx = cx - 100, by = cy - 40 + i * 50, bw = 200, bh = 36;
      const hover = hoverBtn === b.id;

      ctx.fillStyle = hover ? 'rgba(26,140,255,0.25)' : 'rgba(13,17,32,0.85)';
      ctx.beginPath(); ctx.roundRect(bx, by, bw, bh, 4); ctx.fill();

      ctx.strokeStyle = hover ? '#4db8ff' : '#1e2d4a';
      ctx.lineWidth   = hover ? 1.5 : 1;
      ctx.stroke();

      ctx.fillStyle = hover ? '#4db8ff' : '#c8d8f0';
      ctx.font      = '14px Orbitron, monospace';
      ctx.textAlign = 'center';
      ctx.fillText(b.label, cx, by + 24);

      // Click regions registered by game.js _registerMenuButtons()
    });

    // Version
    ctx.fillStyle = '#1a2a3a';
    ctx.font      = '11px Share Tech Mono, monospace';
    ctx.textAlign = 'right';
    ctx.fillText('v0.1.0 — MOON WARS', _W - 10, _H - 10);
  }

  const _menuCallbacks = {};
  function onMenuButton(id, cb) { _menuCallbacks[id] = cb; }

  // ── Map screen ───────────────────────────────────────────

  /* The map screen is handed the ship's hold so the ore readout can be
     read off the cells rather than off a mirrored number (update58).
     Optional, so an old call site still draws. */
  let _mapHold = null;
  function drawMapScreen(sectorMap, hoverNodeId = null, hold = null) {
    _mapHold = hold;
    clear();
    drawBackground(0);

    const ctx = _ctx;
    const ox  = (_W - 700) / 2;   // centered — ship view is separate
    const oy0 = (_H - 400) / 2;
    const oy  = (_H - 400) / 2;

    // Background panel
    _drawPanel(ctx, ox - 20, oy - 40, 740, 480);

    // Title
    ctx.fillStyle = '#c8d8f0';
    ctx.font      = '14px Orbitron, monospace';
    ctx.textAlign = 'left';
    /* THE MOON'S NAME ABOVE THE SECTOR (update56). One region exists,
       and saying so is the point: a player who reads "LUNA · SECTOR 2"
       knows there is somewhere else to be, which is what the Moon Gate
       is for. Reads Save's region table — no second copy of the name. */
    const regionLabel = (typeof Save !== 'undefined' && Save.currentRegion)
      ? (Save.currentRegion()?.label ?? '') : '';
    ctx.fillText(regionLabel ? `${regionLabel} · SECTOR ${sectorMap.sector} MAP`
                             : `SECTOR ${sectorMap.sector} MAP`, ox - 10, oy - 18);
    /* Say WHY the map is half empty, so a player who has not found a
       probe yet does not read the fog as a rendering bug. One WORD up
       here — the CC and He2 readouts own the rest of this line — and
       the explanation goes in the empty space at the foot of the panel. */
    ctx.font      = '10px Share Tech Mono, monospace';
    ctx.fillStyle = sectorMap.revealed ? '#4dffd0' : '#5f7893';
    ctx.fillText(sectorMap.revealed ? '● SURVEYED' : '◌ UNSURVEYED', ox + 188, oy - 18);

    const run = Save.getRun();
    if (run) {
      ctx.font      = '13px Share Tech Mono, monospace';
      ctx.textAlign = 'right';
      ctx.fillStyle = run.fuel <= 2 ? '#ff2d44' : '#ff5566';
      ctx.fillText(`He2 ${run.fuel}`, ox + 450, oy - 18);   // mirrors the cells
      ctx.fillStyle = '#1aff8c';
      ctx.fillText(`${run.scrap} CC`, ox + 360, oy - 18);
      // The ore rides here too — the map is where the player decides
      // whether a detour for salvage is worth it (update58).
      {
        const hold = Save.getRun && _mapHold;
        const ore = _mapHold?.countOfTag ? _mapHold.countOfTag('he3') : 0;
        const oreCol = ore > 0 ? '#cfe4ff' : '#3d4a63';
        ctx.fillStyle = oreCol;
        ctx.fillText(`He3 ${ore}`, ox + 540, oy - 18);
        ctx.textAlign = 'left';
        drawStatIcon(ctx, 'ore', ox + 544, oy - 27, 11, oreCol);
      }
      ctx.textAlign = 'left';
    }

    sectorMap.draw(ctx, ox, oy);

    if (sectorMap && sectorMap.awaitingStartPick) {
      ctx.fillStyle = 'rgba(13,17,32,0.92)';
      /* INSIDE THE PANEL (update104): above it, the objective line now
         sits under the commander bar where this banner was. Between the
         title row and the first nodes there is a free band for it. */
      ctx.beginPath(); ctx.roundRect(_W/2 - 190, oy0 - 6, 380, 26, 5); ctx.fill();
      ctx.strokeStyle = '#1aff8c'; ctx.lineWidth = 1; ctx.stroke();
      ctx.fillStyle = '#1aff8c';
      ctx.font = '12px Share Tech Mono, monospace';
      ctx.textAlign = 'center';
      ctx.fillText('⟨ CHOOSE YOUR STARTING LANE — TOP · MIDDLE · BOTTOM ⟩',
                   _W/2, oy0 + 11);
    }

    if (!sectorMap.revealed) {
      ctx.font      = '11px Share Tech Mono, monospace';
      ctx.fillStyle = '#4a6080';
      ctx.textAlign = 'center';
      ctx.fillText('Sensors reach one jump ahead. Burn a Survey Probe from the hold '
                 + 'to resolve the whole sector.', ox + 350, oy + 412);
      ctx.textAlign = 'left';
    }

    // Hover tooltip
    if (hoverNodeId) {
      const node = sectorMap.getNode(hoverNodeId);
      if (node && !node.locked && sectorMap.visibilityOf?.(node) === 'known') {
        const tx = node.x + ox + 24, ty = node.y + oy - 24;
        _drawPanel(ctx, tx, ty, 120, 48);
        ctx.fillStyle = node.color;
        ctx.font      = '14px Orbitron, monospace';
        ctx.textAlign = 'left';
        ctx.fillText(node.label, tx + 8, ty + 16);
        ctx.fillStyle = '#4a6080';
        ctx.font      = '11px Share Tech Mono, monospace';
        ctx.fillText('Click to travel', tx + 8, ty + 32);
      }
    }
  }

  // ── Combat screen layout ─────────────────────────────────

  function drawCombatLayout(playerShip, enemyShip) {
    // Both ships are drawn by their own draw() method;
    // this just handles the "combat arena" background line

    const ctx = _ctx;
    ctx.strokeStyle = 'rgba(30,45,70,0.3)';
    ctx.lineWidth   = 1;
    ctx.setLineDash([6, 6]);
    ctx.beginPath();
    ctx.moveTo(_W / 2, 20);
    ctx.lineTo(_W / 2, _H - 20);
    ctx.stroke();
    ctx.setLineDash([]);
  }

  // ── Retreat progress ─────────────────────────────────────

  function drawRetreatBar(progress) {
    const w  = 200, h = 20;
    const x  = _W / 2 - w / 2, y = _H - 50;
    _drawPanel(_ctx, x - 4, y - 4, w + 8, h + 8);
    _ctx.fillStyle = '#ff7c20';
    _ctx.fillRect(x, y, w * progress, h);
    _ctx.fillStyle = '#c8d8f0';
    _ctx.font      = '12px Share Tech Mono, monospace';
    _ctx.textAlign = 'center';
    _ctx.fillText('RETREATING…', _W / 2, y + 14);
  }

  // ── Event popup ──────────────────────────────────────────

  function drawEventPopup(event, hoverChoice = -1) {
    const ctx = _ctx;
    const W   = 480, H = 240;
    const x   = _W/2 - W/2, y = _H/2 - H/2;

    _drawPanel(ctx, x, y, W, H);

    ctx.fillStyle = '#4db8ff';
    ctx.font      = '15px Orbitron, monospace';
    ctx.textAlign = 'left';
    ctx.fillText(event.title, x + 20, y + 30);

    ctx.fillStyle = '#c8d8f0';
    ctx.font      = '12px Share Tech Mono, monospace';
    // Word-wrap text (simple)
    const words  = event.text.split(' ');
    let line     = '', cy2 = y + 55;
    words.forEach(w => {
      const test = line + w + ' ';
      if (ctx.measureText(test).width > W - 40) {
        ctx.fillText(line, x + 20, cy2); cy2 += 14; line = w + ' ';
      } else { line = test; }
    });
    if (line) { ctx.fillText(line, x + 20, cy2); }

    // Choices
    event.choices.forEach((c, i) => {
      const bx = x + 20, by = y + 150 + i * 36, bw = W - 40, bh = 28;
      const hover = hoverChoice === i;

      ctx.fillStyle = hover ? 'rgba(26,140,255,0.3)' : 'rgba(20,30,50,0.8)';
      ctx.beginPath(); ctx.roundRect(bx, by, bw, bh, 4); ctx.fill();
      ctx.strokeStyle = hover ? '#4db8ff' : '#1e2d4a';
      ctx.lineWidth   = 1;
      ctx.stroke();

      ctx.fillStyle = hover ? '#4db8ff' : '#c8d8f0';
      ctx.font      = '12px Share Tech Mono, monospace';
      ctx.textAlign = 'left';
      ctx.fillText(c.label, bx + 10, by + 18);

      /* ── WHAT IT COSTS HIM, BEFORE HE CLICKS (update50) ────
         The spec is explicit: show the karma change AND the chips it
         will switch off BEFORE the choice, not in a notification
         afterwards. A moral decision the player only understands in
         hindsight is not a decision. */
      const km = c.result?.karma;
      const cap = (typeof Commander !== 'undefined' && Commander.active)
        ? Commander.active() : null;
      if (km && cap) {
        const pv = Commander.preview ? Commander.preview(cap, km) : null;
        const bits = [`KARMA ${km > 0 ? '+' : ''}${km}`];
        if (pv?.killed) bits.push(`${pv.killed} tablet(s) go dark`);
        else if (pv?.wallMoved) bits.push('blokada tabliczek przeznaczenia się przesunie');
        ctx.textAlign = 'right';
        ctx.fillStyle = km > 0 ? '#1aff8c' : '#ff5566';
        ctx.font = '10px Share Tech Mono, monospace';
        ctx.fillText(bits.join(' · '), bx + bw - 10, by + 18);
        ctx.textAlign = 'left';
      }

      // Click regions registered by game.js _registerEventChoices()
    });
  }

  const _eventCallbacks = {};
  function onEventChoice(idx, cb) { _eventCallbacks[idx] = cb; }

  // ── Victory / defeat splash ───────────────────────────────

  /** Mini blueprint of a hull, drawn from its REAL room layout.
   *  Used by the hangar, the shipyard and anywhere else the player is
   *  choosing between ships — a wall of text does not tell you that a
   *  hull has three free bays, but a picture does.
   *  @param {string} layoutKey  key into SHIP_LAYOUTS
   *  @param {object} opts       { rooms: [{id,type}] } to override the
   *                             stock layout with a ship's real state */
  /** ONE glyph table for the whole game: power bar, thumbnails, panels. */
  const SYSTEM_GLYPHS = {
    shields: '◙', weapons: '▲', engines: '≋', reactor: '⌁',
    oxygen: 'O₂', medbay: '+', piloting: '◎', artillery: '✦',
    cloaking: '◈', autorepair: '⚙', empty: '·',
    /* The brig had no glyph and drew '?' — on the power bar, on the
       thumbnails, and now on the mark strip. A module that cannot say
       what it is is worse than one that is not drawn at all. */
    carbonite: '▣',
  };

  function systemGlyph(type) { return SYSTEM_GLYPHS[type] ?? '?'; }

  /**
   * ONE MODULE ICON, EVERYWHERE (update88).
   *
   * The player: "wszędzie muszą być jednolite ikony reprezentujące dany
   * moduł". There were two: a drawn picture in the middle of the room
   * (hidden as soon as somebody stood on it) and a text glyph in its
   * corner, on the power bar and on the crew marks. Now there is one
   * call. It draws the module's ART when the file is there (the art/
   * PNGs — white, so they tint to the same colour the glyph would have
   * had) and the glyph when it is not, centred on (cx, cy).
   */
  const _tinted = new Map();
  function drawSystemIcon(ctx, type, cx, cy, size, col = '#c8e8ff', alpha = 1) {
    const key = SYSTEM_DEFS?.[systemType ? systemType(type) : type]?.icon ?? `icon_${type}`;
    const art = (typeof Assets !== 'undefined' && Assets.source?.(key) === 'file') ? Assets.get(key) : null;
    const prev = ctx.globalAlpha;
    ctx.globalAlpha = prev * alpha;
    if (art && typeof document !== 'undefined' && document.createElement) {
      const tk = key + '|' + col;
      let img = _tinted.get(tk);
      if (!img) {
        img = document.createElement('canvas');
        img.width = art.width || 64; img.height = art.height || 64;
        const g = img.getContext('2d');
        if (g) {
          g.drawImage(art, 0, 0, img.width, img.height);
          g.globalCompositeOperation = 'source-in';
          g.fillStyle = col;
          g.fillRect(0, 0, img.width, img.height);
        }
        _tinted.set(tk, img);
      }
      ctx.drawImage(img, cx - size / 2, cy - size / 2, size, size);
    } else {
      ctx.fillStyle = col;
      ctx.font = `${Math.round(size * 0.72)}px Share Tech Mono, monospace`;
      ctx.textAlign = 'center';
      ctx.fillText(systemGlyph(type), cx, cy + size * 0.26);
    }
    ctx.globalAlpha = prev;
    /* The glyph used to leave the text alignment CENTRED behind it, and
       the power bar's labels under the icons were written relying on
       that. Left as it was found by the art path, they slid half a word
       to the right — the first screenshot of this package. Centred, as
       before, on both paths. */
    ctx.textAlign = 'center';
  }

  /* ── Weapon graphics ──────────────────────────────────────
     One drawing routine for every gun in the game, so a Burst Laser
     looks like a Burst Laser on the hull, in the shop, in the armoury
     and on a crate. Everything is drawn into a w x h box pointing
     RIGHT by default; pass dir:-1 to face left. */

  const WEAPON_COLORS = {
    laser:   '#4db8ff',
    missile: '#ffb347',
    ion:     '#8a7dff',
    cannon:  '#ff7c20',
    flak:    '#ffd780',
    beam:    '#ff5566',
  };

  function weaponColor(type) { return WEAPON_COLORS[type] || '#4db8ff'; }

  /**
   * Every gun in the game gets its OWN silhouette — not one per damage
   * type. A Burst Laser has three short emitters, a Heavy Laser one fat
   * one; you can tell them apart on the hull without reading a label.
   * `key` is the WEAPON_DEFS key; a bare type still works as a fallback.
   */
  const WEAPON_STYLE = {
    laser_basic:   { col: '#ff5566', form: 'rail',    barrels: 1 },
    laser_burst:   { col: '#ff7a88', form: 'rail',    barrels: 3 },
    laser_heavy:   { col: '#ff3344', form: 'heavy',   barrels: 1 },
    missile_basic: { col: '#ffb347', form: 'pods',    barrels: 2 },
    ion_basic:     { col: '#8a7dff', form: 'coil',    barrels: 1 },
    cannon_basic:  { col: '#ff7c20', form: 'howitzer',barrels: 1 },
    flak_basic:    { col: '#ffd780', form: 'drum',    barrels: 4 },
    torpedo_launcher: { col: '#4dd8c0', form: 'howitzer', barrels: 1 },
    beam_basic:    { col: '#ff2d6a', form: 'emitter', barrels: 1 },
  };

  /** Just the colour a given gun should wear. */
  function weaponStyleColor(key, type) { return weaponStyle(key, type).col; }

  function weaponStyle(key, type) {
    return WEAPON_STYLE[key]
        || WEAPON_STYLE[Object.keys(WEAPON_STYLE).find(k => k.startsWith(type + '_'))]
        || { col: weaponColor(type), form: 'rail', barrels: 1 };
  }

  function drawWeaponIcon(ctx, key, x, y, w, h, opts = {}) {
    const type = opts.type
      || (typeof WEAPON_DEFS !== 'undefined' && WEAPON_DEFS[key]?.type)
      || key;
    const st   = weaponStyle(key, type);
    const { dir = 1, powered = true, dim = false } = opts;
    const col  = dim ? '#4a5568' : st.col;
    const body = dim ? '#161d2b' : 'rgba(20,30,50,0.95)';

    ctx.save();
    ctx.translate(x + (dir < 0 ? w : 0), y);
    ctx.scale(dir < 0 ? -1 : 1, 1);

    const midY = h / 2;
    const hb   = Math.max(4, h * 0.55);
    const bx   = w * 0.50;

    // Housing — shaped by the family, so even the base reads differently.
    ctx.fillStyle = body;
    ctx.beginPath();
    if (st.form === 'howitzer')      ctx.roundRect(0, midY - hb * 0.75, w * 0.50, hb * 1.5, 3);
    else if (st.form === 'emitter')  ctx.roundRect(0, midY - hb * 0.45, w * 0.50, hb * 0.9, 6);
    else if (st.form === 'pods')     ctx.roundRect(0, midY - hb * 0.65, w * 0.48, hb * 1.3, 1);
    else                             ctx.roundRect(0, midY - hb / 2, w * 0.50, hb, 2);
    ctx.fill();
    ctx.strokeStyle = col; ctx.lineWidth = 1; ctx.stroke();

    ctx.fillStyle = dim ? '#232c3d' : '#2a3a55';
    ctx.fillRect(w * 0.10, midY + hb * 0.62, w * 0.20, Math.max(2, h * 0.14));

    ctx.fillStyle = col;
    ctx.strokeStyle = col;

    switch (st.form) {
      case 'pods': {                    // missile launcher: stacked tubes
        for (let i = 0; i < st.barrels; i++) {
          const oy = midY + (i - (st.barrels - 1) / 2) * (hb * 0.62);
          ctx.fillRect(bx, oy - hb * 0.20, w * 0.42, hb * 0.40);
          ctx.fillStyle = dim ? '#2a3346' : '#07080f';
          ctx.fillRect(bx + w * 0.36, oy - hb * 0.20, w * 0.06, hb * 0.40);
          ctx.fillStyle = col;
        }
        break;
      }
      case 'drum': {                    // flak: short barrels round a drum
        ctx.beginPath();
        ctx.ellipse(bx + w * 0.06, midY, w * 0.07, h * 0.34, 0, 0, Math.PI * 2);
        ctx.fill();
        for (let i = 0; i < st.barrels; i++) {
          const oy = midY + (i - (st.barrels - 1) / 2) * (h * 0.17);
          ctx.fillRect(bx + w * 0.10, oy - 1.2, w * 0.28, 2.4);
        }
        break;
      }
      case 'howitzer': {                // hull cannon: one fat barrel
        ctx.fillRect(bx, midY - h * 0.17, w * 0.34, h * 0.34);
        ctx.fillRect(bx + w * 0.30, midY - h * 0.26, w * 0.12, h * 0.52);
        ctx.fillStyle = dim ? '#2a3346' : '#07080f';
        ctx.fillRect(bx + w * 0.40, midY - h * 0.10, w * 0.03, h * 0.20);
        break;
      }
      case 'coil': {                    // ion: rod through coils
        ctx.fillRect(bx, midY - 1.5, w * 0.44, 3);
        for (let i = 0; i < 4; i++) {
          const cx2 = bx + w * (0.05 + i * 0.11);
          ctx.beginPath();
          ctx.ellipse(cx2, midY, Math.max(1.5, w * 0.022), h * 0.26, 0, 0, Math.PI * 2);
          ctx.stroke();
        }
        break;
      }
      case 'emitter': {                 // beam: focusing dish
        ctx.fillRect(bx, midY - 2, w * 0.22, 4);
        ctx.beginPath();
        ctx.moveTo(bx + w * 0.22, midY - h * 0.34);
        ctx.lineTo(bx + w * 0.48, midY);
        ctx.lineTo(bx + w * 0.22, midY + h * 0.34);
        ctx.closePath();
        ctx.fill();
        ctx.fillStyle = dim ? '#2a3346' : '#fff2f5';
        ctx.beginPath();
        ctx.arc(bx + w * 0.30, midY, Math.max(1.5, h * 0.09), 0, Math.PI * 2);
        ctx.fill();
        break;
      }
      case 'heavy': {                   // heavy laser: one thick emitter
        ctx.fillRect(bx, midY - h * 0.13, w * 0.40, h * 0.26);
        ctx.fillRect(bx + w * 0.34, midY - h * 0.24, w * 0.08, h * 0.48);
        break;
      }
      default: {                        // rail: 1..3 slim emitters
        const n = st.barrels;
        for (let i = 0; i < n; i++) {
          const oy = midY + (i - (n - 1) / 2) * (h * 0.24);
          ctx.fillRect(bx, oy - 1.5, w * 0.42, 3);
        }
        ctx.fillRect(bx + w * 0.38, midY - h * 0.20, w * 0.06, h * 0.40);
        break;
      }
    }

    if (!powered && !dim) {
      ctx.globalAlpha = 0.45;
      ctx.fillStyle = '#0b0f18';
      ctx.fillRect(0, 0, w, h);
    }
    ctx.restore();
  }

  /** Same icon as a data URL, for the DOM station panels. Cached. */
  const _wIconCache = new Map();
  function weaponIconURL(type, w = 44, h = 18) {
    const key = `${type}_${w}x${h}`;
    if (_wIconCache.has(key)) return _wIconCache.get(key);
    let url = '';
    try {
      const cv = document.createElement('canvas');
      cv.width = w * 2; cv.height = h * 2;
      const c2 = cv.getContext('2d');
      c2.scale(2, 2);
      drawWeaponIcon(c2, type, 1, 1, w - 2, h - 2, {});
      url = cv.toDataURL('image/png');
    } catch (e) { url = ''; }
    _wIconCache.set(key, url);
    return url;
  }

  function drawShipThumb(ctx, layoutKey, x, y, w, h, opts = {}) {
    const L = (typeof SHIP_LAYOUTS !== 'undefined') ? SHIP_LAYOUTS[layoutKey] : null;
    if (!L) return;

    // save/restore — this helper centres its bay labels, and leaking
    // that textAlign threw the CALLER's next line of text half a width
    // to the left (the hangar stats ended up outside the card).
    ctx.save();
    const rooms = L.rooms;
    const minX = Math.min(...rooms.map(r => r.x));
    const minY = Math.min(...rooms.map(r => r.y));
    const maxX = Math.max(...rooms.map(r => r.x + r.w));
    const maxY = Math.max(...rooms.map(r => r.y + r.h));
    const scale = Math.min(w / (maxX - minX), h / (maxY - minY));
    const ox = x + (w - (maxX - minX) * scale) / 2;
    const oy = y + (h - (maxY - minY) * scale) / 2;

    // Room colours echo the power bar so the same module reads the same
    // everywhere in the game.
    const COL = {
      engines:'#1aff8c', weapons:'#ff5566', shields:'#4db8ff', piloting:'#9fdcff',
      oxygen:'#4dd8ff',  medbay:'#3aff6a',  reactor:'#ffb020', cloaking:'#cc44ff',
      autorepair:'#ffd700', artillery:'#ff7c20', empty:'#39445c',
    };
    // Icons, not letter codes: buying a hull you can SEE what is in it
    // without learning that "SHD" means shields.
    const SHORT = {
      engines:'ENG', weapons:'WPN', shields:'SHD', piloting:'PIL', oxygen:'O₂',
      medbay:'MED', reactor:'RCT', cloaking:'CLK', autorepair:'REP', artillery:'ART',
      empty:'—',
    };
    const levels = new Map((opts.levels ?? []).map(l => [l.id, l.level]));

    const override = new Map((opts.rooms ?? []).map(r => [r.id, r.type]));

    rooms.forEach(r => {
      const type = override.get(r.id) ?? r.type;
      const rx = ox + (r.x - minX) * scale;
      const ry = oy + (r.y - minY) * scale;
      const rw = r.w * scale, rh = r.h * scale;
      const col = COL[type] || '#39445c';
      const bare = type === 'empty';

      ctx.fillStyle = bare ? 'rgba(30,38,58,0.5)' : col + '22';
      ctx.fillRect(rx, ry, rw - 1, rh - 1);
      ctx.strokeStyle = bare ? '#39445c' : col + '99';
      ctx.lineWidth = 1;
      if (bare) ctx.setLineDash([3, 3]);
      ctx.strokeRect(rx + 0.5, ry + 0.5, rw - 2, rh - 2);
      ctx.setLineDash([]);

      // The GLYPH always fits; the word only goes in when there is room
      // for it underneath. An empty bay gets a dashed box and nothing else.
      ctx.textAlign = 'center';
      if (!bare) {
        const gs = Utils.clamp(Math.min(rw, rh) * 0.55, 8, 17);
        ctx.fillStyle = col;
        ctx.font = `${gs}px Share Tech Mono, monospace`;
        const wordFits = rw > 30 && rh > 22;
        ctx.fillText(systemGlyph(type), rx + rw / 2,
                     ry + rh / 2 + (wordFits ? -1 : gs * 0.35));
        if (wordFits) {
          ctx.fillStyle = col + 'cc';
          ctx.font = `${Math.max(6, Math.min(8, rw / 5))}px Share Tech Mono, monospace`;
          ctx.fillText(SHORT[type] ?? '?', rx + rw / 2, ry + rh / 2 + 11);
        }
        // Level pips along the bottom edge — how good the module is.
        const lvl = levels.get(r.id);
        if (lvl > 0 && rw > 18) {
          const pw = Math.min(4, (rw - 6) / Math.max(1, lvl) - 1);
          for (let i = 0; i < lvl; i++) {
            ctx.fillStyle = col;
            ctx.fillRect(rx + 3 + i * (pw + 1), ry + rh - 4, pw, 2);
          }
        }
      } else if (rw > 14 && rh > 12) {
        ctx.fillStyle = '#5a6a86';
        ctx.font = `${Math.max(8, Math.min(12, rw / 3))}px Share Tech Mono, monospace`;
        ctx.fillText('+', rx + rw / 2, ry + rh / 2 + 4);
      }
    });

    // Hull outline, so it reads as ONE ship rather than loose boxes
    ctx.strokeStyle = 'rgba(77,184,255,0.35)';
    ctx.lineWidth = 1;
    ctx.strokeRect(ox - 2.5, oy - 2.5, (maxX - minX) * scale + 4, (maxY - minY) * scale + 4);
    ctx.restore();
  }

  function drawOutcome(type, scrap = 0) {
    const ctx = _ctx;
    const cx  = _W / 2;

    ctx.fillStyle = 'rgba(7,8,15,0.75)';
    ctx.fillRect(0, 0, _W, _H);

    const isVictory = type === 'victory';
    ctx.fillStyle = isVictory ? '#1aff8c' : '#ff2d44';
    ctx.font      = '48px Orbitron, monospace';
    ctx.textAlign = 'center';
    ctx.fillText(isVictory ? 'VICTORY' : 'SHIP DESTROYED', cx, _H/2 - 40);

    if (isVictory && scrap > 0) {
      ctx.fillStyle = '#ffd700';
      ctx.font      = '16px Share Tech Mono, monospace';
      ctx.fillText(`+${scrap} CC COLLECTED`, cx, _H/2 + 10);
    }

    ctx.fillStyle = '#4a6080';
    ctx.font      = '12px Share Tech Mono, monospace';
    ctx.fillText('Press [ENTER] to continue', cx, _H/2 + 50);
  }

  /* ── Weapon stat icons ────────────────────────────────────
     ONE definition, TWO renderers.

     The station shop is DOM and the base armoury is canvas, so the same
     little DMG/CHARGE/POWER pictograms had to exist twice. Rather than
     draw them twice and let them drift apart, each icon is a tiny list
     of primitives in a 0..10 box, and there is one interpreter per
     surface. Change the shape once and both surfaces move together. */

  const STAT_ICONS = {
    /* A CUT CRYSTAL OF ORE (update58) — the mineral readout needed a
       pictogram of its own, and this set is where the game's pictograms
       live. Not a canister (that is He2, the fuel) and not a crate: a
       rough hexagonal stone with a facet, so it reads as something dug
       up rather than something poured. */
    ore: [['poly', [5,0, 9.4,3, 8,8.6, 2,8.6, 0.6,3], true],
          ['line', 5, 0, 5, 8.6], ['line', 0.6, 3, 9.4, 3]],
    // A shell bursting on impact.
    dmg: [['poly', [5,0, 6.4,3.6, 10,5, 6.4,6.4, 5,10, 3.6,6.4, 0,5, 3.6,3.6], true]],
    // A stopwatch: dial plus a hand pointing at one o'clock.
    charge: [['circle', 5, 5.4, 4.2, false],
             ['line', 5, 5.4, 5, 2.4], ['line', 5, 5.4, 7.2, 6.4],
             ['line', 3.6, 0.4, 6.4, 0.4]],
    // The mains bolt, the same shape the ⚡ chip always meant.
    power: [['poly', [5.8,0, 1.6,5.6, 4.4,5.6, 3.8,10, 8.4,4.2, 5.4,4.2], true]],
    // Rounds in flight — three tracers, biggest in front.
    shots: [['poly', [10,5, 6.6,3.2, 6.6,6.8], true],
            ['line', 4.6, 5, 1.6, 5], ['line', 3.0, 2.6, 0.6, 2.6],
            ['line', 3.0, 7.4, 0.6, 7.4]],
    // A warhead: cone, body, fins.
    ammo: [['poly', [10,5, 6.4,2.4, 6.4,7.6], true],
           ['rect', 2.2, 3.4, 4.4, 3.2, true],
           ['poly', [2.2,3.4, 0.2,1.4, 0.2,4.0, 2.2,4.0], true],
           ['poly', [2.2,6.6, 0.2,8.6, 0.2,6.0, 2.2,6.0], true]],
    // A shield: flat top, pointed foot.
    shield: [['poly', [5,0.2, 9.4,2.0, 9.4,5.4, 5,9.8, 0.6,5.4, 0.6,2.0], false]],
    // Hull plating: a riveted plate.
    hull: [['rect', 0.6, 1.6, 8.8, 6.8, false],
           ['circle', 2.4, 5, 0.7, true], ['circle', 7.6, 5, 0.7, true]],

    /* ══ WHAT IS HAPPENING TO A CREWMAN (update80) ══════════════
     *
     * These used to exist TWICE, in two languages, in two files. Over
     * a man's head on the deck `crew.js` drew a mess tin out of an
     * ellipse and two lines, and an air bottle out of a rect and a
     * fill; in his row on the roster `renderer.js` printed the text
     * characters `▼` and a biohazard glyph. Two pictures of one fact,
     * and every future change to either meant remembering the other.
     *
     * The player asked for exactly this: "uzyj tych samych co sa nad
     * zalogantami w statku, ta sama ikonka glodu i brak powietrza".
     * One set, drawn by one function, called from both places — and
     * this set already had a canvas renderer AND an SVG renderer, so
     * the shop gets them for free too.
     *
     * Everything is on the same 10 x 10 grid as the rest of the file.
     */
    // An EMPTY mess tin: a rim and a bowl with nothing in it.
    hunger: [['line', 0.5, 3.4, 9.5, 3.4],
             ['poly', [1.6, 3.4, 8.4, 3.4, 7, 9, 3, 9], false],
             ['line', 5, 0.4, 5, 2.8]],
    // The same tin, full. Empty outline / solid fill is the clearest
    // pair of opposites this grid can draw at 14px.
    eating: [['line', 0.5, 3.4, 9.5, 3.4],
             ['poly', [1.6, 3.4, 8.4, 3.4, 7, 9, 3, 9], true],
             ['line', 5, 0.4, 5, 2.8]],
    // A suit bottle with its last inch of air at the bottom.
    air: [['rect', 3, 2.2, 4, 7.2, false],
          ['line', 3.8, 1.2, 6.2, 1.2], ['line', 5, 1.2, 5, 2.2],
          ['rect', 3.6, 7, 2.8, 2, true]],
    /* A HAMMER, not a spanner. The spanner's open jaw came out of the
       icon sheet as a lollipop — a jaw is a shape you cannot draw in
       four units. A solid head on a diagonal handle is the one
       silhouette in this set that is a block on a bar. */
    repair: [['rect', 0.8, 0.8, 5.4, 2.8, true],
             ['line', 3.2, 3.6, 8.8, 9.4]],
    /* A flame with a lick. The first version was a symmetric teardrop
       and the screenshot showed it reading as an orange DIAMOND —
       symmetry is what kills a flame at 14px. This one leans and has
       a notch out of one side, which is what the eye looks for. */
    fire: [['poly', [5.4, 0.2, 6.6, 3.0, 8.2, 4.4, 8.4, 7.0, 6.2, 9.4,
                     3.2, 9.4, 1.6, 7.2, 2.4, 4.6, 4.0, 5.8, 3.6, 2.6], true]],
    /* A CRACK THROUGH THE PLATING. A filled blob inside a frame read
       as "a box with something in it" on the icon sheet, which is the
       opposite of a hole. A zigzag splitting the plate is damage and
       reads as nothing else. */
    breach: [['rect', 0.6, 1.6, 8.8, 6.8, false],
             ['poly', [4.4, 1.6, 5.8, 3.6, 3.8, 5.0, 6.0, 6.4, 4.6, 8.4], false]],
    /* TWO SIDES MEETING. Crossed blades came out of the screenshot as
       a plain red X — which every interface in the world reads as
       "cancel", and it was the loudest thing on the panel because an
       X fills its whole box corner to corner. Two arrowheads closing
       on each other say "clash" and say nothing else. */
    fight: [['poly', [0.6, 1.4, 4.3, 5, 0.6, 8.6], true],
            ['poly', [9.4, 1.4, 5.7, 5, 9.4, 8.6], true]],
    /* A VIRION: solid core, eight spikes. The first try was a trefoil
       of three buds round a ring and the screenshot showed it reading
       as a little stick figure — three big circles at 14px merge into
       limbs. A filled core with radial spikes survives the size,
       because none of it has to be told apart from the rest of it. */
    plague: [['circle', 5, 5, 2.5, true],
             ['line', 5, 2.5, 5, 0.4], ['line', 5, 7.5, 5, 9.6],
             ['line', 2.5, 5, 0.4, 5], ['line', 7.5, 5, 9.6, 5],
             ['line', 3.2, 3.2, 1.7, 1.7], ['line', 6.8, 6.8, 8.3, 8.3],
             ['line', 6.8, 3.2, 8.3, 1.7], ['line', 3.2, 6.8, 1.7, 8.3]],
    // A medical cross — aid given, or aid needed.
    medical: [['rect', 4, 0.8, 2, 8.4, true], ['rect', 0.8, 4, 8.4, 2, true]],
    // A snowflake: every clock stopped.
    frozen: [['line', 5, 0.4, 5, 9.6], ['line', 1, 2.7, 9, 7.3],
             ['line', 1, 7.3, 9, 2.7],
             ['line', 5, 0.4, 3.4, 2], ['line', 5, 0.4, 6.6, 2]],
    // A chevron: he is not on this hull.
    away: [['poly', [2.6, 0.8, 7.4, 5, 2.6, 9.2], false],
           ['line', 6.2, 0.8, 9.4, 5], ['line', 6.2, 9.2, 9.4, 5]],

    /* ── THREE SKILLS THAT HAD NO PICTURE (update96) ─────────
       Five of the eight skills already had one here (repair, fire,
       breach, shield, fight). These are the other three, and two of
       them are the pair a player confuses — PILOTING vs ENGINES — so
       they are as unlike in silhouette as ten pixels allow: a round
       yoke you hold, against a nozzle with fire coming out of it. */
    // A control yoke: the wheel, its spokes and the column under it.
    sk_pilot: [['circle', 5, 4.4, 3.8, false],
               ['line', 1.2, 4.4, 8.8, 4.4], ['line', 5, 4.4, 5, 9.6]],
    // A gunsight: ring, four ticks, a dot.
    sk_gun: [['circle', 5, 5, 3.4, false], ['circle', 5, 5, 0.9, true],
             ['line', 5, 0.2, 5, 2.2], ['line', 5, 7.8, 5, 9.8],
             ['line', 0.2, 5, 2.2, 5], ['line', 7.8, 5, 9.8, 5]],
    // A drive nozzle, wide end out, and the exhaust behind it.
    sk_engine: [['poly', [0.4, 2.6, 5.2, 3.8, 5.2, 6.2, 0.4, 7.4], true],
                ['line', 6.4, 5, 9.8, 5], ['line', 6.6, 3.2, 9.2, 2.2],
                ['line', 6.6, 6.8, 9.2, 7.8]],
  };

  /** Which icon stands for which skill — one table (update96). */
  const SKILL_ICON = {
    piloting: 'sk_pilot', weapons: 'sk_gun', engines: 'sk_engine',
    repair: 'repair', firefight: 'fire', breach: 'breach',
    shields: 'shield', combat: 'fight',
  };

  /** Paint one stat icon onto a canvas, fitted into `size` pixels. */
  function drawStatIcon(ctx, kind, x, y, size, col) {
    const ops = STAT_ICONS[kind];
    if (!ops) return;
    const s = size / 10;
    ctx.save();
    ctx.translate(x, y);
    ctx.fillStyle = col; ctx.strokeStyle = col;
    ctx.lineWidth = Math.max(1, size / 10);
    ctx.lineJoin = 'round'; ctx.lineCap = 'round';
    ops.forEach(op => {
      const [kindOp] = op;
      if (kindOp === 'poly') {
        const [, pts, fill] = op;
        ctx.beginPath();
        for (let i = 0; i < pts.length; i += 2) {
          const px = pts[i] * s, py = pts[i + 1] * s;
          if (i === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
        }
        ctx.closePath();
        if (fill) ctx.fill(); else ctx.stroke();
      } else if (kindOp === 'circle') {
        const [, cxx, cyy, r, fill] = op;
        ctx.beginPath(); ctx.arc(cxx * s, cyy * s, r * s, 0, Math.PI * 2);
        if (fill) ctx.fill(); else ctx.stroke();
      } else if (kindOp === 'line') {
        const [, x1, y1, x2, y2] = op;
        ctx.beginPath(); ctx.moveTo(x1 * s, y1 * s); ctx.lineTo(x2 * s, y2 * s); ctx.stroke();
      } else if (kindOp === 'rect') {
        const [, rx, ry, rw, rh, fill] = op;
        if (fill) ctx.fillRect(rx * s, ry * s, rw * s, rh * s);
        else ctx.strokeRect(rx * s, ry * s, rw * s, rh * s);
      }
    });
    ctx.restore();
  }

  /** The SAME icon as inline SVG markup, for the DOM station shop. */
  function statIconSVG(kind, col, size = 10) {
    const ops = STAT_ICONS[kind];
    if (!ops) return '';
    const body = ops.map(op => {
      const [k] = op;
      if (k === 'poly') {
        const [, pts, fill] = op;
        const d = [];
        for (let i = 0; i < pts.length; i += 2) d.push(`${pts[i]},${pts[i + 1]}`);
        return `<polygon points="${d.join(' ')}" fill="${fill ? col : 'none'}"` +
               `${fill ? '' : ` stroke="${col}" stroke-width="1"`}/>`;
      }
      if (k === 'circle') {
        const [, cxx, cyy, r, fill] = op;
        return `<circle cx="${cxx}" cy="${cyy}" r="${r}" fill="${fill ? col : 'none'}"` +
               `${fill ? '' : ` stroke="${col}" stroke-width="1"`}/>`;
      }
      if (k === 'line') {
        const [, x1, y1, x2, y2] = op;
        return `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="${col}" ` +
               `stroke-width="1" stroke-linecap="round"/>`;
      }
      const [, rx, ry, rw, rh, fill] = op;
      return `<rect x="${rx}" y="${ry}" width="${rw}" height="${rh}" ` +
             `fill="${fill ? col : 'none'}"${fill ? '' : ` stroke="${col}" stroke-width="1"`}/>`;
    }).join('');
    return `<svg viewBox="0 0 10 10" width="${size}" height="${size}" ` +
           `style="vertical-align:-1px;flex:none">${body}</svg>`;
  }

  /* ══ RANK INSIGNIA (update96, jj's point 14) ════════════════
   *
   * The roster used to carry ONE star, in two colours, for twenty-five
   * ranks: nothing up to Corporal, silver to Lieutenant, gold from
   * Captain. Three looks for twenty-five steps, so a Sergeant and a
   * Lieutenant wore the same thing. Now every rank has its own mark,
   * drawn in code ("rysować w kodzie na razie"), in five families a
   * player learns once:
   *
   *     0–8    enlisted   steel    chevrons, rockers, a specialist's diamond
   *     9–11   warrant    teal     a bar and one to three pips
   *     12–17  officers   gold     bars, then pips
   *     18–22  flag       gold     stars
   *     23–24  lords      gold     a crown; the last one jewelled
   *
   * Each mark is a list of the same primitives the stat icons use, in a
   * 20x10 box (twice as wide as tall — four stars need the room), built
   * once below. The rank NUMBER still comes from `rankLevelOf` and
   * nothing else; this only decides what it looks like.
   */
  const INSIGNIA_TIERS = [
    { from: 0,  to: 8,  key: 'enlisted', col: '#c8d0dc' },
    { from: 9,  to: 11, key: 'warrant',  col: '#4dd8c0' },
    { from: 12, to: 17, key: 'officer',  col: '#e8c25a' },
    { from: 18, to: 22, key: 'flag',     col: '#ffd24a' },
    { from: 23, to: 24, key: 'lord',     col: '#ffd24a' },
  ];
  function insigniaTier(level) {
    const l = Math.max(0, Math.min(24, Math.round(level ?? 0)));
    return INSIGNIA_TIERS.find(t => l >= t.from && l <= t.to);
  }

  const RANK_INSIGNIA = (() => {
    const chev  = y => [['line', 4, y + 2, 10, y], ['line', 10, y, 16, y + 2]];
    const rock  = y => [['line', 4, y, 10, y + 1.6], ['line', 10, y + 1.6, 16, y]];
    const pip   = (x, r = 2.2) => [['circle', x, 5, r, true]];
    const star  = (cx, cy, r) => {
      const pts = [];
      for (let i = 0; i < 10; i++) {
        const a = -Math.PI / 2 + i * Math.PI / 5, rr = i % 2 ? r * 0.45 : r;
        pts.push(+(cx + Math.cos(a) * rr).toFixed(2), +(cy + Math.sin(a) * rr).toFixed(2));
      }
      return [['poly', pts, true]];
    };
    const crown = [['poly', [3, 9, 3, 3, 6.5, 6, 10, 1, 13.5, 6, 17, 3, 17, 9], true]];
    const stack = (n, top, step) => [].concat(...Array.from({ length: n }, (_, i) => chev(top + i * step)));
    const bar   = [['rect', 1.5, 3.5, 7, 3, true]];
    const L = [];
    // ── enlisted ──
    L[0]  = [['rect', 6, 3, 8, 4, false]];                         // Recruit: a blank tab
    L[1]  = stack(1, 4, 0);                                        // Private
    L[2]  = stack(1, 2.4, 0).concat(rock(6.4));                    // PFC
    L[3]  = [['poly', [10, 0.8, 14.2, 5, 10, 9.2, 5.8, 5], true]]; // Specialist
    L[4]  = stack(2, 2.6, 2.6);                                    // Corporal
    L[5]  = stack(2, 1.2, 2.4).concat(rock(6.6));                  // Senior Corporal
    L[6]  = stack(3, 1.4, 2.4);                                    // Sergeant
    L[7]  = stack(3, 0.6, 2.0).concat(rock(7.4));                  // Senior Sergeant
    L[8]  = stack(3, 0.4, 1.8).concat(rock(6.4), rock(8.2));       // Staff Sergeant
    // ── warrant: a bar and its pips ──
    L[9]  = bar.concat(pip(13, 1.5));
    L[10] = bar.concat(pip(12, 1.4), pip(16, 1.4));
    L[11] = bar.concat(pip(11.2, 1.3), pip(14.6, 1.3), pip(18, 1.3));
    // ── officers ──
    L[12] = [['rect', 5, 3, 10, 4, false]];                        // Second Lieutenant: an empty bar
    L[13] = [['rect', 5, 3, 10, 4, true]];                         // Lieutenant
    L[14] = [['rect', 2.5, 3, 6.5, 4, true], ['rect', 11, 3, 6.5, 4, true]];   // Captain
    L[15] = pip(10, 2.6);                                          // Major
    L[16] = pip(7, 2.4).concat(pip(13, 2.4));                      // Lieutenant Colonel
    L[17] = pip(4, 2.2).concat(pip(10, 2.2), pip(16, 2.2));        // Colonel
    // ── flag: stars ──
    L[18] = star(10, 5.4, 4.6);                                    // Commodore
    L[19] = star(6, 5.4, 3.9).concat(star(14, 5.4, 3.9));          // Rear Admiral
    L[20] = [3.6, 10, 16.4].reduce((a, x) => a.concat(star(x, 5.4, 3.1)), []);
    L[21] = [2.6, 7.5, 12.5, 17.4].reduce((a, x) => a.concat(star(x, 5.4, 2.5)), []);
    L[22] = [2.6, 7.5, 12.5, 17.4].reduce((a, x) => a.concat(star(x, 3.6, 2.3)), [])
              .concat([['rect', 1, 7.6, 18, 1.8, true]]);           // Grand Admiral: four over a bar
    // ── lords: the crown ──
    L[23] = crown.slice();                                         // High Lord
    L[24] = crown.concat([['col', '#ff4d6a'],                      // Master Lord: jewelled
                          ['circle', 6.5, 7.2, 1.1, true], ['circle', 10, 6.4, 1.3, true],
                          ['circle', 13.5, 7.2, 1.1, true]]);
    return L;
  })();

  /** The same op painter the stat icons use, for a box `s` px per unit. */
  function _paintOps(ctx, ops, s) {
    ops.forEach(op => {
      const [k] = op;
      if (k === 'col') { ctx.fillStyle = op[1]; ctx.strokeStyle = op[1]; return; }
      if (k === 'poly') {
        const [, pts, fill] = op;
        ctx.beginPath();
        for (let i = 0; i < pts.length; i += 2) {
          if (i === 0) ctx.moveTo(pts[i] * s, pts[i + 1] * s); else ctx.lineTo(pts[i] * s, pts[i + 1] * s);
        }
        ctx.closePath();
        if (fill) ctx.fill(); else ctx.stroke();
      } else if (k === 'circle') {
        const [, cx, cy, r, fill] = op;
        ctx.beginPath(); ctx.arc(cx * s, cy * s, r * s, 0, Math.PI * 2);
        if (fill) ctx.fill(); else ctx.stroke();
      } else if (k === 'line') {
        const [, x1, y1, x2, y2] = op;
        ctx.beginPath(); ctx.moveTo(x1 * s, y1 * s); ctx.lineTo(x2 * s, y2 * s); ctx.stroke();
      } else if (k === 'rect') {
        const [, rx, ry, rw, rh, fill] = op;
        if (fill) ctx.fillRect(rx * s, ry * s, rw * s, rh * s);
        else ctx.strokeRect(rx * s, ry * s, rw * s, rh * s);
      }
    });
  }

  /**
   * Paint a rank's insignia with its top-left at (x, y), `h` pixels
   * tall and twice that wide. Returns the width it took, so a caller
   * laying out a line can carry on after it.
   */
  function drawRankInsignia(ctx, level, x, y, h = 12) {
    const l = Math.max(0, Math.min(24, Math.round(level ?? 0)));
    const ops = RANK_INSIGNIA[l];
    const tier = insigniaTier(l);
    const s = h / 10;
    ctx.save();
    ctx.translate(x, y);
    ctx.fillStyle = tier.col; ctx.strokeStyle = tier.col;
    ctx.lineWidth = Math.max(1, h / 8);
    ctx.lineJoin = 'round'; ctx.lineCap = 'round';
    _paintOps(ctx, ops, s);
    ctx.restore();
    return h * 2;
  }

  /** The skills a man has at 3/3 — what a specialisation IS. */
  function specialtiesOf(rec) {
    if (typeof Commander !== 'undefined' && Commander.masteredOf) return Commander.masteredOf(rec);
    const max = (typeof MAX_SKILL_LEVEL !== 'undefined') ? MAX_SKILL_LEVEL : 3;
    return Object.entries(rec?.skills || {}).filter(([, v]) => (v?.level ?? 0) >= max).map(([k]) => k);
  }

  /**
   * One icon per specialisation, each in its skill's colour, left to
   * right from (x, y). Returns the width it took (0 for none).
   */
  function drawSpecialties(ctx, rec, x, y, size = 10, gap = 3) {
    const keys = Array.isArray(rec) ? rec : specialtiesOf(rec);
    keys.forEach((k, i) => {
      const col = (typeof SKILL_DEFS !== 'undefined' && SKILL_DEFS[k]?.color) || '#c8d8f0';
      drawStatIcon(ctx, SKILL_ICON[k], x + i * (size + gap), y, size, col);
    });
    return keys.length ? keys.length * (size + gap) - gap : 0;
  }

  /** "Sergeant (6) · specialist: Repair, Weapons" — the roster's tooltip. */
  function rankTip(rec) {
    const lvl  = (typeof rankLevelOf !== 'undefined') ? rankLevelOf(rec) : 0;
    const name = (typeof rankName !== 'undefined') ? rankName(lvl) : `rank ${lvl}`;
    const spec = specialtiesOf(rec).map(k => (typeof SKILL_DEFS !== 'undefined' && SKILL_DEFS[k]?.label) || k);
    return `${name} (${lvl})` + (spec.length ? ` · specialist: ${spec.join(', ')}` : ' · no specialisation');
  }

  // ── Public API ───────────────────────────────────────────

  return {
    init, getCtx, getWidth, getHeight, screenInfo, LOGICAL, DESIGN,
    clear,
    drawBackground,
    drawNebula, drawAsteroidField,
    drawHUD, commanderStripRect, drawCommanderDossier, orderRects, commanderBarRects, drawTabletBook, moduleIconState, enemyStripBottom,
    DISEASE_COL,
    bodyMenuRects, drawBodyMenu, setEvaCrew,
    drawPips, PIP_HP,
    crewRoster,
    getPowerClickZones,
    crewMarks, getCrewMarkZones, getRankZones, crewPanelX, leftColumnFloor, enemyHeatBar,
    rosterBox, scrollRoster,
    drawMainMenu,
    drawMapScreen,
    drawCombatLayout,
    drawRetreatBar,
    drawEventPopup,
    drawOutcome,
    drawShipThumb, systemGlyph, drawSystemIcon, runGoalsRect, runGoalsBox,
    drawWeaponIcon, weaponIconURL, weaponColor, weaponStyleColor, weaponStyle,
    drawStatIcon, statIconSVG, STAT_ICONS,
    RANK_INSIGNIA, INSIGNIA_TIERS, insigniaTier, drawRankInsignia,
    SKILL_ICON, specialtiesOf, drawSpecialties, rankTip,
    onMenuButton,
    onEventChoice,
  };

})();
