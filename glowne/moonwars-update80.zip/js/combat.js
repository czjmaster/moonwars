/* ============================================================
   MOON WARS — combat.js
   Battle state machine.
   Manages the combat loop between player and enemy ship:
   enemy AI targeting, auto-fire, boarding, retreat logic.
   ============================================================ */

'use strict';

// ── Combat state ──────────────────────────────────────────

const COMBAT_STATE = {
  IDLE:      'idle',       // no combat
  ENTERING:  'entering',   // ships flying in
  ACTIVE:    'active',     // combat ongoing
  VICTORY:   'victory',    // player won
  DEFEAT:    'defeat',     // player lost
  RETREATING:'retreating', // player is retreating
  ENEMY_FLED:'enemy_fled', // the ENEMY escaped
  FLED:      'fled',       // escaped
};

// ── Enemy AI difficulty levels ────────────────────────────

const AI_DEFS = {
  easy:   { fireDelay: 1.5, targetRandom: 0.6, retreatHull: 0 },
  normal: { fireDelay: 1.0, targetRandom: 0.3, retreatHull: 0 },
  hard:   { fireDelay: 0.7, targetRandom: 0.1, retreatHull: 0 },
  boss:   { fireDelay: 0.5, targetRandom: 0.0, retreatHull: 0 },
};

class Combat {
  constructor() {
    this.state        = COMBAT_STATE.IDLE;
    this.playerShip   = null;
    this.enemyShip    = null;

    // All in-flight projectiles across both ships
    this._projectiles = [];

    // Enemy AI
    this._ai           = AI_DEFS.normal;
    this._aiFireTimers = [];    // one per enemy weapon
    this._aiTargetRoom = null;  // which player room AI is aiming at

    // Retreat
    this._retreatTimer = 0;
    this._retreatCost  = 0;   // fuel cost

    // Enter animation
    this._enterTimer   = 0;
    this._enterDone    = false;

    // Outcome
    this.scrapReward   = 0;
    this.weaponDrop    = null;

    // Timers
    this._stateTimer   = 0;
  }

  // ── Start / stop ─────────────────────────────────────────

  begin(playerShip, enemyShip, difficulty = 'normal') {
    this.state       = COMBAT_STATE.ENTERING;
    this.playerShip  = playerShip;
    this.enemyShip   = enemyShip;
    this._ai         = AI_DEFS[difficulty] || AI_DEFS.normal;
    this._projectiles = [];
    this._enterTimer  = 0;
    this._stateTimer  = 0;

    // A NEW BATTLE, for both hulls: re-lock every door against boarders
    // and put one more action on every living crew member's record.
    // This is the single place every fight passes through exactly once.
    [playerShip, enemyShip].forEach(sh => sh?.onBattleStart?.());

    // Initialise AI fire timers
    this._aiFireTimers = enemyShip.weapons.map(() => 0);

    /* Surrender machinery (rebuilt update62).
       `_hullRolled` is the ONE hull roll; `_surrenderMade` is whether a
       decision was actually put to the player. They are separate on
       purpose: a hull roll that comes up short must not stop a crew
       that is later beaten off its feet from striking. */
    this._hullRolled       = false;
    this._surrenderMade    = false;
    this.surrenderOffer    = false;
    // Their hull is intact and nobody has been told otherwise yet.
    this.enemyDown        = false;
    this._boardersNotice  = false;

    // Escape machinery
    this.RETREAT_TIME       = 9.0;   // player jump spool-up
    this._escapeRolled      = false;
    this.enemyEscapeActive  = false;
    this._enemyEscapeT      = 0;
    this.ENEMY_ESCAPE_TIME  = 11.0;
    this._escapeNotice      = false; // one-shot flag for the game layer

    // Random scrap reward
    const sector = Save.getRun()?.sector ?? 1;
    this.scrapReward = Utils.randInt(10 + sector * 5, 30 + sector * 10);
    this.weaponDrop  = Math.random() < 0.25 ? randomWeaponDrop(sector) : null;

    Audio.playMusic('combat');
  }

  end() {
    this._projectiles = [];
    this.state        = COMBAT_STATE.IDLE;
    this.playerShip   = null;
    this.enemyShip    = null;
    Audio.stopMusic(1.5);
  }

  initiateRetreat(fuelCost = 1) {
    if (this.state !== COMBAT_STATE.ACTIVE) return false;
    this.state         = COMBAT_STATE.RETREATING;
    this._retreatTimer = 0;
    this._retreatTimer = 0;
    this._retreatCost  = fuelCost;
    return true;
  }

  // ── Update ───────────────────────────────────────────────

  update(dt) {
    if (this.state === COMBAT_STATE.IDLE) return;

    this._stateTimer += dt;

    switch (this.state) {
      case COMBAT_STATE.ENTERING:   this._updateEntering(dt);   break;
      case COMBAT_STATE.ACTIVE:     this._updateActive(dt);     break;
      case COMBAT_STATE.RETREATING: this._updateRetreating(dt); break;
      case COMBAT_STATE.VICTORY:
      case COMBAT_STATE.DEFEAT:     /* handled by Game */        break;
    }

    // Always update projectiles
    this._updateProjectiles(dt);
  }

  _updateEntering(dt) {
    this._enterTimer += dt;
    if (this._enterTimer >= 1.5) {
      this.state = COMBAT_STATE.ACTIVE;
    }
  }

  _updateActive(dt) {
    if (!this.playerShip || !this.enemyShip) return;

    // Check win/lose. Hull gone = defeat outright. "No crew aboard"
    // is NOT decided here — the player may have sent everyone on a
    // boarding action; game.js owns that check because it can see the
    // boarding party and crew fighting on the enemy hull.
    if (this.playerShip.hull <= 0 || this.playerShip.destroyed) {
      this.state = COMBAT_STATE.DEFEAT;
      Audio.playMusic('explore');
      return;
    }
    /* THE HULL IS NOT THE BATTLE (update54).
     *
     * Victory used to be declared the instant the enemy hull reached
     * zero — while their boarding party was still swinging axes in our
     * medbay. The fight ended, the loot screen came up, and the men on
     * our deck were tidied away by the machinery rather than beaten.
     * A player who REFUSES a surrender and then blows the ship apart
     * had, in effect, won by pressing the button they were already
     * pressing.
     *
     * So: the ship dies when its hull dies — it explodes, it stops
     * shooting, there is nothing left to shoot back at — but the
     * BATTLE ends only once nobody of theirs is left standing on our
     * deck. Two separate facts, and the second one is the one the
     * victory screen waits on.
     */
    if (this.enemyShip.hull <= 0 || this.enemyShip.destroyed) {
      if (!this.enemyDown) {
        this.enemyDown = true;
        this.enemyShip.destroyed = true;
        Particles.explosion(
          this.enemyShip.worldX + this.enemyShip.spriteW / 2,
          this.enemyShip.worldY + this.enemyShip.spriteH / 2,
          2.0
        );
        Audio.sfx.explosion();
        Camera.shake(16, 0.6);
      }
      if (!this.intrudersAboard()) {
        this._onVictory();
        return;
      }
      if (!this._boardersNotice && typeof UI !== 'undefined') {
        this._boardersNotice = true;
        UI.notify('Their ship is gone — but their boarders are still aboard. Clear the decks!', 'alert');
      }
      /* A wreck does not aim. Everything below this line is the enemy
         SHIP acting, and it has stopped being a ship. */
      return;
    }

    /* ── BEATEN, TWO WAYS, ONE DECISION (update62) ──────────
     *
     * A ship is beaten when its HULL is nearly gone, or when nobody
     * aboard it can still fight. The second one used to lead nowhere:
     * you could kill every hand on their deck and be offered nothing,
     * because the only trigger in the game read the hull. That is the
     * hole a boarding party fell into — clearing their decks was just
     * a slower gun.
     *
     * Both roads end at `_raiseSurrender`, so there is exactly one
     * place that decides a surrender is on the table, one flag the
     * game layer reads, and no way for the two to disagree.
     */
    if (!this._surrenderMade && !this._hullRolled &&
        this._ai !== AI_DEFS.boss &&
        this.enemyShip.hull <= this.enemyShip.hullMax * 0.3) {
      this._hullRolled = true;
      if (this.noQuarter()) {
        /* NO QUARTER, AND HE IS TOLD WHY (update62). An offer that
           silently never comes is indistinguishable from a broken
           game, so the reason is said out loud, once, at the moment
           they would have struck. */
        if (typeof UI !== 'undefined') {
          UI.notify('They will not surrender to you. They know what you do to prisoners.', 'alert');
        }
      } else if (Math.random() < this.surrenderOdds()) {
        this._raiseSurrender();
      }
    }

    // …or try to RUN: needs their cockpit + engines alive. Rolled once
    // at ≤45% hull; never the boss, never while offering surrender.
    if (!this._escapeRolled &&
        this.enemyShip.hull <= this.enemyShip.hullMax * 0.45) {
      this._escapeRolled = true;
      if (this._ai !== AI_DEFS.boss && !this.surrenderOffer && Math.random() < 0.45) {
        this.enemyEscapeActive = true;
        this._enemyEscapeT     = 0;
        this._escapeNotice     = true;
      }
    }
    if (this.enemyEscapeActive) {
      const ep = this.enemyShip.getSystem('piloting');
      const ee = this.enemyShip.getSystem('engines');
      const eok = ep && ee && !ep.isDisabled() && !ee.isDisabled();
      if (!eok) {
        // Max-damaged drive = their charge resets; repairs restart it
        this._enemyEscapeT = 0;
      } else {
        this._enemyEscapeT += dt;
        if (this._enemyEscapeT >= this.ENEMY_ESCAPE_TIME) {
          this.state = COMBAT_STATE.ENEMY_FLED;
          return;
        }
      }
    }

    // Enemy AI
    this._updateAI(dt);
  }

  _updateRetreating(dt) {
    // Escape needs a WORKING cockpit and engines the whole time.
    // Knock-out of either resets the charge — repair and start over.
    const pil = this.playerShip.getSystem('piloting');
    const eng = this.playerShip.getSystem('engines');
    const ok  = pil && eng && !pil.isDisabled() && !eng.isDisabled() &&
                pil.effectivePower() > 0 && eng.effectivePower() > 0;
    if (!ok) {
      if (this._retreatTimer > 0 && typeof UI !== 'undefined') {
        UI.notify('Jump charge LOST — drive systems down!', 'alert');
      }
      this._retreatTimer = 0;
    } else {
      /* FLANK SPEED spools the jump at double time (update53). It
         goes through Commander.orderBonus like every other running
         order, so there is no second place a jump can be hurried
         from — and the bonus is 0 whenever nothing is running. */
      const flank = (typeof Commander !== 'undefined' && Commander.orderBonus)
        ? (Commander.orderBonus('jump') > 0 ? 2 : 1) : 1;
      this._retreatTimer += dt * flank;
      if (this._retreatTimer >= this.RETREAT_TIME) {
        /* Running burns He2 out of the CELLS in the hold (update39),
           the same as any jump — there is no tank behind them to
           quietly cover the cost. */
        const hold = this.playerShip?.cargo;
        if (hold) {
          hold.takeStack('fuel', this._retreatCost);
          Save.updateRun({ fuel: hold.countOf('fuel') });
        } else {
          const run = Save.getRun();
          if (run) Save.updateRun({ fuel: Math.max(0, run.fuel - this._retreatCost) });
        }
        this.state = COMBAT_STATE.FLED;
        return;
      }
    }
    // The battle rages on while the drive spools — enemy AI, win/lose
    // checks, surrender and escape rolls all keep running.
    this._updateActive(dt);
  }

  _onVictory() {
    this.state = COMBAT_STATE.VICTORY;
    // They died mid-escape: clear the spool-up so the "ENEMY ESCAPING"
    // bar and the warning marker over their hull don't linger on a
    // wreck for the rest of the victory screen.
    this.enemyEscapeActive = false;
    this._enemyEscapeT     = 0;
    this._escapeNotice     = false;

    // Award scrap to run
    const run = Save.getRun();
    if (run) {
      Save.updateRun({ scrap: run.scrap + this.scrapReward });
    }

    /* No blanket combat XP any more (update38).
     *
     * `combat` is the hand-to-hand skill. Handing 15 of it to EVERY
     * crew member for winning a gunnery duel taught the whole ship to
     * punch without anybody throwing a punch — and because a mastered
     * skill burns one of the three mastery slots, it quietly stole the
     * slot a gunner needed for `weapons`. Melee grants it, per swing,
     * to the man who swung (CrewMember.creditMeleeSwing) and nothing
     * else does. Gunners are already paid in `weapons` XP per shot. */

    /* The blast belongs to the HULL dying, and _updateActive already
       set it off at that moment. Firing it again here would explode a
       ship that has been a wreck for the length of a boarding fight. */
    if (!this.enemyDown) {
      Particles.explosion(
        this.enemyShip.worldX + this.enemyShip.spriteW / 2,
        this.enemyShip.worldY + this.enemyShip.spriteH / 2,
        2.0
      );
      Audio.sfx.explosion();
      Camera.shake(16, 0.6);
    }
    Audio.playMusic('explore');
  }

  // ── Enemy AI ──────────────────────────────────────────────

  /**
   * IS ANYBODY OF THEIRS STILL ON OUR DECK? (update54)
   *
   * One predicate, and it is the only thing that keeps a battle open
   * once the enemy hull is gone. Vermin do not count: a rat in the hold
   * is a chore, not a boarding party, and holding the victory screen
   * hostage to one would be a bug of its own.
   */
  intrudersAboard() {
    const p = this.playerShip;
    if (!p) return false;
    if (p.crew.some(c => c && c.alive && !c.isPlayer &&
                         !c.isVermin && !c.isSpider)) return true;
    /* AND THE ONES STILL IN THE VOID (update55). A boarder who has left
       his airlock and not yet reached ours belongs to NEITHER crew list
       — game.js owns the parties — so asking only the deck declared the
       battle won while an axe party was drifting towards us. game.js
       installs this counter at boot; the default keeps the class usable
       on its own. */
    return this.inFlightIntruders() > 0;
  }

  /** Overridden by game.js, which owns the boarding parties. */
  inFlightIntruders() { return 0; }

  /**
   * THE ODDS A BEATEN CREW STRIKES TO *THIS* COMMANDER (update62).
   *
   * One number, read from karma, used by both roads to a surrender —
   * the hull roll below and the cleared-decks branch in game.js. The
   * 0.5 fallback is exactly the flat roll this replaced, so a build
   * without commander.js behaves as it always did.
   */
  surrenderOdds() {
    return (typeof Commander !== 'undefined' && Commander.surrenderChance)
      ? Commander.surrenderChance() : 0.5;
  }

  /** True when nobody will ever surrender to him. The one predicate
   *  both roads ask, so they cannot disagree about who gets mercy. */
  noQuarter() { return this.surrenderOdds() <= 0; }

  /** The single door to a surrender offer. */
  _raiseSurrender() {
    this._surrenderMade = true;
    this.surrenderOffer = true;
  }

  _updateAI(dt) {
    const enemy  = this.enemyShip;
    const player = this.playerShip;

    // Pick target room (change occasionally)
    if (!this._aiTargetRoom || Math.random() < 0.005) {
      if (Math.random() < this._ai.targetRandom) {
        this._aiTargetRoom = Utils.pick(player.rooms);
      } else {
        // Prefer shields, then a RANDOM weapon module, then the reactor
        const wRooms = player.rooms.filter(r => r.type === 'weapons');
        this._aiTargetRoom =
          player.rooms.find(r => r.type === 'shields' && r.system) ||
          (wRooms.length ? Utils.pick(wRooms) : null) ||
          player.rooms.find(r => r.type === 'reactor') ||
          Utils.pick(player.rooms);
      }
    }

    // Fire each armed enemy weapon
    enemy.weapons.forEach((w, i) => {
      if (!w || !w.armed) return;

      this._aiFireTimers[i] = (this._aiFireTimers[i] ?? 0) + dt;
      if (this._aiFireTimers[i] < this._ai.fireDelay) return;
      this._aiFireTimers[i] = 0;

      // Their guns leave their barrels too (update80) — the same
      // function, so the rule is not "the player's side looks right".
      const eb = enemy.roomBounds ? enemy.roomBounds() : { x: enemy.worldX, y: enemy.worldY, w: 300, h: 200 };
      const em = enemy.muzzleFor ? enemy.muzzleFor(w) : null;
      const fromX = em ? em.x : eb.x - 10;
      const fromY = em ? em.y : eb.y + eb.h / 2;
      const toX   = this._aiTargetRoom.cx;
      const toY   = this._aiTargetRoom.cy;

      const projs = w.fire(fromX, fromY, toX, toY, false);
      Particles.muzzleFlash?.(fromX, fromY, -1, '#ff8a6a');
      this._projectiles.push(...projs);
    });

    // ── Enemy cloak ──
    //  Fire it when it actually saves them: hull under two thirds, or
    //  shields stripped with a gun charged and pointing at us. A cloak
    //  the AI never used would just be a decoration.
    {
      const cl = enemy.getSystem('cloaking');
      if (cl && cl.cloakReady) {
        const hurt      = enemy.hull <= enemy.hullMax * 0.66;
        const naked     = enemy.shieldBars === 0 && enemy.getSystem('shields');
        const incoming  = this._projectiles.some(p => p.fromPlayer && !p.done);
        if (hurt || (naked && incoming)) {
          if (cl.activateCloak() && typeof UI !== 'undefined') {
            UI.notify('⚠ Enemy CLOAKED — your shots will miss!', 'warn');
          }
        }
      }
    }

    // Enemy crew AI — dispatch exactly ONE crew member per problem,
    // picking the closest (repair skill breaks ties).
    // SMART PILOT RULE: the crew member seated in the cockpit is only
    // ever pulled away if there is NOBODY else available — losing the
    // pilot means losing evasion. (Cockpit damage is fixed in place by
    // the pilot himself via idle auto-repair.)
    const pilotRoomId = enemy.getSystem('piloting')?.roomId ?? null;
    // GUNNER RULE: at least ONE crew member stays in a weapon module
    // so the ship keeps shooting — never pull the last gunner for
    // repairs (that made enemies trivially easy to disarm).
    const wpnRoomIds = enemy.weaponRooms.map(r => r.id);
    const lastGunnerId = (() => {
      const gunners = enemy.crew.filter(c => c.alive && wpnRoomIds.includes(c.roomId));
      return gunners.length === 1 ? gunners[0].id : null;
    })();
    const pickBest = (x, y, skill) => {
      // Spiders do NOT crew the hulk they nest in. They were being
      // dispatched to repair modules and fight fires like a proper crew,
      // which is exactly what a nest would never do.
      let idle = enemy.crew.filter(c => c.task === TASK.IDLE && c.alive && !c.isBeast);
      if (!idle.length) return null;
      const nonPilots = idle.filter(c =>
        c.roomId !== pilotRoomId && c.id !== lastGunnerId);
      if (nonPilots.length) idle = nonPilots;   // keep pilot AND last gunner seated
      idle.sort((a, b) => {
        const da = Utils.dist(a.x, a.y, x, y);
        const db = Utils.dist(b.x, b.y, x, y);
        if (Math.abs(da - db) > 40) return da - db;          // clearly closer wins
        return b.getSkillLevel(skill) - a.getSkillLevel(skill); // tie → better skill
      });
      return idle[0];
    };

    enemy.systems.forEach(sys => {
      if (sys.damagedLevels <= 0) return;
      // Someone already on it? Skip.
      const busy = enemy.crew.some(c =>
        !c.dead && !c.dying &&
        c.task === TASK.REPAIR && c.taskTarget === sys.roomId);
      if (busy) return;
      // Someone already standing in that room? They'll auto-repair it
      // (this keeps the pilot fixing his own cockpit without backup).
      const inRoom = enemy.crew.some(c => c.alive && !c.isBeast && c.roomId === sys.roomId);
      if (inRoom) return;
      const best = pickBest(sys.cx, sys.cy, 'repair');
      if (best) {
        best.moveToOnShip(enemy, sys.cx, sys.cy);
        best.assignTask(TASK.REPAIR, sys.roomId);
      }
    });

    enemy.fires.fires.forEach(fire => {
      if (fire.out) return;
      const busy = enemy.crew.some(c =>
        c.task === TASK.FIRE && c.taskTarget === fire);
      if (busy) return;
      const best = pickBest(fire.x, fire.y, 'firefight');
      if (best) {
        best.moveToOnShip(enemy, fire.x, fire.y);
        best.assignTask(TASK.FIRE, fire);
      }
    });
  }

  // ── Projectile management ─────────────────────────────────

  /**
   * Player fires a weapon at the enemy.
   * @param {Weapon} weapon
   */
  /**
   * @param {Weapon} weapon
   * @param {Room|null} targetRoom - specific enemy room, or null = random
   */
  /**
   * WHY THIS GUN WILL NOT FIRE — or null if it will (update59).
   *
   * ONE implementation, and it is published, because three different
   * places need the same answer: `playerFire` refuses with it, game.js
   * SAYS it to the player, and the HUD greys the card with it. Before
   * this, `playerFire` simply `return`ed on an empty rack — no message,
   * no mark on the card, nothing. A Hull Cannon (missileUse: 1) that
   * ran the warheads out looked charged, powered and manned, and
   * clicking an enemy room did NOTHING, for the rest of that fight and
   * every fight after it. The player reported exactly that and it cost
   * him the run.
   *
   * Same rule as the special orders in update53: an action that refuses
   * has to say what is missing.
   */
  fireRefusal(weapon) {
    if (!weapon) return 'no gun';
    if (this.state !== COMBAT_STATE.ACTIVE) return 'not in a fight';
    /* ARMED IS THE POWER TEST TOO. `Weapon.update` clears `armed` the
       moment a gun loses power, so a separate `powered` check here would
       be a second copy of the same fact. And UNMANNED is deliberately
       NOT a refusal: an empty bay freezes CHARGING, but a shell already
       in the breech fires — checking it here would invent a rule the
       rest of the engine does not have. */
    if (!weapon.armed)    return `${weapon.label} is still charging`;
    const need = weapon.def.missileUse || 0;
    if (need > 0) {
      const hold = this.playerShip?.cargo;
      const have = hold ? hold.countOf('missiles') : (Save.getRun()?.missiles ?? 0);
      if (have < need) {
        return `${weapon.label} is out of ammo — it needs ${need} missile`
             + `${need > 1 ? 's' : ''} a shot and the racks hold ${have}`;
      }
    }
    return null;
  }

  playerFire(weapon, targetRoom = null) {
    const refusal = this.fireRefusal(weapon);
    if (refusal) return refusal;

    // Missile ammo comes straight out of the racks in the hold — there is
    // no second, invisible ammo counter. run.missiles only MIRRORS the
    // hold so the HUD and old saves keep working. The RACKS were checked
    // by fireRefusal above; this is the withdrawal, not the check.
    if (weapon.def.missileUse > 0) {
      const hold = this.playerShip?.cargo;
      if (hold) {
        hold.takeStack('missiles', weapon.def.missileUse);
        Save.updateRun({ missiles: hold.countOf('missiles') });
      } else {
        const run = Save.getRun();
        Save.updateRun({ missiles: run.missiles - weapon.def.missileUse });
      }
    }

    const enemy  = this.enemyShip;
    const target = targetRoom || Utils.pick(enemy.rooms);

    /* THE BOLT LEAVES THE BARREL (update80). This was the corner of
       the rectangle round the whole hull — `pb.x + pb.w + 10` — so
       every gun aboard fired from one pixel on the flank while the
       guns themselves were drawn in a row along the top. One position
       answers both now: see Ship.weaponMounts. The bounding box stays
       as the fallback for a gun that is somehow not on a mount, so a
       shot can never come from `undefined`. */
    const pb = this.playerShip.roomBounds ? this.playerShip.roomBounds() : { x: this.playerShip.worldX, y: this.playerShip.worldY, w: 300, h: 200 };
    const muzzle = this.playerShip.muzzleFor ? this.playerShip.muzzleFor(weapon) : null;
    const fromX = muzzle ? muzzle.x : pb.x + pb.w + 10;
    const fromY = muzzle ? muzzle.y : pb.y + pb.h / 2;

    // The crew standing in this gun's own bay get the credit for it.
    const gunRoom = this.playerShip.weaponRoomFor(weapon);
    const gunners = gunRoom ? this.playerShip.crewOperating(gunRoom.id) : [];
    const projs  = weapon.fire(fromX, fromY, target.cx, target.cy, true, gunners);
    Particles.muzzleFlash?.(fromX, fromY, 1, '#ffd780');
    this._projectiles.push(...projs);

    // FTL XP: crew manning THIS gun's module learn from each shot
    // The gun's OWN bay — see Ship.weaponRoomFor (update60).
    const wRoom = this.playerShip.weaponRoomFor(weapon);
    if (wRoom) {
      const gunner = this.playerShip.consoleOperator(wRoom.id);
      if (gunner) gunner.addXP('weapons', XP_RATES.weapons);
    }
    return null;      // fired
  }

  _updateProjectiles(dt) {
    this._projectiles.forEach(p => p.update(dt));

    // Handle hits
    this._projectiles.forEach(p => {
      if (!p.hit || p._resolved) return;
      p._resolved = true;

      const targetShip = p.fromPlayer ? this.enemyShip : this.playerShip;
      if (!targetShip) return;

      const result = targetShip.receiveHit(p);

      if (!result.dodged) {
        Particles.laserHit(p.x, p.y);
      }
    });

    // Remove spent projectiles
    this._projectiles = this._projectiles.filter(p => !p.done);
  }

  // ── Draw ─────────────────────────────────────────────────

  draw(ctx) {
    if (this.state === COMBAT_STATE.IDLE) return;
    this._projectiles.forEach(p => p.draw(ctx));
  }

  drawBeams(ctx) {
    this._projectiles.forEach(p => {
      if (p.type === 'beam') {
        const ship = p.fromPlayer ? this.enemyShip : this.playerShip;
        if (ship) p.drawBeam(ctx, ship.worldX, ship.worldY + ship.spriteH/2, ship.spriteW);
      }
    });
  }

  // ── Getters ──────────────────────────────────────────────

  isActive()   { return this.state === COMBAT_STATE.ACTIVE; }
  isVictory()  { return this.state === COMBAT_STATE.VICTORY; }
  isDefeat()   { return this.state === COMBAT_STATE.DEFEAT; }
  isFled()     { return this.state === COMBAT_STATE.FLED; }
  isEnemyFled(){ return this.state === COMBAT_STATE.ENEMY_FLED; }
  get retreatProgress() {
    return this.state === COMBAT_STATE.RETREATING
      ? Utils.clamp(this._retreatTimer / this.RETREAT_TIME, 0, 1) : 0;
  }
  get enemyEscapeProgress() {
    return this.enemyEscapeActive
      ? Utils.clamp(this._enemyEscapeT / this.ENEMY_ESCAPE_TIME, 0, 1) : 0;
  }
  consumeEscapeNotice() {
    if (!this._escapeNotice) return false;
    this._escapeNotice = false;
    return true;
  }
  inProgress() {
    return this.state === COMBAT_STATE.ACTIVE ||
           this.state === COMBAT_STATE.ENTERING ||
           this.state === COMBAT_STATE.RETREATING;
  }
}

// Singleton
const CombatManager = new Combat();
