/* ============================================================
   MOON WARS — ship.js
   Ship class: layout, rooms, systems, hull, crew roster,
   weapons rack, elevator integration, damage resolution.
   Both player and enemy ships use this class.
   ============================================================ */

'use strict';

/* ══ GRAVITY (update91) ══════════════════════════════════════
 *
 * The spec (GPT, agreed by the player 01.10): artificial gravity is a
 * SECOND FUNCTION OF THE ENGINES, not a module. It is ON while the
 * engines have a working level and are running on power, and OFF
 * otherwise — no partial gravity. Nothing about it is stored: it is
 * read off the engines every time (`Ship.gravityActive`), so a save,
 * a repair or a power click can never leave it out of step.
 *
 * Zero-G costs and pays:
 *   · crew walk at 70%, repair at 80%, patch hull breaches at 70%
 *   · a casualty carried in gravity goes at 50% of a man's walk, in
 *     zero-G at 120% — the player's figure, faster than walking
 *   · a fire spreads at 20% of its rate; it still burns, eats air,
 *     hurts and is put out as before (zero-G is not vacuum)
 *   · the hold: every 20 s a 15% roll damages ONE item; and with ANY
 *     unpatched hull breach aboard (the player's call: the hold has no
 *     compartment of its own), every 10 s a 25% roll loses ONE item —
 *     one unit off a stack. Installed guns and modules are not cargo.
 * Every number is here and nowhere else. */
const GRAVITY_CONFIG = {
  crewMovementMultiplier:   0.70,
  normalRepairMultiplier:   0.80,
  breachRepairMultiplier:   0.70,
  fireSpreadMultiplier:     0.20,
  normalWoundedCarrySpeed:  0.50,
  zeroGWoundedCarrySpeed:   1.20,   // jj, 01.10: "50% / 120%" (the spec had 0.80)
  cargoDamageCheckInterval: 20,
  cargoDamageProbability:   0.15,
  cargoLossCheckInterval:   10,
  cargoLossProbability:     0.25,
};

/* ══ REACTOR HEAT (update92) ═════════════════════════════════
 *
 * The spec (GPT) with the player's gentler numbers, 01.10:
 *   · LOAD = what the MODULES draw / what the reactor gives now. The lifts'
 *     spare units do not count (the player's call: otherwise the default
 *     split sat at 100% from the first second);
 *   · HEAT 0–100 rises only from 80% load — to full in ~10 min at 80–89%,
 *     ~6 min at 90–99%, ~3 min at 100% — and falls only with 30% or more of
 *     the reactor FREE: slowly from 30%, faster from 40%, fast from 50%.
 *     Between (70–80% load) it holds. A scrammed reactor cools fast;
 *   · the same rules in a fight and out of one: the player cools down
 *     between fights by taking power off, and that is the point;
 *   · from 70% heat, once a second, a small chance of a fire in the reactor
 *     room; at 100%: OVERHEAT — one reactor level shot out (crew repair it
 *     like any module), heat back to 90%, and a 50% fire roll;
 *   · a bigger reactor runs a little cooler (thermal multiplier).
 * Rates are in heat-percent per second. Every number is here. */
const REACTOR_HEAT_CONFIG = {
  heatBands: [                          // highest load first
    { load: 1.00, perSec: 100 / 180 },  // 100%     → full in ~3 min
    { load: 0.90, perSec: 100 / 360 },  // 90–99%   → ~6 min
    { load: 0.80, perSec: 100 / 600 },  // 80–89%   → ~10 min
  ],
  coolBands: [                          // most free first
    { free: 0.50, perSec: 100 / 150 },  // 50%+ free → empty in ~2.5 min
    { free: 0.40, perSec: 100 / 300 },  // 40–49%    → ~5 min
    { free: 0.30, perSec: 100 / 600 },  // 30–39%    → ~10 min
  ],
  scramCoolPerSec: 100 / 150,           // offline, or nothing left to give
  thermal: [                            // by reactor level: heat gain multiplier
    { upTo: 8,  mult: 1.00 },
    { upTo: 12, mult: 0.95 },
    { upTo: 16, mult: 0.90 },
    { upTo: Infinity, mult: 0.85 },
  ],
  hazardInterval: 1,                    // seconds between fire rolls
  fireChance: [                         // per roll, by heat; highest first
    { heat: 90, p: 0.020 },
    { heat: 80, p: 0.005 },
    { heat: 70, p: 0.001 },
  ],
  warnHeat:     70,
  criticalHeat: 90,
  overheatDamage: 1,
  overheatResetHeat: 90,
  overheatFireChance: 0.5,
  /* THE ENEMY KEEPS ITS CORE COOL (update93). From `shedAt` heat it
     takes one unit off a module every `stepSeconds` until the load is at
     `targetLoad` (30% free — the cooling line); from `restoreAt` it
     gives them back, one per step, last taken first. Never the reactor,
     life support below 1, the helm, the carbonite bay, the last gun or
     the shields below one bar. */
  ai: { shedAt: 75, restoreAt: 30, targetLoad: 0.70, stepSeconds: 1 },
};

// ── Door ──────────────────────────────────────────────────

/** Seconds for a door panel to travel from shut to fully open. */
const DOOR_CYCLE = 1.0;

class Door {
  /**
   * Door between two adjacent rooms — or an AIRLOCK to space (roomB = null).
   * Doors are BINARY: 'open' or 'closed'. Green = open, red = closed.
   *        'closed' (player-locked shut).
   * Open airlocks vent the room's oxygen to space (FTL fire-fighting tactic).
   */
  constructor(roomA, roomB, x, y, isAirlock = false) {
    this.roomA  = roomA;
    this.roomB  = roomB;        // null = space
    this.x      = x;
    this.y      = y;
    this.isAirlock = isAirlock;
    // Doors are strictly BINARY: open or closed. Interior doors start
    // open (air flows), airlocks start closed. Click toggles.
    this.mode   = isAirlock ? 'closed' : 'open';
    // A door is no longer instant. `openness` runs 0..1 over DOOR_CYCLE
    // seconds and `open` means FULLY open — nobody squeezes through a
    // door that is still moving.
    this.openness = isAirlock ? 0 : 1;
    this.open   = !isAirlock;
    // Auto-passage: an INTERIOR door a crew member walks up to slides
    // open briefly even if the player locked it 'closed', then closes
    // again. Airlocks NEVER auto-open (they must be breached).
    this._tempT = 0;   // seconds left holding open for a passer-by
    this.breached = false;   // legacy: airlock smashed open (see hack())

    /* ── HACKING ──────────────────────────────────────────────
       A door belongs to the hull it is bolted into: it slides open for
       the crew who live there and stays shut to everyone else. An
       intruder has to work the lock, and the first door of a fight is
       the airlock they came through.

       Per SIDE, and per fight: once a boarding party has cracked a
       particular door it stays cracked for them until the battle ends
       (Ship.markCombatStart resets them), so they are not re-hacking
       the same corridor on the way back. */
    this.hacked = { player: false, enemy: false };
    this.hackT  = 0;
  }

  /** Seconds of work to crack one lock. */
  static get HACK_TIME() { return 2.5; }

  /**
   * An intruder from `side` works this lock. Returns true once the door
   * will actually let them through.
   */
  hackBy(side, dt = 0) {
    if (this.hacked[side]) {
      // Already theirs — from here on it behaves like their own door.
      this._tempT = Math.max(this._tempT, 0.6);
      return this.open;
    }
    this.hackT += dt;
    if (this.hackT >= Door.HACK_TIME) {
      this.hacked[side] = true;
      this.hackT = 0;
      this._tempT = Math.max(this._tempT, 1.2);
      Audio.sfx.doorMove?.();
    }
    return false;
  }

  /** Force a door open to a side without the work — the boarding party
   *  cutting the outer hatch has already spent its time doing that. */
  hackOpen(side, hold = 2.2) {
    this.hacked[side] = true;
    this.hackT = 0;
    this._tempT = Math.max(this._tempT, hold);
  }

  isHackedBy(side) { return !!this.hacked[side]; }
  get hackProgress() { return Utils.clamp(this.hackT / Door.HACK_TIME, 0, 1); }

  /** New battle: every lock is a stranger's lock again. */
  resetHacks() { this.hacked = { player: false, enemy: false }; this.hackT = 0; }

  /** Player click: open ↔ closed. The panel then takes a second to cycle. */
  toggle() {
    this.mode = this.mode === 'open' ? 'closed' : 'open';
    this._tempT = 0;
    Audio.sfx.uiClick();
    Audio.sfx.doorMove?.();
  }

  /** Where the panel should end up, 1 = open. */
  get _target() {
    if (this.breached) return 1;
    // A hacked airlock cycles like any other door instead of staying a
    // hole in the hull. The old boarding code smashed it permanently,
    // which vented that room for the rest of the run with no way to
    // ever seal it again.
    if (this.isAirlock) return (this._tempT > 0 || this.mode === 'open') ? 1 : 0;
    return (this._tempT > 0 || this.mode === 'open') ? 1 : 0;
  }

  /** A crew member is standing at this door wanting through.
   *  INTERIOR doors slide open (with a short delay so it reads as a
   *  door cycling). Returns true once it's actually open to pass. */
  requestPassage(dt) {
    if (this.isAirlock) return this.open;   // airlocks don't auto-open
    // Ask for it, then WAIT. The door needs its full second; returning
    // true early let crew walk through a half-open panel.
    this._tempT = Math.max(this._tempT, 0.6);
    return this.open;
  }

  update(dt, crew) {
    if (this._tempT > 0) this._tempT -= dt;

    // Slide toward the target at a fixed rate — one full second end to
    // end, whichever way it is going. A breached airlock is simply gone,
    // so it snaps.
    const target = this._target;
    if (this.breached) {
      this.openness = 1;
    } else if (this.openness !== target) {
      const step = dt / DOOR_CYCLE;
      this.openness = target > this.openness
        ? Math.min(target, this.openness + step)
        : Math.max(target, this.openness - step);
    }
    // FULLY open, not "on its way".
    this.open = this.openness >= 1;

    if (!this.isAirlock) return;

    // Venting particles for open airlocks (throttled)
    if (this.open) {
      this._ventT = (this._ventT ?? 0) + dt;
      if (this._ventT > 0.15) {
        this._ventT = 0;
        Particles.emit({
          x: this.x, y: this.y + Utils.randFloat(-12, 12),
          vx: (this.x < 640 ? -1 : 1) * Utils.randFloat(40, 90),
          vy: Utils.randFloat(-15, 15), ay: 0,
          color: '#aaccee', size: 2, sizeEnd: 0,
          life: 0.4, alpha: 0.7, alphaEnd: 0,
        });
      }
    }
  }

  /* THE DOOR IS 6 x 34 PIXELS, and that is the only place those two
     numbers live (update69). The drawing below reads them, and so does
     `hits()` — the hit test used to be a 32px circle around the same
     point, five times wider than the leaf you can see, reaching well
     into the module behind it. Clicks meant for the room, and for the
     menu that opens over it, were eaten by a hatch that was nowhere
     near the cursor. The player's words: "drzwi mają siatkę klikania
     za bardzo oddaloną od samych drzwi i nachodzi mocno na moduł". */
  static get W() { return 6; }
  static get H() { return 34; }
  /** Generous enough to hit with a mouse, tight enough to stay ON the
   *  door: the leaf plus 5px of wall either side, and nothing more. */
  static get GRAB() { return 5; }

  hits(mx, my) {
    return Math.abs(mx - this.x) <= Door.W / 2 + Door.GRAB &&
           Math.abs(my - this.y) <= Door.H / 2;
  }

  draw(ctx) {
    const w = Door.W, h = Door.H;

    // Somebody is working this lock — show how far they have got.
    if (this.hackT > 0) {
      const p = this.hackProgress;
      ctx.fillStyle = 'rgba(6,9,16,0.85)';
      ctx.fillRect(this.x - 9, this.y - h / 2 - 9, 18, 4);
      ctx.fillStyle = '#ffd700';
      ctx.fillRect(this.x - 9, this.y - h / 2 - 9, 18 * p, 4);
      ctx.strokeStyle = 'rgba(255,215,0,0.6)'; ctx.lineWidth = 1;
      ctx.strokeRect(this.x - 9.5, this.y - h / 2 - 9.5, 19, 5);
    }

    if (this.isAirlock) {
      // Airlock — same one-second cycle as an interior door, so the
      // outer hatches read as machinery too, not as an instant toggle.
      const ao   = Utils.clamp(this.openness ?? (this.open ? 1 : 0), 0, 1);
      const half = h / 2;
      const leaf = half * (1 - ao);
      const moving = ao > 0 && ao < 1;

      if (ao > 0) {                       // vacuum showing through the gap
        ctx.fillStyle = `rgba(255,60,60,${(0.30 * ao).toFixed(2)})`;
        ctx.fillRect(this.x - w/2 - 3, this.y - half - 3, w + 6, h + 6);
      }
      if (leaf > 0.5) {                   // the hatch leaves themselves
        ctx.fillStyle = this.breached ? '#4a2020' : '#3a2a1a';
        ctx.fillRect(this.x - w/2, this.y - half, w, leaf);
        ctx.fillRect(this.x - w/2, this.y + half - leaf, w, leaf);
      }
      if (ao >= 1) {                      // fully open: hot edges
        ctx.fillStyle = '#ff4455';
        ctx.fillRect(this.x - w/2, this.y - half, w, 6);
        ctx.fillRect(this.x - w/2, this.y + half - 6, w, 6);
      }
      ctx.strokeStyle = this.breached ? '#ff2d44'
                      : moving ? '#ffb020' : (ao >= 1 ? '#ff4455' : '#ff7c20');
      ctx.lineWidth = 1;
      ctx.strokeRect(this.x - w/2, this.y - half, w, h);
      return;
    }

    // Interior door — TWO PANELS that actually slide apart, so a door
    // mid-cycle reads as mid-cycle. Green fully open, red shut, amber
    // while it is moving (and crew are waiting on it).
    const o    = Utils.clamp(this.openness ?? (this.open ? 1 : 0), 0, 1);
    const half = h / 2;
    const panel = half * (1 - o);          // how much each leaf still covers
    const moving = o > 0 && o < 1;
    const col  = o >= 1 ? '#1aff8c' : moving ? '#ffb020' : '#ff5566';

    if (panel > 0.5) {
      ctx.fillStyle = o >= 1 ? '#2a5a3a' : moving ? '#5a4a1a' : '#5a2a2a';
      ctx.fillRect(this.x - w / 2, this.y - half, w, panel);
      ctx.fillRect(this.x - w / 2, this.y + half - panel, w, panel);
    }
    // Frame: doubled and offset when fully open, exactly as before.
    ctx.strokeStyle = col;
    ctx.lineWidth = 1;
    if (o >= 1) {
      ctx.fillStyle = 'rgba(26,255,140,0.25)';
      ctx.fillRect(this.x - w / 2, this.y - half, w, 6);
      ctx.fillRect(this.x - w / 2, this.y + half - 6, w, 6);
      ctx.strokeRect(this.x - w / 2 - 2, this.y - half - 2, w + 4, h + 4);
    } else {
      ctx.strokeRect(this.x - w / 2, this.y - half, w, h);
    }
  }
}

// ── Room ──────────────────────────────────────────────────

class Room {
  constructor(cfg) {
    this.id      = cfg.id;
    this.type    = cfg.type ?? 'empty';   // system type or 'empty'
    this.x       = cfg.x;
    this.y       = cfg.y;
    this.w       = cfg.w ?? 96;
    this.h       = cfg.h ?? 80;
    this.floor   = cfg.floor ?? 0;        // which floor (0=bottom)
    this.cx      = this.x + this.w / 2;
    this.cy      = this.y + this.h / 2;
    this.isVacuum = false;

    // Adjacent room ids (set after all rooms created)
    this.adjacent = cfg.adjacent ?? [];

    // Linked system instance (set by Ship)
    this.system  = null;
  }

  contains(wx, wy) {
    return Utils.pointInRect(wx, wy, this.x, this.y, this.w, this.h);
  }

  /* ── THE CEILING DUCT (update73) ──────────────────────────
   *
   * Every module carries its own duct along the top row of its tiles:
   * oxygen pipes and power runs, wide enough for vermin and the cat and
   * nobody else. It is part of the room rather than a band of its own
   * so that a one-deck hull has one too, and so that the duct NETWORK
   * needs no geometry — it is `adjacent`, which this class has carried
   * since the beginning.
   *
   * Derived, never stored: the module owns its size and the duct is a
   * reading of it. A stored `ventY` would be the same number twice and
   * would go stale the first time a hull moved.
   *
   * The mechanics come later (fire through the grille, air leaving the
   * duct first, rats walking it). What lands now is the SPACE and the
   * fact that the player can see it.
   */
  get ventY()  { return this.y; }
  get ventH()  { return HULL_GRID.VENT_H; }
  /** Where the deck the crew stand on actually begins. */
  get floorTop() { return this.y + HULL_GRID.VENT_H; }
  /** Height of the part anybody walks in. */
  get floorH()   { return this.h - HULL_GRID.VENT_H; }

  /** Repair the system in this room */
  repair(amount, crew) {
    if (this.system) this.system.repair(amount, crew);
  }
}

// ── Ship layouts ──────────────────────────────────────────

/* ============================================================
   THE HULL GRID (update41)

   Every hull in this game is now built from ONE module size. Before
   this there were three — 80x72, 96x80 and 96x60 — with three
   different deck pitches, because each layout hard-coded its own pixel
   coordinates and they drifted apart one hull at a time. That made a
   shared set of art impossible: a floor tile drawn for the scout was
   the wrong size on the frigate and the wrong shape on the station.

   Layouts are declared in GRID COORDINATES now — (col, row) — and the
   pixels are derived. Adding a hull is listing squares; changing the
   module size is changing one number here and every hull, every door,
   every lift stop and every crew station follows.

       MODULE_W x MODULE_H     one compartment
       DECK_PITCH              MODULE_H + DECK_GAP, floor to floor
       SHAFT_W                 a lift trunk sits in the gap BETWEEN two
                               columns, never inside a room
       ENGINE_W / PROW_W       exterior tiles, one per deck, hung off
                               the stern and the bow (see engineSlots
                               and prowSlots). Stations have neither.

   The art kit is cut to these numbers. Do not nudge them for one hull.

   ── EVERYTHING IS A WHOLE NUMBER OF TILES (update73) ──────

   One more rule on top of update41's: every length here is a multiple
   of TILE. That is what lets the art kit be a handful of 10x10 squares
   — a corner, an edge, a floor, a duct — instead of one bespoke
   drawing per hull. Section 247 of the test suite asserts it, so a
   number nudged by a pixel for one screen fails the suite rather than
   quietly making one tile in one hull the wrong size.

   ── THE MODULE LIES DOWN (update73) ───────────────────────

   80x72 was very nearly a square (1.11:1), which read as a cell rather
   than a compartment — and the duct below would only have made it look
   taller. 100x60 is 1.67:1: a room you walk along.

   Measured against the 1280 canvas before it was chosen, because the
   camera never zooms (`Camera.setZoom` is called from nowhere) and so
   both hulls are always drawn 1:1. Two Hapis — the widest pair in the
   game at four columns — come to 1080px and leave 200px between them.
   At 120 wide the same pair left twelve pixels and Hapi would have had
   to lose a column; at 100 no hull has to change at all.

   ── THE DUCT IS THE TOP ROW OF EVERY MODULE (update73) ────

   VENT_H is the ceiling duct: oxygen pipes and power runs, the width
   of one tile, inside the module rather than in a band of its own.
   Three things follow, and they are why it sits here and not in the
   gap between decks:

     · it exists on a ONE-DECK hull, which a band between decks cannot;
     · it needs no geometry of its own — it has the module's;
     · the vent NETWORK is `Room.adjacent`, which this engine has had
       since the beginning. Vermin walk the duct from room to adjacent
       room and no new pathfinding is written.

   DECK_GAP is therefore 0: the duct is the gap now, and a visible one.
   ============================================================ */

const TILE = 10;

const HULL_GRID = {
  TILE,
  MODULE_W: 10 * TILE,   // 100
  MODULE_H:  7 * TILE,   // 70 — INCLUDING the duct along its ceiling
  /* TWO TILES, AND IT WAS MEASURED (update73a). One tile was chosen
     by eye in update73 and the eye was wrong: the sprites were
     rendered in a browser at the size the game draws them and their
     pixels counted, walking, idling and fighting.
         rat     10px  — fits a one-tile duct exactly
         spider  11px  — one over, even standing still
         cat     13px walking, 16 sitting
     The cat is the tall one because it SITS UP, which was a
     deliberate update45 decision so its silhouette could never be
     mistaken for the rat's. That decision does not fit in ten pixels.
     The INTERIOR is unchanged at 50: the module grew, the deck did
     not, so nothing about the crew moves. */
  VENT_H:    2 * TILE,   // the duct: the module's top rows of tiles
  DECK_GAP:  0,          // the duct IS the gap between decks now
  SHAFT_W:   3 * TILE,   // 30
  MARGIN:    1 * TILE,   // hull plate overhang past the outermost room
  /* The exterior tiles came down a tile each with the wider module
     (update73). Two hulls at four columns now come to 1040px of the
     1280 the canvas has, and the twenty pixels this gives back per
     ship are twenty pixels of open space between them — which is
     where the shells fly. They are dressing; the compartments are
     the ship. */
  ENGINE_W:  4 * TILE,   // stern tile, one per deck
  PROW_W:    3 * TILE,   // bow tile, one per deck
  WALK_FRAC: 0.65,       // crew feet, as a fraction of the INTERIOR
};
HULL_GRID.DECK_PITCH = HULL_GRID.MODULE_H + HULL_GRID.DECK_GAP;   // 60

/**
 * How far below a room's TOP the crew's feet stand.
 *
 * ONE DEFINITION, and it has to be (update73). This number lived in
 * two places before: `buildHull` multiplied WALK_FRAC by the whole
 * module to place its lift stops, and `floorWalkY` had a bare 0.65
 * written out beside it. They agreed only because the module had no
 * duct — the moment the ceiling stopped being walkable they would have
 * disagreed by seven pixels, which is a lift that stops just above the
 * floor its passengers are standing on.
 *
 * Measured from the INTERIOR, not the module: the duct is ceiling, and
 * nobody's feet are ever in it.
 */
function walkOffset() {
  return HULL_GRID.VENT_H
       + (HULL_GRID.MODULE_H - HULL_GRID.VENT_H) * HULL_GRID.WALK_FRAC;
}

/** World X of a column, counting the shafts that sit before it. */
function gridColX(originX, col, shaftAfter) {
  const before = shaftAfter.filter(c => c < col).length;
  return originX + col * HULL_GRID.MODULE_W + before * HULL_GRID.SHAFT_W;
}

/** World Y of a deck. Row 0 is the BOTTOM deck, as `floor` always was. */
function gridRowY(originY, row, decks) {
  return originY + (decks - 1 - row) * HULL_GRID.DECK_PITCH;
}

/** World X of the CENTRE of the shaft that follows column `afterCol`. */
function gridShaftX(originX, afterCol, shaftAfter) {
  const before = shaftAfter.filter(c => c < afterCol).length;
  return originX + (afterCol + 1) * HULL_GRID.MODULE_W
       + before * HULL_GRID.SHAFT_W + HULL_GRID.SHAFT_W / 2;
}

/**
 * Expand a compact hull spec into the `rooms` / `elevators` shape the
 * rest of the engine already consumes, so nothing downstream had to
 * change when the grid arrived.
 *
 * Lift stops are DERIVED — every shaft stops on the crew walk line of
 * every deck it passes. They used to be hand-typed per hull, which is
 * how the boss station ended up with a cabin hanging out of the roof.
 */
function buildHull(spec) {
  const { originX, originY, decks, shaftAfter = [], grid = [] } = spec;
  const W = HULL_GRID.MODULE_W, H = HULL_GRID.MODULE_H;

  spec.floors = decks;
  spec.rooms = grid.map(r => ({
    id: r.id, type: r.type ?? 'empty',
    x: gridColX(originX, r.col, shaftAfter),
    y: gridRowY(originY, r.row, decks),
    w: W, h: H,
    floor: r.row,
    adjacent: r.adjacent ?? [],
  }));

  const stops = [];
  for (let row = decks - 1; row >= 0; row--) {
    stops.push(gridRowY(originY, row, decks) + walkOffset());
  }
  spec.elevators = shaftAfter.map((afterCol, i) => ({
    id: 'ev' + i,
    x: gridShaftX(originX, afterCol, shaftAfter),
    floors: stops.slice(),
  }));
  return spec;
}

const SHIP_LAYOUTS = {

  /** FREE STARTER HULL — the same class of boat the ordinary raiders
   *  fly, refitted for you. Two decks, no medbay (field aid only),
   *  smaller reactor. The empty bay is the first real refit decision. */
  scout: buildHull({
    label: 'Bastet',
    spriteKey: 'ship_player',
    hullMax: 22,
    originX: 20, originY: 90, decks: 2, shaftAfter: [0],
    grid: [
      { id:'r_engines',  type:'engines',  col:0, row:0, adjacent:['r_weapons'] },
      { id:'r_weapons',  type:'weapons',  col:1, row:0, adjacent:['r_engines'] },
      { id:'r_piloting', type:'piloting', col:0, row:1, adjacent:['r_oxygen'] },
      { id:'r_oxygen',   type:'oxygen',   col:1, row:1, adjacent:['r_piloting','r_reactor'] },
      { id:'r_reactor',  type:'reactor',  col:2, row:1, adjacent:['r_oxygen','r_hold'] },
      /* SHE IS NOT A RECTANGLE ANY MORE (update73).
       *
       * Six modules, same as ever — but the free bay MOVED from the
       * lower deck's third column to a fourth column on the upper
       * deck, and nothing was put underneath it. A spur on top, a
       * notch below, and the first hull in this game with a profile
       * rather than an outline.
       *
       * Moved, not added, and that matters: the first attempt at this
       * put a NEW bay on the spur and left the old one where it was,
       * which quietly handed the starter ship a second free module —
       * "the empty bay is the first real refit decision" is what the
       * comment above this hull has always said, and two bays is not
       * a decision. Section 43 caught it on the next run. */
      { id:'r_hold',     type:'empty',    col:3, row:1, adjacent:['r_reactor'] },
    ],
    startSystems: ['engines','weapons','piloting','oxygen','reactor'],
    systemLevels: { oxygen: 2, weapons: 2, engines: 2 },
    startWeapons: ['laser_basic'],
    reactorLevel: 6,
    reactorMax: 12,
    weaponSlots: 1,
    cargoCols: 5, cargoRows: 3,
  }),

  /** Bought hull — Bastet's bigger sister: the same two-deck design
   *  with EIGHT bays instead of six, three of them starting empty. */
  hauler: buildHull({
    label: 'Hapi',
    spriteKey: 'ship_player',
    hullMax: 26,
    originX: 20, originY: 90, decks: 2, shaftAfter: [0],
    grid: [
      { id:'r_engines',  type:'engines',  col:0, row:0, adjacent:['r_weapons'] },
      { id:'r_weapons',  type:'weapons',  col:1, row:0, adjacent:['r_engines','r_hold1'] },
      { id:'r_hold1',    type:'empty',    col:2, row:0, adjacent:['r_weapons','r_hold2'] },
      { id:'r_hold2',    type:'empty',    col:3, row:0, adjacent:['r_hold1'] },
      { id:'r_piloting', type:'piloting', col:0, row:1, adjacent:['r_oxygen'] },
      { id:'r_oxygen',   type:'oxygen',   col:1, row:1, adjacent:['r_piloting','r_reactor'] },
      { id:'r_reactor',  type:'reactor',  col:2, row:1, adjacent:['r_oxygen','r_hold3'] },
      { id:'r_hold3',    type:'empty',    col:3, row:1, adjacent:['r_reactor'] },
    ],
    startSystems: ['engines','weapons','piloting','oxygen','reactor'],
    systemLevels: { oxygen: 2, weapons: 2, engines: 2 },
    startWeapons: ['laser_basic'],
    reactorLevel: 8,
    reactorMax: 14,
    weaponSlots: 1,
    cargoCols: 7, cargoRows: 5,
  }),

  /** Three decks and two lift trunks. The side bays on the top deck
   *  start EMPTY and become weapon modules at a station. */
  frigate: buildHull({
    label: 'Horus',
    spriteKey: 'ship_player',
    hullMax: 30,
    originX: 20, originY: 90, decks: 3, shaftAfter: [0, 1],
    grid: [
      { id:'r_engines',  type:'engines',  col:0, row:0, adjacent:['r_weapons'] },
      { id:'r_weapons',  type:'weapons',  col:1, row:0, adjacent:['r_engines','r_shields'] },
      { id:'r_shields',  type:'shields',  col:2, row:0, adjacent:['r_weapons'] },
      { id:'r_piloting', type:'piloting', col:0, row:1, adjacent:['r_oxygen'] },
      { id:'r_oxygen',   type:'oxygen',   col:1, row:1, adjacent:['r_piloting','r_medbay'] },
      { id:'r_medbay',   type:'medbay',   col:2, row:1, adjacent:['r_oxygen'] },
      { id:'r_crew1',    type:'empty',    col:0, row:2, adjacent:['r_reactor'] },
      { id:'r_reactor',  type:'reactor',  col:1, row:2, adjacent:['r_crew1','r_crew3'] },
      { id:'r_crew3',    type:'empty',    col:2, row:2, adjacent:['r_reactor'] },
    ],
    startSystems: ['engines','weapons','shields','piloting','oxygen','medbay','reactor'],
    systemLevels: { oxygen: 2, shields: 2, weapons: 2, engines: 2 },
    startWeapons: ['laser_basic'],
    reactorLevel: 8,
    reactorMax: 16,
    weaponSlots: 1,
    cargoCols: 6, cargoRows: 4,
  }),

  enemy_frigate: buildHull({
    label: 'Set',
    spriteKey: 'ship_enemy',
    hullMax: 20,
    originX: 20, originY: 90, decks: 2, shaftAfter: [0],
    grid: [
      { id:'r_engines',  type:'engines',  col:0, row:0, adjacent:['r_weapons'] },
      { id:'r_weapons',  type:'weapons',  col:1, row:0, adjacent:['r_engines','r_shields'] },
      { id:'r_shields',  type:'shields',  col:2, row:0, adjacent:['r_weapons'] },
      { id:'r_piloting', type:'piloting', col:0, row:1, adjacent:['r_oxygen'] },
      { id:'r_oxygen',   type:'oxygen',   col:1, row:1, adjacent:['r_piloting','r_reactor'] },
      { id:'r_reactor',  type:'reactor',  col:2, row:1, adjacent:['r_oxygen'] },
    ],
    startSystems: ['engines','weapons','shields','piloting','oxygen','reactor'],
    systemLevels: { oxygen: 2, shields: 2, weapons: 2, engines: 2 },
    startWeapons: ['laser_basic'],
    reactorLevel: 8,
    reactorMax: 12,
    weaponSlots: 1,
  }),

  /** TWO weapon bays — the hull elites favour. */
  enemy_gunship: buildHull({
    label: 'Sobek',
    spriteKey: 'ship_enemy',
    hullMax: 20,
    originX: 20, originY: 90, decks: 2, shaftAfter: [0],
    grid: [
      { id:'r_piloting', type:'piloting', col:0, row:0, adjacent:['r_reactor'] },
      { id:'r_reactor',  type:'reactor',  col:1, row:0, adjacent:['r_piloting','r_engines'] },
      { id:'r_engines',  type:'engines',  col:2, row:0, adjacent:['r_reactor'] },
      { id:'r_weapons',  type:'weapons',  col:0, row:1, adjacent:['r_weapons2'] },
      { id:'r_weapons2', type:'weapons',  col:1, row:1, adjacent:['r_weapons','r_oxygen'] },
      { id:'r_oxygen',   type:'oxygen',   col:2, row:1, adjacent:['r_weapons2','r_shields'] },
      { id:'r_shields',  type:'shields',  col:3, row:1, adjacent:['r_oxygen'] },
    ],
    startSystems: ['engines','weapons','shields','piloting','oxygen','reactor'],
    systemLevels: { oxygen: 2, shields: 2, weapons: 2, engines: 2 },
    startWeapons: ['laser_basic'],
    reactorLevel: 8,
    reactorMax: 14,
    weaponSlots: 2,
  }),

  enemy_raider: buildHull({
    label: 'Anubis',
    spriteKey: 'ship_enemy',
    hullMax: 20,
    originX: 20, originY: 90, decks: 2, shaftAfter: [0],
    grid: [
      { id:'r_weapons',  type:'weapons',  col:0, row:0, adjacent:['r_reactor'] },
      { id:'r_reactor',  type:'reactor',  col:1, row:0, adjacent:['r_weapons','r_engines'] },
      { id:'r_engines',  type:'engines',  col:2, row:0, adjacent:['r_reactor'] },
      { id:'r_shields',  type:'shields',  col:0, row:1, adjacent:['r_piloting'] },
      { id:'r_piloting', type:'piloting', col:1, row:1, adjacent:['r_shields','r_oxygen'] },
      { id:'r_oxygen',   type:'oxygen',   col:2, row:1, adjacent:['r_piloting'] },
    ],
    startSystems: ['engines','weapons','shields','piloting','oxygen','reactor'],
    systemLevels: { oxygen: 2, shields: 2, weapons: 2, engines: 2 },
    startWeapons: ['laser_basic'],
    reactorLevel: 8,
    reactorMax: 12,
    weaponSlots: 1,
  }),

  /** APOPHIS — a STATION, not a ship: no engines hung off the stern,
   *  no bow. Five decks of two bays, ten compartments, one trunk up
   *  the middle. It used to be six decks of 96x60 compartments, which
   *  was the only reason a third module size existed at all. */
  boss_station: buildHull({
    label: 'Apophis',
    spriteKey: 'ship_enemy',
    hullMax: 40,
    isStation: true,
    originX: 40, originY: 20, decks: 5, shaftAfter: [0],
    grid: [
      { id:'r_engines',  type:'engines',  col:0, row:0, adjacent:['r_medbay'] },
      { id:'r_medbay',   type:'medbay',   col:1, row:0, adjacent:['r_engines'] },
      { id:'r_reactor',  type:'reactor',  col:0, row:1, adjacent:['r_oxygen'] },
      { id:'r_oxygen',   type:'oxygen',   col:1, row:1, adjacent:['r_reactor'] },
      { id:'r_weapons3', type:'weapons',  col:0, row:2, adjacent:['r_shields'] },
      { id:'r_shields',  type:'shields',  col:1, row:2, adjacent:['r_weapons3'] },
      { id:'r_weapons',  type:'weapons',  col:0, row:3, adjacent:['r_weapons2'] },
      { id:'r_weapons2', type:'weapons',  col:1, row:3, adjacent:['r_weapons'] },
      { id:'r_piloting', type:'piloting', col:0, row:4, adjacent:['r_top'] },
      { id:'r_top',      type:'empty',    col:1, row:4, adjacent:['r_piloting'] },
    ],
    startSystems: ['engines','medbay','reactor','oxygen','weapons','shields','piloting'],
    systemLevels: { shields: 4, engines: 3, piloting: 2, oxygen: 2, medbay: 2, weapons: 2 },
    startWeapons: [],
    reactorLevel: 8,
    reactorMax: 20,
    weaponSlots: 3,
  }),
};

class Ship {
  /**
   * How far ABOVE the floor's walk line the console operator stands.
   *
   * Enough to read as "at the console" and — the part that matters for
   * input — to keep him off the exact middle of the room, so the floor
   * underneath him stays free for module orders. Clicking a crewman
   * always selects that crewman (that is the gesture players reach for
   * most), so ordering crew INTO a manned module means clicking the
   * part of it nobody is standing on. Sitting him high leaves most of
   * the room to click.
   */
  static get OPERATOR_LIFT() { return 14; }

  /**
   * @param {string}  layoutKey  - key into SHIP_LAYOUTS
   * @param {boolean} isPlayer
   * @param {number}  worldX     - ship world X origin
   * @param {number}  worldY     - ship world Y origin
   */
  constructor(layoutKey, isPlayer = true, worldX = 0, worldY = 0) {
    this.layoutKey = layoutKey;
    this.layout    = SHIP_LAYOUTS[layoutKey];
    if (!this.layout) throw new Error(`Unknown ship layout: ${layoutKey}`);

    this.isPlayer = isPlayer;
    this.worldX   = worldX;
    this.worldY   = worldY;

    this.label    = this.layout.label;
    this.hull     = this.layout.hullMax;
    this.hullMax  = this.layout.hullMax;

    // ── Build rooms ──────────────────────────────────────
    this.rooms = this.layout.rooms.map(cfg => new Room({
      ...cfg,
      x: worldX + cfg.x,
      y: worldY + cfg.y,
    }));

    // ── Build systems — ONE per system-type room ──────────
    // Multiple rooms of the same type (e.g. two 'weapons' modules)
    // each get their OWN independent system instance.
    this.systems = [];
    this.reactor  = new Reactor(this.layout.reactorLevel,
                                this.layout.reactorMax ?? 16);
    this.reactorHeat = 0;           // 0–100 (update92, REACTOR_HEAT_CONFIG)

    this.rooms.forEach(room => {
      if (room.type === 'empty' || !SYSTEM_DEFS[room.type]) return;
      const lvl = room.type === 'reactor'
        ? this.reactor.capacity
        : (this.layout.systemLevels ?? {})[room.type] ?? 1;
      const sys = new ShipSystem(room.type, lvl);
      this.systems.push(sys);

      // Link to room
      room.system = sys;
      this._fitSystemToRoom(sys, room);
    });

    // Link the reactor budget object to its room system —
    // from now on damage to the reactor ROOM = lost power.
    this.reactor.sys = this.getSystem('reactor');

    // Default power allocation
    this._allocateDefaultPower();

    /* ── Weapon mounts — ONE gun per weapon module room ────
     *
     * `weaponCargo` DELETED (update75). It was a bare list of gun keys
     * that weighed nothing, took no space and was drawn nowhere the
     * player could point at — a second warehouse standing beside the
     * grid hold, which already holds boxed guns as ordinary crates.
     *
     * Two lists for one thing drift, and this pair drifted in public:
     * a gun handed over by a surrendering crew went onto the rack and
     * the player never saw it; the station had to push a gun onto the
     * rack, box it, and then splice it back OFF the rack, three lines
     * of reconciliation for one move; and the shop drew the same gun
     * twice, once per list, with buttons to shuffle it between them.
     *
     * There is now exactly one answer to "where is that gun": BOLTED
     * ON, or IN A CRATE IN THE HOLD. */
    this.weapons     = [];

    /* ── The brig's cells. NOT crew, deliberately — see takePrisoner. */
    this.prisoners   = [];

    // ── Cargo hold ──────────────────────────────────────
    // A grid, not a list: salvage has a shape, so hull choice and hold
    // upgrades finally mean something. Sized by the layout. (cargo.js
    // may be absent in a stripped-down test — degrade, do not explode.)
    this.cargo = (typeof CargoGrid !== 'undefined')
      ? new CargoGrid(this.layout.cargoCols ?? 5, this.layout.cargoRows ?? 4)
      : null;

    // Slots = number of weapon MODULE rooms (boss may override upward)
    this.weaponSlots = Math.max(this.weaponRooms.length,
                                this.layout.weaponSlots ?? 0);
    this.layout.startWeapons.forEach((wk, i) => {
      this.installWeapon(wk, i);
    });

    // ── Crew ────────────────────────────────────────────
    this.crew = [];

    // ── Subsystems ──────────────────────────────────────
    this.oxygen   = new OxygenManager();
    this.rooms.forEach(r => this.oxygen.addRoom(r.id));

    this.fires    = new FireManager();
    /* WHAT LIVES IN THE DUCTS (update84): rats and spiders. NOT crew —
       see pests.js for why they were moved out of `this.crew`. */
    this.pests    = [];
    this.breaches = new BreachManager();
    // Expose breaches list directly for compatibility
    Object.defineProperty(this, 'breachesList', {
      get: () => this.breaches.breaches
    });

    // ── Elevators ────────────────────────────────────────
    this.elevators = new ElevatorManager();
    (this.layout.elevators ?? []).forEach(ev => {
      this.elevators.addShaft(ev.id, worldX + ev.x,
        ev.floors.map(fy => worldY + fy));
    });

    // Shafts are air columns: give each one an oxygen cell so open
    // shaft doors equalise O2 between the rooms on either side
    // (replaces the old direct doors that used to cross the shaft).
    this.elevators.shafts.forEach(s => this.oxygen.addRoom(`shaft_${s.id}`, { duct: false }));

    /* The split above ran before there were any lifts to keep power for
       (update90): now that there are, do it again. */
    this._allocateDefaultPower();

    // ── Doors between horizontally adjacent rooms ───────
    // If an elevator shaft sits in the gap between two rooms, they get
    // NO direct door — passage/airflow goes through the shaft's own
    // doors instead (a shaft and a room never share space).
    this.doors = [];
    const donePairs = new Set();
    this.rooms.forEach(room => {
      room.adjacent.forEach(adjId => {
        const other = this.getRoomById(adjId);
        if (!other || other.floor !== room.floor) return;
        const key = [room.id, other.id].sort().join('|');
        if (donePairs.has(key)) return;
        donePairs.add(key);
        if (this._shaftBetween(room, other)) return;   // shaft occupies the gap
        // Door at shared vertical edge, hung on the floor's door line
        const doorX = room.x < other.x ? room.x + room.w : other.x + other.w;
        const doorY = this.floorDoorY(room.floor, room.y + room.h * 0.5);
        // Only if rooms actually touch horizontally
        if (Math.abs((room.x + room.w) - other.x) < 30 ||
            Math.abs((other.x + other.w) - room.x) < 30) {
          this.doors.push(new Door(room.id, other.id, doorX, doorY));
        }
      });
    });

    // Elevator shaft doors — each shaft gets a door on BOTH sides
    // at every floor it serves (shaft is its own vertical module)
    this.elevators.shafts.forEach(shaft => {
      // Hand the shaft the line its doors sit on, so the landing plates
      // and the cabin are drawn level with them instead of a dozen
      // pixels lower on the crew walk line. Presentation only.
      shaft.setDoorYs?.(shaft.floorYs.map(fy =>
        this.floorDoorY(this.floorAtY(fy), fy)));
      // …and how far the hull runs, so the trunk spans the ship exactly
      // rather than by a constant tuned for one deck height.
      shaft.setExtent?.(Math.min(...this.rooms.map(r => r.y)),
                        Math.max(...this.rooms.map(r => r.y + r.h)));
      shaft.floorYs.forEach(fy => {
        // Find rooms adjacent to shaft on this floor (left and right)
        const floorIdx = this.floorAtY(fy);
        const onFloor  = this.rooms.filter(r => r.floor === floorIdx);
        const shaftDoorY = this.floorDoorY(floorIdx, fy);
        onFloor.forEach(room => {
          const touchesLeft  = Math.abs((room.x + room.w) - (shaft.x - shaft.width/2)) < 26;
          const touchesRight = Math.abs(room.x - (shaft.x + shaft.width/2)) < 26;
          if (touchesLeft) {
            this.doors.push(new Door(room.id, `shaft_${shaft.id}`,
              shaft.x - shaft.width/2, shaftDoorY, false));
          }
          if (touchesRight) {
            this.doors.push(new Door(room.id, `shaft_${shaft.id}`,
              shaft.x + shaft.width/2, shaftDoorY, false));
          }
        });
      });
    });

    // Airlocks — one on the outer wall of the leftmost and rightmost
    // room of each floor (FTL-style venting hatches)
    const floors = [...new Set(this.rooms.map(r => r.floor))];
    floors.forEach(f => {
      const onFloor = this.rooms.filter(r => r.floor === f);
      if (!onFloor.length) return;
      const leftmost  = onFloor.reduce((a, r) => r.x < a.x ? r : a);
      const rightmost = onFloor.reduce((a, r) => r.x + r.w > a.x + a.w ? r : a);
      const airY = this.floorDoorY(f, leftmost.y + leftmost.h * 0.5);
      this.doors.push(new Door(leftmost.id,  null, leftmost.x,               airY, true));
      if (rightmost.id !== leftmost.id) {
        this.doors.push(new Door(rightmost.id, null, rightmost.x + rightmost.w, airY, true));
      }
    });

    // ── In-flight projectiles ───────────────────────────
    this.projectiles = [];

    // ── Visual body = room bounding box ──────────────────
    const _b = this.roomBounds();
    this.spriteW = _b.w + 28;
    this.spriteH = _b.h + 28;

    // Shield visual
    this._shieldPulse = null;
    this._shieldAlpha = 0;

    // Destruction
    this.destroyed    = false;
    this._deathTimer  = 0;
    this._explosionTimer = new Utils.Interval(0.18);
  }

  // ── Accessors ────────────────────────────────────────────

  getSystem(type) { return this.systems.find(s => s.type === type) || null; }
  getRoomById(id) { return this.rooms.find(r => r.id === id) || null; }

  getAdjacentRooms(roomId) {
    const room = this.getRoomById(roomId);
    if (!room) return [];
    return room.adjacent.map(id => this.getRoomById(id)).filter(Boolean);
  }

  /** Elevator shaft standing in the horizontal gap between two rooms, or null */
  _shaftBetween(a, b) {
    if (!this.elevators) return null;
    const left  = a.x < b.x ? a : b;
    const right = a.x < b.x ? b : a;
    return this.elevators.shafts.find(s =>
      s.x >= left.x + left.w && s.x <= right.x) || null;
  }

  /** Both shaft-side doors open at the given room pair's floor? */
  _shaftChannelOpen(shaft, roomA, roomB) {
    const sid  = `shaft_${shaft.id}`;
    const near = (d, room) =>
      d.roomB === sid && d.roomA === room.id &&
      d.y > room.y - 6 && d.y < room.y + room.h + 6;
    const dA = this.doors.find(d => near(d, roomA));
    const dB = this.doors.find(d => near(d, roomB));
    return !!(dA && dB && dA.open && dB.open);
  }

  /**
   * Every same-floor neighbour, each tagged with whether the way in is
   * actually OPEN. Fire uses this (update42).
   *
   * `getOpenAdjacentRooms` below is the strict version and had exactly
   * zero callers: fire.js spread through walls unconditionally, so
   * shutting a door did nothing at all and the doors were decoration in
   * a fire. Heat DOES cross a shut bulkhead — just far more slowly —
   * so fire needs the whole list plus the state of each way through,
   * not a pre-filtered one.
   */
  adjacentThermal(roomId) {
    const room = this.getRoomById(roomId);
    if (!room) return [];
    const openIds = new Set(this.getOpenAdjacentRooms(roomId).map(r => r.id));
    return (room.adjacent ?? [])
      .map(id => this.getRoomById(id))
      .filter(r => r && r.floor === room.floor)
      .map(r => ({ room: r, open: openIds.has(r.id) }));
  }

  /** Adjacent rooms reachable through OPEN doors (fire spread uses this) */
  getOpenAdjacentRooms(roomId) {
    const room = this.getRoomById(roomId);
    if (!room) return [];
    return room.adjacent
      .map(id => this.getRoomById(id))
      .filter(r => {
        if (!r) return false;
        // Different floor — no door, fire cannot spread vertically
        if (r.floor !== room.floor) return false;
        const door = this.doors.find(d =>
          (d.roomA === roomId && d.roomB === r.id) ||
          (d.roomB === roomId && d.roomA === r.id));
        if (door) return door.open;
        // Rooms separated by an elevator shaft: fire crosses only
        // when BOTH shaft doors on this floor are open.
        const shaft = this._shaftBetween(room, r);
        if (shaft) return this._shaftChannelOpen(shaft, room, r);
        return true;  // genuinely touching, no door = open corridor
      });
  }

  /** Which floor index is at world Y? Returns -1 if outside */
  floorAtY(wy) {
    let best = -1, bestDist = Infinity;
    this.rooms.forEach(r => {
      if (wy >= r.y - 10 && wy <= r.y + r.h + 10) {
        const d = Math.abs(r.cy - wy);
        if (d < bestDist) { bestDist = d; best = r.floor; }
      }
    });
    return best;
  }

  /** Canonical door centre-line for a floor.
   *  EVERY hatch on a floor — interior, elevator and airlock — hangs
   *  here. Each door used to take the centre of whichever room spawned
   *  it, so rooms of different heights pushed their doors to different
   *  levels and the outer airlocks sat visibly off from the interior
   *  doors on every hull in the game. */
  floorDoorY(floorIndex, fallbackY = 0) {
    const roomsOnFloor = this.rooms.filter(r => r.floor === floorIndex);
    if (!roomsOnFloor.length) return fallbackY;
    /* The middle of the DOORWAY, which is the middle of the walkable
       compartment and not of the module (update73) — a hatch does not
       run up into the ceiling duct any more than a man does. Still
       deliberately a different line from `floorWalkY`: movement goes
       by the feet, doors and the lift cabin are drawn by this one,
       and confusing the two is the "empty trunk lower than the doors"
       bug from update34. */
    const top = Math.min(...roomsOnFloor.map(r => r.floorTop));
    const bot = Math.max(...roomsOnFloor.map(r => r.y + r.h));
    return (top + bot) / 2;
  }

  /* ── WHERE A MODULE SITS IN ITS ROOM (update73) ───────────
   *
   * Three copies of these six lines stood in this file — the hull
   * builder and both of the refit paths. Once the duct arrived all
   * three needed the same correction, which is three chances to
   * correct two of them. One method now.
   *
   * A system occupies the room's INTERIOR. The duct along the ceiling
   * is not part of the compartment, and the first screenshot of this
   * package showed exactly why it matters: the module badge was drawn
   * at `room.y + 3`, which is now inside the grille, so O₂ read as a
   * letter hidden behind a vent.
   */
  _fitSystemToRoom(sys, room) {
    sys.roomId = room.id;
    sys.roomX  = room.x;
    sys.roomY  = room.floorTop;
    sys.roomW  = room.w;
    sys.roomH  = room.floorH;
    sys.cx     = room.cx;
    sys.cy     = room.floorTop + room.floorH / 2;
  }

  /** Walking Y line for a floor (crew feet level).
   *
   *  Reads `walkOffset()` — the SAME function the lift stops are built
   *  from. It used to carry its own `0.65` written out longhand, which
   *  was the second copy of a number the grid already owned. */
  floorWalkY(floorIndex, fallbackY = 0) {
    const roomsOnFloor = this.rooms.filter(r => r.floor === floorIndex);
    if (!roomsOnFloor.length) return fallbackY;
    return roomsOnFloor[0].y + walkOffset();
  }

  get shieldBars() {
    const ss = this.getSystem('shields');
    return ss ? ss.shieldBars : 0;
  }

  get shieldMax() {
    const ss = this.getSystem('shields');
    return ss ? ss.shieldMax : 0;
  }

  get evasion() {
    const pilot = this.getSystem('piloting');
    const eng   = this.getSystem('engines');

    // FTL rule: no pilot in cockpit = no evasion at all. `alive` is the
    // one liveness test used throughout here — the old code mixed
    // `!dead && !dying` for the gate with a bare `!dead` for the bonus,
    // so a crewman bleeding out on the cockpit floor still flew the ship.
    const pilotRoom = pilot ? this.getRoomById(pilot.roomId) : null;
    // crewOperating: our own pilot, and only while nobody is fighting
    // him for the chair.
    const hasPilot = pilotRoom ? this.crewOperating(pilotRoom.id).length > 0 : false;
    if (!hasPilot) return 0;

    const pilotPct = pilot ? pilot.effectivePower() * Ship.EVADE_PILOT  : 0;
    const engPct   = eng   ? eng.effectivePower()   * Ship.EVADE_ENGINE : 0;
    const cloak    = this.getSystem('cloaking');
    // Cloak now gives a big evasion spike ONLY while actively cloaked.
    const cloakPct = (cloak && cloak.cloakActive) ? 0.60 : 0;

    // ── Crew skill bonuses ──
    // The pilots at the helm, AND the engine gang keeping the drive
    // responsive. Engine crew have always EARNED engines XP on every
    // dodge (see receiveHit) and CrewMember.engineBonus() has always
    // existed — but nothing ever called it, so levelling Engines paid
    // out exactly nothing in evasion. Terra crews even get double
    // engines XP, which made the dead end worse. The loop is closed now.
    // ONE pilot at the helm, ONE engineer at the drive console
    // (update43) — a crowded cockpit no longer stacks evasion.
    const helm     = this.consoleOperator(pilotRoom.id);
    const skillPct = helm ? helm.pilotBonus() : 0;
    const engRoom  = eng ? this.getRoomById(eng.roomId) : null;
    const engHand  = engRoom ? this.consoleOperator(engRoom.id) : null;
    const engSkill = engHand ? engHand.engineBonus() : 0;

    /* A COMMANDER'S ORDER, while it is running (update53). It goes
       through Commander.orderBonus like every other "what is the boss
       worth right now" question, and it is INSIDE the same clamp as
       everything else — an order that could push evasion past the cap
       would be a different rule for one source, which is how caps stop
       meaning anything. Only OUR hull: the accessor answers for the
       active commander, and the enemy has his own. */
    const order = (this.isPlayer && typeof Commander !== 'undefined'
                   && Commander.orderBonus) ? Commander.orderBonus('evasion') : 0;

    const cap = (cloak && cloak.cloakActive) ? 0.9 : 0.75;
    return Utils.clamp(pilotPct + engPct + cloakPct + skillPct + engSkill + order,
                       0, cap);
  }

  get hullPct() { return this.hull / this.hullMax; }

  // ── Crew helpers ─────────────────────────────────────────

  addCrew(member, keepPosition = false) {
    // Never add the same member twice (boarding recovery could
    // otherwise duplicate crew on the roster).
    if (this.crew.includes(member)) return;
    if (keepPosition) {
      // Caller already placed x/y/roomId precisely (e.g. a boarder
      // storming into the room they just breached) — don't scramble it.
      member.targetX = member.x;
      member.targetY = member.y;
      this.crew.push(member);
      return;
    }
    // Place each crew member in a different room (cycle through rooms)
    const idx  = this.crew.length % this.rooms.length;
    const room = this.rooms[idx] || this.rooms[0];
    if (room) {
      const [sx, sy] = this.stationSpot(room);
      member.x = sx;
      member.y = sy;
      member.roomId = room.id;
      // A recruit with no station never settles anywhere and reads as
      // "broken" to the player — give them the room they walked into.
      if (!member.homeRoomId) member.homeRoomId = room.id;
    } else {
      member.x = this.worldX + 100;
      member.y = this.worldY + 100;
    }
    member.targetX = member.x;
    member.targetY = member.y;
    this.crew.push(member);
  }

  /**
   * Assign home stations by priority:
   * cockpit → engines → shields → weapons → oxygen → medbay.
   * Prefers crew whose corporation matches the module.
   */
  assignStations() {
    // Weapons need a live OPERATOR per module now — stations cover
    // piloting first, then EVERY weapon room, then the rest.
    const prefer = { piloting:'pegasus', engines:'terra', shields:'aquarius', weapons:'phoenix' };
    // The cat does not stand watches.
    const unassigned = this.crew.filter(c => !c.dead && !c.isPet);
    const posts = [];
    const pilot = this.getSystem('piloting');
    if (pilot?.roomId) posts.push({ type:'piloting', roomId: pilot.roomId });
    this.weaponRooms.forEach(r => posts.push({ type:'weapons', roomId: r.id }));
    ['shields','engines','oxygen','medbay'].forEach(t => {
      const sys = this.getSystem(t);
      if (sys?.roomId) posts.push({ type: t, roomId: sys.roomId });
    });

    /* WHO GETS THE CONSOLE (update43).
       Since only the operator at slot 0 supplies the module's bonus,
       picking by CORPORATION alone would sit a Phoenix rookie at the
       gun while a mastered Aquarius gunner stood behind him doing
       nothing. Rank by the skill the post actually uses, and keep the
       corporation preference as the tiebreak it was always meant to
       be — a Terra crew still gravitates to the engine room. */
    const POST_SKILL = { piloting: 'piloting', engines: 'engines',
                         shields: 'shields',   weapons: 'weapons' };
    posts.forEach(post => {
      if (!unassigned.length) return;
      const skill = POST_SKILL[post.type];
      let idx = 0, bestScore = -1;
      unassigned.forEach((cand, i) => {
        const lvl   = skill ? cand.getSkillLevel(skill) : 0;
        const score = lvl * 10 + (cand.race === prefer[post.type] ? 1 : 0);
        if (score > bestScore) { bestScore = score; idx = i; }
      });
      const c = unassigned.splice(idx, 1)[0];
      const room = this.getRoomById(post.roomId);
      // Ask which SPOT is free, not how many heads are in there. The
      // head count once handed the first man into an empty module the
      // LEFT flank (because setting homeRoomId first counted him as an
      // occupant of his own room) and left the console unmanned.
      c.homeRoomId = post.roomId;
      if (room) c.moveToOnShip(this, ...this.stationSpot(room, null, c));
    });
  }

  /**
   * Where a crew member should STAND in a room.
   *
   *      empty room   →  the console, dead centre and a little high
   *      one already  →  the newcomer takes the LEFT of him
   *      two already  →  the third takes the RIGHT
   *
   * That order matters: walking into an empty module and standing off
   * to one side of the console looked like the man had missed his post,
   * which is why hitting RETURN (which sends everyone to room.cx/cy)
   * always "looked right" and ordinary orders did not.
   *
   * The old comment here warned that a crewman on the exact centre
   * swallowed every click aimed at the module. That was true when the
   * pick radius was 20px around a point 14px above his head; the
   * operator now stands OPERATOR_LIFT pixels above the walk line, up at
   * the console, which leaves the whole lower half of the room clear
   * for module clicks.
   */
  stationSpot(room, forCrew = null) {
    /* THE HEAD-COUNT BRANCH IS GONE (update79). This used to take an
       `occupants` number and answer `min(occupants, 2)` — a second way
       of picking a spot, by counting people instead of asking which
       spots are held. Nothing had called it with a number for many
       packages; both callers passed null and fell through to the line
       below. An unreachable second answer to a question that already
       has one is worse than no code, because the next person to read
       it believes there are two ways to place a man. */
    return this.stationSlot(
      room, this.freeStationSlot(room, forCrew ? [forCrew] : [],
                                 forCrew ? forCrew.isPlayer : this.isPlayer));
  }

  /**
   * HOW MANY PEOPLE FIT IN A MODULE, and it is per SIDE (update79).
   *
   * There used to be two answers to this and they disagreed. At home
   * the count filtered on `alive` alone, so two boarders standing in
   * your medbay meant you could send ONE medic — the intruders ate
   * your places. On the enemy hull the very same rule filtered on
   * `isPlayer`, so three of yours could walk into a room that already
   * held four defenders. Two rules, written out by hand at two click
   * sites, and the player met both of them in one fight.
   *
   * One rule now, and it is the player's: THREE A SIDE. A module holds
   * three of yours and three of theirs — six men in a brawl — and
   * neither side can lock the other out by standing there.
   *
   * Downed bodies do not count. A room with three wounded on its floor
   * used to read as full and silently refused every repair order, which
   * is how a breached, shot-out module could look unfixable.
   */
  roomSpaceFor(roomId, side, exclude = []) {
    /* AND A CAT IS NOT ONE OF THE THREE (update83). This counted every
       living body on the side, so the ship's cat sitting in the engine
       room cost you a mechanic. `takenStationSlots` — the other half of
       the same question, "who is holding a place in here" — has
       excluded animals since update43, so the two halves of one rule
       disagreed: the cat blocked an order without ever holding a spot
       for it. She has no station and no console; she does not take a
       place at one. */
    const here = this.crew.filter(c =>
      c && c.alive && !c.isPet && c.isPlayer === side && !exclude.includes(c) &&
      (c.roomId === roomId || c.homeRoomId === roomId)).length;
    return Math.max(0, Ship.ROOM_SLOTS - here);
  }

  /** Standing spots per side in one module. The one number. */
  static get ROOM_SLOTS() { return 3; }

  /** The i-th standing spot in a room: 0 = console, 1 = left, 2 = right. */
  stationSlot(room, i = 0) {
    const slot = [0, -1, 1][Utils.clamp(i, 0, Ship.ROOM_SLOTS - 1)];
    const x = Utils.clamp(room.cx + slot * 26, room.x + 14, room.x + room.w - 14);
    const y = this.floorWalkY(room.floor, room.cy)
            - (slot === 0 ? Ship.OPERATOR_LIFT : 0);
    return [x, y];
  }

  /** How close to a slot counts as standing on it. */
  static get SLOT_GRIP() { return 13; }

  /**
   * Which of the three standing spots in `room` is a crewman on (or
   * heading for)? -1 if he is somewhere else in the room entirely.
   */
  slotIndexAt(x, y, room, tol = Ship.SLOT_GRIP) {
    let best = -1, bd = tol;
    for (let i = 0; i < Ship.ROOM_SLOTS; i++) {
      const [sx, sy] = this.stationSlot(room, i);
      const d = Math.hypot(x - sx, y - sy);
      if (d < bd) { bd = d; best = i; }
    }
    return best;
  }

  /**
   * The set of spots in `room` that are spoken for.
   *
   * "Spoken for" means somebody is standing on it OR walking to it —
   * see CrewMember.destPoint. Counting heads instead of spots is what
   * used to stack crew: the count said "one man in here, you take slot
   * 1", but that man might himself be standing on slot 1 because the
   * room was busier when HE was sent.
   *
   * @param {Room} room
   * @param {CrewMember[]} exclude  people whose claim does not count
   * @param {boolean} residentsOnly  count only crew POSTED to this room —
   *        used to decide whether a stack is real. Somebody merely
   *        crossing the room stands in the way (so you do not walk into
   *        him) but he never owns the console and never evicts anyone.
   */
  takenStationSlots(room, exclude = [], residentsOnly = false,
                    side = this.isPlayer) {
    const taken = new Set();
    if (!room) return taken;
    this.crew.forEach(c => {
      if (!c.alive || c.isPet || exclude.includes(c)) return;
      /* A MAN COMPETES FOR SPOTS ONLY WITH HIS OWN SIDE (update79).
         This had no side filter at all, so an intruder standing on the
         console HELD slot 0 against your own crew — your gunner was
         shoved onto the flank of his own bay by the man who came to
         kill him. Now that six can share a module the filter is not
         cosmetic: without it the two sides would have three places
         between them and the loser of the race would stand nowhere. */
      if (c.isPlayer !== side) return;
      if (residentsOnly && c.homeRoomId !== room.id) return;
      // Only people who belong in, or are inside, this room can hold a
      // spot in it — somebody in another room is irrelevant.
      if (c.roomId !== room.id && c.homeRoomId !== room.id) return;
      const p = c.destPoint ? c.destPoint() : { x: c.x, y: c.y };
      const i = this.slotIndexAt(p.x, p.y, room);
      if (i !== -1) taken.add(i);
    });
    return taken;
  }

  /**
   * The best FREE spot in `room`: the console first, then the left
   * flank, then the right. Falls back to the right flank when all
   * three are held (the room is full and the caller should have
   * stopped earlier).
   */
  freeStationSlot(room, exclude = [], side = this.isPlayer) {
    const taken = this.takenStationSlots(room, exclude, false, side);
    for (let i = 0; i < Ship.ROOM_SLOTS; i++) if (!taken.has(i)) return i;
    return Ship.ROOM_SLOTS - 1;
  }

  /**
   * Hand out one free spot per crew member, in order.
   *
   * This is the ONLY correct way to place several people into the same
   * module at once: each pick has to see the picks made before it, or
   * the whole group lands on the console together.
   *
   * @returns {number[]} slot index per member of `movers`
   */
  allocStationSlots(room, movers = []) {
    /* A group order is always one side's, so the side is read off the
       men being moved rather than passed in as a fourth argument
       nobody would remember to give. */
    const side = movers.length ? movers[0].isPlayer : this.isPlayer;
    const taken = this.takenStationSlots(room, movers, false, side);
    return movers.map(() => {
      let i = 0;
      while (i < Ship.ROOM_SLOTS - 1 && taken.has(i)) i++;
      taken.add(i);
      return i;
    });
  }

  /**
   * OUR crew, able, in this room.
   *
   * The `isPlayer === this.isPlayer` filter is the important half and it
   * was missing entirely. `this.crew` holds everyone physically aboard —
   * including enemy boarders, who are added to the DEFENDING ship's
   * roster when they come through the airlock. Without the filter an
   * intruder standing in your weapons bay MANNED YOUR GUN, one in the
   * shield room sped up YOUR recharge and earned YOUR shields XP, one in
   * the medbay was healed by YOUR doctors, and one in the cockpit added
   * his piloting skill to YOUR evasion.
   */
  crewInRoom(roomId) {
    // Only fully-able crew count for manning/repairs — the downed
    // and the dead lie on the floor (see bodiesInRoom).
    return this.crew.filter(c =>
      c.roomId === roomId && c.alive && c.inRoom !== false &&
      c.isPlayer === this.isPlayer);
  }

  /**
   * A battle is beginning aboard this hull.
   *
   * Done HERE rather than in markCombatStart because CombatManager.begin
   * is the one place every fight passes through exactly once, for both
   * ships — game.js calls markCombatStart from three different places
   * and would have counted some battles twice.
   */
  onBattleStart() {
    // Every lock is a stranger's lock again: boarders work for the ship
    // a second time rather than strolling through last fight's holes.
    this.doors.forEach(d => d.resetHacks?.());
    // And everyone still standing has one more action on their record.
    this.crew.forEach(c => { if (c.alive) c.battles = (c.battles ?? 0) + 1; });
  }

  /** EVERYONE physically in the room, whoever's side they are on.
   *  Weapons fire, stun and fire burns do not care whose uniform you
   *  are wearing — only manning does. */
  occupantsOf(roomId) {
    return this.crew.filter(c => c.roomId === roomId && c.alive && c.inRoom !== false);
  }

  /** Hostiles from both sides sharing a room: nobody is working. */
  roomContested(roomId) {
    const here = this.occupantsOf(roomId);
    return here.some(c => c.isPlayer) && here.some(c => !c.isPlayer);
  }

  /**
   * Who is actually OPERATING the module in this room.
   *
   * A module with a fight going on in it is not being run: the crew are
   * swinging at each other, not flying the ship. A contested cockpit
   * gives no evasion, a contested weapons bay stops charging, contested
   * shields stop recharging — which is what makes boarding a way to shut
   * a ship down rather than only a way to chip at its hull.
   */
  /**
   * THE PEOPLE WORKING THIS MODULE.
   *
   * Empty for a CONTESTED room, and — since update45 — never the
   * cat. She is OURS, so the side check does not keep her out, and a
   * cat that mans the gun is not a joke the player would enjoy twice.
   */
  crewOperating(roomId) {
    if (this.roomContested(roomId)) return [];
    /* AND NOT A MAN WHOSE HANDS ARE FULL (update78). The busy clock
       is new and for one package nothing read it: a gunner could eat
       a ration and still be the gunner, a medic could be kneeling
       over a casualty and still be piloting. Standing in the room was
       the whole test, so "busy" was a word in the panel and nothing
       in the fight.
       This is the one place that answers "who is WORKING here", so it
       is the one place that has to know. The cost falls out of it
       everywhere at once — the gun goes quiet, the cyborg's +1 drops,
       the console mark leaves his row — because all three ask this. */
    return this.crewInRoom(roomId).filter(c => !c.isPet && !c.busy);
  }

  /**
   * WHO A POWERED MEDBAY TREATS (update54).
   *
   * Not `crewOperating` — that answers "who is WORKING here", and it
   * throws out the animals so the cat cannot man a gun. A medbay is
   * not a console: lying on the table is not a job, and the ship's cat
   * bleeds like everybody else. It used to be the only creature aboard
   * that could not be patched up anywhere, on the ship or at a station.
   *
   * The contested check stays, and it is the same one: a compartment
   * being fought over is not treating anybody. That is the ship-side
   * half of "the fight comes first, the bandages come after".
   *
   * Side is already settled by `crewInRoom`, so enemy boarders standing
   * in your medbay are not healed by it — and vermin, being nobody's
   * crew, are not either.
   */
  medbayPatients(roomId) {
    if (this.roomContested(roomId)) return [];
    /* ABLE AND DOWN ALIKE (update78). This returned `crewInRoom`,
       which is the ABLE only — so the one function in the file named
       for "who a powered medbay treats" left out the casualties lying
       on its floor, and the healing loop had to ask `bodiesInRoom`
       instead and therefore never touched anybody on his feet.
       Two lists, each missing half the patients, and between them the
       medbay could not do the job it is bought for. */
    return this.crew.filter(c =>
      c && !c.dead && c.roomId === roomId && c.inRoom !== false &&
      c.isPlayer === this.isPlayer);
  }

  /**
   * WHO IS ACTUALLY AT THE CONSOLE (update43).
   *
   * Every skill bonus a module grants — gunnery, shields, piloting,
   * engines — used to be the SUM over everyone standing in the room.
   * Three mastered gunners came to 0.9 and were stopped only by the
   * 0.75 clamp, which exists to keep `dt / 0` from killing the frame.
   * So the strongest move in the game was to shove three people into
   * one compartment: nobody designed that, and the player could not
   * see it. A module has ONE console (slot 0, the raised spot), and
   * the man sitting at it is the one working it.
   *
   * The other two in the room are not useless — they fight boarders,
   * put out fires and repair the module — they just do not make the
   * gun charge faster.
   *
   * Returns null for an empty or CONTESTED room, exactly like
   * crewOperating(), so an invaded compartment stops paying out.
   */
  consoleOperator(roomId) {
    const room = this.getRoomById(roomId);
    if (!room) return null;
    const manned = this.crewOperating(roomId);
    if (!manned.length) return null;
    return manned.find(c => this.slotIndexAt(c.x, c.y, room) === 0) || null;
  }

  /* SIDE MATTERS FOR BODIES TOO (update42). This used to return every
     downed body in the room regardless of whose it was, which is how
     your crew ended up stretchering enemy boarders to your medbay and
     your medbay healed them back onto their feet — mid-boarding. Pass
     `false` only where you genuinely mean "everyone lying here". */
  bodiesInRoom(roomId, ownSideOnly = true) {
    return this.crew.filter(c =>
      c.roomId === roomId && c.down && c.inRoom !== false &&
      (!ownSideOnly || c.isPlayer === this.isPlayer));
  }

  /** Called by Game whenever a new battle begins: unburied corpses
   *  start to ROT — and rotting corpses spread the plague. */
  markCombatStart() {
    this.crew.forEach(c => {
      if (!c.dead) return;
      c._deadCombats = (c._deadCombats ?? 0) + 1;
      if (c._deadCombats >= 1 && !c.decaying) {
        this._startDecay(c);
      }
    });
  }

  _startDecay(c) {
    if (c.decaying) return;
    c.decaying = true;
    if (this.isPlayer && typeof UI !== 'undefined') {
      UI.notify(c.isPlayer === this.isPlayer
        ? `${c.name}'s body is DECAYING — eject it or bag it.`
        : 'An enemy body is DECAYING on our deck — eject it or bag it.', 'alert');
    }
  }

  /* ══ WHAT TO DO WITH A BODY (update65) ═════════════════════
   *
   * Three answers, and the player gives them. The machinery that
   * carries people around is untouched — what changed is who decides
   * where a corpse goes. `bodyOrder` is that decision and the ONLY
   * thing that moves a dead man off the deck.
   */

  /** Can this body be treated / vented / bagged right now, and if not,
   *  why not? ONE function, so the menu greys exactly what the order
   *  would refuse — a button that looks live and then does nothing is
   *  the bug this shape exists to prevent. */
  bodyRefusal(body, act) {
    if (!body) return 'nobody there';
    if (act === 'treat') {
      if (body.dead) return 'he is dead';
      const med = this.getSystem('medbay');
      if (!med) return 'no medbay aboard';
      return null;
    }
    /* ── THE MEDKIT (update78) ────────────────────────────────
     * The one way to get a man back on his feet on a hull with no
     * medbay — which is most hulls, and both of the ones the player
     * starts in. It costs supplies, not a module. */
    if (act === 'medkit') {
      if (body.dead) return 'he is dead';
      if (!body.down && body.hp >= body.maxHp) return 'he is not hurt';
      if (!this.hasDoses(Ship.MEDKIT_DOSES)) {
        return `not enough medical supplies (needs ${Ship.MEDKIT_DOSES}, `
             + `you have ${this.doseCount()})`;
      }
      return null;
    }
    if (act === 'eject') {
      if (!body.dead) return 'he is still alive';
      /* NOT "is a hatch open" any more (update68) — the man carrying
         him opens one. The only thing that can refuse a burial now is
         a hull with no airlock at all. */
      if (!this.doors.some(d => d.isAirlock)) return 'no airlock on this hull';
      return null;
    }
    if (act === 'bag') {
      if (!body.dead) return 'he is still alive';
      /* NOT "is somebody standing there" any more (update68). The order
         SENDS a man, exactly like every other order on this ship — the
         player's words: "jeżeli mamy zaznaczonego załoganta i najedziemy
         na trupa i damy bag lub vent to on to zrobi niezależnie w którym
         jest module". What can still refuse it is having nobody free to
         send, and a hold with no room in it. */
      const hands = this.crew.some(c =>
        c && c.alive && c.isPlayer === this.isPlayer && !c.carrying);
      if (!hands) return 'nobody free to do it';
      if (!this.cargo) return 'no hold';
      const probe = CargoGrid.deserialise(this.cargo.serialise());
      if (!probe.add(Ship.bagKeyFor(body))) return 'no room in the hold';
      return null;
    }
    return 'unknown order';
  }

  /**
   * A BOARDER IN THE CELL BLOCK LETS THEM OUT (update72).
   *
   * No order, no button: walking in IS the rescue. Anything else would
   * be a second decision on top of the one the player already made —
   * he sent people across a vacuum to a hull with a brig on it, which
   * is the decision.
   *
   * What a freed man becomes is the trick that keeps this small: he
   * turns into one of OURS, standing on THEIR hull. The recovery that
   * brings a boarding party home already sweeps up every `isPlayer`
   * crewman left on the enemy ship, so the ride home, the docking, the
   * barracks and the report are all machinery that already exists. He
   * is not cargo, not a passenger list and not a second register —
   * he is a man on a deck, like everybody else in this game.
   */
  freeCaptives() {
    /* ONE GUARD, and it is `_breakingOut` — a man who has just kicked
       his own cell door open is not waiting to be rescued. An
       `isPlayer` early-out on top of it read as belt and braces and
       was really a mask: it made this filter unreachable on the only
       hull where the difference matters. */
    /* …and not a man still in a slab (update93): he is in no room, so
       nobody is standing with him. The bay has to let him go first. */
    const held = this.crew.filter(c => c.isPrisoner && c.alive && !c._breakingOut && !c.frozen);
    if (!held.length) return 0;
    let freed = 0;
    held.forEach(p => {
      const saviour = this.crew.find(c =>
        c.isPlayer && c.alive && !c.isPet && c.roomId === p.roomId);
      if (!saviour) return;
      p.isPrisoner = false;
      p.isPlayer   = true;
      p.rescued    = true;
      /* HIS OWN NAME AND HIS OWN CORPORATION. He was drawn in hostile
         red while he was theirs; the moment he is ours he is drawn as
         one of ours, because that is what he is. */
      if (p.race === 'hostile' && typeof CORP_KEYS !== 'undefined') {
        p.race = Utils.pick(CORP_KEYS);
      }
      p.homeRoomId = p.roomId;
      freed++;
      if (typeof UI !== 'undefined') {
        UI.notify(`${saviour.name} got the cell open — ${p.name} is with us.`, 'good');
      }
    });
    return freed;
  }

  /**
   * WHAT A LOOSE PRISONER DOES (update72).
   *
   * On somebody ELSE'S hull — an enemy's cell — nothing at all: he
   * waits to be found. On OURS he is a man who has just got the cell
   * door open, and the player's own decision was that he does not
   * fight: "uciekinier NIE WALCZY — biegnie do śluzy i ucieka".
   *
   * So: the nearest airlock, and out. He walks there like anybody
   * else, which is the whole point — a closed door stops him, and a
   * player who is watching can trap him in a compartment and have him
   * put back. That is why this is a WALK and not the line of text it
   * used to be: text cannot be interrupted.
   */
  _prisonerWalk(c, dt) {
    if (!c || !c.alive) return;
    if (!c._breakingOut) return;           // somebody else's prisoner: he sits
    const air = this.doors.filter(d => d.isAirlock)
      .sort((a, b) => Utils.dist(c.x, c.y, a.x, a.y) -
                      Utils.dist(c.x, c.y, b.x, b.y))[0];
    if (!air) return;                      // no way off this hull; he waits
    /* ── HE IS "THERE" WHEN HE IS IN THE AIRLOCK'S ROOM ───────
     *
     * Not "within 24 pixels of the hatch": an airlock is bolted to a
     * WALL, and the crew step-inside rule nudges anybody who reaches
     * one back into the compartment — so a radius around the door
     * turned into a man bouncing in and out of it, picking the lock
     * for one frame in thirteen and never finishing. The room he is
     * standing in does not flicker. */
    if (c.roomId === air.roomA || Utils.dist(c.x, c.y, air.x, air.y) < 24) {
      /* ── HE WORKS THE OUTER LOCK, LIKE ANY INTRUDER ─────────
       *
       * Not a free exit. He got the CELL open, so he can get this one
       * open too — but it costs him the same `Door.HACK_TIME` a
       * boarding party pays for a strange door, and that is the time
       * the player was promised: shut the hatch in his face and you
       * have seconds to get a hand to him and put him back.
       *
       * The same lock, the same clock, the same side ('enemy' — he is
       * not ours while he is running): no second mechanic for a door
       * that already knows how to be picked. */
      if (air.mode === 'open' && air.open) {
        this._prisonerGone(c);
      } else if (air.hackBy('enemy', dt)) {
        air.mode = 'open'; air.open = true;
      }
      return;
    }
    if (!c._waypoints?.length) c.moveToOnShip?.(this, air.x, air.y);
  }

  /** Off the hull for good — and back onto the board if he was on it. */
  _prisonerGone(c) {
    this.crew = this.crew.filter(k => k !== c);
    /* THE BOARD IS WRITTEN HERE, and only here — the moment he is off
       the hull. A man still walking the corridor has not escaped yet,
       and the update67 version wrote the poster the instant the cell
       door opened, which is why trapping him could never have meant
       anything. A prisoner who was never on the board goes up for the
       first time; `reWanted` has always known how to do both. */
    let poster = null;
    if (this.isPlayer && typeof Save !== 'undefined' && Save.reWanted) {
      poster = Save.reWanted({ wantedId: c.wantedId ?? null, name: c.name,
                               bounty: c.bounty, level: c.level, race: c.race });
    }
    if (this.isPlayer && typeof UI !== 'undefined') {
      UI.notify(poster
        ? `${c.name} is out the airlock and away — back on the board at ${poster.bounty} CC.`
        : `${c.name} is out the airlock and away.`, 'alert');
    }
    return poster;
  }

  /**
   * PUT HIM BACK (update72).
   *
   * The other half of making the escape a walk: a player who shut a
   * door in his face has caught him, and catching him has to be worth
   * something. One free cell and a powered brig, and he goes back in —
   * the same `takePrisoner` the fight uses, so a man re-taken is worth
   * exactly what he was worth before.
   */
  /**
   * WHAT THE BAY ITSELF SAYS NO TO — the half of the question that is
   * the same whoever is going in: is there a bay, is it lit, is there
   * a slab left.
   *
   * Written once (update77). `cellRefusal` and `freezeRefusal` had
   * three identical lines each; the first time one of them gained a
   * condition the two would have started answering differently about
   * the same module, which is the whole reason a convict and a
   * crewman spend the SAME capacity.
   */
  _slabRefusal() {
    const pod = this.getSystem('carbonite');
    if (!pod) return 'no carbonite bay on this hull';
    /* `isDisabled()` DELETED from here (update77). Since capacity is
       min(levels, power), a dark bay has no slabs at all — so that
       check could never be the reason any more and the player was
       being told "every slab is taken" about a module with nothing in
       it. The capacity is the honest question, and it answers for a
       shot-out bay and a browned-out one with the same sentence. */
    if (this.carboniteCapacity() <= 0) return 'the carbonite bay is cold — no power';
    if (this.freeCells() <= 0) return 'every slab is taken';
    return null;
  }

  cellRefusal(c) {
    if (!c || !c.isPrisoner || !c.alive) return 'nobody to lock up';
    return this._slabRefusal();
  }

  returnToCell(c) {
    const why = this.cellRefusal(c);
    if (why) return { ok: false, message: `Cannot jail: ${why}.` };
    const ok = this.takePrisoner({
      id: c.wantedId ?? c.id, name: c.name, bounty: c.bounty ?? 0,
      wantedId: c.wantedId ?? null,
    });
    if (!ok) return { ok: false, message: 'No free cell.' };
    this.crew = this.crew.filter(k => k !== c);
    return { ok: true, message: `${c.name} is back in the cell.` };
  }

  /** A cat is one cell, a man is two. Same tag, so one rule at the
   *  dock covers both — only the shape differs. */
  static bagKeyFor(body) { return body && body.isPet ? 'pet_bag' : 'body_bag'; }

  /**
   * Give the order. Returns {ok, message} like every other order in
   * this game, and refuses out loud rather than doing nothing.
   */
  orderBody(body, act, doer = null) {
    const why = this.bodyRefusal(body, act);
    if (why) return { ok: false, message: `Cannot ${act}: ${why}.` };

    /* WHO DOES IT. The man the player has selected, if he is fit for
       it; otherwise the nearest free hand. Every other order on this
       ship works that way and the player asked for this one to as
       well — before update68 BAG simply refused unless somebody
       already happened to be standing over the body. */
    const pick = (doer && doer.alive && doer.isPlayer === this.isPlayer &&
                  !doer.carrying && doer !== body)
      ? doer
      : this.crew.filter(c => c && c.alive && c.isPlayer === this.isPlayer &&
                              !c.carrying && c !== body)
          .sort((a, b) => Utils.dist(a.x, a.y, body.x, body.y) -
                          Utils.dist(b.x, b.y, body.x, body.y))[0];

    if (act === 'bag') {
      /* Already over him? Do it now. Otherwise walk him over and the
         ship finishes the job when he arrives. */
      if (pick && pick.roomId === body.roomId) return this._bagBody(body);
      if (!pick) return { ok: false, message: 'Nobody free to do it.' };
      body.bodyOrder = 'bag';
      pick._bagTargetId  = body.id;
      pick._errandRoomId = body.roomId;
      pick.moveToOnShip?.(this, body.x, body.y);
      return { ok: true, message: `${pick.name} is going for ${body.name}.` };
    }

    body.bodyOrder = act;
    /* AND HE WALKS. Setting the claim without sending him was the whole
       reason VENT looked dead in update67: the man was assigned and
       stayed exactly where he stood, because the only code that moved
       anybody was the automatic dispatch for bodies nobody was near. */
    if (pick) {
      pick._rescueId     = body.id;
      pick._errandRoomId = body.roomId;
      pick.moveToOnShip?.(this, body.x, body.y);
    }
    return { ok: true, message: act === 'treat'
      ? `${body.name} — stretcher on the way.`
      : `${pick ? pick.name : 'A hand'} is carrying ${body.name} to the airlock.` };
  }

  /* ══ THE ENEMY PLAYS BY THE SAME RULES (update93) ══════════
   *
   * The player's list, point 18: "wróg gra według tych samych zasad
   * (apteczki, ranni)". Everything that carries, bandages, doses and
   * vents already worked for both hulls — what the enemy never had was
   * somebody to GIVE the orders the player gives through the body menu.
   * This is that somebody, and it gives nothing but those orders:
   *
   *   • a man of theirs on the floor gets a MEDKIT while the hull has
   *     two doses and no lit ward (a lit ward is fetched to by the
   *     dispatch on its own, as on ours);
   *   • a man of theirs who is dead goes out the airlock after
   *     `AI_VENT_SECONDS` — no name, no bag, no burial; nobody on a
   *     pirate hull is bringing anybody home.
   *
   * Only the order is new. Who walks, who kneels, which hatch opens,
   * the doses spent and the time it takes are the same lines that do
   * it for the player, so the two sides cannot drift apart. */
  static get AI_VENT_SECONDS() { return 8; }

  /* ONE COUNTER, ticked by anything that hurts the player's side: a
     landed shot (`receiveHit`) and a blow from one of theirs
     (`CrewMember.strike`). Combat only compares it with the value it
     saw last, so nothing has to be reset between fights. */
  static noteHarmToPlayer() { Ship._harmToPlayer = (Ship._harmToPlayer ?? 0) + 1; }
  static harmToPlayer() { return Ship._harmToPlayer ?? 0; }

  _aiBodyOrders(dt) {
    if (this.isPlayer || this.isDerelict || this.isPreview) return;
    const own = c => c && c.isPlayer === this.isPlayer && !c.isPet && !c.isPrisoner &&
                     !c.frozen && !c.ejected;
    const ward = this._wardIsOpen();
    const airlock = this.doors.some(d => d.isAirlock);
    this.crew.forEach(c => {
      if (!own(c) || c.carriedBy) return;
      /* The box ran dry with the order still on him: withdraw it, or
         the medic sent for it would stand over him for good. */
      if (c.bodyOrder === 'medkit' && !this.hasDoses(Ship.MEDKIT_DOSES)) c.bodyOrder = null;
      if (c.dead) {
        /* ONLY A FREE HAND CARRIES HIM OUT (update93a). The player:
           "wróg wyrzuca ciało tylko wtedy, kiedy ma wolnego załoganta,
           tak jakby szedł naprawiać czy gasić pożar". So the AI picks
           the man the way it picks a repairer — idle, not the pilot,
           not the last gunner — and sends HIM; nobody else touches the
           body (the pickup below asks for his claim on this hull). No
           free hand, no burial: he lies there, and rots. */
        if (!airlock || !(c.decaying || (c._rotT ?? 0) >= Ship.AI_VENT_SECONDS)) return;
        if (this.crew.some(k => k && k.alive && k._rescueId === c.id)) return;
        const hand = this._aiFreeHand(c);
        if (!hand) return;
        c.bodyOrder = 'eject';
        hand._rescueId     = c.id;
        hand._errandRoomId = c.roomId;
        hand.moveToOnShip?.(this, c.x, c.y);
        return;
      }
      if (c.bodyOrder) return;
      if (c.down && !ward && this.hasDoses(Ship.MEDKIT_DOSES)) c.bodyOrder = 'medkit';
    });
  }

  /** A man the enemy can spare for an errand: the same rule its combat
   *  AI uses for a repair (combat.js, pickBest) — idle, not in the
   *  cockpit, not the last man on a gun, not already carrying or sent
   *  somewhere. Nearest to `near` first. */
  _aiFreeHand(near) {
    const pilotRoom = this.getSystem('piloting')?.roomId ?? null;
    const gunRooms = (this.weaponRooms ?? []).map(r => r.id);
    const gunners = this.crew.filter(k => k && k.alive && k.isPlayer === this.isPlayer &&
                                           gunRooms.includes(k.roomId));
    const lastGunner = gunners.length === 1 ? gunners[0] : null;
    return this.crew.filter(k => k && k.alive && k.isPlayer === this.isPlayer &&
        !k.isPet && !k.isPrisoner && !k.frozen && !k.carrying && !k._rescueId &&
        !k._bagTargetId && !k.stunned && k.task === TASK.IDLE &&
        k.roomId !== pilotRoom && k !== lastGunner && k !== near)
      .sort((a, b) => Utils.dist(a.x, a.y, near.x, near.y) - Utils.dist(b.x, b.y, near.x, near.y))[0] ?? null;
  }

  /* ── THE BITE AND THE EGG, BOTH ON A CLOCK (update69) ──────
   *
   * This used to live in game.js and fire once per WON FIGHT, which
   * made the whole thing a between-battles bookkeeping step: a man
   * could not turn at the gun, and an egg could not hatch in the
   * middle of a boarding action. The player asked for exactly that —
   * "czas jest liczony tylko podczas kontraktu, tak aby to moglo sie
   * stac w kazdym momencie walki".
   *
   * It lives HERE because this is the only clock that runs when the
   * ship is flying and stops when she is docked: the base does not
   * update the hull, so a contract is precisely the time that counts.
   * No second timer, no "are we in a run" flag to get out of step.
   */
  infectionTick(dt) {
    if (!this.isPlayer) return;

    // ── the bitten ──
    this.crew.forEach(c => {
      /* THE CLOCK STOPS IN THE SLAB (update77) — and it is a STOP, not
         a reset: `virusT` is left exactly where it stood, so he comes
         out as ill as he went in. Carbonite does not cure anybody. It
         buys the time to reach somewhere that can. */
      if (!c || !c.isPlayer || c.dead || c.frozen || !c.virus) return;
      const before = c.virusT ?? VIRUS_SECONDS;
      c.virusT = before - dt;
      // One warning at the halfway mark and one near the end — a line
      // every second would bury the log it is trying to warn from.
      [VIRUS_SECONDS / 2, 60].forEach(mark => {
        if (before > mark && c.virusT <= mark && typeof UI !== 'undefined') {
          UI.notify(`${c.name} is getting worse — ${Math.round(mark)}s left. `
                  + 'A research post can still cure it.', 'warn');
        }
      });
      if (c.virusT > 0) return;
      this._hatchFrom(c);
    });

    // ── the eggs ──
    (this.cargo?.items ?? []).filter(it => it.def?.tag === 'egg').forEach(egg => {
      const m = (egg.meta && typeof egg.meta === 'object') ? egg.meta : null;
      if (!m) { egg.meta = { hatchT: EGG_SECONDS }; return; }
      m.hatchT = (m.hatchT ?? EGG_SECONDS) - dt;
      if (m.hatchT > 0) return;
      this._splitEgg(egg);
    });
  }

  /**
   * HE DOES NOT LEAVE A BODY (update69).
   *
   * The old version killed him where he stood and then ALSO put an egg
   * in the hold, so the player had a corpse to bury and a case to sell
   * out of one man — "jak sie zamieni w jajko to nie ma ciala, znika".
   * There is one of him: what is left is the case.
   *
   * The memorial still gets his name, with the note that says what
   * happened to him, because the one thing worse than no gravestone is
   * a gravestone that cannot explain itself.
   */
  _hatchFrom(c) {
    const egg = this.cargo?.add('spider_egg', {
      name: c.name,
      /* WHERE HE FELL. The drawing reads this, so the case the player
         can see in the duct and the case in his hold are ONE item —
         sell it, or let the cat at it, and it is gone from both. */
      roomId: c.roomId,
      x: c.x,
      hatchT: EGG_SECONDS,
    });
    c.virus = false;
    c.hp = 0;
    c.state = 'dead';
    c.dead = true;
    /* THE NOTE ON THE STONE (update69). The memorial already prints
       "killed by …", so what happened to him goes THERE rather than
       into a field of its own — the player asked for "na cmentarzu
       tylko notatka co sie stalo, male info", and a second column for
       one sentence would be a register to keep in step for nothing. */
    c.killedBy = 'the void-spider virus — he left an egg case';
    c._waypoints = [];
    if (typeof Save !== 'undefined' && !c._graved) {
      Save.addToGraveyard?.(c);
      c._graved = true;
    }
    /* OFF THE DECK, NOT ONTO IT. `bagged` is the same flag a body bag
       uses: it says "he is no longer a thing lying in a room", which
       is what keeps the corpse rules, the airlock and the stretcher
       crew from finding a man who is not there any more. */
    c.bagged = true;
    this.crew = this.crew.filter(k => k !== c);
    if (typeof UI !== 'undefined') {
      UI.notify(egg
        ? `${c.name} did not make it — there is an egg case where he fell.`
        : `${c.name} did not make it, and the hold had no room for what came out of him.`,
        'alert');
    }
    return !!egg;
  }

  /** The case splits and they are loose aboard. */
  _splitEgg(egg) {
    const m = (egg.meta && typeof egg.meta === 'object') ? egg.meta : {};
    this.cargo.remove(egg);
    const home = this.getRoomById(m.roomId) ||
                 Utils.pick(this.rooms.filter(r => r.system)) || this.rooms[0];
    const n = Utils.randInt(1, 4);            // 1..3
    /* INTO THE DUCT IT WAS LYING IN (update84). They used to be dropped
       on the deck as hostile crew; the case is in the duct now, and so
       is what comes out of it. */
    for (let i = 0; i < n; i++) {
      this.addPest(new Pest({
        kind: 'spider', roomId: home?.id ?? null,
        x: home ? Utils.clamp((m.x ?? home.cx) + Utils.randFloat(-14, 14),
                              home.x + Pest.EDGE, home.x + home.w - Pest.EDGE) : 0,
      }));
    }
    if (typeof UI !== 'undefined') {
      UI.notify(`The egg case split open — ${n} spider${n > 1 ? 's' : ''} in the ducts!`,
                'alert');
    }
    if (typeof Audio !== 'undefined') Audio.sfx?.bossWarning?.();
    return n;
  }

  /** A man sent to bag a body finishes the job when he gets there. */
  bagArrivals() {
    this.crew.forEach(c => {
      if (!c || !c._bagTargetId || !c.alive) return;
      const body = this.crew.find(b => b && b.id === c._bagTargetId);
      if (!body || !body.dead) { c._bagTargetId = null; return; }
      if (c.roomId !== body.roomId) return;
      c._bagTargetId  = null;
      c._errandRoomId = null;
      const r = this._bagBody(body);
      if (!r.ok && this.isPlayer && typeof UI !== 'undefined') {
        UI.notify(r.message, 'warn');
      }
    });
  }

  /**
   * Bag him where he lies. No walk: the order already required a hand
   * in the room, so the man doing it is standing over the body — and
   * inventing a second carry destination for a job that happens on the
   * spot would have been a road with nothing at the end of it.
   */
  _bagBody(body) {
    /* ONE OF THEIRS (update93): a grave without a name. Not his name
       (nobody aboard knows it), not a bounty (nobody posted one) and
       not `crewBody` (he is not ours) — the dock buries him unmarked. */
    const theirs = body.isPlayer !== this.isPlayer;
    const it = this.cargo.add(Ship.bagKeyFor(body), theirs
      ? { name: 'Unknown', enemyBody: true, bounty: 0 }
      : {
      name: body.name,
      crewId: body.id,
      /* HIS OWN, not a bounty. The dock reads this to tell a man
         brought home for burial from a man brought in for money —
         one item, one rule at the till, two reasons to be in it. */
      crewBody: true,
    });
    if (!it) return { ok: false, message: 'No room in the hold.' };
    if (theirs) {
      body.bagged = true;
      this.crew = this.crew.filter(c => c !== body);
      if (this.isPlayer && typeof UI !== 'undefined') {
        UI.notify('An enemy body is bagged — he gets a grave without a name.', 'good');
      }
      return { ok: true, message: 'Enemy body bagged.' };
    }
    /* OFF THE DECK HERE, not by way of the `ejected` flag. Setting that
       would hand him to the airlock cleanup in `_updateBodies`, which
       would announce "body committed to space" over a man who is
       safely in the hold — and charge the venting karma for it. */
    body.bagged = true;
    this.crew = this.crew.filter(c => c !== body);
    if (this.isPlayer && typeof UI !== 'undefined') {
      UI.notify(`${body.name} is bagged and stowed. He comes home.`, 'good');
    }
    return { ok: true, message: `${body.name} bagged.` };
  }

  /** Is there anywhere to actually put a corpse right now?
   *  You cannot throw a body through a shut hatch (update42). */
  hasOpenAirlock() {
    return this.doors.some(d => d.isAirlock && d.mode === 'open');
  }

  /** Carry the wounded to the medbay, carry the dead to an airlock,
   *  rot unburied corpses onto the crew, remove the ejected. */
  _updateBodies(dt) {
    // Remove anyone who went out the airlock (self-ejected plague
    // victims and committed corpses alike) — the roster entry goes.
    const ejected = this.crew.filter(c => c.ejected);
    ejected.forEach(c => {
      if (c.carriedBy) c.carriedBy.carrying = null;
      if (this.isPlayer && typeof UI !== 'undefined') {
        UI.notify(c.dead ? (c.isPlayer === this.isPlayer ? `${c.name}'s body committed to space.`
                                                         : 'An enemy body is out the airlock.') :
                           `${c.name} walked out of the airlock…`, c.dead ? 'info' : 'alert');
      }
      /* ── THE PRICE OF THE AIRLOCK (update65) ────────────────
       *
       * Only for a body the player ORDERED out, and only his own
       * people — `bagged` men never come through here, and a plague
       * victim who walked out on his own is not a decision anybody
       * made. Karma is for what you do to those who cannot answer,
       * and this is the cheapest way to be rid of one of your own.
       */
      /* ONLY OUR OWN (update93): an enemy corpse thrown out of our
         airlock is a boarder, not a crewman denied his grave. */
      if (this.isPlayer && c.isPlayer && c.dead && c.bodyOrder === 'eject' &&
          typeof Commander !== 'undefined' && Commander.active && Commander.active()) {
        Commander.shift(Commander.active(), Ship.EJECT_KARMA);
        if (typeof UI !== 'undefined') {
          UI.notify(`No burial for ${c.name}. (${Ship.EJECT_KARMA} karma)`, 'warn');
        }
      }
      Particles.emit?.({ x: c.x, y: c.y, vx: this.isPlayer ? -60 : 60, vy: -10,
        ay: 0, color: '#aaccee', size: 3, sizeEnd: 0, life: 1, alpha: 0.8, alphaEnd: 0 });
    });
    if (ejected.length) this.crew = this.crew.filter(c => !c.ejected);

    const medbay = this.getSystem('medbay');
    const medRoom = medbay ? this.getRoomById(medbay.roomId) : null;

    const medPowered = medbay && medRoom && medbay.effectivePower() > 0;

    const medUsable = !!medRoom && !!medPowered;

    /* ── ROT IS A CLOCK NOW (update42) ────────────────────────
       Decay used to be a COMBAT COUNTER: a corpse only began to rot at
       the start of the NEXT fight. Combined with the pickup rule below
       — which hauled a corpse to the airlock the instant anybody walked
       into the room — that meant a body was always gone long before it
       could rot, and the entire plague subsystem never fired once in a
       real game. A corpse left aboard now starts to stink on its own. */
    this.crew.forEach(c => {
      if (!c.dead || c.decaying || c.ejected) return;
      c._rotT = (c._rotT ?? 0) + dt;
      if (c._rotT >= Ship.DECAY_SECONDS) this._startDecay(c);
    });

    /* ── BLEEDING OUT (update42) ─────────────────────────────
       A downed crew member used to lie there indefinitely. That was a
       soft-lock: the last enemy standing goes DOWN instead of dying,
       nobody on his ship is left to treat him, and the fight can never
       end. Being down is now a countdown — save them, or lose them. */
    this.crew.forEach(c => {
      if (c.dead || !c.down) { if (c._bleedT) c._bleedT = 0; return; }
      /* A BANDAGED MAN IS NOT ON A CLOCK ANY MORE (update78). He is
         still down, still helpless and still one hit from dead — he
         has simply stopped running out of time. */
      if (c._bandaged) { c._bleedT = 0; return; }
      /* AND NEITHER IS A MAN ON THE TABLE. A powered medbay is
         treatment; a clock that kept running while the ward worked on
         him would have been the ward losing a race against its own
         patient. Found by the test that carries a casualty across the
         ship: he arrived, and died on the table with the bay lit. */
      if (this._wardIsOpen() && c.roomId === this.getSystem('medbay')?.roomId) {
        c._bleedT = 0; return;
      }
      /* THE SHIP'S CAT SITS WITH HIM (update45). It cannot treat a
         wound — it is a cat — but a body somebody is beside is a body
         somebody notices, and the clock runs slower while it is there.
         40 s becomes about 66. This is what an animal does on the
         nine jumps out of ten when there are no rats to hunt. */
      const vigil = (typeof CAT_TUNING !== 'undefined' && this.petVigilOver(c))
        ? CAT_TUNING.VIGIL_FACTOR : 1;

      /* THE GOLDEN HOUR IS STAMPED WHEN HE FALLS (update49).
         The chip lengthens the window, but the spec is explicit that
         the length is fixed AT THE MOMENT of the wound: swinging the
         karma mid-fight must not reset, renew or shorten a clock that
         is already running over a man on the floor. So it is read
         once, here, on the first tick of the count. */
      if (!(c._bleedT > 0)) {
        c._bleedMax = Ship.BLEEDOUT_SECONDS
          + ((this.isPlayer && typeof Commander !== 'undefined')
             ? Commander.shipBonus('bleedout') : 0);
      }
      c._bleedT = (c._bleedT ?? 0) + dt * vigil;
      if (c._bleedT >= (c._bleedMax ?? Ship.BLEEDOUT_SECONDS)) {
        c._bleedT = 0;
        c.killOutright?.();
        if (this.isPlayer && typeof UI !== 'undefined') {
          UI.notify(`${c.name} bled out.`, 'alert');
        }
      }
    });

    const airOpen = this.hasOpenAirlock();

    /* THE ENEMY GIVES ITS OWN ORDERS (update93) — the same orders the
       player gives with the body menu, so everything below carries them
       out exactly as it does for ours. */
    this._aiBodyOrders(dt);

    // ── RESCUE DISPATCH ──────────────────────────────────────
    // Pickup below only ever triggers for a body in the SAME room, so a
    // crew member who went down somewhere else just bled out while the
    // rest of the ship carried on (the enemy pilot ignoring his downed
    // gunner). Send the nearest able hand to them — to carry them to a
    // medbay if the ship has one, or to patch them up on the spot if it
    // doesn't (most enemy hulls carry no medbay at all).
    {
      // Drop stale claims first (target rescued, dead or already lifted)
      this.crew.forEach(c => {
        if (!c._rescueId) return;
        const t = this.crew.find(b => b.id === c._rescueId);
        // A claim on a DECAYING corpse is a body-collection order and is
        // valid precisely because the target is dead (update42).
        const corpseRun = !!t && t.dead && t.bodyOrder === 'eject';
        /* ── THE JOB IS DONE WHEN THE BLEEDING STOPS (update78) ──
         *
         * The claim used to be released when the man GOT UP, which
         * was the only outcome field aid had. A bandage leaves him on
         * the floor, so that condition never came true and the medic
         * stood over him for the rest of the contract — his console
         * empty, his post forgotten. Found by the test that watches a
         * stretcher-bearer go back to work.
         *
         * A stretcher order (`treat`) and a medkit order are still
         * jobs, so they keep the claim; a plain bandage is finished. */
        const stillWanted = !!t && (t.bodyOrder === 'treat' || t.bodyOrder === 'medkit');
        const patched = !!t && t._bandaged && !stillWanted;
        if (!t || patched || (!corpseRun && (t.dead || !t.down)) || t.carriedBy || !c.alive) {
          c._rescueId = null;
          /* AND HIS POST IS HIS AGAIN (update69). The errand room is
             cleared with the claim that created it, so the moment the
             job is off him the idle walk below takes him back to the
             console he was assigned to. */
          c._errandRoomId = null;
        }
      });

      /* AND SOMEONE GOES TO FETCH A ROTTING BODY (update42).
         Corpse collection was purely opportunistic — a body was only
         ever lifted by somebody who happened to already be standing in
         its room — so a corpse in a compartment nobody visits rotted
         forever and the only cure was to walk a crew member there by
         hand. Opening an airlock is now an ORDER: it sends a hand to
         carry the thing out. */
      /* update65: the order is VENT, not the open hatch. Same dispatch,
         and it no longer waits for the body to start rotting either —
         the player has already said what he wants done. */
      this.crew.forEach(body => {
        if (this.isPlayer && body.dead && body.bodyOrder === 'eject' && !body.carriedBy &&
            !this.crew.some(c => c._rescueId === body.id) &&
            this.crewInRoom(body.roomId).length === 0) {
          const hand = this.crew
            .filter(c => c.alive && !c.carrying && !c._rescueId && !c.isPet &&
                         c.isPlayer === this.isPlayer &&
                         c.task !== TASK.REPAIR && c.task !== TASK.BREACH &&
                         c.task !== TASK.FIRE && c.task !== TASK.FIGHT)
            .sort((a, b) => Utils.dist(a.x, a.y, body.x, body.y) -
                            Utils.dist(b.x, b.y, body.x, body.y))[0];
          if (hand) {
            hand._rescueId     = body.id;
            hand._errandRoomId = body.roomId;
            hand.moveToOnShip(this, body.x, body.y);
          }
          return;
        }
        if (body.dead || !body.down || body.carriedBy) return;
        /* ── A BANDAGED MAN IS NOT AN EMERGENCY (update78) ─────
         *
         * The dispatch sends a hand to anybody who is DOWN, and with
         * field aid a man stopped being down as soon as he was
         * treated. He stays down now, so without this the ship sent
         * somebody to him again the moment the last one walked away —
         * for ever, one man permanently off his post per casualty.
         * Caught by the test that watches a stretcher-bearer go back
         * to his gun.
         *
         * A stretcher (`treat`) or a medkit is still a job worth
         * crossing the ship for, and so is a WORKING MEDBAY: that is
         * the only thing aboard that makes him whole, so a hull that
         * has one keeps fetching him. A hull that has not, and a man
         * who has stopped bleeding, is a man who can wait. */
        const wardOpen = !!medRoom && medPowered;
        if (body._bandaged && body.bodyOrder !== 'treat'
            && body.bodyOrder !== 'medkit' && !wardOpen) return;
        // Nobody runs across the ship to rescue an enemy boarder (update42).
        if (body.isPlayer !== this.isPlayer || body.isPet) return;
        if (body.roomId === medRoom?.id && medPowered) return;  // already being treated
        if (this.crewInRoom(body.roomId).length > 0) return;    // someone's there already
        if (this.crew.some(c => c._rescueId === body.id)) return;

        const helper = this.crew
          .filter(c => c.alive && !c.carrying && !c._rescueId &&
                       c.isPlayer === this.isPlayer && !c.isPet &&
                       c.task !== TASK.REPAIR && c.task !== TASK.BREACH &&
                       c.task !== TASK.FIRE && c.task !== TASK.FIGHT)
          .sort((a, b) => Utils.dist(a.x, a.y, body.x, body.y) -
                          Utils.dist(b.x, b.y, body.x, body.y))[0];
        if (!helper) return;
        helper._rescueId     = body.id;
        helper._errandRoomId = body.roomId;  // walk there; pickup/field aid takes over
        helper.moveToOnShip(this, body.x, body.y);
      });
    }

    this.crew.forEach(c => {
      if (!c.alive) return;
      /* THE ERRAND ENDS WHERE IT WAS DONE (update69). Nothing to
         carry, nobody claimed, and he is standing in the room he was
         sent to: the job is over and his own post is his again. One
         line, no timer, and it cannot leak — a man with no errand is
         simply a man at his station. */
      if (c._errandRoomId && !c.carrying && !c._rescueId && !c._bagTargetId &&
          c.roomId === c._errandRoomId) {
        c._errandRoomId = null;
      }
      /* ── A PRISONER HAS HIS OWN ONE JOB (update72) ───────────
       *
       * He does not repair, does not carry, does not man anything and
       * does not take orders — so he leaves this loop before any of
       * it. What he DOES do is his own three lines, below: sit still
       * in a cell that is not his, or, if this is the hull he has just
       * broken out of, walk to the nearest airlock and leave. */
      if (c.isPrisoner) { this._prisonerWalk(c, dt); return; }
      // Spiders are not a repair crew. They do not fix the wreck they
      // live in, do not haul bodies and do not man stations — they sit
      // in their rooms and kill whatever comes through the door.
      if (c.isPet) return;
      // An EXPLICIT emergency job outranks opportunistic body-hauling.
      // Without this, a crew member sent to seal a breach or fix a
      // module would scoop up a wounded body on arrival and walk off to
      // the medbay, so the damage never got repaired at all.
      const onEmergency = c.task === TASK.REPAIR || c.task === TASK.BREACH ||
                          c.task === TASK.FIRE;
      // Same reasoning for the room they're standing in: while it is
      // burning, holed or shot out, that work comes first — otherwise
      // they seal the breach and immediately wander off with a body,
      // leaving the module broken.
      const hereRoom = this.getRoomById(c.roomId);
      const roomBusy = !!hereRoom && (
        this.fires.getFiresInRoom(hereRoom.id).length > 0 ||
        this.breaches.hasBreachInRoom(hereRoom.id) ||
        (hereRoom.system && hereRoom.system.damagedLevels > 0));
      // Pick up a body sharing the room (wounded first) — but NOT a
      // wounded crew member already lying in a working medbay (that
      // caused the endless carry-back-and-forth jitter), and only if
      // there's actually somewhere useful to take them.
      if (!c.carrying && !onEmergency && !roomBusy) {
        /* THEIR DEAD TOO, once the player has said VENT (update93) —
           the order is what makes him ours to carry. Their living stay
           off our stretchers: `ownSideOnly` was the whole of that rule,
           and it is kept for everybody but a corpse with an order. */
        const body = this.bodiesInRoom(c.roomId, false)
          .filter(b => b.isPlayer === this.isPlayer || (b.dead && b.bodyOrder === 'eject'))
          .filter(b => !b.carriedBy)
          .filter(b => {
            /* NOBODY LIFTS A CORPSE WITH NOWHERE TO PUT IT (update42).
               This used to be an unconditional `return true`, so a body
               was scooped up and shoved through a SHUT airlock — the
               hatch never even opened. Now the player has to open one,
               which is also what finally lets a corpse sit long enough
               to rot. */
            /* A CORPSE GOES NOWHERE WITHOUT AN ORDER (update65).
               This used to be "is an airlock open?", which made the
               PLAYER'S HATCH the decision: open one to fight a fire and
               your dead were quietly thrown out with it. The decay
               alert told him to open an airlock and the game did the
               rest — so the one moment in the game where a body is
               still his to do something about passed without a
               question being asked.
               Now he says VENT and this carries it out. The wounded are
               untouched: they are still picked up and taken to the
               medbay on their own, because a man bleeding on the floor
               is not a decision, he is an emergency. */
            /* On the enemy's hull only the man it SENT lifts a corpse
               (update93a) — a gunner who happens to share the room
               stays on his gun. */
            if (b.dead) return b.bodyOrder === 'eject' && (this.isPlayer || c._rescueId === b.id);
            // wounded: skip if already in a powered medbay (healing)
            /* A MAN ALREADY IN THE WARD IS NOT CARGO (update69). The
               `medPowered` half of this made a DARK medbay a pickup
               spot: the bearer laid him down, the filter let him pick
               the same man straight back up, and the two of them
               shuffled on the spot forever. Whether the lamp is on
               decides whether he HEALS, never whether he is lifted
               again — and now that an errand no longer re-posts the
               bearer, that loop had nothing holding it back. */
            if (medRoom && b.roomId === medRoom.id) return false;
            // wounded: pointless to carry if there's no medbay at all
            return !!medRoom;
          })
          .sort((a, b) => (a.dead ? 1 : 0) - (b.dead ? 1 : 0))[0];
        if (body) { body.carriedBy = c; c.carrying = body; c._rescueId = null; }
      }
      const body = c.carrying;
      if (!body) return;
      // The body rides on the carrier's shoulders
      body.x = c.x; body.y = c.y - 10; body.roomId = c.roomId;
      /* A SURVIVOR OFF A WRECK IS CARRIED WHERE THE PLAYER SAYS (update90b)
         — to the docking hatch (game.js, _survivorTick) — not to whatever
         medbay this hull happens to have. */
      if (body._survivor) return;

      if (!body.dead) {
        // WOUNDED → medbay
        if (medRoom) {
          if (c.roomId === medRoom.id ||
              Utils.dist(c.x, c.y, medRoom.cx, medRoom.cy) < 30) {
            // Arrived: lay them down and STOP (carrier stays put so it
            // doesn't wander off and re-trigger a pickup next frame).
            body.carriedBy = null; c.carrying = null;
            body.x = medRoom.cx + Utils.randFloat(-16, 16);
            body.y = medRoom.cy + 10;
            body.roomId = medRoom.id;
            c._waypoints = [];
            /* HE STANDS STILL FOR A BEAT, THEN GOES BACK TO WORK
               (update69). Parking him here used to mean re-STATIONING
               him here: the man who carried one casualty in never
               returned to his gun. The errand holds him just long
               enough not to scoop the same body up again next frame,
               and `_errandDone` hands his own post back to him. */
            c._errandRoomId = medRoom.id;
          } else if (!c._waypoints.length) {
            c.moveToOnShip(this, medRoom.cx, medRoom.cy);
          }
        }
      } else {
        /* ── DEAD → THE NEAREST AIRLOCK, AND HE WORKS IT HIMSELF
         *    (rebuilt update68)
         *
         * This used to need an airlock the PLAYER had already opened,
         * which made VENT look broken: you gave the order, nothing
         * happened, and the row sat greyed out with no way to guess
         * that the hatch was the missing half. The player's words:
         * "powinno być wyrzuć ciało i wtedy podnosi i zanosi do
         * najbliższego vent, najpierw go otwiera, wyrzuca ciało a
         * następnie zamyka".
         *
         * So the order is now the WHOLE job: walk, open, put him out,
         * shut it again. Any airlock will do — the man carrying the
         * body is the one who opens it.
         *
         * Shutting it again matters: an airlock left open vents the
         * room it is attached to, and a player who asked for a burial
         * did not ask to lose the air in his cargo hold. */
        const air = this.doors.filter(d => d.isAirlock)
          .sort((a, b) => Utils.dist(c.x, c.y, a.x, a.y) -
                          Utils.dist(c.x, c.y, b.x, b.y))[0];
        if (air) {
          c._ejectWaitT = 0;
          if (Utils.dist(c.x, c.y, air.x, air.y) < 26) {
            if (air.mode !== 'open') {
              // Arrived with the body: crack the hatch and wait a beat.
              air.mode = 'open'; air.open = true;
            } else {
              body.ejected = true;
              body.carriedBy = null; c.carrying = null;
              /* AND SHUT IT BEHIND HIM. Only the hatch this order
                 opened — `_ventedBy` marks it, so a hatch the player
                 opened himself to fight a fire is left exactly as he
                 set it. */
              if (c._ventOpened === air.id) { air.mode = 'closed'; air.open = false; }
              c._ventOpened = null;
            }
            if (air.mode === 'open' && c._ventOpened == null) c._ventOpened = air.id;
          } else if (!c._waypoints.length) {
            c.moveToOnShip(this, air.x, air.y);
          }
        } else {
          // A hull with no airlock at all. Put him down rather than
          // stand there holding him forever.
          c._ejectWaitT = (c._ejectWaitT ?? 0) + dt;
          if (c._ejectWaitT >= Ship.CORPSE_HOLD_SECONDS) {
            c._ejectWaitT = 0;
            body.carriedBy = null; c.carrying = null; c._waypoints = [];
          }
        }
      }
    });

    /* ══ THE MEDBAY'S OWN JOB (update78) ════════════════════════
     *
     * Two things changed and together they are the whole reason to buy
     * one.
     *
     * IT IS THE ONLY MEDBAY LOOP NOW. There were two: this one, which
     * healed the men on the FLOOR, and one inside `ShipSystem.update`,
     * which healed the ones on their FEET. Two halves of one patient
     * list in two files, at two rates, agreeing only by accident —
     * and `medbayPatients`, the one function named for the answer,
     * was wired to neither of them.
     *
     * AND IT IS WHAT MAKES A MAN WHOLE. Field aid used to end with the
     * same sentence this loop ends with — up at 30% — so the module
     * was a faster bandage. A bandage stops the bleeding, a medkit
     * gets him up, and only this heals him to full.
     */
    /* THE CURE CLOCK RUNS OVER EVERYBODY, not only over the men in the
       ward (update82). It has to: the clock is reset by LEAVING, and a
       loop that only visits the patients never visits the man who just
       walked out — his half-finished course would sit on him until he
       came back, which is exactly the instalment plan this is not. */
    const inWard = (medbay && medRoom && medbay.effectivePower() > 0)
      ? this.medbayPatients(medRoom.id) : [];
    this.crew.forEach(c => this._cureTick(c, dt, inWard.includes(c)));

    if (medbay && medRoom && medbay.effectivePower() > 0) {
      inWard.forEach(b => {
        if (!b || b.dead) return;
        if (b.hp >= b.maxHp) return;
        b.hp = Math.min(b.maxHp, b.hp + Ship.MEDBAY_HPS * dt * medbay.effectivePower());
        if (b.down && b.hp >= b.maxHp * Ship.MEDKIT_SHARE) {
          b.state = 'ok';
          b._bleedT = 0;
          b._bandaged = false;
          b.bodyOrder = null;
          if (this.isPlayer && typeof UI !== 'undefined') {
            UI.notify(`${b.name} is back on their feet!`, 'good');
          }
        }
      });
    }

    /* ══ FIELD AID IS A BANDAGE, NOT A CURE (update78) ══════
     *
     * It used to heal 2.2 HP/s and STAND HIM UP at 30% — which is the
     * same sentence the medbay's own loop ends with, three times
     * slower. Two things doing one job means the expensive one does
     * not exist: a medbay was a faster bandage and nothing else.
     *
     * A bandage now does exactly what a bandage does. It STOPS THE
     * BLEEDING and leaves him on the floor. Getting him back on his
     * feet is a MEDKIT (any hull) or the MEDBAY (if you have one) —
     * see `_finishMedkit` and the medbay loop above.
     *
     * AND IT COSTS A DOSE. The player's call, and the reason is the
     * whole bleed-out clock: free automatic aid meant the clock never
     * ran out on anybody who fell within reach of a crewmate, so it
     * was a rule that almost never fired. Supplies turn it into the
     * question it was always meant to be — who do I spend the last
     * dose on.
     */
    this.crew.forEach(body => {
      if (body.dead || !body.down || body.carriedBy) return;
      /* NOBODY BANDAGES THE MAN WHO CAME TO BOARD HIM (update54).
         `crewInRoom` below is side-filtered, but this loop walks
         `this.crew`, which holds BOTH sides while a boarding action is
         on — so a downed enemy lying on our deck was quietly patched
         back up by our own hands, and ours by theirs on their hull. */
      if (body.isPlayer !== this.isPlayer) return;
      /* AND NOBODY KNEELS DOWN IN THE MIDDLE OF A FIGHT (update54).
         The same predicate `crewOperating` uses to refuse to man a
         console mid-brawl, so "a fight stops the room's other work" is
         one rule in one place. */
      if (this.roomContested(body.roomId)) return;
      const medic = this.crewInRoom(body.roomId)
        .find(c => !c.carrying && !c.isPet && !c.busy && c !== body);
      if (!medic) return;

      /* THE PLAYER ASKED FOR A MEDKIT ON THIS MAN. Same loop, same
         pair of hands, a different box: the order rides on `bodyOrder`
         exactly like BAG and EJECT do, so there is ONE place that
         knows "a free hand is standing over a casualty" and the order
         decides what he does with them. */
      if (body.bodyOrder === 'medkit' && this.hasDoses(Ship.MEDKIT_DOSES)) {
        this._startBusy(medic, 'medkit', body.id);
        return;
      }
      if (body._bandaged) return;

      /* NO SUPPLIES, NO BANDAGE — and said once, when it matters,
         rather than every frame he lies there. */
      if (!this.hasDoses(Ship.AID_DOSES)) {
        if (this.isPlayer && !body._noAidWarned && typeof UI !== 'undefined') {
          body._noAidWarned = true;
          UI.notify(`No medical supplies for ${body.name} — he is still bleeding.`, 'alert');
        }
        return;
      }
      this._startBusy(medic, 'aid', body.id);
    });

    /* ── THE PLAGUE TRAVELS THROUGH THE VENTS (update42) ──────
       Infection used to reach only `crewInRoom(body.roomId)` — stand
       one door away and you were untouchable, which made the plague a
       non-event. A ship shares one air loop, so a rotting body taints
       the whole hull: fast in the room it lies in, slowly everywhere
       else, and the ship-wide half only while life support is actually
       circulating air. Cutting oxygen contains the outbreak — at the
       obvious price. */
    const vents = (this.getSystem('oxygen')?.effectivePower() ?? 0) > 0;
    const rotting = this.crew.filter(b => b.dead && b.decaying);
    if (rotting.length) {
      const rotRooms = new Set(rotting.map(b => b.roomId));
      const n = rotting.length;
      /* ── ALONG THE DUCTS (update93a) ─────────────────────────
         The player: "mamy wentylację, to choroba zakaźna powinna się w
         miarę łatwo rozprzestrzeniać przez wentylację". Since update90
         the ship HAS a duct network (`ductLinks` — duct to duct past
         every door and up and down the lift shafts), so the air carries
         it the way it carries smoke: the nearer along the ducts, the
         surer. Hops are counted once per frame from the rotting rooms;
         with life support dark nothing moves in the ducts and the
         plague stays in the room it lies in. */
      const hops = new Map();
      if (vents) {
        const queue = [...rotRooms].filter(Boolean);
        queue.forEach(id => hops.set(id, 0));
        for (let qi = 0; qi < queue.length; qi++) {
          const id = queue[qi], d = hops.get(id);
          this.ductLinks(id).forEach(l => {
            if (!l.room || hops.has(l.room.id)) return;
            hops.set(l.room.id, d + 1);
            queue.push(l.room.id);
          });
        }
      }
      const R = Ship.PLAGUE_VENT_RATES;
      this.crew.forEach(c => {
        if (c.infected || !c.alive || c.isPet) return;
        if (c.isPlayer !== this.isPlayer) return;
        const near = rotRooms.has(c.roomId);
        const h = hops.get(c.roomId);
        const rate = near ? Ship.PLAGUE_RATE_ROOM
                   : vents ? (h != null ? R[Math.min(h, R.length) - 1] : Ship.PLAGUE_RATE_VENT)
                   : 0;
        if (rate <= 0) return;
        if (Math.random() < dt * rate * n) {
          c.infected = true;
          if (this.isPlayer && typeof UI !== 'undefined') {
            UI.notify(near ? `${c.name} caught the corpse plague! ☣`
                           : `${c.name} caught the plague through the VENTS! ☣`, 'alert');
          }
        }
      });
    }
  }

  /** Instantly charge shields to full (used at combat start) */
  prechargeShields() {
    const ss = this.getSystem('shields');
    if (!ss) return;
    const layers = Math.floor(ss.effectivePower() / (ss.def.powerPerLayer ?? 2));
    ss._shieldMax  = layers;
    ss._shieldBars = layers;
    ss._shieldTimer = 0;
    // A bubble knocked down LAST fight is not a lesson owed in this
    // one — the debt starts every battle at zero (update44).
    ss._shieldDebt = 0;
  }

  /** World Y of a deck's top edge. */
  _deckY(row) {
    const r = this.rooms.find(o => o.floor === row);
    return r ? r.y : this.roomBounds().y;
  }

  /**
   * THE EXTERIOR TILE SLOTS (update41).
   *
   * The hull is assembled like LEGO, one row per deck:
   *
   *     [engine][module][module][shaft][module][module][prow]
   *
   * The modules and the shaft are the interior, and the engine and the
   * prow are exterior tiles hung off either end — one per deck, every
   * deck the same. These two methods say exactly where they go, so the
   * art can be dropped in without anybody re-deriving the geometry.
   *
   * A STATION has neither: Apophis does not go anywhere.
   */
  engineSlots() {
    if (this.layout.isStation) return [];
    const G = HULL_GRID, b = this.roomBounds();
    // The stern faces AWAY from the enemy: left for you, right for them.
    const x = this.isPlayer ? b.x - G.ENGINE_W : b.x + b.w;
    const out = [];
    for (let row = this.layout.floors - 1; row >= 0; row--) {
      out.push({ x, y: this._deckY(row), w: G.ENGINE_W, h: G.MODULE_H,
                 deck: row, flip: !this.isPlayer });
    }
    return out;
  }

  /**
   * The bow, one tile per deck. Unlike the engine these are NOT all the
   * same tile: a nose is a taper, so the slice you need depends on how
   * tall the hull is and where in it you are —
   *
   *     1 deck   solo
   *     2 decks  top, bot
   *     3 decks  top, mid, bot
   *
   * `slice` names the tile to draw; `decks` names the set it comes from.
   */
  prowSlots() {
    if (this.layout.isStation) return [];
    const G = HULL_GRID, b = this.roomBounds();
    const decks = this.layout.floors;
    const x = this.isPlayer ? b.x + b.w : b.x - G.PROW_W;
    const out = [];
    for (let row = decks - 1; row >= 0; row--) {
      const slice = decks === 1 ? 'solo'
                  : row === decks - 1 ? 'top'
                  : row === 0 ? 'bot' : 'mid';
      out.push({ x, y: this._deckY(row), w: G.PROW_W, h: G.MODULE_H,
                 deck: row, decks, slice, flip: !this.isPlayer });
    }
    return out;
  }

  /** Weapon module rooms in slot order (slot i ↔ i-th weapons room) */
  get weaponRooms() {
    return this.rooms.filter(r => r.type === 'weapons');
  }

  /**
   * WHICH MODULE IS THIS GUN BOLTED INTO? (update60)
   *
   * A gun used to find its module by POSITION: `weaponRooms[slot]`,
   * where `weaponRooms` is `rooms.filter(type === 'weapons')` — a list
   * that is rebuilt from the room table every time it is read. Nothing
   * anchored a gun to a place; the pairing was an accident of ordering.
   * Add a weapons module in a room that sorts EARLIER than an existing
   * one and every gun aboard silently starts drawing power and crew
   * from somebody else's bay. No current hull can do it (checked all
   * three: none has an empty room before its weapons room), which is
   * exactly what makes it the kind of trap that goes off years later,
   * on the first layout somebody adds.
   *
   * A gun now remembers its ROOM. The fallback to the old positional
   * rule stays for two real cases: a save written before update60, and
   * the boss hulls, which mount more guns than they have bays.
   */
  weaponRoomFor(w) {
    if (!w) return null;
    if (w.roomId) {
      const room = this.getRoomById(w.roomId);
      if (room && room.type === 'weapons') return room;
    }
    return this.weaponRooms[w.slot] ?? null;
  }

  /** The weapon system powering slot i (its own module room).
   *  Kept slot-based for the boss overflow path; everything that has a
   *  WEAPON in hand should go through weaponRoomFor instead. */
  weaponSystemFor(slot) {
    return this.weaponRooms[slot]?.system ?? null;
  }

  /** Charge bonus for a SPECIFIC weapon: the gunner AT ITS CONSOLE.
   *  Used to sum over everyone in the bay — see consoleOperator(). */
  weaponCrewBonusFor(slot) {
    // Resolve through the GUN when there is one in this slot, so the
    // bonus comes from the bay the gun is actually in (update60).
    const room = this.weaponRoomFor(this.weapons[slot]) ?? this.weaponRooms[slot];
    if (!room) return 0;
    const gunner = this.consoleOperator(room.id);
    return gunner ? gunner.weaponChargeBonus() : 0;
  }

  weaponCrewBonus() {   // legacy aggregate (kept for compatibility)
    return this.weapons.reduce((a, w, i) =>
      Math.max(a, w ? this.weaponCrewBonusFor(i) : 0), 0);
  }

  // ── Weapons ──────────────────────────────────────────────

  /** ONE gun per weapon module. Fails if the slot is occupied or
   *  there is no module room for it (boss ships may override slots). */
  installWeapon(defKey, slot) {
    if (slot >= this.weaponSlots) return false;
    if (this.weapons[slot]) return false;
    const w = new Weapon(defKey, slot);
    // The bay it is being bolted into, remembered on the gun (update60).
    w.roomId = this.weaponRooms[slot]?.id ?? null;
    this.weapons[slot] = w;
    this._reallocWeaponPower();
    return true;
  }

  /** STATION UPGRADE: convert the first empty room into a brand-new
   *  MODULE of the given type (level 1 system). Weapons cap at 3 per
   *  hull; other module types cap at 1. */
  addModule(type) {
    type = systemType(type);      // an old save may still say 'brig'
    if (!SYSTEM_DEFS[type]) return false;
    if (type === 'weapons') {
      if (this.weaponRooms.length >= 3) return false;
    } else if (this.getSystem(type)) {
      return false;   // only one cloak / repair bay etc.
    }
    const room = this.rooms.find(r => r.type === 'empty');
    if (!room) return false;
    room.type = type;
    // Some modules are worthless at one pip — shields need a whole
    // 2-power layer before they can raise anything at all.
    const sys = new ShipSystem(type, SYSTEM_DEFS[type].startLevel ?? 1);
    sys.power = 0; sys.desiredPower = 0;   // new modules start UNPOWERED
    room.system = sys;
    this._fitSystemToRoom(sys, room);
    this.systems.push(sys);
    this._extraModules = this._extraModules ?? [];
    this._extraModules.push(type);
    if (type === 'weapons') {
      this.weaponSlots = Math.max(this.weaponSlots, this.weaponRooms.length);
    }
    return true;
  }

  addWeaponModule() { return this.addModule('weapons'); }

  /** Same as addModule, but into a SPECIFIC empty room chosen by the
   *  player on the station's ship diagram. */
  addModuleAt(type, roomId) {
    type = systemType(type);      // an old save may still say 'brig'
    if (!SYSTEM_DEFS[type]) return false;
    if (type === 'weapons') {
      if (this.weaponRooms.length >= 3) return false;
    } else if (this.getSystem(type)) {
      return false;
    }
    const room = this.getRoomById(roomId);
    if (!room || room.type !== 'empty') return false;
    room.type = type;
    // Some modules are worthless at one pip — shields need a whole
    // 2-power layer before they can raise anything at all.
    const sys = new ShipSystem(type, SYSTEM_DEFS[type].startLevel ?? 1);
    sys.power = 0; sys.desiredPower = 0;   // new modules start UNPOWERED
    room.system = sys;
    this._fitSystemToRoom(sys, room);
    this.systems.push(sys);
    this._extraModules = this._extraModules ?? [];
    this._extraModules.push({ type, roomId });
    if (type === 'weapons') {
      this.weaponSlots = Math.max(this.weaponSlots, this.weaponRooms.length);
    }
    return true;
  }

  /* ══ THE BRIG (update63) ═══════════════════════════════════
   *
   * A prisoner is NOT crew and never goes in `crew`. That list is
   * walked by station assignment, medbay hauling, the roster panel,
   * hunger, the victory check, docking and the barracks — update45
   * put a CAT in it and the game offered the animal a console. A man
   * who wants to kill you is a worse thing to hand that list.
   *
   * So: their own array, their own three rules, and one door in and
   * one door out.
   */

  /**
   * SLABS THAT ARE ACTUALLY COLD.
   *
   * One per working level AND one unit of power each — the player's
   * rule, and the whole shape of the decision: "1 poziom = 1 miejsce =
   * 1 prąd". Cutting a unit takes a slab away while the module is
   * still standing, which is what makes this a dial rather than a
   * switch. A shot-out bay is smaller before it is empty; a browned-out
   * one is smaller before it is dark.
   *
   * It used to read `workingLevels` alone, so power was all-or-nothing
   * and three cells stayed three cells right up until the lights went
   * out.
   */
  carboniteCapacity() {
    const b = this.getSystem('carbonite');
    if (!b) return 0;
    return Math.max(0, Math.min(b.workingLevels, b.effectivePower()));
  }

  /** Everyone in a slab: convicts you are hauling in, and your own men
   *  whose clock you have stopped. One list would have been wrong —
   *  a prisoner is not crew (see the note above) — but there is only
   *  ONE capacity, and both kinds spend it. */
  frozenCrew() { return this.crew.filter(c => c && c.frozen && !c.dead); }

  /** A medbay that is aboard, undamaged enough to work, and lit. One
   *  question, asked by the bleed clock, the dispatch and the healing
   *  loop alike (update78). */
  _wardIsOpen() {
    const med = this.getSystem('medbay');
    return !!med && !med.isDisabled() && med.effectivePower() > 0;
  }

  /**
   * HOW GOOD THIS WARD ACTUALLY IS, RIGHT NOW (update82).
   *
   * Not `level` — what you PAID for is not what you HAVE. A ward is
   * as good as the smaller of what is built and what is running, the
   * same expression carbonite counts its slabs with since update77,
   * and for the same reason: a shot-out pip and an unpowered pip take
   * a bed away just as surely as a bed that was never installed.
   *
   * That cuts both ways, and the player asked for both. A hit takes
   * the quarantine bench away mid-fight — but a level 5 ward with one
   * pip shot out is still a level 4 ward, which is the whole argument
   * for buying the upgrade before you can afford to run it: "nawet jak
   * nie ma wystarczajaco energi do modulu to warto miec nieraz wyzszy
   * poziom aby w razie uszkodzenia paipa dalej mozna bylo uzywac".
   */
  wardLevel() {
    const med = this.getSystem('medbay');
    if (!med || med.isDisabled()) return 0;
    return Math.max(0, Math.min(med.workingLevels, med.effectivePower()));
  }

  /**
   * WHAT A WARD OF THIS SIZE CAN CURE (update82).
   *
   * The player's ladder, and the steps are two levels apart on his
   * instruction: "co 2 lev jest dodatkowo zalanczane usdrownienie,
   * czyli 3 lev leczy epidemie po zwlokach jak sie rozklada a 5 lev
   * narazie dodatkowo jeszcze virusa pajaka".
   *
   *   1  hit points, which is what a ward has always done
   *   3  + the corpse plague
   *   5  + the void-spider virus
   *   7  + reserved, and deliberately empty
   *
   * THE EMPTY RUNGS ARE NOT AN OVERSIGHT. `maxLevel` stays 8 because
   * a level you cannot yet use is still a level that survives a hit —
   * see `wardLevel`. Filling 7 and 8 later costs one line each.
   *
   * ONE TABLE, so the cure loop, the refusal text and any future shop
   * blurb cannot disagree about which bench does what.
   */
  static get CURE_LEVELS() { return { plague: 3, virus: 5 }; }

  /** Seconds on the table before a disease lets go. */
  static get CURE_SECONDS() { return 20; }

  /** Can this hull treat `what` at all right now? */
  canCure(what) {
    const need = Ship.CURE_LEVELS[what];
    return !!need && this.wardLevel() >= need;
  }

  /**
   * ONE MAN, ONE SPELL ON THE TABLE (update82).
   *
   * A CURE IS TIME, NOT A BUTTON. Clearing the disease the frame he
   * walks in would make a level 5 ward a switch, and would make
   * carrying a sick man to it free — the whole cost of treating
   * somebody is the twenty seconds his hands are not on a console.
   * It is the same shape as everything else this ship asks of the
   * player since update78: the price is the time.
   *
   * ONE CLOCK for both diseases, because a man is on the table or he
   * is not — two timers would be two answers to "how long has he been
   * lying there". Walking out resets it: treatment is not something
   * you bank in instalments between fights.
   *
   * NOT SERIALISED, on purpose. A reload puts him back at the start of
   * the twenty seconds, which costs the player time and can never gain
   * him any — the safe direction for a field that is only ever a
   * countdown.
   */
  _cureTick(b, dt, inWard) {
    if (!b) return;
    if (!inWard) { b._cureT = 0; return; }
    const what = b.virus ? 'virus' : (b.infected ? 'plague' : null);
    if (!what || !this.canCure(what)) { b._cureT = 0; return; }

    b._cureT = (b._cureT ?? 0) + dt;
    if (b._cureT < Ship.CURE_SECONDS) return;
    b._cureT = 0;

    if (what === 'virus') {
      /* THE CLOCK STOPS AND THE EGG NEVER COMES. `virusT` is what
         `_virusBurst` counts down, so putting it back where a healthy
         man's sits is the cure — there is no second "is he ill" flag
         to clear and go stale. */
      b.virus  = false;
      b.virusT = (typeof VIRUS_SECONDS !== 'undefined') ? VIRUS_SECONDS : 0;
    } else {
      b.infected = false;
      b._infT    = 0;
    }
    if (this.isPlayer && typeof UI !== 'undefined') {
      UI.notify(what === 'virus'
        ? `${b.name} is clear of the virus — the ward caught it in time.`
        : `${b.name} is over the plague.`, 'good');
    }
  }

  /** Slabs with nobody in them. */
  freeCells() {
    return Math.max(0, this.carboniteCapacity()
                     - this.prisoners.length - this.frozenCrew().length);
  }

  /**
   * WHY YOU CANNOT FREEZE THIS MAN. Null means you can.
   *
   * Asked by the button AND by the order, so a row can never look live
   * and then do nothing — the same contract the body menu has kept
   * since update68.
   *
   * He has to BE in the bay. Carbonite is a place, not a button: the
   * walk there is the cost you pay before the decision, in the seconds
   * his hands are off a console and in the risk of sending him across
   * a burning ship. Freezing a man from anywhere would make it free.
   */
  freezeRefusal(c) {
    if (!c || c.dead || !c.isPlayer) return 'not one of your crew';
    if (c.isPet) return 'not an animal';
    if (c.frozen)  return 'already in a slab';
    const bay = this._slabRefusal();
    if (bay) return bay;
    // …and the half that is only about HIM: carbonite is a place.
    if (c.roomId !== this.getSystem('carbonite').roomId) {
      return 'he is not in the carbonite bay';
    }
    return null;
  }

  /** Put him under. Returns {ok, message} — the shape every order in
   *  this file answers in. */
  freezeCrew(c) {
    const why = this.freezeRefusal(c);
    if (why) return { ok: false, message: `Cannot freeze: ${why}.` };
    /* WHICH SLAB WENT IN LAST, so thawing can be last-in-first-out
       when the power drops — a rule the player can work out before he
       pulls the pip rather than after.
       COMPUTED from the men already under, not kept in a counter on
       the ship: a counter would be a second register that has to be
       saved, reloaded and kept in step with the crew it describes, and
       the crew already carry the answer.
       Read BEFORE he joins them, or he would be counting himself. */
    this._slabIn(c);
    if (this.isPlayer && typeof UI !== 'undefined') {
      UI.notify(`${c.name} is under. Nothing moves for him now.`, 'good');
    }
    return { ok: true, message: `${c.name} frozen.` };
  }

  /** Into a slab — ONE body of code for the player's order and for the
   *  enemy's captives (update93), so a man frozen either way is frozen
   *  the same way and thaws by the same rule. */
  _slabIn(c) {
    c._slabSeq = 1 + this.frozenCrew()
      .reduce((m, x) => Math.max(m, x._slabSeq ?? 0), 0);
    c.frozen = true;
    c._slabRoom = c.roomId;
    /* OUT OF EVERY ROOM QUERY. He keeps his x and y — the player can
       see him in the slab and click him to thaw him — but nothing that
       searches a ROOM finds him, so he cannot man a console, be shot
       at, catch fire, breathe or be counted as a defender. */
    c.roomId = null; c.inRoom = false;
    c.target = null; c.path = null;     // he was walking; now he is not
  }

  /**
   * THEIR PRISONERS ARE IN CARBONITE (update93) — the player's list,
   * point 27. A captive on an enemy hull goes into a slab of the bay he
   * sits in, and comes out by the rule every slab keeps
   * (`carboniteTick`): the bay loses power, or a level of it is shot
   * out or broken by a boarder, and the last one in is the first one
   * out. Only a THAWED man can be walked out of the bay by one of ours
   * (`freeCaptives` finds people by room, and a man in a slab is in
   * none) — so a rescue is now a bay to knock out first: from the guns,
   * or by the boarder who stands in it and wrecks it.
   */
  freezeCaptive(c) {
    if (!c || !c.isPrisoner || c.dead || c.frozen) return false;
    /* Slabs BUILT, not slabs lit: the hull is still being put together
       when he is seated and its power has not flowed yet. If the bay
       turns out to be dark, the first `carboniteTick` lets him out —
       the rule, not a special case. */
    const bay = this.getSystem('carbonite');
    if (!bay || this.frozenCrew().length + this.prisoners.length >= bay.workingLevels) return false;
    this._slabIn(c);
    return true;
  }

  /** Bring him back, exactly as he went in. */
  thawCrew(c, why = 'thawed') {
    if (!c || !c.frozen) return { ok: false, message: 'He is not in a slab.' };
    c.frozen = false;
    c._slabSeq = null;
    const pod  = this.getSystem('carbonite');
    const room = this.getRoomById(c._slabRoom ?? pod?.roomId) || this.rooms[0];
    if (room) {
      c.roomId = room.id;
      c.x = room.cx;
      c.y = this.floorWalkY(room.floor, room.cy);
      c.homeRoomId = c.homeRoomId ?? room.id;
    }
    if (this.isPlayer && typeof UI !== 'undefined') {
      UI.notify(`${c.name} is out of the slab — ${why}.`,
                why === 'thawed' ? 'good' : 'warn');
    }
    return { ok: true, message: `${c.name} thawed.` };
  }

  /**
   * THE SLAB THAT LOST ITS POWER LETS GO.
   *
   * The player's rule, word for word: "dwóch zamrożonych, ucinasz
   * jeden prąd → jeden się rozmraża, drugi nie". Capacity is a live
   * number now, so this is just "put back whoever no longer has a
   * slab" — LAST IN FIRST OUT, so which man it is, is something the
   * player can work out before he pulls the pip rather than after.
   *
   * Prisoners are NOT thawed here: a convict whose cell goes cold
   * starts working the lock instead, which is `prisonerTick`, and that
   * rule was already right.
   */
  carboniteTick() {
    const over = (this.prisoners.length + this.frozenCrew().length)
               - this.carboniteCapacity();
    if (over <= 0) return;
    const queue = this.frozenCrew().sort((a, b) => (b._slabSeq ?? 0) - (a._slabSeq ?? 0));
    queue.slice(0, over).forEach(c => {
      this.thawCrew(c, 'his slab lost power');
      /* THEIR PRISONER IS OUT OF THE ICE (update93) — said to the
         player, because it is his to act on: one of ours in that bay
         now walks him out. */
      if (!this.isPlayer && c.isPrisoner && typeof UI !== 'undefined') {
        UI.notify('A prisoner on their hull is out of the carbonite — get a man into their bay to free him!', 'good');
      }
    });
  }

  /**
   * Lock a man up. Refuses rather than overfilling — the caller is a
   * player decision and has to be able to say "you have no room".
   */
  takePrisoner(rec) {
    if (!rec || this.freeCells() <= 0) return false;
    this.prisoners.push({
      id: rec.id ?? `p${this.prisoners.length}`,
      name: rec.name ?? 'Prisoner',
      bounty: Math.max(0, Math.round(rec.bounty ?? 0)),
      /* Which poster he came off, or null. The ID, never a copy of the
         record — the list is the one place he lives. */
      wantedId: rec.wantedId ?? null,
      escapeT: 0,
      warned: false,
    });
    return true;
  }

  /**
   * WHAT KEEPS THEM IN IS POWER, NOT THE WALL.
   *
   * A powered brig is a room they sit in. Cut its power — or shoot it
   * out — and the clock starts; restore it and the clock goes back to
   * zero, because a man interrupted at a lock has to start again. Only
   * when the clock runs out is he gone, and the player is warned well
   * before that so it is never a silent loss.
   */
  prisonerTick(dt) {
    if (!this.prisoners.length) return;
    /* ── A SLAB EACH, NOT A DOOR FOR EVERYBODY (update77) ────
     *
     * This asked one yes-or-no question — is the bay powered — so
     * three convicts in a bay browned out from three units to one
     * stayed put, because the module was not DISABLED. Slabs are
     * counted now, so losing two units frees exactly two men to start
     * working their locks and leaves the third cold.
     *
     * PRISONERS HAVE THE FIRST CLAIM on what slabs remain, and your
     * own frozen men are the ones who come out (`carboniteTick`) —
     * a thaw can be undone, an escape cannot.
     *
     * Earliest taken keeps his slab, so the man who has been aboard
     * longest is not the one who gets a chance. */
    const slabs = Math.min(this.prisoners.length, this.carboniteCapacity());
    this.prisoners.slice(0, slabs).forEach(p => { p.escapeT = 0; p.warned = false; });
    const loose = this.prisoners.slice(slabs);
    if (!loose.length) return;
    const gone = [];
    loose.forEach(p => {
      p.escapeT += dt;
      if (!p.warned && p.escapeT >= Ship.ESCAPE_SECONDS * 0.4) {
        p.warned = true;
        if (this.isPlayer && typeof UI !== 'undefined') {
          UI.notify(`${p.name} is working the cell door — get the carbonite bay powered!`, 'alert');
        }
      }
      if (p.escapeT >= Ship.ESCAPE_SECONDS) gone.push(p);
    });
    gone.forEach(p => {
      this.prisoners.splice(this.prisoners.indexOf(p), 1);
      /* ── HE WALKS OUT, HE DOES NOT VANISH (update72) ────────
       *
       * update67 made the escape a LINE OF TEXT: the cell clock ran
       * out, a notification appeared and the man ceased to exist. The
       * player's own design said otherwise — "biegnie do śluzy i
       * ucieka… gracz ma realny czas, żeby go zablokować drzwiami" —
       * and text cannot be interrupted by a door.
       *
       * So he becomes what he always was: a man, standing in the brig,
       * heading for the nearest airlock. Shut the right door and he is
       * still aboard; order a hand to walk him back and he is back in
       * the cell at the same price. The board is written only when he
       * is actually GONE, which is now a thing that can fail to happen.
       */
      const brig = this.getRoomById(this.getSystem('carbonite')?.roomId) || this.rooms[0];
      const runner = new CrewMember({
        name: p.name, race: p.race || 'hostile',
        isPlayer: false, isPrisoner: true,
      });
      runner.wantedId = p.wantedId ?? null;
      runner.bounty   = p.bounty ?? 0;
      /* LEFT UNDEFINED WHEN THE CELL RECORD HAS NO LEVEL, on purpose:
         `reWanted` falls back to 5 for a man nobody has rated, and
         writing 1 here would have put every escaped commander on the
         board as a beginner. */
      runner.level    = p.level;
      runner.escapes  = p.escapes ?? 0;
      runner._breakingOut = true;
      runner.roomId = brig?.id;
      runner.x = brig ? brig.cx : 0;
      runner.y = brig ? this.floorWalkY(brig.floor, brig.cy) : 0;
      runner.homeRoomId = brig?.id;
      this.addCrew(runner, true);
      if (this.isPlayer && typeof UI !== 'undefined') {
        UI.notify(`${p.name} is OUT of the cell and making for an airlock — `
                + 'shut a door on him.', 'alert');
      }
    });
  }

  /**
   * A PRISONER EATS (update67).
   *
   * One meal per sector, taken out of the hold like anybody else's —
   * which is the real cost of carrying a man home: not the cell, the
   * RATIONS. A hold packed with ore and no food is a hold that starves
   * your bounty on the way back.
   *
   * Called once per jump, not per frame: hunger for prisoners is a
   * decision at the jump ("do I have food for him?"), and a meter of
   * its own would be a second hunger system beside the crew's.
   *
   * A man with nothing to eat dies, and a dead prisoner is a BODY —
   * still worth half, if the hold has room for him. That is the same
   * pair of prices as everywhere else, and it means starving him is a
   * loss, not a clean escape from the problem.
   */
  feedPrisoners() {
    const out = { fed: 0, starved: [], bagged: 0 };
    if (!this.prisoners.length) return out;
    this.prisoners.slice().forEach(p => {
      const meal = this.cargo?.items?.find(it =>
        it.def?.tag === 'food' && !it.damaged);
      if (meal) {
        if ((meal.qty ?? 0) > 1) meal.qty--; else this.cargo.remove(meal);
        out.fed++;
        return;
      }
      this.prisoners.splice(this.prisoners.indexOf(p), 1);
      out.starved.push(p.name);
      /* HIS BODY, IF THERE IS ROOM. Half his price, the same rule as
         a commander finished off in his cockpit. */
      const bag = this.cargo?.add?.('body_bag', {
        name: p.name, bounty: Math.round((p.bounty ?? 0) / 2),
        wantedId: p.wantedId ?? null,
      });
      if (bag) out.bagged++;
    });
    if (this.isPlayer && typeof UI !== 'undefined') {
      if (out.starved.length) {
        UI.notify(`${out.starved.join(', ')} starved in the cells.`, 'alert');
      } else if (out.fed) {
        UI.notify(`${out.fed} prisoner meal${out.fed > 1 ? 's' : ''} out of the hold.`,
                  'info');
      }
    }
    return out;
  }

  /** Missiles are physical: the racks in the hold ARE the ammo count. */
  missileCount() { return this.cargo?.countOf?.('missiles') ?? 0; }

  /** He2 is physical too (update39): the cells in the hold ARE the tank.
   *  No canisters aboard, no jump — exactly like the missile racks. */
  fuelCount() { return this.cargo?.countOf?.('fuel') ?? 0; }

  /**
   * Box a gun and stow it in the grid hold. A gun can only ever be
   * MOUNTED or BOXED — there is no weightless rack it can live on.
   * Returns the crate, or null if the hold has no room for it.
   */
  /**
   * Every spare gun aboard, as the crates they actually are.
   *
   * ONE definition of "a boxed gun" (update75). The filter — a crate
   * whose kind is `weapon` and which remembers WHICH gun in `meta` —
   * was written out by hand in the station screen twice, in the yard
   * and in the distress-beacon code. Four copies of one sentence is
   * four chances for one of them to start meaning something else.
   */
  boxedGuns() {
    return (this.cargo?.items ?? [])
      .filter(it => it.def?.kind === 'weapon' && it.meta);
  }

  boxWeapon(defKey, dest = this.cargo) {
    if (!dest || typeof cargoCrateForWeapon !== 'function') return null;
    return dest.add(cargoCrateForWeapon(defKey), defKey);
  }

  /**
   * Unbolt a gun and box it. Returns the gun's defKey, or null if the
   * mount was empty OR the crate would not fit — in which case THE GUN
   * STAYS BOLTED ON.
   *
   * `dest` is which grid the crate lands in: the ship's own hold out on
   * a contract, the base's armoury shelf when she is in the hangar.
   * ONE function unbolts a gun, and it is the one that holds the rule
   * that matters: if the crate cannot be placed, nothing moves at all —
   * a gun is never in the air between the mount and a shelf. The two
   * callers used to each carry their own copy of that check (update75).
   */
  uninstallWeapon(slot, dest = this.cargo) {
    const w = this.weapons[slot];
    if (!w) return null;
    if (!this.boxWeapon(w.defKey, dest)) return null;  // no room — she keeps her gun
    this.weapons[slot] = null;
    this._reallocWeaponPower();
    return w.defKey;
  }

  /**
   * Strip a bay while a hull is still being BUILT. The gun is not
   * stowed anywhere — it is gone, because it never really existed: this
   * is for swapping the layout's default gun out of an enemy hull
   * before anybody has seen her.
   *
   * It exists so that the destruction is written down (update75).
   * Enemy setup used to call `uninstallWeapon` for this and rely on the
   * gun landing in `weaponCargo`, a list nothing ever read on an enemy
   * — destruction by side effect, in a function whose whole promise is
   * that the gun is kept. With the rack gone, that call would have
   * boxed a crate into the enemy's hold, turning her starter laser into
   * loot the player was never meant to find, and would have FAILED on a
   * full hold, leaving the bay occupied and the swap silently undone.
   *
   * Never call this on a ship anybody owns. Taking a gun off a mount
   * and keeping it is `uninstallWeapon`, and that is the only one the
   * station and the hangar are allowed to use.
   */
  scrapWeapon(slot) {
    if (!this.weapons[slot]) return false;
    this.weapons[slot] = null;
    this._reallocWeaponPower();
    return true;
  }

  /* removeWeapon(slot) DELETED (update40).
   *
   * It sat directly below `uninstallWeapon(slot)` with no call sites and
   * the opposite behaviour: uninstall KEPT the gun, removeWeapon
   * DESTROYED it. Two contradictory rules for one action, one of them
   * silently confiscating a weapon the day anybody wired it up by
   * mistake. Still deleted, and now there is only one place a gun can
   * go when it comes off a mount, so the pair cannot grow back.
   */

  _reallocWeaponPower() {
    // Each gun draws power from ITS OWN weapon module. A damaged or
    // ionised module de-powers only the gun mounted in it (FTL rule,
    // one gun per module). Overflow slots without a room (boss ships)
    // share the FIRST module's leftover power.
    let sharedLeft = null;
    this.weapons.forEach((w, i) => {
      if (!w) return;
      const sys = this.weaponRoomFor(w)?.system ?? null;
      if (sys) {
        w.power = Math.min(w.powerCost, sys.effectivePower());
      } else {
        if (sharedLeft === null) {
          const first = this.weaponSystemFor(0);
          sharedLeft = first ? Math.max(0, first.effectivePower()
            - (this.weapons[0]?.power ?? 0)) : 0;
        }
        const give = Math.min(w.powerCost, sharedLeft);
        w.power    = give;
        sharedLeft -= give;
      }
    });
  }

  // ── Power management ──────────────────────────────────────

  /** Has this ship's power ever been laid out (by the auto-spread or
   *  by the player)? Used so a new battle does NOT stomp the layout the
   *  player set up in the previous one. */
  hasPowerPreference() {
    return this.systems.some(s => s.type !== 'reactor' && s.desiredPower > 0);
  }

  /** Evasion per POWERED level — read by `evasion` and by the module
   *  tooltip, so the number on screen is the number in the maths. */
  static get EVADE_PILOT()  { return 0.03; }
  static get EVADE_ENGINE() { return 0.02; }
  /** A repair bay mends like half a crewman per powered level. */
  static get AUTOREPAIR_RATE() { return 0.5; }

  /**
   * WHAT THIS MODULE DOES, LEVEL BY LEVEL (update88).
   *
   * The player: "medyczny moduł powinien mieć info, jaki lev jest
   * aktualnie i co daje każdy lev — teraz gracz nie ma pojęcia, że leczy
   * choroby; tak samo dla wszystkich modułów". Every number here is READ
   * from the rule it describes (Ship.CURE_LEVELS, OXYGEN.PER_POWER,
   * Ship.EVADE_*, SYSTEM_DEFS…), not typed in again — so the tooltip
   * cannot say one thing while the game does another. Several of the
   * SYSTEM_DEFS descriptions had drifted exactly like that (the O2 one
   * still promised a faster refill).
   *
   * Returns { title, status, rows: [{ text, on }] } — `on` when the
   * module, as it stands, already does that.
   */
  moduleInfo(sys) {
    if (!sys) return null;
    const lvl = sys.level, dmg = sys.damagedLevels ?? 0;
    const pw  = sys.type === 'reactor' ? (this.reactor?.totalPower ?? 0) : sys.effectivePower();
    const pct = (x) => `${Math.round(x * 100)}%`;
    const rows = [];
    const row = (text, on) => rows.push({ text, on: !!on });
    let status = `level ${lvl} · powered ${pw}` + (dmg ? ` · ${dmg} shot out` : '');
    switch (sys.type) {
      case 'reactor': {
        status = `level ${lvl} · output ${pw}` + (dmg ? ` · ${dmg} shot out` : '');
        row('1 unit of power per working level', true);
        row('A Terra cyborg at its console: +1 unit', (this.reactor?.cyborgBonus ?? 0) > 0);
        row(`Now: ${pw} units, ${this.availablePower?.() ?? 0} unspent`, true);
        // update92: the heat, and which way it is going.
        {
          const load = Math.round(this.reactorLoad * 100), heat = Math.round(this.reactorHeat ?? 0);
          const rate = this.reactorHeatRate();
          row(`Heat ${heat}% · load ${load}% (modules) — ${rate > 0 ? 'heating' : rate < 0 ? 'cooling' : 'holding'}`, rate <= 0);
          row('Heats from 80% load; cools with 30%+ of it free', rate < 0);
          row('100% heat: OVERHEAT — a reactor level lost, back to 90%', heat < 100);
        }
        break;
      }
      case 'shields': {
        const per = SYSTEM_DEFS.shields.powerPerLayer ?? 2;
        const layers = Math.floor(pw / per);
        for (let L = 1; L <= Math.floor((SYSTEM_DEFS.shields.maxLevel ?? 6) / per); L++) {
          row(`${L * per} power: ${L} layer${L > 1 ? 's' : ''}`, layers >= L);
        }
        row(`A layer recharges in ${SYSTEM_DEFS.shields.rechargeTime}s — faster with a skilled hand`, true);
        break;
      }
      case 'engines': {
        row(`+${pct(Ship.EVADE_ENGINE)} evasion per powered level`, pw > 0);
        row('Powered at all: the ship can jump and retreat', pw > 0);
        row('No pilot in the cockpit: no evasion at all', true);
        row(`Now: +${pct(pw * Ship.EVADE_ENGINE)}`, pw > 0);
        // update91: the engines carry the ship's gravity.
        row(this.gravityActive ? 'Gravity ON — one working, powered level holds it'
                               : 'ZERO-G — give the engines one working, powered level',
            this.gravityActive);
        break;
      }
      case 'piloting': {
        row(`+${pct(Ship.EVADE_PILOT)} evasion per powered level`, pw > 0);
        row('Needs a pilot at the console to dodge, jump or retreat', true);
        row(`Now: +${pct(pw * Ship.EVADE_PILOT)}`, pw > 0);
        break;
      }
      case 'oxygen': {
        const per = OXYGEN.PER_POWER / OXYGEN.BREATHING;
        row(`1 powered level = air for ${per} people`, pw > 0);
        row('A cat breathes half a man, a rat a quarter, a spider nothing', true);
        const mouths = this.crew.filter(c => c && !c.dead && !c.dying && !c.frozen && c.inRoom !== false).length;
        row(`Now: air for ${pw * per} — ${mouths} aboard`, pw * per >= mouths);
        break;
      }
      case 'medbay': {
        const ward = this.wardLevel();
        const C = Ship.CURE_LEVELS;
        row(`Level 1+: heals ${Ship.MEDBAY_HPS} hp/s per powered level, stands the downed up`, ward >= 1);
        row(`Level ${C.plague}+: cures the corpse plague (${Ship.CURE_SECONDS}s in the ward)`, ward >= C.plague);
        row(`Level ${C.virus}+: cures the spider virus (${Ship.CURE_SECONDS}s in the ward)`, ward >= C.virus);
        row(`Now: ward level ${ward} — ${ward * Ship.MEDBAY_HPS} hp/s`, ward > 0);
        break;
      }
      case 'weapons': {
        const i = this.weaponRooms.findIndex(r => r.id === sys.roomId);
        const w = i >= 0 ? this.weapons[i] : null;
        row(w ? `Runs the ${w.label}: it needs ${w.powerCost} power` : 'No gun fitted in this bay', w && pw >= w.powerCost);
        row('Needs a gunner in the bay to charge', true);
        row('Power above the gun\'s cost does nothing', true);
        break;
      }
      case 'carbonite': {
        const slabs = this.carboniteCapacity();
        row('1 slab per powered level — time stops for whoever is in it', pw > 0);
        row('Cut the power and the last one in thaws first', true);
        row(`Now: ${slabs} slab${slabs === 1 ? '' : 's'}`, slabs > 0);
        break;
      }
      case 'cloaking': {
        const d = SYSTEM_DEFS.cloaking;
        row(`Click it: ${d.cloakDuration}s invisible, every hit misses`, pw > 0);
        row(`Then ${d.cloakCooldown}s to recharge — only while powered`, pw > 0);
        break;
      }
      case 'autorepair': {
        const per = pw > 0 ? Math.round(1 / (Ship.AUTOREPAIR_RATE * pw * 0.12)) : 0;
        row('Mends every damaged module at once while powered', pw > 0);
        row(pw > 0 ? `Now: a broken level every ~${per}s` : 'Unpowered: nothing', pw > 0);
        break;
      }
      default:
        row(SYSTEM_DEFS[sys.type]?.description ?? '', true);
    }
    return { title: (sys.label || sys.type).toUpperCase(), status, rows };
  }

  /** How long a bandage or a medkit keeps a man's hands full. */
  static get AID_SECONDS() { return 3; }

  /** The least life support any hull flies with (update87). */
  static get O2_MIN_LEVEL() { return 2; }

  /**
   * LIFE SUPPORT FOR THE CREW ABOARD (update87) — enemies and bosses.
   *
   * One pip carries three men (OXYGEN.PER_POWER). A raider with four
   * aboard on a one-pip module suffocated its own crew. Level: enough
   * for the headcount, never under 2, 3 at least for a boss, 4 at most;
   * and the reactor gets the extra pips on top, so buying air does not
   * cost the ship its guns. The PLAYER gets the level-2 floor from the
   * layout and nothing else — his power is his to spend.
   */
  sizeAirForCrew(crewN, { boss = false } = {}) {
    const o2 = this.getSystem('oxygen');
    if (!o2) return 0;
    const want = Utils.clamp(Math.ceil(crewN / 3), boss ? 3 : Ship.O2_MIN_LEVEL, 4);
    o2.level = Math.max(o2.level, want);
    o2.desiredPower = o2.level;
    // The reactor covers every module at full, air included — past the
    // hull's usual cap if it has to. That is the "extra power".
    const need = this.systems.filter(x => x.type !== 'reactor').reduce((a, x) => a + x.maxPower, 0)
               + this.liftPowerNeed();      // update90: and a spare unit for each lift
    const extra = Math.max(0, need - this.reactor.capacity);
    if (extra) {
      this.reactor.maxLevel = Math.max(this.reactor.maxLevel, need);
      this.reactor.level = need;
    }
    this._allocateDefaultPower();
    return extra;
  }

  /** Who gets the reactor first, by module type — lower first. */
  static get POWER_PRIO() {
    return { oxygen:0, piloting:1, shields:2, weapons:3, engines:4, medbay:5, artillery:6 };
  }

  /** Spare reactor units a lift needs to run (update90, pkt 10). */
  static get LIFT_POWER() { return 1; }

  /** What every lift aboard takes together, when they are all lit. */
  liftPowerNeed() {
    return (this.elevators?.shafts?.length ?? 0) * Ship.LIFT_POWER;
  }

  /**
   * THE DEFAULT SPLIT OF THE REACTOR (update90 — the lifts are in it now).
   *
   * Life support and helm first — the starting reactor cannot feed
   * everything, and an unpowered O2 system suffocates. A lift runs only on
   * SPARE power (Ship._powerLifts), and the old default handed every unit
   * to the modules, so every lift on every hull would have stood dark from
   * the start. The player's call, 01.10, for the 8-unit frigate with two
   * lifts: the engines keep their one (she must be able to jump), the LEFT
   * lift gets its unit, and the guns pay for it — 1 of 2. In order:
   *
   *   oxygen, helm, shields  — full
   *   engines                — 1
   *   the leftmost lift      — its unit, kept spare
   *   every weapon module    — 1
   *   weapons, then engines  — full
   *   the other lifts        — their units, left to right
   *   medbay, artillery, the rest — full, by POWER_PRIO
   *
   * Returns `{ power: Map(system → units), liftUnits }` without touching
   * anything; `_allocateDefaultPower` applies it.
   */
  _defaultPowerPlan() {
    const prio = Ship.POWER_PRIO;
    const mods = this.systems.filter(x => x.type !== 'reactor');
    const power = new Map(mods.map(x => [x, 0]));
    let remaining = this.reactor.totalPower;
    let liftUnits = 0;
    const lifts = this.elevators?.shafts?.length ?? 0;
    const upTo = (type, n) => mods.filter(x => x.type === type).forEach(x => {
      const cap = n == null ? x.maxPower : Math.min(n, x.maxPower);
      const add = Math.max(0, Math.min(cap - power.get(x), remaining));
      power.set(x, power.get(x) + add);
      remaining -= add;
    });
    const lift = (count) => {
      for (let i = 0; i < count && liftUnits < lifts * Ship.LIFT_POWER &&
                      remaining >= Ship.LIFT_POWER; i++) {
        liftUnits += Ship.LIFT_POWER;
        remaining -= Ship.LIFT_POWER;
      }
    };
    upTo('oxygen'); upTo('piloting'); upTo('shields');
    upTo('engines', 1);
    lift(1);
    upTo('weapons', 1);
    upTo('weapons'); upTo('engines');
    lift(lifts);
    [...mods].sort((a, b) => (prio[a.type] ?? 9) - (prio[b.type] ?? 9))
      .forEach(x => {
        const add = Math.max(0, Math.min(x.maxPower - power.get(x), remaining));
        power.set(x, power.get(x) + add);
        remaining -= add;
      });
    return { power, liftUnits };
  }

  _allocateDefaultPower() {
    const { power } = this._defaultPowerPlan();
    power.forEach((units, sys) => { sys.power = units; sys.desiredPower = units; });
  }

  /**
   * A HULL SAVED BEFORE update90 handed every unit to the modules, and
   * would come out of the hangar with every lift dark. Free as many units
   * as the default would keep for lifts on this hull, taken from the
   * modules it feeds LAST — the guns first (the player's call), never
   * life support or the helm, never the engines below the one a jump
   * needs. Once, when it is loaded.
   */
  _reserveLiftPower() {
    const prio = Ship.POWER_PRIO;
    const want = this._defaultPowerPlan().liftUnits;
    const floor = x => (x.type === 'engines' ? 1 : 0);
    const rank = x => x.type === 'weapons' ? -100 : x.type === 'engines' ? 50
                    : x.type === 'shields' ? 60 : -(prio[x.type] ?? 9) - 10;
    const order = this.systems
      .filter(x => x.type !== 'reactor' && x.type !== 'oxygen' && x.type !== 'piloting')
      .sort((a, b) => rank(a) - rank(b));
    let guard = 64;
    while (this.reactor.distribute(this.systems) < want && guard-- > 0) {
      const v = order.find(x => x.power > floor(x));
      if (!v) break;
      v.power -= 1;
      v.desiredPower = v.power;
    }
  }

  /* ══ REACTOR HEAT (update92) — see REACTOR_HEAT_CONFIG ══════ */

  /** What the modules draw, over what the reactor gives (0..1). The lifts'
   *  spare units are not load. A reactor giving nothing has no load. */
  get reactorLoad() {
    const total = this.reactor?.totalPower ?? 0;
    if (total <= 0) return 0;
    const used = this.systems.reduce((a, sys) => a + (sys.type === 'reactor' ? 0 : sys.reactorDraw()), 0);
    return Utils.clamp(used / total, 0, 1);
  }

  /** Heat change per second at this load, after the thermal multiplier. */
  reactorHeatRate() {
    const H = REACTOR_HEAT_CONFIG;
    const r = this.reactor;
    if (!r) return 0;
    if (r.offline || r.totalPower <= 0) return -H.scramCoolPerSec;
    const load = this.reactorLoad, free = 1 - load, eps = 1e-9;
    const up = H.heatBands.find(b => load >= b.load - eps);
    if (up) {
      const mult = (H.thermal.find(t => r.capacity <= t.upTo) ?? H.thermal[H.thermal.length - 1]).mult;
      return up.perSec * mult;
    }
    const down = H.coolBands.find(b => free >= b.free - eps);
    return down ? -down.perSec : 0;
  }

  _heatTick(dt) {
    const H = REACTOR_HEAT_CONFIG;
    if (!this.reactor || this.isPreview) return;
    const before = this.reactorHeat ?? 0;
    let heat = Utils.clamp(before + this.reactorHeatRate() * dt, 0, 100);
    this.reactorHeat = heat;
    const room = this.getRoomById(this.getSystem('reactor')?.roomId);

    // Crossing the lines upward is said once, each time it happens.
    if (this.isPlayer) {
      if (before < H.criticalHeat && heat >= H.criticalHeat && heat < 100) {
        if (typeof UI !== 'undefined') UI.notify('⚠ REACTOR CRITICAL — take power off or it will overheat', 'alert');
        if (typeof Audio !== 'undefined') Audio.sfx?.reactorCritical?.();
      } else if (before < H.warnHeat && heat >= H.warnHeat) {
        if (typeof UI !== 'undefined') UI.notify('Reactor running hot — free some power to cool it', 'warn');
        if (typeof Audio !== 'undefined') Audio.sfx?.reactorWarn?.();
      }
    }

    // OVERHEAT: once, at 100 — then back to 90, so it cannot fire every frame.
    if (heat >= 100) {
      this.reactorHeat = H.overheatResetHeat;
      const sys = this.getSystem('reactor');
      if (sys) sys.damageLevel(H.overheatDamage);
      this._overheatFlashT = 2.5;
      if (room) {
        Particles.explosion?.(room.cx, room.cy, 0.6);
        if (Math.random() < H.overheatFireChance) this.fires.start(room.id, room.cx, room.cy);
      }
      if (this.isPlayer) {
        if (typeof UI !== 'undefined') UI.notify('☢ REACTOR OVERHEAT — a reactor level is gone', 'alert');
        if (typeof Audio !== 'undefined') Audio.sfx?.reactorOverheat?.();
        if (typeof Camera !== 'undefined') Camera.shake?.(6, 0.35);
      }
    }
    if (this._overheatFlashT > 0) this._overheatFlashT -= dt;

    // Fire rolls: on a clock, never per frame.
    this._heatHazardT = (this._heatHazardT ?? 0) + dt;
    while (this._heatHazardT >= H.hazardInterval) {
      this._heatHazardT -= H.hazardInterval;
      const band = H.fireChance.find(b => this.reactorHeat >= b.heat);
      if (band && room && Math.random() < band.p) {
        this.fires.start(room.id, room.cx, room.cy);
        if (this.isPlayer && typeof UI !== 'undefined') UI.notify('The reactor is so hot its room caught fire!', 'alert');
      }
      // Sparks over a hot core — more as it climbs. Drawing only.
      if (room && this.reactorHeat >= H.warnHeat) {
        const n = this.reactorHeat >= H.criticalHeat ? 3 : this.reactorHeat >= 80 ? 2 : 1;
        for (let k = 0; k < n; k++) {
          Particles.repairSparks?.(room.cx + Utils.randFloat(-room.w * 0.35, room.w * 0.35),
                                   room.cy + Utils.randFloat(-10, 10));
        }
      }
    }
  }

  /* ══ THE ENEMY'S HAND ON ITS OWN REACTOR (update93) ══════════
   *
   * Before this the enemy ran everything flat out and overheated in
   * about six minutes — a long fight was won by its own core. It now
   * does what the player is asked to do: watch the bar and take power
   * off. What it takes, in order, is what it needs least —
   *
   *   medbay → cloak → repair bay → engines above 1 → guns (never the
   *   last one powered) → shields above one bar → life support above 1
   *
   * — and it remembers what it took (`_aiShed`), so it gives back the
   * same units, last first, once the core is cool. Only `desiredPower`
   * moves: the flow in `update` does the rest, the same as for a
   * click on the player's bar. */
  _plannedLoad() {
    const total = this.reactor?.totalPower ?? 0;
    if (total <= 0) return 0;
    const used = this.systems.reduce((a, x) => a + (x.type === 'reactor' ? 0
      : x.reactorDraw(Math.max(0, Math.min(x.desiredPower ?? 0, x.workingLevels)))), 0);
    return used / total;
  }

  _aiShedPick() {
    const order = ['medbay', 'cloaking', 'autorepair', 'engines', 'weapons', 'shields', 'oxygen'];
    const floor = (x) => x.type === 'engines' || x.type === 'oxygen' ? 1
                       : x.type === 'shields' ? 2 : 0;
    const guns = this.systems.filter(x => x.type === 'weapons' && (x.desiredPower ?? 0) > 0);
    for (const type of order) {
      const cands = this.systems.filter(x => x.type === type && (x.desiredPower ?? 0) > floor(x))
        .filter(x => !(x.type === 'cloaking' && x.cloakActive))
        .filter(x => !(x.type === 'weapons' && guns.length <= 1));
      if (cands.length) return cands[cands.length - 1];
    }
    return null;
  }

  coolingAI(dt) {
    if (this.isPlayer || this.isDerelict || !this.reactor) return;
    const A = REACTOR_HEAT_CONFIG.ai;
    this._aiShed = this._aiShed ?? [];
    this._aiCoolT = (this._aiCoolT ?? 0) + dt;
    if (this._aiCoolT < A.stepSeconds) return;
    this._aiCoolT = 0;
    const heat = this.reactorHeat ?? 0;
    if (heat >= A.shedAt || (this._aiShed.length && heat > A.restoreAt &&
                             this._plannedLoad() > A.targetLoad + 1e-9)) {
      if (this._plannedLoad() <= A.targetLoad + 1e-9) return;
      const x = this._aiShedPick();
      if (!x) return;
      x.desiredPower -= 1;
      this._aiShed.push(x);
      return;
    }
    if (heat <= A.restoreAt && this._aiShed.length) {
      const x = this._aiShed.pop();
      if (x && this.systems.includes(x)) x.desiredPower = Math.min(x.maxPower, (x.desiredPower ?? 0) + 1);
    }
  }

  /** How far off the deck a body hangs in zero-G, now (update91). */
  static floatOffset(t, i, down = false) {
    const lift = down ? 2 : 4, bob = down ? 1.2 : 2.2;
    return -lift + Math.sin(t * 2.1 + i * 1.7) * bob;
  }

  /** Dust hanging in the air of every compartment in zero-G (update91). Cheap:
   *  a handful of dots per room, placed by time, nothing simulated. */
  _drawZeroGMotes(ctx, t) {
    ctx.save();
    ctx.fillStyle = 'rgba(200,225,255,0.35)';
    this.rooms.forEach((r, ri) => {
      const top = r.floorTop ?? r.y, h = r.floorH ?? r.h;
      for (let k = 0; k < 4; k++) {
        const ph = ri * 3.1 + k * 2.3;
        const x = r.x + 6 + ((Math.sin(t * 0.21 + ph) * 0.5 + 0.5) * (r.w - 12));
        const y = top + 4 + ((Math.cos(t * 0.17 + ph * 1.3) * 0.5 + 0.5) * (h - 8));
        ctx.fillRect(x, y, 1.5, 1.5);
      }
    });
    ctx.restore();
  }

  /** GRAVITY (update91): the engines have a working level and are running.
   *  A Terra cyborg's +1 counts — the module is running on it (as its icon
   *  says, 90a). Ion-locked engines are not running. No engines, no gravity. */
  get gravityActive() {
    const e = this.getSystem('engines');
    return !!e && e.workingLevels >= 1 && e.effectivePower() >= 1;
  }

  get zeroG() { return !this.gravityActive; }

  /** How fast a body moves aboard, as a fraction of its walk (update91). */
  moveFactor(c) {
    const G = GRAVITY_CONFIG, zg = this.zeroG;
    if (c?.carrying) return zg ? G.zeroGWoundedCarrySpeed : G.normalWoundedCarrySpeed;
    return zg ? G.crewMovementMultiplier : 1;
  }

  /** The repair and breach-patching rates in this ship's gravity (update91). */
  repairFactor() { return this.zeroG ? GRAVITY_CONFIG.normalRepairMultiplier : 1; }
  breachFactor() { return this.zeroG ? GRAVITY_CONFIG.breachRepairMultiplier : 1; }

  /**
   * GRAVITY, ONCE A FRAME (update91): say so when it changes — once, never
   * every frame — and run the hold's two hazard clocks while it is off.
   * The first frame only notes the state: a hull that starts in zero-G (a
   * load, a wreck) is not "losing" gravity.
   */
  _gravityTick(dt) {
    const on = this.gravityActive;
    this.crew.forEach(c => { if (c) c._zeroG = !on; });
    if (this._gravityWas === undefined) { this._gravityWas = on; return; }
    if (on !== this._gravityWas) {
      this._gravityWas = on;
      this._zgDamageT = 0; this._zgLossT = 0;
      if (this.isPlayer && typeof UI !== 'undefined') {
        UI.notify(on ? 'GRAVITY RESTORED' : '⚠ GRAVITY LOST — ZERO-G', on ? 'good' : 'alert');
      }
      if (this.isPlayer && typeof Audio !== 'undefined') {
        on ? Audio.sfx?.gravityOn?.() : Audio.sfx?.gravityOff?.();
      }
      if (on && this.isPlayer && typeof Camera !== 'undefined') Camera.shake?.(3, 0.2);
    }
    if (!on && !this.isPreview) this._zeroGCargoTick(dt);
  }

  /** The hold in zero-G (update91) — see GRAVITY_CONFIG. Timed, not per frame. */
  _zeroGCargoTick(dt) {
    const hold = this.cargo;
    if (!hold) return;
    const G = GRAVITY_CONFIG;
    const say = (m) => { if (this.isPlayer && typeof UI !== 'undefined') UI.notify(m, 'warn'); };

    this._zgDamageT = (this._zgDamageT ?? 0) + dt;
    while (this._zgDamageT >= G.cargoDamageCheckInterval) {
      this._zgDamageT -= G.cargoDamageCheckInterval;
      if (Math.random() >= G.cargoDamageProbability) continue;
      /* An egg case is not on the list: a damaged one does not hatch
         (`_hatchTick` skips it), so damage there would be a cure. */
      const ok = hold.items.filter(it => !it.damaged && it.def?.tag !== 'egg');
      if (!ok.length) continue;
      const it = Utils.pick(ok);
      it.damaged = true;
      say(`CARGO DAMAGED: ${it.label}`);
    }

    const holed = (this.breaches?.breaches ?? []).some(b => !b.sealed);
    if (!holed) { this._zgLossT = 0; return; }
    this._zgLossT = (this._zgLossT ?? 0) + dt;
    while (this._zgLossT >= G.cargoLossCheckInterval) {
      this._zgLossT -= G.cargoLossCheckInterval;
      if (Math.random() >= G.cargoLossProbability) continue;
      if (!hold.items.length) continue;
      const it = Utils.pick(hold.items);
      if (it.isStack && it.qty > 1) it.qty -= 1;
      else hold.remove(it);
      say(`CARGO LOST: ${it.label}`);
      if (this.isPlayer && typeof Audio !== 'undefined') Audio.sfx?.hullBreach?.();
    }
  }

  /**
   * LIFTS RUN ON SPARE POWER (update90, pkt 10). `spare` is what the
   * modules left of the reactor this frame. Each lift takes LIFT_POWER,
   * counting from the LEFT — the player's rule: "pierwsza z lewej dostaje
   * prąd pierwsza". The SAME on a wreck (update90a): it has half a
   * reactor now, and what life support and the engines leave runs its
   * lifts like anybody's (see makeDerelict).
   */
  _powerLifts(spare) {
    const shafts = this.elevators?.shafts ?? [];
    let left = Math.max(0, spare);
    [...shafts].sort((a, b) => a.x - b.x).forEach(s => {
      s.powered = left >= Ship.LIFT_POWER;
      if (s.powered) left -= Ship.LIFT_POWER;
    });
  }

  /** How many lifts are lit right now. */
  liftsPowered() {
    return (this.elevators?.shafts ?? []).filter(s => s.powered !== false).length;
  }

  setPower(systemType, power) {
    const sys = this.getSystem(systemType);
    if (!sys) return;
    this.setPowerAt(this.systems.indexOf(sys), power);
  }

  /** Index-based power control — needed because a ship can carry
   *  SEVERAL systems of the same type (one per weapon module). */
  setPowerAt(sysIndex, power) {
    const sys = this.systems[sysIndex];
    if (!sys || sys.type === 'reactor') return;
    const before = sys.power;
    this.reactor.setPower(sys, power, this.systems);
    sys.desiredPower = sys.power;   // remember intent — restored after repair
    // The last module given power is the first to lose it (update90a).
    if (sys.power > before) sys._powerStamp = (this._powerSeq = (this._powerSeq ?? 0) + 1);
    if (sys.type === 'weapons') this._reallocWeaponPower();
    Audio.sfx.powerUp();
  }

  availablePower() {
    return this.reactor.distribute(this.systems);
  }

  // ── Damage resolution ────────────────────────────────────

  /**
   * Receive a projectile hit.
   * Returns { absorbed, hullDamage, roomHit }
   */
  receiveHit(proj) {
    const def = proj.def;

    // ACTIVE CLOAK: nothing lands while the field is up. Not a high
    // evasion roll — a guaranteed miss for the whole duration. That is
    // the point of spending a cooldown on it.
    {
      const cl = this.getSystem('cloaking');
      if (cl && cl.cloakActive) {
        Particles.floatText(proj.x, proj.y - 6, 'CLOAKED', '#cc44ff', 12);
        return { absorbed: true, dodged: true, hullDamage: 0 };
      }
    }

    // Evasion dodge — pilot and engine crew gain XP (FTL)
    if (Math.random() < this.evasion) {
      Particles.floatText(proj.x, proj.y - 6, 'MISS', '#8fd4ff', 12);
      const pSys = this.getSystem('piloting');
      const eSys = this.getSystem('engines');
      const helmHand = pSys ? this.consoleOperator(pSys.roomId) : null;
      const engHand2  = eSys ? this.consoleOperator(eSys.roomId) : null;
      if (helmHand) helmHand.addXP('piloting', XP_RATES.piloting);
      if (engHand2) engHand2.addXP('engines',  XP_RATES.engines);
      return { absorbed: true, dodged: true, hullDamage: 0 };
    }

    // Who ignores shields: it is a property of the GUN now, not a list
    // of type names scattered through the damage code.
    const isBeam    = def.type === 'beam';
    const pierces   = def.pierceShields ?? (def.type === 'missile' || def.type === 'cannon' || isBeam);

    // Shield check. A bolt stopped by the bubble strips shieldDamage
    // BARS, not one — that is what makes an ion cannon or a flak burst
    // a shield-breaker rather than a slightly worse laser.
    if (!pierces && this.shieldBars > 0) {
      const shSys = this.getSystem('shields');
      const strip = Math.max(1, def.shieldDamage ?? def.shield_damage ?? 1);
      for (let i = 0; i < strip && this.shieldBars > 0; i++) shSys.hitShield();
      Particles.shieldHit(proj.x, proj.y);
      if (strip > 1) Particles.floatText(proj.x, proj.y - 6, `-${strip} SHIELD`, '#4db8ff', 11);
      this._shieldAlpha = 1;
      Camera.shake(4, 0.15);
      return { absorbed: true, hullDamage: 0, shieldStripped: strip };
    }

    // Damage lands in the room the projectile actually reached.
    // (Previously a random room was picked — targeting was cosmetic
    //  and fires appeared in modules that were never hit.)
    const roomHit =
      this.rooms.find(r => r.contains(proj.x, proj.y)) ||
      this.rooms.find(r => r.contains(proj.targetX, proj.targetY)) ||
      Utils.pick(this.rooms);

    /* EVERY EFFECT IS ITS OWN NUMBER.
       `damage` used to do four jobs at once — hull points, module levels,
       a multiplier on crew injury and, by implication, the breach roll —
       so there was no way to describe a gun that strips shields and
       harms nothing, or one that cuts up crew but leaves modules alone.
       Each one is a separate field on the def now (see WEAPON_DEFS). */
    const dmg = def.hull_damage ?? def.damage ?? 1;
    this.hull = Math.max(0, this.hull - dmg);

    // Floating damage feedback
    if (roomHit.type === 'reactor' && roomHit.system && dmg > 0) {
      Particles.floatText(roomHit.cx, roomHit.y + 10, `-${dmg} POWER`, '#ffb020', 12);
    } else if (dmg > 0) {
      Particles.floatText(roomHit.cx, roomHit.y + 10, `-${dmg}`, '#ff5566', 13);
    }

    // Module levels knocked out. 0 means this gun cannot break a module
    // at all, however hard it lands (ion, flak).
    const modDmg = def.moduleDamage ?? def.damage ?? 1;
    if (roomHit.system && modDmg > 0) roomHit.system.damageLevel(modDmg);

    // Crew in the hit room. An explicit [min,max] per weapon, so a flak
    // burst can hurt people without touching the machinery.
    const cd = def.crewDamage ?? [10 * dmg, 25 * dmg];
    if ((cd[1] ?? 0) > 0) {
      this.occupantsOf(roomHit.id).forEach(c => {
        const before = c.alive;
        // crewDamage is an inclusive range in WEAPON_DEFS, and the
        // stat chip prints it as one — so roll it as one.
        c.takeDamage(Utils.randIn(cd[0], cd[1]), 'weapons fire');
        // Credit the gunner who actually pulled the trigger — that is
        // what the memorial means by "kills".
        if (before && !c.alive) (proj.gunners ?? []).forEach(g => g.creditKill?.(c));
      });
    }

    // STUN — the module and everyone in it. One second per ion bolt.
    const stun = def.stunTime ?? (def.type === 'ion' ? 1 : 0);
    if (stun > 0) {
      if (roomHit.system) roomHit.system.ionHit(stun);
      this.occupantsOf(roomHit.id).forEach(c => c.stun?.(stun));
      Particles.floatText(roomHit.cx, roomHit.y + 22, 'STUNNED', '#8fd4ff', 11);
    }

    // Breach chance — per weapon now. It used to be "missiles always,
    // any 2+ hit 25% of the time", which made every heavy laser a hull
    // breacher and gave the designer no way to say otherwise.
    const breachP = def.breachChance ?? (pierces ? 0.5 : dmg >= 2 ? 0.25 : 0);
    if (breachP > 0 && Math.random() < breachP) {
      this.breaches.open(
        roomHit.id,
        roomHit.x + Utils.randFloat(8, roomHit.w - 8),
        roomHit.y + Utils.randFloat(8, roomHit.h - 8)
      );
    }

    // Fire chance — per weapon, 25% unless the def says otherwise
    // (the starting laser is deliberately tamer, see WEAPON_DEFS).
    if (Math.random() < (def.fireChance ?? 0.25)) {
      this.fires.start(roomHit.id, roomHit.cx, roomHit.cy);
    }

    Particles.explosion(proj.x, proj.y, 0.7);
    Camera.shake(6, 0.2);

    /* THE SECOND DAMAGE NUMBER IS GONE (update40).
       There were two floatText calls for one hit, at the same point:
       the guarded one above (`else if (dmg > 0)`) and an unguarded one
       here. Every laser hit painted two overlapping numbers in two
       sizes, which read as a smeared bold figure — and because ion and
       flak have hull_damage 0, the unguarded one proudly rendered
       "-0" over the room for the two guns whose whole identity is that
       they harm nothing. */
    roomHit._hitFlash = 1;          // drawn by Room.draw, fades out

    /* WHAT THE ENEMY'S 60-SECOND CLOCK LISTENS FOR (update93): a hit
       that reached the player's hull and did something — hull, a module
       level or a man. A miss, a shield bar or an empty ion buzz is not
       harm. */
    if (this.isPlayer && (dmg > 0 || (roomHit.system && modDmg > 0) ||
        ((cd[1] ?? 0) > 0 && this.occupantsOf(roomHit.id).length > 0))) {
      Ship.noteHarmToPlayer();
    }

    if (this.hull <= 0) this._beginDestruction();

    return { absorbed: false, hullDamage: dmg, roomHit };
  }

  _beginDestruction() {
    if (this.destroyed) return;
    this.destroyed = false;   // will flip after death animation
    this._deathTimer = 0;
    Audio.sfx.explosion();
    Camera.shake(20, 0.8);
    /* WHOSE HULL JUST WENT (update71). `recordKill` counted ANY ship
       breaking up — including the player's own — so the campaign's
       "enemies killed" went up by one every time he lost. It is the
       enemy's destruction that is a kill, and the same line feeds the
       side objective. */
    if (!this.isPlayer) {
      Save.recordKill();
      Save.goalEvent?.('ships');
    }
  }

  // ── Update ───────────────────────────────────────────────

  /* ══ THE DUCTS: RATS, SPIDERS AND THE CAT (update84) ════════
   *
   * `hatchNests` and `verminTick` stood here. Both walked `this.crew`
   * looking for crewmen who were not crewmen, and between them they
   * leant on the room brawl to do the actual killing. The pests have
   * their own list now (`this.pests`, see pests.js), and this is the
   * one tick that runs it: sacs, air, fire, the cat, moving, chewing
   * and the drop. One place, in that order, because each step can end
   * the pest before the next one looks at it.
   */
  pestTick(dt) {
    if (!this.pests.length) return;
    // Anything that stopped moving goes: nobody holds a service for a rat.
    this.pests = this.pests.filter(p => !p.dead);
    this._hatchTick(dt);
    this.pests.forEach(p => {
      if (!p.alive) return;
      p.anim?.update?.(dt);
      if (this._pestHazards(p, dt)) return;       // it died of the ship
      if (this._pestVsCat(p, dt)) return;         // cornered, or killed
      this._pestMove(p, dt);
      if (p.isRat && this._ratLife(p, dt)) return;   // starved
      this._pestDrop(p, dt);
    });
    this.pests = this.pests.filter(p => !p.dead);
  }

  /** Put a pest in a duct. `roomId` and `x` are the caller's to set. */
  addPest(pest) {
    if (!pest || this.pests.includes(pest)) return pest;
    if (pest.roomId == null) {
      const room = Utils.pick(this.rooms);
      pest.roomId = room?.id ?? null;
      pest.x = room ? room.cx : 0;
    }
    this.pests.push(pest);
    return pest;
  }

  /** The living pests in one compartment's duct. */
  pestsIn(roomId) {
    return this.pests.filter(p => p.alive && p.roomId === roomId);
  }

  /** Who a spider in `roomId`'s duct can drop on: a person standing below. */
  _pestVictims(roomId) {
    return this.crew.filter(c => c && c.isPlayer && c.alive && !c.isPet &&
      !c.frozen && !c.isPrisoner && c.inRoom !== false && c.roomId === roomId);
  }

  /**
   * EGG SACS SPLIT ONCE THERE IS PREY ABOARD (moved from hatchNests).
   *
   * Anyone standing under a sac sets it off six times faster; the rest
   * hatch on their own stagger, so a boarding party can never be stuck
   * unable to finish because one sac sits over a room nobody visits.
   */
  _hatchTick(dt) {
    const sacs = this.pests.filter(p => p.dormant && !p.dead);
    if (!sacs.length) return 0;
    const intruders = this.crew.filter(c => c.isPlayer && !c.dead && !c.down && !c.isPet);
    if (!intruders.length) return 0;      // still nobody aboard

    let hatched = 0;
    sacs.forEach(sac => {
      const inRoom = intruders.some(p => p.roomId === sac.roomId);
      /* WALKING IN IS HOW YOU FIND THEM. A sac is invisible until
         somebody is in the room under it — the wreck reads as empty
         and the nests are something you discover. */
      if (inRoom) sac.revealed = true;
      /* THE CAT SMELLS THEM THROUGH THE BULKHEAD (update45). One room
         of warning, revealed WITHOUT speeding it up — knowing is not
         the same as disturbing. */
      if (!sac.revealed) {
        const nearCat = this.crew.some(c => c.isPet && c.alive &&
          (c.roomId === sac.roomId ||
           this.adjacentThermal(c.roomId).some(a => a.room?.id === sac.roomId)));
        if (nearCat) {
          sac.revealed = true;
          sac.sensedByCat = true;
        }
      }
      sac.hatchT -= dt * (inRoom ? 6 : 1);
      if (sac.hatchT <= 0 && sac.hatch()) {
        hatched++;
        Particles.burst?.(sac.x, this.getRoomById(sac.roomId)?.ventY ?? 0, '#9fff7a', 14);
      }
    });
    if (hatched && typeof UI !== 'undefined') {
      UI.notify?.(`${hatched} egg sac${hatched > 1 ? 's' : ''} just split open in the ducts!`, 'alert');
      Audio.sfx?.bossWarning?.();
    }
    return hatched;
  }

  /**
   * WHAT THE SHIP ITSELF DOES TO A PEST: air and fire.
   *
   * VACUUM kills a rat and nothing else — a rat has no bottle, so it
   * starts dying the moment its compartment is empty, at the rate a
   * man does once his bottle is dry. The spider has no lungs and does
   * not care. The duct shares the compartment's air in this package;
   * the duct emptying FIRST is update85 (U11).
   *
   * FIRE in the module below reaches the duct, because the duct is its
   * ceiling — at the rate it burns a man. It is the only thing besides
   * the cat that kills a spider. (A fire burning INSIDE the duct, and
   * spreading along it, is update85 as well.)
   *
   * Returns true when the pest died of it.
   */
  _pestHazards(p, dt) {
    if (p.breathes()) {
      /* The DUCT's air, not the room's (update85): the two empty in
         different orders now — see OXYGEN.DUCT_THIN. */
      const ro = this.oxygen?.getRoom?.(p.roomId);
      /* A BREATH HELD (update86b). It used to start dying the instant
         the duct was dry, which made a rat far easier to kill than a man
         in a suit; it holds a normal suit's worth now, and gets it back
         as fast as a suit refills once there is air again. */
      const T = RAT_TUNING;
      /* Thinner than ROOM_EMPTY is no air (update90) — the vent network
         empties a duct ever more slowly and would never quite reach 0. */
      const dry = ro && ro.duct <= OXYGEN.ROOM_EMPTY;
      if (ro && !dry && typeof SUIT_AIR !== 'undefined') {
        p.air = Math.min(T.AIR_SECONDS, (p.air ?? T.AIR_SECONDS) + SUIT_AIR.REFILL_PER_SEC * dt);
      } else if (dry && (p.air = Math.max(0, (p.air ?? T.AIR_SECONDS) - dt)) <= 0 &&
                 typeof SUIT_AIR !== 'undefined') {
        if (p.takeDamage(SUIT_AIR.DAMAGE_PER_SEC * dt, 'vacuum')) {
          this._pestDied(p, `A ${p.label.toLowerCase()} suffocated in the duct.`);
          return true;
        }
      }
    }
    // The duct burning, not the room (update85): it catches a few
    // seconds after the module does, and not at all without air.
    if (this.fires?.ductBurning?.(this, p.roomId) && typeof FIRE_DEFS !== 'undefined') {
      if (p.takeDamage(FIRE_DEFS.CREW_DAMAGE * dt, 'fire')) {
        this._pestDied(p, `A ${p.label.toLowerCase()} burned in the duct.`);
        return true;
      }
    }
    return false;
  }

  _pestDied(p, line) {
    const cat = p._catId ? this.crew.find(c => c && c.id === p._catId) : null;
    if (cat) this._catLetGo(cat);
    p._catId = null;
    const room = this.getRoomById(p.roomId);
    if (room) Particles.floatText?.(p.x, room.ventY, '✕', '#ffd780', 10);
    if (this.isPlayer && line && typeof UI !== 'undefined') UI.notify?.(line, 'good');
  }

  /* ── THE CAT GOES UP AFTER IT ─────────────────────────────
   *
   * This was the room brawl: the cat walked in, the rat was hostile
   * crew in the same room, and CrewMember.update did the rest. There is
   * no brawl in a duct, so this IS the fight — and it is the only one
   * a pest ever loses to something alive.
   *
   * She takes it when she is standing in the room under it and has
   * stopped walking. From then on the pest is HELD: it does not crawl
   * off and it does not drop on anybody, and a spider bites back. She
   * is drawn up in the duct with it (CrewMember.draw reads `_ductY`),
   * because a fight the player cannot see is not one he knows is on.
   *
   * Returns true while the pest is held (or has just been killed).
   */
  _pestVsCat(p, dt) {
    if (p._climb) return false;          // in the shaft: nobody can reach it there
    let cat = p._catId ? this.crew.find(c => c && c.id === p._catId) : null;
    if (cat && !(cat.alive && cat.roomId === p.roomId && !cat._waypoints?.length && !cat.busy)) {
      this._catLetGo(cat);
      p._catId = null;
      cat = null;
    }
    if (!cat) {
      // A fed cat walks under it and leaves it be (update90b).
      const fed = (c) => typeof HUNGER !== 'undefined' && (c.hunger ?? 0) >= HUNGER.FED;
      cat = this.crew.find(c => c && c.isPet && c.alive && !c.busy && !fed(c) &&
        c.roomId === p.roomId && c.inRoom !== false &&
        !c._waypoints?.length && !c._ductPestId);
      if (!cat) return false;
      p._catId = cat.id;
      p._via = null; p._tx = null; p._pounce = null;
      p._biteBackT = 0;
      cat._ductPestId = p.id;
      cat._facing = (p.x >= cat.x) ? 1 : -1;
    }
    const room = this.getRoomById(p.roomId);
    cat._ductY = room ? Pest.ductFloor(room) - Pest.FEET : null;
    cat.x = Utils.clamp(p.x - 10 * (cat._facing || 1), room ? room.x + 8 : cat.x,
                        room ? room.x + room.w - 8 : cat.x);
    cat._setAnim?.('fight');
    p._setAnim('fight');

    if (cat.attackTimer?.tick(dt)) {
      if (p.takeDamage(cat.meleeDamage(), 'cat')) {
        this._catCaught(cat, p);
        return true;
      }
    }
    if (p.isSpider) {
      p._biteBackT += dt;
      if (p._biteBackT >= PEST_TUNING.BITE_BACK_EVERY) {
        p._biteBackT = 0;
        cat.takeDamage(p.biteDamage(), 'spider');
        Particles.floatText?.(cat.x, (cat._ductY ?? cat.y) - 10, 'BITTEN', '#9fff7a', 10);
        if (!cat.alive) {
          this._catLetGo(cat);
          p._catId = null;
          if (this.isPlayer && typeof UI !== 'undefined') {
            UI.notify?.(`${cat.name} went up after a spider and did not come back down.`, 'alert');
          }
        }
      }
    }
    return true;
  }

  /** She comes back down to the deck — the fight is over either way. */
  _catLetGo(cat) {
    if (!cat) return;
    cat._ductPestId = null;
    cat._ductY = null;
    cat._setAnim?.('idle');
  }

  /**
   * A CAT EATS WHAT IT CATCHES (update45) — moved here from
   * CrewMember.creditKill, which was the brawl's choke point and is
   * not where a cat kills anything any more. The notch on her record is
   * the same `kills` the memorial reads, so no second tally.
   */
  /** What a caught pest is worth to the cat (update90b, HUNGER.PREY). */
  static preyFood(p) {
    const P = HUNGER.PREY;
    if (p.isSpider) return P.spider;
    return P.rat[Utils.clamp((p.level ?? 1) - 1, 0, P.rat.length - 1)];
  }

  _catCaught(cat, p) {
    this._catLetGo(cat);
    p._catId = null;
    cat.kills = (cat.kills ?? 0) + 1;
    if (typeof HUNGER !== 'undefined') {
      const food = Ship.preyFood(p);
      cat.hunger = Utils.clamp((cat.hunger ?? 0) + food.hunger, 0, 100);
      cat.hp     = Math.min(cat.maxHp, cat.hp + food.hp);
    }
    const room = this.getRoomById(p.roomId);
    if (room) Particles.floatText?.(p.x, room.ventY, 'CAUGHT', '#ffc861', 10);
    if (this.isPlayer && typeof UI !== 'undefined') {
      UI.notify?.(`${cat.name} caught the ${p.label.toLowerCase()}.`, 'good');
    }
  }

  /**
   * WHERE A PEST CAN GO FROM A DUCT (update86a).
   *
   * Sideways: `Room.adjacent`, the U9 network — the rooms beside it on
   * its own deck. Up and down: the LIFT SHAFT. The player's call, 29.09:
   * "mamy winde wiec beda uzywac tego jako szyb". A room whose end wall
   * is on a shaft links, through that shaft, to the room on the deck
   * above and the deck below that also back onto it — one deck per hop,
   * so the graph stays as local as the sideways one. (update84 measured
   * that `adjacent` has no link between decks on any hull; this is that
   * link, and it is the shaft.)
   *
   * Worked out once per hull and kept: rooms and shafts do not move.
   */
  ductLinks(roomId) {
    if (!this._ductLinkMap) {
      const map = new Map();
      const add = (a, link) => { if (!map.has(a)) map.set(a, []); map.get(a).push(link); };
      this.rooms.forEach(r => (r.adjacent ?? []).forEach(id => {
        const to = this.getRoomById(id);
        if (to) add(r.id, { room: to, shaft: null });
      }));
      (this.elevators?.shafts ?? []).forEach(sh => {
        const top = sh.extentTop ?? sh.topY ?? -Infinity;
        const bot = sh.extentBottom ?? sh.bottomY ?? Infinity;
        // The rooms whose end wall is on this shaft, one side or the other.
        const onIt = this.rooms.filter(r =>
          (Math.abs(r.x + r.w - sh.x) <= Ship.SHAFT_REACH || Math.abs(r.x - sh.x) <= Ship.SHAFT_REACH) &&
          r.y + r.h > top && r.y < bot);
        onIt.forEach(a => {
          const side = Math.sign(a.cx - sh.x);
          const decks = onIt.filter(b => b.floor !== a.floor && Math.sign(b.cx - sh.x) === side);
          [a.floor - 1, a.floor + 1].forEach(f => {
            const b = decks.find(r => r.floor === f);
            if (b) add(a.id, { room: b, shaft: sh });
          });
        });
      });
      this._ductLinkMap = map;
    }
    return this._ductLinkMap.get(roomId) ?? [];
  }

  /** How far from a shaft's centre line a room's end wall may be and still open onto it. */
  static get SHAFT_REACH() { return 20; }

  /**
   * ALONG THE DUCT, AND THROUGH IT INTO THE NEXT ONE.
   *
   * It crawls to the end of its own duct facing the way it is going
   * and comes out at the near end of the next. A deck change goes the
   * same way, with the climb in the middle: to the end wall on the
   * shaft, up or down the shaft (drawn there, head first — `_climb`),
   * and out into the other deck's duct at the same wall.
   *
   * A spider goes where the people are: if the room it is over has
   * nobody in it and a neighbour does — beside it or up the shaft —
   * that is the way it goes.
   */
  _pestMove(p, dt) {
    if (p._pounce) return;
    if (p._climb) { this._pestClimb(p, dt); return; }
    const room = this.getRoomById(p.roomId);
    if (!room) return;
    const E = Pest.EDGE;

    /* A SPIDER WITH SOMEBODY UNDER IT STAYS. It went where the people
       are to drop on them; wandering off to a random neighbour first
       raced the move clock (8-18 s) against the drop clock (6-14 s) and
       lost about half the time, so a man could stand under one for
       twenty seconds and never be touched. */
    if (p._tx == null && p.isSpider && this._pestVictims(room.id).length) {
      p._setAnim('idle');
      return;
    }
    if (p._tx == null) {
      p._moveT -= dt;
      if (p._moveT <= 0) {
        p._moveT = Utils.randFloat(PEST_TUNING.MOVE_MIN, PEST_TUNING.MOVE_MAX);
        const next = this.ductLinks(room.id);
        let go = null;
        if (p.isSpider && !this._pestVictims(room.id).length) {
          go = next.find(l => this._pestVictims(l.room.id).length) || null;
        }
        if (!go && next.length) go = Utils.pick(next);
        if (go) {
          p._via = go.room.id;
          p._viaShaft = go.shaft;
          const toward = go.shaft ? go.shaft.x : go.room.cx;
          p._tx = toward >= room.cx ? room.x + room.w - E : room.x + E;
        } else {
          p._tx = Utils.randFloat(room.x + E, room.x + room.w - E);   // a turn in its own duct
        }
      } else {
        p._setAnim('idle');
        return;
      }
    }

    const step = p.def.speed * dt;
    const d = p._tx - p.x;
    p._facing = d >= 0 ? 1 : -1;
    p._setAnim('walk');
    if (Math.abs(d) > step) { p.x += Math.sign(d) * step; return; }
    p.x = p._tx;
    p._tx = null;
    if (p._via != null) {
      const to = this.getRoomById(p._via);
      const shaft = p._viaShaft;
      p._via = null; p._viaShaft = null;
      if (to && shaft) {
        const y0 = Pest.ductFloor(room), y1 = Pest.ductFloor(to);
        p._climb = { x: shaft.x, y0, y1, t: 0, dur: Math.abs(y1 - y0) / p.def.speed, to: to.id,
                     exitX: to.cx < shaft.x ? to.x + to.w - E : to.x + E };
        p._setAnim('walk');
        return;
      }
      if (to) {
        p.roomId = to.id;
        p.x = room.cx < to.cx ? to.x + E : to.x + to.w - E;
      }
    }
    p._setAnim('idle');
  }

  /** Up or down the shaft, and out into the other deck's duct. */
  _pestClimb(p, dt) {
    const c = p._climb;
    c.t += dt;
    p._setAnim('walk');
    if (c.t < c.dur) return;
    p._climb = null;
    p.roomId = c.to;
    p.x = c.exitX;
    p._setAnim('idle');
  }

  /**
   * CAN THE PLAYER SEE INTO THIS DUCT (update86a)?
   *
   * The player's rule, 29.09: rats, spiders and eggs are seen only in a
   * compartment where one of his people — or the cat — is standing.
   * What they DO is still reported (the chewed loom, the split sac):
   * the body is hidden, the consequence is not.
   */
  pestVisible(roomId) {
    return this.crew.some(c => c && (c.isPlayer || c.isPet) && c.alive && !c.frozen &&
                               c.inRoom !== false && c.roomId === roomId);
  }

  /**
   * A RAT'S LIFE (update86, U10B) — see RAT_TUNING for the table.
   *
   * It gets hungry, it eats from the hold (the ONE chooser, `mealFor`,
   * so an egg goes first and then the worst box), and each meal grows
   * it: young → breeding → adult, with a litter on the way. An ADULT
   * with nothing aboard it will eat chews the loom under it — a whole
   * level off the module, slowly. The old three-second short, and the
   * rule that it only happened in a fight, went: the player's rule is
   * that food in the hold is what keeps the cables whole, so the hold
   * is the switch, not the battle.
   *
   * Returns true if it starved to death this tick.
   */
  _ratLife(rat, dt) {
    const T = RAT_TUNING;
    rat.fullness = Math.max(0, (rat.fullness ?? 100) - T.HUNGER_PER_SEC * (rat.metab ?? 1) * dt);

    // Long, slow starvation: a point of hide every half a minute.
    if (rat.fullness <= 0) {
      rat._starveT = (rat._starveT ?? 0) + dt;
      if (rat._starveT >= T.STARVE_EVERY) {
        rat._starveT = 0;
        if (rat.takeDamage(1, 'starvation')) {
          this._pestDied(rat, 'A rat starved to death in the ducts.');
          return true;
        }
      }
    } else {
      rat._starveT = 0;
    }

    if (rat.fullness < T.EAT_BELOW) this._ratEat(rat);

    // THE RULE: nothing chews while there is something to eat.
    const hungryForWire = !this._ratFood(rat);
    if (rat.level >= 3 && hungryForWire) this._ratAct(rat, dt);
    else rat._chewT = null;
    if (rat.level === 2 && hungryForWire) this._ratShort(rat, dt);
    else rat._shortT = null;
    return false;
  }

  /**
   * AN ADULT'S MOVE (update89). The player: "dorosłe szczury też nieraz
   * wyskakują na gracza, a nieraz psują moduł". One clock per rat, each
   * started at its own random point, and when it runs out a coin: a
   * hungry rat with a man in the room below drops on him (DROP_SHARE of
   * the time), otherwise it chews the loom.
   */
  _ratAct(rat, dt) {
    const T = RAT_TUNING;
    rat._chewT = (rat._chewT ?? Utils.randFloat(T.CHEW_MIN, T.CHEW_MAX)) - dt;
    if (rat._chewT > 0) return false;
    rat._chewT = Utils.randFloat(T.CHEW_MIN, T.CHEW_MAX);
    const below = this._pestVictims(rat.roomId);
    if (below.length && this._ratAngry(rat) && Math.random() < T.DROP_SHARE) {
      this._startDrop(rat, Utils.pick(below));
      return true;
    }
    return this._ratChewNow(rat);
  }

  /**
   * A BREEDING RAT SHORTS THE LOOM IN A FIGHT (update89) — the old
   * pre-update86 bite, back for the middle size: the module under it is
   * dead for a few seconds (the ion path), the men in it stunned. Only
   * with nothing to eat, like every other thing a rat does to wiring.
   */
  _ratShort(rat, dt) {
    const T = RAT_TUNING;
    rat._shortT = (rat._shortT ?? Utils.randFloat(T.SHORT_MIN, T.SHORT_MAX)) - dt;
    if (rat._shortT > 0) return false;
    rat._shortT = Utils.randFloat(T.SHORT_MIN, T.SHORT_MAX);
    const fighting = (typeof CombatManager !== 'undefined') && (CombatManager.isActive?.() ?? false);
    const room = this.getRoomById(rat.roomId);
    const sys = room?.system;
    if (!fighting || !sys || sys.stunLeft > 0) return false;
    sys.ionHit(T.SHORT_SECONDS);
    this.occupantsOf(room.id).forEach(c => c.stun?.(T.SHORT_SECONDS));
    Particles.floatText?.(room.cx, room.y + 22, 'SHORTED', '#ffd780', 11);
    if (this.isPlayer) Audio.sfx.ratChew?.();
    if (this.isPlayer && typeof UI !== 'undefined') {
      UI.notify(`Something shorted the ${sys.label} loom — it is dead for ${T.SHORT_SECONDS}s!`, 'alert');
    }
    return true;
  }

  /** What a rat in this duct would eat next, or null. */
  _ratFood(rat) {
    const sac = this.pests.find(q => q !== rat && q.dormant && !q.dead && q.roomId === rat.roomId);
    return sac || this.mealFor(rat);
  }

  /** One meal: a sac in its own duct, else the hold, egg first. */
  _ratEat(rat) {
    const meal = this._ratFood(rat);
    if (!meal) return false;
    if (meal instanceof Pest) {
      meal.takeDamage(meal.hp + 1, 'rat');         // a sac, eaten where it lay
      this._pestDied(meal, null);
    } else {
      const isEgg = meal.def?.tag === 'egg';
      // One unit out of a stack, exactly as a man eats — see _finishMeal.
      if (!isEgg && (meal.qty ?? 0) > 1) meal.qty--;
      else this.cargo.remove(meal);
      if (this.isPlayer && typeof UI !== 'undefined') {
        UI.notify(isEgg ? 'Something in the ducts got at a spider egg.'
                        : `Something in the ducts got into the ${meal.def?.label ?? 'rations'}.`,
                  isEgg ? 'info' : 'warn');
      }
    }
    rat.fullness = Math.min(100, rat.fullness + RAT_TUNING.MEAL);
    this._ratGrow(rat);
    return true;
  }

  /** Every meal grows it; from breeding age on, every meal is a litter
   *  as well — the ADULT's too (update86b, the player: "dorosły też
   *  powinien się rozmnażać po zjedzeniu porcji"). MAX_ABOARD is what
   *  stops it. */
  _ratGrow(rat) {
    if (rat.level >= 2) this._ratLitter(rat);
    rat.growUp();
  }

  _ratLitter(rat) {
    const T = RAT_TUNING;
    const room = this.getRoomById(rat.roomId);
    const aboard = this.pests.filter(q => q.isRat && q.alive).length;
    const n = Math.min(Utils.randInt(T.LITTER_MIN, T.LITTER_MAX + 1), T.MAX_ABOARD - aboard);
    if (!room || n <= 0) return 0;
    for (let i = 0; i < n; i++) {
      const pup = this.addPest(new Pest({
        kind: 'rat', level: 1, roomId: room.id,
        fullness: Utils.randFloat(T.PUP_FULL_MIN, 100),   // not one belly for the litter
        x: Utils.clamp(rat.x + Utils.randFloat(-12, 12),
                       room.x + Pest.EDGE, room.x + room.w - Pest.EDGE),
      }));
      pup._moveT = Utils.randFloat(2, 6);         // they scatter
    }
    if (this.isPlayer && typeof UI !== 'undefined') {
      UI.notify(`Squeaking in the ducts over the ${room.system?.label ?? 'deck'} — a litter of ${n}.`, 'alert');
    }
    return n;
  }

  /** The chew itself: a level off the module under it. */
  _ratChewNow(rat) {
    const room = this.getRoomById(rat.roomId);
    const sys = room?.system;
    if (!sys || sys.damagedLevels >= sys.level) return false;
    sys.damageLevel(1);
    Particles.floatText?.(room.cx, room.y + 22, 'CHEWED', '#ffd780', 11);
    if (this.isPlayer) Audio.sfx.ratChew?.();
    if (this.isPlayer && typeof UI !== 'undefined') {
      UI.notify(`Something chewed through the ${sys.label} loom — it lost a level.`, 'alert');
    }
    return true;
  }

  /**
   * THE SPIDER DROPS, BITES AND GOES BACK UP (U10A, the player's rule).
   *
   * "Pająk czasem wyskakuje z wentylacji i atakuje załoganta. Szczur
   * nigdy." It is the one time a pest touches a person, and the man it
   * bites cannot hit back: by the time he turns round it is in the
   * duct again. The bite is the old one — damage, and the same odds of
   * the virus the room brawl rolled in CrewMember.strike.
   */
  /**
   * …AND SINCE update86 A HUNGRY ADULT RAT DOES IT TOO, rarely: the
   * player's "szczury rzadko atakują załogantów", which U10B had as
   * "agresywny NA GŁODZIE". Only an adult, only with nothing in the hold
   * it could eat, only when it is hungry — and no virus, a rat is not a
   * spider. One drop, two kinds of bite.
   */
  _pestDrop(sp, dt) {
    if (sp._climb) return;               // it cannot drop out of a lift shaft
    if (sp._pounce) {
      const P = sp._pounce;
      P.t += dt;
      const victim = this.crew.find(c => c && c.id === P.victimId);
      if (!P.bitten && P.t >= PEST_TUNING.POUNCE_SECONDS / 2) {
        P.bitten = true;
        if (victim && victim.alive && victim.roomId === sp.roomId) {
          /* AN ATTEMPT, NOT A CERTAINTY (update89). A man can twist
             away: BITE_HIT of the drops land, the rest miss. */
          if (Math.random() >= PEST_TUNING.BITE_HIT) {
            Particles.floatText?.(victim.x, victim.y - 18, 'MISSED', '#8fa0b8', 11);
          } else if (sp.isSpider) this._spiderBite(sp, victim);
          else this._ratBite(sp, victim);
        }
      }
      if (P.t >= PEST_TUNING.POUNCE_SECONDS) sp._pounce = null;
      return;
    }
    // A rat's drop is one of the moves on its own clock — `_ratAct`.
    if (sp.isRat) return;
    const below = this._pestVictims(sp.roomId);
    if (!below.length) return;
    const lo = PEST_TUNING.POUNCE_MIN, hi = PEST_TUNING.POUNCE_MAX;
    sp._pounceT = (sp._pounceT ?? Utils.randFloat(lo, hi)) - dt;
    if (sp._pounceT > 0) return;
    sp._pounceT = Utils.randFloat(lo, hi);
    this._startDrop(sp, Utils.pick(below));
  }

  /** Down out of the duct onto one man. */
  _startDrop(sp, victim) {
    sp._tx = null; sp._via = null;
    sp.x = victim.x;
    sp._pounce = { t: 0, victimId: victim.id, bitten: false };
    sp._setAnim('fight');
  }

  /** Adult and hungry: the only rat that bites.
   *  "…and nothing aboard to eat" needs no clause of its own: a rat
   *  with food in reach eats first (`_ratLife`), and a meal puts it far
   *  above HUNGRY. The first break run proved it — the clause could be
   *  deleted and nothing changed — so it was. */
  _ratAngry(rat) {
    return rat.level >= 3 && rat.fullness < RAT_TUNING.HUNGRY;
  }

  _ratBite(rat, victim) {
    victim.takeDamage(RAT_TUNING.BITE, 'rat');
    Particles.floatText?.(victim.x, victim.y - 18, 'BITTEN', '#b3a189', 12);
  }

  _spiderBite(sp, victim) {
    victim.takeDamage(sp.biteDamage(), 'spider');
    Particles.laserHit?.(victim.x, victim.y - 10);
    if (!victim.virus && !victim.dead && Math.random() < SPIDER_INFECT_CHANCE) {
      victim.virus = true;
      victim.virusT = VIRUS_SECONDS;
      Particles.floatText?.(victim.x, victim.y - 18, 'BITTEN', '#9fff7a', 13);
      if (typeof UI !== 'undefined') {
        UI.notify?.(`${victim.name} was bitten — something got into the wound.`, 'alert');
      }
    }
  }

  /* ── A WRECK IS SEARCHED, NOT CLEARED (update84) ──────────
   *
   * A derelict's hold used to open when the last spider on it was dead.
   * The spiders are in the ducts now and nobody in a boarding party can
   * reach one, so that condition could never come true. The player's
   * call: the hold is yours once your people have been into every
   * compartment. The spiders' part is what they do on the way round.
   */
  searchTick() {
    if (!this.isDerelict) return;
    this._searched = this._searched ?? new Set();
    this.crew.forEach(c => {
      if (c && c.isPlayer && c.alive && !c.isPet && c.inRoom !== false && c.roomId != null) {
        this._searched.add(c.roomId);
      }
    });
  }

  /** Has somebody stood in every compartment of this hulk? */
  searchedAll() {
    if (!this.isDerelict || !this.rooms.length) return false;
    const s = this._searched;
    return !!s && this.rooms.every(r => s.has(r.id));
  }

  isSearched(roomId) { return !!this._searched?.has(roomId); }

  /* ── Casualty clocks (update42) ──────────────────────────
     Every one of these used to be an inline literal buried in
     _updateBodies, and two of them didn't exist at all. */
  /** Seconds a corpse lies aboard before it starts to rot. */
  static get DECAY_SECONDS() { return 40; }
  /** Seconds a DOWNED crew member has before they bleed out. */
  static get BLEEDOUT_SECONDS() { return 40; }
  /* ── THE PRICE LIST OF A BOX OF SUPPLIES (update78) ────────
   *
   * `FIELD_AID_HPS` DELETED. A bandage does not restore hit points any
   * more, so an HP-per-second for it was a number describing something
   * that no longer happens — and the medbay's own rate, three times
   * larger, is the one that heals.
   *
   * One box, two prices, and the automatic one is the cheap one so
   * that the expensive one stays a decision. */
  /** HP/s per unit of power a medbay restores — the only thing aboard
   *  that heals past the point a man stands up. */
  static get MEDBAY_HPS()   { return 6; }
  static get AID_DOSES()    { return 1; }   // stop the bleeding
  static get MEDKIT_DOSES() { return 2; }   // …and get him up
  /** What a medkit puts him back on his feet at, as a share of max. */
  static get MEDKIT_SHARE() { return 0.30; }
  /** Infection chance per second, sharing a room with a rotting body. */
  static get PLAGUE_RATE_ROOM() { return 0.05; }
  /** …and anywhere else on the ship, carried by the air handlers. */
  static get PLAGUE_RATE_VENT() { return 0.008; }
  /** Through the ducts (update93a), by hops from the rotting room:
   *  next door, two away, further. Anything the ducts do not reach
   *  falls back to PLAGUE_RATE_VENT. */
  static get PLAGUE_VENT_RATES() { return [0.03, 0.02, 0.012]; }
  /** How long a bearer waits with a body when every hatch is shut. */
  static get CORPSE_HOLD_SECONDS() { return 6; }

  /* ── WHERE THE TWO HULLS STAND IN A FIGHT (update73) ──────
   *
   * Written out FOUR times in game.js before this — `180, 180` at
   * three places where the player's hull is built or loaded, and
   * `850, 200` where the enemy is spawned. Four literals for two
   * positions, and every one of them needed the same correction when
   * the module got wider, which is four chances to correct three.
   *
   * MEASURED, not chosen. The widest player hull and the widest enemy
   * hull are 520px each and the canvas is 1280, so 240px is all there
   * is to divide. The orders panel on the left ends around x=120 and
   * the hull may not sit on top of it, which fixes the left margin at
   * about 140 and leaves 100 to split between the gap the shells
   * cross and the right-hand edge. 70 and 30.
   *
   * The enemy came in from 850, where he no longer fitted: at four
   * columns his stern ran eighty pixels off the right of the screen.
   */
  static get PLAYER_STATION() { return { x: 170, y: 180 }; }
  static get ENEMY_STATION()  { return { x: 750, y: 200 }; }
  /* Out the airlock is free in CC and costs you your name. The other
     half of this pair is the burial at the dock — see base.js.

     `VENT_KARMA` RENAMED to EJECT_KARMA (update75). Since update73 a
     "vent" is the duct along every ceiling — where the fire runs and
     the rats live — and the order that throws a body into the black
     had the same word. The airlock stays dangerous (player's call,
     22.09): the man carrying the body stands in vacuum for a few
     seconds and his suit holds eight, so the burial can cost you the
     bearer. That is the price of the decision, not a bug. */
  static get EJECT_KARMA()   { return -3; }
  static get BURIAL_KARMA() { return  3; }
  /** A grave without a name for one of THEIRS, brought home (update93). */
  static get UNKNOWN_BURIAL_KARMA() { return 1; }
  /* How long a man needs on an unpowered cell door. Long enough that
     restoring power is a real save, short enough that ignoring the
     warning costs you the bounty. */
  static get ESCAPE_SECONDS() { return 25; }

  /* ── HOW LONG A SALVAGE TEAM HAS (update74) ───────────────
   *
   * Fifty seconds, written out in FIVE places in game.js — three
   * `?? 50` defaults, a `_wreckSecs` initialiser and a floor of 20 —
   * which is five chances to change four of them.
   *
   * Fifty is also too long, and that is the player's report: *„za dużo
   * mamy teraz czasu do namysłu"*. In fifty seconds a hold can be
   * solved like a Tetris board, at leisure, which is the opposite of
   * what a clock on a derelict is for. Thirty makes it a decision
   * about what to take; the floor stops a booby trap or a bad roll
   * from turning it into no decision at all.
   *
   * One number, one place. Both are tuning dials — expect to move them
   * once he has flown with them. */
  static get LOOT_SECONDS() { return 30; }
  static get LOOT_SECONDS_MIN() { return 15; }


  /* ── THE SHIP'S CAT (update45) ────────────────────────────
   *
   * A cat is a passenger with an opinion. Nobody gives it orders it
   * has to obey — though the player CAN send it to a compartment, and
   * that beats whatever it had planned — and it works down a short
   * list of its own priorities:
   *
   *   1. eat, if it is in the middle of eating
   *   2. hunt, if there is vermin aboard
   *   3. sit with a downed crewman  ← what it does most of the time
   *   4. find food, if it is hungry
   *   5. wander
   *
   * Priority 3 is the whole reason a cat is worth a pen. Rats appear
   * on maybe a fifth of jumps, so an animal that only hunted them
   * would sit idle for entire contracts; sitting with the wounded
   * gives it work in every fight, and it costs nothing to explain —
   * the animal is simply there when somebody is bleeding.
   */
  petTick(dt) {
    const cats = this.crew.filter(c => c.isPet && !c.dead);
    if (!cats.length) return;
    const H = (typeof HUNGER !== 'undefined') ? HUNGER : null;
    if (!H) return;

    cats.forEach(cat => {
      if (!cat.alive) return;

      /* THE STOMACH MOVED OUT (update47). Draining the meter, the
         starvation damage and the warnings used to be written right
         here, for cats only. The crew eat now, and a second copy of
         the same arithmetic for people is exactly the two-registers
         mistake this project keeps paying for — so all of it went to
         hungerTick, for every mouth aboard, and petTick is left with
         what it was always about: what a CAT does. */

      // ── 1. Mid-meal ── (the timer itself ticks in hungerTick)
      if (cat.busy) return;

      /* UP IN THE DUCT WITH ONE ALREADY (update84) — `_pestVsCat`
         owns her until it is dead or she is. Without this she would be
         called off it by the next pest on the list. */
      if (cat._ductPestId) return;

      /* PREY IS IN THE DUCTS NOW, and it is spiders as well as rats:
         the cat is one of the only two things that can kill a spider.
         The one over her own room first, so she is not sent across the
         ship past the one she is standing under. */
      /* A FED CAT DOES NOT HUNT (update90b) — the player's rule: she goes
         up after them when she has room for one, which is what the prey
         points in HUNGER.PREY are for. */
      const live = (cat.hunger ?? 0) >= H.FED ? [] : this.pests.filter(p => p.alive);
      const prey = live.find(p => p.roomId === cat.roomId) || live[0] || null;
      const hurt = this.crew.find(c => c.isPlayer && c.down && !c.dead && c.inRoom !== false);
      const starving = cat.hunger < H.HUNGRY;

      /* ── A STANDING ORDER, AND WHAT BREAKS IT (update83) ───
       *
       * This flag has been read here since update45 and NOTHING EVER
       * WROTE IT. So the branch was dead, and what the player saw was
       * the cat taking his order and abandoning it — instantly if
       * there was a rat aboard, and otherwise the moment the roam
       * timer ran out a few seconds later: "kot chodzi tam gdzie mu
       * sie pokazuje, nastepnie po chwili chodzi gdzie chce".
       *
       * Now the order HOLDS. She walks there and she stays there, and
       * she keeps standing there when the roam timer fires, because
       * the order is checked before the roam and returns.
       *
       * THREE THINGS OUTRANK IT, and the first two are the player's
       * own rule — "dopóki nie pojawi się szczur albo ranny":
       *
       *   - vermin aboard: hunting is what she is FOR
       *   - a man on the floor: the vigil slows his bleed-out (update45)
       *   - her own hunger: a cat starving at her post would be an
       *     order that kills her, which is not an order the player
       *     thinks he is giving
       *
       * The flag is cleared when one of them fires, so she goes back to
       * her own life for good rather than snapping back to the post
       * afterwards. Wanting her there again is one more click, and one
       * more click is cheaper than a cat you cannot call off.
       *
       * AND IT APPLIES MID-WALK. There used to be a line above this
       * one — `if (cat._waypoints.length) return` — that made the
       * order absolute until she arrived. The breaking run could not
       * break it, which is how it was found: with nothing outranking
       * the order the test below returns anyway, so the line only ever
       * changed what happens when a rat appears while she is still
       * crossing the ship. Marching her into an empty room to turn
       * round there is not better behaviour, it is just more code —
       * so the line is gone and a rat diverts her wherever she is.
       */
      if (cat._ordered) {
        if (!prey && !hurt && !starving) return;     // posted, and staying
        cat._ordered = false;
      }

      // ── 2. Vermin aboard ──
      if (prey) {
        if (cat.roomId === prey.roomId) return;    // _pestVsCat takes it from here
        this._petSendTo(cat, prey.roomId);
        return;
      }

      // ── 3. Sit with the wounded ──
      if (hurt) {
        if (cat.roomId !== hurt.roomId) this._petSendTo(cat, hurt.roomId);
        return;
      }

      // ── 4. Hungry: go and find something ──
      if (starving && this._startMeal(cat)) return;

      // ── 5. Wander ──
      cat._roamT = (cat._roamT ?? Utils.randFloat(3, 9)) - dt;
      if (cat._roamT <= 0) {
        cat._roamT = Utils.randFloat(6, 14);
        const room = Utils.pick(this.rooms);
        if (room && room.id !== cat.roomId) this._petSendTo(cat, room.id);
      }
    });
  }

  /** Walk the cat to a room, the same way any crew order works.
   *
   * ONCE, NOT EVERY FRAME (update84). The hunt and the vigil both call
   * this on every tick until she arrives, and each call re-planned her
   * route from scratch — which is harmless on one deck and fatal on
   * two: a re-plan while she is waiting at or riding a lift turns the
   * cabin round and restarts the ride, so a cat sent to a rat on the
   * other deck stood at the shaft for ever. It went unseen while the
   * rats were crew, because the only test of the hunt looked for a
   * route, not an arrival. Moving the rats into the ducts made the
   * arrival the whole point, and the first test that waited for it
   * found her still at the lift two minutes later. */
  _petSendTo(cat, roomId) {
    const room = this.getRoomById(roomId);
    if (!room) return false;
    const tx = room.cx, ty = this.floorWalkY(room.floor, room.cy);
    /* "Already on her way" is read off her ROUTE, not off a note of
       where she was last sent: the player can re-order her in between,
       and a note would then say she was going somewhere she is not. */
    const last = cat._waypoints?.[cat._waypoints.length - 1];
    if (last && Math.abs(last.x - tx) < 1 && Math.abs(last.y - ty) < 1) return true;
    cat.moveToOnShip?.(this, tx, ty);
    return true;
  }

  /**
   * Start a meal if there is anything in the hold this mouth will eat.
   *
   * EGGS BEFORE RATIONS for the cat, deliberately: a spider egg eaten
   * is a fight that never happens, and the player is far happier to
   * lose one of those than a ration pack he was counting on. The crew
   * do not eat spider eggs. There are limits.
   */
  _startMeal(who) {
    /* ONE CHOOSER (update81). This used to pick its own meal — the egg,
       or else the first ration in grid order — while the player's FEED
       order picked through `mealFor`. Two answers to "what does this
       mouth open next", and they did not even agree about the egg: the
       cat helped herself to one, and FEED told the player there was
       "nothing aboard she will eat". */
    const meal = this.mealFor(who);
    if (!meal) return false;
    who._meal = meal;
    this._startBusy(who, 'eat');
    return true;
  }

  /**
   * WILL THIS MOUTH TOUCH THIS BOX (update66)?
   *
   * One question, asked by the cat's own meal and by the player's FEED
   * order alike, so a hand can never be ordered to eat something he
   * would not have taken on his own.
   *
   * Today it has exactly one rule and one live consumer: THE CAT does
   * not eat vat greens. That matters — it is what keeps `meat` from
   * being a flag with nothing reading it, waiting for religions to
   * arrive. When crew beliefs land, they add rules HERE and nowhere
   * else.
   */
  /**
   * THE WORST BOX ABOARD THIS MOUTH WILL OPEN (update81).
   *
   * It used to be the FIRST one in the grid, which is not a choice at
   * all — it is wherever the crate happened to land when it was
   * packed. The player's rule, and it is the right way round: "od
   * najgorszych potraw po lepsze".
   *
   * That is the opposite of what a player does by hand, and that is
   * the point. The automatic mouth clears out the protein paste that
   * would have gone off anyway; the field meals and the good rations
   * are still there when YOU decide who gets them. Eating up from the
   * bottom is also the only order that makes four kinds of ration a
   * packing decision rather than a shopping list.
   *
   * ONE CHOOSER for the order and for the automatic meal alike — see
   * `_startMeal`. `hunger` is the box's own nutrition, so this cannot
   * drift from what the meal is actually worth.
   *
   * AN EGG IS NOT ON THE LADDER — it jumps it. A cat takes an egg
   * before anything else, and that is not a statement about how tasty
   * it is: an egg left in the hold HATCHES, and the cat eating one is
   * a fight that never happens. Crew are not offered eggs at all;
   * `willEat` is where that rule lives.
   *
   * Asking it HERE rather than in `_startMeal` is the point of this
   * package's clean-up: the cat used to help herself to an egg through
   * one path while FEED, asking the other, told the player there was
   * "nothing aboard she will eat".
   */
  mealFor(who) {
    const hold = this.cargo?.items ?? [];
    if (who?.isPet || who?.isRat) {       // the rats too (update86, U10B)
      const egg = hold.find(it => it && it.def?.tag === 'egg' && !it.damaged);
      if (egg) return egg;
    }
    const edible = hold.filter(it =>
      it && it.def?.tag === 'food' && !it.damaged && this.willEat(who, it));
    if (!edible.length) return null;
    return edible.reduce((a, b) =>
      ((b.def?.hunger ?? 50) < (a.def?.hunger ?? 50) ? b : a));
  }

  /**
   * Why FEED would refuse, or null. The menu greys the row with this
   * and `feedCrew` refuses with it — the same shape as `bodyRefusal`,
   * and for the same reason: a row that looks live and then does
   * nothing is the bug both of them exist to prevent.
   */
  feedRefusal(who, item = null) {
    if (!who || who.dead) return 'nobody there';
    if (who.down) return `${who.name} is down — treat him first`;
    if (who.busy) return `${who.name} has his hands full`;
    if ((who.hunger ?? 100) >= 100) return `${who.name} is not hungry`;
    const meal = item || this.mealFor(who);
    if (!meal) return `nothing aboard ${who.name} will eat`;
    if (!this.willEat(who, meal)) return `${who.name} will not touch the ${meal.def.label}`;
    return null;
  }

  /** ONE door for every row of the crew menu, whoever it belongs to. */
  menuRefusal(person, act) {
    if (act === 'cell')   return this.cellRefusal(person);
    if (act === 'freeze') return this.freezeRefusal(person);
    if (act === 'thaw')   return person?.frozen ? null : 'he is not in a slab';
    return act === 'feed' ? this.feedRefusal(person) : this.bodyRefusal(person, act);
  }

  willEat(who, item) {
    if (!who || !item) return false;
    if (item.def?.tag === 'egg') return !!(who.isPet || who.isRat);   // crew have limits
    if (item.def?.tag !== 'food') return false;
    if (who.isPet && item.def.meat === false) return false;
    return true;
  }

  /**
   * FEED THIS ONE, NOW (update66).
   *
   * A hungry man helps himself, which is right — but it means the last
   * box on the shelf goes to whoever got hungry first, and the player
   * never gets a say. This is the say: name a mouth, and he eats next.
   * Refuses out loud, like every other order.
   */
  feedCrew(who, item = null) {
    const why = this.feedRefusal(who, item);
    if (why) return { ok: false, message: why };
    const meal = item || this.mealFor(who);
    who._meal = meal;
    this._startBusy(who, 'eat');
    return { ok: true, message: `${who.name} is eating the ${meal.def.label}.` };
  }

  /* ══ ONE TIMER FOR EVERY ACTION THAT TAKES A MOMENT (update78) ══
   *
   * The player's rule: eating, bandaging and opening a medkit each
   * take a couple of seconds. They share ONE timer on the man doing
   * them, because the first thing any of them needs to ask is "are
   * your hands already full" — and three separate timers is three
   * places for that one question to be answered differently.
   *
   * `act` says what finishes when it runs out; `onId` is the man it is
   * being done TO, as an ID, because he can die, be carried away or go
   * out an airlock while the seconds run.
   */
  _startBusy(who, act, onId = null, secs = null) {
    if (!who) return false;
    /* ONE timer, but not one LENGTH (update87). Eating went to six
       seconds at the player's ask; the bandage and the medkit borrowed
       the meal's number, so they doubled with it — a side effect the
       player did not ask for. The meal keeps HUNGER.EAT_SECONDS; the
       hands-on medical work keeps its three. */
    const len = act === 'eat'
      ? ((typeof HUNGER !== 'undefined') ? HUNGER.EAT_SECONDS : 6)
      : Ship.AID_SECONDS;
    who._busyT   = secs ?? len;
    who._busyAct = act;
    who._busyOn  = onId;
    return true;
  }

  _cancelBusy(who) {
    if (!who) return;
    who._busyT = 0; who._busyAct = null; who._busyOn = null; who._meal = null;
  }

  _busyTick(dt) {
    this.crew.forEach(c => {
      if (!c || !(c._busyT > 0)) return;
      /* A MAN WHO DIED MID-ACTION FINISHES NOTHING. Checked here and
         not in each finisher, so a new action cannot forget it. */
      if (c.dead) { this._cancelBusy(c); return; }
      c._busyT -= dt;
      if (c._busyT > 0) return;
      const act = c._busyAct, onId = c._busyOn;
      c._busyT = 0; c._busyAct = null; c._busyOn = null;
      const on = onId ? this.crew.find(x => x && x.id === onId) : null;
      if (act === 'eat')    this._finishMeal(c);
      if (act === 'aid')    this._finishAid(c, on);
      if (act === 'medkit') this._finishMedkit(c, on);
    });
  }

  /* ══ MEDICAL SUPPLIES: ONE BOX, TWO PRICES (update78) ══════
   *
   * A bandage costs ONE dose and stops a man bleeding. A MEDKIT costs
   * TWO and puts him back on his feet. One item in the hold, so there
   * is nothing to tell apart on the shelf and no second icon — and the
   * decision is sharp, because the automatic bandaging eats the same
   * doses the player is hoarding to stand people up.
   */
  doseCount() {
    return (this.cargo?.items ?? [])
      .filter(it => it.def?.kind === 'heal')
      .reduce((n, it) => n + (it.qty ?? 1), 0);
  }

  hasDoses(n = 1) { return this.doseCount() >= n; }

  /** Spend `n` doses. All or nothing: it never half-pays. */
  spendDoses(n = 1) {
    if (!this.hasDoses(n)) return false;
    let left = n;
    const hold = this.cargo;
    (hold?.items ?? []).filter(it => it.def?.kind === 'heal').forEach(it => {
      if (left <= 0) return;
      const take = Math.min(left, it.qty ?? 1);
      left -= take;
      if ((it.qty ?? 1) > take) it.qty -= take;
      else hold.remove(it);
    });
    return true;
  }

  /** The bandage is on: the clock stops, and he is still on the floor. */
  _finishAid(medic, body) {
    if (!body || body.dead || !body.down) return;
    if (body._bandaged) return;
    if (!this.spendDoses(Ship.AID_DOSES)) return;   // somebody used the last one
    body._bandaged = true;
    body._bleedT   = 0;
    medic?.addXP?.('repair', 5);
    if (this.isPlayer && typeof UI !== 'undefined') {
      UI.notify(`${medic?.name ?? 'Somebody'} stopped ${body.name}'s bleeding — `
              + 'he still needs a medkit or the medbay.', 'good');
    }
  }

  /** The medkit is open: he is on his feet, and the box is two lighter. */
  _finishMedkit(medic, body) {
    if (!body || body.dead) return;
    if (!this.spendDoses(Ship.MEDKIT_DOSES)) return;   // supplies went elsewhere
    const floor = Math.round(body.maxHp * Ship.MEDKIT_SHARE);
    /* NEVER DOWNWARDS. A man at half health who takes a medkit is not
       pushed back to thirty percent — the dose is a floor, not a
       setting. */
    body.hp     = Math.max(body.hp, floor);
    body.state  = 'ok';
    body._bleedT = 0;
    body._bandaged = false;        // nothing left to stop
    body.bodyOrder = null;
    medic?.addXP?.('repair', 8);
    if (this.isPlayer && typeof UI !== 'undefined') {
      UI.notify(`${body.name} is back on his feet — ${Ship.MEDKIT_DOSES} doses gone.`, 'good');
    }
  }

  /** The meal is over: the item leaves the hold ONCE and feeds ONCE. */
  _finishMeal(who) {
    const meal = who._meal;
    who._meal = null;
    const hold = this.cargo;
    if (!meal || !hold?.items?.includes(meal)) return;   // somebody moved it
    const isEgg = meal.def?.tag === 'egg';
    /* THE MEAL SAYS WHAT IT IS WORTH (update66). Rations carry their
       own `hunger` now — there are four of them and no such thing as
       "the" ration to look up. Eggs and rats are not cargo, so they
       stay in HUNGER.FOOD where they always were: a split by KIND, not
       two copies of one number. */
    const food  = isEgg ? HUNGER.FOOD.spider_egg
                        : { hunger: meal.def?.hunger ?? 50, hp: 4 };
    /* A RATION PACK IS A STACK, not a parcel: one man eats ONE unit
       out of it and the rest stays on the shelf. Removing the whole
       item would throw away four meals to serve one. */
    if (!isEgg && (meal.qty ?? 0) > 1) meal.qty--;
    else hold.remove(meal);
    who.hunger = Utils.clamp((who.hunger ?? 0) + food.hunger, 0, 100);
    who.hp     = Math.min(who.maxHp, who.hp + food.hp);
    if (this.isPlayer && typeof UI !== 'undefined') {
      UI.notify(isEgg ? `${who.name} ate a spider egg.`
                      : `${who.name} ate a ration.`, isEgg ? 'good' : 'info');
    }
  }

  /* ── EVERY MOUTH ABOARD (update47) ────────────────────────
   *
   * One stomach loop for the crew and the cat alike. It drains the
   * meter, starves whoever hits zero, keeps the meal timers, and
   * lets a hungry CREWMAN reach for a ration by himself — the cat's
   * own meals are started by petTick, because for a cat eating sits
   * in a priority list against hunting and sitting with the wounded.
   *
   * A man eats where he stands. He does not walk to the hold: the
   * whole point of a ration pack is that you tear it open at your
   * post, and a gunner who abandoned his console to have lunch in
   * the middle of a fight would be a bug, not a feature.
   */
  hungerTick(dt) {
    const H = (typeof HUNGER !== 'undefined') ? HUNGER : null;
    if (!H) return;

    this.crew.forEach(c => {
      // A frozen man does not get hungry either (update77). Every
      // clock he carries is stopped, not just the one that kills him.
      if (!c || c.dead || c.frozen) return;

      // Mid-meal — for everybody, cat included. The timer itself is
      // `_busyTick`, which every timed action shares.
      if (c.busy && c._busyAct === 'eat') return;

      const rate = c.hungerPerSec ? c.hungerPerSec() : 0;
      if (!rate) return;
      c.hunger = Utils.clamp((c.hunger ?? 100) - rate * dt, 0, 100);

      if (c.hunger <= 0) {
        /* STARVATION IS A SLOPE, NOT A CLIFF. It takes the better
           part of three minutes at zero to kill, and the warning has
           been up since the meter hit STARVING — nobody loses a hand
           or an animal without having been told. */
        c.takeDamage?.(H.STARVE_HP_PER_SEC * dt, 'starvation');
        if (c.dead) {
          if (this.isPlayer && typeof UI !== 'undefined') {
            UI.notify(`${c.name} starved.`, 'alert');
          }
          return;
        }
      }
      if (c.hunger <= H.STARVING && !c._starveWarned) {
        c._starveWarned = true;
        if (this.isPlayer && typeof UI !== 'undefined') {
          UI.notify(`${c.name} is starving — there are rations in the hold.`, 'warn');
        }
      }
      if (c.hunger > H.HUNGRY) c._starveWarned = false;

      /* ── A HUNGRY MAN HELPS HIMSELF AGAIN (update81) ───────
       *
       * This is a REVERSAL of update69, and it is worth saying why,
       * because update69 removed automatic eating for a good reason.
       * The player's complaint then: "jedzenie jest dalej zjadane
       * automatycznie a nie powinno" — a hungry man reached into the
       * hold by himself, so the four rations, the FEED order and the
       * decision about what to carry were all decoration.
       *
       * His instruction now: "wrocimy do mechaniki ze jak jest
       * jedzenie w ladowni to w momecie jak sa glodni automatycznie
       * jedza, poczawszy od najgoryszych potraw po lepsze, oczywiscie
       * dalej mozesz dac rozkaz jedzenia zalagantowi manualnie".
       *
       * What changed in between is why it is not the same mistake:
       *
       *  - update70 gave hunger a MIDDLE. A hungry man works slower,
       *    so a ration buys something other than "not dying", and the
       *    hold no longer empties into a meter nobody watches.
       *  - update78 made a meal TAKE TIME, and update79 took a busy
       *    man off his console. So the automatic mouth costs seconds
       *    of work in the middle of a fight — it is a price, not a
       *    silent subtraction.
       *  - update81 eats the WORST box first (see `mealFor`). The good
       *    rations are still on the shelf when the player decides who
       *    gets them, which is the decision update69 was protecting.
       *
       * FEED stays, and stays exactly as it was. The automatic meal
       * takes the CLICKING away, not the choice.
       *
       * THE FIGHT COMES FIRST. Nobody opens a ration in a compartment
       * with a boarder in it — the same predicate that stops the
       * room's other work stops this too, so "a brawl pre-empts
       * everything" has one answer aboard this ship. Putting out a
       * fire does NOT stop him, and that is the player's own call:
       * "zostawi gaszenie czy zazadzanie modulem na rzecz jedzenia".
       *
       * The CAT is not here. She feeds herself in `petTick`, which is
       * where everything a cat decides lives, and a second caller for
       * the same meal would be the two-registers mistake again.
       */
      /* ONLY WHEN IT STARTS TO HURT (update87). He used to reach for a
         ration the moment he went under HUNGRY — so a hungry icon came
         up and a meal started in the same breath, two food marks side by
         side and nothing for the player to decide. Now a man carries on
         hungry (and slower for it — HUNGER.EFFORT) until his stomach
         starts costing him hide; feeding him before that is the FEED
         order, which is the player's call. */
      if (c.hunger <= 0 && !c.busy && !c.isPet && !c.down
          && c.isPlayer === this.isPlayer
          && !this.roomContested(c.roomId)) {
        this._startMeal(c);
      }
    });
  }
  /** Is a cat sitting with this body? Bleeding out runs slower if so. */
  petVigilOver(body) {
    if (!body?.roomId) return false;
    return this.crew.some(c => c.isPet && c.alive && c.roomId === body.roomId);
  }

  update(dt) {
    if (this.destroyed) return;

    /* A PICTURE IN THE HANGAR IS NOT A CONTRACT (update89 fix). The base
       builds a preview of the hull and walks the crew to their posts —
       and that ran the ducts, the stomachs and the egg clock on a copy
       of the ship, with the real notices: a case close to splitting
       "hatched" in the yard, again every time the preview was rebuilt,
       and the spam came with it. The clocks only run on the real hull,
       in flight; at the dock they stop (see infectionTick). */
    const live = !this.isPreview;
    if (live) this.pestTick(dt);
    this.searchTick();
    if (live) this.hungerTick(dt);
    this.petTick(dt);

    // Death animation
    if (this.hull <= 0) {
      this._deathTimer += dt;
      if (this._explosionTimer.tick(dt)) {
        const db = this.roomBounds();
        const rx = db.x + Utils.randFloat(0, db.w);
        const ry = db.y + Utils.randFloat(0, db.h);
        Particles.explosion(rx, ry, Utils.randFloat(0.5, 1.5));
      }
      if (this._deathTimer > 2.5) {
        this.destroyed = true;
      }
      return;
    }

    // ── Bodies: carrying, medbay healing, decay plague, ejection ──
    this._updateBodies(dt);

    // ── The carbonite: cells, and the men working the locks ──
    this.prisonerTick(dt);
    this._busyTick(dt);

    // ── A man sent to bag a body, arriving ──
    this.bagArrivals();

    // ── The bite and the egg case, both on the clock ──
    if (live) this.infectionTick(dt);

    // ── Anybody's prisoners, found by somebody else's boarders ──
    this.freeCaptives();

    // Sync crew presence into each system (bonuses, cyborg power, medbay)
    this.systems.forEach(sys => {
      // A medbay reads its OCCUPANTS (cat included); every other module
      // reads its OPERATORS. See medbayPatients (update54).
      sys.crew = sys.roomId
        /* A MEDBAY'S CREW IS ITS STAFF, NOT ITS PATIENTS (update78).
           This asked `medbayPatients` because the healing used to live
           in ShipSystem.update and needed the list — the healing is in
           Ship.update now, so what is left of `sys.crew` is what it is
           for every other module: who is WORKING it. A man lying on
           the table was counting as an operator, which among other
           things let a wounded Terra cyborg keep the module lit while
           he was unconscious on its floor. */
        ? this.crewOperating(sys.roomId)
        : [];
      // WHO IS AT THE CONSOLE (update43) — the only one whose skill
      // counts, and the only one who learns from the module's work.
      sys.consoleCrew = sys.roomId ? this.consoleOperator(sys.roomId) : null;
      sys.shipIsPlayer = this.isPlayer;   // so a system can talk to the UI
      /* HIS UNIT LEAVES WITH HIM (update93a). On a module that was full
         his +1 stood in for a reactor unit; when he stepped off the
         console the module simply took a unit from the bank instead, so
         the player saw the power "stay in the old module" while the
         reactor he walked to gained one — two units out of one man. The
         module now drops the unit he was covering, and only that one. */
      const cy = sys.type !== 'reactor' && sys.hasCyborg && sys.workingLevels > 0;
      if (sys._hadCyborg && !cy && sys.type !== 'reactor' &&
          (sys.desiredPower ?? 0) >= sys.workingLevels && sys.workingLevels > 0 &&
          sys._cyborgCovered) {
        sys.desiredPower = Math.max(0, sys.desiredPower - 1);
        sys.power = Math.min(sys.power, sys.desiredPower);
      }
      sys._cyborgCovered = cy && (sys.desiredPower ?? 0) >= sys.workingLevels;
      sys._hadCyborg = cy;
    });

    // Systems
    this.systems.forEach(sys => sys.update(dt));

    // FTL power flow: each system draws up to its DESIRED power,
    // limited by working (undamaged) levels and reactor budget.
    // → repairing a module automatically re-lights its bars.
    {
      /* WHO LOSES WHEN THE REACTOR SHRINKS (update90a).
       *
       * Every module asks for its desired power (capped by its working
       * levels). If the reactor cannot pay for all of it, units are taken
       * back from the module that was powered up MOST RECENTLY first —
       * `_powerStamp`, set in setPowerAt — and only then from the end of
       * the list, which is the order the old greedy loop starved them in.
       *
       * The player's report: a Terra cyborg at the reactor console adds a
       * unit; he gives it to the shields; the cyborg walks off — and the
       * shields KEPT it while the medbay at the end of the list went
       * dark. The unit he added is the one that goes now, exactly as a
       * cyborg's +1 leaves the module he walks out of.
       *
       * Cost is counted with ShipSystem.reactorDraw (the cyborg's
       * substitution rule), the same as Reactor.distribute and setPower. */
      const total = this.reactor.totalPower;
      /* THE ENEMY'S LIFTS COME FIRST (update93a). One hit on their
         reactor took the last spare unit, the lift went dark, and a crew
         split across two decks could no longer reach the reactor to fix
         it — a one-shot win. The player's proposal: on their hull the
         lifts keep their units while the core gives anything at all, so
         stopping them means wrecking the whole reactor. The modules pay
         for it. Ours stay as they were — the player decides his split. */
      const liftFirst = this.isPlayer ? 0 : Math.min(total, this.liftPowerNeed());
      const budget = total - liftFirst;
      const mods  = this.systems;
      const want  = mods.map(sys => Math.max(0, Math.min(sys.desiredPower ?? 0, sys.workingLevels)));
      const drawn = () => mods.reduce((a, sys, i) => a + sys.reactorDraw(want[i]), 0);
      const order = mods.map((_, i) => i).sort((a, b) =>
        ((mods[b]._powerStamp ?? 0) - (mods[a]._powerStamp ?? 0)) || (b - a));
      for (let guard = 256; drawn() > budget && guard > 0; guard--) {
        const i = order.find(k => want[k] > 0);
        if (i == null) break;
        want[i]--;
      }
      mods.forEach((sys, i) => { sys.power = want[i]; });
      this._powerLifts(total - drawn());     // update90: what is left lights the lifts
    }
    // Gravity answers to this frame's power (update91), like the lifts.
    this._gravityTick(dt);
    // …and so does the reactor's heat (update92).
    this._heatTick(dt);

    /* THE SLABS ANSWER TO THE POWER THIS FRAME (update77), so this
       runs AFTER the flow above and not with the other per-frame
       ticks. Put before it, `carboniteTick` read last frame's budget
       and a man whose slab had just gone cold stayed under for one
       more frame — harmless on its own, and exactly the kind of
       one-frame lie that turns into "sometimes he does not wake up"
       the moment anything else reads the same number. */
    this.carboniteTick();

    // Repair Bay: powered nanobots slowly mend every damaged system.
    // Rate ≈ half a crew member per powered level (1 level / ~17s).
    const rbay = this.getSystem('autorepair');
    if (rbay) {
      const rate = rbay.effectivePower() * Ship.AUTOREPAIR_RATE;
      if (rate > 0) {
        this.systems.forEach(sys => {
          if (sys !== rbay && sys.damagedLevels > 0) sys.repair(dt * rate);
        });
      }
    }

    this._reallocWeaponPower();   // damaged weapon module instantly de-powers ITS gun
    this.weapons.forEach((w, i) => {
      if (!w) return;
      // OPERATOR RULE: a gun charges only while a crew member stands
      // in ITS weapon module (slots without a room fall back to any
      // weapons-room operator — legacy boss overflow).
      const room   = this.weaponRoomFor(w);
      const manned = room
        ? this.crewOperating(room.id).length > 0
        : this.weaponRooms.some(r => this.crewOperating(r.id).length > 0);
      /* FORCED FIRE (update49) adds to the GUNNER's reduction and
         is then clipped by the same 75% ceiling inside the gun —
         a second, separate cap here would be a second copy of a
         limit that already exists. */
      const chipFire = (this.isPlayer && typeof Commander !== 'undefined')
        ? Commander.shipBonus('weaponCharge') : 0;
      w.update(dt, this.weaponCrewBonusFor(i) + chipFire, manned);
    });

    // Hit flashes fade; wrecked modules smoke so a broken ship LOOKS
    // broken even when you are not reading the power bar.
    this.rooms.forEach(room => {
      if (room._hitFlash > 0) room._hitFlash = Math.max(0, room._hitFlash - dt * 3.5);
      const sys = room.system;
      if (sys && sys.damagedLevels > 0 && Math.random() < dt * (1.2 * sys.damagedLevels)) {
        Particles.damageSmoke?.(room.cx + Utils.randFloat(-14, 14), room.cy);
      }
    });

    // Crew update and room assignment
    this.crew.forEach(c => {
      if (c.dead) return;
      /* ── A MAN IN A SLAB IS NOT IN A ROOM (update77) ────────
       *
       * ONE guard, here, and it is what makes carbonite mean anything:
       * he does not walk, does not fight, does not breathe, cannot be
       * set on fire and cannot be picked as the man at a console —
       * because everything that finds people finds them BY ROOM, and
       * this loop is the only thing that puts him in one.
       *
       * The alternative was `if (c.frozen) return;` in a dozen loops,
       * and the thirteenth loop written next month without one. */
      if (c.frozen) return;
      /* FIGHTS BELONG IN ROOMS, NOT IN THE WALLS (update42).
         `roomId` was never cleared when a crew member stepped OUT of
         every room rectangle — and there is real floor that belongs to
         no room: the 28px elevator trunk. Waiting for a cabin or riding
         one, a boarder kept the stale id of the room he had left, so
         melee matched him against someone on the other side of a wall,
         the brawl cancelled his ride, and if he lost, the corpse lay in
         the shaft while bodiesInRoom still reported him inside. Melee
         and the body loops now require you to actually BE in a room.

         Resolved BEFORE c.update, not after: melee runs inside update
         and has to judge where the man is standing NOW, not where he
         was last frame — and on his very first frame aboard there is
         no last frame at all. */
      const at = this.rooms.find(r => r.contains(c.x, c.y));
      c.inRoom = !!at;
      if (at) c.roomId = at.id;

      c.update(dt, this);

      // …and again afterwards, so everything that reads the roster
      // between frames sees where he ended up.
      const now = this.rooms.find(r => r.contains(c.x, c.y));
      c.inRoom = !!now;
      if (now) c.roomId = now.id;
    });
    /* CORPSES STAY (update40).
     *
     * This line was `filter(c => !c.dead)` — unconditional, and run at
     * the end of every single update, in the SAME call in which
     * CrewMember.update flips dying → dead. `_updateBodies` runs
     * BEFORE the crew loop, so it never once saw a body that had just
     * died, and the body was gone by the next frame.
     *
     * That quietly deleted an entire subsystem the game keeps telling
     * the player about: carrying the dead to an airlock, the
     * "…body is DECAYING — eject it before the crew gets sick!" warning
     * in markCombatStart, the corpse plague that spreads from a rotting
     * body to everyone in the room, the ☠/☣ head markers in
     * CrewMember.draw and the DECAYING tag in the crew panel. None of
     * it could ever fire. (The wounded half still worked, which is what
     * made the contradiction so easy to miss.)
     *
     * A body now lies where it fell until somebody carries it out —
     * `_updateBodies` removes the EJECTED, and that is the only way off
     * the ship. Animals are the exception: nobody holds a service for a
     * spider, and a hull that had been cleared of vermin should not
     * carry a list of little corpses for the rest of the run.
     *
     * Everything that counts people already filters `!c.dead`
     * (_playerCrewAliveCount, returnFromRun, crewInRoom, occupantsOf,
     * takenStationSlots, the wreck-cleared check), so keeping them in
     * the roster changes no count.
     */
    this.crew = this.crew.filter(c => !(c.dead && c.isPet));

    // O2
    this.oxygen.update(dt, this);

    // Fires
    this.fires.update(dt, this);

    // Breaches
    this.breaches.update(dt);

    // Elevators
    this.elevators.update(dt);

    // Doors
    this.doors.forEach(d => d.update(dt, this.crew));

    // Rooms with an open airlock are venting to space
    this.rooms.forEach(room => {
      room.isVacuum = this.doors.some(d =>
        d.isAirlock && d.open && d.roomA === room.id);
    });

    // Shield fade
    this._shieldAlpha = Math.max(0, this._shieldAlpha - dt * 2);

    // Shield pulse
    if (this._shieldPulse) {
      this._shieldPulse.update(dt);
      if (this._shieldPulse.done) this._shieldPulse = null;
    }
  }

  // ── Draw ─────────────────────────────────────────────────

  /** Bounding box of all rooms (the visual ship body) */
  roomBounds() {
    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    this.rooms.forEach(r => {
      minX = Math.min(minX, r.x);      minY = Math.min(minY, r.y);
      maxX = Math.max(maxX, r.x + r.w); maxY = Math.max(maxY, r.y + r.h);
    });
    return { x: minX, y: minY, w: maxX - minX, h: maxY - minY };
  }

  /* ── AN EGG CASE IS A THING IN A ROOM (update69) ───────────
   *
   * It used to exist only as a line in the hold, which is how the
   * player ended up with a crewman who vanished and a crate that
   * appeared: "jezeli zalogant zamieni sie w jajko to one powinno byc
   * na statku w formie graficznej, nie tylko w ladowni".
   *
   * There is still only ONE of them — the cargo item. This draws that
   * item at the spot stored on it, so selling it, dumping it or
   * letting the cat at it takes the thing off the deck as well, with
   * nothing to keep in step.
   */
  /** One path covering every module, grown by the hull margin.
   *  `inset` shrinks it, which is how the rim is drawn (see draw). */
  _hullPlatePath(ctx, inset = 0) {
    const M = HULL_GRID.MARGIN - inset;
    const R = Math.max(2, HULL_GRID.TILE + 4 - inset);
    ctx.beginPath();
    this.rooms.forEach(r => {
      ctx.roundRect(r.x - M, r.y - M, r.w + M * 2, r.h + M * 2, R);
    });

    /* THE LIFT TRUNKS ARE INSIDE THE HULL, so the plate has to cross
       them. A shaft is SHAFT_W wide and the modules either side are
       grown by MARGIN — 30 against 2x10, which leaves a ten-pixel
       notch bitten out of the hull at every lift. Harmless while the
       plate was one rectangle over the bounding box; visible the
       moment it started following the modules. */
    const b = this.roomBounds();
    const half = HULL_GRID.SHAFT_W / 2 + M;
    (this.elevators?.shafts ?? []).forEach(sh => {
      ctx.roundRect(sh.x - half, b.y - M, half * 2, b.h + M * 2, R);
    });
  }

  /* ── THE DUCT, DRAWN (update73) ───────────────────────────
   *
   * It has to be SEEN, and that is not decoration — it is the whole
   * reason this is safe to build. Rats and spiders are moving into the
   * duct, and a threat the player cannot see is a threat he does not
   * know he has. The same rule the karma wall is waiting on: a
   * consequence is shown, not reported.
   *
   * It does a second job for free. DECK_GAP is 0 now, so without this
   * band two decks meet on a hairline and a two-deck hull reads as one
   * tall grid. The duct IS the seam between decks.
   *
   * Drawn after the rooms so the grille sits over the floor plate, and
   * before the doors, which are taller than it and should cross it.
   */
  /* WHAT IS HAPPENING IN THE DUCTS (update85): how much air each one
     has, and whether it is burning. A duct emptying before its room is
     the whole of U11, and the player has to be able to see it. */
  _drawDuctState(ctx) {
    const H = HULL_GRID.VENT_H;
    this.rooms.forEach(room => {
      this.oxygen?.getRoom?.(room.id)?.drawDuct?.(ctx, room.x, room.ventY, room.w, H);
      if (!this.fires?.ductBurning?.(this, room.id)) return;
      const t = (typeof performance !== 'undefined' ? performance.now() : Date.now()) / 160;
      for (let x = room.x + 6; x < room.x + room.w - 4; x += 9) {
        const h = 3 + 3 * Math.abs(Math.sin(t + x * 0.7));
        ctx.fillStyle = 'rgba(255,120,20,0.85)';
        ctx.beginPath();
        ctx.moveTo(x - 3, room.ventY + H);
        ctx.lineTo(x + 1, room.ventY + H - h - 2);
        ctx.lineTo(x + 3, room.ventY + H);
        ctx.fill();
      }
    });
  }

  _drawVents(ctx) {
    const H = HULL_GRID.VENT_H;
    this.rooms.forEach(room => {
      const x = room.x, y = room.ventY, w = room.w;
      ctx.fillStyle = 'rgba(6,9,16,0.92)';
      ctx.fillRect(x, y, w, H);

      // Grille: short ticks, one every other tile, so it reads as a
      // duct rather than as a shadow under the ceiling.
      ctx.strokeStyle = this.isPlayer ? 'rgba(77,184,255,0.22)'
                                      : 'rgba(255,90,90,0.20)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      for (let tx = x + HULL_GRID.TILE; tx < x + w - 1; tx += HULL_GRID.TILE * 2) {
        ctx.moveTo(tx + 0.5, y + 2);
        ctx.lineTo(tx + 0.5, y + H - 2);
      }
      ctx.stroke();

      // The lip the deck above stands on.
      ctx.strokeStyle = this.isPlayer ? 'rgba(30,58,92,0.9)' : 'rgba(92,30,30,0.9)';
      ctx.beginPath();
      ctx.moveTo(x, y + H + 0.5);
      ctx.lineTo(x + w, y + H + 0.5);
      ctx.stroke();
    });
  }

  /* WHAT IS LEFT TO SEARCH ON A WRECK (update84). The hold opens when
     every compartment has had somebody in it, so which ones have not
     is the thing the player is steering by — shown on the hull, not in
     a counter. */
  _drawSearch(ctx) {
    if (!this.isDerelict) return;
    this.rooms.forEach(room => {
      if (this.isSearched(room.id)) return;
      ctx.fillStyle = 'rgba(0,0,0,0.38)';
      ctx.fillRect(room.x, room.floorTop, room.w, room.floorH);
      ctx.fillStyle = 'rgba(255,200,97,0.75)';
      ctx.font = '9px Share Tech Mono, monospace';
      ctx.textAlign = 'center';
      ctx.fillText('UNSEARCHED', room.cx, room.floorTop + room.floorH - 4);
    });
  }

  _drawEggs(ctx) {
    const eggs = (this.cargo?.items ?? []).filter(it =>
      it.def?.tag === 'egg' && it.meta && typeof it.meta === 'object' &&
      it.meta.roomId != null);
    if (!eggs.length) return;
    const t = (typeof performance !== 'undefined' ? performance.now() : 0) * 0.003;
    eggs.forEach(egg => {
      // Seen only where somebody is standing (update86a), like the pests.
      if (!this.pestVisible(egg.meta.roomId)) return;
      const room = this.getRoomById(egg.meta.roomId);
      if (!room) return;
      /* IN THE DUCT OVER WHERE HE FELL (update84, U10A: "jaja pająków
         pojawiają się w wentylacji"). Still the cargo item and nothing
         else — selling it takes it out of the duct as well. The x he
         fell at is kept, clamped inside the duct; the `y` an older save
         carries was the deck and is simply not read any more. */
      const x = Utils.clamp(egg.meta.x ?? room.cx, room.x + 8, room.x + room.w - 8);
      const y = room.ventY + room.ventH / 2;
      // The nearer it is to splitting, the harder it moves.
      const left = Utils.clamp((egg.meta.hatchT ?? EGG_SECONDS) / EGG_SECONDS, 0, 1);
      const beat = 1 + 0.12 * (1 - left) * Math.sin(t * (2 + (1 - left) * 6));
      ctx.save();
      ctx.globalAlpha = 0.85;
      ctx.fillStyle = 'rgba(30,60,26,0.9)';
      ctx.beginPath();
      ctx.ellipse(x, y, 5 * beat, 7 * beat, Math.PI / 2, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = egg.def.col || '#9fff7a';
      ctx.lineWidth = 1.5;
      ctx.stroke();
      ctx.globalAlpha = 1;
      ctx.fillStyle = egg.def.col || '#9fff7a';
      ctx.font = '9px monospace';
      ctx.textAlign = 'center';
      ctx.fillText('◓', x, y + 3);
      ctx.restore();
    });
  }

  draw(ctx) {
    // Cloaking field: powered cloak renders the whole ship as a
    // shimmering phantom (visual feedback for the evasion bonus)
    const cloakSys = this.getSystem('cloaking');
    const cloaked  = !!(cloakSys && cloakSys.cloakActive);
    if (cloaked) {
      /* A STEADY VEIL, NOT A BREATHING ONE (update90a). The whole hull
         used to pulse between 43% and 67% opacity, slowly, for as long as
         the cloak ran — the player saw an enemy ship whose lights kept
         going down and up again ("ciemnieje jakby światło gasło, dziwnie
         miga") and nothing on it said why. Now it is simply dimmed, and
         the outline and the word CLOAKED below say what it is. */
      ctx.save();
      ctx.globalAlpha = Ship.CLOAK_ALPHA;
    }

    /* ── THE PLATE FOLLOWS THE MODULES (update73) ───────────
     *
     * It used to be ONE rounded rectangle around `roomBounds()`, which
     * was fine while every hull in the game was a solid block. The
     * moment Bastet grew a spur on her upper deck the plate covered
     * the empty square beneath it, and the starter ship looked like a
     * ship with a hole in her — a bug, not a silhouette.
     *
     * So the plate is the UNION of the modules. Each room contributes
     * its own rounded rectangle to one path; overlapping fills merge
     * under nonzero winding, so what is left is an outline that walks
     * round the actual hull, notches and spurs included.
     *
     * The rim is done by filling twice rather than stroking, because
     * stroking a path of overlapping rectangles draws every internal
     * edge as well: fill the union in the rim colour, then fill it
     * again three pixels smaller in the plate colour.
     *
     * The 14 that used to be written here was MARGIN before MARGIN was
     * a tile wide. One more copy of a number the grid already owned. */
    const b = this.roomBounds();
    this._hullPlatePath(ctx, 0);
    ctx.fillStyle = this.isPlayer ? '#1e3a5c' : '#5c1e1e';
    ctx.fill();
    this._hullPlatePath(ctx, 3);
    ctx.fillStyle = 'rgba(10,14,26,0.97)';
    ctx.fill();

    // Engine glow at rear
    const engX = this.isPlayer ? b.x - 14 : b.x + b.w + 14;
    const g = ctx.createRadialGradient(engX, b.y + b.h/2, 2, engX, b.y + b.h/2, 30);
    g.addColorStop(0, this.isPlayer ? 'rgba(26,255,140,0.6)' : 'rgba(255,80,40,0.6)');
    g.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = g;
    ctx.fillRect(engX - 30, b.y + b.h/2 - 30, 60, 60);

    // Rooms (with systems, O2, fire, breach overlays)
    this.rooms.forEach(room => {
      if (room.system) {
        room.system.draw(ctx);
      } else {
        // Empty module — floor tile + visible frame (crew quarters,
        // or an enemy hull slot with no system installed)
        this._drawEmptyRoom(ctx, room);
      }

      // O2 overlay
      const ro = this.oxygen.getRoom(room.id);
      if (ro) ro.draw(ctx, room.x, room.y, room.w, room.h);

      // HIT FLASH — a shell landing here lights the compartment for a
      // moment. Without it a hit on a far room is easy to miss entirely.
      if (room._hitFlash > 0) {
        ctx.fillStyle = `rgba(255,255,255,${0.55 * room._hitFlash})`;
        ctx.fillRect(room.x, room.y, room.w, room.h);
        ctx.strokeStyle = `rgba(255,90,110,${room._hitFlash})`;
        ctx.lineWidth = 2;
        ctx.strokeRect(room.x + 1, room.y + 1, room.w - 2, room.h - 2);
      }
    });

    // The ceiling ducts — over the floor plates, under the doors.
    this._drawVents(ctx);
    this._drawDuctState(ctx);
    /* …and what is in them (update84): egg cases, sacs, rats, spiders.
       Right after the grille so they read as INSIDE it; a spider on
       its way down is drawn here too and passes behind nothing that
       matters. */
    this._drawEggs(ctx);
    this.pests.forEach(p => { if (!p._climb) p.draw(ctx, this); });
    this._drawSearch(ctx);

    // Elevators
    this.elevators.draw(ctx);
    /* …and whatever is climbing a shaft goes on top of it (update86a).
       Drawn with the others it was painted over by the shaft itself —
       the first screenshot of a climbing rat showed an empty shaft. */
    this.pests.forEach(p => { if (p._climb) p.draw(ctx, this); });

    // Doors
    this.doors.forEach(d => d.draw(ctx));

    // Crew (particles below crew)
    Particles.draw(ctx, 0);
    /* ZERO-G (update91): nobody stands on the deck — everybody hangs a
       little off it and bobs, each on his own phase. Drawing only: where
       a man IS does not change, the rules aboard read the same x and y.
       A cabin carries its rider and a cat in the duct is drawn there. */
    const zg = this.zeroG;
    const now = (typeof performance !== 'undefined' ? performance.now() : 0) / 1000;
    if (zg) this._drawZeroGMotes(ctx, now);
    this.crew.forEach((c, i) => {
      if (zg && c && !c._ridingShaft && c._ductY == null) {
        ctx.save();
        ctx.translate(0, Ship.floatOffset(now, i, c.down));
        c.draw(ctx);
        ctx.restore();
      } else c.draw(ctx);
    });

    // Fires
    this.fires.draw(ctx);

    // Breaches
    this.breaches.draw(ctx);

    /* THE GUN STRIPS STAY SOLID UNDER A CLOAK (update54).
       Everything from here up was drawn through the cloak's pulsing
       globalAlpha, the charge boxes on the mounts included — so while
       either side was cloaked the one readout that says "how long until
       that gun fires" faded in and out at a third of its brightness and
       READ AS FROZEN. The guns were charging the whole time (nothing in
       the engine ties charge to a cloak, and section 173 nails that
       down); the player simply could not see them move. The field hides
       the hull, not its gunnery clock. */
    const cloakAlpha = ctx.globalAlpha;
    if (cloaked) ctx.globalAlpha = 1;
    this._drawWeaponMounts(ctx);
    if (cloaked) ctx.globalAlpha = cloakAlpha;

    // Shield ring
    this._drawShield(ctx);

    // Hull damage glow
    if (this.hull / this.hullMax < 0.35) {
      const b = this.roomBounds();
      const alpha = (0.35 - this.hull / this.hullMax) * 0.5;
      ctx.fillStyle = `rgba(255,45,68,${alpha})`;
      ctx.fillRect(b.x - 14, b.y - 14, b.w + 28, b.h + 28);
    }

    if (cloaked) {
      ctx.restore();
      // The hull outline, in the cloak's own violet, and what it is.
      const b = this.roomBounds();
      ctx.save();
      ctx.strokeStyle = 'rgba(204,68,255,0.55)';
      ctx.lineWidth = 2;
      ctx.setLineDash([6, 4]);
      ctx.strokeRect(b.x - 10, b.y - 10, b.w + 20, b.h + 20);
      ctx.setLineDash([]);
      ctx.fillStyle = '#cc44ff';
      ctx.font = 'bold 11px Share Tech Mono, monospace';
      ctx.textAlign = 'center';
      const left = Math.ceil(cloakSys.cloakTimer ?? 0);
      ctx.fillText(left > 0 ? `CLOAKED ${left}s` : 'CLOAKED', b.x + b.w / 2, b.y - 16);
      ctx.restore();
    }
  }

  /** How see-through a cloaked hull is drawn — steady (update90a). */
  static get CLOAK_ALPHA() { return 0.45; }

  /** Empty room: tiled floor, subtle grid line, clear frame */
  _drawEmptyRoom(ctx, room) {
    /* The INTERIOR, not the module (update73) — the same rule
       `_fitSystemToRoom` applies to a fitted module. A bay's floor
       plate stops where the ceiling duct begins, or the grille ends up
       drawn on top of a floor that is pretending to be up there. */
    const x = room.x, y = room.floorTop, w = room.w, h = room.floorH;
    const tile = Assets.has('room_default') ? Assets.get('room_default') : null;
    if (tile) {
      ctx.save();
      ctx.globalAlpha = 0.8;
      Assets.tileRect(ctx, tile, x, y, w, h, 48);
      ctx.restore();
    } else {
      ctx.fillStyle = 'rgba(16,22,38,0.9)';
      ctx.fillRect(x, y, w, h);
    }

    // Frame — always visible so the module reads as a room
    ctx.strokeStyle = 'rgba(110,135,175,0.55)';
    ctx.lineWidth = 1.5;
    ctx.strokeRect(x + 0.5, y + 0.5, w - 1, h - 1);
  }

  /**
   * Guns sit ON the hull, along the top edge, spread across its width —
   * they used to float off the nose in a vertical stack, which read as a
   * detached UI widget rather than as part of the ship.
   */
  /**
   * WHERE EVERY GUN ON THIS HULL IS — ONE ANSWER (update80).
   *
   * This layout used to live inside `_drawWeaponMounts` as a local
   * `gx` in a forEach, and the shot came out of `combat.js` at
   * `roomBounds().x + w + 10, y + h/2` — the corner of the rectangle
   * round the WHOLE ship. So the gun was drawn along the top edge and
   * fired from the flank, and every gun aboard fired from the same
   * pixel no matter which bay it was bolted into. Two positions for
   * one gun, in two files, that had never met.
   *
   * The player put it plainly: "a wystrzal rakieta lasery i wszytko
   * pociski powinny wychodzic z dzialek a nie z przodu statku".
   *
   * One function answers it now, and both the picture and the bolt
   * read it. `muzzle` is the tip of the barrel on the side the gun
   * points at — which is the enemy, because `dir` is the same flag
   * the sprite is drawn with.
   */
  weaponMounts() {
    const b = this.roomBounds();
    const mounted = this.weapons.filter(Boolean);
    if (!mounted.length) return [];

    // Space the mounts by whichever is wider — the gun or its charge
    // strip — so an 18-second cannon's boxes never run into its neighbour.
    const GW = 44, GH = 18, GAP = 14;
    const widths = mounted.map(w => Math.max(GW, w.chargeStripWidth?.() ?? GW));
    const total = widths.reduce((a, b) => a + b, 0) + (mounted.length - 1) * GAP;
    // Centre the row on the hull; if the hull is narrow, start at its edge.
    const startX = Math.round(b.x + Math.max(6, (b.w - total) / 2));
    // Clear of the plating: the charge boxes hang under the gun, so
    // a tighter offset put them straight on top of the hull.
    const y = Math.round(b.y - 42);
    const dir = this.isPlayer ? 1 : -1;      // point at the enemy

    const out = [];
    let gx = startX;
    mounted.forEach((w, i) => {
      // draw() centres itself on the 44px gun box, so offset by the
      // difference when the strip is the wider of the two.
      const x = gx + Math.round((widths[i] - GW) / 2);
      out.push({
        weapon: w, x, y, w: GW, h: GH, dir,
        muzzleX: dir > 0 ? x + GW : x,
        muzzleY: y + GH / 2,
      });
      gx += widths[i] + GAP;
    });
    return out;
  }

  /** Where one weapon's barrel ends, or null if it is not mounted. */
  muzzleFor(weapon) {
    const m = this.weaponMounts().find(q => q.weapon === weapon);
    return m ? { x: m.muzzleX, y: m.muzzleY } : null;
  }

  _drawWeaponMounts(ctx) {
    this.weaponMounts().forEach(m => m.weapon.draw(ctx, m.x, m.y, false, m.dir));
  }

  _drawShield(ctx) {
    if (this._shieldAlpha <= 0 && this.shieldBars <= 0) return;
    const b   = this.roomBounds();
    const cx  = b.x + b.w / 2;
    const cy  = b.y + b.h / 2;
    const rx  = b.w * 0.68 + 20;
    const ry  = b.h * 0.68 + 20;
    const alpha = Math.max(this._shieldAlpha, this.shieldBars > 0 ? 0.3 : 0);

    ctx.save();
    ctx.globalAlpha = alpha;

    // Shield rings — layered strokes instead of shadowBlur (GPU-cheap)
    for (let ring = 0; ring < this.shieldBars; ring++) {
      // Soft outer glow: wide translucent stroke
      ctx.strokeStyle = 'rgba(26,140,255,0.18)';
      ctx.lineWidth   = 7;
      ctx.beginPath();
      ctx.ellipse(cx, cy, rx + ring * 8, ry + ring * 8, 0, 0, Math.PI * 2);
      ctx.stroke();
      // Crisp core line
      ctx.strokeStyle = '#4db8ff';
      ctx.lineWidth   = 2;
      ctx.beginPath();
      ctx.ellipse(cx, cy, rx + ring * 8, ry + ring * 8, 0, 0, Math.PI * 2);
      ctx.stroke();
    }
    // Hit flash ring
    if (this._shieldAlpha > 0.3) {
      ctx.strokeStyle = '#bfe8ff';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.ellipse(cx, cy, rx + 4, ry + 4, 0, 0, Math.PI * 2);
      ctx.stroke();
    }
    ctx.restore();
  }

  // ── Serialise ────────────────────────────────────────────

  serialise() {
    return {
      layoutKey: this.layoutKey,
      hull: this.hull,
      // Systems serialised BY INDEX — layouts are deterministic, and a
      // ship can carry several systems of the same type (weapon modules).
      // Save the DESIRED allocation, not the momentary one: a module
      // that happened to be shot out when we jumped would otherwise
      // come back permanently switched off after repairs.
      systems: this.systems.map(s => ({
        type: s.type, level: s.level, power: Math.max(s.power, s.desiredPower ?? 0),
      })),
      weapons: this.weapons.map(w => w ? { defKey: w.defKey, slot: w.slot, roomId: w.roomId ?? null } : null),
      // `weaponCargo` is NOT written any more (update75) — a boxed gun
      // is a crate in `cargo`, like every other thing aboard.
      cargo: this.cargo ? this.cargo.serialise() : null,
      extraModules: [...(this._extraModules ?? [])],
      prisoners: this.prisoners.map(p => ({ ...p })),
      /* THE DUCTS (update84). An infestation survives a reload — it
         did when the rats were crew records, and moving them must not
         turn saving into a free fumigation. */
      pests: this.pests.filter(p => !p.dead).map(p => p.serialise()),
      reactor: this.reactor.level,
      // Heat is state, not derived (update92); a whole number is plenty.
      heat: Math.round(this.reactorHeat ?? 0),
      /* Written since update90: the power above already keeps the lifts'
         spare units free. A save without it is from before, and gets
         them taken back once (Ship._reserveLiftPower). */
      lifts: 1,
    };
  }

  static deserialise(data, isPlayer, wx, wy) {
    const ship = new Ship(data.layoutKey, isPlayer, wx, wy);
    ship.hull  = data.hull;
    ship.reactor.level = data.reactor;
    ship.reactorHeat = Utils.clamp(data.heat ?? 0, 0, 100);   // an old save: cold

    // Re-apply purchased modules IN ORDER before restoring systems so
    // the systems array lines up index-for-index with the save.
    (data.extraModules ?? []).forEach(e => {
      if (typeof e === 'string') ship.addModule(e);
      else ship.addModuleAt(e.type, e.roomId) || ship.addModule(e.type);
    });

    data.systems.forEach((sd, i) => {
      const sys = ship.systems[i];
      // `systemType` so a hull saved with a 'brig' still lines up with
      // the carbonite bay the modules loop above just rebuilt.
      if (!sys || sys.type !== systemType(sd.type)) return;   // layout mismatch guard
      if (sd.type === 'reactor') return;  // pips derive from module level
      sys.level = sd.level; sys.power = sd.power; sys.desiredPower = sd.power;
      /* O2 IS LEVEL 2 AT LEAST (update87). Every hull was built with a
         one-pip life support, which carries three men — and a starting
         crew of four ran a deficit from the first minute. A hull saved
         before this comes out of the hangar with the floor applied; its
         power is the player's to give it. */
      if (sys.type === 'oxygen' && sys.level < Ship.O2_MIN_LEVEL) sys.level = Ship.O2_MIN_LEVEL;
    });
    // A hull saved before update90 gives its lifts their spare units back.
    if (data.lifts == null) ship._reserveLiftPower();
    /* Prisoners ride home in the hull's record. A save written before
       the brig existed simply has none. */
    ship.prisoners = (data.prisoners ?? []).map(p => ({
      id: p.id, name: p.name, bounty: p.bounty ?? 0, escapeT: 0, warned: false,
    }));
    // A save written before update84 has none here — its rats are in
    // the crew list, and game.js converts those as it loads them.
    (data.pests ?? []).forEach(pd => ship.addPest(Pest.deserialise(pd)));

    // Saves written before the grid hold existed simply have no `cargo`
    // key — those ships keep the empty grid the constructor built.
    if (data.cargo && typeof CargoGrid !== 'undefined') {
      ship.cargo = CargoGrid.deserialise(data.cargo);
    }

    /* ── THE OLD RACK, EMPTIED INTO THE HOLD (update75) ──────
     *
     * A save written before the rack was deleted carries `weaponCargo`:
     * gun keys with no crate anywhere. Box each one now.
     *
     * AFTER the hold is restored, not before — boxing into the empty
     * grid the constructor built would put the crates somewhere that is
     * thrown away two lines later, and the guns would be gone with no
     * error anywhere to say so.
     *
     * A gun that will not fit is SAID OUT LOUD. The alternative is to
     * keep a second list alive to carry it, which is the exact thing
     * being deleted. */
    (data.weaponCargo ?? []).forEach(key => {
      if (ship.boxWeapon(key)) return;
      const label = (typeof WEAPON_DEFS !== 'undefined' && WEAPON_DEFS[key]?.label) || key;
      if (typeof UI !== 'undefined') {
        UI.notify?.(`${label} had no crate and the hold is full — it was left at the dock.`, 'warn');
      }
    });

    ship.weapons = [];
    data.weapons.forEach(wd => {
      if (wd) {
        ship.installWeapon(wd.defKey, wd.slot);
        /* A SAVE FROM BEFORE update60 carries no roomId; installWeapon
           has just stamped the positional one, which IS what that save
           meant. A newer save overrides it with the bay the gun was
           really in. */
        if (wd.roomId && ship.weapons[wd.slot]) ship.weapons[wd.slot].roomId = wd.roomId;
      }
    });

    return ship;
  }
}

/* The grid is the contract between the code and the art kit — the
   brief that the module, shaft, engine and prow tiles are cut to reads
   these numbers, so they have to be reachable from a test. */
if (typeof window !== 'undefined') {
  window.GRAVITY_CONFIG = GRAVITY_CONFIG;
  window.REACTOR_HEAT_CONFIG = REACTOR_HEAT_CONFIG;
  window.HULL_GRID = HULL_GRID;
  window.buildHull = buildHull;
}
