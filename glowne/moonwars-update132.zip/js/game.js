/* ============================================================
   MOON WARS — game.js  (clean rewrite)
   ============================================================ */
'use strict';

const Game = (() => {

  // ── State ─────────────────────────────────────────────────
  let STATE        = 'menu';   // menu | map | combat | event | station | outcome
  let _prevTime    = 0;
  let _paused      = false;

  let _playerShip  = null;
  let _enemyShip   = null;
  let _sectorMap   = null;
  let _station     = null;
  let _event       = null;
  let _outcomeType = null;
  let _outcomeScrap= 0;
  let _outcomeTimer= 0;

  // GRAVEYARD used to be here. The memorial is a tab in the base now —
// THE HILL — where it sits beside the barracks it is the other half of,
// so the menu no longer needs its own door to a list of the dead.
/* CONTINUE LIVES IN THE BASE NOW (update57). The title screen asked
   the player to decide between "enter the base" and "carry on the
   contract" before he could see the state of either — and a contract
   in the air is a fact ABOUT the base: the hangar is short a hull and
   the barracks is short a crew until it comes home. Two doors, and the
   base is the room they both open into. */
const MENU_ITEMS = ['ENTER BASE','OPTIONS','NEW GAME'];
/* THE TITLE SCREEN (update123, jj: "co do menu zrób to, co napisałeś"):
   your own hull drifting past the Moon with its roof on, a line under
   ENTER BASE saying what is waiting in there, and NEW GAME — behind a
   question, because it wipes the save. */
const MENU_LAYOUT = { top: -20, gap: 70, w: 200, h: 40, flyT: 48, flyY: 0.87, flyScale: 0.6 };
/* THE CHASE (update125, jj: "powinien ścigać jakiś jeden duży mniejszego
   i powinni strzelać do siebie" — and then: "ten statek powinien być tej
   samej wielkości … wziąć najlepszy statek jaki mamy w hangarze, aby
   ścigał tego zwykłego"). The best hull the shipyard sells chases the
   one you fly, both at the same size, trading fire as they cross the
   screen under the buttons. */
const MENU_CHASE = { foeScale: 0.6, gap: 150 };
/* A REAL FIGHT IN THE CHASE (update131, jj: "menu: prawdziwa walka w
   pościgu — nowe bronie i osłony; po najechaniu widać wnętrze"). Every
   gun on both hulls charges and fires its own shot — the same bodies,
   muzzle flashes, blasts and honeycomb shields as a fight — but nothing
   is damaged: a picture, not a contract. Guns charge `chargeScale` of
   their real time (never under `minCharge` s) so the screen stays busy;
   `evade` of the shots miss and fly on; a shield layer that is knocked
   down comes back after `shieldBack` s; a roof lifts at `roofSpeed`/s
   while the pointer is over its hull. */
const MENU_FIGHT = { chargeScale: 0.45, minCharge: 1.8, evade: 0.15,
                     shieldBack: 3.5, roofSpeed: 4, maxShots: 40 };
  let _fatal = '';   // set when a required module could not be loaded

  // ── Screen transition ────────────────────────────────────
  //  Hard cuts between menu / base / map / combat felt jarring; a short
  //  fade sells them as one continuous journey. Purely cosmetic: the
  //  state has ALREADY changed when the fade plays, so nothing can get
  //  stuck behind it.
  let _fadeT = 0;
  const FADE_TIME = 0.28;
  function _beginFade() { _fadeT = FADE_TIME; }
  function _drawFade(ctx) {
    if (_fadeT <= 0) return;
    const a = Math.min(1, _fadeT / FADE_TIME);
    ctx.fillStyle = `rgba(7,8,15,${a * 0.85})`;
    ctx.fillRect(0, 0, Renderer.getWidth(), Renderer.getHeight());
  }
  let _menuHover   = null;
  let _mapHover    = null;

  let _combatTimer = 0;
  let _combatFired = false;
  let _selectedWeapon = null;   // weapon awaiting a target room
  /* The open body menu: which body, and where it was opened. Geometry
     lives in Renderer.bodyMenuRects — this is only the anchor. */
  let _bodyMenu = null;

  // FTL-style crew stations: SAVE snapshots current rooms,
  // RETURN sends everyone back. Session-only (not serialised).
  let _savedStations = null;    // Map crewId → roomId

  // Map screen has two switchable views: sector MAP or the SHIP
  let _mapView = 'map';   // 'map' | 'ship'

  /* ── A FIGHT ENDS ON THE SHIP, NOT ON THE MAP (update93a) ────
   * The player: "po walce gracz sam załącza mapę — nieraz po walce
   * trzeba ponaprawiać albo zmienić coś, więc przeskok na mapę jest
   * negatywny". Every way out of a fight lands in the map state (that
   * is where jumping lives) but with the SHIP in view; [M] / SHOW MAP
   * brings the chart up when he is ready. */
  function _leaveFight() {
    STATE = 'map';
    _mapView = 'ship';
  }

  /* THE NAMES IN PLAY (update93a) — every hand on our hull, on theirs
     (captives included) and in the barracks. A new name is drawn
     against these, so the same name does not turn up on both sides. */
  /* The men out in the wreckage are on the roster down the left (update93b). */
  if (typeof Renderer !== 'undefined' && Renderer.setEvaCrew) {
    Renderer.setEvaCrew(() => (CombatManager.salvage?.men ?? []).filter(m => m.phase !== 'muster').map(m => m.c));
  }
  if (typeof CrewMember !== 'undefined') {
    CrewMember.namesInPlay = () => {
      const out = [];
      [_playerShip, _enemyShip].forEach(sh => (sh?.crew ?? []).forEach(c => { if (c?.name) out.push(c.name); }));
      try { if (typeof Base !== 'undefined' && Base.takenNames) out.push(...Base.takenNames()); } catch (e) {}
      return out;
    };
  }

  // Boarding parties in transit (player → enemy, enemy → player)
  let _boardingParty = null;   // { crew:[], t, dur }
  let _enemyParty    = null;
  let _counterBoarded = false; // enemy already sent boarders this fight
  let _derelictOffered = false; // already offered the search/destroy choice this fight
  let _noQuarterSaid   = false; // told him once why nobody strikes to him
  /* WANTED_ENCOUNTER_CHANCE IS GONE (update66). It was the odds that a
     rolled commander turned out to be somebody off the board — a
     second answer to a question the MAP now answers, and the two would
     have disagreed the first time either was tuned. The one number
     left is SectorMap.WANTED_ON_MAP. */
  let _sosFightPending = false; // this fight was started to take a scavenger's He2
  /* THE COMMANDER FLYING THIS CONTRACT (update43), or null. The very same
     object that sits in Base.commanders() — never a copy of it. */
  let _commander = null;

  // Combat pending behind a negotiation dialog + nebula battle flag
  let _pendingCombat  = null;   // { difficulty, nebula }
  let _nebulaCombat   = false;  // both ships fight at −2 reactor power
  /** How often an asteroid node holds a fight (update100); the rest is a quiet crossing. */
  const ASTEROID_FIGHT_ODDS = 0.7;
  let _surrenderAsked = false;  // enemy already offered surrender this fight

  // ── Boot ──────────────────────────────────────────────────
  /** Modules that arrived AFTER the first release of index.html.
   *  If a player copies new js/ files but keeps an old index.html, the
   *  script tags are missing and the game dies the moment it needs
   *  them ("Enter Base" plays a click and nothing happens). Rather
   *  than depend on the player editing HTML, load them ourselves. */
  const LATE_MODULES = [
    { name: 'Base',       src: 'js/base.js' },
    { name: 'BaseScreen', src: 'js/basescreen.js' },
    { name: 'Chips',      src: 'js/chips.js' },
    { name: 'CargoGrid',  src: 'js/cargo.js' },
    { name: 'LootScreen', src: 'js/lootscreen.js' },
    { name: 'DockingGame', src: 'js/wreck.js' },
    { name: 'Commander',    src: 'js/commander.js' },
    /* update84 — the rats and spiders moved out of the crew and into
       the ducts, and this is the file they live in now. */
    { name: 'Pest',         src: 'js/pests.js' },
    /* update124 — every man drawn with his own face. */
    { name: 'CrewArt',      src: 'js/crewart.js' },
    /* update126 — the guns, their shots and every hit, painted. */
    { name: 'WeaponArt',    src: 'js/weaponart.js' },
  ];

  function _moduleLoaded(name) {
    return typeof window !== 'undefined' && typeof window[name] !== 'undefined';
  }

  function _loadScript(src) {
    return new Promise((resolve, reject) => {
      const el = document.createElement('script');
      el.src = src;
      el.dataset.autoloaded = 'true';   // so it's distinguishable from index.html's own tags
      el.onload  = () => resolve(src);
      el.onerror = () => reject(new Error('could not load ' + src));
      document.head.appendChild(el);
    });
  }

  async function _ensureModules() {
    const missing = LATE_MODULES.filter(m => !_moduleLoaded(m.name));
    if (!missing.length) return true;
    console.warn('[Game] index.html is out of date — loading',
                 missing.map(m => m.src).join(', '), 'at runtime.');
    for (const m of missing) {
      try { await _loadScript(m.src); } catch (e) { console.error('[Game]', e.message); }
    }
    const stillMissing = LATE_MODULES.filter(m => !_moduleLoaded(m.name));
    if (stillMissing.length) {
      _fatal = 'Missing game files: ' + stillMissing.map(m => m.src).join(', ') +
               ' — re-extract the update over C:\\MoonWars\\ (index.html included).';
      return false;
    }
    return true;
  }

  async function init() {
    const canvas = document.getElementById('game-canvas');
    Renderer.init(canvas);
    Input.init(canvas);
    Audio.init();
    Save.load();
    // AFTER Save.load — the settings blob does not exist before it.
    // Until update40 the whole settings block in save.js was written,
    // persisted, and never read by a single line of game code.
    Audio.applySettings?.();

    await _ensureModules();

    Utils.setLoadingProgress(5, 'Generating sprites…');
    await Assets.init((p, m) => Utils.setLoadingProgress(10 + p * 75, m));
    Utils.setLoadingProgress(87, 'Animating crew…');
    Animation.init();
    // The jump and the arrival are filmed in the game, not in the suites
    // (update118) — unless the player switched them off (update122).
    if (typeof JumpScene !== 'undefined') JumpScene.enabled = _filmsOn();
    Utils.setLoadingProgress(100, 'Ready.');
    await new Promise(r => setTimeout(r, 500));
    Utils.hideLoadingScreen();

    STATE = 'menu';
    requestAnimationFrame(_loop);
  }

  // ── Loop ──────────────────────────────────────────────────
  function _loop(ts) {
    requestAnimationFrame(_loop);
    const dt = Math.min((ts - _prevTime) / 1000, 0.05);
    _prevTime = ts;
    Input.beginFrame();
    /* ── PAUSE, THE WAY FTL DOES IT (update76) ────────────────
     *
     * Two things changed and they are one change.
     *
     * SPACE, not P. The player's call, and P had the second problem
     * anyway: a key nobody finds. Space is the pause key EVERYWHERE it
     * can pause and means nothing else anywhere — the lesson of TAB in
     * update74, where one key did two jobs depending on which screen
     * was on top and came back as a bug report. The two places Space
     * used to mean "carry on" now read Enter, and both of them already
     * had a button and a click for the same job.
     *
     * And `_update(0)` instead of skipping the update. THE WORLD
     * STOPS, THE PLAYER DOES NOT: every clock in this game is driven
     * by `dt`, so a zero tick simulates exactly nothing while clicks,
     * selection, orders and power still go through the same code they
     * always do. Skipping the update froze the input too, which made
     * the pause a screenshot rather than a moment to think in — and
     * thinking is what a pause is FOR in a real-time game.
     *
     * Only where there is something to stop. The salvage clock on a
     * wreck is a pressure the player is meant to feel; a pause there
     * would just be a longer wreck. */
    _step(dt);
    _draw();
  }

  /** One frame of WORLD, with the pause decision in it. Split out of
   *  `_loop` so a test can take a frame without a browser: the loop
   *  above is now timing and drawing, and everything that decides what
   *  moves is in here, where it can be asked. */
  function _step(dt) {
    /* A FILM HOLDS THE CLOCK (update118). The world is already where the
       jump took it; nothing in it moves until the film is over, and the
       first click or key — SPACE included, which therefore does not
       also pause — skips the rest. */
    if (typeof JumpScene !== 'undefined' && JumpScene.active()) {
      if (Input.mouse.leftPressed || Input.isPressed('Space') || Input.isPressed('Escape')
          || Input.isPressed('Enter') || Input.isPressed('NumpadEnter')) JumpScene.skip();
      else JumpScene.update(dt);
      // the screen fade is part of the picture, not of the world: it runs on
      if (_fadeT > 0) _fadeT = Math.max(0, _fadeT - dt);
      return;
    }
    if (_canPause() && Input.isPressed('Space')) _paused = !_paused;
    if (!_canPause()) _paused = false;
    /* THE BOOK STOPS THE CLOCK (update99, jj: "walka wstrzymana"). The
       world gets no time while it is open; the screens still run, so
       the Book can take its clicks. */
    if (!_canPause()) _B().open = false;
    _update(_paused || _B().open ? 0 : dt);
  }

  /** Where pausing means anything: the two screens that run a clock
   *  the player is expected to think against. Read in the loop and by
   *  the banner, so what can be paused and what SAYS it is paused can
   *  never be two different answers. */
  function _canPause() { return STATE === 'combat' || STATE === 'map'; }

  // ── Update ────────────────────────────────────────────────
  function _update(dt) {
    if (_fadeT > 0) _fadeT = Math.max(0, _fadeT - dt);
    UI.update(dt);
    Camera.update(dt);
    Particles.update(dt);
    if (typeof WeaponArt !== 'undefined') WeaponArt.update(dt);   // the blasts play out (update126)

    if (STATE === 'menu')    _updateMenu(dt);
    if (STATE === 'options') _updateOptions(dt);
    if (STATE === 'base')    _updateBase(dt);
    if (STATE === 'map')     _updateMap(dt);
    _checkPromo();
    if (STATE === 'combat')  _updateCombat(dt);
    if (STATE === 'outcome') _updateOutcome(dt);
    if (STATE === 'promo')   _updatePromo(dt);
    if (STATE === 'dismiss') _updateDismiss(dt);
    if (STATE === 'loot')    _updateLoot(dt);
    if (STATE === 'docking')  _updateDocking(dt);
    // The racks in the hold are the ammo. Whatever moved them — looting,
    // merging, jettisoning, a spoiled rack — the readout follows.
    if (STATE === 'map' || STATE === 'combat' || STATE === 'loot' ||
        STATE === 'station' || STATE === 'event') { _syncAmmo(); _syncFuel(); }
    /* ── SETTLING UP FOR A FINISHED SIDE JOB (update71) ────────
     *
     * The counting happens wherever the event happens — a kill, a hull
     * breaking up, a fire going out — and those places have no business
     * moving CC around mid-frame. So they only COUNT; this drains the
     * finished ones, once, from the one loop that always runs. */
    _payRunGoals();
    if (STATE === 'station') _updateStation(dt);
  }

  // ── Draw ──────────────────────────────────────────────────
  function _draw() {
    const ctx = Renderer.getCtx();
    Renderer.clear();
    // The jump fills the screen until its flash (update118).
    if (typeof JumpScene !== 'undefined' && JumpScene.covers()) {
      JumpScene.draw(ctx, Renderer.getWidth(), Renderer.getHeight());
      return;
    }

    if (STATE === 'menu')    _drawMenu(ctx);
    if (STATE === 'options') _drawOptions(ctx);
    if (STATE === 'base')    BaseScreen.draw(ctx);
    if (STATE === 'map')     { _drawMap(ctx); if (_dossier && _commander) Renderer.drawCommanderDossier(ctx, _commander); }
    if (STATE === 'combat')  _drawCombat(ctx);
    if (STATE === 'event')   _drawEvent(ctx);
    if (STATE === 'station') _drawStation(ctx);
    if (STATE === 'outcome') _drawOutcome(ctx);
    if (STATE === 'promo')   _drawPromo(ctx);
    if (STATE === 'dismiss') _drawDismiss(ctx);
    if (STATE === 'loot')    LootScreen.draw(ctx);
    if (STATE === 'docking')  DockingGame.draw(ctx);

    // The loot screen is a full-screen modal — the HUD underneath it
    // would only fight the two holds for attention.
    if (STATE !== 'loot' && STATE !== 'docking') {
      UI.draw(ctx, { playerShip: _playerShip,
                     // the log window, in a fight and on the map (update90a)
                     logPanel: STATE === 'combat' || STATE === 'map',
                     logCompact: STATE === 'map' && _mapView !== 'ship',
                     // hover a module of ours for what it does (update88)
                     moduleTips: STATE === 'combat' || (STATE === 'map' && _mapView === 'ship') });
    }
    // The Book sits over everything, the log window included (update99).
    if (_B().open && (STATE === 'combat' || STATE === 'map') && _commander) _drawBook(ctx);
    if (STATE === 'map') _drawEventResult(ctx);       // update106: what an event did
    _drawFade(ctx);
    if (typeof JumpScene !== 'undefined') JumpScene.drawOverlay(ctx, Renderer.getWidth(), Renderer.getHeight());
    if (_paused) _drawPause(ctx);
    if (_fatal) _drawFatal(ctx);
  }

  // ── MENU ──────────────────────────────────────────────────
  function _updateMenu(dt = 0) {
    try { _menuFightTick(dt); } catch (e) { /* a picture never stops the menu */ }
    const mx = Input.mouse.x, my = Input.mouse.y;
    const W  = Renderer.getWidth(), H = Renderer.getHeight();
    const cx = W / 2;
    _menuHover = null;
    // The question over NEW GAME takes every click while it is up.
    if (_menuConfirm) { _updateMenuConfirm(); return; }
    MENU_ITEMS.forEach((lbl, i) => {
      const r = _menuRect(i);
      if (Utils.pointInRect(mx, my, r.x, r.y, r.w, r.h)) _menuHover = i;
    });
    Audio.hoverCue?.(_menuHover === null ? null : `menu:${_menuHover}`);

    if (Input.mouse.leftPressed && _menuHover !== null) {
      Audio.resume();
      Audio.sfx.uiClick();
      // A thrown error here used to look like "the click did nothing"
      // (the sound had already played). Surface it instead.
      try {
        if (_menuHover === 0) _openBase();
        if (_menuHover === 1) { STATE = 'options'; _beginFade(); }
        if (_menuHover === 2) { _menuConfirm = true; _menuConfirmHover = null; }
      } catch (e) {
        console.error('[Game] menu action failed:', e);
        _fatal = String(e && e.message || e);
        UI.notify?.('Something broke: ' + _fatal, 'alert');
      }
    }
  }

  /** Where menu button i is (the click box and the drawing). */
  function _menuRect(i) {
    const W = Renderer.getWidth(), H = Renderer.getHeight(), L = MENU_LAYOUT;
    return { x: W / 2 - L.w / 2, y: H / 2 + L.top + i * L.gap, w: L.w, h: L.h };
  }

  /* ── THE HULL THAT FLIES PAST ────────────────────────────
     The one you fly: the hull out on a contract if there is one, the
     first in the hangar if not, the free scout on a new save. Built once
     and kept (`_menuShipKey` says which), closed, no crew. */
  let _menuShip = null, _menuShipKey = null, _menuShipSrc = null;
  /** The run on record, or null — the title screen draws before a save
   *  is read too (and must not throw over it). */
  function _menuRun() { try { return Save.getRun?.() ?? null; } catch (e) { return null; } }
  function _menuHullKey() {
    const run = _menuRun();
    if (run?.shipKey && SHIP_LAYOUTS[run.shipKey]) return run.shipKey;
    try {
      const first = Base.ships?.()?.[0]?.key;
      if (first && SHIP_LAYOUTS[first]) return first;
    } catch (e) { /* no base yet */ }
    return 'scout';
  }
  /** The record the hull that flies past is built from (update131):
   *  the hull out on a contract as she flies, or the first in the
   *  hangar as she was fitted — her modules, her guns, her shields —
   *  and the men who go with her. Null data = a bare hull of `key`. */
  function _menuShipSource() {
    const key = _menuHullKey();
    const run = _menuRun();
    if (run?.shipKey === key && run.ship) return { key, data: run.ship, crew: run.crew ?? [] };
    try {
      const e = Base.ships?.()?.[0];
      if (e && e.key === key) return { key, data: e.data ?? null, crew: (Base.crew?.() ?? []).slice(0, 4) };
    } catch (e) { /* no base yet */ }
    return { key, data: null, crew: [] };
  }
  function _menuShipFor() {
    const src = _menuShipSource();
    /* Rebuilt when the RECORD changes, not just the hull kind — the
       lesson of update68: a cache keyed on less than what it draws
       hands back the ship as she was. */
    if (!_menuShip || _menuShipKey !== src.key || _menuShipSrc !== src.data) {
      try {
        _menuShip = src.data ? Ship.deserialise(src.data, true, 0, 0) : new Ship(src.key, true, 0, 0);
        _menuShipKey = src.key; _menuShipSrc = src.data;
        _menuMan(_menuShip, src.crew);
        _menuShip.gunsFace = -1;             // you shoot back over the stern
        _menuFightReset();
      } catch (e) { _menuShip = null; _menuShipKey = null; _menuShipSrc = null; }
      if (_menuShip) _menuShip.roofAlpha = 1;
    }
    return _menuShip;
  }

  /** Put the men aboard a menu hull and walk them to their posts, once,
   *  with every clock stopped and nothing said (update131). The hull is
   *  a picture (`isPreview`): no stomachs, no eggs, no reactor heat. */
  function _menuMan(ship, records) {
    ship.isPreview = true;
    ship._allocateDefaultPower?.();
    (records || []).forEach(cd => { try { ship.addCrew(CrewMember.deserialise(cd)); } catch (e) {} });
    ship.assignStations?.();
    const guns = ship.weapons;
    const realNotify = UI.notify;
    UI.notify = () => {};
    ship.weapons = [];                        // no charging hum on the title screen
    try {
      for (let i = 0; i < 400; i++) {
        ship.update(0.1);
        if (i >= 10 && ship.crew.every(c => !c || c.isPet || c.dead ||
            (!c._waypoints?.length && !c._ridingShaft && c.task !== TASK.MOVE))) break;
      }
    } catch (e) { /* a picture never stops the menu */ }
    finally { ship.weapons = guns; UI.notify = realNotify; }
    /* …and the shields come up full: a fight starts from a charged bubble. */
    const ss = ship.getSystem('shields');
    if (ss && (ss._shieldMax ?? 0) > 0) { ss._shieldBars = ss._shieldMax; ss._shieldTimer = 0; }
  }

  /* THE CHASER IS FITTED FOR A FIGHT (update131): the dearest hull in
     the yard, with a shield module and a mixed rack — a heavy laser, an
     ion gun and a missile launcher where it has bays — so the title
     screen shows the new guns and the honeycomb. Crewed like yours. */
  const MENU_FOE_GUNS = ['laser_heavy', 'ion_basic', 'missile_basic', 'laser_burst'];
  function _menuFit(ship) {
    try {
      if (!ship.getSystem('shields')) {
        const room = ship.rooms.find(r => r.type === 'empty');
        if (room) ship.addModuleAt?.('shields', room.id);
      }
      const ss = ship.getSystem('shields');
      if (ss) ss.level = Math.max(ss.level, 4);
      ship.weapons.forEach((w, i) => {
        const want = MENU_FOE_GUNS[i % MENU_FOE_GUNS.length];
        if (w && w.defKey !== want && typeof WEAPON_DEFS !== 'undefined' && WEAPON_DEFS[want]) {
          ship.weapons[i] = Object.assign(new Weapon(want, w.slot), { roomId: w.roomId });
        }
      });
    } catch (e) { /* the bare hull is still a picture */ }
  }
  /** The chase's numbers, for the tests (MENU_CHASE is a script const). */
  function _menuChaseCfg() { return MENU_CHASE; }
  /** The fight's numbers (update131), for the tests. */
  function _menuFightCfg() { return MENU_FIGHT; }
  /** The chaser: the best hull the shipyard sells (the dearest in
   *  SHIP_CATALOG) — or, when that is the one you fly, the next best. */
  function _menuChaserKey() {
    const mine = _menuHullKey();
    const hulls = (typeof SHIP_CATALOG !== 'undefined' ? Object.values(SHIP_CATALOG) : [])
      .filter(d => d && SHIP_LAYOUTS[d.key] && d.key !== mine)
      .sort((a, b) => (b.cost ?? 0) - (a.cost ?? 0));
    return hulls[0]?.key ?? null;
  }
  let _menuFoe = null, _menuFoeKey = null;
  function _menuFoeShip() {
    const key = _menuChaserKey();
    if (!key) return null;
    if (!_menuFoe || _menuFoeKey !== key) {
      try {
        _menuFoe = new Ship(key, true, 0, 0); _menuFoe.roofAlpha = 1; _menuFoeKey = key;
        _menuFit(_menuFoe);
        _menuMan(_menuFoe, makeStartingCrew().map(c => c.serialise()));
        _menuFightReset();
      } catch (e) { _menuFoe = null; _menuFoeKey = null; }
    }
    return _menuFoe;
  }

  /** Where the flyby is at time t (seconds): x of the hull's left edge,
   *  y of its middle — yours ahead, the chaser `gap` behind. In from the
   *  left, out at the right, again. `foeShip` is optional. */
  function _menuFlyby(t, ship, foeShip = null) {
    const W = Renderer.getWidth(), H = Renderer.getHeight(), L = MENU_LAYOUT, C = MENU_CHASE;
    const b = ship.roomBounds(), w = b.w * L.flyScale;
    const fb = foeShip ? foeShip.roomBounds() : null, fw = fb ? fb.w * C.foeScale : 0;
    const behind = fb ? C.gap + fw : 0;
    const span = W + w + behind + 240;
    const k = ((t % L.flyT) + L.flyT) % L.flyT / L.flyT;
    const x = -w - behind - 120 + span * k;
    const y = H * L.flyY + Math.sin(t * 0.6) * 4;
    const out = { x, y, b, s: L.flyScale };
    if (fb) out.foe = { x: x - C.gap - fw, y: H * L.flyY - 6 + Math.sin(t * 0.5 + 1) * 5, b: fb, s: C.foeScale };
    return out;
  }

  /* ── THE FIGHT ITSELF (update131) ───────────────────────────
     Shots live in the CONVOY's frame: x and y in hull units measured
     from your hull's left edge and middle. Both hulls fly at the same
     speed, so in this frame they hardly move and a bolt flies straight
     from one to the other, as in a fight. `_menuToConvoy` maps a point
     on a hull into it; the drawing undoes it with one translate+scale. */
  const _menuFightState = { shots: [], guns: new Map(), queue: [], hovered: null, fired: 0 };
  function _menuFightReset() {
    _menuFightState.shots.length = 0; _menuFightState.queue.length = 0;
    _menuFightState.guns.clear();
  }
  function _menuFight() { return _menuFightState; }
  function _menuToConvoy(f, which, px, py) {
    if (which === 'you') return { x: px - f.b.x, y: py - f.b.y - f.b.h / 2 };
    const g = f.foe;
    return { x: (g.x - f.x) / f.s + px - g.b.x, y: (g.y - f.y) / f.s + py - g.b.y - g.b.h / 2 };
  }
  /** A hull's screen rectangle in the flyby (for the hover). */
  function _menuHullRect(g) {
    return { x: g.x, y: g.y - g.b.h * g.s / 2, w: g.b.w * g.s, h: g.b.h * g.s };
  }
  function _menuOnScreen(f) {
    const W = Renderer.getWidth();
    const foeR = _menuHullRect(f.foe), youR = _menuHullRect(f);
    return foeR.x + foeR.w > 20 && youR.x < W - 20;
  }

  /** One step of the chase fight. `now` is the flyby's clock (seconds). */
  function _menuFightTick(dt, now = Date.now() / 1000) {
    const you = _menuShipFor(), foe = _menuFoeShip();
    const S = _menuFightState, C = MENU_FIGHT;
    if (!you || !foe) return;
    const f = _menuFlyby(now, you, foe);
    if (!f.foe) return;
    const sides = [
      { me: you, them: foe, mine: 'you', theirs: 'foe' },
      { me: foe, them: you, mine: 'foe', theirs: 'you' },
    ];
    const live = _menuOnScreen(f);

    // ── the guns charge, and fire when full ──
    sides.forEach(sd => {
      sd.me.weaponMounts().forEach(m => {
        const w = m.weapon;
        if (!w || w.def?.type === 'beam') return;
        const T = Math.max(C.minCharge, (w.def?.chargeTime ?? 6) * C.chargeScale);
        let st = S.guns.get(w);
        if (!st) { st = { charge: Math.random() * 0.8 }; S.guns.set(w, st); }
        st.charge = Math.min(1, st.charge + dt / T);
        w.charge = st.charge; w.armed = false;          // its boxes on the hull fill (picture only)
        if (st.charge < 1 || !live || S.shots.length >= C.maxShots) return;
        st.charge = 0; w.charge = 0;
        const rooms = sd.them.rooms.filter(r => r.type !== 'corridor');
        const shots = Math.max(1, w.def?.shots ?? 1);
        for (let i = 0; i < shots; i++) {
          S.queue.push({ delay: i * (w.def?.burstGap ?? 0.35), w, m, side: sd,
                         room: rooms[Math.floor(Math.random() * rooms.length)] ?? sd.them.rooms[0] });
        }
      });
    });

    // ── bursts leave the barrel one by one ──
    for (let i = S.queue.length - 1; i >= 0; i--) {
      const q = S.queue[i];
      q.delay -= dt;
      if (q.delay > 0) continue;
      S.queue.splice(i, 1);
      const src = _menuToConvoy(f, q.side.mine, q.m.muzzleX, q.m.muzzleY);
      const dst = _menuToConvoy(f, q.side.theirs, q.room.cx ?? (q.room.x + q.room.w / 2), q.room.cy ?? (q.room.y + q.room.h / 2));
      const p = new Projectile({ x: src.x, y: src.y, targetX: dst.x, targetY: dst.y,
        speed: q.w.def?.projectileSpeed ?? 320, type: q.w.def?.type ?? 'laser', def: q.w.def,
        defKey: q.w.defKey, gun: q.w, fromPlayer: q.side.mine === 'you' });
      p._menu = { target: q.side.theirs, room: q.room };
      q.w.kick?.();
      if (typeof WeaponArt !== 'undefined') {
        WeaponArt.add({ kind: 'muzzle', x: src.x, y: src.y, dir: q.m.dir,
                        col: WeaponArt.styleOf(q.w.defKey, q.w.def?.type).col });
      }
      S.shots.push(p); S.fired++;
    }

    // ── the shots fly; the bubble or the plate takes them ──
    S.shots.forEach(p => {
      p.update(dt);
      if (p.done && !p.hit) return;
      const tgt = p._menu.target === 'you' ? you : foe;
      const e = tgt.shieldEllipse();
      const c = _menuToConvoy(f, p._menu.target, e.cx, e.cy);
      const ell = { cx: c.x, cy: c.y, rx: e.rx, ry: e.ry };
      const inside = ((p.x - ell.cx) / ell.rx) ** 2 + ((p.y - ell.cy) / ell.ry) ** 2 <= 1;
      if (!p.flyOn && !p._menuRolled && inside) {
        p._menuRolled = true;
        if (Math.random() < C.evade) {
          p.flyOn = true; p.hit = false; p.done = false;
          if (typeof WeaponArt !== 'undefined') WeaponArt.add({ kind: 'miss', x: p.x, y: p.y });
          return;
        }
        if (tgt.shieldBars > 0 && !Ship.piercesShields(p.def ?? {})) {
          const ss = tgt.getSystem('shields');
          ss._shieldBars = Math.max(0, ss._shieldBars - 1); ss._shieldTimer = 0;
          tgt._shieldAlpha = 1;
          if (typeof WeaponArt !== 'undefined') WeaponArt.add({ kind: 'shield', x: p.x, y: p.y, shield: ell });
          p.done = true; p.hit = true; p._menuDone = true;
          return;
        }
      }
      if (p.hit && !p._menuDone) {
        p._menuDone = true;
        if (typeof WeaponArt !== 'undefined') {
          WeaponArt.add({ kind: WeaponArt.hitKind(p.type, p.defKey), x: p.x, y: p.y });
          WeaponArt.add({ kind: 'scorch', x: p.x, y: p.y });
        }
        if (p._menu.room) p._menu.room._hitFlash = 1;
      }
    });
    S.shots = S.shots.filter(p => !p.done);

    // ── what a fight's Ship.update would do, and nothing more ──
    [you, foe].forEach(sh => {
      sh._shieldAlpha = Math.max(0, (sh._shieldAlpha ?? 0) - dt * 2);
      sh.rooms.forEach(r => { if (r._hitFlash > 0) r._hitFlash = Math.max(0, r._hitFlash - dt * 3.5); });
      const ss = sh.getSystem('shields');
      if (ss && ss._shieldBars < (ss._shieldMax ?? 0)) {
        ss._shieldTimer = (ss._shieldTimer ?? 0) + dt;
        if (ss._shieldTimer >= C.shieldBack) { ss._shieldBars++; ss._shieldTimer = 0; }
      }
    });

    // ── the pointer over a hull lifts its roof ──
    const mx = Input.mouse.x, my = Input.mouse.y;
    const inR = (r) => mx >= r.x && mx <= r.x + r.w && my >= r.y && my <= r.y + r.h;
    S.hovered = _menuConfirm ? null : inR(_menuHullRect(f)) ? 'you' : inR(_menuHullRect(f.foe)) ? 'foe' : null;
    [['you', you], ['foe', foe]].forEach(([k, sh]) => {
      const want = S.hovered === k ? 0 : 1;
      const step = dt * C.roofSpeed;
      sh.roofAlpha = sh.roofAlpha < want ? Math.min(want, sh.roofAlpha + step) : Math.max(want, sh.roofAlpha - step);
    });
  }

  function _drawHullAt(ctx, ship, g) {
    ctx.save();
    // smaller than in a fight: far off, and clear of the buttons
    ctx.translate(g.x, g.y);
    ctx.scale(g.s, g.s);
    ctx.translate(-g.b.x, -(g.b.y + g.b.h / 2));
    try { ship.draw(ctx); } catch (e) { /* a picture never stops the menu */ }
    ctx.restore();
  }

  function _drawMenuShip(ctx, t) {
    const ship = _menuShipFor();
    if (!ship) return;
    const foe = _menuFoeShip();
    const f = _menuFlyby(t, ship, foe);
    if (foe && f.foe) _drawHullAt(ctx, foe, f.foe);
    _drawHullAt(ctx, ship, f);
    // the fight, over both hulls, in the convoy's frame (update131)
    ctx.save();
    ctx.translate(f.x, f.y);
    ctx.scale(f.s, f.s);
    if (typeof WeaponArt !== 'undefined') WeaponArt.draw(ctx, 'under');
    _menuFightState.shots.forEach(p => { try { p.draw(ctx); } catch (e) {} });
    if (typeof WeaponArt !== 'undefined') WeaponArt.draw(ctx, 'over');
    ctx.restore();
  }

  /** The line under ENTER BASE: a contract in the air, or what the base
   *  holds. Two facts, plainly. */
  function _menuStatus() {
    const run = _menuRun();
    if (run?.shipKey) {
      const m = (typeof MISSIONS !== 'undefined' && MISSIONS[run.mission]) ? MISSIONS[run.mission].label : 'Contract';
      const last = run.finalSector ? `/${run.finalSector}` : '';
      return { text: `CONTRACT IN THE AIR — ${m}, sector ${run.sector ?? 1}${last}`, col: '#ffb020' };
    }
    try {
      const hulls = Base.ships().length, men = Base.crew().length, cc = Base.cc();
      return { text: `${cc} CC  ·  ${hulls} hull${hulls === 1 ? '' : 's'} in the hangar  ·  ${men} in the barracks`, col: '#5f7893' };
    } catch (e) { return { text: '', col: '#5f7893' }; }
  }

  function _drawMenu(ctx) {
    Renderer.drawBackground(Date.now() * 0.008);
    const W = Renderer.getWidth(), H = Renderer.getHeight();
    const cx = W / 2;

    // your hull, going past the Moon — under everything else
    _drawMenuShip(ctx, Date.now() / 1000);

    // Logo
    ctx.save();
    ctx.shadowBlur = 30; ctx.shadowColor = '#1a8cff';
    ctx.fillStyle = '#4db8ff';
    ctx.font = '64px Orbitron, monospace';
    ctx.textAlign = 'center';
    ctx.fillText('MOON WARS', cx, H/2 - 130);
    ctx.restore();

    ctx.fillStyle = '#2a4060';
    ctx.font = '12px Share Tech Mono, monospace';
    ctx.textAlign = 'center';
    ctx.fillText('TACTICAL SPACE SURVIVAL', cx, H/2 - 96);

    MENU_ITEMS.forEach((lbl, i) => {
      const { x: bx, y: by, w: bw, h: bh } = _menuRect(i);
      const hover = _menuHover === i && !_menuConfirm;
      const wipe = lbl === 'NEW GAME';
      const edge = wipe ? (hover ? '#ff7c20' : '#4a2a20') : (hover ? '#4db8ff' : '#1e2d4a');
      ctx.fillStyle = hover ? (wipe ? 'rgba(255,124,32,0.18)' : 'rgba(26,140,255,0.3)') : 'rgba(13,17,32,0.9)';
      ctx.beginPath(); ctx.roundRect(bx, by, bw, bh, 4); ctx.fill();
      ctx.strokeStyle = edge;
      ctx.lineWidth = hover ? 2 : 1; ctx.stroke();
      ctx.fillStyle = wipe ? (hover ? '#ff9a50' : '#a07060') : (hover ? '#4db8ff' : '#c8d8f0');
      ctx.font = '15px Orbitron, monospace';
      ctx.textAlign = 'center';
      ctx.fillText(lbl, cx, by + 26);
      if (i === 0) {
        const st = _menuStatus();
        ctx.fillStyle = st.col;
        ctx.font = '11px Share Tech Mono, monospace';
        ctx.fillText(st.text, cx, by + bh + 16);
      }
    });

    ctx.fillStyle = '#1a2a3a';
    ctx.font = '11px Share Tech Mono, monospace';
    ctx.textAlign = 'right';
    ctx.fillText('MOON WARS v0.1', W-10, H-10);

    if (_menuConfirm) _drawMenuConfirm(ctx);
  }

  /* ── NEW GAME, ASKED FIRST ───────────────────────────────
     It wipes everything: the base, the hangar, the barracks, the mess,
     the money and any contract in the air. So it asks, says exactly
     that, and the safe answer is the one under the cursor's way out
     (ESC too). */
  let _menuConfirm = false, _menuConfirmHover = null;
  function _menuConfirmRects() {
    const W = Renderer.getWidth(), H = Renderer.getHeight();
    const box = { x: W / 2 - 230, y: H / 2 - 90, w: 460, h: 180 };
    return {
      box,
      wipe: { x: box.x + 30,  y: box.y + box.h - 58, w: 190, h: 38 },
      keep: { x: box.x + 240, y: box.y + box.h - 58, w: 190, h: 38 },
    };
  }
  function _updateMenuConfirm() {
    const mx = Input.mouse.x, my = Input.mouse.y, R = _menuConfirmRects();
    _menuConfirmHover = Utils.pointInRect(mx, my, R.wipe.x, R.wipe.y, R.wipe.w, R.wipe.h) ? 'wipe'
                      : Utils.pointInRect(mx, my, R.keep.x, R.keep.y, R.keep.w, R.keep.h) ? 'keep' : null;
    if (Input.isPressed('Escape')) { _menuConfirm = false; return; }
    if (!Input.mouse.leftPressed) return;
    if (_menuConfirmHover === 'keep' || !_menuConfirmHover) { if (_menuConfirmHover) Audio.sfx.uiClick(); _menuConfirm = false; return; }
    Audio.sfx.uiClick();
    _newGame();
  }
  /** Wipe the save and start over, on the title screen. */
  function _newGame() {
    Save.reset();
    _menuConfirm = false;
    /* No menu-hull reset here any more (update131): the hull that flies
       past is cached on the RECORD it was built from, and a wipe leaves
       a different record (or none) — so it is rebuilt by itself. A second
       way of saying "build it again" would be a second register. */
    _playerShip = null; _enemyShip = null;
    UI.notify?.('A new game. The base is yours to build.', 'info');
  }
  function _drawMenuConfirm(ctx) {
    const W = Renderer.getWidth(), H = Renderer.getHeight(), R = _menuConfirmRects();
    ctx.save();
    ctx.fillStyle = 'rgba(3,5,10,0.72)';
    ctx.fillRect(0, 0, W, H);
    ctx.fillStyle = 'rgba(13,17,32,0.97)';
    ctx.beginPath(); ctx.roundRect(R.box.x, R.box.y, R.box.w, R.box.h, 6); ctx.fill();
    ctx.strokeStyle = '#ff7c20'; ctx.lineWidth = 1; ctx.stroke();
    ctx.textAlign = 'center';
    ctx.fillStyle = '#ff9a50';
    ctx.font = '18px Orbitron, monospace';
    ctx.fillText('START A NEW GAME?', W / 2, R.box.y + 36);
    ctx.fillStyle = '#9fb0c4';
    ctx.font = '12px Share Tech Mono, monospace';
    ctx.fillText('This wipes the base, the hangar, the barracks, the money', W / 2, R.box.y + 66);
    ctx.fillText('and any contract in the air. It cannot be undone.', W / 2, R.box.y + 84);
    [[R.wipe, 'WIPE AND START', '#ff7c20', 'wipe'], [R.keep, 'KEEP MY GAME', '#4db8ff', 'keep']].forEach(([r, label, col, id]) => {
      const hot = _menuConfirmHover === id;
      ctx.fillStyle = hot ? 'rgba(255,255,255,0.08)' : 'rgba(8,10,18,0.9)';
      ctx.beginPath(); ctx.roundRect(r.x, r.y, r.w, r.h, 4); ctx.fill();
      ctx.strokeStyle = col; ctx.lineWidth = hot ? 2 : 1; ctx.stroke();
      ctx.fillStyle = col;
      ctx.font = '13px Orbitron, monospace';
      ctx.fillText(label, r.x + r.w / 2, r.y + 24);
    });
    ctx.fillStyle = '#2a4060';
    ctx.font = '10px Share Tech Mono, monospace';
    ctx.fillText('ESC — keep my game', W / 2, R.box.y + R.box.h + 18);
    ctx.restore();
  }

  /* ── OPTIONS ──────────────────────────────────────────────
   *
   * The whole settings subsystem already existed and was wired to
   * NOTHING: `Save.getSetting/setSetting`, `_defaultSettings()` with
   * three volume levels, and `Audio.setMasterVolume/SfxVolume/
   * MusicVolume` — every one of them written, persisted, and never
   * called by a single line of game code. A game with procedural music
   * and no way to turn it down is a game people play on mute.
   *
   * Three sliders and a mute toggle. Dragging is live (you hear what
   * you are setting) and the value is written to the save on release,
   * because Save.setSetting hits localStorage.
   */
  const OPT_ROWS = [
    { key: 'masterVolume', label: 'MASTER',  apply: v => Audio.setMasterVolume(v) },
    { key: 'sfxVolume',    label: 'EFFECTS', apply: v => Audio.setSfxVolume(v)    },
    { key: 'musicVolume',  label: 'MUSIC',   apply: v => Audio.setMusicVolume(v)  },
  ];
  const OPT_BAR = { x: 470, w: 340, h: 16, top: 250, gap: 62 };
  let _optDrag = null;      // key being dragged, or null
  let _optHover = null;

  function _optRowRect(i) {
    return { x: OPT_BAR.x, y: OPT_BAR.top + i * OPT_BAR.gap, w: OPT_BAR.w, h: OPT_BAR.h };
  }
  /* JUMP FILMS (update122, jj: "wprowadź w opcjach możliwość
     wyłączenia"). A row of its own under the three levels; BACK and
     MUTE moved down one row to make room. */
  function _optFilmsRect() { return { x: 470, y: OPT_BAR.top + 3 * OPT_BAR.gap - 8, w: 340, h: 34 }; }
  function _optBackRect() { return { x: 470, y: OPT_BAR.top + 4 * OPT_BAR.gap + 24, w: 150, h: 40 }; }
  function _optMuteRect() { return { x: 660, y: OPT_BAR.top + 4 * OPT_BAR.gap + 24, w: 150, h: 40 }; }

  /** The films are on unless the player turned them off — an old save
   *  without the setting plays them. */
  function _filmsOn() { return Save.getSetting?.('jumpFilms') !== false; }

  /** Read a level, falling back to the shipped default. */
  function _optValue(key) {
    const v = Save.getSetting?.(key);
    if (typeof v === 'number') return Utils.clamp(v, 0, 1);
    return { masterVolume: 0.8, sfxVolume: 1.0, musicVolume: 0.35 }[key] ?? 0.8;
  }

  /** Mute is its own persisted flag, independent of the three levels. */
  function _optMuted() { return Save.getSetting?.('muted') === true; }

  function _updateOptions() {
    const mx = Input.mouse.x, my = Input.mouse.y;

    // ESC and a click on BACK both leave.
    if (Input.isPressed('Escape')) { STATE = 'menu'; _beginFade(); _optDrag = null; return; }

    _optHover = null;
    OPT_ROWS.forEach((row, i) => {
      const r = _optRowRect(i);
      // A generous grab band — a 16px bar is hard to hit exactly.
      if (Utils.pointInRect(mx, my, r.x - 8, r.y - 10, r.w + 16, r.h + 20)) _optHover = row.key;
    });
    const back = _optBackRect(), mute = _optMuteRect();
    if (Utils.pointInRect(mx, my, back.x, back.y, back.w, back.h)) _optHover = 'back';
    if (Utils.pointInRect(mx, my, mute.x, mute.y, mute.w, mute.h)) _optHover = 'mute';
    const films = _optFilmsRect();
    if (Utils.pointInRect(mx, my, films.x, films.y, films.w, films.h)) _optHover = 'films';
    Audio.hoverCue?.(_optHover ? `opt:${_optHover}` : null);

    if (Input.mouse.leftPressed) {
      if (_optHover === 'back') {
        Audio.sfx.uiClick(); STATE = 'menu'; _beginFade(); return;
      }
      if (_optHover === 'mute') {
        Audio.sfx.uiClick();
        /* MUTE no longer overwrites masterVolume with 0 (update42).
           It used to, which meant the zero was saved, survived F5 —
           the game booted silent — and UNMUTE restored a guessed 0.8
           instead of the level the player had actually set. */
        const next = !_optMuted();
        Save.setSetting?.('muted', next);
        Audio.setMuted?.(next);
        return;
      }
      if (_optHover === 'films') {
        Audio.sfx.uiClick();
        const next = !_filmsOn();
        Save.setSetting?.('jumpFilms', next);
        if (typeof JumpScene !== 'undefined') JumpScene.enabled = next;
        return;
      }
      if (_optHover && OPT_ROWS.some(r => r.key === _optHover)) _optDrag = _optHover;
    }

    if (_optDrag) {
      if (!Input.mouse.leftDown) {
        // Persist ONCE, on release. The comment used to say this while
        // the drag branch below called setSetting — which writes
        // localStorage — on every frame (update42).
        Save.saveSettings?.();
        _optDrag = null;
      } else {
        const i = OPT_ROWS.findIndex(r => r.key === _optDrag);
        const r = _optRowRect(i);
        const v = Utils.clamp((mx - r.x) / r.w, 0, 1);
        // Live: you hear the level you are setting while you set it.
        (Save.setSettingLive ?? Save.setSetting)?.call(Save, _optDrag, v);
        OPT_ROWS[i].apply(v);
      }
    }
  }

  function _drawOptions(ctx) {
    Renderer.drawBackground(Date.now() * 0.006);
    const W = Renderer.getWidth(), H = Renderer.getHeight();

    ctx.save();
    ctx.fillStyle = 'rgba(5,7,14,0.78)';
    ctx.fillRect(0, 0, W, H);

    ctx.fillStyle = '#4db8ff';
    ctx.font = '30px Orbitron, monospace';
    ctx.textAlign = 'center';
    ctx.fillText('OPTIONS', W / 2, 170);
    ctx.fillStyle = '#5f7893';
    ctx.font = '11px Share Tech Mono, monospace';
    ctx.fillText('Drag a bar to set the level — you hear it as you drag.', W / 2, 196);

    OPT_ROWS.forEach((row, i) => {
      const r = _optRowRect(i);
      const v = _optValue(row.key);
      const hot = _optHover === row.key || _optDrag === row.key;

      ctx.textAlign = 'right';
      ctx.font = '13px Share Tech Mono, monospace';
      ctx.fillStyle = hot ? '#c8e8ff' : '#7a90a8';
      ctx.fillText(row.label, r.x - 20, r.y + 13);

      ctx.fillStyle = '#0a1018';
      ctx.beginPath(); ctx.roundRect(r.x, r.y, r.w, r.h, 3); ctx.fill();
      ctx.fillStyle = v > 0 ? (hot ? '#4db8ff' : '#2f7fc4') : '#3d2430';
      ctx.beginPath(); ctx.roundRect(r.x, r.y, Math.max(3, r.w * v), r.h, 3); ctx.fill();
      ctx.strokeStyle = hot ? '#4db8ff' : '#1e2d4a'; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.roundRect(r.x + 0.5, r.y + 0.5, r.w, r.h, 3); ctx.stroke();

      // Grip, so it reads as draggable rather than as a progress bar.
      const gx = r.x + r.w * v;
      ctx.fillStyle = hot ? '#c8e8ff' : '#9fdcff';
      ctx.fillRect(gx - 2, r.y - 5, 4, r.h + 10);

      ctx.textAlign = 'left';
      ctx.fillStyle = hot ? '#c8e8ff' : '#7a90a8';
      ctx.font = '12px Share Tech Mono, monospace';
      ctx.fillText(`${Math.round(v * 100)}%`, r.x + r.w + 16, r.y + 13);
    });

    // JUMP FILMS — a switch: the label at the left like the levels, the
    // state in a box you click.
    {
      const r = _optFilmsRect(), on = _filmsOn(), hot = _optHover === 'films';
      ctx.textAlign = 'right';
      ctx.font = '13px Share Tech Mono, monospace';
      ctx.fillStyle = hot ? '#c8e8ff' : '#7a90a8';
      ctx.fillText('JUMP FILMS', r.x - 20, r.y + 22);
      ctx.fillStyle = hot ? 'rgba(26,140,255,0.18)' : 'rgba(13,17,32,0.92)';
      ctx.beginPath(); ctx.roundRect(r.x, r.y, r.w, r.h, 4); ctx.fill();
      ctx.strokeStyle = on ? '#1aff8c' : '#ff7c20'; ctx.lineWidth = hot ? 2 : 1;
      ctx.beginPath(); ctx.roundRect(r.x, r.y, r.w, r.h, 4); ctx.stroke();
      ctx.fillStyle = on ? '#1aff8c' : '#ff7c20';
      ctx.font = '14px Orbitron, monospace';
      ctx.textAlign = 'center';
      ctx.fillText(on ? 'ON' : 'OFF', r.x + r.w / 2, r.y + 22);
      ctx.fillStyle = '#5f7893';
      ctx.font = '10px Share Tech Mono, monospace';
      ctx.fillText(on ? 'the jump and the arrival are shown — ENTER skips one'
                      : 'jumps and arrivals happen at once', r.x + r.w / 2, r.y + r.h + 14);
    }

    const back = _optBackRect(), mute = _optMuteRect();
    const muted = _optMuted();
    [[back, 'BACK', '#4db8ff', 'back'],
     [mute, muted ? 'UNMUTE' : 'MUTE', muted ? '#ffd700' : '#ff7c20', 'mute']]
      .forEach(([r, label, col, id]) => {
        const hot = _optHover === id;
        ctx.fillStyle = hot ? 'rgba(26,140,255,0.18)' : 'rgba(13,17,32,0.92)';
        ctx.beginPath(); ctx.roundRect(r.x, r.y, r.w, r.h, 4); ctx.fill();
        ctx.strokeStyle = col; ctx.lineWidth = hot ? 2 : 1;
        ctx.beginPath(); ctx.roundRect(r.x, r.y, r.w, r.h, 4); ctx.stroke();
        ctx.fillStyle = col;
        ctx.font = '14px Orbitron, monospace';
        ctx.textAlign = 'center';
        ctx.fillText(label, r.x + r.w / 2, r.y + 26);
      });

    ctx.fillStyle = '#2a4060';
    ctx.font = '10px Share Tech Mono, monospace';
    ctx.textAlign = 'center';
    ctx.fillText('ESC to go back', W / 2, OPT_BAR.top + 4 * OPT_BAR.gap + 86);
    ctx.restore();
  }

  // ── MAP ───────────────────────────────────────────────────
  /**
   * TAB, wherever the player presses it (update74).
   *
   * It used to mean two different things in two places: in a fight it
   * walked the crew list, and on the MAP it was a second key for M and
   * flipped between the map and the ship — so the same finger did
   * something else depending on which screen was up, which is how it
   * came back as a bug report. TAB is the crew key now, everywhere.
   * M and the on-screen button are the view.
   *
   * Lifted into a function rather than copied into the second place,
   * because two copies of a selection rule drift the first time one of
   * them learns about a new kind of crewman.
   */
  function _cycleCrew() {
    const roster = Renderer.crewRoster({ playerShip: _playerShip, enemyShip: _enemyShip })
      .filter(c => c && c.isPlayer && c.alive && !c.isPet);
    if (!roster.length) return false;
    const cur = UI.getSelectedCrew?.();
    const at  = roster.indexOf(cur);
    // Not on the list (nobody selected, or a beast/dead man was) →
    // start at the top. Otherwise one down, wrapping.
    UI.selectCrew(roster[at === -1 ? 0 : (at + 1) % roster.length]);
    Audio.sfx.uiClick?.();
    return true;
  }

  function _updateMap(dt) {
    if (_playerShip) _playerShip.update(dt);

    /* THE FILE SWALLOWS THE MAP. While it is open nothing behind it
       moves or takes a click — a modal that leaves the jump nodes live
       is how a player ends up jumping while reading. */
    if (_dossier) { _updateDossier(); return; }
    // What an event did (update106): the window takes the map's input until closed.
    if (_updateEventResult()) return;
    // The Book of tablets (update99) — B, on the map as in a fight.
    if (_bookKey()) return;
    if (_B().open) { _updateBook('map'); return; }
    // Tablets used in flight run their clocks here too (update101: the Djed).
    Chips?.tick?.(dt);
    /* The log window is on the map too now (update90a): its key and its
       tab work here as they do in a fight. */
    if (Input.isPressed('KeyL')) UI.toggleLog();
    if (Input.mouse.leftPressed && UI.logClick?.(Input.mouse.x, Input.mouse.y)) return;
    /* The strip is drawn by drawHUD, which runs in BOTH map views —
       so the button works in both. Restricting it to the ship view
       would have made a visible button dead half the time. */
    // update104: his face and name in the commander bar (the strip is gone).
    if (_commander && Input.mouse.leftPressed) {
      const r = Renderer.commanderStripRect();
      if (Utils.pointInRect(Input.mouse.x, Input.mouse.y, r.x, r.y, r.w, r.h)) {
        _dossier = true;
        Audio.sfx.uiClick?.();
        return;
      }
    }

    // A gun won in the last fight is waiting to be stowed.
    if (_pendingLocker) {
      const key = _pendingLocker;
      _pendingLocker = null;
      _openWeaponLocker(key);
      return;
    }

    /* A BOSS CHIP THAT DID NOT FIT (update49). The spec is explicit
       that a guaranteed reward must not quietly disappear when the
       hold is full — so it waits here and opens the hold the moment
       the fight is over, exactly the way a won gun does. */
    if (_queuedChip) {
      const key = _queuedChip;
      _queuedChip = null;
      _openChipLocker(key);
      return;
    }

    // Fires (and other hazards) can finish a ship OUTSIDE combat —
    // don't wait for the next fight to notice we're dead.
    if (_playerShip) {
      const crewAlive = _playerCrewAliveCount() > 0;
      if (_playerShip.hull <= 0 || !crewAlive) {
        UI.notify(!crewAlive ? 'All crew lost…' : 'Hull breach — ship lost…', 'alert');
        /* Re-Atum answers a hull at 0 out of a fight too (update103) —
           a fire in flight sinks her as surely as a gun. */
        if (crewAlive && _reAtumRescue('hull')) return;
        _onLose();
        return;
      }
    }
    // TAB / M or the on-screen button flips between MAP and SHIP view
    const mx = Input.mouse.x, my = Input.mouse.y;
    const btn = _mapToggleRect();
    const btnClick = Input.mouse.leftPressed &&
      Utils.pointInRect(mx, my, btn.x, btn.y, btn.w, btn.h);
    const holdBtn = _holdBtnRect();
    const holdClick = Input.mouse.leftPressed &&
      Utils.pointInRect(mx, my, holdBtn.x, holdBtn.y, holdBtn.w, holdBtn.h);
    if (holdClick || Input.isPressed('KeyC')) { _openHold(); return; }

    // TAB is the CREW key on every screen (update74) — M and the button
    // are the view. They used to share TAB, so the same press did two
    // different things depending on what was up.
    if (Input.isPressed('Tab')) _cycleCrew();

    if (btnClick || Input.isPressed('KeyM')) {
      _mapView = _mapView === 'map' ? 'ship' : 'map';
      Audio.sfx.uiClick();
      if (btnClick) return;   // don't let the same click hit the new view
    }

    if (_mapView === 'ship') {
      // SHIP view: full crew management — rubber-band selection,
      // doors, power bar, medbay healing between jumps.
      _crewMouseUpdate();
      _mapHover = null;
      return;
    }

    // MAP view: the bottom power bar still works (buttons, pips)
    if (Input.mouse.leftPressed) _handlePowerBarClick();

    // Hover detection (panel is centered — the ship isn't drawn here)
    // the same origin the screen draws at (update132: one place, SectorMap)
    const { x: ox, y: oy } = SectorMap.origin(Renderer.getWidth(), Renderer.getHeight());
    _mapHover = null;
    if (_sectorMap) {
      _sectorMap.nodes.forEach(node => {
        if (node.locked) return;
        const nx = node.x + ox, ny = node.y + oy;
        if (Utils.dist(mx, my, nx, ny) < 22) _mapHover = node.id;
      });
    }

    // Click detection
    if (Input.mouse.leftPressed && _mapHover) {
      _travelTo(_mapHover);
    }
  }

  /* ── WHERE THE THREE FIGHT ORDERS ARE (update53) ──────────
   * They used to be written out here as literal coordinates AND again
   * at the draw site, which is how the BOARD button ended up with two
   * copies of one rectangle. The order panel owns the layout now and
   * both sides read it, so a button cannot move on screen without its
   * click moving with it. */
  function _retreatRect() { return Renderer.orderRects().retreat; }
  function _recallRect()  { return Renderer.orderRects().recall;  }
  function _boardRect()   { return Renderer.orderRects().board;   }

  /** Fire the cloak. Called from the module icon in the power bar and
   *  from the C hotkey — one place, so both report the same reason. */
  function _activateCloak(cloak) {
    if (!cloak) return;
    if (cloak.activateCloak()) {
      UI.notify('CLOAK ENGAGED — evasion spike!', 'good');
      Audio.sfx.powerUp?.();
    } else if (cloak.cloakActive) {
      UI.notify('Cloak already active', 'warn');
    } else if (cloak.cloakCd > 0) {
      UI.notify(`Cloak recharging (${Math.ceil(cloak.cloakCd)}s)`, 'warn');
    } else {
      UI.notify('Cloak needs power', 'warn');
    }
  }

  /* ── THE TWO BUTTONS CLEAR THE OBJECTIVE LINE (update74) ──
   *
   * They sat at y 42 and 70, and the run-goal line sits at y 40 with a
   * height of 17 — so SHOW MAP was drawn straight through it and the
   * player read "OBJ Cut them dow…" with a button on top of the rest.
   *
   * Both moved down by the height of that line. The gap is measured
   * from `Renderer.runGoalsRect()` rather than typed in here, so there
   * is one description of where the line is and these buttons are
   * placed against it instead of beside it. FIXED, not conditional:
   * a button that moves depending on whether this contract carries
   * objectives is a button the hand has to look for.
   */
  const _TOP_BTN_W = 150, _TOP_BTN_H = 24, _TOP_BTN_GAP = 6;
  function _topBtnY() {
    // `runGoalsBox`, not `runGoalsRect`: where the line LIVES, not
    // whether it has anything on it today. Asking the second question
    // here is what would make the buttons move between contracts.
    const box = Renderer.runGoalsBox ? Renderer.runGoalsBox() : { y: 40, h: 17 };
    return box.y + box.h + _TOP_BTN_GAP;
  }

  /* SIDE BY SIDE, not stacked (update74).
   *
   * Moving them below the objective line was half the fix and the
   * screenshot showed the other half: stacked, CARGO landed at y 89
   * and drove straight through the green "CHOOSE YOUR STARTING LANE"
   * banner — the very first thing a player sees in a run. The strip
   * between the resources row and the map panel is 40..115, which is
   * not tall enough for two rows of buttons and a banner.
   *
   * One row of two is. It gives back 28 vertical pixels, the banner
   * keeps its place, and the pair still reads as a pair. */
  /* RIGHT OF THE COMMANDER BAR (update104). The bar is up on the map now
     too, and the strip under the resources row (40..115) cannot hold
     the bar, the objective line AND these two. They go to the right of
     the bar, level with it — FIXED, whether a commander is aboard or
     not, for the reason above: a button that moves is a button the
     hand has to look for. */
  function _topBtnX0() {
    const bar = Renderer.commanderBarRects ? Renderer.commanderBarRects().bar : { x: 300, w: 615 };
    return bar.x + bar.w + 10;
  }
  function _mapToggleRect() {
    const bar = Renderer.commanderBarRects ? Renderer.commanderBarRects().bar : { y: 44, h: 36 };
    return { x: _topBtnX0(), y: bar.y + (bar.h - _TOP_BTN_H) / 2,
             w: _TOP_BTN_W, h: _TOP_BTN_H };
  }

  function _holdBtnRect() {
    const t = _mapToggleRect();
    return { x: t.x + t.w + _TOP_BTN_GAP, y: t.y, w: _TOP_BTN_W, h: _TOP_BTN_H };
  }

  function _drawMapToggle(ctx) {
    // Cargo hold is reachable from either map view — you pack between
    // jumps, and a full hold is a decision you want to see coming.
    const hb = _holdBtnRect();
    const hold = _playerShip?.cargo;
    const hot  = Utils.pointInRect(Input.mouse.x, Input.mouse.y, hb.x, hb.y, hb.w, hb.h);
    const warn = hold?.hasLiveHazard?.();
    ctx.fillStyle = hot ? 'rgba(26,140,255,0.18)' : 'rgba(13,17,32,0.92)';
    ctx.beginPath(); ctx.roundRect(hb.x, hb.y, hb.w, hb.h, 4); ctx.fill();
    ctx.strokeStyle = warn ? '#ff5566' : '#4db8ff'; ctx.lineWidth = 1; ctx.stroke();
    ctx.fillStyle = warn ? '#ff5566' : '#4db8ff';
    ctx.font = '11px Share Tech Mono, monospace';
    ctx.textAlign = 'center';
    const used = hold ? `${hold.usedCells()}/${hold.capacity}` : '—';
    ctx.fillText(`${warn ? '⚠' : '▣'} CARGO ${used}  [C]`, hb.x + hb.w / 2, hb.y + 17);

    const b = _mapToggleRect();
    ctx.fillStyle = 'rgba(13,17,32,0.92)';
    ctx.beginPath(); ctx.roundRect(b.x, b.y, b.w, b.h, 4); ctx.fill();
    ctx.strokeStyle = '#4db8ff'; ctx.lineWidth = 1; ctx.stroke();
    ctx.fillStyle = '#4db8ff';
    ctx.font = '11px Share Tech Mono, monospace';
    ctx.textAlign = 'center';
    ctx.fillText(_mapView === 'map' ? '⇄ SHOW SHIP  [M]' : '⇄ SHOW MAP  [M]',
                 b.x + b.w / 2, b.y + 17);
  }

  function _drawMap(ctx) {
    Renderer.drawBackground(0);
    if (_mapView === 'ship') {
      // SHIP view — full-size ship, crew management between jumps
      if (_playerShip) _playerShip.draw(ctx);
      _drawCrewSelection(ctx);
      _drawBodyMenu(ctx);
    } else {
      // MAP view — centered sector map
      Renderer.drawMapScreen(_sectorMap, _mapHover, _playerShip?.cargo ?? null);
    }
    Renderer.drawHUD({ playerShip: _playerShip });
    _drawMapToggle(ctx);
  }

  /** FTL escape rules: working engines + manned working cockpit, never vs boss */
  /* ── THE ESCAPE POD (update50) ────────────────────────────
   *
   * The one chip that is SPENT, and the only way a commander survives a
   * contract that has already been lost.
   *
   * It is deliberately not a get-out-of-jail card. The countdown runs
   * while the fight goes on — 12 seconds at level I, 6 at IV — and if
   * the hull dies or the last living crewman dies before it ends, the
   * commander dies with them. What he buys with it is his own levels,
   * his karma and his remaining chips; what he pays is the ship, the
   * hold, the cat and every hand aboard, who surrender and do not come
   * home. There is no ransom system and there is not going to be one.
   *
   * And then karma takes 10 off him for it, AFTER the pod is away —
   * the penalty must never be able to switch off the very pod that is
   * carrying him.
   */
  /* (update104: the strip is the WHO corner of the commander bar now —
     the badge kept its place beside his name.)
     THE POD IS A BADGE BESIDE THE COMMANDER (update90a). It was a
     130px button at the top centre — exactly where JUMP [ENTER] is drawn
     after a win, so the two sat on top of each other. It is a small icon
     at the right end of the commander strip now, always there while a
     commander is aboard: live when a working pod chip is mounted, grey
     when there is none or it has gone dark, and the hover says which. */
  function _podRect() {
    const c = Renderer.commanderStripRect();
    return { x: c.x + c.w + 4, y: c.y, w: c.h, h: c.h };
  }

  /** What the badge has to say: 'live', 'dark' (Re-Atum mounted, dark), 'none'. */
  function _podState() {
    if (_podSeconds()) return 'live';
    const cap = _commander;
    if (cap && typeof Chips !== 'undefined' && Chips.board) {
      // Re-Atum carries the pod since update99 (the escape-pod chip is gone).
      const any = Chips.board(cap).items.some(it => it.def?.chipKey === 're_atum');
      if (any) return 'dark';
    }
    return 'none';
  }

  /** Seconds on the mounted, working pod — 0 when there is none. */
  function _podSeconds() {
    if (!_commander || typeof Commander === 'undefined') return 0;
    return Commander.podSeconds?.() ?? 0;
  }

  function _evacRunning() { return _evacT > 0; }

  function _startEvac() {
    if (_evacRunning()) return false;
    const secs = _podSeconds();
    if (!secs) {
      UI.notify('No working pod — Re-Atum must be among his Destiny Tablets and working.', 'warn');
      return false;
    }
    /* The pod pays at launch time's end — but a pod that could not pay
       must not be started at all (update103). */
    const no = Chips.rescueRefusal?.(_commander);
    if (no) { UI.notify(no, 'warn'); return false; }
    _evacT = secs; _evacSecs = secs;
    UI.notify(`POD: ${secs}s to launch. The fight goes on.`, 'alert');
    return true;
  }

  /** One tick of the countdown. Called from the combat update. */
  function _tickEvac(dt) {
    if (!_evacRunning()) return;
    _evacT -= dt;
    if (_evacT > 0) return;
    _evacT = 0;
    _completeEvac();
  }

  /** The pod is away (by hand): the rescue, then the loss. */
  function _completeEvac() {
    _evacT = 0; _evacSecs = 0;
    if (!_reAtumRescue('pod')) _onLose();
  }

  /**
   * RE-ATUM'S RESCUE (update103, jj's card, package F). At hull 0 by
   * itself, or when the pod launched by hand lands. The RUN ENDS (jj
   * 07.10) — but not for everybody: by its level it brings home the
   * commander, 1 or 2 of the crew (the most experienced) or all of the
   * living crew, 0 / 10 / 25 / 50% of the run's scrap as CC, and at IV
   * a copy of one of his other tablets into the warehouse. Paid in
   * Knowledge now; spent — the tablet leaves the board. Returns false
   * when it cannot save him (the caller loses the run the old way).
   */
  function _reAtumRescue(cause = 'hull') {
    const cap = _commander;
    if (!cap || typeof Chips === 'undefined' || !Chips.rescueRefusal) return false;
    if (Chips.rescueRefusal(cap)) return false;
    const eff = Chips.rescueLevel(cap);
    const def = Chips.DEFS.re_atum;
    if (!Commander.spendKnowledge(cap, Chips.costOf('re_atum', eff))) return false;

    /* The best working one flies — the level podSeconds() and the
       rescue promised — and leaves the board (jj: one use). */
    const board = Chips.board(cap);
    const flown = board.items
      .filter(it => it.def.chipKey === 're_atum' && Chips.itemLevel(cap, it) > 0)
      .sort((a, b) => Chips.itemLevel(cap, b) - Chips.itemLevel(cap, a))[0];
    if (flown) board.remove(flown);
    Chips.commit(cap, board);

    // Who gets a seat: the most experienced first.
    const alive = (_playerShip?.crew ?? []).filter(c =>
      c && c.isPlayer && !c.isPet && !c.dead && !c.dying);
    const seats = def.crew[eff - 1];
    const saved = alive.slice().sort((a, b) => (b.level ?? 0) - (a.level ?? 0)
      || (b.totalXP?.() ?? 0) - (a.totalXP?.() ?? 0)).slice(0, seats);
    const left = alive.length - saved.length;
    const run = Save.getRun();
    const cc = Math.floor((run?.scrap ?? 0) * def.scrap[eff - 1]);
    Base.returnFromRun({ shipEntry: null, crew: saved.map(c => c.serialise()), cc });

    // IV: a copy of one of his other tablets, onto the warehouse shelf.
    let copied = null;
    if (def.copy[eff - 1] > 0) {
      const others = Chips.board(cap).items.filter(it => it.def.chipKey && it.def.chipKey !== 're_atum');
      const pick = others.length ? others[Math.floor(Math.random() * others.length) % others.length] : null;
      const shelf = pick ? Base.warehouseGrid?.() : null;
      if (pick && shelf) {
        const item = new CargoItem(pick.defKey);
        if (shelf.autoPlace(item)) { Base.commitWarehouse(shelf); copied = item.def.label ?? pick.defKey; }
      }
    }

    cap.away = false;
    cap.escapes = (cap.escapes ?? 0) + 1;
    Base.saveCommander?.(cap);
    /* THE PENALTY IS LAST, and only for a living crew left behind —
       at IV nobody is. */
    if (left > 0 && typeof Commander !== 'undefined') {
      const r = Commander.shift(cap, Commander.KARMA.EVACUATE);
      Base.saveCommander?.(cap);
      if (r) {
        UI.notify(`${cap.name} left a living crew behind: karma ${r.from} → ${r.to}`
                + (r.killed ? ` — ${r.killed} tablet(s) went dark` : ''), 'warn');
      }
    }
    UI.notify(`Re-Atum ${Chips.roman(eff)}${cause === 'hull' ? ' at hull 0' : ''} — ${cap.name} is home`
            + (saved.length ? ` with ${saved.map(c => c.name).join(', ')}` : '')
            + (cc ? `, ${cc} CC of the scrap` : '')
            + (copied ? `, and a copy of ${copied} on the shelf` : '') + '.', 'good');
    _rescued = { level: eff, crew: saved.length, cc, copied };
    _commander = null;          // so _onLose does not bury him as well
    Commander?.setActive?.(null);
    _onLose();
    return true;
  }

  /* ── ORDERS NEED A COMMANDER (update51) ──────────────────────
   *
   * A ship without a commander still FLIES: the crew walk where you
   * point them, man consoles, put out fires, patch breaches, fire the
   * guns, and you still move power around. What it cannot do is
   * anything that is an ORDER TO THE SHIP AS A WHOLE — doors, the
   * boarding party, saved stations, and running away. Those are the
   * chair's job, and now they need someone sitting in it.
   *
   * This is one predicate with one message, deliberately: four copies
   * of "if there is no commander" would drift apart the first time the
   * wording changed, and a button that draws as enabled but refuses to
   * act is the worst outcome here. The renderer asks the same
   * question through Game.hasCommander().
   */
  function _hasCommander() { return !!_commander; }

  /** Refuse an order and say why. Returns TRUE when it refused. */
  function _needCommander(what) {
    if (_hasCommander()) return false;
    UI.notify(`No commander in the chair — no orders: ${what}`, 'warn');
    return true;
  }

  /* ── EVERY ORDER IS PAID FOR (update98) ─────────────────────
   *
   * jj: "Knowledge schodzi przy każdym rozkazie". The routine orders
   * (SAVE POS, RETURN, OPEN ALL, CLOSE ALL, BOARD, RECALL) are given
   * as often as the pool lasts; Commander.orderRefusal is the ONE rule
   * for whether he may, routine or special, and Commander.giveOrder
   * the one place that takes the knowledge.
   *
   * Two halves on purpose: ASK before the order is worked out, PAY
   * only once it actually did something — an order that moved nothing
   * costs nothing, the rule the special orders have had since 53.
   */
  function _orderRefused(key) {
    const label = Commander?.ROUTINE?.[key]?.label ?? key;
    if (_needCommander(label)) return true;
    const no = (typeof Commander !== 'undefined') ? Commander.orderRefusal(key, _commander) : null;
    if (no) { UI.notify(no, 'warn'); return true; }
    return false;
  }
  function _payOrder(key) {
    return (typeof Commander !== 'undefined') ? Commander.giveOrder(key, _commander) : true;
  }

  /**
   * WHAT STOPS THE DRIVE — ONE ANSWER, TWO DOORS (update68).
   *
   * Running from a fight and jumping on the map are the SAME physical
   * act, and until now they asked different questions: the map checked
   * only fuel, the retreat checked fuel, engines and cockpit power, and
   * NEITHER asked whether anybody was at the helm. So you could jump a
   * sector with a dead cockpit and an empty chair.
   *
   * The player's rule, and it is the right one: "jak silniki nie
   * działają lub kokpit, skok jest niemożliwy... tak samo załogant musi
   * być w kokpicie działającym... tak samo co do ucieczki z walki."
   *
   * Returns the sentence to show, or null when the drive will spin up.
   */
  function _jumpRefusal() {
    if (_fuelAboard() <= 0) return 'DRIVE WILL NOT SPIN UP — no He2 cells in the hold.';
    const eng = _playerShip?.getSystem('engines');
    if (!eng || eng.effectivePower() <= 0) return 'Engines offline — cannot jump!';
    const pil = _playerShip?.getSystem('piloting');
    if (!pil || pil.effectivePower() <= 0) return 'Cockpit offline — cannot jump!';
    /* AND SOMEBODY HAS TO BE SITTING IN IT. `crewOperating` is the same
       list the cockpit's own evasion bonus reads, so "manned" means one
       thing on this ship, not two. */
    const at = _playerShip.crewOperating
      ? _playerShip.crewOperating(pil.roomId).filter(c => c && c.isPlayer && !c.isPet)
      : [];
    if (!at.length) return 'Nobody at the helm — put a hand in the cockpit.';
    return null;
  }

  function _canRetreat() {
    if (_needCommander('RETREAT')) return false;
    if (BossManager.isActive) {
      UI.notify('Cannot escape Apophis!', 'alert');
      return false;
    }
    const why = _jumpRefusal();
    if (why) { UI.notify(why, 'alert'); return false; }
    return true;
  }

  /** Click near a door toggles it (interior: auto→open→closed; airlock: closed↔open) */
  function _handleDoorClick() {
    if (!_playerShip) return false;
    const mx = Input.mouse.x, my = Input.mouse.y;
    /* THE MENU OWNS ITS OWN PRESS (update69). A hatch under an open
       body menu used to swallow the click that was aimed at a row —
       the player gave VENT and the door opened instead. An open menu
       is modal for one press, exactly as `_crewClickResolve` already
       treats it; this is the same rule, one step earlier in the frame. */
    if (_bodyMenu) return false;
    for (const d of _playerShip.doors) {
      if (d.hits(mx, my)) {
        /* A HAND ON THE HATCH NEEDS NO COMMANDER (update54).
           update51 put every order under the commander and swept the
           doors up with them, which took away the one thing the player
           can always do himself: walk over and pull a lever. OPEN ALL /
           CLOSE ALL are still orders — they are the ship acting as one,
           and `_setAllDoors` guards them — but a single hatch is not.
           Returning TRUE keeps the click spent either way: doors sit on
           room WALLS, so nothing else claims that pixel. */
        d.toggle();
        if (d.isAirlock && d.open) UI.notify('Airlock OPEN — venting!', 'warn');
        return true;
      }
    }
    return false;
  }

  // ── Rubber-band crew selection (Windows/FTL style) ────────
  let _dragStart   = null;    // {x,y} where LMB went down
  let _dragActive  = false;   // moved far enough to count as a drag
  let _pressConsumed = false; // press hit a UI button/door — no select/move
  let _pressHadWeapon = false; // press was a weapon-targeting click
  let _lastCrewClick = { c: null, t: 0 };   // double-click detection

  /** The body under the cursor, if any. Deliberately the same tight
   *  ellipse as a living crewman: what you can click is what you can
   *  see, and a corpse is drawn the same size as the man was. */
  function _bodyUnderCursor(mx, my) {
    if (!_playerShip) return null;
    /* ANY of our own, on his feet or on the floor (update66). The menu
       is "what do I do with this person"; which rows it offers is the
       next function's business. */
    /* A BODY IS DRAWN LOW IN THE ROOM (update68), so its hot spot has
       to be low too — the offset comes from the same constant the
       drawing uses, never a second copy of it. */
    return _nearestCrew(mx, my, _playerShip.crew.filter(c => {
      /* OURS — AND THE MAN OUT OF OUR OWN CELL (update72). He is the
         one person aboard who is not `isPlayer` and still has an order
         the player can give him: back in the cell. Leaving him out of
         this test would have drawn a menu row nobody could ever
         reach. */
      if (!c || c.ejected) return false;
      /* AND THEIR DEAD (update93). A boarder killed on our deck used to
         be a body nobody could touch: not ours, so no menu — he lay there
         and rotted into our air for the rest of the contract. He is a
         body like any other now: VENT him, or BAG him for a grave
         without a name. The living ones are still not ours to order. */
      const theirDead = !c.isPlayer && !c.isPrisoner && !c.isPet && c.dead;
      if (!c.isPlayer && !c.isPrisoner && !theirDead) return false;
      const dy = (c.dead || c.down) ? CrewMember.BODY_DROP : 0;
      return _hitsCrew(mx, my - dy, c);
    }), c => (c.dead || c.down) ? CrewMember.BODY_DROP : 0);
  }

  /**
   * WHICH ROWS THIS PERSON GETS.
   *
   * A man on his feet is fed; a man on the floor is treated, vented or
   * bagged. One gesture, one menu, and the rows follow his state — an
   * always-four-row menu with three permanently dead rows would be
   * three quarters noise.
   */
  function _menuActsFor(person) {
    if (!person) return [];
    /* ── A MAN YOU HAVE CORNERED (update72) ───────────────────
     *
     * One row, and only for somebody who is out of your cell and
     * still aboard: put him back. It is the other half of making the
     * escape a WALK — trapping him behind a door has to be worth
     * doing, and this is what it is worth. He is not fed, not
     * treated, not bagged and not vented while he is alive, so the
     * menu is his one row and nothing else. */
    if (person.isPrisoner) return person.dead ? ['eject', 'bag'] : ['cell'];
    /* ── A MAN IN A SLAB (update77) ───────────────────────────
     * One row, and it is the only one that means anything: he cannot
     * be fed, treated, bagged or ejected while he is frozen, because
     * nothing is happening to him at all. */
    if (person.frozen) return ['thaw'];
    /* ── THE ROWS FOLLOW HIS STATE (sharpened in update78) ────
     *
     * They used to be one list for the dead and the merely downed —
     * TREAT, EJECT, BAG — with the refusals doing the talking, so a
     * living casualty was shown two rows that exist for a corpse and a
     * corpse was shown one that exists for a casualty. Three of the
     * six were always dead on arrival.
     *
     * A BODY is something you get rid of; a CASUALTY is something you
     * get back. */
    if (person.dead) return ['eject', 'bag'];
    if (person.down) return ['treat', 'medkit'];
    /* FREEZE is offered next to FEED and refused with a reason when he
       is not standing in the bay — the same contract every other row
       keeps: the row is drawn, the click explains. Offering it only
       when it would work would hide the bay from a player who has one
       and has never walked anybody into it. */
    /* HEAL beside FEED (update97): a dose, from his own menu. */
    return _playerShip?.getSystem('carbonite') ? ['feed', 'heal', 'freeze'] : ['feed', 'heal'];
  }



  /** The body the open menu belongs to, or null if he has since gone
   *  out an airlock — the menu is an anchor and an ID, never a
   *  reference that can outlive what it points at. */
  function _bodyMenuBody() {
    if (!_bodyMenu || !_playerShip) return null;
    return _playerShip.crew.find(c => c && c.id === _bodyMenu.id && !c.ejected) || null;
  }

  /** Which row of the open menu is under the cursor. Reads the SAME
   *  rectangles the drawing does, and asks the same refusal question:
   *  a greyed row is not clickable. */
  function _bodyMenuHit(mx, my) {
    const body = _bodyMenuBody();
    if (!body) return null;
    const R = Renderer.bodyMenuRects(_bodyMenu.x, _bodyMenu.y, _menuActsFor(body));
    /* THE ROW UNDER THE CURSOR, refused or not (update68). The menu no
       longer prints the reason on the row — it got too big to sit over
       a ship — so the reason has to arrive when the row is CLICKED.
       Filtering refused rows out here would have made them silent
       again, which is the bug this project keeps coming back to. */
    return R.items.find(it =>
      mx >= it.x && mx <= it.x + it.w && my >= it.y && my <= it.y + it.h) || null;
  }

  function _crewUnderCursor(mx, my) {
    if (!_playerShip) return null;
    // `alive` (not just "not dead") — a DOWNED body lying on the floor
    // takes no orders, so it must not swallow the click. It used to:
    // clicking a wrecked room that had wounded in it just re-selected
    // a body instead of sending the repair crew in.
    // Radius is sprite-tight (13px). It used to be 20, which made a
    // crew member standing anywhere near the middle of a module eat
    // every click aimed at that module — you'd just keep re-selecting
    // him instead of ordering the repair you wanted.
    // The anchor is c.y - 1, the sprite's real centre. It used to be
    // c.y - 14, thirteen pixels above his head, so the hot spot sat on
    // the crewman's name plate rather than on the crewman.
    //
    // And it is an ELLIPSE the size of the drawn ring, not a circle:
    // a man is 9px wide and 26 tall, so a 13px circle claimed four
    // pixels of module either side of him for nothing. Matching the
    // ring means what you can click is exactly what you can see.
    /* `c.isPlayer` (update42): this used to match ANY living body in
       _playerShip.crew, so an enemy boarder standing on your deck could
       be clicked, selected, added to a group and ORDERED AROUND YOUR
       SHIP like one of your own. */
    /* THE NEAREST, NOT THE FIRST (update120). The operator stands only
       OPERATOR_LIFT above the walk line now, so a man passing in front
       of the console overlaps him — and "first in the crew list" then
       picked whoever was hired earlier, not the one under the pointer. */
    const own = _nearestCrew(mx, my, _playerShip.crew.filter(c => c.isPlayer && c.alive && _hitsCrew(mx, my, c)));
    if (own) return own;
    // A man out in the wreckage can be picked up where he floats (update93b).
    const eva = (CombatManager.salvage?.men ?? []).find(m => m.phase !== 'muster' && m.c.alive && _hitsCrew(mx, my, m.c, 1.4));
    if (eva) return eva.c;
    // Your boarders on the ENEMY ship are selectable the same way
    if (_enemyShip) {
      return _enemyShip.crew.find(c =>
        c.isPlayer && !c.dead && !c.dying && _hitsCrew(mx, my, c, 1.4)) ?? null;
    }
    return null;
  }

  /** Inside the selection ring? rx/ry match _drawCrewSelection exactly. */
  /** Of the bodies under the pointer, the one whose middle is closest
   *  (update120) — or null. `drop` is how far below his line a body lies. */
  /** The middle of the man as drawn (update124: a man is taller than a cat). */
  function _crewMid(c) {
    if (c.isPet || !CrewMember.HIT) return c.y - 1;
    return c.y + ((c.dead || c.down) ? CrewMember.HIT_LYING.cy : CrewMember.HIT.cy);
  }
  function _nearestCrew(mx, my, list, drop = () => 0) {
    let best = null, bd = Infinity;
    list.forEach(c => {
      const d = Math.hypot(mx - c.x, my - drop(c) - _crewMid(c));
      if (d < bd) { bd = d; best = c; }
    });
    return best;
  }

  function _hitsCrew(mx, my, c, scale = 1) {
    /* A man is taller since update124 (CrewMember.HIT); a cat is not. */
    const H = (!c.isPet && CrewMember.HIT)
      ? ((c.dead || c.down) ? CrewMember.HIT_LYING : CrewMember.HIT)   // a body lies flat (update124)
      : { cy: -1, rx: 8, ry: 14 };
    const rx = H.rx * scale, ry = H.ry * scale;
    const dx = (mx - c.x) / rx, dy = (my - (c.y + H.cy)) / ry;
    return dx * dx + dy * dy <= 1;
  }

  /** Runs every frame in map AND combat: press bookkeeping, drag
   *  rectangle, and click-vs-drag resolution on release. */
  function _crewMouseUpdate() {
    if (!_playerShip) return;
    const mx = Input.mouse.x, my = Input.mouse.y;
    /* The wheel over the crew list scrolls it (update97). */
    {
      const wheel = Input.mouse.scrollDelta || 0, box = Renderer.rosterBox?.();
      if (wheel && box && Utils.pointInRect(mx, my, box.x, box.y, box.w, box.h + 14)) {
        Renderer.scrollRoster(wheel);
      }
    }

    if (Input.mouse.leftPressed) {
      // OR, not assign: _updateCombat handles the BOARD/RECALL/RETREAT
      // buttons BEFORE this runs and flags the press as spent. Assigning
      // here wiped that flag, so the same press fell through to
      // _crewClickResolve, hit no room, and cleared the selection.
      _pressConsumed = _handlePowerBarClick() || _handleDoorClick() || _pressConsumed;
      _pressHadWeapon = !!_selectedWeapon;   // weapon targeting wins the click
      _dragStart  = _pressConsumed ? null : { x: mx, y: my };
      _dragActive = false;
    }

    if (_dragStart && Input.mouse.leftDown &&
        Utils.dist(mx, my, _dragStart.x, _dragStart.y) > 8) {
      _dragActive = true;
    }

    /* ── RIGHT-CLICK A BODY: WHAT DO WE DO WITH HIM (update65) ──
     *
     * The FIRST version of this opened on a plain left click and broke
     * the oldest rule on this screen inside a minute: three downed men
     * lying in a wrecked module swallowed every click aimed at the
     * module, so the repair order could not be given. That is the
     * update34 bug, rediscovered by its own test.
     *
     * A context menu is a context gesture. Right-click leaves every
     * existing left-click order exactly as it was — move, repair,
     * board, target — and needs no rule about which one wins.
     */
    if (Input.mouse.rightPressed) {
      /* ONLY WITH SOMEBODY SELECTED (update68). Every row of this menu
         is an order, and an order needs a man to carry it out — so a
         menu raised with nobody picked was three buttons that could
         only ever say no. The player asked for exactly this: "menu nie
         ma jak nie jest zaznaczony załogant". */
      const sel = UI.getSelectedCrewAll();
      const body = sel.length ? _bodyUnderCursor(mx, my) : null;
      /* ANCHORED ON THE MAN, NOT ON THE CURSOR (update69). The menu
         opened wherever the mouse happened to be, which on a hull this
         tight is usually a wall — and walls are where the doors are.
         Hanging it under his feet puts it over floor, and it lands in
         the same place every time you right-click the same man. */
      const ax = body ? body.x : mx;
      const ay = body ? body.y + ((body.dead || body.down) ? CrewMember.BODY_DROP : 0) : my;
      _bodyMenu = body ? { id: body.id, x: ax, y: ay } : null;
      return;
    }

    if (Input.mouse.leftReleased) {
      const additive = Input.isHeld('ShiftLeft') || Input.isHeld('ShiftRight');
      if (_dragActive && _dragStart) {
        // Rubber-band: select every living crew member inside the box
        const x0 = Math.min(_dragStart.x, mx), x1 = Math.max(_dragStart.x, mx);
        const y0 = Math.min(_dragStart.y, my), y1 = Math.max(_dragStart.y, my);
        const pool = [..._playerShip.crew.filter(c => c.isPlayer),
          ...(_enemyShip ? _enemyShip.crew.filter(c => c.isPlayer && !c._survivor) : [])];
        const hit = pool.filter(c => !c.dead && !c.dying &&
          c.x >= x0 && c.x <= x1 && _crewMid(c) >= y0 && _crewMid(c) <= y1);
        if (hit.length || !additive) UI.selectCrewGroup(hit, additive);
        if (hit.length) UI.notify(`${hit.length} crew selected`, 'info');
      } else if (!_pressConsumed && !_dragActive) {
        _crewClickResolve(mx, my, additive);
      }
      _dragStart = null; _dragActive = false; _pressConsumed = false;
    }
  }

  /**
   * RELIEVING A CASUALTY (update79).
   *
   * The player's report: "brak podmienienia zalogantow na kogos kto ma
   * wiecej hp a tego z mala iloscia aby muc wyslac do medbay". Pulling
   * a bleeding gunner out and putting a fresh man in was two orders
   * that could not both be given — the module refused the fresh man
   * while the wounded one was still standing in it, and moving the
   * wounded one first meant the bay sat empty under fire.
   *
   * One click does both now, and only when it is an IMPROVEMENT: the
   * worst-hurt man in the room steps out for someone in better shape.
   * A relief that swapped a healthy man for a healthier one would be
   * the game quietly re-sorting the player's crew behind his back.
   *
   * He walks to the medbay if the hull has one — that is the point of
   * the order — and otherwise to any other compartment with room,
   * because "there is no ward" must not mean "he stays in the fight".
   * Both starting hulls have no medbay, so the fallback is the common
   * case, not the exotic one.
   *
   * @returns {number} how many places were actually freed
   */
  function _relieveInRoom(room, incoming, needed) {
    if (needed <= 0 || !incoming.length) return 0;
    const frac = c => (c.maxHp > 0 ? c.hp / c.maxHp : 1);
    const med  = _playerShip.getSystem('medbay');
    const ward = med ? _playerShip.getRoomById(med.roomId) : null;
    const dest = (ward && ward.id !== room.id) ? ward
               : _playerShip.rooms.find(r => r.id !== room.id &&
                   _playerShip.roomSpaceFor(r.id, true) > 0);
    if (!dest) return 0;

    // The best man being sent in is the bar: nobody steps out for
    // somebody in worse shape than himself.
    const bar = incoming.reduce((a, b) => (frac(b) > frac(a) ? b : a));
    const here = _playerShip.crew
      .filter(c => c.alive && c.isPlayer && !incoming.includes(c) &&
                   (c.roomId === room.id || c.homeRoomId === room.id))
      .sort((a, b) => frac(a) - frac(b));

    let freed = 0;
    for (const man of here) {
      if (freed >= needed) break;
      if (frac(man) >= frac(bar)) break;           // no improvement, no relief
      const slot = _playerShip.freeStationSlot(dest, [man], true);
      const [tx, ty] = _playerShip.stationSlot(dest, slot);
      man.homeRoomId = dest.id;
      man.assignTask(TASK.IDLE);
      man.moveToOnShip(_playerShip, tx, ty);
      freed++;
      UI.notify(`${man.name} is relieved — ${dest.id === ward?.id
        ? 'heading to the medbay' : 'pulled out of the line'}.`, 'info');
    }
    return freed;
  }

  /** Plain click: crew sprite → select (dbl-click = select ALL);
   *  otherwise a room click sends the WHOLE selection there. */
  function _crewClickResolve(mx, my, additive) {
    const sel0 = UI.getSelectedCrewAll();

    /* ── THE BODY MENU EATS ITS OWN CLICK FIRST (update65) ──
       An open menu is modal for one press: a click on a row is the
       order, a click anywhere else shuts it. Without this the same
       press would also be read as "move the selection here", and the
       player would order a burial and a march in one go. */
    if (_bodyMenu) {
      const hit = _bodyMenuHit(mx, my);
      /* A row is the order; anywhere else just shuts it. The click is
         SPENT either way — see the note above. */
      const body = _bodyMenuBody();
      _bodyMenu = null;
      if (hit && body && _playerShip) {
        /* A GREYED ROW SAYS WHY. It cannot be carried out, but the
           player clicked it and is owed a sentence. */
        const why = _playerShip.menuRefusal(body, hit.act);
        if (why) {
          UI.notify(`${hit.act.toUpperCase()} — ${why}.`, 'warn');
        } else {
          /* THE SELECTED MAN IS THE ONE WHO GOES. */
          const doer = UI.getSelectedCrewAll().find(c => c && c.alive && c !== body)
                    || UI.getSelectedCrew();
          const r = hit.act === 'feed'   ? _playerShip.feedCrew(body)
                  : hit.act === 'heal'   ? _playerShip.healCrew(body)
                  : hit.act === 'cell'   ? _playerShip.returnToCell(body)
                  : hit.act === 'freeze' ? _playerShip.freezeCrew(body)
                  : hit.act === 'thaw'   ? _playerShip.thawCrew(body)
                  : _playerShip.orderBody(body, hit.act, doer);
          UI.notify(r.message, r.ok ? 'good' : 'warn');
        }
      }
      return;
    }

    const c = _crewUnderCursor(mx, my);

    /* CLICKING A CREWMAN ALWAYS PICKS HIM UP.
     *
     * update34 made a live selection turn every click into an ORDER, so
     * that the console operator standing in the middle of a module could
     * not eat the click aimed at that module. It worked — and it broke
     * the most ordinary gesture in the game: clicking one crewman while
     * another was selected no longer switched to him.
     *
     * Switching wins. The room click is protected by geometry instead:
     * the hot spot is the SILHOUETTE (an ellipse the size of the drawn
     * selection ring, not a 13px circle around a point above his head),
     * and the operator stands high in the room rather than dead on its
     * centre — so there is always most of a module left to click. */
    if (c) {
      const now = performance.now();
      if (_lastCrewClick.c === c && now - _lastCrewClick.t < 350) {
        UI.selectCrewGroup(Renderer.crewRoster({
          playerShip: _playerShip, enemyShip: _enemyShip,
        }).filter(k => !k.dead && !k.dying));
        UI.notify('All crew selected', 'info');
      } else {
        UI.selectCrew(c, additive);
      }
      _lastCrewClick = { c, t: now };
      return;
    }
    const sel = sel0;
    if (!sel.length) return;

    // ── Boarder orders: clicking an ENEMY room moves YOUR crew who
    //    are aboard the enemy ship — exactly like moving at home. ──
    if (_enemyShip && !_pressHadWeapon && STATE === 'combat') {
      const eRoom = _enemyShip.rooms.find(r => r.contains(mx, my));
      if (eRoom) {
        const aboard = sel.filter(c => _enemyShip.crew.includes(c));
        if (aboard.length) {
          // ONE capacity rule, asked of the ship (update79) — see
          // Ship.roomSpaceFor. This used to be counted out by hand here
          // and again at the home-ship click below, with two different
          // filters; the defenders' places are theirs, ours are ours.
          const movers = aboard.slice(0, _enemyShip.roomSpaceFor(eRoom.id, true, aboard));
          if (!movers.length) {
            UI.notify(`Module full (max ${Ship.ROOM_SLOTS} of yours)`, 'warn');
            return;
          }
          // Free SPOTS, not head counts — same rule as at home, so a
          // boarding party of three does not pile onto one console.
          const picks = _enemyShip.allocStationSlots(eRoom, movers);
          movers.forEach((m, i) => {
            const [tx, ty] = _enemyShip.stationSlot(eRoom, picks[i]);
            m.homeRoomId = eRoom.id;
            m._ordered   = true;   // boarder AI stops auto-roaming
            m.moveToOnShip(_enemyShip, tx, ty);
          });
          return;
        }
      }
    }

    const room = _playerShip.rooms.find(r => r.contains(mx, my));
    // Clicking off the hull drops the selection — the counterpart to
    // "a live selection turns clicks into orders", and the way you get
    // back to picking an individual crew member.
    if (!room) {
      if (!(_enemyShip && _enemyShip.rooms.some(r => r.contains(mx, my)))) {
        UI.selectCrewGroup([]);
      }
      return;
    }
    // Boarders still aboard the ENEMY hull can't just walk into a room
    // on OUR ship — they're not physically here. Use RECALL to bring
    // them home first (this used to silently teleport their move
    // target while they stayed registered as enemy crew — the "fly
    // home then re-breach the same door" glitch).
    const homeSel = sel.filter(c => _playerShip.crew.includes(c));
    if (!homeSel.length) {
      if (_enemyShip && sel.some(c => _enemyShip.crew.includes(c))) {
        UI.notify('They’re still aboard the enemy ship — use RECALL.', 'warn');
      }
      return;
    }
    /* ROOM CAPACITY — Ship.roomSpaceFor, and it is per SIDE (update79).
     * The count used to live here, filtered on `alive` alone, so
     * boarders standing in the room ate your places: two intruders in
     * the medbay and you could send one medic to fight them. Three a
     * side now, and the enemy-hull click above asks the same function.
     *
     * AND A CASUALTY CAN BE RELIEVED. If the room is full of your own
     * men, the ones you are sending take the place of the worst-hurt
     * men already there, who are pushed out to make room. Before this,
     * "pull the bleeding gunner out and put a fresh one in" was two
     * orders that could not both be given: the room refused the fresh
     * man while the wounded one was still standing in it. */
    let space = _playerShip.roomSpaceFor(room.id, true, homeSel);
    if (space < homeSel.length) {
      space += _relieveInRoom(room, homeSel, homeSel.length - space);
    }
    if (space === 0) {
      UI.notify(`Module full (max ${Ship.ROOM_SLOTS} crew)`, 'warn');
      return;
    }
    const movers = homeSel.slice(0, space);
    if (movers.length < homeSel.length) {
      UI.notify(`Module full — only ${movers.length} sent (max ${Ship.ROOM_SLOTS})`, 'warn');
    }
    // FTL: sent crew STAY — home follows the order; spread them out
    const breach = _playerShip.breaches.getBreachesInRoom(room.id)[0];
    const needsRepair = room.system && room.system.damagedLevels > 0;
    /* Slot 0 is the CONSOLE, slot 1 the left of it, slot 2 the right.
     *
     * The spots are handed out by Ship.allocStationSlots, which looks at
     * which spots are actually HELD — by men standing on them and by men
     * walking to them — instead of counting heads. Counting heads was
     * wrong twice over: the man already in the room might himself be
     * standing on the left flank (so "one head, you take slot 1" put the
     * newcomer inside him), and three movers sent together all measured
     * the room before any of them had moved, so they stacked. */
    const picks = _playerShip.allocStationSlots(room, movers);
    movers.forEach((m, i) => {
      /* ── A CAT TAKES THE ORDER, NOT THE JOB (update83) ─────
       *
       * The same click sends everybody, and until now it sent the cat
       * the same way it sends a mechanic: a station, a posting, and —
       * if the room was shot up — `TASK.REPAIR`. And she DID it.
       * Measured: a cat alone in a damaged engine room pushed the
       * repair meter from 0 to 0.43 in three seconds. An animal was
       * doing a trade.
       *
       * She still goes where you point. What she does not get is a
       * post to stand at and a job to do when she arrives, because
       * neither is a thing a cat has. `_ordered` is what makes the
       * order STICK — see `Ship.petTick`, where the flag has been read
       * since update45 and, until this package, never written. */
      if (m.isPet) {
        m._ordered = true;
        m.moveToOnShip(_playerShip, room.cx,
                       _playerShip.floorWalkY(room.floor, room.cy));
        return;
      }
      const [tx, ty] = _playerShip.stationSlot(room, picks[i]);
      m.homeRoomId = room.id;
      m.moveToOnShip(_playerShip, tx, ty);
      // Sending crew INTO a damaged or holed room is an explicit repair
      // order — don't rely on the idle auto-task noticing after arrival
      // (a fire, a passing order or a re-route could eat it first).
      if (breach)           m.assignTask(TASK.BREACH, breach);
      else if (needsRepair) m.assignTask(TASK.REPAIR, room.id);
    });
    if (breach)           UI.notify('Sealing hull breach…', 'info');
    else if (needsRepair) UI.notify(`Repairing ${room.system.label}…`, 'info');
  }

  /** Selection visuals: rings under selected crew + drag rectangle */
  function _drawCrewSelection(ctx) {
    if (!_playerShip) return;
    /* A SMALL EGG AT THE BOOTS.
     *
     * This has been round the houses: a flat shadow, then a full-body
     * outline — which at 26x38 was three times the width of the man and
     * made a crowded module unreadable — and now back to the marker the
     * player actually wanted. A little ellipse on the deck under him,
     * kept small so three of them in one room still read as three.
     *
     * The CLICK target is deliberately NOT this shape: you click the
     * man, not his shadow, so _hitsCrew stays body-sized. */
    UI.getSelectedCrewAll().forEach(c => {
      ctx.save();
      ctx.fillStyle = 'rgba(26,255,140,0.20)';
      ctx.beginPath();
      ctx.ellipse(c.x, c.y + 4, 7, 3, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = 'rgba(26,255,140,0.95)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.ellipse(c.x, c.y + 4, 7, 3, 0, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();
    });
    if (_dragActive && _dragStart) {
      const mx = Input.mouse.x, my = Input.mouse.y;
      ctx.fillStyle   = 'rgba(26,140,255,0.12)';
      ctx.strokeStyle = '#4db8ff';
      ctx.lineWidth   = 1;
      const x = Math.min(_dragStart.x, mx), y = Math.min(_dragStart.y, my);
      const w = Math.abs(mx - _dragStart.x), h = Math.abs(my - _dragStart.y);
      ctx.fillRect(x, y, w, h);
      ctx.strokeRect(x + 0.5, y + 0.5, w, h);
    }
  }

  /** Open or close EVERY door at once — interior AND airlocks.
   *  Opening all with airlocks vents the ship, so warn loudly. */
  function _setAllDoors(open) {
    if (!_playerShip) return;
    const key = open ? 'doorsOpen' : 'doorsClose';
    if (_orderRefused(key)) return;
    let moved = 0;
    _playerShip.doors.forEach(d => {
      // Set the LATCH, not the panel — `open` is now derived from the
      // slide animation, so writing it directly would just be undone.
      const want = open ? 'open' : 'closed';
      if (d.mode !== want) { d.mode = want; d._tempT = 0; moved++; }
    });
    Audio.sfx.uiClick();
    /* OPEN ALL / CLOSE ALL were silent (update42): they wrote d.mode
       by hand instead of going through Door.toggle(), so the one place
       doorMove() is played was bypassed and the whole ship's doors
       cycled without a sound. */
    if (moved) Audio.sfx.doorMove?.();
    // Nothing moved, nothing paid (update98).
    if (!moved) {
      UI.notify(open ? 'Every door is already open.' : 'Every door is already closed.', 'info');
      return;
    }
    _payOrder(key);
    UI.notify(open ? 'ALL doors open — the air is going out!' : 'All doors CLOSED',
              open ? 'warn' : 'info');
  }

  /** PHYSICAL boarding: the selected crew WALK to your airlock,
   *  step outside, drift slowly across the void to the enemy's
   *  airlock, SMASH its door open (takes a while), then storm in.
   *  Non-Pegasus crew suffocate the whole way. */
  function _launchBoarders() {
    if (_boardingParty) return;
    /* ── THERE HAS TO BE SOMETHING TO BOARD (update69) ─────────
     *
     * The player pressed BOARD after the fight was over — the enemy
     * hull was a wreck and her crew were dead — and the game played
     * the whole animation into nothing: "udał że otwiera drzwi hak i
     * zniknął przepadł". The man walked out of the airlock towards a
     * ship that no longer takes boarders and never came home, because
     * the only thing that brings boarders back is the end of a fight
     * that had already ended.
     *
     * A silent `return` was the old guard and it is what let this
     * through: `_enemyShip` still points at the hulk. The question is
     * not "is there a record" but "is there a hull over there worth
     * walking to" — and when there is not, the order is refused OUT
     * LOUD, like every other order on this ship.
     */
    const gone = !_enemyShip || _enemyShip.destroyed || _enemyShip.hull <= 0;
    if (gone) {
      UI.notify('Nothing to board — there is no hull left over there.', 'warn');
      _pressConsumed = true;
      return;
    }
    if (!CombatManager.isActive() &&
        CombatManager.state !== COMBAT_STATE.RETREATING && !_wreckMode) {
      UI.notify('The fight is over — nobody is going across now.', 'warn');
      _pressConsumed = true;
      return;
    }
    if (_orderRefused('board')) { _pressConsumed = true; return; }
    // Only crew still aboard OUR ship can be sent — boarders already on
    // the enemy hull are handled by RECALL instead (see _recallBoarders).
    const sel = UI.getSelectedCrewAll()
      .filter(c => c.alive && _playerShip.crew.includes(c)).slice(0, Ship.ROOM_SLOTS);
    if (!sel.length) { UI.notify('Select crew to board with.', 'warn'); return; }
    const party = _makeParty(_playerShip, _enemyShip, sel);
    if (!party) { UI.notify('No airlock route to the enemy!', 'warn'); return; }
    _payOrder('board');
    _boardingParty = party;
    // The selection SURVIVES the launch. Boarders stay yours: they are
    // still drawn with their rings, still listed on the roster, and are
    // still the crew you are giving orders to the moment they land.
    // Dropping it here meant you had to re-select everybody on the
    // enemy hull before you could tell them anything.
    _pressConsumed = true;
    Audio.sfx.uiClick();
    UI.notify(`⚔ Boarding action — crew heading for the airlock`, 'warn');

    /* AND SOMEBODY OVER THERE GIVES AN ORDER (update55).
       A commander on the other bridge does what the player would do
       with the same button: he shuts the ship. It costs our party the
       four seconds at the lock that an open hatch would have saved, so
       an enemy WITH a commander is measurably harder to board than one
       without — which is the whole point of them having one.
       Once per boarding action, and only while he is alive to give it:
       `Commander.enemy()` is the same record the badge reads. */
    if (typeof Commander !== 'undefined' && Commander.enemy?.() && !_enemySealed) {
      _enemySealed = true;
      let moved = 0;
      _enemyShip.doors.forEach(d => {
        if (d.mode !== 'closed') { d.mode = 'closed'; d._tempT = 0; moved++; }
      });
      if (moved) {
        UI.notify('Their commander is sealing the ship — CLOSE ALL DOORS.', 'warn');
      }
    }
  }

  /** Bring boarders HOME: selected crew currently aboard the enemy hull
   *  fly back through their own (already-breached) airlock, cycle open
   *  our OWN airlock (quick, not smashed), and rejoin the roster. */
  function _recallBoarders() {
    _pressConsumed = true;
    if (!_enemyShip || !_playerShip || _boardingParty) return;
    /* RECALL is an order like BOARD (update98): a commander, and one
       knowledge. It used to be the only order with no chair check. */
    if (_orderRefused('recall')) return;
    const sel = UI.getSelectedCrewAll()
      .filter(c => c.alive && c.isPlayer && _enemyShip.crew.includes(c)).slice(0, Ship.ROOM_SLOTS);
    if (!sel.length) { UI.notify('Select boarders on the enemy ship to recall.', 'warn'); return; }
    const party = _makeParty(_enemyShip, _playerShip, sel, { recall: true });
    if (!party) { UI.notify('No airlock route home!', 'warn'); return; }
    _payOrder('recall');
    _boardingParty = party;
    Audio.sfx.uiClick();
    UI.notify('⚓ Boarding party pulling back to the ship', 'warn');
  }

  /** Build a party: members first WALK to fromShip's facing airlock,
   *  then fly to toShip's facing airlock, break it, and enter.
   *  opts.recall marks a RETURN trip home: the destination airlock is
   *  the party's OWN, so it's just cycled open (quick, no permanent
   *  breach) instead of smashed in. */
  function _makeParty(fromShip, toShip, crewList, opts = {}) {
    const recall = !!opts.recall;
    const facingRight = fromShip.worldX < toShip.worldX;
    const exitDoor = fromShip.doors.filter(d => d.isAirlock)
      .sort((a, b) => facingRight ? b.x - a.x : a.x - b.x)[0];
    const entryDoor = toShip.doors.filter(d => d.isAirlock)
      .sort((a, b) => facingRight ? a.x - b.x : b.x - a.x)[0];
    if (!exitDoor || !entryDoor) return null;
    const entryRoom = toShip.getRoomById(entryDoor.roomA) ?? toShip.rooms[0];
    crewList.forEach(c => {
      // Step out of any elevator cabin BEFORE mustering: a boarder who
      // left the ship still flagged as a passenger came home unable to
      // ride, and blocked the shaft for everyone else.
      fromShip.elevators?.release?.(c);
      toShip.elevators?.release?.(c);
      c._waypoints = []; c.task = TASK.IDLE; c.carrying = null;
      c.moveToOnShip(fromShip, exitDoor.x + (facingRight ? -10 : 10), exitDoor.y);
    });
    return {
      fromShip, toShip, exitDoor, entryDoor, entryRoom, facingRight, recall,
      members: crewList.map(c => ({ c, phase: 'muster', x: c.x, y: c.y })),
      breachT: 0, breachNeed: recall ? 1.5 : 4.0, doorBroken: false, t: 0, _sparkT: 0,
    };
  }

  /** One tick of a boarding party (works for BOTH directions). */
  function _updateParty(party, dt) {
    party.t += dt;
    const speed = 85;   // px/s — far slower than any projectile
    const doorSlot = { x: party.entryDoor.x + (party.facingRight ? -16 : 16),
                      y: party.entryDoor.y };

    party.members.forEach(m => {
      const c = m.c;
      if (m.phase === 'muster') {
        // Walking to our own airlock (still a normal crew member)
        m.x = c.x; m.y = c.y;
        const near = Utils.dist(c.x, c.y, party.exitDoor.x, party.exitDoor.y) < 24;
        if (near || party.t > 9) {
          if (!near && party.t > 9) { m.phase = 'cancelled'; return; }
          party.fromShip.crew = party.fromShip.crew.filter(k => k !== c);
          c._waypoints = []; c.task = TASK.IDLE; c.roomId = null;
          m.phase = 'fly';
          m.x = c.x = party.exitDoor.x; m.y = c.y = party.exitDoor.y;
          Audio.sfx.uiClick();
        }
        return;
      }
      if (m.phase === 'cancelled' || m.phase === 'inside') return;

      // The void: no air out here for anyone but Pegasus
      if (c.race !== 'pegasus' && !c.down) c.takeDamage(2.2 * dt, 'suffocation');
      if (c.dead || c.down) {
        /* LOST IN THE VOID MEANS DEAD (update40).
           He was already spliced out of his ship's crew when he cast
           off, so a man who merely went DOWN out here (the 35% roll)
           ended up on nobody's roster: not drawn, not counted, never
           banked at the base and — because he was not `dead` — never
           given a headstone either. He just stopped existing. There is
           no stretcher in vacuum: finish it, and bury him. */
        if (!c.dead) c.killOutright('the void');
        m.phase = 'cancelled';
        UI.notify(`${c.name} was lost in the void…`, 'alert');
        return;
      }

      if (m.phase === 'fly') {
        const dx = doorSlot.x - m.x, dy = doorSlot.y - m.y;
        const d  = Math.hypot(dx, dy);
        if (Math.abs(dx) > 1) c._facing = dx > 0 ? 1 : -1;   // update127: a recall flies home facing home
        if (d < 6) { m.phase = 'wait'; }
        else {
          m.x += (dx / d) * speed * dt;
          m.y += (dy / d) * speed * dt;
          if (Math.random() < 0.3) Particles.emit?.({
            x: m.x - Math.sign(dx) * 10, y: m.y + Utils.randFloat(-3, 3),
            vx: -Math.sign(dx) * 40, vy: 0, ay: 0, color: '#8fd4ff',
            size: 2, sizeEnd: 0, life: 0.35, alpha: 0.7, alphaEnd: 0 });
        }
        c.x = m.x; c.y = m.y;
      }

      if (m.phase === 'wait') {
        c.x = m.x; c.y = m.y + Math.sin(party.t * 5) * 2;
        if (party.doorBroken) {
          // Door's open — climb in
          m.phase = 'inside';
          c.x = party.entryRoom.cx + Utils.randFloat(-16, 16);
          c.y = party.entryRoom.cy + party.entryRoom.h * 0.2;
          c.roomId = party.entryRoom.id;
          c.homeRoomId = party.entryRoom.id;
          c._ordered = false;
          party.toShip.addCrew(c, true);   // keep them in the breached room
        }
      }
    });

    /* AN OPEN HATCH IS NOT HACKED (update55).
       Boarders spent the full four seconds cutting a lock that was
       standing open — the hack was unconditional. A hatch that is open
       when they arrive is simply walked through, which is what makes
       the enemy commander's CLOSE ALL below worth issuing: shutting the
       ship IS the defence, and leaving it open is the price of not
       having anyone on the bridge to order it shut. */
    const waiting = party.members.filter(m => m.phase === 'wait').length;
    if (waiting > 0 && !party.doorBroken &&
        (party.entryDoor.mode === 'open' || party.entryDoor.openness >= 1)) {
      party.doorBroken = true;
      party.entryDoor.openness = 1;
      party.entryDoor.open = true;
      UI.notify(party.toShip.isPlayer
        ? '⚠ THEY WALKED IN THROUGH AN OPEN AIRLOCK!'
        : '⚔ Their airlock stood open — we are aboard.', 'alert');
    }

    // Breaching: everyone waiting at the door hacks at it together
    if (waiting > 0 && !party.doorBroken) {
      party.breachT += dt * Math.min(waiting, 2);   // 2nd pair of hands helps
      party._sparkT += dt;
      if (party._sparkT > 0.25) {
        party._sparkT = 0;
        Particles.emit?.({ x: party.entryDoor.x, y: party.entryDoor.y + Utils.randFloat(-8, 8),
          vx: Utils.randFloat(-50, 50), vy: Utils.randFloat(-40, 10), ay: 60,
          color: '#ffd700', size: 2, sizeEnd: 0, life: 0.5, alpha: 0.9, alphaEnd: 0 });
        Audio.sfx.repair?.();
      }
      if (party.breachT >= party.breachNeed) {
        party.doorBroken = true;
        /* HACKED, NOT SMASHED.
           A boarding party used to set `breached = true` on the hatch,
           which pinned it open for the rest of the RUN — that room then
           vented forever, with no repair task in the game that could
           ever seal it. They crack the lock now: the hatch cycles like
           any other door, stays theirs for the fight, and the hull can
           be closed up again afterwards. */
        const side = party.toShip.isPlayer ? 'enemy' : 'player';
        if (party.recall) party.entryDoor.mode = 'open';
        else party.entryDoor.hackOpen(side, 2.4);
        party.entryDoor.openness = 1;
        party.entryDoor.open = true;
        if (party.recall) {
          // Your own airlock — just cycled open for re-entry, not smashed.
          UI.notify('Boarding party cycling back aboard…', 'good');
        } else {
          Camera.shake?.(4);
          UI.notify(party.toShip.isPlayer
            ? '⚠ ENEMY BOARDERS HACKED OUR AIRLOCK!'
            : '⚔ AIRLOCK HACKED — BOARDERS ARE IN!', 'alert');
          Audio.sfx.bossWarning?.();
        }
      }
    }

    party.members = party.members.filter(m =>
      m.phase !== 'cancelled' && m.phase !== 'inside');
    return party.members.length === 0;   // true → party done
  }

  /* ══ SALVAGE — CUTTING THE WRECKAGE OPEN (update93b) ══════════
   *
   * The player's idea, 02.10: "po zniszczeniu statku wroga nie otwiera
   * się cargo, a pojawiają się szczątki, które trzeba przeszukać albo
   * skrzynie załogantem — załogant wylatuje na zewnątrz, lutuje,
   * otwiera się cargo i przerzucasz, co jest, i wracasz do statku; jak
   * więcej rzeczy do zlutowania, więcej wypraw".
   *
   * ONLY after a hull is DESTROYED. A crew beaten to the last man still
   * leaves a whole hulk to walk through, and that has its own loot.
   *
   * The pieces, all of them already in the game:
   *   · the man walks to our facing airlock and steps out — the boarding
   *     pod's muster and its speed;
   *   · out there he breathes off his OWN suit (SUIT_AIR — eight seconds
   *     for most, twenty-six for a Pegasus) and only when it is dry does
   *     the void bite, gently (the boarding flight's 2.2 HP/s) — so a man
   *     out to the near crate and back loses a little, and a Pegasus can
   *     take two in one trip and come home whole;
   *   · a crate is a CargoGrid, and opening one is the two-hold loot
   *     screen every wreck already uses.
   *
   * He is OFF the ship while he is out — in no crew list but this one —
   * and a ship that jumps leaves him there. So does a crew with an
   * empty roster: he is counted, he is on the roster down the left,
   * and he can be clicked out in the black to be sent on to the next.
   */
  const SALVAGE = {
    SPEED:        85,     // px/s — the boarding pod's
    CUT_SECONDS:  2.5,    // the player: "2–3 s"
    VOID_DPS:     2.2,    // once the suit is dry — the boarding flight's void
    EMPTY_CHANCE: 0.2,    // "niektóre skrzynie mogą być puste"
    MAX_CRATES:   4,
    /* HER MEDICINE CHEST MOSTLY BURNS WITH HER (update97). jj: medicine
       turned up too often and in too great a quantity — every hull blown
       up spilled its whole chest, two to four full boxes. Now half the
       time one box survives, with a few doses in it. */
    MED_SURVIVE:  0.5,
    MED_DOSES:    [1, 3],
  };
  /* The wreckage lives on CombatManager (`.salvage`) — it is the fight's
     aftermath, and it is what a test or a debugging eye can reach. */
  // { crates: [], men: [] } — only in a won fight over a destroyed hull.
  // ONE place: CombatManager.salvage, which `begin()` clears with the rest of a fight.
  function _setSalvage(v) {
    CombatManager.salvage = v;
    return v;
  }
  let _leaveWarnT = 0;      // seconds a "they will be left behind" warning stays armed

  /** How much of a ship she was: the bigger, the more crates and the better
   *  what is in them. Hull, a second gun, a commander aboard. */
  function _salvageClass(e) {
    if (!e) return 0;
    const guns = (e.weapons ?? []).filter(Boolean).length;
    return Math.min(3, Math.floor((e.hullMax ?? 12) / 10)) + (guns >= 2 ? 1 : 0) + (e.commander ? 1 : 0);
  }

  /** Will this win leave crates in the void? The same test `_spawnSalvage`
   *  opens with — a destroyed hull, not a boss, not a derelict. */
  function _salvageWillSpawn() {
    const e = _enemyShip;
    // A hold already searched leaves no crates (update105): one door or the other.
    return !!e && !BossManager.isActive && !e.isDerelict && !e._searched && (e.destroyed || e.hull <= 0);
  }

  /* SCATTERED, NOT IN A ROW (update107, jj). The crates sat in a neat
     line through the middle of the hull. A blast throws them: anywhere in
     a field a good way wider and taller than the wreck, never two on top
     of each other, and never under the HUD at the top or the bar below. */
  const SALVAGE_SPREAD = { padX: 0.25, padY: 0.6, minGap: 70, top: 120, bottom: 455, side: 24 };   // bottom: above the log window
  function _salvageSpot(b, taken) {
    const S = SALVAGE_SPREAD, W = Renderer.getWidth?.() ?? 1280;
    const x0 = Math.max(S.side, b.x - b.w * S.padX), x1 = Math.min(W - S.side, b.x + b.w * (1 + S.padX));
    const y0 = Math.max(S.top, b.y - b.h * S.padY), y1 = Math.min(S.bottom, b.y + b.h * (1 + S.padY));
    let best = null, bestD = -1;
    for (let k = 0; k < 24; k++) {
      const p = { x: Utils.randFloat(x0, x1), y: Utils.randFloat(y0, y1) };
      const d = taken.length ? Math.min(...taken.map(t => Math.hypot(t.x - p.x, t.y - p.y))) : Infinity;
      if (d >= S.minGap) return p;
      if (d > bestD) { bestD = d; best = p; }
    }
    return best;
  }

  function _spawnSalvage() {
    const e = _enemyShip;
    if (!e || BossManager.isActive || e.isDerelict || e._searched) return null;
    const sector = Save.getRun()?.sector ?? 1;
    const big = _salvageClass(e);
    const n = Utils.clamp(Utils.randIn(1, 1 + big), 1, SALVAGE.MAX_CRATES);
    const b = e.roomBounds ? e.roomBounds() : { x: e.worldX, y: e.worldY, w: 300, h: 160 };
    const crates = [];
    for (let i = 0; i < n; i++) {
      const empty = Math.random() < SALVAGE.EMPTY_CHANCE;
      const grid = empty ? null : makeWreckGrid(sector + Math.floor(big / 2), {
        cols: 3, rows: 3, tries: Utils.randIn(1, 2 + big), noTablet: true,
      });
      crates.push({
        id: `sc${i}`, ..._salvageSpot(b, crates),
        grid, state: 'sealed', cutT: 0, by: null, phase: Utils.randFloat(0, 6),
      });
    }
    /* A TABLET, SOMETIMES (update99, jj 06.10) — once per hull, not once
       per crate, at the REAL sector's level (1 → I, 2 → I-II, 3 → III). */
    if (typeof Chips !== 'undefined' && Math.random() < Chips.DROP.salvage) {
      const full = crates.filter(c => c.grid);
      const key = Chips.rollDrop(sector);
      const home = full.find(c => c.grid.add(key));
      if (!home) {
        const k = crates.find(c => !c.grid) ?? crates[0];
        k.grid = k.grid ?? new CargoGrid(3, 3);
        k.grid.add(key);
      }
    }
    /* WHAT SHE WAS CARRYING DRIFTS OUT TOO, into crates that hold
       something already (an empty one stays empty) — all of it but the
       medicine chest, which mostly goes up with her (update97). */
    const items = e.cargo?.items ?? [];
    items.filter(it => it.def?.kind !== 'heal').forEach(it => {
      const full = crates.filter(c => c.grid);
      if (!full.length) return;
      Utils.pick(full).grid.add(it.defKey, it.meta ?? null, it.qty ?? null);
    });
    const doses = items.filter(it => it.def?.kind === 'heal').reduce((a, it) => a + (it.qty ?? 1), 0);
    if (doses > 0 && Math.random() < SALVAGE.MED_SURVIVE) {
      const full = crates.filter(c => c.grid);
      if (full.length) {
        Utils.pick(full).grid.add('medkit', null,
          Math.min(doses, Utils.randIn(SALVAGE.MED_DOSES[0], SALVAGE.MED_DOSES[1])));
      }
    }
    /* HER GUN IS IN THE WRECKAGE, NOT ON OUR MOUNT (update97). jj: the
       gun used to bolt itself onto our ship the moment she blew. Now
       everything a destroyed hull gives is in the crates, the gun too —
       somebody has to go out and cut it free. `_onWin` leaves it alone
       when there is wreckage to put it in. */
    const gun = CombatManager.weaponDrop;
    if (gun) {
      CombatManager.weaponDrop = null;
      const box = (typeof cargoCrateForWeapon === 'function') ? cargoCrateForWeapon(gun) : null;
      let placed = false;
      if (box) {
        for (const k of Utils.shuffle ? Utils.shuffle(crates.slice()) : crates) {
          if (k.grid && k.grid.add(box, gun)) { placed = true; break; }
        }
        if (!placed) {
          const k = crates.find(c => !c.grid) ?? crates[0];
          k.grid = k.grid ?? new CargoGrid(3, 3);
          if (!k.grid.add(box, gun)) {
            const grid = new CargoGrid(3, 3);
            grid.add(box, gun);
            crates.push({ ...k, id: `sc${crates.length}`, ..._salvageSpot(e.roomBounds ? e.roomBounds() : { x: e.worldX, y: e.worldY, w: 300, h: 160 }, crates), grid, phase: 0 });
          }
        }
      }
    }
    _setSalvage({ crates, men: [] });
    const nc = crates.length;
    UI.notify(`Wreckage: ${nc} crate${nc > 1 ? 's' : ''} drifting — select a crewman and click a crate to cut it open.`, 'good');
    return CombatManager.salvage;
  }

  function _salvageCrateAt(mx, my) {
    if (!CombatManager.salvage) return null;
    return CombatManager.salvage.crates.find(k => k.state !== 'taken' && Math.abs(mx - k.x) <= 14 && Math.abs(my - k.y) <= 12) ?? null;
  }

  /** Our hatch facing the wreck. */
  function _salvageHatch() {
    if (!_playerShip) return null;
    return _playerShip.doors.filter(d => d.isAirlock).sort((a, b) => b.x - a.x)[0] ?? null;
  }

  /** Why this man cannot be sent to this crate — or null. */
  function _salvageRefusal(c, crate) {
    if (!crate || crate.state === 'taken') return 'nothing left there';
    if (!c || !c.alive || c.isPet || !c.isPlayer) return 'select a crewman to send';
    const out = CombatManager.salvage?.men.find(m => m.c === c);
    if (!out && !_playerShip.crew.includes(c)) return `${c.name} is not aboard`;
    if (crate.by && crate.by !== c) return `${crate.by.name} is already on it`;
    if (!out && !_salvageHatch()) return 'no airlock on this hull';
    return null;
  }

  /** Send the first selected man to a crate — or, if he is already out
   *  there, add it to his round (a Pegasus can do two on one tank). */
  function _orderSalvage(crate) {
    const sel = UI.getSelectedCrewAll().filter(c => c && c.alive && c.isPlayer && !c.isPet);
    const c = sel[0] ?? null;
    const why = _salvageRefusal(c, crate);
    if (why) { UI.notify(`Salvage — ${why}.`, 'warn'); return false; }
    crate.by = c;
    const m = CombatManager.salvage.men.find(x => x.c === c);
    if (m) {
      if (!m.queue.includes(crate.id)) m.queue.push(crate.id);
      if (m.phase === 'home') m.phase = 'fly';
      UI.notify(`${c.name} will take that one too.`, 'info');
      return true;
    }
    const hatch = _salvageHatch();
    _playerShip.elevators?.release?.(c);
    c._waypoints = []; c.task = TASK.IDLE; c.carrying = null;
    c.moveToOnShip(_playerShip, hatch.x - 10, hatch.y);
    CombatManager.salvage.men.push({ c, phase: 'muster', queue: [crate.id], x: c.x, y: c.y, t: 0, hatch });
    UI.notify(`${c.name} is suiting up for the wreckage.`, 'good');
    return true;
  }

  function _crateById(id) { return CombatManager.salvage?.crates.find(k => k.id === id) ?? null; }

  function _salvageRelease(m) {
    (m.queue ?? []).forEach(id => { const k = _crateById(id); if (k && k.by === m.c) k.by = null; });
    m.queue = [];
  }

  /** The cut is through: open it, or say it was empty. */
  function _openCrate(crate, m) {
    crate.by = null;
    if (!crate.grid || !crate.grid.items.length) {
      crate.state = 'taken';
      UI.notify(`${m.c.name}: empty — nothing in it but scorched plating.`, 'warn');
      return false;
    }
    crate.state = 'open';
    if (typeof LootScreen === 'undefined' || !_playerShip?.cargo) return false;
    _lootReturn = 'combat';
    if (CombatManager.salvage) CombatManager.salvage.openBy = m;
    LootScreen.openLoot(crate.grid, _playerShip.cargo, {
      title: 'SALVAGE',
      subtitle: `${m.c.name} has it open · take what fits · what you leave keeps drifting`,
      leftLabel: 'CRATE',
      doneLabel: 'DONE',
      intro: `${m.c.name} cut the crate open.`,
      /* HIS BOTTLE IS THE CLOCK (update107): what is left in his suit, read
         off the same air the void takes. At zero he has to let go. */
      seconds: Math.max(3, m.c.air ?? 0),
      timerLabel: `${m.c.name.toUpperCase()}'S SUIT AIR`,
      timeoutText: `${m.c.name} is out of air — he lets go of the crate!`,
      onUnpack: _unpackCargo,
      onClose: () => {
        if (CombatManager.salvage) CombatManager.salvage.openBy = null;
        if (!crate.grid.items.length) crate.state = 'taken';
        STATE = 'combat';
      },
    });
    STATE = 'loot';
    return true;
  }

  /** A man outside: his suit first, then the void, gently. True when he
   *  is lost (update107: one body of code, the loot window runs it too). */
  function _salvageBreathe(m, dt) {
    const c = m.c;
    const max = c.airMax ? c.airMax() : 0;
    c.air = Math.max(0, (c.air ?? max) - dt);
    if (c.air <= 0) c.takeDamage(SALVAGE.VOID_DPS * dt, 'the void');
    if (c.dead || c.dying || c.down) {
      if (!c.dead) c.killOutright('the void');
      _salvageRelease(m); m.phase = 'lost';
      UI.notify(`${c.name} was lost in the wreckage…`, 'alert');
      return true;
    }
    return false;
  }

  /* THE SUIT DOES NOT STOP FOR THE CRATE (update107, jj). Sorting a crate
     open in the void used to freeze the clock — the window is a modal, and
     the fight's update stood still behind it. Everybody outside keeps
     breathing his bottle while the player picks, so the picking is fast.
     If the man at the open crate is lost, the window shuts. */
  function _salvageLootTick(dt) {
    const S = CombatManager.salvage;
    if (!S) return;
    for (const m of S.men) {
      if (['muster', 'gone', 'lost', 'aboard'].includes(m.phase)) continue;
      if (_salvageBreathe(m, dt) && S.openBy === m && LootScreen.isOpen()) {
        S.openBy = null;
        LootScreen.forceClose?.();
      }
    }
  }

  function _updateSalvage(dt) {
    if (!CombatManager.salvage) return;
    const speed = SALVAGE.SPEED;
    const step = (m, tx, ty) => {
      const dx = tx - m.x, dy = ty - m.y, d = Math.hypot(dx, dy);
      /* HE FACES THE WAY HE FLIES (update127, jj: "animacja załoganta w
         powrotnym locie od skrzyni jest w złym kierunku"). The suit kept
         the facing it had on the way out, so the trip home was flown
         backwards. */
      if (Math.abs(dx) > 1 && m.c) m.c._facing = dx > 0 ? 1 : -1;
      if (d <= Math.max(4, speed * dt)) { m.x = tx; m.y = ty; return true; }
      m.x += dx / d * speed * dt; m.y += dy / d * speed * dt;
      return false;
    };
    for (const m of CombatManager.salvage.men) {
      const c = m.c;
      m.t += dt;
      if (m.phase === 'muster') {
        if (!c.alive) { _salvageRelease(m); m.phase = 'gone'; continue; }
        if (Utils.dist(c.x, c.y, m.hatch.x, m.hatch.y) < 24) {
          _playerShip.crew = _playerShip.crew.filter(k => k !== c);
          c._waypoints = []; c.task = TASK.IDLE; c.roomId = null; c.inRoom = false;
          m.x = c.x = m.hatch.x; m.y = c.y = m.hatch.y;
          m.phase = 'fly';
          Audio.sfx.uiClick?.();
        } else if (m.t > 15) {
          _salvageRelease(m); m.phase = 'gone';
          UI.notify(`${c.name} could not reach the airlock.`, 'warn');
        }
        continue;
      }
      if (m.phase === 'gone' || m.phase === 'lost' || m.phase === 'aboard') continue;

      if (_salvageBreathe(m, dt)) continue;

      if (m.phase === 'fly') {
        const k = _crateById(m.queue[0]);
        if (!k || k.state === 'taken') { m.queue.shift(); if (!m.queue.length) m.phase = 'home'; }
        else if (step(m, k.x, k.y - 4)) m.phase = k.state === 'sealed' ? 'cut' : 'open';
      } else if (m.phase === 'cut') {
        const k = _crateById(m.queue[0]);
        if (!k) { m.phase = 'fly'; }
        else {
          k.cutT += dt;
          m._sparkT = (m._sparkT ?? 0) + dt;
          if (m._sparkT > 0.2) { m._sparkT = 0; Particles.repairSparks?.(k.x, k.y); }
          if (k.cutT >= SALVAGE.CUT_SECONDS) m.phase = 'open';
        }
      }
      if (m.phase === 'open') {
        const k = _crateById(m.queue.shift());
        m.phase = m.queue.length ? 'fly' : 'home';
        if (k) _openCrate(k, m);
      } else if (m.phase === 'home') {
        if (step(m, m.hatch.x + 14, m.hatch.y)) {
          const room = _playerShip.getRoomById(m.hatch.roomA) ?? _playerShip.rooms[0];
          c.x = room.cx; c.y = _playerShip.floorWalkY(room.floor, room.cy);
          c.roomId = room.id; c.inRoom = true; c.homeRoomId = c.homeRoomId ?? room.id;
          c._waypoints = []; c.task = TASK.IDLE;
          _playerShip.addCrew(c, true);
          m.phase = 'aboard';
          UI.notify(`${c.name} is back aboard.`, 'good');
          continue;
        }
      }
      c.x = m.x; c.y = m.y + Math.sin(m.t * 3) * 2;
    }
    CombatManager.salvage.men = CombatManager.salvage.men.filter(m => !['gone', 'lost', 'aboard'].includes(m.phase));
  }

  /** Everybody of ours outside the hull right now: in the wreckage, in a
   *  boarding pod, or on the enemy's deck. */
  function _outsideCrew() {
    const out = [];
    (CombatManager.salvage?.men ?? []).forEach(m => { if (m.phase !== 'muster' && !m.c.dead) out.push(m.c); });
    (_boardingParty?.members ?? []).forEach(m => {
      if (m.phase !== 'muster' && m.phase !== 'cancelled' && !m.c.dead && !out.includes(m.c)) out.push(m.c);
    });
    (_enemyShip?.crew ?? []).forEach(c => {
      if (c.isPlayer && !c._survivor && !c.dead && !out.includes(c)) out.push(c);
    });
    return out;
  }

  /**
   * LEAVING WITH PEOPLE OUTSIDE (update93b). The player: "w każdej chwili
   * możesz odlecieć — jeżeli załogant nie jest w statku, a statek
   * odleci, tracimy załoganta". The first press says who will be left;
   * a second within a few seconds means it. Returns true when the jump
   * may go ahead.
   */
  function _leaveOutsideConfirmed() {
    const out = _outsideCrew();
    if (!out.length) return true;
    if (_leaveWarnT > 0) { _leaveWarnT = 0; return true; }
    _leaveWarnT = 4;
    UI.notify(`⚠ ${out.length === 1 ? out[0].name + ' is' : out.length + ' crew are'} still outside — `
            + 'JUMP again to leave them behind.', 'alert');
    return false;
  }

  /** Everybody still outside is gone with the jump: dead to the roster,
   *  on the memorial, never recovered. */
  function _abandonOutside(why = 'left behind') {
    const out = _outsideCrew();
    out.forEach(c => {
      if (_enemyShip) _enemyShip.crew = _enemyShip.crew.filter(k => k !== c);
      if (!c.dead) c.killOutright(why);
    });
    if (_boardingParty) _boardingParty.members = _boardingParty.members.filter(m => m.phase === 'muster');
    if (CombatManager.salvage) CombatManager.salvage.men = CombatManager.salvage.men.filter(m => m.phase === 'muster');
    if (out.length) {
      UI.notify(out.length === 1 ? `${out[0].name} was ${why}.` : `${out.length} crew were ${why}.`, 'alert');
    }
    return out.length;
  }

  /** The spool takes nine seconds — time to RECALL them, said once. */
  function _warnOutsideOnRetreat() {
    const out = _outsideCrew();
    if (!out.length) return;
    UI.notify(`⚠ ${out.length === 1 ? out[0].name + ' is' : out.length + ' crew are'} outside — `
            + 'RECALL them before the jump, or they are left behind.', 'alert');
  }

  function _drawSalvage(ctx) {
    if (!CombatManager.salvage) return;
    const t = (_prevTime ?? 0) / 1000;
    const sel = UI.getSelectedCrewAll?.() ?? [];
    CombatManager.salvage.crates.forEach(k => {
      if (k.state === 'taken') return;
      const y = k.y + Math.sin(t * 1.3 + k.phase) * 2;
      const hot = Math.abs(Input.mouse.x - k.x) <= 14 && Math.abs(Input.mouse.y - k.y) <= 12;
      ctx.save();
      ctx.translate(k.x, y);
      ctx.rotate(Math.sin(t * 0.7 + k.phase) * 0.12);
      ctx.fillStyle = k.state === 'open' ? '#2a3a2e' : '#3a3f4c';
      ctx.fillRect(-11, -8, 22, 16);
      ctx.strokeStyle = hot ? '#ffd700' : (k.state === 'open' ? '#1aff8c' : '#8a94a8');
      ctx.lineWidth = hot ? 2 : 1;
      ctx.strokeRect(-11, -8, 22, 16);
      // hazard stripes across the lid
      ctx.fillStyle = 'rgba(255,176,32,0.8)';
      for (let i = -9; i < 10; i += 6) ctx.fillRect(i, -8, 2, 4);
      ctx.restore();
      // cut progress / label
      if (k.cutT > 0 && k.state === 'sealed') {
        const p = Utils.clamp(k.cutT / SALVAGE.CUT_SECONDS, 0, 1);
        ctx.beginPath();
        ctx.arc(k.x, y, 15, -Math.PI / 2, -Math.PI / 2 + p * Math.PI * 2);
        ctx.strokeStyle = '#ffd700'; ctx.lineWidth = 3; ctx.stroke();
      }
      ctx.font = '8px Share Tech Mono, monospace';
      ctx.textAlign = 'center';
      ctx.fillStyle = k.state === 'open' ? '#1aff8c' : '#c8d8f0';
      ctx.fillText(k.state === 'open' ? 'OPEN' : k.by ? k.by.name.toUpperCase() : (hot && sel.length ? 'CUT [CLICK]' : 'SEALED'), k.x, y + 18);
    });
    CombatManager.salvage.men.forEach(m => {
      if (m.phase === 'muster') return;
      m.c.draw(ctx);
      // His bottle, over his head, always — it is the clock of the trip.
      const max = m.c.airMax ? m.c.airMax() : 0;
      if (max > 0) {
        const f = Utils.clamp((m.c.air ?? max) / max, 0, 1);
        ctx.fillStyle = 'rgba(13,17,32,0.85)';
        ctx.fillRect(m.c.x - 12, m.c.y - 30, 24, 4);
        ctx.fillStyle = f < 0.34 ? '#ff2d44' : '#4db8ff';
        ctx.fillRect(m.c.x - 12, m.c.y - 30, 24 * f, 4);
      }
    });
  }

  /** Draw crew in transit + the breach progress arc */
  function _drawParty(ctx, party) {
    party.members.forEach(m => {
      if (m.phase === 'muster' || m.phase === 'cancelled' || m.phase === 'inside') return;
      m.c.draw(ctx);
    });
    if (!party.doorBroken &&
        party.members.some(m => m.phase === 'wait')) {
      const p = Utils.clamp(party.breachT / party.breachNeed, 0, 1);
      ctx.beginPath();
      ctx.arc(party.entryDoor.x, party.entryDoor.y, 16,
              -Math.PI / 2, -Math.PI / 2 + p * Math.PI * 2);
      ctx.strokeStyle = '#ffd700';
      ctx.lineWidth = 3;
      ctx.stroke();
    }
  }

  function _partyArrive(party, targetShip, label) {
    const rooms = targetShip.rooms.filter(r => r.system);
    party.crew.forEach((c, i) => {
      const room = rooms.length ? rooms[(i + (targetShip.weaponRooms[0] ? 0 : 1)) % rooms.length]
                                : targetShip.rooms[0];
      const spot = targetShip.weaponRooms[0] && i === 0 ? targetShip.weaponRooms[0] : room;
      c.x = spot.cx + Utils.randFloat(-14, 14);
      c.y = spot.cy + spot.h * 0.15;
      c.roomId = spot.id;
      c.homeRoomId = spot.id;
      targetShip.addCrew(c);
    });
    UI.notify(label, 'alert');
    Audio.sfx.bossWarning?.();
  }

  /** Survivors head home the moment a fight ends any way at all */
  function _recoverBoarders(opts = {}) {
    /* opts.aboardLost / opts.flightLost (update93b): a reason, and the men
       on the enemy deck / in the pod are LOST for it instead of coming
       home — a hull blown up under them, or a jump that left them. */
    const lost = [];
    const lose = (c, why) => {
      if (!c || c.dead) return;
      c.killOutright(why);
      lost.push(c);
    };
    // Clear the parties FIRST so the update loop can't re-process them
    // this frame (that caused boarders to "fly out again" on victory).
    const party = _boardingParty;
    _boardingParty = null;
    /* THEIR BOARDERS FIGHT ON (update105, jj). When their hull goes, the
       men they already sent are not tidied away with it — update54 meant
       the battle to wait for them, and this sweep threw them out of the
       airlock the same moment. `keepIntruders`: the ones on our deck stay
       and fight, the ones between the hulls keep coming; only those
       still walking to THEIR airlock go down with their ship. */
    if (opts.keepIntruders && _enemyParty) {
      _enemyParty.members.forEach(m => {
        if (m.phase === 'muster') {
          m.phase = 'cancelled';
          if (!m.c.dead) m.c.killOutright('went down with their ship');
        }
      });
    } else {
      _enemyParty = null;
    }
    // A recall in progress had its own airlock cycled open (not
    // smashed) — reseal it since the flight is being cut short here.
    if (party && party.recall && party.doorBroken) party.entryDoor.mode = 'closed';

    const seen = new Set();
    // Anyone still in transit turns around and climbs back in.
    if (party) {
      party.members.forEach(m => {
        if (m.phase === 'cancelled' || m.c.dead) return;
        if (seen.has(m.c)) return;
        seen.add(m.c);
        // If they'd already boarded the enemy, pull them off it first.
        if (_enemyShip) _enemyShip.crew = _enemyShip.crew.filter(k => k !== m.c);
        const inPod = m.phase !== 'inside' && m.phase !== 'muster';
        if (inPod && opts.flightLost) { lose(m.c, opts.flightLost); return; }
        if (m.phase === 'inside' && opts.aboardLost) { lose(m.c, opts.aboardLost); return; }
        _returnBoarder(m.c);
      });
    }
    // Anyone who made it onto the enemy hull comes home too (the
    // fallen stay behind on the wreck).
    if (_enemyShip) {
      /* A SURVIVOR comes home only on somebody's shoulders (update90b);
         one nobody picked up is left on the hulk. Done before the party,
         while his bearer still has him. */
      _enemyShip.crew.filter(c => c._survivor).forEach(c => {
        const b = c.carriedBy;
        if (!c.dead && b && b.alive && b.isPlayer && b.carrying === c) _rescueSurvivor(c);
        else {
          _enemyShip.crew = _enemyShip.crew.filter(k => k !== c);
          if (!c.dead) UI.notify('The survivor was left on the wreck.', 'warn');
        }
      });
      _enemyShip.crew.filter(c => c.isPlayer).forEach(c => {
        _enemyShip.crew = _enemyShip.crew.filter(k => k !== c);
        if (seen.has(c)) return;      // already handled above
        seen.add(c);
        if (c.dead) return;
        if (opts.aboardLost) lose(c, opts.aboardLost);
        else _returnBoarder(c);
      });
    }
    if (lost.length) {
      const why = opts.aboardLost || opts.flightLost;
      UI.notify(lost.length === 1 ? `${lost[0].name} ${why}.` : `${lost.length} of our boarders ${why}.`, 'alert');
    }
    if (!opts.keepIntruders) _purgeIntruders();
  }

  /* THE ENEMY DOES NOT GET TO STAY (update42).
     `_recoverBoarders` pulled OUR people off the enemy hull but there
     was no mirror image: an enemy boarder still standing aboard your
     ship when the fight ended simply remained in `_playerShip.crew`
     forever. He got a roster row, he was selectable and orderable, he
     was counted at the docking bay and BANKED INTO YOUR BARRACKS, and
     he was written into the save. Whoever is left of the boarding party
     when their ship is gone goes out with it.
     An infestation is not touched by this, and does not need to be
     spared by name any more (update84): the rats and spiders are in
     `ship.pests`, not in the crew list this sweeps. */
  function _purgeIntruders() {
    if (!_playerShip) return;
    const intruders = _playerShip.crew.filter(c => !c.isPlayer);
    if (!intruders.length) return;
    const alive = intruders.filter(c => !c.dead && !c.dying).length;
    _playerShip.crew = _playerShip.crew.filter(c => c.isPlayer);
    intruders.forEach(c => {
      if (c.carriedBy) c.carriedBy.carrying = null;
      if (c.carrying)  c.carrying.carriedBy = null;
      _playerShip.elevators?.release?.(c);
    });
    _playerShip.crew.forEach(c => {
      if (intruders.includes(c.carrying)) c.carrying = null;
      if (intruders.some(i => i.id === c._rescueId)) c._rescueId = null;
    });
    if (alive) {
      UI.notify(alive === 1 ? 'The last boarder is thrown out of the airlock.'
                            : `${alive} enemy boarders are thrown out of the airlock.`, 'good');
    }
  }

  /* ══ THE SURVIVOR ON A WRECK (update90b) ═══════════════════
   * See wreck.js WRECK_SURVIVOR_SHARE. One of our boarders walking into
   * his compartment with free hands lifts him; carried into the
   * compartment we docked at, he is handed across to our ship — down,
   * bandaged, and on the roster, for our own people to take to the
   * medbay. While he is on somebody's shoulders the hulk is not done:
   * the player is not robbed of him by searching the last room first. */
  function _wreckDockRoomId() {
    if (!_enemyShip || !_playerShip) return null;
    const facingRight = _playerShip.worldX < _enemyShip.worldX;
    const door = _enemyShip.doors.filter(d => d.isAirlock)
      .sort((a, b) => facingRight ? a.x - b.x : b.x - a.x)[0];
    return door ? door.roomA : null;
  }

  function _survivorCarried() {
    return !!_enemyShip?.crew.some(c => c._survivor && !c.dead && c.carriedBy);
  }

  function _survivorTick() {
    const s = _enemyShip.crew.find(c => c._survivor && !c.dead);
    if (!s) return;
    const b = s.carriedBy;
    if (!b) {
      const bearer = _enemyShip.crew.find(c => c.isPlayer && c.alive && !c._survivor &&
        !c.isPet && !c.carrying && !c._ridingShaft && c.roomId === s.roomId && c.inRoom !== false);
      if (!bearer) return;
      s.carriedBy = bearer; bearer.carrying = s;
      UI.notify(`${bearer.name} has a SURVIVOR on his shoulders — carry him to the hatch you came in by.`, 'good');
      return;
    }
    if (!b.alive || b.carrying !== s || !_enemyShip.crew.includes(b)) {
      if (b.carrying === s) b.carrying = null;
      s.carriedBy = null;
      return;
    }
    s.x = b.x; s.y = b.y - 10; s.roomId = b.roomId;
    if (b.roomId && b.roomId === _enemyShip.dockRoomId) _rescueSurvivor(s);
  }

  function _rescueSurvivor(s) {
    const b = s.carriedBy;
    if (b && b.carrying === s) b.carrying = null;
    s.carriedBy = null;
    _enemyShip.crew = _enemyShip.crew.filter(k => k !== s);
    // Our hatch facing the hulk.
    const facingRight = _playerShip.worldX < _enemyShip.worldX;
    const door = _playerShip.doors.filter(d => d.isAirlock)
      .sort((a, c) => facingRight ? c.x - a.x : a.x - c.x)[0];
    const room = (door && _playerShip.getRoomById(door.roomA)) || _playerShip.rooms[0];
    s._survivor = false;
    s.roomId = room.id; s.homeRoomId = room.id; s.inRoom = true;
    s.x = room.cx + Utils.randFloat(-12, 12);
    s.y = _playerShip.floorWalkY(room.floor, room.cy);
    s._waypoints = [];
    _playerShip.addCrew(s, true);
    const spec = Object.entries(s.skills ?? {}).find(([, v]) => v.level >= MAX_SKILL_LEVEL);
    const label = spec ? (SKILL_DEFS[spec[0]]?.label ?? spec[0]) : 'a';
    UI.notify(`${s.name} is aboard — a ${label} specialist. Get them to the medbay.`, 'good');
  }

  function _returnBoarder(c) {
    const room = _playerShip.getRoomById(_playerShip.getSystem('medbay')?.roomId)
              ?? _playerShip.rooms[0];
    c.x = room.cx + Utils.randFloat(-16, 16);
    c.y = room.cy + 8;
    c.roomId = room.id; c.homeRoomId = room.id;
    c._waypoints = []; c.task = TASK.IDLE;
    c._ordered = false; c.carrying = null; c.carriedBy = null;
    // Whatever cabin they were flagged into before they left, they are
    // out of it now — including a shaft on the ENEMY hull.
    _playerShip.elevators?.release?.(c);
    _enemyShip?.elevators?.release?.(c);
    c._ridingShaft = null; c._elevatorArrived = false;
    c._pathRetryCd = 0;
    _playerShip.addCrew(c);
    UI.notify(`${c.name} is back aboard.`, 'good');
  }

  /** Every living crew member LOYAL to the player, wherever they are:
   *  aboard our ship, mid-flight in a boarding pod, or fighting on the
   *  enemy hull. Used so a full-crew boarding action doesn't read as
   *  "everyone died" and end the game. */
  /**
   * EVERY LIVING SOUL LOYAL TO THEM, WHEREVER THEY ARE (update55).
   *
   * The mirror image of `_playerCrewAliveCount`, and it exists for the
   * same reason. "Their crew is wiped out" was asked as
   * `_enemyShip.crew.filter(...).length === 0` in two places, and that
   * is only true of the men standing on THEIR deck — so the moment
   * their boarding party stepped out of the airlock (which removes them
   * from `fromShip.crew` and does not add them to ours until they
   * arrive) their hull read as empty, the DERELICT HULK offer came up,
   * and the battle was over while an axe party was drifting across the
   * gap towards us.
   *
   * Three places to look, exactly like ours: their deck, the void, and
   * our deck.
   */
  /**
   * WHAT AN ENEMY COMMANDER IS WORTH (update63).
   *
   * ONE figure. Alive he pays this; dead his body pays half, and the
   * half is computed from this rather than written down beside it —
   * two hand-written prices for one man would drift apart the first
   * time either was balanced, and the player would learn that the
   * numbers on the two buttons cannot be trusted against each other.
   *
   * Rank is what it keys off, because rank is what he already has:
   * a Master Lord is a name worth carrying home, a Recruit is not.
   */
  function _commanderBounty(cap) {
    if (!cap) return 0;
    /* A MAN ON THE LIST IS WORTH WHAT THE LIST SAYS (update64), not
       what this formula would make of his rank. The poster is the
       price — computing a second figure here would put one number on
       the wanted board in the base and a different one on the button
       in the fight. */
    if (cap.bounty > 0) return Math.round(cap.bounty);
    const sector = Save.getRun()?.sector ?? 1;
    const rank   = Math.max(1, cap.level ?? 1);
    return Math.round(40 + rank * 12 + sector * 10);
  }

  /** Take the enemy commander into the brig, or say why not. */
  function _lockUpCommander() {
    const cap = (typeof Commander !== 'undefined') ? Commander.enemy() : null;
    if (!cap || !_playerShip) return false;
    const ok = _playerShip.takePrisoner({
      id: cap.id, name: cap.name, bounty: _commanderBounty(cap),
      wantedId: cap.wantedId ?? null,
    });
    UI.notify(ok
      ? `${cap.name} is in a cell. Keep the carbonite bay powered.`
      : `No free cell — ${cap.name} walks.`, ok ? 'good' : 'warn');
    return ok;
  }

  /**
   * The wreck of a wanted man leaves something to collect (update68).
   *
   * Shares `_bagCommander` with the "finish him in his cockpit" door,
   * so one man is worth one figure however he died — a second price
   * for a body blown up rather than shot down is exactly the drift
   * this project keeps deleting.
   */
  function _bagWantedCommander() {
    const cap = (typeof Commander !== 'undefined') ? Commander.enemy() : null;
    if (!cap || !cap.wantedId) return false;
    return _bagCommander();
  }

  /** Bag his body for the bounty office, if the hold has two cells. */
  function _bagCommander() {
    const cap = (typeof Commander !== 'undefined') ? Commander.enemy() : null;
    const hold = _playerShip?.cargo;
    if (!cap || !hold) return false;
    const ok = !!hold.add('body_bag',
      { name: cap.name, bounty: Math.round(_commanderBounty(cap) / 2),
        wantedId: cap.wantedId ?? null });
    UI.notify(ok
      ? `${cap.name}'s body is in the hold — two cells, and the yard pays for it.`
      : `No room in the hold for ${cap.name}'s body. It stays out there.`,
      ok ? 'good' : 'warn');
    return ok;
  }

  /**
   * Turn a rolled commander into a wanted man, sometimes.
   *
   * Returns the commander to seat — the same object, restamped, so
   * there is never a second record of him anywhere. His LEVEL and his
   * BOUNTY come off the list; the chips and picks the roll already
   * gave him stay, because those are the fight, not the identity.
   */
  /** The poster pinned to the node we are standing on, or null. */
  function _wantedOnThisNode() {
    const id = _sectorMap?.current?.()?.wantedId;
    return (id && typeof Save !== 'undefined' && Save.wantedById)
      ? Save.wantedById(id) : null;
  }

  function _seatWantedPirate(cap, sector) {
    if (!cap || typeof Save === 'undefined' || !Save.wantedById) return cap;
    /* ── THE NODE DECIDES, NOT A ROLL (update66) ──────────
     *
     * This used to roll 35% at the start of every fight, which made
     * the wanted list a lottery: the player found out who he had run
     * into once the shooting had started, and could not go looking for
     * anybody. The poster is pinned to a MAP NODE now, so the answer
     * to "is this his fight" is already on the map the player scanned
     * — and it is asked in exactly one place.
     *
     * A poster that has been handed in since the map was drawn simply
     * is not on the board any more, and `wantedById` says so.
     */
    const w = _wantedOnThisNode();
    if (!w) return cap;
    /* HIS RANK IS THE POSTER'S RANK. A commander rolled for the sector
       would throw away the levels an escape bought him — and the board
       would promise a harder man than the fight delivers. */
    if (w.level > (cap.level ?? 1) && Commander.rollEnemy) {
      cap = Commander.rollEnemy(sector, { level: w.level, race: w.race,
                                          chips: 1 + (w.escapes ?? 0) });
    }
    cap.name     = w.name;
    cap.race     = w.race || cap.race;
    cap.wantedId = w.id;
    cap.bounty   = w.bounty;
    Save.markSighted(w.id);
    UI.notify((w.escapes > 0
      ? `WANTED: ${w.name} — and he has slipped a brig before. `
        + `Better ship, better crew, ${w.bounty} CC.`
      : `WANTED: ${w.name} — the yard pays ${w.bounty} CC for him alive.`), 'alert');
    return cap;
  }

  function _enemyCrewAliveCount() {
    /* ON HIS FEET, not merely breathing — `alive` is false for a man who
       has gone down, and that is deliberate: update42 fixed a soft-lock
       where the last defender going DOWN instead of dying meant the
       boarding action could never resolve. This function widens WHERE we
       look, never WHO counts. */
    /* A MAN IN THEIR OWN CELL IS NOT A DEFENDER (update72). Counting
       him would mean their decks are never "cleared", so the derelict
       branch — and the commander's surrender with it — could never
       fire on a hull that happened to be carrying prisoners. */
    let n = _enemyShip
      ? _enemyShip.crew.filter(c => !c.isPlayer && !c.isPrisoner && c.alive).length
      : 0;
    if (_enemyParty) {
      // 'muster' members are still standing on their own deck, counted above.
      n += _enemyParty.members.filter(m =>
        m.phase !== 'cancelled' && m.phase !== 'muster' &&
        m.c && m.c.alive).length;
    }
    if (_playerShip) {
      n += _playerShip.crew.filter(c =>
        !c.isPlayer && c.alive).length;
    }
    return n;
  }

  /* WHO ANSWERS FOR THE VOID. CombatManager decides when a battle is
     over, but the men crossing between the hulls are game.js's — so
     game.js hands it the counter, once, at load. Installed here rather
     than in init() so the rule holds in tests too, which never boot the
     whole game. */
  if (typeof CombatManager !== 'undefined') {
    CombatManager.inFlightIntruders = () => (_enemyParty
      ? _enemyParty.members.filter(m => m.phase !== 'cancelled' &&
                                        m.phase !== 'muster' &&
                                        m.c && m.c.alive).length
      : 0);
  }

  function _playerCrewAliveCount() {
    // Boarders and loose SPIDERS both live in _playerShip.crew — only
    // your own people count, or a ship full of spiders would read as
    // "still crewed" after they had killed everybody.
    let n = _playerShip
      ? _playerShip.crew.filter(c => c.isPlayer && !c.dead && !c.dying).length : 0;
    if (_boardingParty) {
      // 'muster' members are still counted in _playerShip.crew above;
      // only count boarders who have already LEFT the ship (fly/wait).
      n += _boardingParty.members.filter(m =>
        m.phase !== 'cancelled' && m.phase !== 'muster' &&
        !m.c.dead && !m.c.dying).length;
    }
    if (_enemyShip) {
      // A survivor on a wreck is not one of ours until he is aboard (update90b).
      n += _enemyShip.crew.filter(c =>
        c.isPlayer && !c._survivor && !c.dead && !c.dying).length;
    }
    // …and the men out in the wreckage (update93b).
    if (CombatManager.salvage) n += CombatManager.salvage.men.filter(m => m.phase !== 'muster' && !m.c.dead && !m.c.dying).length;
    return n;
  }

  /** Snapshot every living crew member's current room (FTL "save stations") */
  function _saveStations() {
    if (!_playerShip) return;
    if (_orderRefused('save')) return;
    _payOrder('save');
    _savedStations = new Map();
    _playerShip.crew.forEach(c => {
      if (!c.dead && c.roomId) _savedStations.set(c.id, c.roomId);
    });
    Audio.sfx.uiClick();
    UI.notify('Crew positions saved', 'good');
  }

  /** Send everyone back to their saved rooms (FTL "return to stations") */
  function _returnToStations() {
    if (!_playerShip) return;
    if (_orderRefused('return')) return;
    if (!_savedStations || !_savedStations.size) {
      UI.notify('No saved positions — use SAVE first', 'warn');
      return;
    }
    let sent = 0;
    /* Everyone returning to one room gets a DIFFERENT slot — console,
       then left, then right. This used to send every one of them to
       room.cx/room.cy, so three crew stacked on the exact same pixel;
       then it counted returnees per room, which still ignored anyone
       already standing in there who was NOT recalled. Group them by
       room and let the ship allocate. */
    const byRoom = new Map();
    _playerShip.crew.forEach(c => {
      if (c.dead || c.dying) return;
      const roomId = _savedStations.get(c.id);
      const room   = roomId ? _playerShip.getRoomById(roomId) : null;
      if (!room) return;
      if (!byRoom.has(room.id)) byRoom.set(room.id, { room, movers: [] });
      byRoom.get(room.id).movers.push(c);
    });
    byRoom.forEach(({ room, movers }) => {
      const picks = _playerShip.allocStationSlots(room, movers);
      movers.forEach((c, i) => {
        c.homeRoomId = room.id;          // idle logic keeps them there
        c.moveToOnShip(_playerShip, ..._playerShip.stationSlot(room, picks[i]));
        sent++;
      });
    });
    Audio.sfx.uiClick();
    if (sent) { _payOrder('return'); UI.notify('Crew returning to stations', 'info'); }
  }

  /** Handle clicks on the FTL-style bottom power bar (pips + weapons) */
  function _handlePowerBarClick() {
    if (!_playerShip) return false;
    const zones = Renderer.getPowerClickZones();
    const mx = Input.mouse.x, my = Input.mouse.y;
    // The log window's toggle (update88) — in a fight, where the window is.
    if (STATE === 'combat' && UI.logClick?.(mx, my)) return true;
    for (const z of zones) {
      if (!Utils.pointInRect(mx, my, z.x, z.y, z.w, z.h)) continue;
      if (z.specialOrder) { _giveOrder(z.specialOrder); return true; }
      if (z.tablet)       { _useTablet(z.tablet, STATE === 'combat' ? 'combat' : 'map'); return true; }
      if (z.bookOpen)     { if (_commander) { _B().open = true; Audio.sfx.uiClick?.(); } return true; }
      if (z.crewSave)   { _saveStations();     return true; }
      if (z.crewReturn) { _returnToStations(); return true; }
      if (z.doorsOpen)  { _setAllDoors(true);  return true; }
      if (z.doorsClose) { _setAllDoors(false); return true; }
      if (z.sysIndex !== undefined) {
        const sys = _playerShip.systems[z.sysIndex];
        if (!sys) return;
        // Clicking a lit pip removes power down to that pip;
        // clicking an unlit pip adds power up to that pip.
        const target = z.pip < sys.power ? z.pip : z.pip + 1;
        _playerShip.setPowerAt(z.sysIndex, target);
        return true;
      }
      if (z.weapon !== undefined) {
        const w = _playerShip.weapons[z.weapon];
        /* A CHARGING GUN CAN BE AIMED (update87). "Jak nie jest
           załadowana broń jeszcze, to i tak można zaznaczyć namierzenie;
           jak naładuje, to wystrzeli tam." Selecting needed `armed`; it
           needs only a gun that COULD fire once charged — the ammo and
           the fight are still checked (`aimRefusal`). */
        if (w && CombatManager.isActive()) {
          // An ARMED gun is selected as it always was — its refusals (an
          // empty rack) are said when it is told to shoot.
          const why = w.armed ? null : CombatManager.aimRefusal(w);
          if (why) { UI.notify(why, 'warn'); return true; }
          _selectedWeapon = (_selectedWeapon === w) ? null : w;
          Audio.sfx.uiClick();
          if (_selectedWeapon) UI.notify(w.armed
            ? `${w.label} — click enemy room to target`
            : `${w.label} is still charging — click enemy room; it fires there when ready`, 'info');
        }
        return true;
      }
      if (z.weaponAuto !== undefined) {
        const w = _playerShip.weapons[z.weaponAuto];
        if (w) {
          w.autoFire = !w.autoFire;
          Audio.sfx.uiClick();
          UI.notify(`${w.label}: AUTO ${w.autoFire ? 'ON' : 'OFF'}`, 'info');
        }
        return true;
      }
      if (z.sysActivateIndex !== undefined) {
        const sys = _playerShip.systems[z.sysActivateIndex];
        if (sys && sys.type === 'cloaking') _activateCloak(sys);
        return true;
      }
      // The reactor is a module too — its icon scrams the whole plant.
      if (z.reactorToggle !== undefined) {
        const r = _playerShip.reactor;
        r.offline = !r.offline;
        Audio.sfx.uiClick();
        UI.notify(r.offline ? 'REACTOR SCRAMMED — everything is dark'
                            : 'Reactor back online', r.offline ? 'alert' : 'good');
        return;
      }
      if (z.sysToggleIndex !== undefined) {
        const sys = _playerShip.systems[z.sysToggleIndex];
        if (sys) {
          if (sys.power > 0) {
            sys._prefPower = sys.power;   // remember for re-enable
            _playerShip.setPowerAt(z.sysToggleIndex, 0);
            UI.notify(`${sys.label} OFFLINE`, 'warn');
          } else {
            const want = sys._prefPower ?? sys.maxPower;
            _playerShip.setPowerAt(z.sysToggleIndex, want);
            UI.notify(`${sys.label} ONLINE`, 'good');
          }
        }
        return true;
      }
      if (z.crewIndex !== undefined) {
        // crewRef, not an index into _playerShip.crew — the roster now
        // spans both hulls while a boarding party is away (update42).
        const c = z.crewRef ?? _playerShip.crew[z.crewIndex];
        if (c) {
          const additive = Input.isHeld('ShiftLeft') || Input.isHeld('ShiftRight');
          const all = UI.getSelectedCrewAll();
          // Clicking the only selected member deselects; shift toggles
          if (!additive && all.length === 1 && all[0] === c) UI.deselectCrew();
          else UI.selectCrew(c, additive);
        }
        return true;
      }
    }
    return false;
  }

  function _travelTo(nodeId) {
    if (!_sectorMap) return;
    const wasPicking = _sectorMap.awaitingStartPick;
    // Every FTL jump burns 1 He2. Choosing the starting lane in sector 1
    // is not a jump, so it stays free.
    if (!wasPicking) {
      /* SAME QUESTION THE RETREAT ASKS (update68) — see `_jumpRefusal`.
         This used to test fuel and nothing else, so a hull with a shot
         out cockpit and nobody at the helm still jumped happily across
         the sector while the same hull could not run from a fight. */
      const why = _jumpRefusal();
      if (why) {
        /* SAY SO OUT LOUD (update42). This bounced straight into the
           beacon with no message at all, so the refusal was invisible
           and — because the beacon always handed over fuel — the jump
           read as if it had simply gone through. */
        UI.notify(why, 'alert');
        // Out of fuel is the one the beacon can answer; a dead cockpit
        // is the player's own repair job and no distress call fixes it.
        if (_fuelAboard() <= 0) _maybeSOS();
        return;
      }
    }
    if (!_sectorMap.travelTo(nodeId)) return;
    Audio.sfx.uiClick();
    const node = _sectorMap.getNode(nodeId);
    _sectorMap.unlockNext();

    if (!wasPicking) {
      // One cell out of the racks per jump — a real item leaving a real
      // shelf, not a counter going down.
      _burnFuel(1);
      const left = _fuelAboard();
      if (left <= 2) UI.notify(`He2 low: ${left} left`, left === 0 ? 'alert' : 'warn');
      // The jump, filmed (update118) — the outcome below happens at once.
      if (typeof JumpScene !== 'undefined') JumpScene.jump(_playerShip);
      // A jump is also when badly packed cargo bites: an uncooled core
      // spoils whatever is touching it.
      const spoiled = _playerShip?.cargo?.hazardTick?.() ?? [];
      spoiled.forEach(m => UI.notify(m, 'warn'));
      // …and when a full hold picks up passengers nobody invited.
      _rollForRats();
    }

    // Sector 1: this click CHOSE the starting lane — lock the other
    // two entry nodes and remember the lane for save/continue.
    if (wasPicking) {
      _sectorMap.startNodes.forEach(s => { if (s.id !== nodeId) s.locked = true; });
      Save.updateRun({ lane: node.row });
      UI.notify(`Starting lane locked in — ${SectorMap.laneName(node.row)}`, 'good');
      _saveShip();
      return;   // picking a lane is not a jump — no event fires
    }
    _saveShip();

    _playerShip.reactor.penalty = 0;   // any lingering nebula effect ends
    _nebulaCombat = false;

    const t = node.type;
    if (t === 'combat' || t === 'elite') {
      const diff = t === 'elite' ? 'hard' : 'normal';
      /* A NAME OFF THE BOARD MAY TALK FIRST (update70) — but only to a
         commander the honest ports already distrust. Asked before the
         extortion roll below: this is HIS node, and a random toll
         collector must not speak over him. */
      if (_maybeParley(diff)) return;
      // Sometimes the hostiles would rather extort than fight
      if (t === 'combat' && Math.random() < 0.45) _maybeNegotiate(diff, false);
      else _startCombat(diff, false, { canSurprise: true });
    } else if (t === 'nebula') {
      // Nebula: sometimes an ambush (fought at −2 power for BOTH sides),
      // sometimes a random event hidden in the clouds.
      if (Math.random() < 0.55) {
        if (Math.random() < 0.3) _maybeNegotiate('normal', true);
        else _startCombat('normal', true, { canSurprise: true });
      } else {
        _event = pickEventFor(_playerShip);
        STATE = 'event';
      }
    } else if (t === 'asteroids') {
      /* AN ASTEROID FIELD (update100): most of the time somebody is
         waiting in it and the fight is fought among the rocks; the rest
         of the time the field is crossed and nothing happens. */
      if (Math.random() < ASTEROID_FIGHT_ODDS) {
        _startCombat('normal', false, { canSurprise: true, asteroids: true });
      } else {
        UI.notify('The asteroid field is empty — the helm threads it without a scratch.', 'info');
      }
    } else if (t === 'store') {
      _station = new Station(Save.getRun()?.sector ?? 1, Date.now());
      _customs(_station);
      /* A PORT RESTS THE COMMANDER (update98): knowledge back to full. */
      if (_commander && typeof Commander !== 'undefined') {
        const got = Commander.refillKnowledge(_commander, 1);
        if (got > 0) UI.notify(`${_commander.name} rests in port — knowledge +${got}.`, 'good');
      }
      STATE = 'station'; _beginFade();
      /* THE PORT OPENS WHEN THE FILM IS OVER (update127, jj: "jak wchodzę
         do stacji i już w niej jestem, to dalej w tle pod spodem jest
         animacja lotu statku"). The shop is a DOM overlay; opened in the
         same frame as the jump it sat over the whole flight. */
      if (typeof JumpScene !== 'undefined' && JumpScene.active()) _stationOpenPending = true;
      else UI.openStation(_station, _playerShip);
    } else if (t === 'event' && node.event) {
      /* The node's event was chosen when the SECTOR was generated, and
         the ship changes during the run — a med-bay refit baked into
         column 4 is nonsense by the time you get there with the med bay
         shot off. Re-roll anything that no longer fits the hull. */
      _event = eventFits(node.event, _playerShip)
             ? node.event
             : (node.event = pickEventFor(_playerShip));
      STATE = 'event';
    } else if (t === 'exit') {
      // Exit lane carries over: top exit → top start of the next
      // sector, middle → middle, bottom → bottom.
      Save.updateRun({ lane: node.row });
      _nextSector();
    } else if (t === 'boss') {
      // Resume at the phase already reached — fleeing and coming back
      // does NOT reset Apophis to phase I.
      _enemyShip = BossManager.start(BossManager.phase, 850, 120);
      _playerShip.resetShieldDebt();   // update97: our bubble as we brought it
      _playerShip.weapons.forEach(w => { if (w) { w.charge = 0; w.armed = false; w.targetRoom = null; w.queuedShot = false; } });
      _playerShip.markCombatStart();
      _surrenderAsked = false;
      _derelictOffered = false;
      _noQuarterSaid   = false;
      STATE = 'combat'; _beginFade();
      _combatTimer = 0;
      _combatFired = false;
      CombatManager.begin(_playerShip, _enemyShip, 'boss');
      if (typeof JumpScene !== 'undefined') JumpScene.arrive(_playerShip, _enemyShip);   // update118
      Audio.resume(); Audio.playMusic('boss');
      UI.notify('WARNING: APOPHIS', 'alert');
    } else {
      UI.notify('Path clear.', 'info');
    }
  }

  // ── COMBAT ────────────────────────────────────────────────
  function _updateCombat(dt) {
    if (_bookKey()) return;
    if (_B().open) { _updateBook('combat'); return; }
    // The order clocks run on combat time, like everything else here.
    Commander?.tickOrders?.(dt);
    Chips?.tick?.(dt);              // …and the tablets in use (update99)
    if (!_playerShip || !_enemyShip) return;
    _playerShip.update(dt);
    _enemyShip.update(dt);

    // ── Boss phase machine — runs BEFORE CombatManager so a downed
    //    phase chains straight into the next one: no victory screen,
    //    no scrap payout, no jump prompt between phases. ──
    if (BossManager.isActive) {
      const bres = BossManager.update(dt);
      if (bres === 'next_phase') {
        CombatManager.end();
        _enemyShip = BossManager.nextPhase(850, 120);
        _combatTimer = 0; _combatFired = false;
        CombatManager.begin(_playerShip, _enemyShip, 'boss');
        UI.notify(`MOTHERSHIP — PHASE ${BossManager.phase + 1}/${BossManager.totalPhases}: "${BossManager.currentPhaseDef.taunt}"`, 'alert');
        Audio.sfx.bossWarning();
        return;
      }
      if (bres === 'defeated') {
        // Contract complete — fly home and dock. Fetch the boarding
        // party FIRST: docking banks _playerShip.crew, so anyone still
        // standing on the boss's hull was quietly deleted from the
        // barracks by winning the fight they had just won for you.
        // update93b: whoever is still ON her goes down with her, as on
        // any other hull; those between the hulls come home.
        _recoverBoarders({ aboardLost: 'went down with the enemy ship' });
        _finishContract();
        CombatManager.end();
        _enemyShip = null;
        return;
      }
    }

    CombatManager.update(dt);

    /* THEIR HULL JUST WENT (update54). The battle carries on while
       their boarders are still on our deck — see CombatManager — but
       OUR people have no business standing on a wreck while it happens,
       and they used to be pulled off at the victory screen, which no
       longer comes at the same moment. Emergency teleport now, once. */
    if (CombatManager.enemyDown && !CombatManager._downHandled) {
      CombatManager._downHandled = true;
      /* …and anybody of ours still ON her goes with her (update93b, the
         player: "tracimy załogantów, jeżeli statek przeciwnika zostanie
         zniszczony wraz z naszą załogą abordażową"). Those still in the
         pod, between the hulls, turn back. Theirs on OUR deck and in
         their pod stay in the fight (update105). */
      _recoverBoarders({ aboardLost: 'went down with the enemy ship', keepIntruders: true });
    }

    // Boarding parties: walk out → drift across → breach → storm in
    if (_boardingParty && _updateParty(_boardingParty, dt)) {
      // A recall trip re-seals your own airlock behind the returning
      // crew — it was only cycled open, never smashed (see _makeParty).
      if (_boardingParty.recall) _boardingParty.entryDoor.mode = 'closed';
      _boardingParty = null;
    }
    if (_enemyParty    && _updateParty(_enemyParty, dt))    _enemyParty = null;

    /* AN ESCAPED PRISONER RUNS FOR OUR SHIP (update107). He goes the way a
       recalled boarder goes — their airlock, the void, ours — and a party
       that times out at the hatch (a shut door, a fight on the way) is
       simply sent again. Once he is aboard he is crew like anybody else. */
    if (!_boardingParty && _enemyShip && !_enemyShip.destroyed && _enemyShip.hull > 0) {
      const run = _enemyShip.crew.filter(c => c._escapee && c.isPlayer && c.alive);
      if (run.length) _boardingParty = _makeParty(_enemyShip, _playerShip, run, { recall: true });
    }
    (_playerShip?.crew ?? []).forEach(c => { if (c._escapee) c._escapee = false; });

    /* `c.alive`, NOT `!c.dead` (update42).
       A crew member who has gone DOWN is hp 1, state 'injured' — he is
       not dead. So the last enemy going down instead of dying meant the
       boarding action could NEVER end: no derelict offer, no wreck
       clear, nothing to do but grind the hull to zero with the guns.
       `alive` is already the "still on his feet" test — it excludes the
       injured and the dying — and a fight is over when nobody is left
       standing, not when the last body stops twitching.

       A DERELICT we boarded: no dialog, no reward roll — the moment the
       hulk has been searched the hold is ours. */
    /* A HULK IS SEARCHED, NOT CLEARED (update84). This used to wait for
       every hostile on the hulk to be dead — spiders included. The
       spiders are in the ducts now and nobody in a boarding party can
       reach one, so that could never happen; the player's call is that
       the hold is yours once somebody has been into every compartment.
       The spiders' part is what they do to your people on the way
       round. `_enemyCrewAliveCount` below is a different question:
       "are their SOLDIERS finished", wherever they are standing. */
    if (_wreckMode && _enemyShip) _survivorTick();
    if (_wreckMode && !_wreckLooted && _enemyShip && _enemyShip.searchedAll() &&
        !_survivorCarried()) {
      _wreckCleared();
      return;
    }

    // derelict choice instead of grinding it down turret-by-turret.
    if (!_derelictOffered && !BossManager.isActive && _enemyShip &&
        !_enemyShip.destroyed && _enemyShip.hull > 0 &&
        (CombatManager.isActive() || CombatManager.state === COMBAT_STATE.RETREATING) &&
        _enemyCrewAliveCount() === 0) {
      _derelictOffered = true;
      /* ── THEIR DECKS ARE CLEARED. IS ANYONE LEFT TO STRIKE? (update62)
       *
       * This branch already owned the moment "the enemy crew is wiped
       * out" — it just assumed there was nobody left to talk to. There
       * often is: the enemy COMMANDER is a record, not a body, so he
       * survives his crew, and clearing their decks leaves him alone
       * with your boarding party. That is the moment the karma design
       * asks for, and it belongs HERE rather than in a second trigger
       * of its own — one situation, one place that decides it.
       *
       * The hulk offer is untouched for a ship that never had one.
       */
      const foeCap = (typeof Commander !== 'undefined') ? Commander.enemy() : null;
      const noQuarter = CombatManager.noQuarter?.() ?? false;
      if (foeCap && noQuarter && !_noQuarterSaid) {
        _noQuarterSaid = true;
        UI.notify(`${foeCap.name} would rather burn with his ship than be your prisoner.`, 'alert');
      }
      /* WHAT HE IS WORTH (update63). One figure, computed here, and
         both prices come off it: alive is the bounty, his body is
         half. Two numbers written separately would drift the first
         time either was balanced. */
      const bounty = _commanderBounty(foeCap);
      const cells  = _playerShip?.freeCells?.() ?? 0;
      const choices = [];
      /* ── ONLY A NAME OFF THE BOARD IS WORTH A CELL (update69) ──
       *
       * The offer was made after ordinary fights too, and the player
       * took it and felt he got nothing: "pokonałem przeciwnika
       * zwykłego… dałem tak ale nie dostałem, to powinno być chyba
       * tylko jak walka z piratem ściganym". He is right, and it is
       * the same rule the rest of update68 already follows — the yard
       * has an office for the men on the poster and nobody at all for
       * a nameless patrol captain. His body is worth nothing there,
       * his person is worth nothing there, and a cell spent on him is
       * a cell not spent on the man you are hunting.
       *
       * So: the brig door is offered for a WANTED commander. Everyone
       * else gets the two doors that were always there — let him go
       * for the karma, or finish him for the wreck.
       */
      if (foeCap && foeCap.wantedId && !noQuarter && cells > 0) {
        /* THE CELL DOOR. Only offered when there is somewhere to put
           him — an option that greys out with no reason on it is worse
           than an option that is not there, and the text below says
           what is missing when it is missing. */
        choices.push({
          label: `Take him prisoner — worth ${bounty} CC at the yard`,
          result: { searchDerelict: true, capture: true,
                    karma: Commander?.KARMA?.HELP_AT_COST ?? 5 },
        });
      }
      choices.push(
        /* SPARING HIM COSTS THE GUARANTEED CC — that is the price of
           the +5, and the reason this is a decision rather than a
           free good deed. */
        { label: 'Let him go — board it and cast off',
          result: { searchDerelict: true,
                    karma: Commander?.KARMA?.HELP_AT_COST ?? 5 } },
        { label: `Finish him off — his body is worth ${Math.round(bounty / 2)} CC`,
          result: { destroyDerelict: true, takeBody: true,
                    karma: Commander?.KARMA?.KILL_HELPLESS ?? -10 } });

      _event = (foeCap && !noQuarter) ? {
        title: 'Their Commander Strikes',
        text: `Nobody aboard is left standing. ${foeCap.name} puts down his sidearm `
            + 'and offers you his ship rather than his crew\'s bodies. '
            /* THE LINE MATCHES THE DOORS (update69). It used to promise
               a free cell to a player who was not being offered one,
               which is how "I said yes and got nothing" starts. */
            + (!foeCap.wantedId
                ? 'Nobody is paying for this one — he is not on any board.'
                : cells > 0
                  ? 'He is on the board, and you have a cell free.'
                  : 'He is on the board — and you have nowhere to put him. '
                  + 'A carbonite bay with a free cell would be worth having.'),
        choices,
      } : {
        title: 'Derelict Hulk',
        text: 'The enemy crew is wiped out, but their ship still drifts intact. Board it and take what your hold will carry — or just finish it off for CC?',
        choices: [
          { label: 'Board it — strip the hold yourself',
            result: { searchDerelict: true } },
          { label: 'Finish it off — guaranteed CC',
            result: { destroyDerelict: true } },
        ],
      };
      STATE = 'event';
      return;
    }

    // Badly damaged enemies sometimes beg for mercy, offering tribute
    if (CombatManager.surrenderOffer && !_surrenderAsked) {
      _surrenderAsked = true;
      CombatManager.surrenderOffer = false;
      const run    = Save.getRun();
      // (The Extortion chip's squeeze went with the chips — update99.)
      const scrap  = Math.round(Utils.randInt(20, 35 + (run?.sector ?? 1) * 5));
      const offers = [{ scrap }];
      // Sometimes they throw in their gun or a crew member
      const gun = _enemyShip.weapons.find(w => w);
      if (gun && Math.random() < 0.5)            offers[0].weaponReward = gun.defKey;
      else if (_playerShip.crew.length < 8 && Math.random() < 0.5) offers[0].crew = 1;
      const extras = offers[0].weaponReward ? `, their ${gun.label}`
                   : offers[0].crew         ? ', and a crew member defects to you'
                   : '';
      _event = {
        title: 'They Surrender!',
        text: `"Cease fire! Take it — just let us live." They offer ${scrap} CC${extras}.`,
        choices: [
          /* THE FORK THE PLAYER MEETS MOST OFTEN (update50). Taking
             the money and letting them live is mercy with a price on
             it; opening up on a ship that has already struck its
             colours is "świadome zabicie bezbronnych". */
          { label: 'Accept tribute — let them go',
            result: { ...offers[0], acceptSurrender: true,
                      karma: Commander?.KARMA?.HELP_AT_COST ?? 5 } },
          { label: 'No mercy — finish them',
            result: { resumeCombat: true,
                      karma: Commander?.KARMA?.KILL_HELPLESS ?? -10 } },
        ],
      };
      STATE = 'event';
      return;
    }

    /* ── TAB WALKS THE CREW LIST (update55) ──────────────────
       First press takes the man at the TOP of the roster; every press
       after that steps one down and wraps at the bottom. The list it
       walks is `Renderer.crewRoster` — the very list drawn down the left
       edge — so the highlight moves the way the player's eye does, and
       an away team at the bottom of the panel is reachable too.

       Only OUR people, and only those on their feet: a dead name on the
       roster is a name you cannot give an order to, and stepping onto it
       would make TAB feel broken.

       Selection is REPLACED, never added to, so TAB is always "who am I
       commanding now" and never a way to build a group by accident —
       shift-click is what builds groups. */
    if (Input.isPressed('Tab')) _cycleCrew();
    if (Input.isPressed('KeyL')) UI.toggleLog();      // the log window (update88)

    // Weapon hotkeys — select weapon (then click enemy room), double-tap = fire random
    ['Digit1','Digit2','Digit3','Digit4'].forEach((code, i) => {
      if (Input.isPressed(code)) {
        const w = _playerShip.weapons[i];
        /* A GUN THAT CANNOT BE SELECTED SAYS WHY (update59). Pressing
           the number of a gun that is not ready used to do NOTHING —
           no selection, no sound, no message — which is the same dead
           click as the empty rack, one step earlier. A Hull Cannon
           whose level-3 bay has been shot down to two power is exactly
           this case, and it looks identical to a bug from the outside. */
        // A charging gun is selectable too (update87) — see the click above.
        const aimWhy = (w && !w.armed) ? CombatManager.aimRefusal(w) : null;
        if (w && aimWhy) UI.notify(aimWhy, 'warn');
        if (w && !aimWhy && !w.armed) {
          _selectedWeapon = w;
          UI.notify(`${w.label} is still charging — click enemy room; it fires there when ready`, 'info');
        } else if (w && !aimWhy) {
          if (_selectedWeapon === w) {
            // Second press = fire at remembered room (or random if none)
            const t = w.targetRoom && _enemyShip && _enemyShip.rooms.includes(w.targetRoom)
              ? w.targetRoom : null;
            const why = CombatManager.playerFire(w, t);
            if (why) UI.notify(why, 'warn');
            _selectedWeapon = null;
          } else {
            _selectedWeapon = w;
            UI.notify(`${w.label} — click enemy room`, 'info');
          }
        }
      }
    });

    // Targeted fire: selected weapon + click on enemy room.
    // The room is REMEMBERED — subsequent shots hit the same module.
    if (_selectedWeapon && Input.mouse.leftPressed && _enemyShip) {
      const wx = Input.mouse.x, wy = Input.mouse.y;
      const room = _enemyShip.rooms.find(r => r.contains(wx, wy));
      if (room && !_selectedWeapon.armed) {
        // Charging: remember the room and fire the moment it is ready.
        _selectedWeapon.targetRoom = room;
        _selectedWeapon.queuedShot = true;
        UI.notify(`${_selectedWeapon.label} will fire at the ${room.system?.label ?? 'compartment'} when charged.`, 'info');
        _selectedWeapon = null;
      } else if (room) {
        _selectedWeapon.targetRoom = room;
        /* AND IT SAYS SO WHEN IT WILL NOT SHOOT (update59). This click
           used to be able to do NOTHING AT ALL, in silence: an out-of-
           ammo Hull Cannon sat armed and powered and simply ignored the
           order, fight after fight. The refusal comes back from
           playerFire and goes straight on screen. */
        const why = CombatManager.playerFire(_selectedWeapon, room);
        if (why) UI.notify(why, 'warn');
        _selectedWeapon = null;
      }
    }
    /* (The selection used to be dropped the moment a gun was not armed,
       which is what made a charging gun impossible to aim. It is dropped
       now only when the gun is gone — update87.) */
    if (_selectedWeapon && !_playerShip.weapons.includes(_selectedWeapon)) _selectedWeapon = null;

    /* THE QUEUED SHOT (update87): a gun aimed while charging fires at
       its room the moment it is armed — once. */
    _playerShip.weapons.forEach(w => {
      if (!w || !w.queuedShot || !w.armed) return;
      if (!CombatManager.isActive() || !_enemyShip) { w.queuedShot = false; return; }
      w.queuedShot = false;
      const target = w.targetRoom && _enemyShip.rooms.includes(w.targetRoom) ? w.targetRoom : null;
      const why = CombatManager.playerFire(w, target);
      if (why) UI.notify(why, 'warn');
    });

    // AUTO-fire: weapons with autoFire on shoot their remembered room when charged
    _playerShip.weapons.forEach(w => {
      if (!w || !w.autoFire || !w.armed) return;
      if (!CombatManager.isActive() || !_enemyShip) return;
      const target = w.targetRoom && _enemyShip.rooms.includes(w.targetRoom)
        ? w.targetRoom : null;
      const why = CombatManager.playerFire(w, target);
      /* AUTO fires sixty times a second, so the reason is said ONCE per
         gun until it changes — otherwise an empty rack would bury the
         log. Cleared the moment the gun can shoot again. */
      if (why) {
        if (w._lastRefusal !== why) { w._lastRefusal = why; UI.notify(why, 'warn'); }
      } else {
        w._lastRefusal = null;
      }
    });

    // BOARD button
    if (Input.mouse.leftPressed) {
      const bb = _boardRect();
      if (Utils.pointInRect(Input.mouse.x, Input.mouse.y, bb.x, bb.y, bb.w, bb.h)) {
        _launchBoarders();
      }
    }

    // RECALL button — bring selected boarders home
    if (Input.mouse.leftPressed) {
      const rc = _recallRect();
      if (Utils.pointInRect(Input.mouse.x, Input.mouse.y, rc.x, rc.y, rc.w, rc.h)) {
        _recallBoarders();
      }
    }

    // CLOAK hotkey. The button itself now lives ON the cloak module in
    // the bottom power bar (FTL style) — see _activateCloak / the
    // sysActivateIndex zone in renderer._drawPowerBar.
    if (Input.isPressed('KeyC')) {
      const cl = _playerShip?.getSystem('cloaking');
      if (cl) _activateCloak(cl);
    }

    // EJECT button — only drawn when there is a pod to fire.
    if (Input.mouse.leftPressed && _podSeconds() && !_evacRunning()) {
      const pb = _podRect();
      if (Utils.pointInRect(Input.mouse.x, Input.mouse.y, pb.x, pb.y, pb.w, pb.h)) {
        _pressConsumed = true;
        _startEvac();
      }
    }

    // Retreat button (power pips & buttons are handled in _crewMouseUpdate)
    if (Input.mouse.leftPressed) {
      const rb = _retreatRect();
      if (Utils.pointInRect(Input.mouse.x, Input.mouse.y, rb.x, rb.y, rb.w, rb.h)) {
        // BOARD / RECALL / RETREAT are UI buttons, not points in space.
        // Without this the SAME press also reached _crewClickResolve,
        // landed on no room, and cleared the selection — so pressing
        // BOARD dropped the very crew it had just sent.
        _pressConsumed = true;
        if (_canRetreat()) {
          CombatManager.initiateRetreat(1);
          UI.notify('FTL jump initiated…', 'warn');
          _warnOutsideOnRetreat();
        }
      }
    }
    if (Input.isPressed('KeyR')) {
      if (_canRetreat()) {
        CombatManager.initiateRetreat(1);
        UI.notify('FTL jump initiated…', 'warn');
        _warnOutsideOnRetreat();
      }
    }

    /* A CRATE IN THE WRECKAGE IS AN ORDER (update93b): the click goes to
       the salvage, not to "move the selection here". */
    if (CombatManager.salvage && Input.mouse.leftPressed && !_pressConsumed) {
      const crate = _salvageCrateAt(Input.mouse.x, Input.mouse.y);
      if (crate) { _pressConsumed = true; _orderSalvage(crate); }
    }

    // Press/drag/release: UI buttons, doors, rubber-band crew
    // selection and group movement (Windows/FTL style)
    _crewMouseUpdate();


    // Outcomes
    // ── Boss phase machine ──
    if (BossManager.isActive) {
      const bres = BossManager.update(0);
      if (bres === 'next_phase') {
        CombatManager.end();
        UI.notify(`MOTHERSHIP — PHASE ${BossManager.phase + 2}`, 'alert');
        _enemyShip = BossManager.nextPhase(850, 120);
        _combatTimer = 0; _combatFired = false;
        CombatManager.begin(_playerShip, _enemyShip, 'boss');
        Audio.sfx.bossWarning();
        return;
      }
      if (bres === 'defeated') {
        /* THE CHIP IS HANDED OVER BEFORE THE CONTRACT IS SETTLED —
           `_finishContract` flies her home and unpacks the hold, and a
           reward dropped after that has no hold to land in. */
        _payBossChip();
        // Contract complete — fly home and dock.
        _finishContract();
        CombatManager.end();
        _enemyShip = null;
        return;
      }
    }

    if (CombatManager.isVictory()) {
      _combatTimer += dt;
      if (!_combatFired) {
        _combatFired = true;
        _recoverBoarders();   // emergency teleport off the dying hull
        _creditCrew('wins');
        _onWin();
        UI.notify('Enemy destroyed — repair, then JUMP when ready', 'good');
      }
      /* ONLY A HULL THAT WENT UP leaves crates in the void (update93b) —
         once per fight, and "the fight" is CombatManager's: begin() clears it. */
      if (!CombatManager._salvageRolled) {
        CombatManager._salvageRolled = true;
        if (_enemyShip && (_enemyShip.destroyed || _enemyShip.hull <= 0)) _spawnSalvage();
      }
      _updateSalvage(dt);
      if (_leaveWarnT > 0) _leaveWarnT -= dt;
      // Player decides when to leave: ENTER or the JUMP button.
      // Crew keep repairing, shields recharge in the meantime.
      const W = Renderer.getWidth();
      const jumpHit = Input.mouse.leftPressed &&
        Utils.pointInRect(Input.mouse.x, Input.mouse.y, W/2 - 80, 90, 160, 40);
      // ENTER, not Space: Space is the pause key now and means only
      // that. The JUMP button beside this line does the same job for a
      // player who never touches the keyboard.
      if (_combatTimer > 1.0 && (Input.isPressed('Enter') ||
          Input.isPressed('NumpadEnter') || jumpHit) && _leaveOutsideConfirmed()) {
        /* ANYBODY STILL OUT THERE IS LEFT THERE (update93b). */
        _abandonOutside('left behind in the wreckage');
        _setSalvage(null);
        CombatManager.end(); _enemyShip = null; _selectedWeapon = null;
        Commander?.setEnemy?.(null);
        /* WINNING IS AN EXIT TOO (update40). Every other way out of a
           fight cleared the nebula's −2 reactor penalty; this one did
           not, so a won ambush left you sitting on the map with the
           medbay and life support starved until the next jump. */
        _playerShip.reactor.penalty = 0; _nebulaCombat = false;
        _clearWreckMode();
        _saveShip(); _leaveFight(); Audio.playMusic('explore');
      }
    }
    /* The pod counts down WHILE the fight goes on — that is the whole
       tension of it, and it is why this sits above the defeat check:
       a countdown that finishes on the same frame the hull dies gets
       him out, and one that does not, does not. */
    _tickEvac(dt);
    // The pod finishing ENDS the run — do not carry on updating a
    // fight that no longer has a ship in it.
    if (STATE !== 'combat') return;

    if (CombatManager.isDefeat()) { if (!_reAtumRescue('hull')) _onLose(); return; }

    // Total crew wipe — count boarders too, so a full-crew boarding
    // action doesn't false-trigger game over while they're in transit
    // or fighting aboard the enemy.
    if (_playerCrewAliveCount() === 0) {
      UI.notify('All crew lost…', 'alert');
      _onLose();
      return;
    }
    if (CombatManager.isFled()) {
      _sosFightPending = false;   // ran away from the scavengers, no prize
      _creditCrew('escapes');
      /* WE JUMPED: whoever was outside stays outside (update93b). */
      _recoverBoarders({ aboardLost: 'left behind when we jumped', flightLost: 'left behind when we jumped' });
      CombatManager.end(); _enemyShip = null; _saveShip();
      _playerShip.reactor.penalty = 0; _nebulaCombat = false;
      _clearWreckMode();          // see the comment on _clearWreckMode
      UI.notify('Escaped!', 'good'); _leaveFight(); Audio.playMusic('explore');
      if (typeof JumpScene !== 'undefined') JumpScene.jump(_playerShip);   // update118
      return;
    }
    // The ENEMY completed their escape — they jump out, no loot.
    if (CombatManager.isEnemyFled()) {
      _sosFightPending = false;   // they jumped out with their tanks
      /* THEY JUMPED WITH OUR PEOPLE ABOARD (update93b): gone with them. */
      _recoverBoarders({ aboardLost: 'carried off on the enemy ship' });
      CombatManager.end(); _enemyShip = null; _saveShip();
      _playerShip.reactor.penalty = 0; _nebulaCombat = false;
      _clearWreckMode();
      UI.notify('Enemy ship ESCAPED — no salvage…', 'warn');
      _leaveFight(); Audio.playMusic('explore');
      return;
    }
    // One-shot alert the moment they start spooling their drive
    if (CombatManager.consumeEscapeNotice()) {
      UI.notify(CombatManager.escapeWhy === 'stalemate'
        ? '⚠ ENEMY GIVES UP — a minute without hurting you, they are spooling to RUN. Kill their cockpit or engines!'
        : CombatManager.escapeWhy === 'alone'
        ? '⚠ THEIR LAST MAN IS RUNNING — kill their cockpit or engines!'
        : '⚠ ENEMY IS TRYING TO ESCAPE — kill their cockpit or engines!', 'alert');
      Audio.sfx.bossWarning?.();
    }
  }

  /** The pod badge beside the commander, its countdown, and its hover. */
  function _drawEvac(ctx) {
    if (!_commander && !_evacRunning()) return;
    const r = _podRect();
    const state = _evacRunning() ? 'run' : _podState();
    const col = state === 'run' ? '#ff2d44' : state === 'live' ? '#ff8adf' : '#3a4560';
    const hot = Utils.pointInRect(Input.mouse.x, Input.mouse.y, r.x, r.y, r.w, r.h);

    ctx.save();
    ctx.fillStyle = state === 'run' ? 'rgba(40,10,14,0.9)'
                  : hot && state === 'live' ? 'rgba(255,138,223,0.18)' : 'rgba(13,17,32,0.85)';
    ctx.beginPath(); ctx.roundRect(r.x, r.y, r.w, r.h, 3); ctx.fill();
    if (state === 'run') {
      // The countdown drains the badge from the top.
      const frac = Utils.clamp(_evacT / (_evacSecs || 1), 0, 1);
      ctx.fillStyle = 'rgba(255,45,68,0.45)';
      ctx.fillRect(r.x + 1, r.y + 1 + (r.h - 2) * (1 - frac), r.w - 2, (r.h - 2) * frac);
    }
    ctx.strokeStyle = col; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.roundRect(r.x, r.y, r.w, r.h, 3); ctx.stroke();

    // The pod: a capsule with a porthole and a flame under it.
    const cx = r.x + r.w / 2, cy = r.y + r.h / 2 - 1;
    ctx.strokeStyle = col; ctx.fillStyle = col; ctx.lineWidth = 1.4;
    ctx.beginPath();
    ctx.ellipse(cx, cy, 4, 6.5, 0, 0, Math.PI * 2);
    ctx.stroke();
    ctx.beginPath(); ctx.arc(cx, cy - 1.5, 1.6, 0, Math.PI * 2); ctx.fill();
    ctx.beginPath();
    ctx.moveTo(cx - 2.5, cy + 6.5); ctx.lineTo(cx, cy + 9.5); ctx.lineTo(cx + 2.5, cy + 6.5);
    ctx.stroke();

    if (state === 'run') {
      ctx.fillStyle = '#ffd7d7';
      ctx.font = 'bold 10px Share Tech Mono, monospace';
      ctx.textAlign = 'left';
      // In the bar now (update104): over the KNOWLEDGE word beside it.
      ctx.fillStyle = 'rgba(40,10,14,0.95)';
      ctx.fillRect(r.x + r.w + 2, r.y, 56, 14);
      ctx.fillStyle = '#ffd7d7';
      ctx.fillText(`POD ${Math.ceil(_evacT)}s`, r.x + r.w + 4, r.y + 11);
    }

    if (hot) {
      const k = (typeof Commander !== 'undefined' && Commander.KARMA) ? Commander.KARMA.EVACUATE : -10;
      const lines = state === 'run'
        ? ['ESCAPE POD — LAUNCHING', `${Math.ceil(_evacT)}s left. The fight goes on:`,
           'if the hull or the last hand dies first,', 'the commander dies with them.']
        : state === 'live'
        ? ['ESCAPE POD — click to launch', `${_podSeconds()}s countdown, the fight goes on.`,
           'The commander comes home with his levels', 'and tablets. Ship, hold and crew are lost.',
           `Karma ${k}.`]
        : state === 'dark'
        ? ['ESCAPE POD — Re-Atum is DARK', 'Re-Atum is mounted, but it works at', 'nothing (the wall, or INT 0).']
        : ['ESCAPE POD — none', 'No Re-Atum tablet on the commander\'s', 'board. Mount one at the base.'];
      ctx.font = '9px Share Tech Mono, monospace';
      const w = Math.max(...lines.map(t => ctx.measureText(t).width)) + 12;
      const bx = r.x, by = r.y + r.h + 4, bh = lines.length * 12 + 6;
      ctx.fillStyle = 'rgba(7,8,15,0.95)';
      ctx.fillRect(bx, by, w, bh);
      ctx.strokeStyle = col; ctx.strokeRect(bx + 0.5, by + 0.5, w - 1, bh - 1);
      ctx.textAlign = 'left';
      lines.forEach((t, i) => {
        ctx.fillStyle = i === 0 ? (state === 'none' || state === 'dark' ? '#7a90a8' : col) : '#c8d4e4';
        ctx.fillText(t, bx + 6, by + 13 + i * 12);
      });
    }
    ctx.restore();
  }

  /** The body menu, drawn wherever the game is. Closes itself if the
   *  body it points at has left the ship — a panel hanging over an
   *  empty patch of deck is the sort of thing that outlives its
   *  subject and then takes a click meant for something else. */
  function _drawBodyMenu(ctx) {
    if (!_bodyMenu) return;
    const body = _bodyMenuBody();
    if (!body) { _bodyMenu = null; return; }
    Renderer.drawBodyMenu(ctx, _bodyMenu.x, _bodyMenu.y, body.name,
                          (act) => _playerShip.menuRefusal(body, act),
                          _menuActsFor(body));
  }

  function _drawCombat(ctx) {
    Renderer.drawBackground(_prevTime * 0.008);
    // (crew selection visuals drawn after ships, see below)

    // Nebula backdrop — drifting violet clouds behind the ships
    if (_nebulaCombat) Renderer.drawNebula(ctx, _prevTime * 0.001);
    // …or the rocks of an asteroid field (update100)
    if (CombatManager.asteroids) Renderer.drawAsteroidField(ctx, _prevTime * 0.001);

    /* Both hulls go through the film (update118): while a fight opens,
       you slide in from the jump and he drops out of his. */
    const _drawHull = sh => (typeof JumpScene !== 'undefined') ? JumpScene.drawShip(ctx, sh) : sh.draw(ctx);
    /* Who each side's guns point at — the weapons' displays show the
       chance to hit him (update120). Set where both ships are known. */
    if (_playerShip) _playerShip.foe = (_enemyShip && !_enemyShip.destroyed) ? _enemyShip : null;
    if (_enemyShip)  _enemyShip.foe  = _playerShip ?? null;
    if (_playerShip) _drawHull(_playerShip);
    if (_enemyShip && !_enemyShip.destroyed) _drawHull(_enemyShip);
    // A survivor lying on a wreck says so (update90b).
    if (_wreckMode && _enemyShip) {
      _enemyShip.crew.forEach(c => {
        if (!c._survivor || c.dead) return;
        const pulse = 0.6 + 0.4 * Math.sin((_prevTime ?? 0) * 0.006);
        ctx.save();
        ctx.globalAlpha = c.carriedBy ? 1 : pulse;
        ctx.fillStyle = '#1aff8c';
        ctx.font = 'bold 10px Share Tech Mono, monospace';
        ctx.textAlign = 'center';
        ctx.fillText(c.carriedBy ? 'SURVIVOR → HATCH' : 'SOS', c.x, c.y - 46);   // above his name plate
        ctx.restore();
      });
    }
    if (_boardingParty) _drawParty(ctx, _boardingParty);
    if (_enemyParty)    _drawParty(ctx, _enemyParty);
    _drawSalvage(ctx);
    _drawRockWarning(ctx);
    _drawHorusEye(ctx);
    _drawCrewSelection(ctx);
    _drawBodyMenu(ctx);

    // Nebula haze in front — the battle feels buried in the cloud
    if (_nebulaCombat) {
      ctx.fillStyle = 'rgba(140,60,200,0.07)';
      ctx.fillRect(0, 0, Renderer.getWidth(), Renderer.getHeight());
    }

    // Victory: JUMP button (player leaves when ready)
    // (Boss phase machine moved to _updateCombat — it used to race
    //  the victory screen here in draw, which looked like a restart.)

    if (CombatManager.isVictory()) {
      const W = Renderer.getWidth();
      const hover = Utils.pointInRect(Input.mouse.x, Input.mouse.y, W/2 - 80, 90, 160, 40);
      ctx.fillStyle = hover ? 'rgba(26,255,140,0.3)' : 'rgba(13,17,32,0.9)';
      ctx.beginPath(); ctx.roundRect(W/2 - 80, 90, 160, 40, 5); ctx.fill();
      ctx.strokeStyle = '#1aff8c'; ctx.lineWidth = hover ? 2 : 1.5; ctx.stroke();
      ctx.fillStyle = '#1aff8c';
      ctx.font = '14px Orbitron, monospace';
      ctx.textAlign = 'center';
      ctx.fillText('JUMP [ENTER]', W/2, 115);
    }
    CombatManager.draw(ctx);
    CombatManager.drawBeams(ctx);
    Particles.draw(ctx, 1);
    Renderer.drawHUD({ playerShip: _playerShip, enemyShip: _enemyShip , nebula: _nebulaCombat });

    /* ── THE FIGHT ORDERS MOVED (update53) ────────────────────
     * BOARD, RECALL and RETREAT are drawn by the order panel now,
     * under the crew, with every other order. What is left here is the
     * PROGRESS they show while they are running — a boarding party
     * crossing the void and a jump spooling up are states of the
     * fight, not buttons, and they belong over the ships where the
     * player is already looking.
     */
    _drawEvac(ctx);
    {
      const W = Renderer.getWidth();
      const prog = CombatManager.retreatProgress;
      if (prog > 0) {
        const rb = { x: W / 2 - 90, y: 42, w: 180, h: 22 };
        ctx.fillStyle = 'rgba(13,17,32,0.85)';
        ctx.beginPath(); ctx.roundRect(rb.x, rb.y, rb.w, rb.h, 4); ctx.fill();
        ctx.fillStyle = 'rgba(255,124,32,0.35)';
        ctx.beginPath(); ctx.roundRect(rb.x, rb.y, rb.w * prog, rb.h, 4); ctx.fill();
        ctx.strokeStyle = '#ff7c20'; ctx.lineWidth = 1;
        ctx.beginPath(); ctx.roundRect(rb.x, rb.y, rb.w, rb.h, 4); ctx.stroke();
        ctx.fillStyle = '#ff7c20';
        ctx.font = '12px Share Tech Mono, monospace';
        ctx.textAlign = 'center';
        ctx.fillText(`JUMPING ${Math.round(prog * 100)}%`, rb.x + rb.w / 2, rb.y + 15);
        ctx.textAlign = 'left';
      }
      if (_boardingParty) {
        const bb = { x: W / 2 - 90, y: prog > 0 ? 70 : 42, w: 180, h: 22 };
        ctx.fillStyle = 'rgba(13,17,32,0.85)';
        ctx.beginPath(); ctx.roundRect(bb.x, bb.y, bb.w, bb.h, 4); ctx.fill();
        ctx.strokeStyle = '#ff2d44'; ctx.lineWidth = 1;
        ctx.beginPath(); ctx.roundRect(bb.x, bb.y, bb.w, bb.h, 4); ctx.stroke();
        ctx.fillStyle = '#ff2d44';
        ctx.font = '12px Share Tech Mono, monospace';
        ctx.textAlign = 'center';
        const pct = Math.round(Utils.clamp(
          _boardingParty.breachT / _boardingParty.breachNeed, 0, 1) * 100);
        ctx.fillText(_boardingParty.doorBroken ? 'BOARDING…'
          : `${_boardingParty.recall ? 'RETURN' : 'POD'} ${pct}%`,
          bb.x + bb.w / 2, bb.y + 15);
        ctx.textAlign = 'left';
      }
    }

    // Enemy escape progress — big red warning bar under their readout.
    // Never for a dead hull: the marker used to hang around after we
    // shot the runner down.
    if (_enemyShip && CombatManager.enemyEscapeActive &&
        !_enemyShip.destroyed && _enemyShip.hull > 0 &&
        CombatManager.inProgress()) {
      // `W` is declared inside the button block ABOVE, not at this
      // scope. Reading it here threw a ReferenceError straight out of
      // _drawCombat on every frame the enemy was spooling its drive —
      // the whole frame died, which is what the freezes looked like.
      const W  = Renderer.getWidth();
      const ep = CombatManager.enemyEscapeProgress;
      /* ── THE SPOOL, REDRAWN (update127, jj: "enemy escape bar też słaby,
       * ikona ostrzegawcza wchodzi na działko") ───────────────────────
       * The bar is a drive spooling: one cell per second of the spool,
       * the seconds left at its end, the warning mark INSIDE it. The
       * blinking triangle that hung over their hull sat on their gun;
       * what the player needs on the hull is WHERE TO SHOOT, so the two
       * rooms that stop the jump — the helm and the engines — pulse
       * red instead. */
      const anchored = typeof Chips !== 'undefined' && Chips.running('cone');
      const T  = CombatManager.ENEMY_ESCAPE_TIME ?? 11;
      const left = Math.max(0, Math.ceil((1 - ep) * T));
      const pulse = 0.55 + 0.45 * Math.sin((performance.now() % 100000) * 0.012);
      const ex = W - 320, ey = 84, ew = 300, eh = 24;
      const col = anchored ? '#8fd4ff' : '#ff2d44';
      ctx.save();
      ctx.fillStyle = 'rgba(13,17,32,0.94)';
      ctx.beginPath(); ctx.roundRect(ex, ey, ew, eh, 4); ctx.fill();
      // the mark, inside the bar on the left
      ctx.globalAlpha = anchored ? 1 : pulse;
      ctx.beginPath();
      ctx.moveTo(ex + 14, ey + 4); ctx.lineTo(ex + 23, ey + 20); ctx.lineTo(ex + 5, ey + 20); ctx.closePath();
      ctx.fillStyle = col; ctx.fill();
      ctx.fillStyle = '#0d1120'; ctx.font = 'bold 11px Share Tech Mono, monospace'; ctx.textAlign = 'center';
      ctx.fillText(anchored ? '⚓' : '!', ex + 14, ey + 18);
      ctx.globalAlpha = 1;
      // label
      ctx.fillStyle = col; ctx.textAlign = 'left'; ctx.font = 'bold 10px Share Tech Mono, monospace';
      ctx.fillText(anchored ? 'FTL ANCHORED' : 'ENEMY FTL', ex + 30, ey + 10);
      ctx.fillStyle = '#c8d0e0'; ctx.font = '9px Share Tech Mono, monospace';
      ctx.fillText(anchored ? `held ${Math.ceil(Chips.runningLeft('cone'))}s` : 'hit HELM / ENGINES', ex + 30, ey + 20);
      // the cells — one per second of the spool
      const cx0 = ex + 132, cw = ew - 132 - 40, n = Math.max(1, Math.round(T));
      const gap = 2, cell = (cw - gap * (n - 1)) / n, lit = ep * n;
      for (let i = 0; i < n; i++) {
        const x = cx0 + i * (cell + gap);
        ctx.fillStyle = 'rgba(255,45,68,0.14)';
        ctx.fillRect(x, ey + 6, cell, eh - 12);
        const f = Utils.clamp(lit - i, 0, 1);
        if (f > 0) { ctx.fillStyle = anchored ? 'rgba(143,212,255,0.8)' : col; ctx.fillRect(x, ey + 6, cell * f, eh - 12); }
      }
      // seconds left, at the end
      ctx.fillStyle = col; ctx.textAlign = 'right'; ctx.font = 'bold 13px Share Tech Mono, monospace';
      ctx.fillText(`${left}s`, ex + ew - 7, ey + 17);
      ctx.strokeStyle = col; ctx.lineWidth = 1;
      ctx.globalAlpha = anchored ? 1 : 0.6 + 0.4 * pulse;
      ctx.beginPath(); ctx.roundRect(ex, ey, ew, eh, 4); ctx.stroke();
      ctx.globalAlpha = 1;

      // ON THE HULL: the two rooms that stop the jump.
      if (!anchored) {
        ['piloting', 'engines'].forEach(type => {
          const sys = _enemyShip.getSystem(type);
          const r = sys ? _enemyShip.getRoomById(sys.roomId) : null;
          if (!r) return;
          ctx.globalAlpha = pulse;
          ctx.strokeStyle = '#ff2d44'; ctx.lineWidth = 2;
          ctx.setLineDash([6, 3]);
          ctx.strokeRect(r.x + 2, r.y + 2, r.w - 4, r.h - 4);
          ctx.setLineDash([]);
          ctx.globalAlpha = 1;
        });
      }
      ctx.restore();
    }

    // Targeting mode — highlight enemy rooms
    if (_selectedWeapon && _enemyShip) {
      ctx.save();
      _enemyShip.rooms.forEach(r => {
        const hover = Utils.pointInRect(Input.mouse.x, Input.mouse.y, r.x, r.y, r.w, r.h);
        ctx.strokeStyle = hover ? '#ff2d44' : 'rgba(255,45,68,0.4)';
        ctx.lineWidth = hover ? 3 : 1.5;
        ctx.setLineDash(hover ? [] : [5, 4]);
        ctx.strokeRect(r.x, r.y, r.w, r.h);
        if (hover) {
          ctx.fillStyle = 'rgba(255,45,68,0.15)';
          ctx.fillRect(r.x, r.y, r.w, r.h);
        }
      });
      ctx.setLineDash([]);
      // Crosshair at cursor
      ctx.strokeStyle = '#ff2d44';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.arc(Input.mouse.x, Input.mouse.y, 10, 0, Math.PI*2);
      ctx.moveTo(Input.mouse.x - 15, Input.mouse.y);
      ctx.lineTo(Input.mouse.x + 15, Input.mouse.y);
      ctx.moveTo(Input.mouse.x, Input.mouse.y - 15);
      ctx.lineTo(Input.mouse.x, Input.mouse.y + 15);
      ctx.stroke();
      ctx.restore();
    }

    if (CombatManager.state === 'retreating') {
      Renderer.drawRetreatBar(CombatManager._retreatTimer / 3.0);
    }
  }

  // ── EVENT ─────────────────────────────────────────────────
  function _drawEvent(ctx) {
    Renderer.drawBackground(0);
    if (!_event) return;
    const W = Renderer.getWidth(), H = Renderer.getHeight();
    const EW = 480, EH = 260, ex = W/2-EW/2, ey = H/2-EH/2;

    ctx.fillStyle = 'rgba(13,17,32,0.96)';
    ctx.beginPath(); ctx.roundRect(ex,ey,EW,EH,8); ctx.fill();
    ctx.strokeStyle = '#1e2d4a'; ctx.lineWidth = 1; ctx.stroke();

    ctx.fillStyle = '#4db8ff'; ctx.font = '15px Orbitron, monospace';
    ctx.textAlign = 'left';
    ctx.fillText(_event.title, ex+20, ey+30);

    ctx.fillStyle = '#c8d8f0'; ctx.font = '12px Share Tech Mono, monospace';
    let ty = ey+55, words = _event.text.split(' '), line = '';
    words.forEach(w => {
      const test = line + w + ' ';
      if (ctx.measureText(test).width > EW-40) { ctx.fillText(line, ex+20, ty); ty+=14; line=w+' '; }
      else line = test;
    });
    if (line) ctx.fillText(line, ex+20, ty);

    _event.choices.forEach((c, i) => {
      const bx=ex+20, by=ey+160+i*40, bw=EW-40, bh=32;
      const hover = Utils.pointInRect(Input.mouse.x, Input.mouse.y, bx, by, bw, bh);

      /* ── THE COLOUR OF THE DECISION (update52) ───────────────
       * A choice that moves karma is drawn in the direction it moves
       * it: green for the decent one, red for the ugly one, plain
       * for a choice that costs nothing but resources. The player
       * should not have to have memorised the karma table to know
       * which button is which — and this is the same number the
       * choice actually pays, read off the choice itself, not a
       * second flag somebody has to remember to set. */
      /* AND NOBODY ON THE BRIDGE MEANS NO COLOUR (update54).
         Karma is personal to a commander — `_resolveEvent` moves
         nothing without one — but the buttons were painted green and
         red regardless, promising a consequence the run cannot pay.
         The same predicate decides both: one question, one answer. */
      const km  = _hasCommander() ? (c.result?.karma || 0) : 0;
      const tone = km > 0 ? { line: '#1aff8c', fill: 'rgba(26,255,140,0.16)' }
                 : km < 0 ? { line: '#ff5566', fill: 'rgba(255,85,102,0.16)' }
                 :          { line: '#4db8ff', fill: 'rgba(26,140,255,0.3)'  };
      ctx.fillStyle = hover ? tone.fill : 'rgba(20,30,50,0.9)';
      ctx.beginPath(); ctx.roundRect(bx,by,bw,bh,4); ctx.fill();
      ctx.strokeStyle = km ? tone.line : (hover ? '#4db8ff' : '#1e2d4a');
      ctx.lineWidth=1; ctx.stroke();
      ctx.fillStyle = km ? tone.line : (hover ? '#4db8ff' : '#c8d8f0');
      ctx.font = '12px Share Tech Mono, monospace'; ctx.textAlign = 'left';
      ctx.fillText(c.label, bx+12, by+20);
      if (km) {
        ctx.textAlign = 'right';
        ctx.fillText(`${km > 0 ? '+' : ''}${km} KARMA`, bx + bw - 12, by + 20);
        ctx.textAlign = 'left';
      }

      if (Input.mouse.leftPressed && hover) {
        Audio.sfx.uiClick();
        _resolveEvent(i);
      }
    });
  }


  /* ══ THE PROMOTION SCREEN (update52) ═══════════════════════
   *
   * A commander's level is not a number that quietly ticks up in a
   * corner: it is a DECISION the player makes, and he has to see it
   * happen. Every level owes one POINT in one of four attributes
   * (update98 — it was +0.5% in one of two corporation trades), and
   * this screen is where that point is spent.
   *
   * It is driven entirely by `Commander.pointsOwed()`, which is
   * `level - pointsSpent` — a computed number, not a counter somebody
   * has to remember to increment after a fight. That means the screen
   * cannot get out of step with the levels: promote a rank-12 crewman
   * and it opens twelve times; win a fight that granted three levels
   * and it opens three times; close the game halfway through and the
   * picks are still owed when you come back.
   */
  let _promo = null;          // { cap, ret } — who is promoting, where to go back

  /* ── HIS FILE, BETWEEN FIGHTS (update52a) ────────────────
   *
   * The commander is not a body on the deck: he has no portrait among
   * the crew and nothing to click in a fight. That left the player
   * with no way to look at his karma or his board once the contract
   * had launched — the mess is at base, and the base is a run away.
   *
   * So the HUD strip is a button on the MAP. Not in combat: the
   * commander's numbers are not a thing to read while being shot at,
   * and a modal over a live fight is a modal the player did not ask
   * for. The panel itself is Renderer.drawCommanderDossier, the very
   * one the mess opens — one layout, two doors. */
  let _dossier = false;

  function _openPromo(cap, ret) {
    if (!cap || typeof Commander === 'undefined') return false;
    if (Commander.pointsOwed(cap) <= 0) return false;
    _promo = { cap, ret: ret || 'map', from: Commander.pointsSpent(cap) };
    STATE = 'promo';
    Audio.sfx.levelUp?.();
    return true;
  }

  function _promoRects() {
    const W = Renderer.getWidth(), H = Renderer.getHeight();
    /* FOUR ATTRIBUTES (update98), so four rows — and wider, because
       the right-hand side says what the point will make of him. */
    const PW = 540, PH = 318, px = W / 2 - PW / 2, py = H / 2 - PH / 2;
    const opts = (typeof Commander !== 'undefined' && _promo) ? Commander.ATTRS : [];
    return {
      panel: { x: px, y: py, w: PW, h: PH },
      opts: opts.map((k, i) => ({
        key: k, x: px + 24, y: py + 120 + i * 46, w: PW - 48, h: 38,
      })),
    };
  }

  function _drawPromo(ctx) {
    Renderer.drawBackground(0);
    if (!_promo) return;
    const cap = _promo.cap;
    const { panel, opts } = _promoRects();

    ctx.fillStyle = 'rgba(13,17,32,0.96)';
    ctx.beginPath(); ctx.roundRect(panel.x, panel.y, panel.w, panel.h, 8); ctx.fill();
    ctx.strokeStyle = '#ffd700'; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.roundRect(panel.x, panel.y, panel.w, panel.h, 8); ctx.stroke();

    /* WHAT HE WAS AND WHAT HE IS. The rank names carry this: "level 7
       to 8" means nothing to a player, "Senior Sergeant to Staff
       Sergeant" is a thing that happened to a man. */
    const owed = Commander.pointsOwed(cap);
    const at   = cap.level - owed + 1;       // the level being spent right now
    ctx.fillStyle = '#ffd700'; ctx.font = '16px Orbitron, monospace';
    ctx.textAlign = 'center';
    ctx.fillText('PROMOTION', panel.x + panel.w / 2, panel.y + 34);

    ctx.fillStyle = '#c8d8f0'; ctx.font = '13px Share Tech Mono, monospace';
    ctx.fillText(`${cap.name} — ${rankName(at - 1)} → ${rankName(at)}`,
                 panel.x + panel.w / 2, panel.y + 60);
    ctx.fillStyle = '#7a90a8'; ctx.font = '11px Share Tech Mono, monospace';
    ctx.fillText(`LEVEL ${at} of ${Commander.MAX_LEVEL}`
               + (owed > 1 ? `   ·   ${owed - 1} more to spend after this` : ''),
                 panel.x + panel.w / 2, panel.y + 80);

    const corp = (CORP_DEFS[cap.race] || {}).label || cap.race;
    ctx.fillStyle = '#4dd8c0'; ctx.font = '10px Share Tech Mono, monospace';
    ctx.fillText(`one point — LEADERSHIP and ENDURANCE reach ${corp} crew only`,
                 panel.x + panel.w / 2, panel.y + 104);
    ctx.textAlign = 'left';

    opts.forEach(o => {
      const hover = Utils.pointInRect(Input.mouse.x, Input.mouse.y, o.x, o.y, o.w, o.h);
      ctx.fillStyle = hover ? 'rgba(26,255,140,0.16)' : 'rgba(20,30,50,0.9)';
      ctx.beginPath(); ctx.roundRect(o.x, o.y, o.w, o.h, 4); ctx.fill();
      ctx.strokeStyle = hover ? '#1aff8c' : '#1e2d4a'; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.roundRect(o.x, o.y, o.w, o.h, 4); ctx.stroke();

      ctx.fillStyle = hover ? '#1aff8c' : '#c8d8f0';
      ctx.font = '13px Share Tech Mono, monospace';
      const n = Commander.attr(cap, o.key);
      ctx.fillText(`+1  ${Commander.ATTR_LABEL[o.key]} (${n})`, o.x + 14, o.y + 24);

      /* WHAT IT WILL MAKE OF HIM, not just "+1" — read off the same
         wording the dossier uses, on a probe one point up. */
      const probe = { ...cap, attrs: { ...cap.attrs, [o.key]: n + 1 } };
      ctx.fillStyle = '#7a90a8'; ctx.font = '10px Share Tech Mono, monospace';
      ctx.textAlign = 'right';
      ctx.fillText(`→ ${Commander.attrLine(probe, o.key)}`, o.x + o.w - 14, o.y + 24);
      ctx.textAlign = 'left';
    });
  }

  function _updatePromo(dt) {
    if (!_promo) { STATE = 'map'; return; }
    const { opts } = _promoRects();
    if (!Input.mouse.leftPressed) { _promoArmed = true; return; }
    if (!_promoArmed) return;
    for (const o of opts) {
      if (!Utils.pointInRect(Input.mouse.x, Input.mouse.y, o.x, o.y, o.w, o.h)) continue;
      _promoArmed = false;
      Audio.sfx.uiClick();
      Commander.spendPoint(_promo.cap, o.key);
      Base.saveCommander?.(_promo.cap);
      /* The crew are wearing his max-HP bonus, so a point that moves it
         has to be re-seated the same frame — otherwise the HP only
         appears at the next launch and the player is told a number
         that is not true yet. */
      if (o.key === 'endurance' && _playerShip) Commander.reseatMaxHp(_playerShip.crew);
      if (Commander.pointsOwed(_promo.cap) <= 0) {
        const ret = _promo.ret;
        _promo = null;
        STATE = ret;
      }
      return;
    }
  }
  let _promoArmed = true;

  /**
   * Is a promotion owed RIGHT NOW? Called every frame from the update
   * loop rather than at the end of a fight, because "the end of a
   * fight" is four different code paths (win, boss, retreat, the
   * enemy surrendering) and one of them would have been forgotten.
   * The owed count is computed, so asking often is free and asking
   * late is impossible.
   */
  function _checkPromo() {
    if (STATE !== 'map' && STATE !== 'combat') return;
    if (!_commander || typeof Commander === 'undefined') return;
    if (Commander.pointsOwed(_commander) <= 0) return;
    if (STATE === 'combat' && CombatManager.inProgress?.()) return;  // not mid-fight
    _openPromo(_commander, 'map');
  }

  /** One click closes the file: CLOSE, or anywhere off the panel. */
  function _updateDossier() {
    if (!_commander) { _dossier = false; return; }
    if (!Input.mouse.leftPressed) { _dossierArmed = true; return; }
    if (!_dossierArmed) return;
    _dossierArmed = false;
    const r = Renderer.drawCommanderDossier(_nullCtx(), _commander);
    const onPanel = Utils.pointInRect(Input.mouse.x, Input.mouse.y,
                                      r.panel.x, r.panel.y, r.panel.w, r.panel.h);
    const onClose = Utils.pointInRect(Input.mouse.x, Input.mouse.y,
                                      r.close.x, r.close.y, r.close.w, r.close.h);
    /* THE FILE HANDS OUT POINTS TOO (update98) — the same door as the
       promotion screen, so a point is a point whichever way it went. */
    const plus = (r.attrPlus || []).find(z =>
      Utils.pointInRect(Input.mouse.x, Input.mouse.y, z.x, z.y, z.w, z.h));
    if (plus) {
      if (Commander.spendPoint(_commander, plus.attr)) {
        Base.saveCommander?.(_commander);
        if (plus.attr === 'endurance' && _playerShip) Commander.reseatMaxHp(_playerShip.crew);
        Audio.sfx.uiClick?.();
      }
      return;
    }
    if (onClose || !onPanel) { _dossier = false; Audio.sfx.uiClick?.(); }
  }
  let _dossierArmed = true;

  /* The dossier's rectangles are a function of the canvas size, and
     the only honest way to ask for them is to ask the thing that draws
     them. This is a context that measures and paints nothing, so the
     hit test can never disagree with the picture. */
  function _nullCtx() {
    const noop = () => {};
    return new Proxy({}, {
      get(_, k) {
        if (k === 'measureText') return (t) => ({ width: String(t ?? '').length * 6 });
        if (k === 'canvas') return null;
        return noop;
      },
      set() { return true; },
    });
  }

  /* ══ SPECIAL ORDERS (update53) ═════════════════════════════
   *
   * The bookkeeping — may he, and what is it worth while it runs — is
   * Commander's, next door to every other question about the boss.
   * What is HERE is the half that touches the ship, because this is
   * where the ship is: a gun that charges, a bubble that comes back, a
   * fire that goes out.
   *
   * Every order goes through this one function, so "once per fight"
   * and "he has to be in the chair" are asked once each and cannot be
   * skipped by a new caller.
   */
  function _giveOrder(key) {
    if (!_playerShip) return false;
    const def = (typeof Commander !== 'undefined') ? Commander.ORDERS[key] : null;
    if (!def) return false;
    if (_needCommander(def.label)) return false;
    if (!CombatManager.isActive?.() && !_enemyShip) {
      UI.notify('Special orders are for a fight.', 'warn');
      return false;
    }
    /* WHETHER HE MAY is Commander's answer, asked once and reported —
       not asked again here in different words. `giveOrder` below goes
       through the very same function, so the check that refuses the
       player and the check that guards the record are one check. */
    const no = Commander.orderRefusal(key);
    if (no) { UI.notify(no, 'warn'); return false; }

    /* ── AN ORDER THAT WOULD DO NOTHING IS REFUSED, NOT SPENT ──
     *
     * Once per fight makes every one of these a decision, and a
     * decision the player cannot take back. FIRE SUPPRESSION with
     * nothing burning, or EVASIVE PATTERN with nobody at the helm,
     * would burn the only chance he gets and leave him with a
     * cheerful message about it. So the work is computed FIRST, and
     * the order is only marked given if there was work to do.
     *
     * Each case returns the sentence the player sees, or null to
     * refuse — and the refusal says what is missing, because "nothing
     * happened" is the least useful thing a game can say.
     */
    const doIt = () => {
      switch (key) {
        case 'piloting': {
          /* Evasion is ZERO without a pilot in the cockpit — that is
             the oldest rule in this ship model, and it runs before any
             bonus. An order that buys +25% of nothing is a wasted
             order, so it needs a man at the helm. */
          if (_playerShip.evasion <= 0) {
            UI.notify('EVASIVE PATTERN — nobody is flying. Man the cockpit first.', 'warn');
            return null;
          }
          return `EVASIVE PATTERN — ${def.hold}s of hard flying.`;
        }
        case 'engines':
          return `FLANK SPEED — ${def.hold}s, and the jump spools double time.`;
        case 'weapons': {
          const hot = (_playerShip.weapons || []).filter(w => w && w.charge < 1);
          if (!hot.length) {
            UI.notify('FULL SALVO — every gun is already hot.', 'warn');
            return null;
          }
          hot.forEach(w => { w.charge = 1; });
          return `FULL SALVO — ${hot.length} gun(s) charged.`;
        }
        case 'shields': {
          const before = _playerShip.shieldBars;
          if (!_playerShip.getSystem('shields') || before >= _playerShip.shieldMax) {
            UI.notify('EMERGENCY BUBBLE — the bubble is already full.', 'warn');
            return null;
          }
          _playerShip.prechargeShields();
          return `EMERGENCY BUBBLE — ${before} → ${_playerShip.shieldBars} layers.`;
        }
        case 'repair': {
          const hurt = _playerShip.systems.filter(sys => sys && sys.damagedLevels > 0);
          if (!hurt.length) {
            UI.notify('DAMAGE CONTROL — nothing is broken.', 'warn');
            return null;
          }
          hurt.forEach(sys => { sys.damagedLevels--; sys.repairProgress = 0; });
          return `DAMAGE CONTROL — ${hurt.length} system(s) back a level.`;
        }
        case 'firefight': {
          const n = _playerShip.fires?.fires?.length ?? 0;
          if (!n) {
            UI.notify('FIRE SUPPRESSION — nothing is burning.', 'warn');
            return null;
          }
          _playerShip.fires.clear();
          return `FIRE SUPPRESSION — ${n} fire(s) out.`;
        }
        case 'breach': {
          const n = _playerShip.breaches?.breaches?.length ?? 0;
          if (!n) {
            UI.notify('HULL SEAL — the hull is tight.', 'warn');
            return null;
          }
          _playerShip.breaches.clear();
          return `HULL SEAL — ${n} breach(es) closed.`;
        }
        case 'combat':
          return `BATTLE FURY — ${def.hold}s of it.`;
        default:
          return def.label;
      }
    };

    const said = doIt();
    if (said === null) return false;          // refused, and NOT spent

    /* Only now is it spent — the once AND the knowledge (update98).
       Commander owns "may he", "what does it cost" and "what is it
       worth while it runs"; the ship half is above. */
    if (!Commander.giveOrder(key)) return false;
    UI.notify(said, 'good');
    Audio.sfx.uiClick?.();
    return true;
  }

  /* ── THE ROCK THAT IS COMING (update100) ──────────────────────
   * ASTEROID.WARN seconds before a rock lands, the room is known: it is
   * outlined and labelled on whichever hull it will hit, and the field
   * says so above the fight. A warning the player cannot see is a rule
   * he learns by losing a module. */
  function _drawRockWarning(ctx) {
    const A = CombatManager.asteroids;
    if (!A) return;
    const W = Renderer.getWidth();
    ctx.save();
    ctx.textAlign = 'center';
    ctx.font = '10px Share Tech Mono, monospace';
    ctx.fillStyle = '#c08a52';
    ctx.fillText(A.warn ? '◆ ASTEROID FIELD — ROCK INCOMING' : `◆ ASTEROID FIELD — next rock in ${Math.max(0, Math.ceil(A.t))} s`,
                 W / 2, 116);
    if (A.warn) {
      const ship = A.warn.side === 'player' ? _playerShip : _enemyShip;
      const room = ship?.getRoomById?.(A.warn.roomId);
      if (room) {
        const pulse = 0.5 + 0.5 * Math.sin((_prevTime ?? 0) * 0.02);
        ctx.strokeStyle = `rgba(255,140,60,${0.5 + 0.5 * pulse})`;
        ctx.lineWidth = 3;
        ctx.strokeRect(room.x + 2, room.y + 2, room.w - 4, room.h - 4);
        ctx.fillStyle = '#ffb060';
        ctx.font = 'bold 10px Share Tech Mono, monospace';
        ctx.fillText('ROCK!', room.cx, room.y + room.h - 8);   // under the name plates
      }
    }
    ctx.restore();
  }

  /* ── WHAT THE EYE OF HORUS SEES (update101) ───────────────────
   * From level II: the room their guns are aimed at, marked on our
   * hull. From III: how long each of their guns has before it fires.
   * The aim is the enemy AI's own target (CombatManager._aiTargetRoom),
   * so the mark cannot point anywhere the shots will not go. */
  function _drawHorusEye(ctx) {
    if (typeof Chips === 'undefined') return;
    const lvl = Chips.runningLevel('horus');
    if (lvl < 2 || !_playerShip || !_enemyShip) return;
    const room = CombatManager._aiTargetRoom;
    if (!room) return;
    const pulse = 0.5 + 0.5 * Math.sin((_prevTime ?? 0) * 0.012);
    ctx.save();
    ctx.strokeStyle = `rgba(232,176,74,${0.55 + 0.45 * pulse})`;
    ctx.lineWidth = 2;
    const r = Math.min(room.w, room.h) * 0.32;
    ctx.beginPath(); ctx.arc(room.cx, room.cy, r, 0, Math.PI * 2); ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(room.cx - r - 6, room.cy); ctx.lineTo(room.cx + r + 6, room.cy);
    ctx.moveTo(room.cx, room.cy - r - 6); ctx.lineTo(room.cx, room.cy + r + 6);
    ctx.stroke();
    ctx.fillStyle = '#e8b04a';
    ctx.font = 'bold 9px Share Tech Mono, monospace';
    ctx.textAlign = 'center';
    ctx.fillText('◉ THEIR AIM', room.cx, room.y + 12);
    if (lvl >= 3) {
      const lines = (_enemyShip.weapons ?? []).filter(Boolean).map((w, i) => {
        if (!w.powered) return `GUN ${i + 1}: unpowered`;
        if (w.armed || w.charge >= 1) return `GUN ${i + 1}: READY`;
        const left = (1 - (w.charge ?? 0)) * w.chargeTime();
        return `GUN ${i + 1}: ${left.toFixed(1)} s`;
      });
      ctx.font = '8px Share Tech Mono, monospace';
      lines.forEach((t, i) => ctx.fillText(t, room.cx, room.y + room.h - 6 - (lines.length - 1 - i) * 9));
    }
    ctx.restore();
  }

  /* ══ THE TABLETS (update99, package B) ════════════════════════
   *
   * The bookkeeping — may he, at what level, what it costs, how long it
   * runs — is Chips's (chips.js), next to the board. What is HERE is the
   * half that touches the ship, because this is where the ship is: the
   * same split the special orders have.
   *
   * Every use goes through this one function: the Book's click, the
   * quick bar's click. A use that would do nothing is refused and NOT
   * paid for, like an order.
   */
  function _useTablet(key, where = 'combat') {
    const def = (typeof Chips !== 'undefined') ? Chips.DEFS[key] : null;
    if (!def) return false;
    if (_needCommander(def.label)) return false;
    const no = Chips.useRefusal(_commander, key, where);
    if (no) { UI.notify(no, 'warn'); return false; }
    const eff = Chips.tablets(_commander).find(t => t.key === key)?.eff ?? 0;
    const roman = Chips.roman(eff);

    const doIt = () => {
      switch (key) {
        case 'golden_ratio': {
          // Evasion is ZERO with nobody flying — +5% of nothing is a waste.
          if (!_playerShip || _playerShip.evasion <= 0) {
            UI.notify('Golden Ratio — nobody is flying. Man the cockpit first.', 'warn');
            return null;
          }
          return `Golden Ratio ${roman} — ${def.levels[eff - 1]}.`;
        }
        case 'was': {
          const foe = _enemyShip;
          if (!foe || foe.destroyed || foe.hull <= 0 || foe.isDerelict || !foe.reactor) {
            UI.notify('Was Sceptre — there is no live reactor over there.', 'warn');
            return null;
          }
          foe.reactor.drain = def.drain[eff - 1];
          foe.reflowPower?.();
          return `Was Sceptre ${roman} — their reactor −${def.drain[eff - 1]} for ${def.secs[eff - 1]} s.`;
        }
        case 'me': {
          const crew = (_playerShip?.crew ?? []).filter(c =>
            c && c.isPlayer && !c.isPet && !c.dead && !c.dying && c.hp < c.maxHp);
          const heal = def.heal[eff - 1];
          const o2 = _playerShip?.getSystem?.('oxygen');
          const fixO2 = eff === 3 && o2 && o2.damagedLevels > 0;
          const worst = eff === 4 ? (_playerShip?.systems ?? [])
            .filter(x => x && x.damagedLevels > 0)
            .sort((a, b) => b.damagedLevels - a.damagedLevels)[0] : null;
          if (!crew.length && !fixO2 && !worst) {
            UI.notify('ME — nobody is hurt and nothing it could mend is broken.', 'warn');
            return null;
          }
          crew.forEach(c => { c.hp = Math.min(c.maxHp, c.hp + heal); });
          if (fixO2) { o2.damagedLevels--; o2.repairProgress = 0; }
          if (worst) { worst.damagedLevels--; worst.repairProgress = 0; }
          return `ME ${roman} — ${crew.length} healed`
               + (fixO2 ? ', life support a level better' : '')
               + (worst ? `, ${worst.type} a level better` : '') + '.';
        }
        case 'absolute_zero': {
          const sh = _playerShip;
          const heat = sh?.reactorHeat ?? 0;
          const live = (sh?.fires?.fires ?? []).filter(f => !f.out);
          if (heat <= 0 && !live.length) {
            UI.notify('Absolute Zero — the core is cold and nothing is burning.', 'warn');
            return null;
          }
          sh.reactorHeat = Math.max(0, heat - def.cool[eff - 1]);
          const how = def.douse[eff - 1];
          let out = 0;
          const douse = (f) => { if (!f.out) { f.intensity = 0; f.out = true; out++; } };
          if (how === 'all') live.forEach(douse);
          else if (how === 'room') {
            // The module burning worst: most fires, then the hottest.
            const by = new Map();
            live.forEach(f => by.set(f.roomId, (by.get(f.roomId) ?? 0) + f.intensity + 10));
            const worst = [...by.entries()].sort((a, b) => b[1] - a[1])[0]?.[0];
            live.filter(f => f.roomId === worst).forEach(douse);
          } else {
            live.slice().sort((a, b) => b.intensity - a.intensity).slice(0, how).forEach(douse);
          }
          if (def.noIgnite[eff - 1] > 0) sh.fires.noIgniteT = def.noIgnite[eff - 1];
          return `Absolute Zero ${roman} — core ${heatCelsius(heat)} °C → ${heatCelsius(sh.reactorHeat)} °C`
               + (out ? `, ${out} fire(s) out` : '')
               + (def.noIgnite[eff - 1] ? `, no new fire for ${def.noIgnite[eff - 1]} s` : '') + '.';
        }
        case 'westcar':
          return `Westcar Papyrus ${roman} — the way is folded: ${def.secs[eff - 1]} s safe from the rocks.`;
        case 'horus': {
          const foe = _enemyShip;
          if (!foe || foe.destroyed || foe.hull <= 0 || foe.isDerelict) {
            UI.notify('Eye of Horus — there is nobody over there to watch.', 'warn');
            return null;
          }
          const cl = foe.getSystem?.('cloaking');
          /* At I the Eye only strips the cloak, so against a ship with
             none it would buy nothing — refused, not paid for. */
          if (eff === 1 && !cl) {
            UI.notify('Eye of Horus I — they carry no cloak to strip.', 'warn');
            return null;
          }
          let stripped = false;
          if (cl && cl.cloakActive) {
            cl.cloakActive = false; cl.cloakTimer = 0;
            cl.cloakCd = cl.cloakRecharge ? cl.cloakRecharge() : (cl.def?.cloakCooldown ?? 22);
            stripped = true;
          }
          return `Eye of Horus ${roman} — ${def.secs[eff - 1]} s`
               + (stripped ? ', their cloak torn off' : ', they cannot cloak')
               + (eff >= 2 ? ', their aim shown' : '') + (eff >= 3 ? ' with their charge' : '') + '.';
        }
        case 'djed': {
          const sh = _playerShip;
          if (!sh?.reactor) return null;
          sh.reactor.boost = def.power[eff - 1];
          sh.reactorHeat = Math.min(100, (sh.reactorHeat ?? 0) + def.heat[eff - 1]);
          return `Djed Pillar ${roman} — +${def.power[eff - 1]} power for ${def.secs[eff - 1]} s, `
               + `core heat +${def.heat[eff - 1]} (now ${Math.round(sh.reactorHeat)}).`;
        }
        case 'destinies': {
          const foe = _enemyShip;
          if (!foe || foe.destroyed || foe.hull <= 0 || foe.isDerelict) {
            UI.notify('Tablet of Destinies — there is nobody over there to shoot at us.', 'warn');
            return null;
          }
          /* Only missiles and torpedoes are turned aside — against a ship
             that carries neither it would buy nothing: refused, not paid. */
          const heavy = (foe.weapons ?? []).some(w => w?.def && (w.def.type === 'missile' || w.def.type === 'torpedo'));
          if (!heavy) {
            UI.notify('Tablet of Destinies — they carry no missiles or torpedoes.', 'warn');
            return null;
          }
          return `Tablet of Destinies ${roman} — ${def.secs[eff - 1]} s: their missiles and torpedoes pass through us.`;
        }
        case 'cone': {
          const foe = _enemyShip;
          if (!foe || foe.destroyed || foe.hull <= 0) {
            UI.notify('Foundation Cone — there is nobody over there to anchor.', 'warn');
            return null;
          }
          /* Wrecks, things on the ground and the boss never jump away —
             an anchor on them would be Knowledge thrown out. */
          const boss = typeof AI_DEFS !== 'undefined' && CombatManager._ai === AI_DEFS.boss;
          if (foe.isDerelict || foe.layout?.grounded || boss) {
            UI.notify('Foundation Cone — they cannot jump away anyway.', 'warn');
            return null;
          }
          return `Foundation Cone ${roman} — anchored: they cannot jump away for ${def.secs[eff - 1]} s.`;
        }
        case 'va243': {
          if (!_sectorMap?.revealSome) return null;
          const got = _sectorMap.revealSome(def.chance[eff - 1]);
          if (!got.length) {
            UI.notify('VA 243 Seal — nothing on this map is hidden any more.', 'warn');
            return null;
          }
          _saveShip();
          const left = _sectorMap.hiddenNodes().length;
          return `VA 243 Seal ${roman} — ${got.length} hidden node(s) revealed`
               + (left ? `, ${left} still hidden.` : ', the whole map is known.');
        }
        default:
          return null;
      }
    };

    const said = doIt();
    if (said === null) return false;          // refused, and NOT paid for
    const holder = key === 'was' ? _enemyShip : key === 'djed' ? _playerShip : null;
    if (!Chips.markUsed(_commander, key, { ship: holder })) {
      if (key === 'djed' && _playerShip?.reactor) _playerShip.reactor.boost = 0;
      return false;
    }
    Base.saveCommander?.(_commander);
    UI.notify(said, 'good');
    Audio.sfx.uiClick?.();
    return true;
  }

  /* ── THE BOOK (update99) ─────────────────────────────────────
   * jj's "Księga jak w Heroes": B or the BOOK button on the commander
   * bar; the fight STOPS while it is open (`_step`). Tabs by family and
   * one for the orders. Click a tablet = use it; RIGHT click = on/off
   * the quick bar. The renderer owns the layout (`drawTabletBook`), and
   * the click reads the very rectangles it drew.
   */
  /* Its state lives on Chips.book ({ open, tab }) — a global a test (and
     a debugging eye) can reach; the game's export is fixed. */
  const _B = () => (typeof Chips !== 'undefined' && Chips.book) ? Chips.book : { open: false, tab: 'all' };

  /** B opens and closes it. True when the key was taken this frame. */
  function _bookKey() {
    if (!Input.isPressed('KeyB')) return false;
    if (!_commander) { UI.notify('No commander in the chair — no Book.', 'warn'); return true; }
    _B().open = !_B().open;
    Audio.sfx.uiClick?.();
    return true;
  }

  function _bookState(where) {
    return { tab: _B().tab, where, inCombat: where === 'combat' };
  }

  function _drawBook(ctx) {
    Renderer.drawTabletBook(ctx, _commander, _bookState(STATE === 'combat' ? 'combat' : 'map'));
  }

  function _updateBook(where) {
    if (!_commander) { _B().open = false; return; }
    if (Input.isPressed('Escape')) { _B().open = false; return; }
    const left = Input.mouse.leftPressed, right = Input.mouse.rightPressed;
    if (!left && !right) return;
    const r = Renderer.drawTabletBook(_nullCtx(), _commander, _bookState(where));
    const at = (z) => z && Utils.pointInRect(Input.mouse.x, Input.mouse.y, z.x, z.y, z.w, z.h);
    _pressConsumed = true;
    if (left && at(r.close)) { _B().open = false; Audio.sfx.uiClick?.(); return; }
    const tab = r.tabs.find(at);
    if (left && tab) { _B().tab = tab.key; Audio.sfx.uiClick?.(); return; }
    const card = r.cards.find(at);
    if (card) {
      if (card.kind === 'tablet') {
        if (right) {
          const on = Chips.toggleQuick(_commander, card.key);
          Base.saveCommander?.(_commander);
          UI.notify(on ? `${Chips.DEFS[card.key].label} is on the quick bar.`
                       : `${Chips.DEFS[card.key].label} — off the quick bar (it holds ${Chips.QUICK_MAX}).`, 'info');
          return;
        }
        _useTablet(card.key, where);
        return;
      }
      if (card.kind === 'order' && left && where === 'combat') { _giveOrder(card.key); return; }
      return;
    }
    // A click off the panel closes it, like the dossier.
    if (left && !at(r.panel)) { _B().open = false; }
  }

  /* ══ WHAT HAPPENED (update106, jj) ═══════════════════════════
   * An event's outcome used to be a toast or two in the corner, gone in
   * a few seconds. Now, when the choice leaves you on the map, a window
   * says what happened — the event, what was chosen, and every line the
   * outcome produced, in its colour — with a frame for the picture the
   * event will carry later. The player closes it. The lines still go to
   * the log as before; the window is the same words, held still. */
  let _eventResult = null;      // { title, choice, lines: [{ m, t }], art }

  function _resolveEvent(idx) {
    if (!_event) return;
    const ev = _event, choice = ev.choices[idx];
    const said = [];
    const notify = UI.notify;
    UI.notify = function (m, t) { said.push({ m: String(m), t: t || 'info' }); return notify.apply(UI, arguments); };
    try { _resolveEventCore(idx); } finally { UI.notify = notify; }
    if (STATE === 'map' && !_event) {
      _eventResult = { title: ev.title || 'Event', choice: choice?.label || '',
                       lines: said.length ? said : [{ m: 'Nothing came of it.', t: 'info' }],
                       art: ev.art ?? null };
    }
  }

  function _eventResultRects() {
    const W = Renderer.getWidth(), H = Renderer.getHeight();
    const PW = 600, PH = 300, px = W / 2 - PW / 2, py = H / 2 - PH / 2;
    return { panel: { x: px, y: py, w: PW, h: PH },
             art:   { x: px + 20, y: py + 56, w: 160, h: 160 },
             close: { x: px + PW / 2 - 80, y: py + PH - 50, w: 160, h: 32 } };
  }

  /** True while the window is up — it takes the map's input. */
  function _updateEventResult() {
    if (!_eventResult) return false;
    const c = _eventResultRects().close;
    const hit = Input.mouse.leftPressed && Utils.pointInRect(Input.mouse.x, Input.mouse.y, c.x, c.y, c.w, c.h);
    if (hit || Input.isPressed('Enter') || Input.isPressed('Escape')) {
      _eventResult = null;
      Audio.sfx.uiClick?.();
    }
    return true;
  }

  function _drawEventResult(ctx) {
    if (!_eventResult) return;
    const R = _eventResultRects(), P = R.panel, A = R.art;
    ctx.save();
    ctx.fillStyle = 'rgba(4,6,12,0.6)';
    ctx.fillRect(0, 0, Renderer.getWidth(), Renderer.getHeight());
    ctx.fillStyle = 'rgba(13,17,32,0.97)';
    ctx.beginPath(); ctx.roundRect(P.x, P.y, P.w, P.h, 8); ctx.fill();
    ctx.strokeStyle = '#4db8ff'; ctx.lineWidth = 1.5;
    ctx.beginPath(); ctx.roundRect(P.x, P.y, P.w, P.h, 8); ctx.stroke();
    ctx.textAlign = 'left';
    ctx.fillStyle = '#4db8ff'; ctx.font = '15px Orbitron, monospace';
    ctx.fillText(String(_eventResult.title).slice(0, 40), P.x + 20, P.y + 30);
    // The picture's place: an image when the event has one, a frame for now.
    const img = _eventResult.art && typeof Assets !== 'undefined' ? Assets.get?.(_eventResult.art) : null;
    ctx.fillStyle = 'rgba(20,28,46,0.9)';
    ctx.fillRect(A.x, A.y, A.w, A.h);
    if (img) ctx.drawImage(img, A.x, A.y, A.w, A.h);
    else {
      ctx.strokeStyle = '#2a3a58'; ctx.lineWidth = 1;
      ctx.strokeRect(A.x + 0.5, A.y + 0.5, A.w - 1, A.h - 1);
      ctx.fillStyle = '#2a3a58'; ctx.font = '10px Share Tech Mono, monospace';
      ctx.textAlign = 'center';
      ctx.fillText('— image —', A.x + A.w / 2, A.y + A.h / 2 + 4);
      ctx.textAlign = 'left';
    }
    const tx = A.x + A.w + 18, tw = P.x + P.w - 20 - tx;
    let y = A.y + 10;
    if (_eventResult.choice) {
      ctx.fillStyle = '#7a90a8'; ctx.font = '10px Share Tech Mono, monospace';
      ctx.fillText(`You chose: ${_eventResult.choice}`.slice(0, 60), tx, y);
      y += 20;
    }
    const COL = { good: '#1aff8c', warn: '#ffb020', alert: '#ff5566', info: '#c8d8f0' };
    ctx.font = '12px Share Tech Mono, monospace';
    for (const { m, t } of _eventResult.lines) {
      ctx.fillStyle = COL[t] || '#c8d8f0';
      let line = '';
      for (const w of m.split(' ')) {
        const test = line ? line + ' ' + w : w;
        if (line && ctx.measureText(test).width > tw) {
          if (y < A.y + A.h + 10) ctx.fillText(line, tx, y);
          y += 15; line = w;
        } else line = test;
      }
      if (line && y < A.y + A.h + 10) ctx.fillText(line, tx, y);
      y += 19;
    }
    const c = R.close;
    const hot = Utils.pointInRect(Input.mouse.x, Input.mouse.y, c.x, c.y, c.w, c.h);
    ctx.fillStyle = hot ? 'rgba(26,140,255,0.25)' : 'rgba(20,30,50,0.9)';
    ctx.beginPath(); ctx.roundRect(c.x, c.y, c.w, c.h, 4); ctx.fill();
    ctx.strokeStyle = '#4db8ff'; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.roundRect(c.x, c.y, c.w, c.h, 4); ctx.stroke();
    ctx.fillStyle = '#c8e8ff'; ctx.font = '12px Share Tech Mono, monospace';
    ctx.textAlign = 'center';
    ctx.fillText('CLOSE [ENTER]', c.x + c.w / 2, c.y + 21);
    ctx.restore();
  }

  function _resolveEventCore(idx) {
    if (!_event) return;
    const result = _event.choices[idx]?.result ?? {};
    const run = Save.getRun();
    if (!run) { _event = null; STATE = 'map'; return; }

    /* ── THE DECISION IS SCORED ONCE, HERE (update50) ────────
     *
     * Every karma-bearing choice in the game routes through this one
     * function, so this is the only place that has to be right about
     * "jedna decyzja nalicza wynik raz". A karma value on a choice
     * that ALSO resumes combat or opens another screen is still paid
     * exactly here, before any of that happens.
     *
     * A run without a commander moves nothing: karma is personal to a
     * man, and the ones sitting in the mess did not make this call. */
    if (result.karma && _commander && typeof Commander !== 'undefined') {
      const r = Commander.shift(_commander, result.karma);
      if (r) {
        const dir = result.karma > 0 ? 'good' : 'warn';
        let msg = `${_commander.name}: karma ${r.from} → ${r.to}`;
        if (r.killed) msg += ` — ${r.killed} tablet(s) stopped working`;
        else if (r.wallMoved) msg += ' — the Destiny Tablets wall moved';
        UI.notify(msg, dir);
        Base.saveCommander?.(_commander);
      }
    }

    if (result.scrap) {
      // The table declares INCLUSIVE ranges — see Utils.randIn.
      const amt = Array.isArray(result.scrap) ? Utils.randIn(result.scrap[0], result.scrap[1]) : result.scrap;
      Save.updateRun({ scrap: Math.max(0, run.scrap + amt) });
      UI.notify((amt>=0?'+':'')+`${amt} CC`, amt>=0?'good':'warn');
    }
    if (result.fuel) {
      const amt = Array.isArray(result.fuel)
        ? Utils.randIn(result.fuel[0], result.fuel[1]) : result.fuel;
      if (amt < 0) {
        const burned = _burnFuel(-amt);
        UI.notify(`−${burned} He2`, 'warn');
      } else {
        const r = _addFuel(amt);
        UI.notify(_fuelGainMessage(r), r.spilled ? 'warn' : 'good');
      }
    }
    if (result.missiles) {
      const amt = Array.isArray(result.missiles) ? Utils.randIn(result.missiles[0], result.missiles[1]) : result.missiles;
      const r = _addMissiles(amt);
      UI.notify(r.spilled
        ? `+${r.loaded} missiles — ${r.spilled} left behind, no room in the hold`
        : `+${r.loaded} missiles`, r.spilled ? 'warn' : 'good');
    }
    if (result.crew && _playerShip && _playerShip.crew.length < 8) {
      const c = new CrewMember({});
      _playerShip.addCrew(c);
      UI.notify(`${c.name} joined!`, 'good');
    }
    /* AN ANIMAL COMES ABOARD (update45). One per hull — a second cat
       would only halve the first one's work — and it goes straight into
       the crew list, because that is where everything physically aboard
       lives. If the offer had a price and it cannot be paid, nothing
       happens at all rather than half-happening. */
    if (result.pet && _playerShip && typeof makeCat === 'function') {
      const already = _playerShip.crew.some(c => c.isPet && !c.dead);
      const price   = result.cost ?? 0;
      const run     = Save.getRun();
      if (already) {
        UI.notify('You already have an animal aboard — one is the limit.', 'warn');
      } else if (price > 0 && (run?.scrap ?? 0) < price) {
        UI.notify(`Not enough CC — ${price} asked.`, 'warn');
      } else {
        if (price > 0) Save.updateRun({ scrap: (run.scrap ?? 0) - price });
        const cat = makeCat();
        _playerShip.addCrew(cat);
        UI.notify(`${cat.name} is aboard — keep the rations coming.`, 'good');
      }
    }
    /* ── MODULE OFFERS (update38) ──────────────────────────────
     * `system_upgrade`, `cost` and `system_damage` were written into
     * the event table and then never read by anything: accepting the
     * field medic's offer charged nothing, upgraded nothing, and was
     * offered to ships with no medbay at all. Both are handled here
     * now, and the offer itself is filtered before it is ever shown —
     * see eventFits() in map.js.
     */
    if (result.system_upgrade && _playerShip) {
      const sys  = _playerShip.getSystem(result.system_upgrade);
      const cost = result.cost ?? 0;
      const have = Save.getRun()?.scrap ?? 0;
      const max  = sys?.def?.maxLevel ?? 8;
      if (!sys) {
        // Belt and braces: the filter should have kept this off screen.
        UI.notify('Nothing aboard for them to work on — the offer lapses.', 'warn');
      } else if (cost > have) {
        UI.notify(`Not enough CC — they wanted ${cost}.`, 'warn');
      } else if (sys.level >= max) {
        UI.notify(`${sys.label} is already at maximum.`, 'warn');
      } else {
        sys.level += 1;
        sys.desiredPower = Math.max(sys.desiredPower ?? 0, 1);
        if (cost) Save.updateRun({ scrap: have - cost });
        _saveShip();
        UI.notify(`${sys.label} upgraded to level ${sys.level}`
                + (cost ? ` (−${cost} CC)` : ''), 'good');
      }
    }
    if (result.system_damage && _playerShip) {
      // A chance — not a certainty — that the anomaly burns something out.
      const hurtable = _playerShip.systems.filter(s =>
        s.type !== 'reactor' && s.damagedLevels < s.level);
      if (hurtable.length && Math.random() < result.system_damage) {
        const sys = Utils.pick(hurtable);
        sys.damageLevel(1);
        _saveShip();
        UI.notify(`${sys.label} burned out a level!`, 'alert');
      }
    }
    if (result.risk === 'crew_damage' && _playerShip?.crew.length > 0) {
      const target = Utils.pick(_playerShip.crew.filter(c=>!c.dead));
      if (target) { const dmg=Utils.randInt(10,40); target.takeDamage(dmg,'boarding'); UI.notify(`${target.name} took ${dmg} dmg!`,'alert'); }
    }
    if (result.loseCrew && _playerShip && _playerShip.crew.length > 1) {
      const victim = Utils.pick(_playerShip.crew.filter(c => !c.dead));
      if (victim) {
        _playerShip.crew = _playerShip.crew.filter(c => c !== victim);
        // addToGraveyard takes the CREW MEMBER, not a name: it deep-clones
        // `crewMember.skills`, and deepClone(undefined) throws, so handing
        // somebody over as tribute crashed the event mid-resolution.
        victim.killedBy = 'handed over as tribute';
        Save.addToGraveyard?.(victim);
        UI.notify(`${victim.name} was handed over…`, 'alert');
      }
    }
    /* A GUN YOU WERE GIVEN LANDS WHERE YOU CAN SEE IT (update75).
       It used to go onto the weightless rack, which is why the player
       reported that a surrendering crew handing over their gun gave him
       nothing: the gun existed, in a list drawn nowhere. It is a crate
       in the hold now — and if the hold is full, he is told so and can
       come back for it, rather than being quietly given nothing. */
    if (result.weaponReward && _playerShip) {
      const label = WEAPON_DEFS[result.weaponReward]?.label ?? 'A gun';
      if (_playerShip.boxWeapon(result.weaponReward)) {
        UI.notify(`${label} boxed into the hold — fit it at a station`, 'good');
      } else {
        /* A FULL HOLD OPENS THE HOLD (update106, jj). "They kept it" threw
           the gun away for the player; he gets the cargo screen instead,
           with the gun in the prize locker, to make room or leave it. */
        _queueWeaponLocker(result.weaponReward);
        UI.notify(`${label} — the hold is full: make room for it`, 'warn');
      }
    }
    if (result.startPending && _pendingCombat) {
      const pc = _pendingCombat; _pendingCombat = null;
      _event = null;
      _startCombat(pc.difficulty, pc.nebula);
      return;
    }
    if (result.resumeCombat) {
      _event = null;
      STATE = 'combat';
      /* No mercy given — a cornered crew storms YOUR ship instead.
       *
       * UP TO THREE, NOT EXACTLY TWO (update79). The number was written
       * out here as `-2` while the player's own boarding party was
       * `0, 3` at the other end of the file: the enemy could never
       * fill one of your compartments, so a counter-boarding was
       * always a fight you outnumbered. Both ends read
       * `Ship.ROOM_SLOTS` now — they send as many as can stand in one
       * of your modules, which is the same number for the same reason.
       *
       * They always keep somebody aboard: an empty hull is a derelict,
       * and a "boarding party" that abandons its own ship is a
       * different event with a different ending. */
      if (_enemyShip && !_counterBoarded && _enemyShip.crew.length > 1 &&
          Math.random() < 0.6) {
        _counterBoarded = true;
        const alive  = _enemyShip.crew.filter(c => c.alive);
        const send   = Math.min(Ship.ROOM_SLOTS, alive.length - 1);
        const troops = send > 0 ? alive.slice(-send) : [];
        troops.forEach(c => {
          _enemyShip.crew = _enemyShip.crew.filter(k => k !== c);
          c._waypoints = []; c.task = TASK.IDLE;
        });
        if (troops.length) {
          // give them back for the muster walk — _makeParty removes
          // them from the roster only when they step outside
          troops.forEach(c => { if (!_enemyShip.crew.includes(c)) _enemyShip.crew.push(c); });
          _enemyParty = _makeParty(_enemyShip, _playerShip, troops);
          if (_enemyParty) UI.notify('⚠ Enemy assault team is heading for their airlock!', 'alert');
        }
      }
      return;
    }
    if (result.acceptSurrender) {
      _event = null;
      _endCombatPeacefully();
      return;
    }
    // ── Distress beacon outcomes ─────────────────────────────
    if (result.sosRetry) {          // couldn't afford it — beacon stays up
      _event = null;
      _maybeSOS(true);
      return;
    }
    if (result.sosTradeWeapon) {
      _event = null;
      /* The trader takes a BOXED gun out of the hold, and the cells it
         was sitting on come back — the trade is now worth something
         twice over (update75). */
      const crate = _playerShip?.boxedGuns()[0] ?? null;
      const gun   = crate ? crate.meta : null;
      if (crate) _playerShip.cargo.remove(crate);
      const gain = gun ? 5 : 2;
      const r = _addFuel(gain);
      UI.notify((gun ? `Traded a spare weapon for ` : `They took pity: +`)
              + `${r.loaded} He2` + (r.spilled ? ` — ${r.spilled} would not fit` : ''),
              r.spilled ? 'warn' : 'good');
      STATE = 'map';
      return;
    }
    if (result.sosFight) {
      _event = null;
      // Win the fight and you take their tanks (handled in _onWin plus
      // this guaranteed top-up, so the fight is always worth it).
      _sosFightPending = true;
      _startCombat(_difficulty(), false);
      return;
    }
    if (result.sosBeg) {
      _event = null;
      // Always yields SOMETHING — this branch is what stops an empty
      // tank from ending the run outright.
      const alms = Utils.randIn(1, 2);        // really 1 OR 2 now
      const toll = Math.min(run.scrap, Utils.randIn(0, 10));
      const r = _addFuel(alms);
      Save.updateRun({ scrap: Math.max(0, run.scrap - toll) });
      UI.notify(toll > 0
        ? `They spare ${r.loaded} He2 — and help themselves to ${toll} CC`
        : `They spare ${r.loaded} He2. Barely enough.`, toll > 0 ? 'warn' : 'good');
      STATE = 'map';
      return;
    }
    if (result.destroyDerelict) {
      _event = null;
      STATE = 'combat';
      /* HIS BODY, IF THE HOLD WILL TAKE IT (update63). Two cells, and
         a full hold means it stays out there — said out loud, because
         a bounty that silently never arrives reads as a bug. */
      if (result.takeBody) _bagCommander();
      if (_enemyShip) {
        const sector = Save.getRun()?.sector ?? 1;
        const bonus = Utils.randInt(25, 40 + sector * 8);
        CombatManager.scrapReward = (CombatManager.scrapReward ?? 0) + bonus;
        _enemyShip.hull = 0;
        _enemyShip.destroyed = true;
      }
      UI.notify('Finishing off the wreck for CC…', 'warn');
      return;
    }
    if (result.dockWreck) {
      // A derelict found on the MAP: dock with it, then WALK THROUGH it.
      _event = null;
      const sector = Save.getRun()?.sector ?? 1;
      _beginDocking(sector, {
        seconds: result.seconds ?? Ship.LOOT_SECONDS,
        rich: !!result.rich,
        // The mining barge sets this and nothing ever read it.
        hazard: !!result.hazard,
        title: 'DOCKING WITH THE DERELICT',
      });
      return;
    }
    if (result.searchDerelict) {
      _event = null;
      /* LOCK HIM UP BEFORE THE HOLD SCREEN OPENS. Doing it after would
         hand the player a loot screen and only then tell him the cell
         was taken by somebody else in the meantime. */
      if (result.capture) _lockUpCommander();
      // Used to be a single dice roll and a line of text. Now you
      // actually go aboard: two holds, a clock, and only so many cells.
      const sector = Save.getRun()?.sector ?? 1;
      _openWreckLoot(sector);
      return;
    }
    /* ── HIS HOLD, INSTEAD OF HIS HEAD (update70) ────────────
       Handled before `combat` below, because the trade is the door
       that does NOT end in a fight. */
    if (result.blackMarket) {
      _event = null;
      _openBlackMarket(result.blackMarket);
      return;
    }
    if (result.combat) {
      _event = null;
      /* ACCEPTING AND THEN SHOOTING IS A REAL ADVANTAGE, and it is
         paid for in karma above (`result.karma`), not here. `ambush`
         is passed into the fight rather than applied afterwards: the
         shields are raised inside `_startCombat`, so lowering them
         from out here would be a second opinion about the same
         bubble, applied a frame later. */
      _startCombat(result.combat === 'easy' ? 'normal' : result.combat, _nebulaCombat,
                   { ambush: !!result.ambush });
      return;
    }
    _pendingCombat = null;
    _event = null;
    STATE = 'map';
  }

  /** Enemy surrendered — take the tribute, let them limp away. */
  /* ── MOON RATS ────────────────────────────────────────────
     A heavily loaded hold is a place to hide, and a hold that smells
     of rations is a place worth hiding in. Both halves of the player's
     report are here: the fuller the hold the likelier they are, and
     food makes it likelier still.

     Deliberately a per-JUMP roll rather than a per-frame one: a jump
     is when the ship is open, and it is the one moment the player is
     already reading notifications. */
  const RAT_FILL_FLOOR   = 0.5;   // below half empty, nothing comes aboard
  const RAT_MAX_CHANCE   = 0.22;  // at a completely full hold
  const RAT_FOOD_BONUS   = 0.09;  // per ration pack aboard
  const RAT_FOOD_CAP     = 0.27;
  const RAT_MAX_ABOARD   = 4;

  /** The odds of picking up a stowaway on this jump. Exposed for tests. */
  function _ratChance(hold) {
    if (!hold || !hold.capacity) return 0;
    const fill = hold.usedCells() / hold.capacity;
    if (fill < RAT_FILL_FLOOR) return 0;
    let p = ((fill - RAT_FILL_FLOOR) / (1 - RAT_FILL_FLOOR)) * RAT_MAX_CHANCE;
    const food = hold.items.filter(it => it.def?.tag === 'food' && !it.damaged).length;
    if (food) p += Math.min(RAT_FOOD_CAP, food * RAT_FOOD_BONUS);
    /* A CAT ABOARD IS A DETERRENT, NOT A CURE (update45). It takes
       twelve points off the roll and cannot take it to zero: a hold
       packed to the roof is still a hold packed to the roof, and the
       cat's real job is what it does to the rats that DO get aboard. */
    if (typeof CAT_TUNING !== 'undefined' &&
        _playerShip?.crew?.some(c => c.isPet && !c.dead)) {
      p = Math.max(0, p - CAT_TUNING.RAT_SPAWN_CUT);
    }
    return Utils.clamp(p, 0, 0.6);
  }

  /** Roll for stowaways. Called once per real jump. */
  function _rollForRats() {
    const ship = _playerShip;
    const hold = ship?.cargo;
    if (!ship || !hold) return 0;

    const aboard = ship.pests.filter(p => p.isRat && !p.dead).length;
    /* (A rat aboard used to spoil a ration here, once a jump, on a coin
       toss. Since update86 it EATS — all the time, one portion at a
       meal, and grows on it: Ship._ratLife. Two ways for a rat to take
       food would have been two answers to how much it costs you.) */

    if (aboard >= RAT_MAX_ABOARD) return 0;
    if (Math.random() >= _ratChance(hold)) return 0;

    const n = Math.min(Utils.randInt(1, 3), RAT_MAX_ABOARD - aboard);   // 1..2
    const rooms = ship.rooms.filter(r => r.system).length
                ? ship.rooms.filter(r => r.system) : ship.rooms;
    if (!rooms.length) return 0;
    /* STRAIGHT INTO THE DUCTS (update84). They used to be put on the
       deck as hostile crew; they are pests now, and a pest lives in
       the duct over a module. */
    for (let i = 0; i < n; i++) {
      const room = rooms[(i + Utils.randInt(0, rooms.length)) % rooms.length];
      ship.addPest(new Pest({
        kind: 'rat', roomId: room.id,
        level: Utils.randInt(1, 3),          // 1..2: stowaways, not the breeding stock of years
        x: room.cx + Utils.randFloat(-16, 16),
      }));
    }
    UI.notify(n > 1
      ? `Moon rats in the ducts — ${n} of them, came aboard with the cargo.`
      : 'Something is moving in the ducts. A moon rat came aboard with the cargo.',
      'alert');
    Audio.sfx.bossWarning?.();
    return n;
  }

  /* THE VIRUS CLOCK LEFT THIS FILE (update69).
   *
   * `_tickInfections()` stood here and ran once per won fight: it aged
   * every bite by one battle and every egg case by one battle. That is
   * why a man could only ever turn in the quiet after a victory, and
   * why the roster printed a number of FIGHTS that nothing on screen
   * explained. It is `Ship.infectionTick(dt)` now — seconds, ticking
   * whenever the hull is flying and stopped dead while she is docked,
   * because the hull's own update IS the contract.
   *
   * Deleted rather than left as a wrapper: three call sites that each
   * aged a disease by "one fight" are three ways of disagreeing with a
   * clock that already exists.
   */
  /**
   * Leaving a derelict, by ANY door — put the mode back.
   *
   * This used to be called from exactly one place (_endCombatPeacefully),
   * so retreating from a hulk left `_wreckMode` armed with the old
   * `_wreckLoot` grid still loaded. The next time you wiped an enemy
   * crew, the "the nest is dead, take the hold" check fired instead of
   * the derelict offer: it handed you the PREVIOUS wreck's hold for
   * free, skipped _onWin entirely (no CC, no weapon drop) and deleted a
   * live enemy ship mid-fight. It survived _onLose too, so it could
   * carry into a different contract.
   */
  function _clearWreckMode() {
    _wreckMode = false; _wreckLoot = null; _wreckLooted = false;
  }

  function _endCombatPeacefully() {
    _recoverBoarders();
    CombatManager.end();
    if (_enemyShip) Particles.floatText(
      _enemyShip.worldX + 150, _enemyShip.worldY + 80, 'SURRENDERED', '#1aff8c', 14);
    _enemyShip = null;
    _playerShip.reactor.penalty = 0;
    _nebulaCombat = false;
    // Nobody threw a punch — nobody learns to punch. (See combat.js.)
    _clearWreckMode();
    _leaveFight();
    Audio.playMusic('explore');
  }

  // ── CARGO / LOOT ──────────────────────────────────────────

  let _lootReturn = 'map';   // where to go when the loot screen closes

  /**
   * Open a container and use it. Returns { ok, message, consumed } —
   * `consumed:false` means the item survives with fewer units in it,
   * which is how a 10-dose medkit works.
   */
  function _unpackCargo(item) {
    const run = Save.getRun();
    const k   = item.def.kind;

    if (k === 'fuel') {
      /* THERE IS NO TANK ANY MORE (update39). He2 works exactly like
         warheads: the drive feeds straight out of the cells sitting in
         the hold. Pouring a canister into a counter was the last place
         a cargo item turned into an invisible number, and it meant you
         could jump with an empty hold. */
      return { ok: false, message: 'The drive feeds straight from these cells' };
    }

    if (k === 'missiles') {
      // Nothing to open — the launchers feed from the rack where it lies.
      return { ok: false, message: 'The launchers already feed from this rack' };
    }

    if (k === 'scan') {
      /* A SURVEY PROBE (update39). You arrive in a sector able to see
         the jump in front of you and a smudge one step past it; this
         is what buys you the rest of the map. One shot, and the sector
         you are IN is the one it resolves. */
      if (!_sectorMap) return { ok: false, message: 'Nothing to survey out here' };
      if (!_sectorMap.revealAll()) {
        return { ok: false, message: 'This sector is already surveyed' };
      }
      _saveShip();
      return { ok: true, consumed: true,
               message: `Probe away — Sector ${Save.getRun()?.sector ?? '?'} resolves` };
    }

    if (k === 'heal') {
      /* ── MEDICINE CURES THE PLAGUE FIRST (update68) ──────────
       *
       * A dose only ever added hit points, and the player was right
       * that this is weak: "teraz dodają hp, co jest słabe — mamy do
       * tego jedzenie". Food and the medbay already put HP back. What
       * nothing aboard could do was clear the corpse plague, so a
       * carrier stayed a carrier for the rest of the run.
       *
       * So a dose does the thing only medicine can do, and falls back
       * to patching a wound when nobody is ill. The VIRUS is not on
       * this list on purpose — a void-spider bite is meant to be a
       * clock you cannot buy your way out of, and a station clinic is
       * still the only cure for it.
       */
      const sick = _playerShip?.crew
        .filter(c => c.isPlayer && !c.dead && c.infected && !c.virus)[0];
      if (sick) {
        sick.infected = false;
        sick._infT = 0;
        if (item.isStack) item.qty -= 1;
        const left0 = item.isStack ? item.qty : 0;
        return { ok: true, consumed: !item.isStack || left0 <= 0,
                 message: `${sick.name} is over the plague`
                        + (item.isStack ? ` — ${left0} dose(s) left` : '') };
      }

      // YOUR medkit, YOUR people (update42). Unfiltered, this picked
      // the most wounded body aboard — which after a boarding fight is
      // usually the enemy who is bleeding on your floor, or a rat.
      const hurt = _playerShip?.crew
        .filter(c => c.isPlayer && !c.dead && c.hp < c.maxHp)
        .sort((a, b) => a.hp - b.hp)[0];
      if (!hurt) return { ok: false, message: 'Nobody needs patching up or curing' };
      const dose = item.def.healPerDose ?? item.def.amount ?? 25;
      hurt.heal(dose);
      if (item.isStack) item.qty -= 1;
      const left = item.isStack ? item.qty : 0;
      return { ok: true, consumed: !item.isStack || left <= 0,
               message: `${hurt.name} patched up`
                      + (item.isStack ? ` — ${left} dose(s) left` : '') };
    }

    if (k === 'weapon') {
      const wk = item.meta;
      if (!wk || !_playerShip) return { ok: false, message: 'The crate is empty' };
      // A gun is either BOLTED ON or BOXED — never floating in an
      // abstract rack. Unboxing therefore means FITTING it, and that
      // needs a free weapon mount.
      let slot = -1;
      for (let i = 0; i < _playerShip.weaponSlots; i++) {
        if (!_playerShip.weapons[i]) { slot = i; break; }
      }
      if (slot === -1) {
        return { ok: false,
                 message: 'Every weapon mount is full — it stays in its crate' };
      }
      if (!_playerShip.installWeapon(wk, slot)) {
        return { ok: false, message: 'That mount will not take it' };
      }
      // Take the crate out HERE, not only in the loot screen — any other
      // caller would otherwise fit the gun and leave the crate behind.
      _playerShip.cargo?.remove(item);
      const label = (typeof WEAPON_DEFS !== 'undefined' && WEAPON_DEFS[wk]?.label) || 'Gun';
      return { ok: true, consumed: true,
               message: `${label} unboxed and fitted to mount ${slot + 1}` };
    }
    return { ok: false, message: 'Nothing to open — sell it instead' };
  }

  /**
   * Keep the HUD's missile figure equal to what is actually in the racks.
   * Writes ONLY when the two disagree — Save.updateRun hits localStorage,
   * so this is safe to call every frame as a backstop.
   */
  function _syncAmmo() {
    if (!_playerShip?.cargo) return;
    const run = Save.getRun();
    if (!run) return;
    const real = _playerShip.missileCount();
    if (run.missiles !== real) Save.updateRun({ missiles: real });
  }

  /**
   * The same, for He2 (update39). `run.fuel` is a MIRROR of the cells
   * in the hold now, kept only so the HUD, the shop and old saves keep
   * working — never the source of truth.
   */
  function _syncFuel() {
    if (!_playerShip?.cargo) return;
    const run = Save.getRun();
    if (!run) return;
    const real = _playerShip.fuelCount();
    if (run.fuel !== real) Save.updateRun({ fuel: real });
  }

  /** He2 aboard right now. Falls back to the counter on a hull with no
   *  grid, so nothing can strand a ship that has no hold at all. */
  function _fuelAboard() {
    if (_playerShip?.cargo) return _playerShip.fuelCount();
    return Save.getRun()?.fuel ?? 0;
  }

  /**
   * Burn He2 out of the cells. Returns how much was actually drawn —
   * ask for one, get zero, and you did not jump.
   */
  function _burnFuel(n = 1) {
    const hold = _playerShip?.cargo;
    if (!hold) {
      const run = Save.getRun();
      if (!run) return 0;
      const took = Math.min(n, run.fuel);
      Save.updateRun({ fuel: run.fuel - took });
      return took;
    }
    const took = hold.takeStack('fuel', n);
    _syncFuel();
    return took;
  }

  /**
   * Put He2 aboard, in cells. Reports what did NOT fit rather than
   * quietly inflating a counter — same contract as _addMissiles.
   */
  function _addFuel(n) {
    const hold = _playerShip?.cargo;
    if (!hold) {
      const run = Save.getRun();
      if (run) Save.updateRun({ fuel: run.fuel + n });
      return { loaded: n, spilled: 0 };
    }
    // Small bottles first: they slot into the gaps a full hold leaves.
    let left = n;
    for (const key of ['he2_med', 'he2_small', 'he2_large']) {
      if (left <= 0) break;
      left = hold.addStack(key, left);
    }
    _syncFuel();
    return { loaded: n - left, spilled: left };
  }

  /** One line for "+n He2, m left behind". Used by every fuel payout. */
  function _fuelGainMessage(r) {
    return r.spilled
      ? `+${r.loaded} He2 — ${r.spilled} left behind, no room in the hold`
      : `+${r.loaded} He2`;
  }

  /**
   * Put missiles aboard. The hold is a real constraint, so this reports
   * what did NOT fit instead of quietly inflating a counter.
   */
  function _addMissiles(n) {
    const hold = _playerShip?.cargo;
    if (!hold) {
      const run = Save.getRun();
      if (run) Save.updateRun({ missiles: run.missiles + n });
      return { loaded: n, spilled: 0 };
    }
    const left = hold.addStack('missile_rack', n);
    _syncAmmo();
    return { loaded: n - left, spilled: left };
  }

  /**
   * A gun you were GIVEN (a battlefield recovery) arrives in a locker,
   * exactly like a wreck's hold: you have to physically find room for it.
   * Queued rather than opened on the spot, because the fight is still
   * unwinding when the drop is rolled.
   */
  let _pendingLocker = null;
  let _queuedChip    = null;   // a boss chip with nowhere to go yet
  /* Have our boarders been pulled off the wreck this fight? Cleared
     where a fight begins, beside every other per-battle flag. */
  /* Has the enemy commander already sealed his ship this fight? One
     order per boarding action, cleared where every other per-battle
     flag is. */
  let _enemySealed = false;
  let _rescued       = null;   // what Re-Atum brought home last (update103)
  let _evacT         = 0;      // escape-pod countdown, seconds left
  let _evacSecs      = 0;      // what it started at, for the bar

  function _queueWeaponLocker(defKey) { _pendingLocker = defKey; }

  /**
   * A chip the hold could not take, shown as a one-cell locker beside
   * it. Same screen, same rules: he moves it across or he decides what
   * to drop for it. He cannot leave with it unresolved — the reward
   * has to end up somewhere the player chose.
   */
  function _openChipLocker(chipKey) {
    if (typeof LootScreen === 'undefined' || !_playerShip?.cargo) return;
    const probe  = new CargoItem(chipKey);
    const locker = new CargoGrid(Math.max(4, probe.w), Math.max(2, probe.h));
    locker.add(chipKey);
    const back = STATE === 'loot' ? 'map' : STATE;
    _lootReturn = back;
    LootScreen.openLoot(locker, _playerShip.cargo, {
      title: 'REWARD — ANCIENT TABLET',
      subtitle: 'make room in the hold · a tablet is only mounted at base',
      leftLabel: 'NAGRODA',
      holdLabel: 'SHIP HOLD',
      takeAllLabel: 'TAKE IT',
      portType: 'general',
      onClose: ({ wreck }) => {
        // Still in the locker? He chose not to take it; say so plainly
        // rather than pretending it went somewhere.
        if (wreck?.items?.length) UI.notify('Tablet left behind.', 'warn');
        STATE = back; _beginFade(); _saveShip();
      },
    });
    STATE = 'loot'; _beginFade();
  }

  function _openWeaponLocker(defKey) {
    /* The fallback DELETED (update75). It read "no cargo system — fall
       back to the abstract rack", and the rack is gone. What is left of
       it is the one honest half: with no loot screen there is nothing
       to open, so box the gun straight into the hold and say where it
       went. */
    if (typeof LootScreen === 'undefined' || !_playerShip?.cargo) {
      if (_playerShip?.boxWeapon(defKey)) {
        UI.notify('Weapon recovered — boxed into the hold', 'good');
      } else {
        UI.notify('Weapon recovered, but the hold is full — left behind', 'warn');
      }
      return;
    }
    const crateKey = (typeof cargoCrateForWeapon === 'function')
      ? cargoCrateForWeapon(defKey) : 'gun_crate';
    const probe  = new CargoItem(crateKey);
    const locker = new CargoGrid(Math.max(3, probe.w), Math.max(3, probe.h));
    locker.add(crateKey, defKey);

    const wdef = (typeof WEAPON_DEFS !== 'undefined' && WEAPON_DEFS[defKey]) || {};
    const back = STATE === 'loot' ? 'map' : STATE;
    _lootReturn = back;
    LootScreen.openLoot(locker, _playerShip.cargo, {
      title: 'SALVAGED WEAPON',
      subtitle: 'click to pick up, click to put down · R rotates · anything left in the '
              + 'locker stays on the wreck',
      leftLabel: 'PRIZE LOCKER',
      takeAllLabel: 'TAKE IT',
      doneLabel: 'DONE',
      intro: `${wdef.label ?? 'A gun'} recovered — find room for it.`,
      onUnpack: _unpackCargo,
      onClose: ({ wreck }) => {
        const left = wreck?.items?.length ?? 0;
        if (left) UI.notify('No room — the gun stays behind.', 'warn');
        STATE = back; _beginFade();
        _saveShip();
      },
    });
    STATE = 'loot'; _beginFade();
  }

  // ── DERELICTS: dock, board, search every compartment, strip the hold ──

  let _dockPending = null;   // { sector, seconds, rich, title }
  let _wreckMode   = false;  // the "enemy" is a derelict, not a fight
  let _wreckLoot   = null;   // its hold, generated up front
  /* Set by `_startWreckBoarding` before anything reads it — the value
     here is never the one used. Seeded from the constant anyway so a
     future reader that arrives early gets a sane clock rather than a
     zero, which would read as "out of time" the moment it was shown. */
  let _wreckSecs   = Ship.LOOT_SECONDS;
  let _wreckLooted = false;

  /** Step 1: line up on the hulk. */
  function _beginDocking(sector, opts = {}) {
    if (typeof DockingGame === 'undefined') {   // module missing — skip it
      _startWreckBoarding(sector, opts);
      return;
    }
    _dockPending = { sector, ...opts };
    DockingGame.open({ sector, title: opts.title || 'DOCKING MANOEUVRE' });
    STATE = 'docking'; _beginFade();
  }

  function _updateDocking(dt) {
    const res = DockingGame.update(dt);
    if (!res) return;
    const pend = _dockPending || { sector: 1 };
    _dockPending = null;

    if (res === 'abort') {
      UI.notify('Broke off the approach.', 'warn');
      STATE = 'map'; _beginFade();
      return;
    }

    const out = DOCK_OUTCOMES[res] || DOCK_OUTCOMES.ok;
    if (out.hullDamage && _playerShip) {
      _playerShip.hull = Math.max(1, _playerShip.hull - out.hullDamage);
    }
    // Auto-dock burns He2 out of the cells like any other burn.
    if (out.fuel) _burnFuel(out.fuel);
    UI.notify(out.message, res === 'bad' ? 'warn' : 'good');

    _startWreckBoarding(pend.sector, {
      ...pend,
      seconds: Math.max(Ship.LOOT_SECONDS_MIN, (pend.seconds ?? Ship.LOOT_SECONDS) + out.bonusSeconds),
    });
  }

  /**
   * Step 2: the derelict is a REAL ship you walk through. It has no guns
   * and no power, but it has a nest in it — so this reuses the whole
   * boarding stack (BOARD, melee, oxygen, RECALL) rather than inventing
   * a second one.
   */
  function _startWreckBoarding(sector, opts = {}) {
    /* NOBODY COMMANDS A WRECK (update90b). The last fight's commander was
       cleared only on a win; one that ran — or that we ran from — was
       still "the enemy" when the next wreck came up, and his badge hung
       over the hulk ("na wrakach jest nieraz ikona kapitana"). */
    Commander?.setEnemy?.(null);
    _enemyShip = makeDerelict(sector);
    const nest = opts.nest ?? derelictNestKind();
    populateDerelict(_enemyShip, sector, nest);
    // Where our party comes aboard — and where a survivor is carried to (update90b).
    _enemyShip.dockRoomId = _wreckDockRoomId();
    if (Math.random() < WRECK_SURVIVOR_SHARE) placeSurvivor(_enemyShip, _enemyShip.dockRoomId);
    _wreckMode   = true;
    _wreckLooted = false;
    _wreckSecs   = opts.seconds ?? Ship.LOOT_SECONDS;
    const lean = nest === 'rat';
    _wreckLoot   = makeWreckGrid(sector, opts.rich
      ? { cols: 5, rows: 4, tries: Utils.randInt(4, 7 + sector), lean } : { lean });

    _playerShip.resetShieldDebt();   // update97: our bubble as we brought it
    _playerShip.markCombatStart();
    _surrenderAsked  = true;    // nothing aboard to surrender
    _derelictOffered = true;    // we go straight to the hold, no dialog
    _boardingParty = null; _enemyParty = null;

    CombatManager.begin(_playerShip, _enemyShip, 'normal');
    CombatManager.scrapReward = 0;
    CombatManager.weaponDrop  = null;
    CombatManager.enemyEscapeActive = false;

    STATE = 'combat'; _beginFade();
    _combatTimer = 0; _combatFired = false;
    Audio.playMusic('explore');
    /* NO HEAD COUNT. The sacs are hidden until somebody walks into the
       room with them, so handing the player an exact number on the way
       in gave away the one thing the boarding action is FOR. And the
       air warning is gone with the coin flip that used to decide it —
       a derelict always has one unit of power, and it runs life
       support (see wreck.js makeDerelict).
       NOTHING IS BURNING EITHER (update39) — see wreck.js. */
    UI.notify(nest === 'rat'
      ? 'Docked. Her hull is cold and the ducts are squeaking — rats have had this one. '
        + 'Send a boarding party through every compartment.'
      : 'Docked. Her hull is cold and something is living in the ducts — '
        + 'send a boarding party through every compartment.', 'alert');
  }

  /** Step 3: every compartment searched — take the hold. */
  function _wreckCleared() {
    _wreckLooted = true;
    // One hull stripped — the side objective reads this, not a count
    // of crates, because the crates are the player's decision (update71).
    Save.goalEvent?.('wrecks');
    _recoverBoarders();
    CombatManager.end();
    const grid = _wreckLoot || makeWreckGrid(Save.getRun()?.sector ?? 1);
    _wreckLoot = null;
    LootScreen.openLoot(grid, _playerShip.cargo, {
      title: 'THE HOLD',
      subtitle: 'every compartment searched · take what fits before she breaks up',
      leftLabel: 'DERELICT HOLD',
      timerLabel: 'HULL BREAKING UP',
      doneLabel: 'CAST OFF',
      seconds: _wreckSecs,
      intro: 'Hulk searched. The hold is yours.',
      onUnpack: _unpackCargo,
      onClose: () => {
        _enemyShip = null;
        _wreckMode = false;
        _playerShip.reactor.penalty = 0;
        _leaveFight(); _beginFade();
        _saveShip();
      },
    });
    STATE = 'loot'; _beginFade();
  }

  /** Look at (and tidy) your own hold between jumps. */
  function _openHold() {
    if (!_playerShip?.cargo) { UI.notify('No cargo hold on this hull', 'warn'); return; }
    _lootReturn = STATE;
    LootScreen.openHold(_playerShip.cargo, {
      title: 'CARGO HOLD',
      subtitle: 'click to pick up, click again to put down · R rotates · SPLIT halves a stack',
      doneLabel: 'CLOSE',
      onUnpack: _unpackCargo,
      onClose:  () => { STATE = _lootReturn; _beginFade(); _saveShip(); },
    });
    STATE = 'loot'; _beginFade();
  }

  /**
   * Board a dead-but-intact hull and strip its hold.
   * opts.returnTo  — 'combat' (after a fight) or 'map' (a map event)
   * opts.seconds   — clock; opts.hazard shortens it; opts.rich fattens the hold
   */
  function _openWreckLoot(sector, opts = {}) {
    /* ── BOARD IT, OR BLOW IT (update105, jj 08.10) ──────────────
     * A crew wiped out leaves two doors: search her hold, or finish her
     * and send men out to the crates. ONE or the other — the search used
     * to be followed by the same crates once she was cast off. And the
     * search is USUALLY THE BETTER HAUL: she is intact, so her whole hold
     * is there (the medicine too, which mostly burns in a blast), her gun
     * is on its rack, and the derelict hold is a size larger than the
     * random lot. The price is the clock and the room in your own hold. */
    const her = _enemyShip && !_enemyShip.destroyed ? _enemyShip : null;
    const sizeUp = her ? 1 : 0;
    const base = { cols: Utils.clamp(3 + Math.floor(sector / 2), 3, 5) + sizeUp,
                   rows: Utils.clamp(3 + Math.floor(sector / 3), 3, 4) + sizeUp };
    let wreck;
    if (her) {
      /* HERS FIRST, then what else is lying about: her gun and her own
         hold are put in before the random lot, so they always fit. */
      her._searched = true;          // no crates after this: see _salvageWillSpawn
      wreck = new CargoGrid(base.cols, base.rows);
      const gun = CombatManager.weaponDrop;
      if (gun) {
        CombatManager.weaponDrop = null;
        const box = (typeof cargoCrateForWeapon === 'function') ? cargoCrateForWeapon(gun) : null;
        if (!box || !wreck.add(box, gun)) _queueWeaponLocker(gun);   // never lost
      }
      (her.cargo?.items ?? []).forEach(it => wreck.add(it.defKey, it.meta ?? null, it.qty ?? null));
      makeWreckGrid(sector, { ...base, tries: Utils.randIn(5, 8 + Math.floor(sector / 2)) })
        .items.forEach(it => wreck.add(it.defKey, it.meta ?? null, it.qty ?? null));
    } else {
      wreck = makeWreckGrid(sector, opts.rich
        ? { cols: 6, rows: 5, tries: Utils.randInt(8, 12 + sector) } : {});
    }
    // A wreck sometimes still has a gun in a crate — the old
    // "jackpot" roll, but now it has to physically fit in your hold.
    if (Math.random() < 0.22) {
      const wk = (typeof randomWeaponDrop === 'function') ? randomWeaponDrop(sector) : null;
      if (wk) wreck.add(cargoCrateForWeapon(wk), wk);
    }

    let intro = 'Salvage team aboard. Take what fits.';
    // The booby trap survives from the old event — it just costs you
    // time on the clock now instead of ending the scene.
    let seconds = opts.seconds ?? Ship.LOOT_SECONDS;
    if (Math.random() < 0.18) {
      const target = _playerShip?.crew.find(c => !c.dead);
      const dmg    = Utils.randInt(8, 18);
      if (target) {
        target.takeDamage(dmg, 'boarding');
        intro = `Booby trap! ${target.name} took ${dmg} — and you are on the clock.`;
        seconds = Math.min(seconds, 32);
      }
    }

    // Survivors still turn up, but they walk aboard before the hold
    // is opened, so this never competes with the salvage itself.
    if (Math.random() < 0.20 && _playerShip && _playerShip.crew.length < 8) {
      const c = new CrewMember({});
      _playerShip.addCrew(c);
      UI.notify(`Found a survivor in the wreck — ${c.name} joins your crew!`, 'good');
    }

    const back = opts.returnTo ?? 'combat';
    _lootReturn = back;
    LootScreen.openLoot(wreck, _playerShip.cargo, {
      title: opts.title || 'BOARDING THE DERELICT',
      subtitle: 'click a crate, click a cell · R rotates · the clock is running',
      leftLabel: 'DERELICT HOLD',
      timerLabel: 'HULL BREAKING UP',
      doneLabel: 'CAST OFF',
      seconds, intro,
      onUnpack: _unpackCargo,
      onClose: () => {
        if (back === 'combat' && _enemyShip) {
          _enemyShip.hull = 0; _enemyShip.destroyed = true;
        }
        STATE = back; _beginFade();
        _saveShip();
      },
    });
    STATE = 'loot'; _beginFade();
  }

  function _updateLoot(dt) {
    if (typeof LootScreen === 'undefined') { STATE = _lootReturn || 'map'; return; }
    if (_lootReturn === 'combat' && CombatManager.salvage) _salvageLootTick(dt);
    if (STATE !== 'loot') return;
    LootScreen.update(dt);
  }

  // ── STATION ───────────────────────────────────────────────

  /**
   * Leaving a port is a STATE CHANGE, so it belongs in update, not in
   * draw — where it used to live, one frame's worth of luck away from
   * whether the save happened at all.
   */
  let _stationOpenPending = false;
  function _updateStation(dt) {
    if (_stationOpenPending) {
      // the world only gets time once the film has finished — open now
      _stationOpenPending = false;
      if (_station) UI.openStation(_station, _playerShip);
      return;
    }
    if (_playerShip) _playerShip.update(dt);
    const stEl = document.getElementById('station-screen');
    if (stEl && !stEl.classList.contains('visible')) {
      /* SAVE ON THE WAY OUT.
       *
       * Everything bought at a port — a welded hull, a cured crewman, a
       * new module, a fitted gun — was applied to the LIVE objects and
       * nothing wrote them to the save. The CC, meanwhile, was spent
       * through Save.updateRun() immediately. So the money always stuck
       * and the goods never did: reload after visiting a science post
       * and the virus you paid 45 CC a head to cure was back, countdown
       * and all. That is the "cured it at the station, still infected in
       * the barracks" report. */
      _saveShip();
      STATE = 'map';
      Audio.playMusic('explore');
    }
  }

  function _drawStation(ctx) {
    Renderer.drawBackground(0);
    Renderer.drawHUD({ playerShip: _playerShip });
    // Station DOM overlay is handled by UI.openStation; leaving it is
    // handled in _updateStation, where a state change belongs.
  }

  // ── OUTCOME ───────────────────────────────────────────────
  function _updateOutcome(dt) {
    _outcomeTimer += dt;
    // Enter or a click — see the note on the JUMP line above.
    if (_outcomeTimer > 1.0 && (Input.isPressed('Enter') ||
        Input.isPressed('NumpadEnter') || Input.mouse.leftPressed)) {
      // Straight back to the base — that's where the next contract is
      // fitted out, and where the player sees what survived.
      _playerShip = null; _enemyShip = null; _sectorMap = null;
      _openBase();
    }
  }

  function _drawOutcome(ctx) {
    Renderer.drawBackground(0);
    Renderer.drawOutcome(_outcomeType, _outcomeScrap);
  }

  /** Loud, readable failure. Beats a dead-looking menu every time. */
  function _drawFatal(ctx) {
    const W = Renderer.getWidth(), H = Renderer.getHeight();
    ctx.fillStyle = 'rgba(40,6,10,0.92)';
    ctx.fillRect(0, H / 2 - 70, W, 140);
    ctx.strokeStyle = '#ff2d44'; ctx.lineWidth = 2;
    ctx.strokeRect(0, H / 2 - 70, W, 140);
    ctx.fillStyle = '#ff2d44';
    ctx.font = '20px Orbitron, monospace';
    ctx.textAlign = 'center';
    ctx.fillText('SOMETHING IS MISSING', W / 2, H / 2 - 30);
    ctx.fillStyle = '#ffb0b8';
    ctx.font = '13px Share Tech Mono, monospace';
    const words = _fatal.split(' ');
    let line = '', y = H / 2;
    words.forEach(w => {
      const t = line ? line + ' ' + w : w;
      if (ctx.measureText(t).width > W - 120 && line) { ctx.fillText(line, W / 2, y); y += 18; line = w; }
      else line = t;
    });
    if (line) ctx.fillText(line, W / 2, y);
    ctx.fillStyle = '#7a90a8';
    ctx.font = '11px Share Tech Mono, monospace';
    ctx.fillText('Press F12 → Console for details.', W / 2, H / 2 + 52);
  }

  // ── PAUSE ─────────────────────────────────────────────────
  /* THE CURTAIN CAME DOWN (update76).
   *
   * This used to paint the whole screen over at 70% and write PAUSED
   * across the middle in 48px — which is the right drawing for a pause
   * you cannot act in, and exactly the wrong one for a pause you are
   * MEANT to act in. You cannot give an order to a ship you cannot see.
   *
   * What is left says the same thing without standing in front of it:
   * a hairline frame round the play area and one line at the bottom,
   * clear of the crew roster, the orders panel and the power bar. */
  const PAUSE_BAR_H = 18;
  const PAUSE_TEXT  = 'PAUSED  \u00b7  orders still work  \u00b7  SPACE to resume';
  function _drawPause(ctx) {
    const W = Renderer.getWidth(), H = Renderer.getHeight();

    ctx.save();
    // A hairline round the play area: says "stopped" from the corner of
    // the eye without hiding a single pixel of the ship.
    ctx.strokeStyle = 'rgba(77,184,255,0.55)'; ctx.lineWidth = 2;
    ctx.strokeRect(1, 1, W - 2, H - 2);

    /* BOTTOM RIGHT, and one string. It was two centred strings across
       the whole bottom edge, which ran into each other on screen
       ("PAUSEDorders still work") and sat on top of the weapon panel's
       AUTO button. Both of those are things the screenshot showed and
       nothing measured. The right-hand corner is the only part of this
       screen with nothing in it. */
    ctx.font = '11px Share Tech Mono, monospace';
    const w = ctx.measureText(PAUSE_TEXT).width + 20;
    const x = W - w - 12, y = H - PAUSE_BAR_H - 8;
    ctx.fillStyle = 'rgba(8,12,22,0.94)';
    ctx.beginPath(); ctx.roundRect(x, y, w, PAUSE_BAR_H, 4); ctx.fill();
    ctx.strokeStyle = '#4db8ff'; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.roundRect(x, y, w, PAUSE_BAR_H, 4); ctx.stroke();
    ctx.fillStyle = '#4db8ff';
    ctx.textAlign = 'left';
    ctx.fillText(PAUSE_TEXT, x + 10, y + 12);
    ctx.restore();
  }

  // ── HOME BASE ─────────────────────────────────────────────

  function _openBase() {
    if (Save.hasActiveRun()) {
      // A contract is already in the air. Going back to the base means
      // writing that ship and crew off — say so plainly.
      UI.notify('A contract is still running — CONTINUE it, or launch a new one and write it off.', 'warn');
    }
    BaseScreen.open();
    STATE = 'base'; _beginFade();
    Audio.playMusic('explore');
  }

  function _updateBase(dt) {
    const action = BaseScreen.update(dt);
    if (action === 'launch') {
      const loadout = BaseScreen.consumeLaunch();
      if (loadout) _startContract(loadout);
    }
    /* THE CONTRACT STILL IN THE AIR (update57) — resumed from the base,
       which is the only screen that can tell you what is riding on it. */
    if (action === 'continue') _continueRun();
    if (action === 'pack') _openPackScreen();
    if (action === 'cpu')  _openCpuBoard(BaseScreen.consumeCpu());
    if (action === 'levelUp') {
      const c = Base.commanderById?.(BaseScreen.consumeLevelUp());
      if (c) _openPromo(c, 'base');
    }
  }

  /**
   * THE CPU BOARD — the same screen as the shelf, with a third grid.
   *
   * Nothing new was built for this. The board is a CargoGrid, the
   * chips are CargoItems, and moving one is the click-pick-up that
   * already moves a He2 drum, which is precisely why a chip cannot
   * end up both mounted and in storage: there is one item and it is
   * in one grid.
   *
   * Mounting is a BASE-ONLY act, by the spec — that is enforced by
   * where this door is, and by nothing else: no other screen ever
   * opens a board.
   */
  function _openCpuBoard(capId) {
    if (typeof LootScreen === 'undefined' || typeof Chips === 'undefined') {
      UI.notify('Cargo system not loaded', 'warn');
      return;
    }
    const cap = Base.commanderById?.(capId);
    if (!cap) { UI.notify('No such commander', 'warn'); return; }
    if (cap.away) { UI.notify(`${cap.name} is out on a contract.`, 'warn'); return; }

    /* THE BASE'S SHELF, NOT A COPY OF IT (update79). This used to call
       `Base.warehouseGrid()`, which hands back a freshly deserialised
       grid of freshly built items — a private twin of the shelf the
       base screen was already holding. Both twins got written back to
       the save, the base screen's last, and the chip the player had
       just mounted reappeared on the shelf while it also sat on the
       board. See BaseScreen.liveShelf. */
    const shelf = BaseScreen?.liveShelf?.() ?? Base.warehouseGrid?.();
    const board = Chips.board(cap);
    if (!shelf || !board) { UI.notify('Cargo system not loaded', 'warn'); return; }
    board.noRotate = true;          // spec §6.2 — never turn a chip on the board

    const wall = Chips.wallColumn(cap.karma ?? 50);
    _lootReturn = 'base';
    LootScreen.openLoot(shelf, board, {
      title: `DESTINY TABLETS — ${cap.name}`,
      subtitle: `karma ${Math.round(cap.karma ?? 50)} · wall in column ${wall}`
              + ` · ${wall - 1} good / ${Chips.COLS - wall} evil`
              + ` · ${Chips.cellsFor(cap.level)}/25 cells (level ${cap.level})`,
      leftLabel: 'BASE WAREHOUSE',
      holdLabel: 'TABLETS',
      portType: 'general',
      board: cap,                   // the screen draws the wall and the dead chips
      onSell: (it) => { const paid = it.value('general'); Base.earn(paid); return paid; },
      onClose: ({ hold }) => {
        Chips.commit(cap, hold);
        Base.saveCommander?.(cap);
        // Committed through the screen that OWNS the shelf, so the
        // save and the object the base is still holding are the same
        // story. Committing `shelf` directly here was half the bug:
        // it wrote the truth, and then the base overwrote it.
        if (BaseScreen?.commitPack) BaseScreen.commitPack();
        else Base.commitWarehouse?.(shelf);
        STATE = 'base'; _beginFade();
      },
    });
    STATE = 'loot'; _beginFade();
  }

  /**
   * The warehouse AND the packing screen — they are the same screen now.
   *
   * There used to be two: PACK HOLD (a throwaway grid built from the
   * fuel/missile counters) and OPEN WAREHOUSE (the salvage shelf). Two
   * views of what the player quite reasonably thought was one shelf, and
   * each needed its own reconciliation with the other. One store, one
   * screen: drag between the shelf and the hold, sell off the shelf, done.
   */
  function _openPackScreen() {
    if (typeof LootScreen === 'undefined' || typeof CargoGrid === 'undefined') {
      UI.notify('Cargo system not loaded', 'warn');
      return;
    }
    const { store, hold } = BaseScreen.packGrids();
    if (!store || !hold) { UI.notify('No hull selected', 'warn'); return; }
    _lootReturn = 'base';
    LootScreen.openLoot(store, hold, {
      title: 'WAREHOUSE',
      subtitle: 'click to pick up, click to put down · R rotates · SPLIT halves a stack · '
              + 'SELL banks CC on the spot',
      leftLabel: 'BASE WAREHOUSE',
      holdLabel: 'SHIP HOLD',
      takeAllLabel: 'LOAD ALL',
      doneLabel: 'DONE',
      portType: 'general',
      onSell: (it) => { const paid = it.value('general'); Base.earn(paid); return paid; },
      onUnpack: (it) => (it.def.kind === 'heal'
        ? { ok: false, message: 'No patient to treat here — pack it for the next contract instead.' }
        : null),
      // No clock: packing before a launch is not a raid.
      onClose: () => { BaseScreen.commitPack?.(); STATE = 'base'; _beginFade(); },
    });
    STATE = 'loot'; _beginFade();
  }

  /** Launch a contract with the loadout the base handed us. */
  function _startContract(loadout) {
    Save.startRun();
    const mission = loadout.mission || MISSIONS.patrol;
    Save.updateRun({
      mission: mission.id,
      finalSector: mission.sectors,
      fuel: loadout.fuel,
      missiles: loadout.missiles,
      shipKey: loadout.ship.key,
    });
    /* ── WHAT ELSE THEY WANT OUT OF THIS RUN (update71) ──────
       Rolled once, here, where the contract's LENGTH is known — the
       same place the boss and the final sector are decided. */
    Save.rollRunGoals?.(mission.sectors ?? 1);
    const run = Save.getRun();
    _savedStations = null;
    BossManager.reset(mission.boss);

    /* THE COMMANDER TAKES THE CHAIR (update43). He is optional — a
       contract flies perfectly well without one. The record that goes
       into the run IS the record in the mess: one object, so his XP
       cannot end up half-written in two places. */
    _commander = null;
    if (typeof Commander !== 'undefined' && loadout.commanderId) {
      _commander = Base.commanderById?.(loadout.commanderId) ?? null;
      if (_commander) {
        _commander.away = true;
        /* HE LEAVES BASE WITH A FULL HEAD (update98). Knowledge is
           restored in port and at base; launch is the one door every
           contract goes out through. */
        Commander.refillKnowledge?.(_commander, 1);
        Base.saveCommander?.(_commander);
        Save.updateRun({ commanderId: _commander.id });
      }
    }
    Commander?.setActive?.(_commander);

    // Veteran hull keeps its upgrades; a fresh one is built from the layout
    _playerShip = loadout.ship.data
      ? Ship.deserialise(loadout.ship.data, true, Ship.PLAYER_STATION.x, Ship.PLAYER_STATION.y)
      : new Ship(loadout.ship.key, true, Ship.PLAYER_STATION.x, Ship.PLAYER_STATION.y);

    // The hold the player packed in the base travels with the ship.
    if (loadout.hold && _playerShip.cargo && typeof CargoGrid !== 'undefined') {
      _playerShip.cargo = _launchHold(_playerShip.cargo, CargoGrid.deserialise(loadout.hold));
      // The racks in the hold ARE the ammo, and the cells ARE the He2 —
      // the HUD figures just mirror them, so nothing needs unpacking.
      _syncAmmo();
      _syncFuel();
    }

    /* Spare guns from the armoury: fit what the mounts allow, BOX the
       rest (update75). They used to go onto the weightless rack, which
       is why a player could carry six spare guns off the shelf and
       notice no difference in the hold. A gun he chose to bring now
       takes the cells it takes — and one that will not fit stays in
       the armoury rather than riding along invisibly. */
    (loadout.spareGuns ?? []).forEach(key => {
      let slot = -1;
      for (let i = 0; i < _playerShip.weaponSlots; i++) {
        if (!_playerShip.weapons[i]) { slot = i; break; }
      }
      if (slot !== -1 && _playerShip.installWeapon(key, slot)) return;
      if (_playerShip.boxWeapon(key)) return;
      /* PUT BACK, not dropped. The crate already left the armoury shelf
         when she was loaded, so doing nothing here would destroy a gun
         the player owns — quietly, on the launch pad. */
      const back = Base.storeWeapon?.(key);
      UI.notify(`${WEAPON_DEFS[key]?.label ?? 'A spare gun'} would not fit in the hold — `
              + (back ? 'it is back on the armoury shelf.' : 'and the shelf is full too; it is lost.'),
              'warn');
    });

    if (loadout.crew && loadout.crew.length) {
      loadout.crew.forEach(cd => _playerShip.addCrew(CrewMember.deserialise(cd)));
    } else {
      // Nobody in the barracks — the guild sends green hands instead
      makeStartingCrew().forEach(c => _playerShip.addCrew(c));
      UI.notify('No veterans available — a fresh crew signed on.', 'info');
    }
    _playerShip.assignStations();
    /* THE POSTS THE PLAYER CHOSE IN THE LOADOUT (update113) — and they are
       the saved stations from the first jump, so RETURN sends everyone
       back to exactly where he was put. */
    if (loadout.posts && Object.keys(loadout.posts).length) {
      _playerShip.applyPosts(loadout.posts);
      // Keyed by each man's own id (a number or a string — whatever he carries),
      // which is what RETURN looks him up by.
      _savedStations = new Map(_playerShip.crew
        .filter(c => !c.isPet && loadout.posts[c.id] != null)
        .map(c => [c.id, loadout.posts[c.id]]));
    }

    /* THE SHIP'S CAT COMES ABOARD (update45). After assignStations, so
       nothing tries to give it a post — it is a beast and beasts do not
       stand watches. */
    if (loadout.pet) {
      const cat = CrewMember.deserialise(loadout.pet);
      // Every contract, she comes aboard hungry (update91) — see CAT_TUNING.
      cat.hunger = Math.min(cat.hunger ?? 100, CAT_TUNING.START_HUNGER);
      _playerShip.addCrew(cat);
      UI.notify(`${cat.name} is aboard.`, 'good');
    }

    // The commander's max-HP bonus is a stored number, so it is seated
    // once here rather than recomputed in every frame that reads hp.
    Commander?.reseatMaxHp?.(_playerShip.crew);

    _sosNode = null;   // node ids repeat per sector — clear the beacon lock
    _sectorMap = new SectorMap(run.sector, run.seed,
      run.sector > 1 ? (run.lane ?? SectorMap.MID_LANE) : (run.lane ?? null), mission.sectors,
      !!mission.boss);
    _saveShip();
    STATE = 'map'; _beginFade();
    Audio.playMusic('explore');
    UI.notify(`${mission.label} — ${mission.sectors} sectors. Good hunting.`, 'good');
  }

  /** Contract complete and docked: bank the ship, the survivors and
   *  whatever is left in the hold. This is the ONLY way anything gets
   *  back into the base. */
  /**
   * THE EGG CASE FLIES AGAIN (update89 fix). The yard will not take a
   * case off the hull (see `yardRefuses` in _dockAtBase), so it rides
   * home in the ship's own hold — and the launch then REPLACED that
   * hold with the one packed at the base, and the case was gone: "puzniej
   * znika". What the hull kept aboard goes into the packed hold first;
   * a crate it pushes out goes back onto the warehouse shelf, and the
   * player is told. Nothing is lost either way.
   */
  function _launchHold(oldHold, packed) {
    const kept = (oldHold?.items ?? []).filter(it => it?.def?.tag === 'egg');
    if (!kept.length) return packed;
    // Room for it as packed: the player's arrangement stays as it is.
    const placed = kept.filter(it => packed.autoPlace(it));
    if (placed.length === kept.length) {
      UI.notify('The egg case is still in the hold.', 'warn');
      return packed;
    }
    placed.forEach(it => packed.remove(it));
    const fresh = new CargoGrid(packed.cols, packed.rows);
    const shelf = Base.storeGrid?.() ?? null;
    let shelved = 0;
    kept.forEach(it => fresh.autoPlace(it));
    packed.items.forEach(it => {
      if (fresh.autoPlace(it)) return;
      if (shelf?.autoPlace(it)) shelved++;
    });
    if (shelf && shelved) Base.commitWarehouse?.(shelf);
    UI.notify(`The egg case is still in the hold${shelved
      ? ` — ${shelved} crate(s) went back on the shelf to make room` : ''}.`, 'warn');
    return fresh;
  }

  function _dockAtBase(ccEarned, andThen = null) {
    // ONE SHELF. Everything in the hold — canisters, racks, gun crates,
    // medkits, relics — goes back onto the same warehouse grid it was
    // packed out of, exactly as it is. Nothing is unpacked into a counter.
    let stashedCount = 0;
    const hold = _playerShip?.cargo;
    const shelf = Base.warehouseGrid?.();
    /* ── A BAG WITH SOMEBODY IN IT IS NOT CARGO (update68) ────
     *
     * This loop moved EVERYTHING off the ship and onto the warehouse
     * shelf — bodies included — and it runs BEFORE `returnFromRun`,
     * which is where the bounty office and the burial live. So by the
     * time anybody looked for a bag on the hull there was none: the
     * dead man was on a shelf between the missiles and the ore, no
     * burial, no karma, no bounty, and the player's own crewman sat in
     * his warehouse for the rest of the game.
     *
     * Bodies stay ON the hull through docking. `returnFromRun` takes
     * them off, pays for them, buries them and clears them — one
     * place, exactly as designed.
     */
    const isBody = (it) => it?.def?.tag === 'body';
    /* ── AND THE YARD WILL NOT TOUCH AN EGG CASE (update69) ────
     *
     * The player's rule, and it is the right one: "jajka nie mozna
     * wyjac z ladowni i ze statku w bazie, nie mozna rowniez go tam
     * sprzedac, jedynie jajko mozna sprzedac w porcie". Nobody at a
     * home dock signs for a sealed case with something alive in it —
     * the science posts out in the sectors do, and ask no questions.
     *
     * So it never leaves the hull here: not onto the shelf, not
     * through the till, not by accident in the SELL THE REST sweep. It
     * rides home in the hold and it is still ticking on the next
     * contract, which is exactly the decision the player is meant to
     * be making about it.
     */
    const isEgg = (it) => it?.def?.tag === 'egg';
    const yardRefuses = (it) => isBody(it) || isEgg(it);
    if (hold?.items?.length && shelf) {
      for (const it of [...hold.items]) {
        if (yardRefuses(it)) continue;
        if (!shelf.autoPlace(it)) continue;
        hold.remove(it);
        stashedCount++;
      }
    }
    if (shelf) Base.commitWarehouse(shelf);

    /* ── WHAT WOULD NOT FIT IS THE PLAYER'S DECISION (update48) ──
     *
     * This used to read:
     *     else { cargoCC += it.value('general'); spilled++; }
     *     hold.clear();
     * — the base bought the overflow at scrap value whether you liked
     * it or not, and the crate you had crossed two sectors for was
     * gone before the outcome screen came up. The player's report is
     * exactly that: "items must not just disappear; the player always
     * gets to choose what to keep and what to throw out."
     *
     * So the shelf and the hold go up side by side and the run does
     * not close until he has said what happens to the rest. He can
     * still sell it — the DONE button says so in CC, out loud — but
     * nothing is sold behind his back.
     */
    /* …and the sorting screen must not offer to SELL them either. What
       is left in the hold that is not a body is what the player has to
       decide about. */
    const holdHasGoods = !!hold?.items?.some(it => !yardRefuses(it));
    if (holdHasGoods && typeof LootScreen !== 'undefined' && shelf) {
      _lootReturn = 'outcome';
      LootScreen.openLoot(shelf, hold, {
        title: 'DOCKED — WHAT COMES OFF THE SHIP?',
        subtitle: 'the shelf is full · move what you want to keep, sell or dump the rest',
        leftLabel: 'BASE WAREHOUSE',
        holdLabel: 'STILL IN THE HOLD',
        takeAllLabel: 'UNLOAD ALL',
        portType: 'general',
        sellRestOnDone: true,
        /* The one thing this screen may not do with an egg case is take
           it off the ship — see `yardRefuses` above. The screen asks
           before it sells and before it shelves. */
        locked: yardRefuses,
        lockedWhy: 'the yard will not sign for that — a port might',
        onSell: (it) => { const paid = it.value('general'); Base.earn(paid); return paid; },
        onClose: () => {
          Base.commitWarehouse?.(Base.warehouseGrid ? shelf : null);
          _finishDocking(ccEarned, stashedCount, andThen);
        },
      });
      STATE = 'loot'; _beginFade();
      return null;
    }

    return _finishDocking(ccEarned, stashedCount, andThen);
  }

  /* ══ WHO IS LET GO (update106) ════════════════════════════════
   * A full barracks at the dock. One row per hand — those at the base and
   * those coming home — and the player marks exactly as many as there are
   * bunks short. Nothing is decided for him; DOCK stays dark until the
   * count is right. Dismissed men at the base leave the barracks, men
   * coming home are let off at the dock; nobody else is touched. */
  let _dismiss = null;          // { need, rows: [{ who, home, pick }], resume }
  let _dismissPicked = false;

  function _openDismiss(need, back, resume) {
    const rows = [
      ...Base.crew().map(rec => ({ who: rec, home: true, pick: false })),
      ...back.map(c => ({ who: c, home: false, pick: false })),
    ];
    // Where docking was when it stopped to ask; the hold screen is closed by now.
    _dismiss = { need, rows, resume, back: STATE === 'loot' ? 'map' : STATE };
    STATE = 'dismiss'; _beginFade?.();
  }

  function _dismissRects() {
    const W = Renderer.getWidth(), H = Renderer.getHeight();
    const n = _dismiss?.rows.length ?? 0;
    const perCol = Math.max(1, Math.ceil(n / 2));
    const rowH = Math.min(30, Math.floor(420 / perCol));
    const PW = 760, PH = Math.min(H - 40, 104 + perCol * rowH + 84);
    const px = W / 2 - PW / 2, py = H / 2 - PH / 2;
    const colW = (PW - 60) / 2;
    return {
      panel: { x: px, y: py, w: PW, h: PH },
      rows: (_dismiss?.rows ?? []).map((r, i) => ({
        i, x: px + 24 + Math.floor(i / perCol) * (colW + 12), y: py + 104 + (i % perCol) * rowH,
        w: colW, h: rowH - 4,
      })),
      ok: { x: px + PW / 2 - 130, y: py + PH - 56, w: 260, h: 36 },
    };
  }

  function _dismissCount() { return (_dismiss?.rows ?? []).filter(r => r.pick).length; }

  function _updateDismiss() {
    if (!_dismiss) { STATE = 'map'; return; }
    const R = _dismissRects();
    const ready = _dismissCount() === _dismiss.need;
    if (Input.mouse.leftPressed) {
      const hit = R.rows.find(z => Utils.pointInRect(Input.mouse.x, Input.mouse.y, z.x, z.y, z.w, z.h));
      if (hit) {
        const row = _dismiss.rows[hit.i];
        if (row.pick || _dismissCount() < _dismiss.need) { row.pick = !row.pick; Audio.sfx.uiClick?.(); }
        else UI.notify(`Only ${_dismiss.need} have to go — unmark somebody first.`, 'warn');
        return;
      }
      if (ready && Utils.pointInRect(Input.mouse.x, Input.mouse.y, R.ok.x, R.ok.y, R.ok.w, R.ok.h)) {
        _applyDismiss(); return;
      }
    }
    if (ready && Input.isPressed('Enter')) _applyDismiss();
  }

  function _applyDismiss() {
    const d = _dismiss;
    if (!d || _dismissCount() !== d.need) return;
    const gone = d.rows.filter(r => r.pick);
    gone.forEach(r => {
      if (r.home) Base.removeCrew(r.who.id);
      else if (_playerShip) _playerShip.crew = _playerShip.crew.filter(c => c !== r.who);
    });
    _dismiss = null;
    STATE = d.back;                 // docking carries on from there (and sets its own end)
    UI.notify(`Dismissed: ${gone.map(r => r.who.name).join(', ')}.`, 'warn');
    d.resume?.();
  }

  function _drawDismiss(ctx) {
    Renderer.drawBackground(0);
    if (!_dismiss) return;
    const R = _dismissRects(), P = R.panel;
    const picked = _dismissCount(), need = _dismiss.need;
    ctx.fillStyle = 'rgba(13,17,32,0.96)';
    ctx.beginPath(); ctx.roundRect(P.x, P.y, P.w, P.h, 8); ctx.fill();
    ctx.strokeStyle = '#ff7c20'; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.roundRect(P.x, P.y, P.w, P.h, 8); ctx.stroke();
    ctx.textAlign = 'center';
    ctx.fillStyle = '#ff7c20'; ctx.font = '16px Orbitron, monospace';
    ctx.fillText('BARRACKS FULL', P.x + P.w / 2, P.y + 34);
    ctx.fillStyle = '#c8d8f0'; ctx.font = '12px Share Tech Mono, monospace';
    const home = _dismiss.rows.filter(r => r.home).length;
    ctx.fillText(`${Base.barracksCap()} bunks · ${home} at the base · ${_dismiss.rows.length - home} coming home`,
                 P.x + P.w / 2, P.y + 58);
    ctx.fillStyle = picked === need ? '#1aff8c' : '#ffd700';
    ctx.fillText(`Choose ${need} to dismiss — ${picked}/${need} marked`, P.x + P.w / 2, P.y + 80);
    ctx.textAlign = 'left';
    R.rows.forEach(z => {
      const row = _dismiss.rows[z.i], c = row.who;
      const hot = Utils.pointInRect(Input.mouse.x, Input.mouse.y, z.x, z.y, z.w, z.h);
      ctx.fillStyle = row.pick ? 'rgba(255,45,68,0.18)' : hot ? 'rgba(26,140,255,0.12)' : 'rgba(20,30,50,0.9)';
      ctx.beginPath(); ctx.roundRect(z.x, z.y, z.w, z.h, 3); ctx.fill();
      ctx.strokeStyle = row.pick ? '#ff5566' : '#1e2d4a'; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.roundRect(z.x, z.y, z.w, z.h, 3); ctx.stroke();
      const cy = z.y + z.h / 2 + 4;
      ctx.strokeStyle = row.pick ? '#ff5566' : '#4a6080';
      ctx.strokeRect(z.x + 8, z.y + z.h / 2 - 6, 12, 12);
      if (row.pick) { ctx.fillStyle = '#ff5566'; ctx.fillRect(z.x + 11, z.y + z.h / 2 - 3, 6, 6); }
      /* THE ONE CREW CARD (update112) — the man you are about to let go
         looks exactly as he does in the barracks and on the roster. */
      Renderer.drawCrewCard(ctx, c, z.x + 26, z.y, 'S', {
        w: z.w - 26 - 92, h: z.h,
        frameCol: row.pick ? '#ff5566' : null, fill: row.pick ? 'rgba(255,45,68,0.14)' : null,
      });
      ctx.textAlign = 'right';
      ctx.fillStyle = row.home ? '#4db8ff' : '#1aff8c';
      ctx.fillText(row.home ? 'AT BASE' : 'COMING HOME', z.x + z.w - 8, cy);
      ctx.textAlign = 'left';
    });
    const ok = R.ok, ready = picked === need;
    ctx.fillStyle = ready ? 'rgba(255,45,68,0.2)' : 'rgba(13,17,32,0.9)';
    ctx.beginPath(); ctx.roundRect(ok.x, ok.y, ok.w, ok.h, 5); ctx.fill();
    ctx.strokeStyle = ready ? '#ff5566' : '#3a4560'; ctx.lineWidth = 1.5;
    ctx.beginPath(); ctx.roundRect(ok.x, ok.y, ok.w, ok.h, 5); ctx.stroke();
    ctx.fillStyle = ready ? '#ffd7d7' : '#3a4560';
    ctx.font = '13px Share Tech Mono, monospace'; ctx.textAlign = 'center';
    ctx.fillText(`DISMISS ${need} & DOCK [ENTER]`, ok.x + ok.w / 2, ok.y + 23);
    ctx.textAlign = 'left';
  }

  /** The rest of docking, once the hold is empty one way or another. */
  function _finishDocking(ccEarned, stashedCount, andThen) {
    /* MORE HANDS THAN BUNKS: THE PLAYER CHOOSES WHO GOES (update106, jj).
       The barracks used to take whoever came first and turn the rest away
       — people vanished at the dock without the player knowing who. Now,
       before anything is banked, a screen asks which of them (home or
       coming back) are let go; the rest come in. */
    if (!_dismissPicked) {
      const back = (_playerShip?.crew ?? []).filter(c => c && c.isPlayer && !c.dead && !c.isPet);
      const over = Base.crew().length + back.length - Base.barracksCap();
      if (over > 0) {
        _openDismiss(over, back, () => {
          _dismissPicked = true;
          try { _finishDocking(ccEarned, stashedCount, andThen); } finally { _dismissPicked = false; }
        });
        return null;
      }
    }
    const run = Save.getRun();
    const shipKey = run?.shipKey || _playerShip?.layoutKey || 'scout';


    /* THE ANIMAL GOES BACK IN ITS PEN, hungry or not. It is NOT part of
       the crew roster below — `c.isPlayer && !c.dead` would put a cat in
       the barracks as a hireable hand. */
    /* EVERYBODY OUT OF THE SLABS (update77). A slab runs on the
       ship's power and the ship is being unloaded — nobody is banked
       into the barracks still frozen, because the barracks has no
       carbonite and a man saved mid-freeze would come back to a hull
       with no slab to be in. His clock starts again here, which is the
       deal: carbonite buys you the trip, not the cure. */
    (_playerShip?.crew ?? [])
      .filter(c => c && c.frozen)
      .forEach(c => _playerShip.thawCrew(c, 'the ship is powering down'));

    (_playerShip?.crew ?? [])
      .filter(c => c.isPet && !c.dead)
      .forEach(cat => Base.savePet?.(cat.serialise()));

    /* THE HOLD IS EMPTY BY NOW — either it fitted on the shelf or the
       player said, on the sorting screen above, what happened to the
       rest. Anything still in it would ride home inside the hull's own
       save data, where the base cannot see it and the next launch
       would overwrite it: that is a slower way of losing a crate, not
       a safer one. */
    /* THE YARD DOES NOT FUMIGATE (update86b). update84 cleared the
       ducts here; the player's call after playing it: "szczury się nie
       restartują, nie znikają, zostają na danym statku do następnej
       wyprawy". They ride in the ship record, which the hangar keeps,
       and come out with her on the next launch. Getting rid of them is
       the cat's job, or the air's — not the dock's. */
    const rep = Base.returnFromRun({
      shipEntry: _playerShip ? { key: shipKey, data: _playerShip.serialise() } : null,
      // `c.isPlayer` (update42): a surviving enemy boarder aboard at
      // docking was BANKED INTO THE BARRACKS and showed up as hireable
      // crew on the next run. `!isPet`: the cat goes to her pen above.
      crew: (_playerShip?.crew ?? [])
        .filter(c => c.isPlayer && !c.dead && !c.isPet).map(c => c.serialise()),
      // NOTHING loose comes back as units any more (update39). He2
       // rides home in its cells and warheads in their racks, exactly
       // like every other container — passing the mirror numbers here
       // would bank a second copy of both.
      fuel: 0,
      missiles: 0,
      cc: ccEarned,
    });
    /* ── THE COMMANDER LEAVES THE CHAIR LAST (update68) ──────
     *
     * This used to run BEFORE `returnFromRun`, and it cost the burial
     * its karma: the dock buries your dead and pays the commander for
     * bringing them home, but there was no commander in the chair by
     * then — he had been cleared two lines earlier. The +3 went
     * nowhere and the player got a gravestone and nothing else.
     *
     * So: dock first, THEN bank him. Saving him before the docking
     * that changes his karma would have written the old figure over
     * the new one, which is the same bug wearing a different hat.
     */
    /* ── AND WHAT THE PEOPLE YOU GOT OUT ARE WORTH (update72) ──
     *
     * `RESCUE_AT_COST` is the table's own figure for "saving people at
     * the expense of the run", and that is exactly what this was: a
     * boarding party sent to a cell block instead of a reactor, and a
     * bunk given up to somebody who did not come with a bounty.
     *
     * Paid HERE — after the dock counted them, before the commander
     * leaves the chair two lines down. Get that order wrong and the
     * karma goes nowhere, which is precisely the bug update68 fixed
     * for the burial and the same chair it was fixed in. */
    if (rep.rescued > 0 && _commander && typeof Commander !== 'undefined') {
      const each = Commander.KARMA?.RESCUE_AT_COST ?? 10;
      const r = Commander.shift(_commander, each * rep.rescued);
      if (r) {
        UI.notify(`${rep.rescued} rescued off their hull — `
                + `${_commander.name}: karma ${r.from} → ${r.to}`, 'good');
      }
    }
    if (_commander) {
      _commander.away = false;
      Commander?.refillKnowledge?.(_commander, 1);     // home: full (update98)
      Base.saveCommander?.(_commander);
    }
    Commander?.setActive?.(null);

    const bits = [];
    if (rep.rescued)      bits.push(`${rep.rescued} rescued`);
    if (rep.shipStored)   bits.push('hull docked');
    if (rep.crewStored)   bits.push(`${rep.crewStored} crew home`);
    if (rep.fuelStored)   bits.push(`${rep.fuelStored} He2 stored`);
    if (rep.mslStored)    bits.push(`${rep.mslStored} missiles stored`);
    if (rep.cc)           bits.push(`${rep.cc} CC banked`);
    if (rep.prisoners)    bits.push(`${rep.prisoners} prisoner${rep.prisoners > 1 ? 's' : ''} handed over`);
    if (rep.bodies)       bits.push(`${rep.bodies} bod${rep.bodies > 1 ? 'ies' : 'y'} claimed`);
    if (rep.bounty)       bits.push(`${rep.bounty} CC in bounties`);
    if (rep.wanted)       bits.push(`${rep.wanted} off the wanted list`);
    if (rep.buried)       bits.push(`${rep.buried} laid to rest`);
    if (rep.buriedUnknown) bits.push(`${rep.buriedUnknown} buried without a name`);
    if (rep.burialKarma)  bits.push(`+${rep.burialKarma} karma`);
    if (stashedCount)     bits.push(`${stashedCount} crate${stashedCount > 1 ? 's' : ''} back on the shelf`);
    UI.notify(bits.length ? bits.join(' · ') : 'Docked.', 'good');

    const lost = [];
    if (rep.fuelLost)       lost.push(`${rep.fuelLost} He2`);
    if (rep.mslLost)        lost.push(`${rep.mslLost} missiles`);
    if (rep.crewTurnedAway) lost.push(`${rep.crewTurnedAway} crew turned away`);
    if (!rep.shipStored && _playerShip) lost.push('no berth for the hull!');
    if (lost.length) UI.notify(`No room for: ${lost.join(', ')} — upgrade the base.`, 'warn');
    andThen?.(rep);
    return rep;
  }

  // ── Helpers ───────────────────────────────────────────────
  function _startNewRun() {
    // Legacy entry point — send the player through the base instead so
    // the hangar, barracks and warehouse actually mean something.
    _openBase();
  }

  function _continueRun() {
    if (!Save.hasActiveRun()) { UI.notify('No saved run.','warn'); return; }
    const run = Save.getRun();
    if (!run?.ship) { _openBase(); return; }
    _savedStations = null;
    /* THE CONTRACT'S OWN BOSS, INCLUDING "NONE" (update38).
     *
     * `MISSIONS[run.mission]?.boss ?? 'station'` reads as a sensible
     * default and is a bug: Courier Run declares `boss: null` on
     * purpose, and `null ?? 'station'` is 'station'. So reloading a
     * boss-less contract armed Apophis and rebuilt the last column as
     * a BOSS node where launching had built an exit — the player saw
     * the main boss on the map of a one-sector courier job. Only a
     * genuinely UNKNOWN mission falls back now. */
    const mission = MISSIONS[run.mission] ?? null;
    const boss    = mission ? mission.boss : 'station';
    BossManager.reset(boss);
    _playerShip = Ship.deserialise(run.ship, true, Ship.PLAYER_STATION.x, Ship.PLAYER_STATION.y);
    /* A SAVE FROM BEFORE update84 HAS ITS RATS IN THE CREW LIST.
       `Pest.fromCrewRecord` recognises one and hands back the pest it
       really was; everybody else is a crewman, as before. */
    (run.crew||[]).forEach(cd => {
      const pest = Pest.fromCrewRecord(cd);
      if (pest) { if (!pest.dead) _playerShip.addPest(pest); return; }
      _playerShip.addCrew(CrewMember.deserialise(cd));
    });

    /* THE COMMANDER COMES BACK WITH THE RUN (update43). The mess holds
       the authoritative record; the run only remembers WHICH commander
       is out. An id that no longer matches anybody (an old save, a
       deleted mess) simply means this contract flies without one. */
    /* An update51 run stored the man as `captainId` (update52 renamed
       the chair). Read the old key once so a save mid-contract does
       not lose its commander — and do not write it back. */
    const rid = run.commanderId ?? run.captainId;
    _commander = (typeof Commander !== 'undefined' && rid)
      ? (Base.commanderById?.(rid) ?? null) : null;
    Commander?.setActive?.(_commander);
    // Crew HP came out of the save with the bonus already in it, so
    // this only re-seats the baseline; it never heals.
    Commander?.reseatMaxHp?.(_playerShip.crew);

    _sosNode = null;   // node ids repeat per sector — clear the beacon lock
    _sectorMap = new SectorMap(run.sector, run.seed,
      run.sector > 1 ? (run.lane ?? SectorMap.MID_LANE) : (run.lane ?? null),
      run.finalSector ?? mission?.sectors ?? 3,
      !!boss);
    // …and put him back on the node he was standing on, with the rest
    // of the sector still behind him.
    _sectorMap.restoreProgress(run.mapProgress);
    STATE = 'map';
    Audio.playMusic('explore');
  }

  /** How often a fight from sector 2 on is a bunker or a mech (update94). */
  const GROUND_ODDS = { bunker: 0.12, mech: 0.10 };
  /** The ordinary enemy draw (update95: four of jj's hulls joined it). */
  const ENEMY_POOL = ['enemy_frigate', 'enemy_gunship', 'enemy_raider',
                      'enemy_ra', 'enemy_khnum', 'enemy_hathor', 'enemy_montu'];
  /* SOMETIMES A TORPEDO TUBE IN THE SECOND BAY (update95) — jj: the
     enemy gets one too, but only ever as the second gun, and from
     sector 2 like the player's. It needs no racks: no enemy gun counts
     its ammunition. */
  const ENEMY_TORPEDO_ODDS = 0.25;
  /* One fight in five the enemy is caught off guard (update97): crew
     off their posts, shields not yet charged. Otherwise they are ready. */
  const ENEMY_SURPRISE_ODDS = 0.20;

  function _spawnEnemy(difficulty='normal') {
    // Random hull layout — different module arrangements per encounter.
    // Elites favour the Gunship (it has TWO weapon module rooms).
    /* A WANTED MAN NEEDS A HULL THAT CAN CARRY TWO GUNS (update68).
       The arming block further down could not fit a second barrel on a
       one-bay frigate, so a pirate rolled onto that layout came out as
       an ordinary patrol boat with a famous name — which is exactly
       what the player met and reported. */
    const _wantedHere = (typeof _wantedOnThisNode === 'function' && !BossManager.isActive)
      ? _wantedOnThisNode() : null;
    /* BUNKERS AND MECHS (update94): from sector 2, rarer than ships —
       never for a wanted man (he flies) and never for an elite. */
    const groundKey = (() => {
      if (difficulty === 'hard' || _wantedHere) return null;
      if ((Save.getRun()?.sector ?? 1) < 2) return null;
      const r = Math.random();
      return r < GROUND_ODDS.bunker ? 'bunker_small'
           : r < GROUND_ODDS.bunker + GROUND_ODDS.mech ? 'enemy_mech' : null;
    })();
    /* THE NEW HULLS (update95). The one-gun ones from the start; the
       two-gun Nephthys joins the elites everywhere and the ordinary
       draw from sector 2, the same rule the bunkers keep. */
    const sectorNow = Save.getRun()?.sector ?? 1;
    let layoutKey = groundKey ?? ((difficulty === 'hard' || _wantedHere)
      ? Utils.pick(['enemy_gunship', 'enemy_gunship', 'enemy_raider', 'enemy_nephthys'])
      : Utils.pick(sectorNow >= 2 ? ENEMY_POOL.concat(['enemy_nephthys']) : ENEMY_POOL));
    /* A TWO-GUN HULL ONLY VERY RARELY ON THE FIRST CONTRACT (update108,
       jj). The contract says how rarely (`twoGunChance`); any two-bay
       hull the draw made is swapped for a one-bay one otherwise. */
    {
      const m = (typeof MISSIONS !== 'undefined') ? MISSIONS[Save.getRun()?.mission] : null;
      const twoBay = (k) => (SHIP_LAYOUTS?.[k]?.rooms ?? []).filter(r => r.type === 'weapons').length >= 2;
      if (m && m.twoGunChance != null && !_wantedHere && twoBay(layoutKey) && Math.random() >= m.twoGunChance) {
        layoutKey = Utils.pick(ENEMY_POOL.filter(k => !twoBay(k)));
      }
    }
    _enemyShip = new Ship(layoutKey, false, Ship.ENEMY_STATION.x, Ship.ENEMY_STATION.y);
    /* WHO BUILT HER (update117): the yard's habits, `BUILDER_TRAITS`. */
    const builder = (typeof hullBuilder === 'function') ? hullBuilder(layoutKey) : null;
    const traits  = builder ? BUILDER_TRAITS[builder] : {};
    /* AND SHE CARRIES A FEW DOSES (update78). Bandaging costs medical
       supplies now, for everybody — and a hull with none would mean
       every enemy casualty bleeds out, which is not a rule, it is one
       side quietly exempted from one. Two to four boxes: enough for
       her own wounded, and a reason to board a ship you are beating
       rather than only the wrecks. */
    if (_enemyShip.cargo) {
      for (let i = Utils.randInt(2, 4) + (traits.medkits ?? 0); i > 0; i--) _enemyShip.cargo.add('medkit');
    }
    const sector = Save.getRun()?.sector ?? 1;
    const elite  = difficulty === 'hard';

    // ── Hull scaling ──
    if (sector === 1) {
      _enemyShip.hull    = elite ? 16 : 12;
    } else {
      _enemyShip.hull    = (elite ? 24 : 18) + (sector - 2) * 5;
    }
    // Plate and a few more points of hull on what stands on the ground.
    if (_enemyShip.layout?.grounded) _enemyShip.hull += 4;
    _enemyShip.hullMax = _enemyShip.hull;

    // ── What the raider fitted in her spare bay ──
    //  A raider hull has exactly ONE bay going spare, so shields and a
    //  cloak COMPETE for it — this is a single roll, not two, otherwise
    //  whichever was rolled first would always win and the other would
    //  effectively never appear.
    //    shields → you have to shoot through something
    //    cloak   → the AI blinks out when hurt and your volley whiffs
    //  (The player's own starter hull has no shields either, so an
    //   unshielded raider is a fair fight, not a free win.)
    const loadout = (() => {
      const roll = Math.random();
      /* A Pegasus hull carries her bubble from sector 2 on (update117) —
         the same roll is still spent, so the dice stay in step. Sector 1
         keeps its rule: nobody's shields there. */
      if (traits.shieldsFromSector && sector >= traits.shieldsFromSector) return 'shields';
      if (elite) return roll < 0.60 ? 'shields' : 'cloak';
      // SECTOR 1 HAS NO SHIELDS AT ALL. One layer takes a starting laser
    // six seconds a bolt to chip through, which is most of the opening
    // sector spent watching a bubble absorb everything you have. The
    // first sector is where the player learns the controls; it should
    // not also be the hardest wall they meet.
    if (sector === 1) return roll < 0.45 ? 'cloak' : 'empty';
      if (sector === 2) return roll < 0.50 ? 'shields' : roll < 0.75 ? 'cloak' : 'empty';
      return roll < 0.60 ? 'shields' : roll < 0.90 ? 'cloak' : 'empty';
    })();

    const sh = _enemyShip.getSystem('shields');
    if (sh) {
      if (loadout === 'shields') {
        sh.level = elite ? (sector >= 2 ? 4 : 2) : 2;   // 2 pips = 1 layer
        // …and a Pegasus hull one layer more, later in the run (update117)
        if (traits.extraLayerFromSector && sector >= traits.extraLayerFromSector) {
          sh.level = Math.min(sh.level + 2, SYSTEM_DEFS.shields?.maxLevel ?? 8);
        }
        sh.desiredPower = sh.level;
      } else {
        // Bay stripped back to bare frame — free for something else
        const room = _enemyShip.getRoomById(sh.roomId);
        if (room) { room.system = null; room.type = 'empty'; }
        _enemyShip.systems = _enemyShip.systems.filter(s => s !== sh);
      }
    }

    if (loadout === 'cloak' && !_enemyShip.layout?.grounded && _enemyShip.addModule('cloaking')) {
      const cl = _enemyShip.getSystem('cloaking');
      if (cl) { cl.level = 1; cl.desiredPower = cl.level; }
    }

    /* ── A WANTED MAN FLIES A WANTED MAN'S SHIP (update68) ────
     *
     * The player fought one and reported it: "przeciwnik był bardzo
     * słaby, każdy pirat powinien oprócz kapitana mieć 2 różne działka
     * lub osłony, mocniejsi to i to". He is right — a name you crossed
     * half a sector for cannot be an ordinary patrol boat.
     *
     * ONLY the men on the board (his call). Ordinary enemies stay
     * exactly as they are, so the difficulty ladder of a normal run is
     * untouched and only the hunt gets harder.
     *
     *   on the board          → two DIFFERENT guns, or shields
     *   already escaped once  → both, and heavier guns
     */
    {
      const w = _wantedHere;
      if (w) {
        const hard = (w.escapes ?? 0) > 0;
        // Two different guns: never the same barrel twice, so the
        // player has two charge clocks to read instead of one.
        const PAIR = hard ? ['laser_heavy', 'missile_basic']
                          : ['laser_basic', 'missile_basic'];
        /* Fitted BEFORE the generic "every bay gets a gun" loop below,
           on purpose: that loop only fills EMPTY bays, so arming him
           afterwards silently did nothing and he flew with two of the
           same starter laser. */
        PAIR.forEach((key, slot) => {
          if (slot >= _enemyShip.weaponSlots) return;
          if (_enemyShip.weapons[slot]?.defKey === key) return;
          /* UNBOLT WHAT THE LAYOUT CAME WITH FIRST. `installWeapon`
             refuses an occupied bay, so without this the hull kept its
             default starter laser in slot 0 and the "two DIFFERENT
             guns" rule quietly became "one different gun". */
          if (_enemyShip.weapons[slot]) _enemyShip.scrapWeapon(slot);
          _enemyShip.installWeapon(key, slot);
        });
        // …and a bubble, if he has already slipped a brig once.
        const sh2 = _enemyShip.getSystem('shields');
        if (hard) {
          if (sh2) { sh2.level = Math.max(sh2.level, 2); sh2.desiredPower = sh2.level; }
          else if (_enemyShip.addModule('shields')) {
            const ns = _enemyShip.getSystem('shields');
            if (ns) { ns.level = 2; ns.desiredPower = 2; }
          }
        } else if (!sh2 && !_enemyShip.getSystem('cloaking')) {
          /* Two guns OR a bubble — he has the guns, so a plain pirate
             who ended up with neither gets the bubble instead. */
          if (_enemyShip.addModule('shields')) {
            const ns = _enemyShip.getSystem('shields');
            if (ns) { ns.level = 2; ns.desiredPower = 2; }
          }
        }
      }
    }

    /* ── EVERY WEAPON BAY GETS A GUN (update42) ──────────────
       The second gun used to be gated on `elite || sector >= 2`, so a
       sector-1 Gunship flew with two weapon modules, four crew and ONE
       laser — and `assignStations` posted a gunner to the empty bay,
       where he sat at a dead console for the whole fight. If the hull
       has the bay, the bay is armed; sector and elite decide how GOOD
       the gun is, not whether it exists. */
    for (let slot = 1; slot < _enemyShip.weaponRooms.length; slot++) {
      if (_enemyShip.weapons[slot]) continue;
      if (slot === 1 && sector >= 2 && Math.random() < ENEMY_TORPEDO_ODDS) {
        _enemyShip.installWeapon('torpedo_launcher', slot);
        continue;
      }
      const heavy = elite && sector >= 2;
      _enemyShip.installWeapon(heavy ? 'laser_heavy' : 'laser_basic', slot);
    }
    /* ── THE YARD'S HABITS (update117) ─────────────────────────
       Before the balance rules below, so the module levels, the crew
       count and the reactor all follow what was fitted here. */
    // Phoenix: the first barrel is often better than the layout's.
    if (traits.gunUpgradeOdds && !_wantedHere && _enemyShip.weapons[0]?.defKey === 'laser_basic'
        && Math.random() < traits.gunUpgradeOdds) {
      _enemyShip.scrapWeapon(0);
      _enemyShip.installWeapon(sector >= 2 ? traits.gunLate : traits.gunEarly, 0);
    }
    /* Aquarius: a hospital ship — and a better medbay. Every Aquarius
       hull is DRAWN with one (section 304 holds the layouts to that), so
       there is nothing to fit, only to upgrade. */
    if (traits.medbayLevel) {
      const mb = _enemyShip.getSystem('medbay');
      if (mb) { mb.level = Math.max(mb.level, traits.medbayLevel); mb.desiredPower = mb.level; }
    }
    // Terra: a hotter drive (the spare reactor comes with the reactor rule below).
    if (traits.enginesBonus) {
      const en = _enemyShip.getSystem('engines');
      if (en) {
        en.level = Math.min(en.level + traits.enginesBonus, SYSTEM_DEFS.engines?.maxLevel ?? 8);
        en.desiredPower = en.level;
      }
    }

    // ── Balance rule: weapon module level EQUALS its gun's power
    //    cost (1-power gun → lvl-1 module, 2-power → lvl-2). ──
    _enemyShip.weapons.forEach((w, i) => {
      if (!w) return;
      const sys = _enemyShip.weaponSystemFor(i);
      if (!sys) return;
      sys.level        = w.powerCost;
      sys.desiredPower = sys.level;
    });
    // Gunless weapon modules idle at level 1
    _enemyShip.weaponRooms.forEach((r, i) => {
      if (!_enemyShip.weapons[i] && r.system) {
        r.system.level = 1; r.system.desiredPower = 0;
      }
    });

    // ── Balance rule: reactor level EQUALS the total power the ship
    //    needs to run every module at full (capped by the hull). ──
    const need = _enemyShip.systems
      .filter(s => s.type !== 'reactor')
      .reduce((a, s) => a + s.maxPower, 0);
    _enemyShip.reactor.level = Math.min(need, _enemyShip.reactor.maxLevel);
    /* Terra builds the reactor bigger than the ship needs (update117):
       spare power on the bar, which is what the player reads. */
    if (traits.reactorSpare) {
      const want = need + traits.reactorSpare;
      _enemyShip.reactor.maxLevel = Math.max(_enemyShip.reactor.maxLevel, want);
      _enemyShip.reactor.level = want;
    }
    _enemyShip._allocateDefaultPower();

    // Crew sized so every GUN has an operator (operator rule):
    // pilot + one gunner per installed weapon + 1 spare repairer.
    //
    // FLOORS (update38). A two-man crew meant a boarding party of three
    // walked onto an empty ship and the fight was over before it started.
    // Every hull now carries at least THREE, and a hull with two weapon
    // BAYS carries at least FOUR — the bays are what the ship has room
    // for, so the floor holds even when only one gun is fitted.
    const guns     = _enemyShip.weapons.filter(w => w).length;
    const gunRooms = _enemyShip.weaponRooms.length;
    const floor    = gunRooms >= 2 ? 4 : 3;
    /* A HAND FOR THE SHIELDS AND ONE SPARE (update97). The helm, the guns
       and the shield console now stay manned through the fight (combat.js,
       the posts that fight), so the crew counts them all and adds one
       hand who is free to repair and fight fires. */
    const shieldHand = _enemyShip.getSystem('shields') ? 1 : 0;
    const crewN    = Math.max(floor, 1 + guns + shieldHand + 1 + (elite ? 1 : 0));
    makeEnemyCrew(crewN, _enemyShip.layoutKey, Save.getRun()?.sector ?? 1)
      .forEach(c=>_enemyShip.addCrew(c));
    _enemyShip.assignStations();
    _seatCaptives();
    /* Air for the people aboard, and the power to run it (update87) —
       LAST, after the captives: their carbonite bay is fitted in
       `_seatCaptives`, and sizing before it left a raider carrying
       prisoners one pip short (it was, before this package, too). */
    _enemyShip.sizeAirForCrew(crewN);
  }

  /* ── SOMEBODY ELSE'S PRISONERS (update72) ──────────────────
   *
   * "nieraz wrogi statek będzie przewoził więźniów, których będzie
   * można uratować" — the player's own idea, and the design document's
   * order of work: the cell first, the people in it afterwards.
   *
   * They are seated ONLY on a hull that has a brig, which is what
   * makes them findable rather than random: the module is drawn on the
   * enemy blueprint, so a player who has learned to read it knows
   * before he sends anybody across that there is something to send
   * them for. No brig, no captives, however the dice fall.
   *
   * Not on a boss and not on a derelict: a boss fight is its own
   * contract, and a hulk with nobody alive aboard is looted, not
   * boarded.
   */
  const CAPTIVE_CHANCE = 0.45;
  function _seatCaptives() {
    if (!_enemyShip || BossManager.isActive) return 0;
    if (Math.random() >= CAPTIVE_CHANCE) return 0;
    /* ── AND THE CELL BLOCK IS FITTED WITH THEM ───────────────
     *
     * No enemy layout ships with a brig — the first version of this
     * asked for one and got nothing, on every hull in the game, so
     * captives could never appear at all. The deliberate-breakage run
     * is what said so: two reverts about the seating rate could not be
     * told apart, because the answer was always zero.
     *
     * A hull that is carrying prisoners has a cell block, so it gets
     * one HERE — into the bay `_spawnEnemy` strips when the loadout
     * rolls no shields, which is exactly the "free for something else"
     * that note above it promises. The player can read it off the
     * enemy blueprint before he sends anybody across, which is what
     * makes the rescue a decision rather than a surprise.
     */
    let brig = _enemyShip.getSystem('carbonite');
    if (!brig) {
      /* A HULL RUNNING PRISONERS GAVE SOMETHING UP FOR THE CELLS.
         No enemy layout has a spare compartment, so one is taken — the
         shield bay first, then the softer modules. That is a trade the
         player can SEE: a ship carrying people is a ship with a hole
         in its defences, and boarding it is the easier fight as well
         as the one worth having. The reactor, the drive, the cockpit
         and the guns are never touched; a hull that cannot fly is not
         an encounter. */
      /* ── AN EMPTY BAY, AND NOTHING ELSE ──────────────────────
       *
       * Two versions of this were wrong before the tests stopped them,
       * and both were wrong the same way: they took a module the enemy
       * was USING. Stripping the shield bay quietly disarmed half the
       * enemies in the game (three tests said so within a minute);
       * falling back to "any soft module" then started eating cloaks,
       * and the loadout statistics said so on the next run.
       *
       * So: the cells go in a bay that is already bare — the one
       * `_spawnEnemy` leaves when the loadout rolls neither shields nor
       * a cloak. Nothing is taken from the fight, the frequency rides
       * on a roll that already exists, and it reads on the blueprint:
       * a hull with no bubble and no shimmer might be carrying people
       * instead. If there is no free bay there are no prisoners, which
       * is the right answer rather than a compromise. */
      const room = _enemyShip.rooms.find(r => r.type === 'empty');
      if (!room) return 0;
      if (!_enemyShip.addModuleAt('carbonite', room.id)) return 0;
      brig = _enemyShip.getSystem('carbonite');
      if (brig) { brig.level = 1; brig.desiredPower = 1; }
    }
    if (!brig) return 0;
    const room = _enemyShip.getRoomById(brig.roomId);
    if (!room) return 0;
    /* ONE PER LEVEL, exactly like your own cells (update63's rule) —
       the module says how many it can hold and nothing else does. */
    const n = Utils.randInt(1, Math.max(1, brig.level) + 1);
    let seated = 0;
    for (let i = 0; i < n; i++) {
      const c = new CrewMember({ isPlayer: false, isPrisoner: true });
      c.roomId = room.id; c.homeRoomId = room.id;
      c.x = room.cx + Utils.randFloat(-12, 12);
      c.y = _enemyShip.floorWalkY(room.floor, room.cy);
      _enemyShip.addCrew(c, true);
      /* AND INTO A SLAB (update93): their prisoners are kept the way
         ours are. A bay with no slab left for him (no power for it)
         leaves him sitting thawed in the bay, as before. */
      _enemyShip.freezeCaptive(c);
      seated++;
    }
    return seated;
  }

  /** Start combat vs a fresh enemy. In a nebula BOTH ships run at −2 power. */
  function _startCombat(difficulty, nebula = false, opts = {}) {
    /* A NEW FIGHT GIVES THE ORDERS BACK (update53). Once per fight is
       the rule, so "the fight" has to be a real boundary — and it is
       this line, the one place every gun duel begins. */
    Commander?.resetOrders?.();
    Chips?.resetRunning?.();        // a new fight: no tablet still running (update99)
    /* ── A MAN WHO GOT AWAY ONCE COMES BACK HEAVIER (update67) ──
     *
     * The poster on this node carries `escapes`, and that one number
     * buys him everything: a better hull and heavier crew HERE, more
     * levels and chips on his commander below, and a bigger price on
     * the board. The player's decision, and the right one — a re-listed
     * pirate who was only DEARER would be free money for a crew that
     * has already beaten him.
     *
     * Read BEFORE the hull is spawned, because the hull is the half
     * that has to change first. */
    const escapee = _wantedOnThisNode();
    if (escapee && escapee.escapes > 0) difficulty = 'hard';
    _spawnEnemy(difficulty);
    _nebulaCombat   = nebula;
    _surrenderAsked = false;
    _enemySealed    = false;
    _derelictOffered = false;
    _boardingParty = null; _enemyParty = null; _counterBoarded = false;
    _setSalvage(null); _leaveWarnT = 0;
    _playerShip.reactor.penalty = nebula ? 2 : 0;
    _enemyShip.reactor.penalty  = nebula ? 2 : 0;
    /* …and the budget is settled NOW, not on the next frame: a frame
       drawn in between showed the reactor at "-1/6" (update98). */
    _playerShip.reflowPower();
    // The player's power layout CARRIES OVER between fights — it used
    // to be wiped back to defaults every battle, undoing whatever they
    // had set up. Only a ship that has never been configured (fresh
    // run) gets the automatic spread. The enemy always re-rolls.
    if (!_playerShip.hasPowerPreference()) _playerShip._allocateDefaultPower();
    _enemyShip._allocateDefaultPower();
    /* ── OUR BUBBLE IS WHATEVER WE BROUGHT (update97) ─────────
     * It used to fill to the top the moment we jumped in — jj: "jak nie
     * jest załadowana to nie jest, a jak jest 1, 2, 3 to jest; ten sam
     * stan". The layers carry over from the last place; only the lesson
     * debt starts again at zero, as it always has.
     *
     * HIS CREW IS AT ACTION STATIONS, AND HIS SHIELDS ARE UP — most of
     * the time. jj saw every enemy caught napping. Now they are at their
     * posts with the bubble full, and one fight in ENEMY_SURPRISE_ODDS
     * they are not: crew wherever they were, emitters cold. */
    _playerShip.resetShieldDebt();
    /* Only a ship you jump in on can be caught napping: one that hailed
       you, set a trap or refused a parley has been watching you come. */
    const surprised = !!opts.canSurprise && !opts.ambush && Math.random() < ENEMY_SURPRISE_ODDS;
    CombatManager.enemySurprised = surprised;
    if (!surprised) {
      _enemyShip.prechargeShields();
      _enemyShip.snapToStations();
    } else {
      _enemyShip.resetShieldDebt();
      UI.notify('They were not ready for you — crews off station, emitters cold.', 'good');
    }
    /* ── UNLESS YOU SHOOK HIS HAND FIRST (update70) ───────────
     *
     * The third door of the parley: you accepted the trade and opened
     * fire while his emitters were still down. He starts with NO
     * bubble at all — it charges from zero like any other knocked-out
     * shield — and that is the whole prize. His guns start uncharged
     * because every gun does, on both sides, in the four lines above.
     *
     * Done HERE, inside the one function that arms a fight, so there
     * is no window in which the shields are up and something else has
     * to take them down again. */
    if (opts.ambush && _enemyShip) {
      const ss = _enemyShip.getSystem('shields');
      if (ss) { ss._shieldBars = 0; ss._shieldTimer = 0; }
      UI.notify('His emitters are still down — hit him NOW.', 'warn');
    }
    // …but GUNS are NOT: charging starts when the battle does
    [_playerShip, _enemyShip].forEach(sh => sh.weapons.forEach(w => {
      if (w) { w.charge = 0; w.armed = false; }
    }));
    // Unburied corpses begin to rot once a new fight starts
    _playerShip.markCombatStart();
    _playerShip.weapons.forEach(w => { if (w) { w.targetRoom = null; w.queuedShot = false; } });

    /* ── THE OTHER SIDE HAS A COMMANDER TOO (update50) ────────
       Not every ship: a lone scout in sector 1 is a lone scout. The
       further in, the likelier — and the boss always has one. He is
       seated here and cleared the moment the fight ends, so he can
       never pay bonuses to the next enemy. */
    if (typeof Commander !== 'undefined' && Commander.rollEnemy) {
      const sec = Save.getRun()?.sector ?? 1;
      /* HIS NODE MEANS HE IS HERE (update66). Not every ship has a
         commander — a lone scout in sector 1 is a lone scout — but a
         node with a poster on it is not an ordinary fight, and rolling
         "no commander" there would put the player on the square he
         flew across the sector for and give him nobody to catch. */
      const posted = !BossManager.isActive && !!_sectorMap?.current?.()?.wantedId;
      const chance = (BossManager.isActive || posted)
        ? 1 : Math.min(0.55, 0.12 + sec * 0.12);
      let boss = Math.random() < chance
        ? Commander.rollEnemy(sec, BossManager.isActive ? { level: 6 + sec } : {})
        : null;
      /* ── A NAME OFF THE LIST (update64) ───────────────────
       *
       * A rolled commander is sometimes somebody the yard is already
       * looking for. He is not a COPY of that record — he carries its
       * `wantedId`, and every price and every state change downstream
       * goes back through `Save.wantedById`. The design names two
       * copies of one pirate as this package's biggest risk, and this
       * is the line where that would have happened.
       *
       * Never the boss: the contract boss is his own fight.
       */
      if (boss && !BossManager.isActive) boss = _seatWantedPirate(boss, sec);
      Commander.setEnemy(boss);
      if (boss && _enemyShip) {
        _enemyShip.commander = boss;
        Commander.reseatMaxHp?.(_enemyShip.crew);
      }
    }

    STATE = 'combat'; _beginFade(); _combatTimer = 0; _combatFired = false;
    CombatManager.begin(_playerShip, _enemyShip, difficulty === 'hard' ? 'hard' : _difficulty());
    /* BOTH CLOSED, THEN OPEN (update118): he drops out of his jump, and
       the roofs come off for the fight. With the films off: open now. */
    if (typeof JumpScene !== 'undefined') JumpScene.arrive(_playerShip, _enemyShip);
    /* The field is the fight's (update100): begin() cleared any old one,
       end() will clear this one, whichever way the fight ends. */
    if (opts.asteroids) {
      CombatManager.startAsteroidField();
      UI.notify('ASTEROID FIELD — rocks will fall on both ships. Watch for the marked room.', 'warn');
    }
    Audio.resume(); Audio.playMusic('combat');
    if (nebula) UI.notify('NEBULA — both ships at −2 power', 'warn');
  }

  /* ══ THE BLACK MARKET (update70) ═══════════════════════════
   *
   * The other side of a bad name. Until now karma below the middle was
   * all penalty — dearer fuel, dearer hands, closed docks — and the
   * player asked for something on the other side of it: "ze zla karma
   * dowodca bedzie mogl handlowac z piratami… jezeli bedzie handlowal
   * to nie ma walki".
   *
   * ONLY with a man off the wanted board. That is what makes it a
   * decision instead of a discount: the crate in his hold and the
   * bounty on his head are the same trip, and you cannot have both.
   *
   * WHO may deal is `Commander.pirateWillDeal` — which is the port
   * surcharge band, not a new threshold. The same reputation that
   * costs you at the pump is the one that gets you through his airlock.
   */
  function _parleyRefusal() {
    if (BossManager.isActive) return 'boss';
    const w = _wantedOnThisNode();
    if (!w) return 'not a poster';
    if (typeof Commander === 'undefined' || !Commander.pirateWillDeal) return 'no commander code';
    if (!Commander.active?.()) return 'nobody in the chair';
    if (!Commander.pirateWillDeal()) return 'your name is too clean for him';
    return null;
  }

  /**
   * Three doors, and the player picked the third one himself.
   *
   * TRADE            — his hold opens, and the bounty goes with him.
   * REFUSE           — the fight that was always going to happen.
   * ACCEPT AND STRIKE— you say yes and shoot: he comes in with his
   *                    shields down, and it costs you five karma.
   *
   * Returns true when the parley has taken over the turn.
   */
  function _maybeParley(difficulty = 'normal') {
    if (_parleyRefusal()) return false;
    const w = _wantedOnThisNode();
    const cap = Commander.active();
    const robbery = Commander.KARMA?.ROBBERY ?? -5;
    _event = {
      title: `${w.name} opens a channel`,
      text: `He knows the yard wants him and he knows what your name is worth `
          + `these days. "Nobody has to shoot," he says. "I am carrying more than `
          + `I can move." His hold is open — and so are his shield emitters, `
          + `while you are talking.`,
      choices: [
        { label: `Trade with him — his ${w.bounty} CC bounty goes`,
          result: { blackMarket: w.id } },
        { label: 'Refuse — you came for him',
          result: { combat: difficulty } },
        { label: `Accept, then open fire (${robbery} karma)`,
          result: { combat: difficulty, ambush: true, karma: robbery } },
      ],
    };
    STATE = 'event';
    return true;
  }

  /** Customs at the port's door (update90a) — see Station.customs. */
  function _customs(station) {
    const run = Save.getRun();
    if (!run || !station?.customs) return null;
    const purse = { scrap: run.scrap ?? 0 };
    const r = station.customs(_playerShip, purse);
    if (!r) return null;
    Save.updateRun({ scrap: purse.scrap });
    _syncAmmo(); _syncFuel();          // the HUD mirrors of the hold
    UI.notify(`Customs seized ${r.seized.length > 1 ? r.seized.length + ' crates of contraband' : 'the ' + r.seized[0]}.`, 'alert');
    if (r.paid) UI.notify(`Fine: ${r.paid} CC taken.`, 'alert');
    if (r.taken.length) {
      UI.notify(`Short of the fine — they took ${r.taken.map(t => t.label).join(', ')} instead.`, 'alert');
    }
    return r;
  }

  /**
   * Open his hold. A `Station` with a flag — the same counter, the
   * same hold probe, the same buy methods; what changes is the stock
   * and the price. Building a second shop screen for this would have
   * been two shops to keep in step for the rest of the project.
   */
  function _openBlackMarket(wantedId) {
    const w = (typeof Save !== 'undefined' && Save.wantedById)
      ? Save.wantedById(wantedId) : null;
    _station = new Station(Save.getRun()?.sector ?? 1, Date.now(),
                           { blackMarket: true, owner: w?.name });
    /* HE SAILS AWAY WITH HIS PRICE ON HIM. The poster stays up — you
       can hunt him on another contract — but this meeting is spent,
       and the node is not a fight any more. That IS the cost of the
       trade, and the player set it: "handel z nim jest, ale wtedy
       schodzi Ci nagroda". */
    const node = _sectorMap?.current?.();
    if (node) node.wantedId = null;
    STATE = 'station'; _beginFade();
    UI.openStation(_station, _playerShip);
    if (w) UI.notify(`${w.name} will be gone before the yard hears of this.`, 'warn');
  }

  /**
   * Pay for whatever was finished since the last frame.
   *
   * `Save.payRunGoal` is what makes this safe to call sixty times a
   * second: it returns false for a goal that has already been settled,
   * so the money changes hands exactly once however often we ask.
   */
  function _payRunGoals() {
    const goals = Save.runGoals?.() ?? [];
    goals.forEach(g => {
      if (!g.done) return;
      /* ONE GUARD, AND IT IS THE ONE THAT OWNS THE FLAG. Checking
         `g.paid` here as well read as belt and braces and was really a
         mask: it made `payRunGoal`'s own guard unreachable, so the rule
         that stops a goal paying twice could be deleted without
         anything noticing. The save layer owns the record; it answers
         the question. */
      if (!Save.payRunGoal(g.key)) return;
      const run = Save.getRun();
      if (run) Save.updateRun({ scrap: (run.scrap ?? 0) + g.cc });
      UI.notify(`OBJECTIVE — ${g.label}: ${g.need} ${g.unit}. +${g.cc} CC`, 'good');
      Audio.sfx.scrapCollect?.();
    });
  }

  /** 35%: hostiles hail you and demand tribute instead of fighting */
  function _maybeNegotiate(difficulty, nebula) {
    const run = Save.getRun();
    const toll = 15 + (run?.sector ?? 1) * 10;
    const choices = [
      { label: `Pay ${toll} CC tribute`, result: { scrap: -toll } },
    ];
    if (_playerShip.crew.length > 1) {
      /* Handing one of your own to a raider to save the rest is the
         worst thing on the karma table that is not an evacuation. */
      choices.push({ label: 'Hand over a crew member',
                     result: { loseCrew: true,
                               karma: Commander?.KARMA?.KILL_HELPLESS ?? -10 } });
    }
    choices.push({ label: 'Refuse — battle stations!', result: { startPending: true } });
    _pendingCombat = { difficulty, nebula };
    _event = {
      title: 'Hailing Frequencies',
      text: nebula
        ? 'A ship emerges from the nebula. "Tribute, or we take it from your wreck." Sensors show the nebula drains −2 power from BOTH ships.'
        : '"This is our territory. Pay the toll — minerals or a pair of hands — or we open fire."',
      choices,
    };
    STATE = 'event';
  }

  /** DISTRESS BEACON — the tank is dry and the drive can't spin up.
   *  Somebody always answers; the question is what they want for the
   *  He2. This is the anti-softlock: the 'beg' branch always yields
   *  fuel, so a run can never dead-end on an empty tank. */
  /* THE BEACON IS A RESCUE, NOT A FUEL TAP (update42).
     `_travelTo` refused a dry jump and then opened this event EVERY
     time, with no limit — so an empty hold cost nothing: click a node,
     beg, take 1-2 He2, click again. He2 was the one resource in the
     game with no teeth. The beacon now answers ONCE per node; stay put
     with a dry hold and the channel goes quiet. */
  let _sosNode = null;

  function _maybeSOS(force = false) {
    const run = Save.getRun();
    if (!run) return;
    const here = _sectorMap?.currentId ?? null;
    // `force` is the re-offer after an unaffordable trade: that is the
    // SAME broadcast still on the air, not a second one.
    if (!force && _sosNode !== null && _sosNode === here) {
      UI.notify('The channel is dead — nobody else is out here.', 'alert');
      return;
    }
    _sosNode = here;
    const sector  = run.sector ?? 1;
    const price   = 25 + sector * 15;          // trader's asking price
    const canPay  = run.scrap >= price;
    const cargo   = (_playerShip?.boxedGuns().length ?? 0) > 0;

    const choices = [];
    choices.push({
      label: canPay ? `Buy 4 He2 from the trader (${price} CC)`
                    : `Buy 4 He2 — need ${price} CC (you have ${run.scrap})`,
      result: canPay ? { scrap: -price, fuel: 4 } : { sosRetry: true },
    });
    if (cargo) {
      choices.push({
        label: 'Trade a spare weapon from cargo for 5 He2',
        result: { sosTradeWeapon: true },
      });
    }
    choices.push({
      // Robbing people who came to sell to you: "ograbienie kosztem innych".
      label: 'Answer the scavengers — take their He2 by force',
      result: { sosFight: true, karma: Commander?.KARMA?.ROBBERY ?? -5 },
    });
    choices.push({
      label: 'Beg for a fuel donation (they will not be generous)',
      result: { sosBeg: true },
    });

    _event = {
      title: 'Distress Beacon',
      text: `The He2 tanks are dry and the drive will not spin up. You broadcast on the open channel. ` +
            `A scavenger crew answers — they have fuel, and they are curious about what you will pay for it.`,
      choices,
    };
    STATE = 'event';
  }

  function _difficulty() {
    const s = Save.getRun()?.sector ?? 1;
    return s>=6?'hard':s>=3?'normal':'easy';
  }

  function _nextSector() {
    const run = Save.getRun(); if (!run) return;
    const final = run.finalSector ?? MISSIONS[run.mission]?.sectors ?? 3;
    const next = run.sector + 1;
    // Past the last sector with no boss left to fight = contract done
    if (next > final) { _finishContract(); return; }
    // A fresh sector starts at its entry lane: clear last sector's
    // node progress, or CONTINUE would try to restore a node id that
    // belongs to a map that no longer exists.
    Save.updateRun({ sector:next, nodeIndex:0, seed:Math.floor(Math.random()*1e9),
                     mapProgress: null });
    // Same `?? 'station'` trap as _continueRun — a contract with
    // boss: null must NOT grow a boss column on the way through.
    const mission = MISSIONS[run.mission] ?? null;
    _sosNode = null;   // node ids repeat per sector — clear the beacon lock
    _sectorMap = new SectorMap(next, Save.getRun().seed, Save.getRun().lane ?? SectorMap.MID_LANE, final,
      !!(mission ? mission.boss : 'station'));
    /* THE BRIG EATS TOO (update67). Once per jump, out of the same
       hold everybody else eats from — the cost of carrying a man home
       is his rations, not the cell. */
    _playerShip?.feedPrisoners?.();
    UI.notify(`Entering Sector ${next}`,'good');
    STATE='map'; _beginFade();
  }

  /** Contract complete: pay the bonus, dock everything at the base and
   *  show the outcome screen. */
  function _finishContract() {
    const run     = Save.getRun();
    const mission = MISSIONS[run?.mission] || MISSIONS.mothership;
    const bossCC  = BossManager.isActive || BossManager.ship ? BossManager.scrapReward : 0;
    const held    = (run?.scrap ?? 0) + bossCC;
    if (run) Save.updateRun({ scrap: held });

    /* ── WHAT THE TWO EDGE CONTRACTS PAY IN (update71) ─────────
     *
     * DELIVERING is the deed, not signing: both of these settle here,
     * at the end of the job, exactly like the CC bonus. A man who took
     * the dirty contract and never came back did not do it.
     *
     * And BEFORE `_dockAtBase` below, deliberately — docking is where
     * the commander leaves the chair, and karma paid after that has
     * nobody to go to. That was the update68 bug with the burial, and
     * it is the same chair. */
    if (mission.karmaPay && _commander && typeof Commander !== 'undefined') {
      const delta = Commander.KARMA?.[mission.karmaPay] ?? 0;
      const r = delta ? Commander.shift(_commander, delta) : null;
      if (r) {
        UI.notify(`${_commander.name}: karma ${r.from} → ${r.to} — ${mission.label}`,
                  delta > 0 ? 'good' : 'warn');
        Base.saveCommander?.(_commander);
      }
    }
    /* The relief run's other payment: whatever was still working in
       their lab. Awarded into the HOLD, before docking unloads it, so
       it lands on the shelf like anything else brought home. */
    if (mission.chipReward) _awardChip({ minLevel: 1, maxLevel: 2 }, 'the people you got out');

    // Banked CC: half of what you finish holding, plus the contract bonus
    const banked = Math.floor(held * 0.5) + mission.ccBonus;


    /* DOCKING CAN NOW STOP AND ASK (update48). If the shelf could not
       take everything, _dockAtBase puts the sorting screen up and calls
       this back when the player is done — so the outcome screen must
       wait for it rather than being set two lines below. */
    _dockAtBase(banked, () => {
      /* THE BOARD FILLS UP BETWEEN JOBS (update64). One new face per
         contract, and `addWanted` refuses past the ceiling — so the
         list is a hunt that keeps up with the player rather than a
         queue that outgrows him.
         Rolled INSIDE the dock callback, on purpose: the hand-over
         happens in `returnFromRun`, so a man delivered on this very
         docking has already left the list and his slot is free for
         the new name. Rolling a line earlier would have silently
         capped the board one short for the rest of the game. */
      const fresh = Save.addWanted ? Save.addWanted(run?.sector ?? 1) : null;
      if (fresh) UI.notify(`New name on the wanted board: ${fresh.name} — ${fresh.bounty} CC.`, 'info');

      _outcomeType  = 'victory';
      _outcomeScrap = held;
      Save.endRun(true);
      STATE = 'outcome'; _beginFade(); _outcomeTimer = 0;
      Audio.stopMusic(1.0);
    });
  }

  /** Put one on everybody's record — the memorial reads these off the
   *  headstone, so they have to be counted while people are still alive
   *  to earn them. Boarders on the enemy hull count too: they were very
   *  much present. */
  function _creditCrew(field) {
    const all = [
      ...(_playerShip?.crew ?? []),
      ...((_enemyShip?.crew ?? []).filter(c => c.isPlayer)),
    ];
    all.forEach(c => { if (c.alive) c[field] = (c[field] ?? 0) + 1; });
  }

  /** Was the thing we just killed the contract's boss? */
  function _bossJustBeaten() {
    if (typeof BossManager === 'undefined') return false;
    // The manager clears `isActive` as the last phase dies, so the
    // flag to read is that it WAS running and has no phases left.
    return !!BossManager.ship && !BossManager.isActive;
  }

  /**
   * Hand the player a TABLET (a chip before update99 — the name stays,
   * the test harness knows it). Never silently: it lands in the hold, and
   * if there is no room the hold screen opens so he chooses what to
   * drop for it — the same rule update48 gave the docking bay.
   */
  /* THE BOSS CHIP HAS ONE PAYMASTER (update54).
   *
   * It used to be paid inside `_onWin`, which is reached only through
   * `CombatManager.isVictory()` — and a managed boss NEVER goes that
   * way. The last phase dying raises `defeated` in the boss machine,
   * and that branch flies the contract straight home:
   * `_finishContract(); CombatManager.end();` and out. So the guaranteed
   * reward for the one fight in the contract that is supposed to give
   * one silently did not exist, exactly as the player reported for the
   * second contract's boss.
   *
   * Now both exits call this, it pays at most once per boss, and the
   * flag is cleared where a boss fight BEGINS — so a second contract
   * pays again and a single kill never pays twice.
   */
  /* WHICH boss has been paid for, not WHETHER one has (update54).
     A boolean needed clearing at the start of every boss fight, and a
     flag somebody must remember to clear is the same shape as every
     drift bug in this project — miss it once and the second contract's
     boss silently pays nothing. Remembering the HULL instead needs no
     clearing at all: the next boss is a different object, so it has
     not been paid, and there is nothing to reset anywhere. */
  let _bossChipPaidFor = null;

  function _payBossChip() {
    if (!_bossJustBeaten()) return null;
    const hull = BossManager.ship;
    if (!hull || _bossChipPaidFor === hull) return null;
    _bossChipPaidFor = hull;
    const run3 = Save.getRun();
    const apophis = (MISSIONS[run3?.mission]?.sectors ?? 2) >= 3;
    /* jj 06.10: the first boss Lv1-2, Apophis Lv3-4 (was II-III / III-IV). */
    return _awardChip(apophis ? { minLevel: 3, maxLevel: 4 } : { minLevel: 1, maxLevel: 2 },
                      apophis ? 'Apophis' : 'the patrol boss');
  }

  function _awardChip(opts, from) {
    if (typeof Chips === 'undefined' || !_playerShip?.cargo) return null;
    const sector = Save.getRun()?.sector ?? 1;
    const key = Chips.rollDrop(sector, { ...opts, maxLevel: opts.maxLevel ?? 4 });
    const it = _playerShip.cargo.add(key);
    const def = CARGO_ITEMS[key];
    if (it) {
      UI.notify(`${def.label} recovered from ${from}.`, 'good');
      return it;
    }
    UI.notify(`${def.label} from ${from} — no room in the hold, make some.`, 'warn');
    _queuedChip = key;
    return null;
  }

  function _onWin() {
    /* ── A NAME OFF THE BOARD LEAVES A BODY (update68) ─────────
     *
     * The player blew up a wanted pirate and got nothing: "zniszczyłem
     * go ale ciała nie dostałem, powinienem je dostać?" He should —
     * a poster is worth something dead, and the whole point of the two
     * prices is that the gun is the cheap way of collecting.
     *
     * ONLY the men on the board (his call). An ordinary enemy commander
     * still goes up with his ship; there is no office paying for him.
     * The brig is still the ONLY way to bring one in ALIVE, which is
     * what keeps that module worth its room.
     *
     * Read BEFORE `setEnemy(null)` below — that line is what clears
     * him, and running after it would find nobody. */
    _bagWantedCommander();

    // The enemy commander leaves with his ship (update50).
    Commander?.setEnemy?.(null);
    /* THE NEBULA ENDS WITH THE FIGHT (update90b). Its −2 was cleared
       only on the way OUT of the combat screen — JUMP, a flight, a run
       — so after a win the ship sat repairing and boarding the wreck on
       two units short, and the player saw the nebula switch off only
       with his next move on the map. The fight is over here. */
    if (_playerShip?.reactor) _playerShip.reactor.penalty = 0;
    _nebulaCombat = false;
    const reward = CombatManager.scrapReward;
    const run = Save.getRun();
    if (run) Save.updateRun({ scrap: run.scrap+reward });
    UI.notify(`+${reward} CC`,'good');
    Audio.sfx.scrapCollect();
    // Jumps burn He2, so wrecks have to give some back — otherwise a
    // long sector between stations can strand the run for good.
    {
      const r2 = Save.getRun();
      // A fight picked BECAUSE we were dry always pays out in fuel —
      // that is the whole reason we took it.
      if (r2 && _sosFightPending) {
        const gain = Utils.randIn(4, 7);
        _sosFightPending = false;
        const r = _addFuel(gain);
        UI.notify(`Their tanks are ours: ${_fuelGainMessage(r)}`, r.spilled ? 'warn' : 'good');
      } else if (r2 && Math.random() < 0.5) {
        const gain = Utils.randIn(1, 2);
        const r = _addFuel(gain);
        UI.notify(`${_fuelGainMessage(r)} siphoned from the wreck`, r.spilled ? 'warn' : 'good');
      }

      /* ── A WON FIGHT NEVER LEAVES YOU STRANDED (update68) ───
       *
       * The siphon above is a coin toss, so a player who was already
       * dry could win a battle and still have nothing to jump with —
       * no fuel, no way to reach a station, nothing to do but reload
       * the page and fight it again. The player reported exactly that:
       * "normalnie jest utknięcie, więc zrób tak aby zawsze w tej
       * sytuacji dali 1 he2".
       *
       * So: after every won fight, if the tanks are EMPTY, one cell
       * comes out of the wreck. Only at zero — this is a floor under
       * the run, not a fuel supply, and a player with one cell left
       * still has a real decision about where to spend it.
       */
      if (_fuelAboard() <= 0) {
        const r = _addFuel(1);
        if (r.loaded > 0) {
          UI.notify('Their last cell — enough for one more jump. Do not waste it.', 'warn');
        }
      }
    }
    /* ── A BOSS ALWAYS PAYS A CHIP (update49, spec §9) ────────
     *
     * Not a roll: exactly one, guaranteed, from the pair of levels
     * that fight is worth. The Border Patrol boss hands out a II or a
     * III; Apophis is the ONLY source of a level IV in the game.
     *
     * It goes through _awardChip, which puts it in the hold or, when
     * the hold is full, opens the hold screen rather than dropping it
     * — a guaranteed reward that silently evaporates is worse than no
     * reward at all, and update48 built that door already. */
    _payBossChip();

    // Winning a gun duel is not melee practice — no combat XP here.
    /* A HULL THAT GOES UP leaves its gun in the wreckage (update97) —
       `_spawnSalvage` puts it in a crate. Only a win with no wreckage
       (a boss, a hulk) still hands it over here. */
    if (CombatManager.weaponDrop && _playerShip && !_salvageWillSpawn()) {
      // Install into a free weapon MODULE, otherwise stash it in cargo
      let slot = -1;
      for (let i = 0; i < _playerShip.weaponRooms.length; i++) {
        if (!_playerShip.weapons[i]) { slot = i; break; }
      }
      if (slot !== -1 && _playerShip.installWeapon(CombatManager.weaponDrop, slot)) {
        UI.notify('Weapon recovered and installed!', 'good');
      } else {
        // No free mount — the crate has to go in the hold, and that is
        // a decision, so it gets its own screen once the fight settles.
        _queueWeaponLocker(CombatManager.weaponDrop);
      }
    }
  }

  function _onLose() {
    _setSalvage(null);
    // The enemy commander leaves with his ship (update50).
    Commander?.setEnemy?.(null);
    _sosFightPending = false;
    // The hull and everyone aboard were CHECKED OUT of the base at
    // launch — losing here simply means they never come back. There is
    // nothing to delete; the hangar and barracks have been short all along.
    Base.loseRun();
    /* HE GOES DOWN WITH HER (update43). The base, the other commanders
       and everything left on the shelf are untouched — only his levels
       and his karma are gone. No end of game. */
    if (_commander) {
      const lostName = _commander.name;
      /* HE GOES ON THE MEMORIAL TOO (update68). Until now a commander
         simply vanished from the game — no headstone, no line, nothing
         to say he had ever flown. The player asked for the men who did
         not come home to be visible somewhere, and he is the one who
         never can. */
      Save.addCommanderToGraveyard?.(_commander);
      Base.loseCommander?.(_commander.id);
      UI.notify(`Commander ${lostName} was lost with the ship.`, 'alert');
      _commander = null;
    }
    Commander?.setActive?.(null);
    const lostShip = SHIP_CATALOG[Save.getRun()?.shipKey]?.label ?? 'The ship';
    UI.notify(`${lostShip} and her crew are lost — the base keeps only what came home.`, 'alert');
    _outcomeType='defeat'; _outcomeScrap=0;
    Save.endRun(false); Audio.stopMusic(1.0);
    STATE='outcome'; _beginFade(); _outcomeTimer=0;
  }

  function _saveShip() {
    if (!_playerShip) return;
    const patch = {
      ship: _playerShip.serialise(),
      // Intruders are not part of the ship (update42). The cat is
      // `isPlayer`; the rats and spiders ride in `ship.pests`, inside
      // the ship record above (update84).
      crew: _playerShip.crew.filter(c => c.isPlayer)
                            .map(c => c.serialise()),
    };
    /* WHERE WE GOT TO (update38).
     * _saveShip runs after every jump, so this is the one place that is
     * guaranteed to see the map right after it moved. Without it,
     * reloading mid-contract flew the whole sector again — the save
     * knew the sector number and the seed but not the node. */
    if (_sectorMap?.serialiseProgress) patch.mapProgress = _sectorMap.serialiseProgress();
    Save.updateRun(patch);
  }

  /* The renderer draws the order buttons grey without a commander, and
     it must be asking the SAME question the click handler answers —
     a button that looks live and then refuses is worse than one that
     is plainly dead. This is that one question, published. */
  return {
    init,
    hasCommander: _hasCommander,
    /* WHICH SCREEN IS UP. One word, read-only. The promotion screen
       is the first full-screen panel with no module of its own to
       ask (`LootScreen.isOpen()` and friends answer for the rest),
       and a browser test that cannot see it would have to guess. */
    state: () => STATE,
  };
})();

window.addEventListener('DOMContentLoaded', () => {
  Game.init().catch(err => console.error('[Game] Fatal:', err));
});
window.addEventListener('pointerdown', () => Audio.resume(), { once: true });
