/* ============================================================
   MOON WARS — station.js
   Station shop: random stock, limited supply,
   all shop categories with buy logic.
   ============================================================ */

'use strict';

// ── Station types ─────────────────────────────────────────

const STATION_TYPES = ['general','military','science','outpost'];

// ── Shop item templates ───────────────────────────────────

const REPAIR_PRICES   = { hull: 3, system: 40 };    // per hp / per system
const FUEL_PRICE      = 3;
const MISSILE_PRICE   = 6;
const CREW_PRICE      = 60;

/**
 * THE WORLD READS KARMA (update61).
 *
 * Every price a port quotes goes through here, and NOWHERE ELSE
 * multiplies it a second time. The quote methods at the bottom of this
 * file are the only price register in the shop — the buy methods ask
 * them what something costs instead of doing the arithmetic again,
 * because two copies of a price drift the moment one of them learns
 * about karma and the other does not.
 *
 * Guarded on `typeof` so a harness that loads station.js alone still
 * prices things at par.
 */
function karmaPriceFactor() {
  return (typeof Commander !== 'undefined' && Commander.priceFactor)
    ? Commander.priceFactor() : 1;
}
/**
 * Upgrades get EXPONENTIALLY dearer. A linear price made maxing the
 * reactor a formality; now the last few pips are a real campaign goal.
 *
 *   reactor lvl  4 →  ~34 CC      lvl 10 → ~132 CC     lvl 15 → ~380 CC
 *
 * GROWTH is the per-level multiplier; the linear term keeps early
 * upgrades affordable so the curve only bites at the top.
 */
const UPGRADE_GROWTH  = 1.22;
const REACTOR_PRICE   = (level) =>
  Math.round((10 + level * 4) * Math.pow(UPGRADE_GROWTH, Math.max(0, level - 3)));

/* MODULE_DEFS IS GONE (update40).
 *
 * It was a second, flat price list for upgrading a module — 55-80 CC —
 * sitting beside the live exponential one (`systemUpgradeCost`), which
 * is exactly the disease that produced the reactor "you don't have
 * enough CC" bug in update34: two prices for one thing, and they drift.
 *
 * Worse, this half never even reached the player. Every station visit
 * rolled 1-3 of these into `stock.modules`, the station screen renders
 * `stock.newModules` (a different list) and never `stock.modules`, and
 * `buyModule` had no call site anywhere. The stock was generated and
 * thrown away on every single visit.
 *
 * The real path is: click a module on the blueprint → the detail panel
 * → UPGRADE at `systemUpgradeCost(sys)`. That one works, and it is now
 * the only one.
 */

// Crew name pool for recruits
const RECRUIT_NAMES = [
  'Pax','Rho','Sable','Talon','Uma','Vox','Wren',
  'Xeno','Yuki','Zeb','Frost','Blaze','Storm','Arc',
];

// ── Station class ─────────────────────────────────────────

class Station {
  /**
   * @param {number} sector - current sector (affects prices and stock)
   * @param {number} seed   - RNG seed for stock
   */
  constructor(sector = 1, seed = 0, opts = {}) {
    this.sector  = sector;
    this.seed    = seed;
    /* ── A HOLD IS NOT A PORT (update70) ───────────────────────
     *
     * The black market is a Station with a flag, not a second shop.
     * The counter, the buy methods, the hold probe and the whole UI
     * are the ones that already work; what changes is WHO is behind
     * the counter — his stock is short, it is cheap, and he does not
     * care what your name is. Building a second screen for it would
     * have been two shops to keep in step forever.
     */
    this.blackMarket = !!opts.blackMarket;
    this.owner       = opts.owner || null;      // the name off the board
    this.type    = this.blackMarket ? 'outpost' : Utils.pick(STATION_TYPES);
    this.name    = this.blackMarket
      ? `${this.owner || 'Somebody'}'s hold`
      : this._genName();
    this._rng    = this._makeRng(seed);

    // Stock (limited quantities)
    this.stock = this.blackMarket ? this._generateBlackStock() : this._generateStock();
  }

  /**
   * EVERY PRICE THIS COUNTER QUOTES GOES THROUGH HERE.
   *
   * A port adds the karma surcharge; a pirate takes a cut off instead
   * — and never both, because the surcharge is what the honest docks
   * charge a man the pirate is pleased to see.
   */
  _priceFactor() {
    if (!this.blackMarket) return karmaPriceFactor();
    const off = (typeof Commander !== 'undefined' && Commander.pirateDiscount)
      ? Commander.pirateDiscount() : 0.30;
    return Math.max(0.2, 1 - off);
  }

  _makeRng(seed) {
    let s = seed + 1;
    return () => { s ^= s<<13; s ^= s>>17; s ^= s<<5; return (s>>>0)/0xFFFFFFFF; };
  }

  _rngInt(a,b) { return Math.floor(this._rng()*(b-a))+a; }

  _genName() {
    const prefixes = ['Alpha','Beta','Delta','Echo','Foxtrot','Gamma','Kappa','Nova','Sigma','Theta'];
    const suffixes = ['Station','Post','Depot','Hub','Outpost','Base','Beacon'];
    return `${Utils.pick(prefixes)}-${Utils.pick(suffixes)}`;
  }

  _generateStock() {
    const s  = this.sector;
    const r  = this._rng.bind(this);
    const ri = this._rngInt.bind(this);

    const stock = {
      // Hull repair
      hullRepair: ri(5, 15 + s * 3),   // hp available to buy

      // Fuel
      fuel: ri(1, 4 + s),

      /* He-3 ORE (update56). A port sells it because miners bring it in;
         the player buys it because it is worth money at home and,
         later, because the Gate eats it. Thin stock on purpose — a
         station that could fill your hold with it would make the
         mineral meaningless the day it gets a use. */
      he3: ri(0, 2 + Math.floor(s / 2)),

      // Missiles
      missiles: ri(0, 6 + s),

      /* RATIONS (update66). A port carries a couple of KINDS, not the
         whole menu — which is why the four are a packing decision and
         not just a shopping list. Which kinds is deterministic in the
         station's seed, so a port you came back for still has what you
         came back for. */
      rations: (() => {
        const KINDS = ['ration_pack', 'protein_paste', 'field_meal', 'green_ration'];
        const out = {};
        KINDS.forEach(k => { if (r() < 0.55) out[k] = ri(2, 8 + s); });
        // Never a port with nothing to eat at all.
        if (!Object.keys(out).length) out.ration_pack = ri(2, 6 + s);
        return out;
      })(),

      // Weapons (1–2 random)
      weapons: [],

      // Modules
      // `modules` used to be rolled here and shown nowhere — see the
      // note above MODULE_DEFS. `newModules` is the live one.


      // Crew recruits (0–2)
      crew: [],

      // Upgrades are ALWAYS available at stations
      reactorUpgrade: true,

      // Brand-new MODULES — random whether a given one is in stock.
      // SHIELDS are here because the starter hull ships without them:
      // getting a shield bay is the first big purchase of a run, so it
      // has to be findable (60% — often, not always).
      newModules: [
        ...(r() < 0.60 ? [{ type: 'shields',    cost: 90 + this.sector * 15, sold: false }] : []),
        ...(r() < 0.35 ? [{ type: 'medbay',     cost: 70 + this.sector * 10, sold: false }] : []),
        ...(r() < 0.5  ? [{ type: 'cloaking',   cost: 85 + this.sector * 10, sold: false }] : []),
        ...(r() < 0.5  ? [{ type: 'autorepair', cost: 75 + this.sector * 10, sold: false }] : []),
        /* THE BRIG. Started at 30% in update63 on the theory that it
           is a module you go looking for; raised to 60% in update64,
           the player's call, because a cell you never find means the
           "Take him prisoner" door never opens and the whole bounty
           half of the game is untestable. To revisit at balance
           time — this is a number for playing, not a final one. */
        ...(r() < 0.60 ? [{ type: 'carbonite',       cost: 80 + this.sector * 10, sold: false }] : []),
      ],
    };

    // Weapons
    const wCount = ri(1, 3);
    const wPool  = Object.entries(WEAPON_DEFS)
      .filter(([,d]) => d.cost > 0 && d.cost <= 50 + s*15);
    for (let i = 0; i < wCount && wPool.length; i++) {
      const idx = ri(0, wPool.length);
      const [key, def] = wPool.splice(idx, 1)[0];
      stock.weapons.push({ key, def, sold: false });
    }

    /* Crew — HOW MANY ARE EVEN INTERESTED (update61).
       A delta on the roll, never a second roll: a port that rolled
       nobody still has nobody, and a shunned commander finds two
       fewer berths filled than a saint would at the same port. */
    const interest = (typeof Commander !== 'undefined' && Commander.recruitInterest)
      ? Commander.recruitInterest() : 0;
    const cCount = Utils.clamp(ri(0, 3) + interest, 0, 3);
    for (let i = 0; i < cCount; i++) {
      const name  = Utils.pick(RECRUIT_NAMES);
      const skill = Utils.pick(Object.keys(SKILL_DEFS));
      stock.crew.push({
        name,
        skill,
        sold: false,
        member: new CrewMember({
          name,
          skills: { [skill]: { level: 1, xp: 0 } },
        }),
      });
    }

    return stock;
  }

  /**
   * WHAT A MAN OFF THE WANTED BOARD HAS IN HIS HOLD (update70).
   *
   * Short, and all of it the kind of thing a port either does not
   * carry or will not admit to carrying: guns, a module or two out of
   * somebody else's ship, sealed contraband and chips. No hull repair,
   * no recruits, no reactor work — he is not a dockyard, he is a man
   * with a hold full of other people's property.
   *
   * The prices are the same catalogue every port uses; what makes them
   * cheap is `_priceFactor`, in one place, so "how much under the port
   * price" is a single number and not a second price list.
   */
  _generateBlackStock() {
    const s  = this.sector;
    const r  = this._rng.bind(this);
    const ri = this._rngInt.bind(this);
    const deep = (typeof Commander !== 'undefined' && Commander.KARMA_SHUNNED != null &&
                  Commander.karmaNow)
      ? Commander.karmaNow() <= Commander.KARMA_SHUNNED : false;

    const stock = {
      hullRepair: 0,
      // He will spare a cell or two, at his price.
      fuel: ri(0, 3 + (deep ? 2 : 0)),
      he3: 0,
      missiles: ri(0, 4 + s),
      rations: {},
      weapons: [],
      crew: [],
      reactorUpgrade: false,
      newModules: [],
      /* CRATES HE SELLS OVER THE COUNTER. Ports have no such list —
         this is the one thing the black market adds to the shop
         rather than reprices. */
      goods: [],
    };

    // ── guns: more than a port, and the better ones show up deeper in ──
    const wCount = ri(2, 4 + (deep ? 2 : 0));
    const wPool  = Object.entries(WEAPON_DEFS)
      .filter(([, d]) => d.cost > 0 && d.cost <= 70 + s * 20);
    for (let i = 0; i < wCount && wPool.length; i++) {
      const [key, def] = wPool.splice(ri(0, wPool.length), 1)[0];
      stock.weapons.push({ key, def, sold: false });
    }

    // ── a module or two, out of a hull that is not using it any more ──
    const MODS = ['shields', 'cloaking', 'carbonite', 'medbay', 'autorepair'];
    Utils.shuffle(MODS);
    MODS.slice(0, ri(1, deep ? 4 : 3)).forEach(type => {
      stock.newModules.push({ type, cost: 70 + this.sector * 12, sold: false });
    });

    // ── the goods ──
    const push = (key, n = 1) => {
      for (let i = 0; i < n; i++) {
        const def = (typeof CARGO_ITEMS !== 'undefined') ? CARGO_ITEMS[key] : null;
        if (!def) return;
        stock.goods.push({ key, cost: Math.round((def.value ?? 20) * 1.1), sold: false });
      }
    };
    push('contraband', ri(1, deep ? 4 : 3));
    if (r() < (deep ? 0.9 : 0.6)) push('alien_relic');
    /* CHIPS. His are the ones nobody can account for — the same items
       the CPU board mounts, bought here instead of found. */
    const chipKeys = (typeof CARGO_ITEMS !== 'undefined')
      ? Object.keys(CARGO_ITEMS).filter(k => CARGO_ITEMS[k].kind === 'chip' &&
                                             CARGO_ITEMS[k].chipLevel <= (deep ? 3 : 2))
      : [];
    for (let i = 0, n = ri(1, deep ? 4 : 3); i < n && chipKeys.length; i++) {
      push(chipKeys[ri(0, chipKeys.length)]);
    }
    return stock;
  }

  /** What this counter wants for a gun off the rack, and for a module
   *  out of the back. A PORT quotes the catalogue price it always has
   *  — karma has never touched guns and quietly adding it here would
   *  re-balance every station in the game. A pirate takes his cut off
   *  the same figure, which is the whole point of dealing with him. */
  _goodsFactor() { return this.blackMarket ? this._priceFactor() : 1; }
  weaponCost(item) { return Math.round((item?.def?.cost ?? 0) * this._goodsFactor()); }
  moduleCost(item) { return Math.round((item?.cost    ?? 0) * this._goodsFactor()); }
  goodsCost(item)  { return Math.round((item?.cost    ?? 0) * this._goodsFactor()); }

  /**
   * Buy a crate over the counter. Same shape as `buyRations`: probe a
   * COPY of the hold first, so nothing is charged for that cannot be
   * carried, and the crate is placed by the grid rather than counted.
   */
  buyGoods(idx, run, ship) {
    const closed = this.refusal();
    if (closed) return { ok: false, message: closed };
    const item = (this.stock.goods ?? [])[idx];
    if (!item || item.sold) return { ok: false, message: 'Item not available.' };
    const hold = ship?.cargo;
    if (!hold) return { ok: false, message: 'Nothing to load it into.' };
    const cost = this.goodsCost(item);
    if (!run || run.scrap < cost) return { ok: false, message: 'Insufficient CC.' };
    const probe = CargoGrid.deserialise(hold.serialise());
    if (!probe.add(item.key)) return { ok: false, message: 'No room in the hold.' };
    const placed = hold.add(item.key);
    if (!placed) return { ok: false, message: 'No room in the hold.' };
    item.sold = true;
    Save.updateRun({ scrap: run.scrap - cost });
    Audio.sfx.scrapCollect?.();
    return { ok: true, cost, message: `Loaded ${placed.label}.` };
  }

  // ── Buy actions ──────────────────────────────────────────

  /**
   * Buy hull repair.
   * @param {number}  hp     - amount of HP to repair
   * @param {Ship}    ship
   * @returns {{ ok, cost, message }}
   */
  buyHullRepair(hp, ship) {
    const closed = this.refusal();
    if (closed) return { ok: false, message: closed };
    const available = Math.min(hp, this.stock.hullRepair);
    if (available <= 0) return { ok: false, message: 'No hull repair available.' };

    const cost = this.hullRepairCost(available);
    const run  = Save.getRun();
    if (!run || run.scrap < cost) return { ok: false, message: 'Insufficient CC.' };

    ship.hull = Math.min(ship.hullMax, ship.hull + available);
    this.stock.hullRepair -= available;
    Save.updateRun({ scrap: run.scrap - cost });
    Audio.sfx.repair();
    return { ok: true, cost, message: `Hull repaired +${available} HP.` };
  }

  /**
   * He2 is physical now (update39): it goes into CELLS in the hold, and
   * the hold can be full. Same shape as buyMissiles, including the
   * dry-run probe so the player is only ever charged for what fits.
   * `ship` is optional so old call sites still work.
   */
  buyFuel(amount, run, ship = null) {
    const closed = this.refusal();
    if (closed) return { ok: false, message: closed };
    let avail = Math.min(amount, this.stock.fuel);
    if (avail <= 0) return { ok: false, message: 'No He2 available.' };

    const hold = ship?.cargo;
    // Medium tanks first, then bottles for the gaps, then drums.
    const KEYS = ['he2_med', 'he2_small', 'he2_large'];
    const pour = (grid, n) => {
      let left = n;
      for (const k of KEYS) { if (left <= 0) break; left = grid.addStack(k, left); }
      return left;
    };
    if (hold) {
      const probe = CargoGrid.deserialise(hold.serialise());
      avail -= pour(probe, avail);
      if (avail <= 0) return { ok: false, message: 'No room in the hold for He2.' };
    }

    const cost = this.fuelCost(avail);
    if (run.scrap < cost) return { ok: false, message: 'Insufficient CC.' };

    this.stock.fuel -= avail;
    if (hold) {
      pour(hold, avail);
      Save.updateRun({ scrap: run.scrap - cost, fuel: hold.countOf('fuel') });
    } else {
      Save.updateRun({ scrap: run.scrap - cost, fuel: run.fuel + avail });
    }
    Audio.sfx.scrapCollect();
    return { ok: true, cost, message: `Loaded ${avail} He2 into the hold.` };
  }

  /**
   * He-3 ORE ACROSS THE COUNTER (update56).
   *
   * Deliberately the same shape as `buyFuel` — probe a COPY of the hold
   * first, so a purchase that will not fit is refused before any money
   * moves, and the player is never charged for ore left on the dock.
   *
   * What it is NOT: fuel. It never touches `run.fuel`, and the hold
   * counts it as trade goods, because the ship does not burn it.
   */
  buyHe3(amount, run, ship = null) {
    const closed = this.refusal();
    if (closed) return { ok: false, message: closed };
    let avail = Math.min(amount, this.stock.he3 ?? 0);
    if (avail <= 0) return { ok: false, message: 'No He-3 at this port.' };

    const hold = ship?.cargo;
    if (!hold) return { ok: false, message: 'Nothing to load it into.' };

    const probe = CargoGrid.deserialise(hold.serialise());
    avail -= probe.addStack('he3_ore', avail);
    if (avail <= 0) return { ok: false, message: 'No room in the hold for ore.' };

    const cost = this.he3Cost(avail);
    if (run.scrap < cost) return { ok: false, message: 'Insufficient CC.' };

    this.stock.he3 -= avail;
    hold.addStack('he3_ore', avail);
    Save.updateRun({ scrap: run.scrap - cost });
    Audio.sfx.scrapCollect();
    return { ok: true, cost, message: `Loaded ${avail} He-3 into the hold.` };
  }

  /** What a port charges for a unit of ore. Dearer further out, the way
   *  everything else is — it is mined here, not made here. */
  he3Cost(amt = 1) {
    const base = (typeof CARGO_ITEMS !== 'undefined'
                  && CARGO_ITEMS.he3_ore?.unitValue) || 30;
    return Math.round(amt * base * (1.1 + this.sector * 0.05) * this._priceFactor());
  }

  /**
   * Missiles are physical now: they go into racks in the hold, and the
   * hold can be full. `ship` is optional so old call sites still work.
   */
  buyMissiles(amount, run, ship = null) {
    const closed = this.refusal();
    if (closed) return { ok: false, message: closed };
    let avail = Math.min(amount, this.stock.missiles);
    if (avail <= 0) return { ok: false, message: 'No missiles available.' };

    const hold = ship?.cargo;
    if (hold) {
      // Only charge for what actually fits — dry-run the load first.
      const probe = CargoGrid.deserialise(hold.serialise());
      const spill = probe.addStack('missile_rack', avail);
      avail -= spill;
      if (avail <= 0) return { ok: false, message: 'No room in the hold for missiles.' };
    }

    const cost = this.missileCost(avail);
    if (run.scrap < cost) return { ok: false, message: 'Insufficient CC.' };

    this.stock.missiles -= avail;
    if (hold) {
      hold.addStack('missile_rack', avail);
      Save.updateRun({ scrap: run.scrap - cost, missiles: hold.countOf('missiles') });
    } else {
      Save.updateRun({ scrap: run.scrap - cost, missiles: run.missiles + avail });
    }
    Audio.sfx.scrapCollect();
    return { ok: true, cost, message: `Loaded ${avail} missiles into the racks.` };
  }

  buyWeapon(idx, ship, run) {
    const closed = this.refusal();
    if (closed) return { ok: false, message: closed };
    const item = this.stock.weapons[idx];
    if (!item || item.sold) return { ok: false, message: 'Item not available.' };

    const cost = this.weaponCost(item);
    if (run.scrap < cost) return { ok: false, message: 'Insufficient CC.' };

    /* THE GOODS BEFORE THE MONEY (update75). This charged the player
       first and then found somewhere to put the gun — and "somewhere"
       was the weightless rack, which always had room, so the order
       never mattered. It matters now: the hold can be full, and a sale
       that cannot be delivered must not happen at all. */

    // ONE gun per weapon MODULE: install into the first free module,
    // otherwise it goes into a crate in the hold.
    let slot = -1;
    for (let i = 0; i < ship.weaponRooms.length; i++) {
      if (!ship.weapons[i]) { slot = i; break; }
    }
    let where = null;
    if (slot !== -1 && ship.installWeapon(item.key, slot)) {
      where = `installed in module ${slot + 1}.`;
    } else if (ship.boxWeapon(item.key)) {
      where = 'boxed and stowed in the hold — all modules are occupied.';
    } else {
      const probe = (typeof CargoItem !== 'undefined' && typeof cargoCrateForWeapon === 'function')
        ? new CargoItem(cargoCrateForWeapon(item.key)) : null;
      return { ok: false,
        message: probe
          ? `Every module is occupied and the hold has no ${probe.w}x${probe.h} space `
            + 'for the crate — make room first. Nothing was bought.'
          : 'Nowhere to put that gun — nothing was bought.' };
    }

    item.sold = true;
    Save.updateRun({ scrap: run.scrap - cost });
    Audio.sfx.powerUp();
    return { ok: true, cost, message: `${item.def.label} ${where}` };
  }

  /** Move a mounted gun into the cargo hold — free, station only. */
  /**
   * A gun taken off the hull has to go SOMEWHERE physical — into a crate
   * in the hold. If there is no room for the crate, the gun stays bolted
   * on: no invisible rack to park it on any more.
   */
  uninstallWeapon(ship, slot) {
    const peek = ship.weapons[slot];
    if (!peek) return { ok: false, message: 'Module is empty.' };

    /* THE ROOM CHECK MOVED INTO `Ship.uninstallWeapon` (update75).
       It used to live here as a hand-rolled scan of every cell, next to
       a second copy of it in base.js — and then this function had to
       UNDO what `Ship.uninstallWeapon` had just done, because that one
       pushed the gun onto the old rack. Three lines of reconciliation
       between two registers, all of it gone with the second register. */
    const key = ship.uninstallWeapon(slot);
    if (!key) {
      const probe = (typeof CargoItem !== 'undefined' && typeof cargoCrateForWeapon === 'function')
        ? new CargoItem(cargoCrateForWeapon(peek.defKey)) : null;
      return { ok: false,
        message: probe
          ? `No room in the hold for a ${probe.w}x${probe.h} crate — make space first. `
            + 'The gun stays on the mount.'
          : 'No room in the hold — the gun stays on the mount.' };
    }
    Audio.sfx.uiClick();
    return { ok: true,
      message: `${WEAPON_DEFS[key]?.label ?? key} boxed and stowed in the hold.` };
  }

  /**
   * Mount a BOXED gun from the hold into a specific empty module. The
   * crate is the thing that moves — it leaves the grid, and the space
   * it took comes back (update75; this used to take an index into the
   * old weightless rack).
   */
  installFromCargo(ship, crate, slot) {
    const key = crate?.meta;
    if (!crate || crate.def?.kind !== 'weapon' || !key) {
      return { ok: false, message: 'That is not a gun crate.' };
    }
    if (!ship.cargo?.items.includes(crate)) {
      return { ok: false, message: 'That crate is not in this hold.' };
    }
    if (ship.weapons[slot]) return { ok: false, message: `Module ${slot + 1} is occupied.` };
    if (!ship.installWeapon(key, slot)) return { ok: false, message: 'Install failed.' };
    ship.cargo.remove(crate);
    Audio.sfx.powerUp();
    return { ok: true,
      message: `${WEAPON_DEFS[key]?.label ?? key} installed in module ${slot + 1} `
             + '— the crate is out of the hold.' };
  }

  /** Sell a BOXED gun out of the hold for half its list price. */
  sellCargoWeapon(ship, run, crate) {
    const key = crate?.meta;
    if (!crate || crate.def?.kind !== 'weapon' || !key) {
      return { ok: false, message: 'That is not a gun crate.' };
    }
    if (!ship.cargo?.items.includes(crate)) {
      return { ok: false, message: 'That crate is not in this hold.' };
    }
    const price = Math.floor((WEAPON_DEFS[key]?.cost ?? 20) * 0.5);
    ship.cargo.remove(crate);
    Save.updateRun({ scrap: run.scrap + price });
    Audio.sfx.scrapPickup?.();
    return { ok: true, message: `Sold for ${price} CC — the hold has its space back.` };
  }

  /** Upgrade any ship system by INDEX — always available, price grows
   *  with current level. Shields upgrade a whole MODULE level at a
   *  time (+2 pips = +1 layer), capped at level 3. */
  upgradeSystemAt(ship, run, sysIndex) {
    const sys = ship.systems[sysIndex];
    if (!sys || sys.type === 'reactor')
      return { ok: false, message: 'Use the Reactor tab for that.' };
    const step = sys.type === 'shields' ? 2 : 1;
    const max  = sys.def?.maxLevel ?? 8;
    if (sys.level + step > max)
      return { ok: false, message: `${sys.label} already at max level.` };
    const cost = this.systemUpgradeCost(sys);
    if (run.scrap < cost) return { ok: false, message: 'Insufficient CC.' };
    sys.level += step;
    Save.updateRun({ scrap: run.scrap - cost });
    Audio.sfx.levelUp();
    const shown = sys.type === 'shields' ? `${sys.level / 2}/3` : `${sys.level}`;
    return { ok: true, cost, message: `${sys.label} upgraded to level ${shown}.` };
  }

  /**
   * Module upgrades climb exponentially too — the same reasoning as the
   * reactor. `step` for shields is a whole 2-pip layer, so its curve is
   * driven by LAYER number, not pip number.
   */
  systemUpgradeCost(sys) {
    if (sys.type === 'shields') {
      const layer = sys.level / 2;                 // layers already fitted
      return Math.round((40 + layer * 45) * Math.pow(UPGRADE_GROWTH, layer))
           + this.sector * 5;
    }
    const lvl = sys.level;
    return Math.round((18 + lvl * 10) * Math.pow(UPGRADE_GROWTH, Math.max(0, lvl - 1)))
         + this.sector * 5;
  }

  /** Buy a brand-new module from stock — converts an empty room. */
  buyNewModule(idx, ship, run) {
    const closed = this.refusal();
    if (closed) return { ok: false, message: closed };
    const item = this.stock.newModules[idx];
    if (!item || item.sold) return { ok: false, message: 'Item not available.' };
    if (ship.getSystem(item.type))
      return { ok: false, message: 'Already installed on this hull.' };
    if (!ship.rooms.some(r => r.type === 'empty'))
      return { ok: false, message: 'No empty room to convert.' };
    const cost = this.moduleCost(item);
    if (run.scrap < cost) return { ok: false, message: 'Insufficient CC.' };
    if (!ship.addModule(item.type)) return { ok: false, message: 'Install failed.' };
    item.sold = true;
    Save.updateRun({ scrap: run.scrap - cost });
    Audio.sfx.levelUp();
    return { ok: true, cost,
      message: `${SYSTEM_DEFS[item.type].label} installed — give it power!` };
  }

  /** Orbital med-clinic: heals everyone to full, gets the wounded back
   *  on their feet and cures the CORPSE PLAGUE. 12 CC a patient.
   *  It does NOT touch the void-spider virus — that needs a research
   *  post's quarantine ward. (The dead stay dead — eject the bodies.) */
  healCrew(ship, run) {
    /* `c.isPlayer` keeps enemy boarders off the bill (update42).
       THE CAT IS A PATIENT (update54): the old filter was `!c.isBeast`,
       which was aimed at a stowaway rat but caught the ship's cat with
       it — and the cat is ours, walks our decks and takes our wounds.
       `isVermin || isSpider` is the thing that was actually meant, so
       that is what is written now. A vet costs the same as a doctor. */
    const patients = ship.crew.filter(c =>
      c.isPlayer && !c.isVermin && !c.isSpider &&
      !c.dead && (c.hp < c.maxHp || c.state === 'injured' || c.infected));
    if (!patients.length) return { ok: false, message: 'Nobody needs treatment.' };
    const cost = patients.length * 12;
    if (run.scrap < cost) return { ok: false, message: `Need ${cost} CC for ${patients.length} patient(s).` };
    patients.forEach(c => {
      c.hp = c.maxHp;
      c.state = 'ok';
      c._bleedT = 0;
      c.infected = false;
    });
    Save.updateRun({ scrap: run.scrap - cost });
    Audio.sfx.levelUp();
    return { ok: true, cost,
      message: `${patients.length} crew treated — healed and plague-free.` };
  }

  /**
   * QUARANTINE WARD — research posts only.
   *
   * The ordinary clinic cannot touch the void-spider virus; letting it
   * would make the whole mechanic a 12 CC inconvenience. A `science`
   * port can, and charges for it.
   */
  quarantineCost(ship) {
    const n = ship.crew.filter(c => !c.dead && c.virus).length;
    return n * 45;
  }

  cureVirus(ship, run) {
    if (this.type !== 'science') {
      return { ok: false,
        message: 'No quarantine ward here — only a research post can treat it.' };
    }
    const patients = ship.crew.filter(c => !c.dead && c.virus);
    if (!patients.length) return { ok: false, message: 'Nobody is carrying it.' };
    const cost = this.quarantineCost(ship);
    if (run.scrap < cost) {
      return { ok: false, message: `Need ${cost} CC to treat ${patients.length}.` };
    }
    patients.forEach(c => c.cureVirus());
    Save.updateRun({ scrap: run.scrap - cost });
    Audio.sfx.levelUp();
    return { ok: true, cost,
      message: `${patients.length} crew scrubbed clean — the virus is out of them.` };
  }

  /** Room-targeted variants — the player clicks the destination room
   *  on the station's ship diagram. */
  buyNewModuleAt(idx, ship, run, roomId) {
    const closed = this.refusal();
    if (closed) return { ok: false, message: closed };
    const item = this.stock.newModules[idx];
    if (!item || item.sold) return { ok: false, message: 'Item not available.' };
    if (ship.getSystem(item.type))
      return { ok: false, message: 'Already installed on this hull.' };
    const cost = this.moduleCost(item);
    if (run.scrap < cost) return { ok: false, message: 'Insufficient CC.' };
    if (!ship.addModuleAt(item.type, roomId))
      return { ok: false, message: 'That compartment cannot take it.' };
    item.sold = true;
    Save.updateRun({ scrap: run.scrap - cost });
    Audio.sfx.levelUp();
    return { ok: true, cost,
      message: `${SYSTEM_DEFS[item.type].label} installed — give it power!` };
  }

  buyWeaponModuleAt(ship, run, roomId) {
    const closed = this.refusal();
    if (closed) return { ok: false, message: closed };
    if (ship.weaponRooms.length >= 3)
      return { ok: false, message: 'Hull supports at most 3 weapon modules.' };
    const cost = this.weaponModuleCost(ship);
    if (run.scrap < cost) return { ok: false, message: 'Insufficient CC.' };
    if (!ship.addModuleAt('weapons', roomId))
      return { ok: false, message: 'That compartment cannot take it.' };
    Save.updateRun({ scrap: run.scrap - cost });
    Audio.sfx.levelUp();
    return { ok: true, cost,
      message: `Weapon module ${ship.weaponRooms.length} installed — fit a gun into it.` };
  }

  /** Convert an empty room into a NEW weapon module (2nd: 60, 3rd: 120). */
  weaponModuleCost(ship) { return 60 * ship.weaponRooms.length; }

  buyWeaponModule(ship, run) {
    const closed = this.refusal();
    if (closed) return { ok: false, message: closed };
    if (ship.weaponRooms.length >= 3)
      return { ok: false, message: 'Hull supports at most 3 weapon modules.' };
    if (!ship.rooms.some(r => r.type === 'empty'))
      return { ok: false, message: 'No empty room to convert.' };
    const cost = this.weaponModuleCost(ship);
    if (run.scrap < cost) return { ok: false, message: 'Insufficient CC.' };
    if (!ship.addWeaponModule()) return { ok: false, message: 'Conversion failed.' };
    Save.updateRun({ scrap: run.scrap - cost });
    Audio.sfx.levelUp();
    return { ok: true, cost,
      message: `Weapon module ${ship.weaponRooms.length} installed — fit a gun into it.` };
  }

  buyCrew(idx, ship, run) {
    const closed = this.refusal();
    if (closed) return { ok: false, message: closed };
    const item = this.stock.crew[idx];
    if (!item || item.sold) return { ok: false, message: 'No crew available.' };
    if (ship.crew.length >= 8) return { ok: false, message: 'Crew quarters full.' };

    const cost = this.crewCost();
    if (run.scrap < cost) return { ok: false, message: 'Insufficient CC.' };

    item.sold = true;
    ship.addCrew(item.member);
    Save.updateRun({ scrap: run.scrap - cost });
    Audio.sfx.levelUp();
    return { ok: true, cost, message: `${item.name} joined the crew.` };
  }

  buyReactorUpgrade(ship, run) {
    const closed = this.refusal();
    if (closed) return { ok: false, message: closed };
    if (!this.stock.reactorUpgrade) return { ok: false, message: 'No reactor upgrade available.' };

    const cost = this.reactorCost(ship);
    // Max BEFORE money: a maxed reactor with a light purse used to be
    // reported as "Insufficient CC.", which is the wrong reason and sends
    // the player off to earn CC they can never spend.
    if (ship.reactor.level >= ship.reactor.maxLevel) {
      return { ok: false, message: 'Reactor at maximum.' };
    }
    if (run.scrap < cost) return { ok: false, message: `Insufficient CC — needs ${cost}.` };
    if (!ship.reactor.upgrade()) return { ok: false, message: 'Reactor at maximum.' };
    // Upgrades are always available — no one-per-station limit
    Save.updateRun({ scrap: run.scrap - cost });
    Audio.sfx.powerUp();
    return { ok: true, cost, message: `Reactor upgraded to level ${ship.reactor.level}.` };
  }

  // ── Price helpers ────────────────────────────────────────

  hullRepairCost(hp = 1)  { return Math.round(hp  * REPAIR_PRICES.hull * this._priceFactor()); }
  fuelCost(amt = 1)       { return Math.round(amt * FUEL_PRICE          * this._priceFactor()); }
  missileCost(amt = 1)    { return Math.round(amt * MISSILE_PRICE       * this._priceFactor()); }
  reactorCost(ship)       { return Math.round(REACTOR_PRICE(ship.reactor.level) * this._priceFactor()); }

  /** What a port wants for one meal of a given kind. The item's own
   *  value is the base — one register — and karma is applied here the
   *  same way it is applied to everything else across this counter. */
  rationCost(key, amt = 1) {
    const base = (typeof CARGO_ITEMS !== 'undefined' && CARGO_ITEMS[key]?.unitValue) || 8;
    return Math.round(amt * base * this._priceFactor());
  }

  /**
   * Buy meals. Deliberately the same shape as `buyFuel` and
   * `buyMissiles` — probe a COPY of the hold first, so the player is
   * only ever charged for what actually fits.
   */
  buyRations(key, amount, run, ship = null) {
    const closed = this.refusal();
    if (closed) return { ok: false, message: closed };
    const def = (typeof CARGO_ITEMS !== 'undefined') ? CARGO_ITEMS[key] : null;
    if (!def || def.tag !== 'food') return { ok: false, message: 'Not food.' };
    let avail = Math.min(amount, this.stock.rations?.[key] ?? 0);
    if (avail <= 0) return { ok: false, message: 'None of that left here.' };

    const hold = ship?.cargo;
    if (!hold) return { ok: false, message: 'Nothing to load it into.' };
    const probe = CargoGrid.deserialise(hold.serialise());
    avail -= probe.addStack(key, avail);
    if (avail <= 0) return { ok: false, message: 'No room in the hold.' };

    const cost = this.rationCost(key, avail);
    if (run.scrap < cost) return { ok: false, message: 'Insufficient CC.' };

    this.stock.rations[key] -= avail;
    hold.addStack(key, avail);
    Save.updateRun({ scrap: run.scrap - cost });
    Audio.sfx.scrapCollect();
    return { ok: true, cost, message: `Loaded ${avail} × ${def.label}.` };
  }

  /** A hand's signing fee. Reads the BARRACKS side of karma, not the
   *  shop side — people are not stock, and a good name is worth a
   *  discount here where it buys nothing at the fuel pump. */
  crewCost() {
    const f = (typeof Commander !== 'undefined' && Commander.recruitFactor)
      ? Commander.recruitFactor() : 1;
    return Math.round(CREW_PRICE * f);
  }

  /**
   * WILL THIS PORT DEAL WITH HIM AT ALL (update61)?
   *
   * Returns the reason to put on screen, or null when the dock is
   * open. The decision itself lives in commander.js and is
   * deterministic in this station's own seed, so a port that turned
   * you away is still turning you away when you come back — and only
   * a small share of them ever do, or a low-karma run would simply
   * strand with no fuel to buy anywhere.
   */
  refusal() {
    /* HE DOES NOT CARE WHAT YOUR NAME IS (update70) — that is what he
       is FOR. The refusal below reads karma, and a black market that
       turned away the only commanders it exists to serve would be a
       door with nothing behind it. */
    if (this.blackMarket) return null;
    if (typeof Commander === 'undefined' || !Commander.portRefuses) return null;
    if (!Commander.portRefuses(this.seed)) return null;
    return `${this.name} will not trade with you. `
         + 'Word of what you did got here first.';
  }
}
