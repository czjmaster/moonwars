/* ============================================================
   MOON WARS — ship.js
   Ship class: layout, rooms, systems, hull, crew roster,
   weapons rack, elevator integration, damage resolution.
   Both player and enemy ships use this class.
   ============================================================ */

'use strict';

// ── Door ──────────────────────────────────────────────────

/** Seconds for a door panel to travel from shut to fully open. */
const DOOR_CYCLE = 1.0;

class Door {
  /**
   * Door between two adjacent rooms — or an AIRLOCK to space (roomB = null).
   * Doors are BINARY: 'open' or 'closed'. Green = open, red = closed.
   *        'closed' (player-locked shut).
   * Open airlocks vent the room's oxygen to space (FTL fire-fighting tactic).
   */
  constructor(roomA, roomB, x, y, isAirlock = false) {
    this.roomA  = roomA;
    this.roomB  = roomB;        // null = space
    this.x      = x;
    this.y      = y;
    this.isAirlock = isAirlock;
    // Doors are strictly BINARY: open or closed. Interior doors start
    // open (air flows), airlocks start closed. Click toggles.
    this.mode   = isAirlock ? 'closed' : 'open';
    // A door is no longer instant. `openness` runs 0..1 over DOOR_CYCLE
    // seconds and `open` means FULLY open — nobody squeezes through a
    // door that is still moving.
    this.openness = isAirlock ? 0 : 1;
    this.open   = !isAirlock;
    // Auto-passage: an INTERIOR door a crew member walks up to slides
    // open briefly even if the player locked it 'closed', then closes
    // again. Airlocks NEVER auto-open (they must be breached).
    this._tempT = 0;   // seconds left holding open for a passer-by
    this.breached = false;   // airlock smashed open by boarders
  }

  /** Player click: open ↔ closed. The panel then takes a second to cycle. */
  toggle() {
    this.mode = this.mode === 'open' ? 'closed' : 'open';
    this._tempT = 0;
    Audio.sfx.uiClick();
    Audio.sfx.doorMove?.();
  }

  /** Where the panel should end up, 1 = open. */
  get _target() {
    if (this.breached) return 1;
    if (this.isAirlock) return this.mode === 'open' ? 1 : 0;
    return (this._tempT > 0 || this.mode === 'open') ? 1 : 0;
  }

  /** A crew member is standing at this door wanting through.
   *  INTERIOR doors slide open (with a short delay so it reads as a
   *  door cycling). Returns true once it's actually open to pass. */
  requestPassage(dt) {
    if (this.isAirlock) return this.open;   // airlocks don't auto-open
    // Ask for it, then WAIT. The door needs its full second; returning
    // true early let crew walk through a half-open panel.
    this._tempT = Math.max(this._tempT, 0.6);
    return this.open;
  }

  update(dt, crew) {
    if (this._tempT > 0) this._tempT -= dt;

    // Slide toward the target at a fixed rate — one full second end to
    // end, whichever way it is going. A breached airlock is simply gone,
    // so it snaps.
    const target = this._target;
    if (this.breached) {
      this.openness = 1;
    } else if (this.openness !== target) {
      const step = dt / DOOR_CYCLE;
      this.openness = target > this.openness
        ? Math.min(target, this.openness + step)
        : Math.max(target, this.openness - step);
    }
    // FULLY open, not "on its way".
    this.open = this.openness >= 1;

    if (!this.isAirlock) return;

    // Venting particles for open airlocks (throttled)
    if (this.open) {
      this._ventT = (this._ventT ?? 0) + dt;
      if (this._ventT > 0.15) {
        this._ventT = 0;
        Particles.emit({
          x: this.x, y: this.y + Utils.randFloat(-12, 12),
          vx: (this.x < 640 ? -1 : 1) * Utils.randFloat(40, 90),
          vy: Utils.randFloat(-15, 15), ay: 0,
          color: '#aaccee', size: 2, sizeEnd: 0,
          life: 0.4, alpha: 0.7, alphaEnd: 0,
        });
      }
    }
  }

  draw(ctx) {
    const w = 6, h = 34;

    if (this.isAirlock) {
      // Airlock — hull hatch. Red glow when venting.
      if (this.open) {
        ctx.fillStyle = 'rgba(255,60,60,0.3)';
        ctx.fillRect(this.x - w/2 - 3, this.y - h/2 - 3, w + 6, h + 6);
        ctx.fillStyle = '#ff4455';
        ctx.fillRect(this.x - w/2, this.y - h/2, w, 6);
        ctx.fillRect(this.x - w/2, this.y + h/2 - 6, w, 6);
        // (venting particles emitted in update, not draw)
      } else {
        ctx.fillStyle = '#3a2a1a';
        ctx.fillRect(this.x - w/2, this.y - h/2, w, h);
        ctx.strokeStyle = '#ff7c20';
        ctx.lineWidth = 1;
        ctx.strokeRect(this.x - w/2, this.y - h/2, w, h);
      }
      return;
    }

    // Interior door — TWO PANELS that actually slide apart, so a door
    // mid-cycle reads as mid-cycle. Green fully open, red shut, amber
    // while it is moving (and crew are waiting on it).
    const o    = Utils.clamp(this.openness ?? (this.open ? 1 : 0), 0, 1);
    const half = h / 2;
    const panel = half * (1 - o);          // how much each leaf still covers
    const moving = o > 0 && o < 1;
    const col  = o >= 1 ? '#1aff8c' : moving ? '#ffb020' : '#ff5566';

    if (panel > 0.5) {
      ctx.fillStyle = o >= 1 ? '#2a5a3a' : moving ? '#5a4a1a' : '#5a2a2a';
      ctx.fillRect(this.x - w / 2, this.y - half, w, panel);
      ctx.fillRect(this.x - w / 2, this.y + half - panel, w, panel);
    }
    // Frame: doubled and offset when fully open, exactly as before.
    ctx.strokeStyle = col;
    ctx.lineWidth = 1;
    if (o >= 1) {
      ctx.fillStyle = 'rgba(26,255,140,0.25)';
      ctx.fillRect(this.x - w / 2, this.y - half, w, 6);
      ctx.fillRect(this.x - w / 2, this.y + half - 6, w, 6);
      ctx.strokeRect(this.x - w / 2 - 2, this.y - half - 2, w + 4, h + 4);
    } else {
      ctx.strokeRect(this.x - w / 2, this.y - half, w, h);
    }
  }
}

// ── Room ──────────────────────────────────────────────────

class Room {
  constructor(cfg) {
    this.id      = cfg.id;
    this.type    = cfg.type ?? 'empty';   // system type or 'empty'
    this.x       = cfg.x;
    this.y       = cfg.y;
    this.w       = cfg.w ?? 96;
    this.h       = cfg.h ?? 80;
    this.floor   = cfg.floor ?? 0;        // which floor (0=bottom)
    this.cx      = this.x + this.w / 2;
    this.cy      = this.y + this.h / 2;
    this.isVacuum = false;

    // Adjacent room ids (set after all rooms created)
    this.adjacent = cfg.adjacent ?? [];

    // Linked system instance (set by Ship)
    this.system  = null;
  }

  contains(wx, wy) {
    return Utils.pointInRect(wx, wy, this.x, this.y, this.w, this.h);
  }

  /** Repair the system in this room */
  repair(amount, crew) {
    if (this.system) this.system.repair(amount, crew);
  }
}

// ── Ship layouts ──────────────────────────────────────────

const SHIP_LAYOUTS = {

  /** FREE STARTER HULL — the same class of boat the ordinary raiders
   *  fly, refitted for you. Two decks, no medbay (field aid only),
   *  smaller reactor. Geometry mirrors enemy_frigate so the shaft
   *  never crosses a room: columns 20|100, 128|208, 208|288, shaft 114. */
  scout: {
    label: 'Tugboat "Halcyon"',
    spriteKey: 'ship_player',
    hullMax: 22,
    floors: 2,
    rooms: [
      { id:'r_engines',  type:'engines',  x: 20, y:170, w:80, h:72, floor:0, adjacent:['r_weapons'] },
      { id:'r_weapons',  type:'weapons',  x:128, y:170, w:80, h:72, floor:0, adjacent:['r_engines','r_hold'] },
      // NO shields on the starter hull — this bay is EMPTY, and fitting
      // it (shields, cloak, medbay…) at a station is the first real
      // decision a new captain makes.
      { id:'r_hold',     type:'empty',    x:208, y:170, w:80, h:72, floor:0, adjacent:['r_weapons'] },
      { id:'r_piloting', type:'piloting', x: 20, y: 90, w:80, h:72, floor:1, adjacent:['r_oxygen'] },
      { id:'r_oxygen',   type:'oxygen',   x:128, y: 90, w:80, h:72, floor:1, adjacent:['r_piloting','r_reactor'] },
      { id:'r_reactor',  type:'reactor',  x:208, y: 90, w:80, h:72, floor:1, adjacent:['r_oxygen'] },
    ],
    elevators: [
      { id:'ev0', x: 114, floors:[217, 137] },
    ],
    startSystems: ['engines','weapons','piloting','oxygen','reactor'],
    systemLevels: { weapons: 2, engines: 2 },
    startWeapons: ['laser_basic'],
    reactorLevel: 6,
    reactorMax: 12,
    weaponX: 310,
    weaponSlots: 1,
    // Grid hold — a tug has barely room for the crew, let alone salvage.
    cargoCols: 5, cargoRows: 3,
  },

  /** Bought hull — the Halcyon's bigger sister: same simple two-deck
   *  design, but EIGHT bays instead of six, so there is real room to
   *  grow (three of them start empty). Grid: 20|100 · shaft 114 ·
   *  128|208 · 208|288 · 288|368. */
  hauler: {
    label: 'Freighter "Mule"',
    spriteKey: 'ship_player',
    hullMax: 26,
    floors: 2,
    rooms: [
      { id:'r_engines',  type:'engines',  x: 20, y:170, w:80, h:72, floor:0, adjacent:['r_weapons'] },
      { id:'r_weapons',  type:'weapons',  x:128, y:170, w:80, h:72, floor:0, adjacent:['r_engines','r_hold1'] },
      { id:'r_hold1',    type:'empty',    x:208, y:170, w:80, h:72, floor:0, adjacent:['r_weapons','r_hold2'] },
      { id:'r_hold2',    type:'empty',    x:288, y:170, w:80, h:72, floor:0, adjacent:['r_hold1'] },
      { id:'r_piloting', type:'piloting', x: 20, y: 90, w:80, h:72, floor:1, adjacent:['r_oxygen'] },
      { id:'r_oxygen',   type:'oxygen',   x:128, y: 90, w:80, h:72, floor:1, adjacent:['r_piloting','r_reactor'] },
      { id:'r_reactor',  type:'reactor',  x:208, y: 90, w:80, h:72, floor:1, adjacent:['r_oxygen','r_hold3'] },
      { id:'r_hold3',    type:'empty',    x:288, y: 90, w:80, h:72, floor:1, adjacent:['r_reactor'] },
    ],
    elevators: [
      { id:'ev0', x: 114, floors:[217, 137] },
    ],
    startSystems: ['engines','weapons','piloting','oxygen','reactor'],
    systemLevels: { weapons: 2, engines: 2 },
    startWeapons: ['laser_basic'],
    reactorLevel: 8,
    reactorMax: 14,
    weaponX: 390,
    weaponSlots: 1,
    // A freighter is mostly hold — this is the reason to buy one.
    cargoCols: 7, cargoRows: 5,
  },

  /** Player starting frigate — 3 floors.
   *  Grid: 3 room columns (x 20 / 144 / 268, w 96) separated by two
   *  28px-wide elevator shafts (x 130 / 254). Shafts NEVER overlap rooms:
   *  column edges 116|144 and 240|268 are exactly the shaft walls. */
  frigate: {
    label: 'Kestrel Mk II',
    spriteKey: 'ship_player',
    hullMax: 30,
    floors: 3,
    rooms: [
      // Floor 0 (bottom)
      { id:'r_engines',  type:'engines',  x: 20,  y:220, w:96, h:80, floor:0, adjacent:['r_weapons'] },
      { id:'r_weapons',  type:'weapons',  x:144,  y:220, w:96, h:80, floor:0, adjacent:['r_engines','r_shields'] },
      { id:'r_shields',  type:'shields',  x:268,  y:220, w:96, h:80, floor:0, adjacent:['r_weapons'] },

      // Floor 1 (middle)
      { id:'r_piloting', type:'piloting', x: 20,  y:130, w:96, h:80, floor:1, adjacent:['r_oxygen'] },
      { id:'r_oxygen',   type:'oxygen',   x:144,  y:130, w:96, h:80, floor:1, adjacent:['r_piloting','r_medbay'] },
      { id:'r_medbay',   type:'medbay',   x:268,  y:130, w:96, h:80, floor:1, adjacent:['r_oxygen'] },

      // Floor 2 (top — reactor amidships; the side rooms start EMPTY
      // and can be converted into weapon modules at a station)
      { id:'r_crew1',    type:'empty',    x: 20,  y: 40, w:96, h:80, floor:2, adjacent:['r_reactor'] },
      { id:'r_reactor',  type:'reactor',  x:144,  y: 40, w:96, h:80, floor:2, adjacent:['r_crew1','r_crew3'] },
      { id:'r_crew3',    type:'empty',    x:268,  y: 40, w:96, h:80, floor:2, adjacent:['r_reactor'] },
    ],
    // Shaft stops sit on the crew walk line of each floor (y + h*0.65)
    elevators: [
      { id:'ev0', x: 130, floors:[272, 182, 92] },
      { id:'ev1', x: 254, floors:[272, 182, 92] },
    ],
    startSystems: ['engines','weapons','shields','piloting','oxygen','medbay','reactor'],
    // Rough start: shields MODULE lvl1 (2 pips = 1 layer @ 2 power),
    // reactor lvl3 (6 power)
    systemLevels: { shields: 2, weapons: 2, engines: 2 },
    startWeapons: ['laser_basic'],
    reactorLevel: 8,   // 1 power per level — start with 8 power
    reactorMax: 16,    // this hull's reactor limit
    weaponX: 360,   // world X where weapons are drawn on hull exterior
    weaponSlots: 1,   // start with ONE weapon module; buy 2nd/3rd at stations
    cargoCols: 6, cargoRows: 4,
  },

  /** Enemy frigate — classic: cockpit up front, reactor topside aft */
  enemy_frigate: {
    label: 'Rebel Interceptor',
    spriteKey: 'ship_enemy',
    hullMax: 20,
    floors: 2,
    // Grid: engines | 28px shaft | weapons | shields (shared wall).
    // Upper floor aligned to the same columns — shaft never crosses a room.
    rooms: [
      { id:'r_engines',  type:'engines',  x: 20, y:170, w:80, h:72, floor:0, adjacent:['r_weapons'] },
      { id:'r_weapons',  type:'weapons',  x:128, y:170, w:80, h:72, floor:0, adjacent:['r_engines','r_shields'] },
      { id:'r_shields',  type:'shields',  x:208, y:170, w:80, h:72, floor:0, adjacent:['r_weapons'] },
      { id:'r_piloting', type:'piloting', x: 20, y: 90, w:80, h:72, floor:1, adjacent:['r_oxygen'] },
      { id:'r_oxygen',   type:'oxygen',   x:128, y: 90, w:80, h:72, floor:1, adjacent:['r_piloting','r_reactor'] },
      { id:'r_reactor',  type:'reactor',  x:208, y: 90, w:80, h:72, floor:1, adjacent:['r_oxygen'] },
    ],
    elevators: [
      { id:'ev0', x: 114, floors:[217, 137] },
    ],
    startSystems: ['engines','weapons','shields','piloting','oxygen','reactor'],
    systemLevels: { shields: 2, weapons: 2, engines: 2 },
    startWeapons: ['laser_basic'],
    reactorLevel: 8,   // 1 power per level (auto-sized per spawn)
    reactorMax: 12,
    weaponX: 310,
    weaponSlots: 1,   // one weapon module room
  },

  /** Enemy gunship — TWO weapon modules on the gun deck (elite hull) */
  enemy_gunship: {
    label: 'Rebel Gunship',
    spriteKey: 'ship_enemy',
    hullMax: 20,
    floors: 2,
    rooms: [
      { id:'r_piloting', type:'piloting', x: 20, y:170, w:80, h:72, floor:0, adjacent:['r_reactor'] },
      { id:'r_reactor',  type:'reactor',  x:128, y:170, w:80, h:72, floor:0, adjacent:['r_piloting','r_engines'] },
      { id:'r_engines',  type:'engines',  x:208, y:170, w:80, h:72, floor:0, adjacent:['r_reactor'] },
      { id:'r_weapons',  type:'weapons',  x: 20, y: 90, w:80, h:72, floor:1, adjacent:['r_weapons2'] },
      { id:'r_weapons2', type:'weapons',  x:128, y: 90, w:80, h:72, floor:1, adjacent:['r_weapons','r_oxygen'] },
      { id:'r_oxygen',   type:'oxygen',   x:208, y: 90, w:80, h:72, floor:1, adjacent:['r_weapons2','r_shields'] },
      { id:'r_shields',  type:'shields',  x:288, y: 90, w:80, h:72, floor:1, adjacent:['r_oxygen'] },
    ],
    elevators: [
      { id:'ev0', x: 114, floors:[217, 137] },
    ],
    startSystems: ['engines','weapons','shields','piloting','oxygen','reactor'],
    systemLevels: { shields: 2, weapons: 2, engines: 2 },
    startWeapons: ['laser_basic'],
    reactorLevel: 8,
    reactorMax: 14,
    weaponX: 310,
    weaponSlots: 2,
  },

  /** Enemy raider — reactor buried aft on the lower deck, shields forward */
  enemy_raider: {
    label: 'Rebel Raider',
    spriteKey: 'ship_enemy',
    hullMax: 20,
    floors: 2,
    rooms: [
      { id:'r_weapons',  type:'weapons',  x: 20, y:170, w:80, h:72, floor:0, adjacent:['r_reactor'] },
      { id:'r_reactor',  type:'reactor',  x:128, y:170, w:80, h:72, floor:0, adjacent:['r_weapons','r_engines'] },
      { id:'r_engines',  type:'engines',  x:208, y:170, w:80, h:72, floor:0, adjacent:['r_reactor'] },
      { id:'r_shields',  type:'shields',  x: 20, y: 90, w:80, h:72, floor:1, adjacent:['r_piloting'] },
      { id:'r_piloting', type:'piloting', x:128, y: 90, w:80, h:72, floor:1, adjacent:['r_shields','r_oxygen'] },
      { id:'r_oxygen',   type:'oxygen',   x:208, y: 90, w:80, h:72, floor:1, adjacent:['r_piloting'] },
    ],
    elevators: [
      { id:'ev0', x: 114, floors:[217, 137] },
    ],
    startSystems: ['engines','weapons','shields','piloting','oxygen','reactor'],
    systemLevels: { shields: 2, weapons: 2, engines: 2 },
    startWeapons: ['laser_basic'],
    reactorLevel: 8,
    reactorMax: 12,
    weaponX: 310,
    weaponSlots: 1,   // one weapon module room
  },

  /** THE MOTHERSHIP — a vertical STATION. One central elevator shaft,
   *  rooms flanking it left/right (some floors have one, some two),
   *  6 floors tall. ALL modules + THREE weapon mounts. */
  boss_station: {
    label: 'The Mothership',
    spriteKey: 'ship_enemy',
    hullMax: 40,
    floors: 6,
    // Shaft x=150 (gap 136-164) · left col 40-136 · right col 164-260
    rooms: [
      { id:'r_engines',  type:'engines',  x: 40, y:350, w:96, h:60, floor:0, adjacent:['r_medbay'] },
      { id:'r_medbay',   type:'medbay',   x:164, y:350, w:96, h:60, floor:0, adjacent:['r_engines'] },
      { id:'r_reactor',  type:'reactor',  x: 40, y:284, w:96, h:60, floor:1, adjacent:['r_oxygen'] },
      { id:'r_oxygen',   type:'oxygen',   x:164, y:284, w:96, h:60, floor:1, adjacent:['r_reactor'] },
      { id:'r_weapons3', type:'weapons',  x: 40, y:218, w:96, h:60, floor:2, adjacent:['r_shields'] },
      { id:'r_shields',  type:'shields',  x:164, y:218, w:96, h:60, floor:2, adjacent:['r_weapons3'] },
      { id:'r_weapons',  type:'weapons',  x: 40, y:152, w:96, h:60, floor:3, adjacent:['r_weapons2'] },
      { id:'r_weapons2', type:'weapons',  x:164, y:152, w:96, h:60, floor:3, adjacent:['r_weapons'] },
      { id:'r_piloting', type:'piloting', x: 40, y: 86, w:96, h:60, floor:4, adjacent:[] },
      { id:'r_top',      type:'empty',    x:164, y: 20, w:96, h:60, floor:5, adjacent:[] },
    ],
    // Central shaft serves every floor (stops on the walk lines y+39)
    elevators: [
      { id:'ev0', x: 150, floors:[389, 323, 257, 191, 125, 59] },
    ],
    startSystems: ['engines','medbay','reactor','oxygen','weapons','shields','piloting'],
    systemLevels: { shields: 4, engines: 3, piloting: 2, oxygen: 2, medbay: 2, weapons: 2 },
    startWeapons: [],
    reactorLevel: 8,
    reactorMax: 20,
    weaponX: 300,
    weaponSlots: 3,
  },
};

// ── Ship ──────────────────────────────────────────────────

class Ship {
  /**
   * @param {string}  layoutKey  - key into SHIP_LAYOUTS
   * @param {boolean} isPlayer
   * @param {number}  worldX     - ship world X origin
   * @param {number}  worldY     - ship world Y origin
   */
  constructor(layoutKey, isPlayer = true, worldX = 0, worldY = 0) {
    this.layoutKey = layoutKey;
    this.layout    = SHIP_LAYOUTS[layoutKey];
    if (!this.layout) throw new Error(`Unknown ship layout: ${layoutKey}`);

    this.isPlayer = isPlayer;
    this.worldX   = worldX;
    this.worldY   = worldY;

    this.label    = this.layout.label;
    this.hull     = this.layout.hullMax;
    this.hullMax  = this.layout.hullMax;

    // ── Build rooms ──────────────────────────────────────
    this.rooms = this.layout.rooms.map(cfg => new Room({
      ...cfg,
      x: worldX + cfg.x,
      y: worldY + cfg.y,
    }));

    // ── Build systems — ONE per system-type room ──────────
    // Multiple rooms of the same type (e.g. two 'weapons' modules)
    // each get their OWN independent system instance.
    this.systems = [];
    this.reactor  = new Reactor(this.layout.reactorLevel,
                                this.layout.reactorMax ?? 16);

    this.rooms.forEach(room => {
      if (room.type === 'empty' || !SYSTEM_DEFS[room.type]) return;
      const lvl = room.type === 'reactor'
        ? this.reactor.capacity
        : (this.layout.systemLevels ?? {})[room.type] ?? 1;
      const sys = new ShipSystem(room.type, lvl);
      this.systems.push(sys);

      // Link to room
      room.system = sys;
      sys.roomId  = room.id;
      sys.roomX   = room.x;
      sys.roomY   = room.y;
      sys.roomW   = room.w;
      sys.roomH   = room.h;
      sys.cx      = room.cx;
      sys.cy      = room.cy;
    });

    // Link the reactor budget object to its room system —
    // from now on damage to the reactor ROOM = lost power.
    this.reactor.sys = this.getSystem('reactor');

    // Default power allocation
    this._allocateDefaultPower();

    // ── Weapons rack — ONE gun per weapon module room ────
    this.weapons     = [];
    this.weaponCargo = [];   // uninstalled guns (defKeys), managed at stations

    // ── Cargo hold ──────────────────────────────────────
    // A grid, not a list: salvage has a shape, so hull choice and hold
    // upgrades finally mean something. Sized by the layout. (cargo.js
    // may be absent in a stripped-down test — degrade, do not explode.)
    this.cargo = (typeof CargoGrid !== 'undefined')
      ? new CargoGrid(this.layout.cargoCols ?? 5, this.layout.cargoRows ?? 4)
      : null;

    // Slots = number of weapon MODULE rooms (boss may override upward)
    this.weaponSlots = Math.max(this.weaponRooms.length,
                                this.layout.weaponSlots ?? 0);
    this.layout.startWeapons.forEach((wk, i) => {
      this.installWeapon(wk, i);
    });

    // ── Crew ────────────────────────────────────────────
    this.crew = [];

    // ── Subsystems ──────────────────────────────────────
    this.oxygen   = new OxygenManager();
    this.rooms.forEach(r => this.oxygen.addRoom(r.id));

    this.fires    = new FireManager();
    this.breaches = new BreachManager();
    // Expose breaches list directly for compatibility
    Object.defineProperty(this, 'breachesList', {
      get: () => this.breaches.breaches
    });

    // ── Elevators ────────────────────────────────────────
    this.elevators = new ElevatorManager();
    (this.layout.elevators ?? []).forEach(ev => {
      this.elevators.addShaft(ev.id, worldX + ev.x,
        ev.floors.map(fy => worldY + fy));
    });

    // Shafts are air columns: give each one an oxygen cell so open
    // shaft doors equalise O2 between the rooms on either side
    // (replaces the old direct doors that used to cross the shaft).
    this.elevators.shafts.forEach(s => this.oxygen.addRoom(`shaft_${s.id}`));

    // ── Doors between horizontally adjacent rooms ───────
    // If an elevator shaft sits in the gap between two rooms, they get
    // NO direct door — passage/airflow goes through the shaft's own
    // doors instead (a shaft and a room never share space).
    this.doors = [];
    const donePairs = new Set();
    this.rooms.forEach(room => {
      room.adjacent.forEach(adjId => {
        const other = this.getRoomById(adjId);
        if (!other || other.floor !== room.floor) return;
        const key = [room.id, other.id].sort().join('|');
        if (donePairs.has(key)) return;
        donePairs.add(key);
        if (this._shaftBetween(room, other)) return;   // shaft occupies the gap
        // Door at shared vertical edge, hung on the floor's door line
        const doorX = room.x < other.x ? room.x + room.w : other.x + other.w;
        const doorY = this.floorDoorY(room.floor, room.y + room.h * 0.5);
        // Only if rooms actually touch horizontally
        if (Math.abs((room.x + room.w) - other.x) < 30 ||
            Math.abs((other.x + other.w) - room.x) < 30) {
          this.doors.push(new Door(room.id, other.id, doorX, doorY));
        }
      });
    });

    // Elevator shaft doors — each shaft gets a door on BOTH sides
    // at every floor it serves (shaft is its own vertical module)
    this.elevators.shafts.forEach(shaft => {
      shaft.floorYs.forEach(fy => {
        // Find rooms adjacent to shaft on this floor (left and right)
        const floorIdx = this.floorAtY(fy);
        const onFloor  = this.rooms.filter(r => r.floor === floorIdx);
        const shaftDoorY = this.floorDoorY(floorIdx, fy);
        onFloor.forEach(room => {
          const touchesLeft  = Math.abs((room.x + room.w) - (shaft.x - shaft.width/2)) < 26;
          const touchesRight = Math.abs(room.x - (shaft.x + shaft.width/2)) < 26;
          if (touchesLeft) {
            this.doors.push(new Door(room.id, `shaft_${shaft.id}`,
              shaft.x - shaft.width/2, shaftDoorY, false));
          }
          if (touchesRight) {
            this.doors.push(new Door(room.id, `shaft_${shaft.id}`,
              shaft.x + shaft.width/2, shaftDoorY, false));
          }
        });
      });
    });

    // Airlocks — one on the outer wall of the leftmost and rightmost
    // room of each floor (FTL-style venting hatches)
    const floors = [...new Set(this.rooms.map(r => r.floor))];
    floors.forEach(f => {
      const onFloor = this.rooms.filter(r => r.floor === f);
      if (!onFloor.length) return;
      const leftmost  = onFloor.reduce((a, r) => r.x < a.x ? r : a);
      const rightmost = onFloor.reduce((a, r) => r.x + r.w > a.x + a.w ? r : a);
      const airY = this.floorDoorY(f, leftmost.y + leftmost.h * 0.5);
      this.doors.push(new Door(leftmost.id,  null, leftmost.x,               airY, true));
      if (rightmost.id !== leftmost.id) {
        this.doors.push(new Door(rightmost.id, null, rightmost.x + rightmost.w, airY, true));
      }
    });

    // ── In-flight projectiles ───────────────────────────
    this.projectiles = [];

    // ── Visual body = room bounding box ──────────────────
    const _b = this.roomBounds();
    this.spriteW = _b.w + 28;
    this.spriteH = _b.h + 28;

    // Shield visual
    this._shieldPulse = null;
    this._shieldAlpha = 0;

    // Destruction
    this.destroyed    = false;
    this._deathTimer  = 0;
    this._explosionTimer = new Utils.Interval(0.18);
  }

  // ── Accessors ────────────────────────────────────────────

  getSystem(type) { return this.systems.find(s => s.type === type) || null; }
  getRoomById(id) { return this.rooms.find(r => r.id === id) || null; }

  getAdjacentRooms(roomId) {
    const room = this.getRoomById(roomId);
    if (!room) return [];
    return room.adjacent.map(id => this.getRoomById(id)).filter(Boolean);
  }

  /** Elevator shaft standing in the horizontal gap between two rooms, or null */
  _shaftBetween(a, b) {
    if (!this.elevators) return null;
    const left  = a.x < b.x ? a : b;
    const right = a.x < b.x ? b : a;
    return this.elevators.shafts.find(s =>
      s.x >= left.x + left.w && s.x <= right.x) || null;
  }

  /** Both shaft-side doors open at the given room pair's floor? */
  _shaftChannelOpen(shaft, roomA, roomB) {
    const sid  = `shaft_${shaft.id}`;
    const near = (d, room) =>
      d.roomB === sid && d.roomA === room.id &&
      d.y > room.y - 6 && d.y < room.y + room.h + 6;
    const dA = this.doors.find(d => near(d, roomA));
    const dB = this.doors.find(d => near(d, roomB));
    return !!(dA && dB && dA.open && dB.open);
  }

  /** Adjacent rooms reachable through OPEN doors (fire spread uses this) */
  getOpenAdjacentRooms(roomId) {
    const room = this.getRoomById(roomId);
    if (!room) return [];
    return room.adjacent
      .map(id => this.getRoomById(id))
      .filter(r => {
        if (!r) return false;
        // Different floor — no door, fire cannot spread vertically
        if (r.floor !== room.floor) return false;
        const door = this.doors.find(d =>
          (d.roomA === roomId && d.roomB === r.id) ||
          (d.roomB === roomId && d.roomA === r.id));
        if (door) return door.open;
        // Rooms separated by an elevator shaft: fire crosses only
        // when BOTH shaft doors on this floor are open.
        const shaft = this._shaftBetween(room, r);
        if (shaft) return this._shaftChannelOpen(shaft, room, r);
        return true;  // genuinely touching, no door = open corridor
      });
  }

  /** Which floor index is at world Y? Returns -1 if outside */
  floorAtY(wy) {
    let best = -1, bestDist = Infinity;
    this.rooms.forEach(r => {
      if (wy >= r.y - 10 && wy <= r.y + r.h + 10) {
        const d = Math.abs(r.cy - wy);
        if (d < bestDist) { bestDist = d; best = r.floor; }
      }
    });
    return best;
  }

  /** Canonical door centre-line for a floor.
   *  EVERY hatch on a floor — interior, elevator and airlock — hangs
   *  here. Each door used to take the centre of whichever room spawned
   *  it, so rooms of different heights pushed their doors to different
   *  levels and the outer airlocks sat visibly off from the interior
   *  doors on every hull in the game. */
  floorDoorY(floorIndex, fallbackY = 0) {
    const roomsOnFloor = this.rooms.filter(r => r.floor === floorIndex);
    if (!roomsOnFloor.length) return fallbackY;
    const top = Math.min(...roomsOnFloor.map(r => r.y));
    const bot = Math.max(...roomsOnFloor.map(r => r.y + r.h));
    return (top + bot) / 2;
  }

  /** Walking Y line for a floor (crew feet level) */
  floorWalkY(floorIndex, fallbackY = 0) {
    const roomsOnFloor = this.rooms.filter(r => r.floor === floorIndex);
    if (!roomsOnFloor.length) return fallbackY;
    // Walk line = lower third of room (feet on floor)
    const r = roomsOnFloor[0];
    return r.y + r.h * 0.65;
  }

  get shieldBars() {
    const ss = this.getSystem('shields');
    return ss ? ss.shieldBars : 0;
  }

  get shieldMax() {
    const ss = this.getSystem('shields');
    return ss ? ss.shieldMax : 0;
  }

  get evasion() {
    const pilot = this.getSystem('piloting');
    const eng   = this.getSystem('engines');

    // FTL rule: no pilot in cockpit = no evasion at all
    const pilotRoom = pilot ? this.getRoomById(pilot.roomId) : null;
    const hasPilot  = pilotRoom
      ? this.crew.some(c => !c.dead && !c.dying && c.roomId === pilotRoom.id)
      : false;
    if (!hasPilot) return 0;

    const pilotPct = pilot ? pilot.effectivePower() * 0.03 : 0;   // 3%/level
    const engPct   = eng   ? eng.effectivePower()   * 0.02 : 0;   // 2%/level
    const cloak    = this.getSystem('cloaking');
    // Cloak now gives a big evasion spike ONLY while actively cloaked.
    const cloakPct = (cloak && cloak.cloakActive) ? 0.60 : 0;

    // Crew skill bonuses
    const skillPct = this.crew
      .filter(c => !c.dead && c.roomId === pilotRoom.id)
      .reduce((a, c) => a + c.pilotBonus(), 0);

    const cap = (cloak && cloak.cloakActive) ? 0.9 : 0.75;
    return Utils.clamp(pilotPct + engPct + cloakPct + skillPct, 0, cap);
  }

  get hullPct() { return this.hull / this.hullMax; }

  // ── Crew helpers ─────────────────────────────────────────

  addCrew(member, keepPosition = false) {
    // Never add the same member twice (boarding recovery could
    // otherwise duplicate crew on the roster).
    if (this.crew.includes(member)) return;
    if (keepPosition) {
      // Caller already placed x/y/roomId precisely (e.g. a boarder
      // storming into the room they just breached) — don't scramble it.
      member.targetX = member.x;
      member.targetY = member.y;
      this.crew.push(member);
      return;
    }
    // Place each crew member in a different room (cycle through rooms)
    const idx  = this.crew.length % this.rooms.length;
    const room = this.rooms[idx] || this.rooms[0];
    if (room) {
      const [sx, sy] = this.stationSpot(room);
      member.x = sx;
      member.y = sy;
      member.roomId = room.id;
      // A recruit with no station never settles anywhere and reads as
      // "broken" to the player — give them the room they walked into.
      if (!member.homeRoomId) member.homeRoomId = room.id;
    } else {
      member.x = this.worldX + 100;
      member.y = this.worldY + 100;
    }
    member.targetX = member.x;
    member.targetY = member.y;
    this.crew.push(member);
  }

  /**
   * Assign home stations by priority:
   * cockpit → engines → shields → weapons → oxygen → medbay.
   * Prefers crew whose corporation matches the module.
   */
  assignStations() {
    // Weapons need a live OPERATOR per module now — stations cover
    // piloting first, then EVERY weapon room, then the rest.
    const prefer = { piloting:'pegasus', engines:'terra', shields:'aquarius', weapons:'phoenix' };
    const unassigned = this.crew.filter(c => !c.dead && !c.isSpider);
    const posts = [];
    const pilot = this.getSystem('piloting');
    if (pilot?.roomId) posts.push({ type:'piloting', roomId: pilot.roomId });
    this.weaponRooms.forEach(r => posts.push({ type:'weapons', roomId: r.id }));
    ['shields','engines','oxygen','medbay'].forEach(t => {
      const sys = this.getSystem(t);
      if (sys?.roomId) posts.push({ type: t, roomId: sys.roomId });
    });

    posts.forEach(post => {
      if (!unassigned.length) return;
      let idx = unassigned.findIndex(c => c.race === prefer[post.type]);
      if (idx === -1) idx = 0;
      const c = unassigned.splice(idx, 1)[0];
      c.homeRoomId = post.roomId;
      const room = this.getRoomById(post.roomId);
      if (room) c.moveToOnShip(this, ...this.stationSpot(room));
    });
  }

  /** Where a crew member should STAND in a room.
   *  Deliberately never the exact centre: a crew member parked dead in
   *  the middle of a module swallowed every click aimed at that module
   *  (you'd re-select him instead of ordering anyone in), which is what
   *  made new recruits look like they "can't use the elevator". Spots
   *  fan out left/right of centre, so the middle stays clickable. */
  stationSpot(room, occupants = null) {
    const n = occupants ?? this.crew.filter(c =>
      c.alive && (c.roomId === room.id || c.homeRoomId === room.id)).length;
    const slot = [-1, 1, 0][Math.min(n, 2)];      // left, right, then centre
    const x = Utils.clamp(room.cx + slot * 26, room.x + 14, room.x + room.w - 14);
    return [x, this.floorWalkY(room.floor, room.cy)];
  }

  crewInRoom(roomId) {
    // Only fully-able crew count for manning/repairs — the downed
    // and the dead lie on the floor (see bodiesInRoom).
    return this.crew.filter(c => c.roomId === roomId && c.alive);
  }

  bodiesInRoom(roomId) {
    return this.crew.filter(c => c.roomId === roomId && c.down);
  }

  /** Called by Game whenever a new battle begins: unburied corpses
   *  start to ROT — and rotting corpses spread the plague. */
  markCombatStart() {
    this.crew.forEach(c => {
      if (!c.dead) return;
      c._deadCombats = (c._deadCombats ?? 0) + 1;
      if (c._deadCombats >= 1 && !c.decaying) {
        c.decaying = true;
        if (this.isPlayer && typeof UI !== 'undefined') {
          UI.notify(`${c.name}'s body is DECAYING — eject it before the crew gets sick!`, 'alert');
        }
      }
    });
  }

  /** Carry the wounded to the medbay, carry the dead to an airlock,
   *  rot unburied corpses onto the crew, remove the ejected. */
  _updateBodies(dt) {
    // Remove anyone who went out the airlock (self-ejected plague
    // victims and committed corpses alike) — the roster entry goes.
    const ejected = this.crew.filter(c => c.ejected);
    ejected.forEach(c => {
      if (c.carriedBy) c.carriedBy.carrying = null;
      if (this.isPlayer && typeof UI !== 'undefined') {
        UI.notify(c.dead ? `${c.name}'s body committed to space.` :
                           `${c.name} walked out of the airlock…`, c.dead ? 'info' : 'alert');
      }
      Particles.emit?.({ x: c.x, y: c.y, vx: this.isPlayer ? -60 : 60, vy: -10,
        ay: 0, color: '#aaccee', size: 3, sizeEnd: 0, life: 1, alpha: 0.8, alphaEnd: 0 });
    });
    if (ejected.length) this.crew = this.crew.filter(c => !c.ejected);

    const medbay = this.getSystem('medbay');
    const medRoom = medbay ? this.getRoomById(medbay.roomId) : null;

    const medPowered = medbay && medRoom && medbay.effectivePower() > 0;

    const medUsable = !!medRoom && !!medPowered;

    // ── RESCUE DISPATCH ──────────────────────────────────────
    // Pickup below only ever triggers for a body in the SAME room, so a
    // crew member who went down somewhere else just bled out while the
    // rest of the ship carried on (the enemy pilot ignoring his downed
    // gunner). Send the nearest able hand to them — to carry them to a
    // medbay if the ship has one, or to patch them up on the spot if it
    // doesn't (most enemy hulls carry no medbay at all).
    {
      // Drop stale claims first (target rescued, dead or already lifted)
      this.crew.forEach(c => {
        if (!c._rescueId) return;
        const t = this.crew.find(b => b.id === c._rescueId);
        if (!t || t.dead || !t.down || t.carriedBy || !c.alive) c._rescueId = null;
      });

      this.crew.forEach(body => {
        if (body.dead || !body.down || body.carriedBy) return;
        if (body.roomId === medRoom?.id && medPowered) return;  // already being treated
        if (this.crewInRoom(body.roomId).length > 0) return;    // someone's there already
        if (this.crew.some(c => c._rescueId === body.id)) return;

        const helper = this.crew
          .filter(c => c.alive && !c.carrying && !c._rescueId &&
                       c.task !== TASK.REPAIR && c.task !== TASK.BREACH &&
                       c.task !== TASK.FIRE && c.task !== TASK.FIGHT)
          .sort((a, b) => Utils.dist(a.x, a.y, body.x, body.y) -
                          Utils.dist(b.x, b.y, body.x, body.y))[0];
        if (!helper) return;
        helper._rescueId  = body.id;
        helper.homeRoomId = body.roomId;   // walk there; pickup/field aid takes over
        helper.moveToOnShip(this, body.x, body.y);
      });
    }

    this.crew.forEach(c => {
      if (!c.alive) return;
      // Spiders are not a repair crew. They do not fix the wreck they
      // live in, do not haul bodies and do not man stations — they sit
      // in their rooms and kill whatever comes through the door.
      if (c.isSpider) return;
      // An EXPLICIT emergency job outranks opportunistic body-hauling.
      // Without this, a crew member sent to seal a breach or fix a
      // module would scoop up a wounded body on arrival and walk off to
      // the medbay, so the damage never got repaired at all.
      const onEmergency = c.task === TASK.REPAIR || c.task === TASK.BREACH ||
                          c.task === TASK.FIRE;
      // Same reasoning for the room they're standing in: while it is
      // burning, holed or shot out, that work comes first — otherwise
      // they seal the breach and immediately wander off with a body,
      // leaving the module broken.
      const hereRoom = this.getRoomById(c.roomId);
      const roomBusy = !!hereRoom && (
        this.fires.getFiresInRoom(hereRoom.id).length > 0 ||
        this.breaches.hasBreachInRoom(hereRoom.id) ||
        (hereRoom.system && hereRoom.system.damagedLevels > 0));
      // Pick up a body sharing the room (wounded first) — but NOT a
      // wounded crew member already lying in a working medbay (that
      // caused the endless carry-back-and-forth jitter), and only if
      // there's actually somewhere useful to take them.
      if (!c.carrying && !onEmergency && !roomBusy) {
        const body = this.bodiesInRoom(c.roomId)
          .filter(b => !b.carriedBy)
          .filter(b => {
            if (b.dead) return true;   // corpses always get hauled out
            // wounded: skip if already in a powered medbay (healing)
            if (medRoom && b.roomId === medRoom.id && medPowered) return false;
            // wounded: pointless to carry if there's no medbay at all
            return !!medRoom;
          })
          .sort((a, b) => (a.dead ? 1 : 0) - (b.dead ? 1 : 0))[0];
        if (body) { body.carriedBy = c; c.carrying = body; c._rescueId = null; }
      }
      const body = c.carrying;
      if (!body) return;
      // The body rides on the carrier's shoulders
      body.x = c.x; body.y = c.y - 10; body.roomId = c.roomId;

      if (!body.dead) {
        // WOUNDED → medbay
        if (medRoom) {
          if (c.roomId === medRoom.id ||
              Utils.dist(c.x, c.y, medRoom.cx, medRoom.cy) < 30) {
            // Arrived: lay them down and STOP (carrier stays put so it
            // doesn't wander off and re-trigger a pickup next frame).
            body.carriedBy = null; c.carrying = null;
            body.x = medRoom.cx + Utils.randFloat(-16, 16);
            body.y = medRoom.cy + 10;
            body.roomId = medRoom.id;
            c._waypoints = [];
            c.homeRoomId = medRoom.id;
          } else if (!c._waypoints.length) {
            c.moveToOnShip(this, medRoom.cx, medRoom.cy);
          }
        }
      } else {
        // DEAD → nearest airlock, then out it goes
        const air = this.doors.filter(d => d.isAirlock)
          .sort((a, b) => Utils.dist(c.x, c.y, a.x, a.y) -
                          Utils.dist(c.x, c.y, b.x, b.y))[0];
        if (air) {
          if (Utils.dist(c.x, c.y, air.x, air.y) < 26) {
            body.ejected = true;
            body.carriedBy = null; c.carrying = null;
          } else if (!c._waypoints.length) {
            c.moveToOnShip(this, air.x, air.y);
          }
        }
      }
    });

    // Medbay treats the wounded lying on its floor
    if (medbay && medRoom && medbay.effectivePower() > 0) {
      this.bodiesInRoom(medRoom.id).forEach(b => {
        if (b.dead) return;
        b.hp = Math.min(b.maxHp, b.hp + 6 * dt * medbay.effectivePower());
        if (b.hp >= b.maxHp * 0.3) {
          b.state = 'ok';
          if (this.isPlayer && typeof UI !== 'undefined') {
            UI.notify(`${b.name} is back on their feet!`, 'good');
          }
        }
      });
    }

    // FIELD AID: with no usable medbay (none fitted, or shot out /
    // unpowered), an able crew member kneeling beside a wounded comrade
    // patches them up where they lie. Slower than a medbay, but it
    // means going down is no longer a death sentence on hulls that
    // never had a medbay — which is every enemy frigate.
    if (!medUsable) {
      this.crew.forEach(body => {
        if (body.dead || !body.down || body.carriedBy) return;
        const medic = this.crewInRoom(body.roomId).find(c => !c.carrying);
        if (!medic) return;
        body.hp = Math.min(body.maxHp, body.hp + 2.2 * dt);
        if (Math.random() < dt * 0.7) Particles.repairSparks?.(body.x, body.y - 6);
        if (body.hp >= body.maxHp * 0.3) {
          body.state = 'ok';
          medic.addXP?.('repair', 5);
          if (this.isPlayer && typeof UI !== 'undefined') {
            UI.notify(`${medic.name} patched ${body.name} up in the field.`, 'good');
          }
        }
      });
    }

    // Rotting corpses spread the plague to the living in the room
    this.crew.forEach(body => {
      if (!body.dead || !body.decaying) return;
      this.crewInRoom(body.roomId).forEach(c => {
        if (!c.infected && Math.random() < dt * 0.05) {
          c.infected = true;
          if (this.isPlayer && typeof UI !== 'undefined') {
            UI.notify(`${c.name} caught the corpse plague! ☣`, 'alert');
          }
        }
      });
    });
  }

  /** Instantly charge shields to full (used at combat start) */
  prechargeShields() {
    const ss = this.getSystem('shields');
    if (!ss) return;
    const layers = Math.floor(ss.effectivePower() / (ss.def.powerPerLayer ?? 2));
    ss._shieldMax  = layers;
    ss._shieldBars = layers;
    ss._shieldTimer = 0;
  }

  /** Weapon module rooms in slot order (slot i ↔ i-th weapons room) */
  get weaponRooms() {
    return this.rooms.filter(r => r.type === 'weapons');
  }

  /** The weapon system powering slot i (its own module room) */
  weaponSystemFor(slot) {
    return this.weaponRooms[slot]?.system ?? null;
  }

  /** Crew charge bonus for a SPECIFIC weapon: crew inside ITS module */
  weaponCrewBonusFor(slot) {
    const room = this.weaponRooms[slot];
    if (!room) return 0;
    return this.crewInRoom(room.id)
      .reduce((acc, c) => acc + c.weaponChargeBonus(), 0);
  }

  weaponCrewBonus() {   // legacy aggregate (kept for compatibility)
    return this.weapons.reduce((a, w, i) =>
      Math.max(a, w ? this.weaponCrewBonusFor(i) : 0), 0);
  }

  // ── Weapons ──────────────────────────────────────────────

  /** ONE gun per weapon module. Fails if the slot is occupied or
   *  there is no module room for it (boss ships may override slots). */
  installWeapon(defKey, slot) {
    if (slot >= this.weaponSlots) return false;
    if (this.weapons[slot]) return false;
    const w = new Weapon(defKey, slot);
    this.weapons[slot] = w;
    this._reallocWeaponPower();
    return true;
  }

  /** STATION UPGRADE: convert the first empty room into a brand-new
   *  MODULE of the given type (level 1 system). Weapons cap at 3 per
   *  hull; other module types cap at 1. */
  addModule(type) {
    if (!SYSTEM_DEFS[type]) return false;
    if (type === 'weapons') {
      if (this.weaponRooms.length >= 3) return false;
    } else if (this.getSystem(type)) {
      return false;   // only one cloak / repair bay etc.
    }
    const room = this.rooms.find(r => r.type === 'empty');
    if (!room) return false;
    room.type = type;
    // Some modules are worthless at one pip — shields need a whole
    // 2-power layer before they can raise anything at all.
    const sys = new ShipSystem(type, SYSTEM_DEFS[type].startLevel ?? 1);
    sys.power = 0; sys.desiredPower = 0;   // new modules start UNPOWERED
    room.system = sys;
    sys.roomId = room.id;
    sys.roomX = room.x; sys.roomY = room.y;
    sys.roomW = room.w; sys.roomH = room.h;
    sys.cx = room.cx;   sys.cy = room.cy;
    this.systems.push(sys);
    this._extraModules = this._extraModules ?? [];
    this._extraModules.push(type);
    if (type === 'weapons') {
      this.weaponSlots = Math.max(this.weaponSlots, this.weaponRooms.length);
    }
    return true;
  }

  addWeaponModule() { return this.addModule('weapons'); }

  /** Same as addModule, but into a SPECIFIC empty room chosen by the
   *  player on the station's ship diagram. */
  addModuleAt(type, roomId) {
    if (!SYSTEM_DEFS[type]) return false;
    if (type === 'weapons') {
      if (this.weaponRooms.length >= 3) return false;
    } else if (this.getSystem(type)) {
      return false;
    }
    const room = this.getRoomById(roomId);
    if (!room || room.type !== 'empty') return false;
    room.type = type;
    // Some modules are worthless at one pip — shields need a whole
    // 2-power layer before they can raise anything at all.
    const sys = new ShipSystem(type, SYSTEM_DEFS[type].startLevel ?? 1);
    sys.power = 0; sys.desiredPower = 0;   // new modules start UNPOWERED
    room.system = sys;
    sys.roomId = room.id;
    sys.roomX = room.x; sys.roomY = room.y;
    sys.roomW = room.w; sys.roomH = room.h;
    sys.cx = room.cx;   sys.cy = room.cy;
    this.systems.push(sys);
    this._extraModules = this._extraModules ?? [];
    this._extraModules.push({ type, roomId });
    if (type === 'weapons') {
      this.weaponSlots = Math.max(this.weaponSlots, this.weaponRooms.length);
    }
    return true;
  }

  /** Missiles are physical: the racks in the hold ARE the ammo count. */
  missileCount() { return this.cargo?.countOf?.('missiles') ?? 0; }

  /**
   * Box a gun and stow it in the grid hold. A gun can only ever be
   * MOUNTED or BOXED — there is no weightless rack it can live on.
   * Returns the crate, or null if the hold has no room for it.
   */
  boxWeapon(defKey) {
    if (!this.cargo || typeof cargoCrateForWeapon !== 'function') return null;
    return this.cargo.add(cargoCrateForWeapon(defKey), defKey);
  }

  /** Uninstall a gun into the cargo hold (station use). */
  uninstallWeapon(slot) {
    const w = this.weapons[slot];
    if (!w) return null;
    this.weapons[slot] = null;
    this.weaponCargo.push(w.defKey);
    this._reallocWeaponPower();
    return w.defKey;
  }

  removeWeapon(slot) {
    this.weapons[slot] = null;
    this._reallocWeaponPower();
  }

  _reallocWeaponPower() {
    // Each gun draws power from ITS OWN weapon module. A damaged or
    // ionised module de-powers only the gun mounted in it (FTL rule,
    // one gun per module). Overflow slots without a room (boss ships)
    // share the FIRST module's leftover power.
    let sharedLeft = null;
    this.weapons.forEach((w, i) => {
      if (!w) return;
      const sys = this.weaponSystemFor(i);
      if (sys) {
        w.power = Math.min(w.powerCost, sys.effectivePower());
      } else {
        if (sharedLeft === null) {
          const first = this.weaponSystemFor(0);
          sharedLeft = first ? Math.max(0, first.effectivePower()
            - (this.weapons[0]?.power ?? 0)) : 0;
        }
        const give = Math.min(w.powerCost, sharedLeft);
        w.power    = give;
        sharedLeft -= give;
      }
    });
  }

  // ── Power management ──────────────────────────────────────

  /** Has this ship's power ever been laid out (by the auto-spread or
   *  by the player)? Used so a new battle does NOT stomp the layout the
   *  player set up in the previous one. */
  hasPowerPreference() {
    return this.systems.some(s => s.type !== 'reactor' && s.desiredPower > 0);
  }

  _allocateDefaultPower() {
    // Life support and helm first — the starting reactor (6 power)
    // cannot feed everything, and an unpowered O2 system suffocates.
    const prio = { oxygen:0, piloting:1, shields:2, weapons:3,
                   engines:4, medbay:5, artillery:6 };
    let remaining = this.reactor.totalPower;
    [...this.systems]
      .filter(s => s.type !== 'reactor')
      .sort((a, b) => (prio[a.type] ?? 9) - (prio[b.type] ?? 9))
      .forEach(sys => {
        const give = Math.min(sys.maxPower, remaining);
        sys.power        = give;
        sys.desiredPower = give;
        remaining       -= give;
      });
  }

  setPower(systemType, power) {
    const sys = this.getSystem(systemType);
    if (!sys) return;
    this.setPowerAt(this.systems.indexOf(sys), power);
  }

  /** Index-based power control — needed because a ship can carry
   *  SEVERAL systems of the same type (one per weapon module). */
  setPowerAt(sysIndex, power) {
    const sys = this.systems[sysIndex];
    if (!sys || sys.type === 'reactor') return;
    this.reactor.setPower(sys, power, this.systems);
    sys.desiredPower = sys.power;   // remember intent — restored after repair
    if (sys.type === 'weapons') this._reallocWeaponPower();
    Audio.sfx.powerUp();
  }

  availablePower() {
    return this.reactor.distribute(this.systems);
  }

  // ── Damage resolution ────────────────────────────────────

  /**
   * Receive a projectile hit.
   * Returns { absorbed, hullDamage, roomHit }
   */
  receiveHit(proj) {
    const def = proj.def;

    // ACTIVE CLOAK: nothing lands while the field is up. Not a high
    // evasion roll — a guaranteed miss for the whole duration. That is
    // the point of spending a cooldown on it.
    {
      const cl = this.getSystem('cloaking');
      if (cl && cl.cloakActive) {
        Particles.floatText(proj.x, proj.y - 6, 'CLOAKED', '#cc44ff', 12);
        return { absorbed: true, dodged: true, hullDamage: 0 };
      }
    }

    // Evasion dodge — pilot and engine crew gain XP (FTL)
    if (Math.random() < this.evasion) {
      Particles.floatText(proj.x, proj.y - 6, 'MISS', '#8fd4ff', 12);
      const pSys = this.getSystem('piloting');
      const eSys = this.getSystem('engines');
      if (pSys) this.crewInRoom(pSys.roomId).forEach(c => c.addXP('piloting', 10));
      if (eSys) this.crewInRoom(eSys.roomId).forEach(c => c.addXP('engines', 10));
      return { absorbed: true, dodged: true, hullDamage: 0 };
    }

    // Beam always hits regardless of shields
    const isBeam = def.type === 'beam';
    const isMissile = def.type === 'missile' || def.type === 'cannon';

    // Shield check (missiles bypass, beams bypass)
    if (!isMissile && !isBeam && this.shieldBars > 0) {
      const shSys = this.getSystem('shields');
      shSys.hitShield();
      Particles.shieldHit(proj.x, proj.y);
      this._shieldAlpha = 1;
      Camera.shake(4, 0.15);
      return { absorbed: true, hullDamage: 0 };
    }

    // Damage lands in the room the projectile actually reached.
    // (Previously a random room was picked — targeting was cosmetic
    //  and fires appeared in modules that were never hit.)
    const roomHit =
      this.rooms.find(r => r.contains(proj.x, proj.y)) ||
      this.rooms.find(r => r.contains(proj.targetX, proj.targetY)) ||
      Utils.pick(this.rooms);

    // Hull damage
    const dmg  = def.hull_damage ?? def.damage ?? 1;
    this.hull  = Math.max(0, this.hull - dmg);

    // Floating damage feedback
    if (roomHit.type === 'reactor' && roomHit.system) {
      Particles.floatText(roomHit.cx, roomHit.y + 10, `-${def.damage ?? 1} POWER`, '#ffb020', 12);
    } else {
      Particles.floatText(roomHit.cx, roomHit.y + 10, `-${dmg}`, '#ff5566', 13);
    }

    // System damage — hit breaks one module level per damage point (FTL style)
    if (roomHit.system) {
      roomHit.system.damageLevel(def.damage ?? 1);
    }

    // Crew in the hit room take damage
    this.crewInRoom(roomHit.id).forEach(c => {
      c.takeDamage(Utils.randInt(10, 25) * dmg, 'weapons fire');
    });

    // Ion damage
    if (def.type === 'ion' && roomHit.system) {
      roomHit.system.ionHit();
    }

    // Breach chance (missiles always, heavy hits 25%)
    if (isMissile || (dmg >= 2 && Math.random() < 0.25)) {
      this.breaches.open(
        roomHit.id,
        roomHit.x + Utils.randFloat(8, roomHit.w - 8),
        roomHit.y + Utils.randFloat(8, roomHit.h - 8)
      );
    }

    // Fire chance — per weapon, 25% unless the def says otherwise
    // (the starting laser is deliberately tamer, see WEAPON_DEFS).
    if (Math.random() < (def.fireChance ?? 0.25)) {
      this.fires.start(roomHit.id, roomHit.cx, roomHit.cy);
    }

    Particles.explosion(proj.x, proj.y, 0.7);
    Camera.shake(6, 0.2);

    // Read-at-a-glance feedback: how much it hurt, and WHERE.
    Particles.floatText?.(roomHit.cx, roomHit.y + 10, `-${dmg}`,
                          this.isPlayer ? '#ff5566' : '#ffd780', 15);
    roomHit._hitFlash = 1;          // drawn by Room.draw, fades out

    if (this.hull <= 0) this._beginDestruction();

    return { absorbed: false, hullDamage: dmg, roomHit };
  }

  _beginDestruction() {
    if (this.destroyed) return;
    this.destroyed = false;   // will flip after death animation
    this._deathTimer = 0;
    Audio.sfx.explosion();
    Camera.shake(20, 0.8);
    Save.recordKill();
  }

  // ── Update ───────────────────────────────────────────────

  update(dt) {
    if (this.destroyed) return;

    // Death animation
    if (this.hull <= 0) {
      this._deathTimer += dt;
      if (this._explosionTimer.tick(dt)) {
        const db = this.roomBounds();
        const rx = db.x + Utils.randFloat(0, db.w);
        const ry = db.y + Utils.randFloat(0, db.h);
        Particles.explosion(rx, ry, Utils.randFloat(0.5, 1.5));
      }
      if (this._deathTimer > 2.5) {
        this.destroyed = true;
      }
      return;
    }

    // ── Bodies: carrying, medbay healing, decay plague, ejection ──
    this._updateBodies(dt);

    // Sync crew presence into each system (bonuses, cyborg power, medbay)
    this.systems.forEach(sys => {
      sys.crew = sys.roomId ? this.crewInRoom(sys.roomId) : [];
      sys.shipIsPlayer = this.isPlayer;   // so a system can talk to the UI
    });

    // Systems
    this.systems.forEach(sys => sys.update(dt));

    // FTL power flow: each system draws up to its DESIRED power,
    // limited by working (undamaged) levels and reactor budget.
    // → repairing a module automatically re-lights its bars.
    {
      let remaining = this.reactor.totalPower;
      this.systems.forEach(sys => {
        // Use the SAME cyborg-substitution rule as Reactor.distribute/
        // setPower (ShipSystem.reactorDraw). This loop used to subtract
        // the raw allocation, so a unit the cyborg had freed was never
        // actually available here — the last modules in the list (the
        // medbay, typically) silently got starved and would not switch
        // on no matter how many times you clicked their pips.
        let want = Math.min(sys.desiredPower, sys.workingLevels);
        while (want > 0 && sys.reactorDraw(want) > remaining) want--;
        sys.power  = want;
        remaining -= sys.reactorDraw(want);
      });
    }

    // Repair Bay: powered nanobots slowly mend every damaged system.
    // Rate ≈ half a crew member per powered level (1 level / ~17s).
    const rbay = this.getSystem('autorepair');
    if (rbay) {
      const rate = rbay.effectivePower() * 0.5;
      if (rate > 0) {
        this.systems.forEach(sys => {
          if (sys !== rbay && sys.damagedLevels > 0) sys.repair(dt * rate);
        });
      }
    }

    this._reallocWeaponPower();   // damaged weapon module instantly de-powers ITS gun
    this.weapons.forEach((w, i) => {
      if (!w) return;
      // OPERATOR RULE: a gun charges only while a crew member stands
      // in ITS weapon module (slots without a room fall back to any
      // weapons-room operator — legacy boss overflow).
      const room   = this.weaponRooms[i];
      const manned = room
        ? this.crewInRoom(room.id).length > 0
        : this.weaponRooms.some(r => this.crewInRoom(r.id).length > 0);
      w.update(dt, this.weaponCrewBonusFor(i), manned);
    });

    // Hit flashes fade; wrecked modules smoke so a broken ship LOOKS
    // broken even when you are not reading the power bar.
    this.rooms.forEach(room => {
      if (room._hitFlash > 0) room._hitFlash = Math.max(0, room._hitFlash - dt * 3.5);
      const sys = room.system;
      if (sys && sys.damagedLevels > 0 && Math.random() < dt * (1.2 * sys.damagedLevels)) {
        Particles.damageSmoke?.(room.cx + Utils.randFloat(-14, 14), room.cy);
      }
    });

    // Crew update and room assignment
    this.crew.forEach(c => {
      if (c.dead) return;
      c.update(dt, this);
      // Update roomId based on position
      const inRoom = this.rooms.find(r => r.contains(c.x, c.y));
      if (inRoom) c.roomId = inRoom.id;
    });
    // Remove dead crew (after death anim)
    this.crew = this.crew.filter(c => !c.dead);

    // O2
    this.oxygen.update(dt, this);

    // Fires
    this.fires.update(dt, this);

    // Breaches
    this.breaches.update(dt);

    // Elevators
    this.elevators.update(dt);

    // Doors
    this.doors.forEach(d => d.update(dt, this.crew));

    // Rooms with an open airlock are venting to space
    this.rooms.forEach(room => {
      room.isVacuum = this.doors.some(d =>
        d.isAirlock && d.open && d.roomA === room.id);
    });

    // Shield fade
    this._shieldAlpha = Math.max(0, this._shieldAlpha - dt * 2);

    // Shield pulse
    if (this._shieldPulse) {
      this._shieldPulse.update(dt);
      if (this._shieldPulse.done) this._shieldPulse = null;
    }
  }

  // ── Draw ─────────────────────────────────────────────────

  /** Bounding box of all rooms (the visual ship body) */
  roomBounds() {
    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    this.rooms.forEach(r => {
      minX = Math.min(minX, r.x);      minY = Math.min(minY, r.y);
      maxX = Math.max(maxX, r.x + r.w); maxY = Math.max(maxY, r.y + r.h);
    });
    return { x: minX, y: minY, w: maxX - minX, h: maxY - minY };
  }

  draw(ctx) {
    // Cloaking field: powered cloak renders the whole ship as a
    // shimmering phantom (visual feedback for the evasion bonus)
    const cloakSys = this.getSystem('cloaking');
    const cloaked  = !!(cloakSys && cloakSys.cloakActive);
    if (cloaked) {
      ctx.save();
      const t = (typeof performance !== 'undefined' ? performance.now() : 0) * 0.004;
      ctx.globalAlpha = 0.55 + Math.sin(t) * 0.12;
    }

    // Hull silhouette behind rooms (dark plate with outline)
    const b = this.roomBounds();
    ctx.fillStyle = 'rgba(10,14,26,0.9)';
    ctx.beginPath();
    ctx.roundRect(b.x - 14, b.y - 14, b.w + 28, b.h + 28, 18);
    ctx.fill();
    ctx.strokeStyle = this.isPlayer ? '#1e3a5c' : '#5c1e1e';
    ctx.lineWidth = 3;
    ctx.stroke();

    // Engine glow at rear
    const engX = this.isPlayer ? b.x - 14 : b.x + b.w + 14;
    const g = ctx.createRadialGradient(engX, b.y + b.h/2, 2, engX, b.y + b.h/2, 30);
    g.addColorStop(0, this.isPlayer ? 'rgba(26,255,140,0.6)' : 'rgba(255,80,40,0.6)');
    g.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = g;
    ctx.fillRect(engX - 30, b.y + b.h/2 - 30, 60, 60);

    // Rooms (with systems, O2, fire, breach overlays)
    this.rooms.forEach(room => {
      if (room.system) {
        room.system.draw(ctx);
      } else {
        // Empty module — floor tile + visible frame (crew quarters,
        // or an enemy hull slot with no system installed)
        this._drawEmptyRoom(ctx, room);
      }

      // O2 overlay
      const ro = this.oxygen.getRoom(room.id);
      if (ro) ro.draw(ctx, room.x, room.y, room.w, room.h);

      // HIT FLASH — a shell landing here lights the compartment for a
      // moment. Without it a hit on a far room is easy to miss entirely.
      if (room._hitFlash > 0) {
        ctx.fillStyle = `rgba(255,255,255,${0.55 * room._hitFlash})`;
        ctx.fillRect(room.x, room.y, room.w, room.h);
        ctx.strokeStyle = `rgba(255,90,110,${room._hitFlash})`;
        ctx.lineWidth = 2;
        ctx.strokeRect(room.x + 1, room.y + 1, room.w - 2, room.h - 2);
      }
    });

    // Elevators
    this.elevators.draw(ctx);

    // Doors
    this.doors.forEach(d => d.draw(ctx));

    // Crew (particles below crew)
    Particles.draw(ctx, 0);
    this.crew.forEach(c => c.draw(ctx));

    // Fires
    this.fires.draw(ctx);

    // Breaches
    this.breaches.draw(ctx);

    // Weapon mounts on hull exterior
    this._drawWeaponMounts(ctx);

    // Shield ring
    this._drawShield(ctx);

    // Hull damage glow
    if (this.hull / this.hullMax < 0.35) {
      const b = this.roomBounds();
      const alpha = (0.35 - this.hull / this.hullMax) * 0.5;
      ctx.fillStyle = `rgba(255,45,68,${alpha})`;
      ctx.fillRect(b.x - 14, b.y - 14, b.w + 28, b.h + 28);
    }

    if (cloaked) {
      ctx.restore();
      // faint distortion ring so you can still find the hull outline
      const b = this.roomBounds();
      ctx.strokeStyle = 'rgba(120,200,255,0.25)';
      ctx.lineWidth = 2;
      ctx.strokeRect(b.x - 10, b.y - 10, b.w + 20, b.h + 20);
    }
  }

  /** Empty room: tiled floor, subtle grid line, clear frame */
  _drawEmptyRoom(ctx, room) {
    const { x, y, w, h } = room;
    const tile = Assets.has('room_default') ? Assets.get('room_default') : null;
    if (tile) {
      const tW = 48, tH = 48;
      ctx.save();
      ctx.globalAlpha = 0.8;
      for (let tx = 0; tx < w; tx += tW) {
        for (let ty = 0; ty < h; ty += tH) {
          ctx.drawImage(tile, 0, 0, tile.width, tile.height,
                        x + tx, y + ty,
                        Math.min(tW, w - tx), Math.min(tH, h - ty));
        }
      }
      ctx.restore();
    } else {
      ctx.fillStyle = 'rgba(16,22,38,0.9)';
      ctx.fillRect(x, y, w, h);
    }

    // Frame — always visible so the module reads as a room
    ctx.strokeStyle = 'rgba(110,135,175,0.55)';
    ctx.lineWidth = 1.5;
    ctx.strokeRect(x + 0.5, y + 0.5, w - 1, h - 1);
  }

  /**
   * Guns sit ON the hull, along the top edge, spread across its width —
   * they used to float off the nose in a vertical stack, which read as a
   * detached UI widget rather than as part of the ship.
   */
  _drawWeaponMounts(ctx) {
    const b = this.roomBounds();
    const mounted = this.weapons.filter(Boolean);
    if (!mounted.length) return;

    const GW = 44, GAP = 10;
    const total = mounted.length * GW + (mounted.length - 1) * GAP;
    // Centre the row on the hull; if the hull is narrow, start at its edge.
    const startX = Math.round(b.x + Math.max(6, (b.w - total) / 2));
    const y = Math.round(b.y - 30);          // flush above the hull plating
    const dir = this.isPlayer ? 1 : -1;      // point at the enemy

    mounted.forEach((w, i) => {
      w.draw(ctx, startX + i * (GW + GAP), y, false, dir);
    });
  }

  _drawShield(ctx) {
    if (this._shieldAlpha <= 0 && this.shieldBars <= 0) return;
    const b   = this.roomBounds();
    const cx  = b.x + b.w / 2;
    const cy  = b.y + b.h / 2;
    const rx  = b.w * 0.68 + 20;
    const ry  = b.h * 0.68 + 20;
    const alpha = Math.max(this._shieldAlpha, this.shieldBars > 0 ? 0.3 : 0);

    ctx.save();
    ctx.globalAlpha = alpha;

    // Shield rings — layered strokes instead of shadowBlur (GPU-cheap)
    for (let ring = 0; ring < this.shieldBars; ring++) {
      // Soft outer glow: wide translucent stroke
      ctx.strokeStyle = 'rgba(26,140,255,0.18)';
      ctx.lineWidth   = 7;
      ctx.beginPath();
      ctx.ellipse(cx, cy, rx + ring * 8, ry + ring * 8, 0, 0, Math.PI * 2);
      ctx.stroke();
      // Crisp core line
      ctx.strokeStyle = '#4db8ff';
      ctx.lineWidth   = 2;
      ctx.beginPath();
      ctx.ellipse(cx, cy, rx + ring * 8, ry + ring * 8, 0, 0, Math.PI * 2);
      ctx.stroke();
    }
    // Hit flash ring
    if (this._shieldAlpha > 0.3) {
      ctx.strokeStyle = '#bfe8ff';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.ellipse(cx, cy, rx + 4, ry + 4, 0, 0, Math.PI * 2);
      ctx.stroke();
    }
    ctx.restore();
  }

  // ── Serialise ────────────────────────────────────────────

  serialise() {
    return {
      layoutKey: this.layoutKey,
      hull: this.hull,
      // Systems serialised BY INDEX — layouts are deterministic, and a
      // ship can carry several systems of the same type (weapon modules).
      // Save the DESIRED allocation, not the momentary one: a module
      // that happened to be shot out when we jumped would otherwise
      // come back permanently switched off after repairs.
      systems: this.systems.map(s => ({
        type: s.type, level: s.level, power: Math.max(s.power, s.desiredPower ?? 0),
      })),
      weapons: this.weapons.map(w => w ? { defKey: w.defKey, slot: w.slot } : null),
      weaponCargo: [...this.weaponCargo],
      cargo: this.cargo ? this.cargo.serialise() : null,
      extraModules: [...(this._extraModules ?? [])],
      reactor: this.reactor.level,
    };
  }

  static deserialise(data, isPlayer, wx, wy) {
    const ship = new Ship(data.layoutKey, isPlayer, wx, wy);
    ship.hull  = data.hull;
    ship.reactor.level = data.reactor;

    // Re-apply purchased modules IN ORDER before restoring systems so
    // the systems array lines up index-for-index with the save.
    (data.extraModules ?? []).forEach(e => {
      if (typeof e === 'string') ship.addModule(e);
      else ship.addModuleAt(e.type, e.roomId) || ship.addModule(e.type);
    });

    data.systems.forEach((sd, i) => {
      const sys = ship.systems[i];
      if (!sys || sys.type !== sd.type) return;   // layout mismatch guard
      if (sd.type === 'reactor') return;  // pips derive from module level
      sys.level = sd.level; sys.power = sd.power; sys.desiredPower = sd.power;
    });
    ship.weaponCargo = [...(data.weaponCargo ?? [])];

    // Saves written before the grid hold existed simply have no `cargo`
    // key — those ships keep the empty grid the constructor built.
    if (data.cargo && typeof CargoGrid !== 'undefined') {
      ship.cargo = CargoGrid.deserialise(data.cargo);
    }

    ship.weapons = [];
    data.weapons.forEach(wd => {
      if (wd) ship.installWeapon(wd.defKey, wd.slot);
    });

    return ship;
  }
}
