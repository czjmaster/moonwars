'use strict';
/* browser_test.js — runs the REAL game in a REAL browser.
 *
 * WHY THIS EXISTS: the Node harness stubs the canvas with a Proxy that
 * swallows every unknown call, so it can never catch "this only breaks
 * in a browser" problems. It missed a stale index.html that left
 * BaseScreen undefined — clicking ENTER BASE played a click sound and
 * did nothing at all, with the error only visible in the F12 console.
 *
 *   node tests/browser_test.js            (needs playwright)
 *
 * Skips cleanly (exit 0) if playwright is not installed, so it never
 * blocks a packaging run on a machine without it.
 */
const http = require('http');
const fs   = require('fs');
const path = require('path');

let chromium;
try { ({ chromium } = require('playwright')); }
catch (e) {
  console.log('playwright not installed — skipping the browser test.');
  process.exit(0);
}

const ROOT = path.join(__dirname, '..');
const PORT = 8097;
const MIME = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css' };

let failures = 0, passed = 0;
function ok(cond, msg) {
  if (cond) { passed++; console.log('  ok   ' + msg); }
  else { failures++; console.error('  FAIL ' + msg); }
}

const server = http.createServer((req, res) => {
  let p = decodeURIComponent(req.url.split('?')[0]);
  if (p === '/') p = '/index.html';
  const f = path.join(ROOT, p);
  if (!f.startsWith(ROOT) || !fs.existsSync(f)) { res.writeHead(404); return res.end('not found'); }
  res.writeHead(200, { 'Content-Type': MIME[path.extname(f)] || 'application/octet-stream' });
  res.end(fs.readFileSync(f));
});

/** Canvas is 1280x720; the page viewport matches so coords map 1:1. */
const CANVAS = { w: 1280, h: 720 };

(async () => {
  await new Promise(r => server.listen(PORT, r));
  const browser = await chromium.launch();

  async function session(label, { staleIndexHtml = false } = {}) {
    const page = await browser.newPage({ viewport: { width: CANVAS.w, height: CANVAS.h } });
    const errors = [];
    page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
    page.on('console', m => {
      if (m.type() === 'error' && !/ERR_TUNNEL|ERR_INTERNET/.test(m.text())) {
        errors.push('CONSOLE: ' + m.text());
      }
    });

    if (staleIndexHtml) {
      // Simulate a player who copied js/ but kept the OLD index.html:
      // strip the late-added module tags before the page ever parses.
      await page.route('**/index.html', async route => {
        let html = fs.readFileSync(path.join(ROOT, 'index.html'), 'utf8');
        html = html.replace(/\s*<script src="js\/base\.js"><\/script>/, '')
                   .replace(/\s*<script src="js\/basescreen\.js"><\/script>/, '')
                   .replace(/\s*<script src="js\/lootscreen\.js"><\/script>/, '');
        await route.fulfill({ status: 200, contentType: 'text/html', body: html });
      });
    }

    await page.goto(`http://localhost:${PORT}/index.html`);
    await page.waitForTimeout(3500);   // asset generation + loading screen
    const click = async (x, y) => { await page.mouse.click(x, y); await page.waitForTimeout(200); };
    return { page, errors, click, close: () => page.close() };
  }

  // ── 1. Normal boot: menu → base → every tab → launch ──
  console.log('\n— browser: full base flow —');
  {
    const s = await session('normal');
    await s.click(640, 360);                       // ENTER BASE (menu item 0)

    const state = await s.page.evaluate(() => ({
      base: typeof Base, screen: typeof BaseScreen,
      run: JSON.parse(localStorage.getItem('moonwars_save_v1') || '{}').base ? 'yes' : 'no',
    }));
    ok(state.base === 'object' && state.screen === 'object',
       'Base and BaseScreen are live in the page');

    for (const [name, x] of [['HANGAR', 102], ['CREW', 234], ['SUPPLY', 366], ['UPGRADES', 498]]) {
      await s.click(x, 107);
      ok(s.errors.length === 0, `${name} tab drew without a page error`);
    }

    await s.click(366, 107);       // SUPPLY
    await s.click(686, 190);       // + He2
    await s.click(742, 190);       // MAX He2
    await s.click(104, 246);       // BUY x1 (broke — must flash, not throw)
    ok(s.errors.length === 0, 'supply stepper and a refused purchase do not throw');

    await s.click(1030, 600);      // LAUNCH
    await s.page.waitForTimeout(600);
    const after = await s.page.evaluate(() =>
      JSON.parse(localStorage.getItem('moonwars_save_v1') || '{}'));
    ok(!!after.run, 'LAUNCH actually starts a run');
    ok(after.run && after.run.mission === 'patrol' && after.run.finalSector === 2,
       `the chosen contract is the one that starts (${after.run && after.run.mission})`);
    ok(after.base && after.base.ships.length === 0,
       'the hull is checked out of the hangar for the contract');
    ok(s.errors.length === 0, `no page errors during the whole flow${s.errors.length ? ': ' + s.errors[0] : ''}`);
    await s.close();
  }

  // ── 2. STALE index.html: the game must heal itself ──
  console.log('\n— browser: stale index.html (missing script tags) —');
  {
    const s = await session('stale', { staleIndexHtml: true });
    // Only count tags that came from the HTML — the self-healer injects
    // its own (marked data-autoloaded), which would mask the setup.
    const tags = await s.page.evaluate(() =>
      [...document.querySelectorAll('script[src]:not([data-autoloaded])')]
        .map(x => x.getAttribute('src')));
    ok(!tags.includes('js/base.js'),
       'test setup: index.html really is missing the new script tags');

    await s.click(640, 360);       // ENTER BASE
    await s.page.waitForTimeout(400);
    const healed = await s.page.evaluate(() => ({
      base: typeof Base, screen: typeof BaseScreen, loot: typeof LootScreen,
    }));
    ok(healed.base === 'object' && healed.screen === 'object' && healed.loot === 'object',
       'the game loaded the missing modules by itself');
    ok(s.errors.length === 0,
       `an out-of-date index.html no longer breaks the base screen${s.errors.length ? ': ' + s.errors[0] : ''}`);
    await s.close();
  }

  // ── 3. The salvage screen: real drag & drop on a real canvas ──
  console.log('\n— browser: boarding a derelict —');
  {
    const s = await session('loot');
    await s.click(640, 360);        // ENTER BASE
    await s.click(1030, 600);       // LAUNCH
    await s.page.waitForTimeout(700);

    // The CARGO button on the map is the player's way in — click it, so
    // the REAL game loop is the thing driving the screen from here on.
    await s.click(640, 82);
    await s.page.waitForTimeout(300);
    const isLoot = await s.page.evaluate(() => LootScreen.isOpen());
    ok(isLoot === true, 'the CARGO button on the map opens the hold');

    // Swap in a wreck + a known hold so the drag has something to move.
    await s.page.evaluate(() => {
      const wreck = window.__wreck = new CargoGrid(4, 3);
      wreck.add('module_crate');    // 2x3 — will not fit just anywhere
      wreck.add('data_core');
      const hold = window.__hold = new CargoGrid(6, 4);
      LootScreen.openLoot(wreck, hold, { seconds: 60, title: 'TEST SALVAGE' });
    });
    await s.page.waitForTimeout(200);

    const rects = await s.page.evaluate(() => ({
      wreck: LootScreen._gridRect('wreck'), hold: LootScreen._gridRect('hold'),
    }));
    ok(rects.wreck && rects.hold, 'both holds are laid out on screen');
    ok(rects.wreck.x + rects.wreck.w < rects.hold.x,
       'the derelict hold sits fully left of your own — they never overlap');

    await s.page.mouse.move(rects.wreck.x + 20, rects.wreck.y + 20);
    await s.page.mouse.down();
    await s.page.waitForTimeout(150);
    await s.page.mouse.move(rects.hold.x + 24, rects.hold.y + 24, { steps: 10 });
    await s.page.waitForTimeout(150);
    await s.page.mouse.up();
    await s.page.waitForTimeout(250);

    const moved = await s.page.evaluate(() => ({
      wreck: window.__wreck.items.length, hold: window.__hold.items.length,
      overflow: window.__hold.items.some(it =>
        it.x < 0 || it.y < 0 || it.x + it.w > window.__hold.cols || it.y + it.h > window.__hold.rows),
    }));
    ok(moved.hold === 1 && moved.wreck === 1,
       `dragging really moves a crate between holds (wreck ${moved.wreck}, hold ${moved.hold})`);
    ok(moved.overflow === false, 'and never lands it outside the grid');
    await s.page.screenshot({ path: '/tmp/shot_loot.png' });

    // TAKE ALL, then cast off, and we should be out of the loot state.
    await s.click(120 + 122 + 60, 588 + 17);
    const after = await s.page.evaluate(() => ({
      wreck: window.__wreck.items.length, hold: window.__hold.items.length }));
    ok(after.wreck === 0 && after.hold === 2, 'TAKE ALL clears the derelict hold');

    await s.click(1100, 588 + 17);   // DONE / CAST OFF
    await s.page.waitForTimeout(300);
    const closed = await s.page.evaluate(() => LootScreen.isOpen());
    ok(closed === false, 'DONE closes the salvage screen');
    ok(s.errors.length === 0,
       `no page errors on the salvage screen${s.errors.length ? ': ' + s.errors[0] : ''}`);
    await s.close();
  }

  await browser.close();
  server.close();
  console.log(`\n${passed} passed, ${failures} failed`);
  process.exit(failures ? 1 : 0);
})().catch(e => {
  console.error('BROWSER TEST CRASH:', e);
  server.close();
  process.exit(1);
});
