'use strict';
/* ============================================================
   MOON WARS — break_check.js  (update54, extended in 55-60)

   THE POINT: a test that does not fail on a broken build is worth
   nothing. This reverts each fix in update54, ONE AT A TIME, runs the
   suites, and reports any revert the tests slept through.

   It edits the real files and puts them back afterwards — including on
   a crash — so it must be run on a clean tree.

   Usage:  node tests/break_check.js
   ============================================================ */

const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');

const ROOT = path.join(__dirname, '..');
const F = (n) => path.join(ROOT, 'js', n);

/* Each entry: what was fixed, which file, and the exact text to swap
   back to the broken version. `from` must appear EXACTLY once. */
const BREAKS = [
  {
    name: '#4 doors — put them back under the commander',
    file: F('game.js'),
    from: "           room WALLS, so nothing else claims that pixel. */\n        d.toggle();",
    to:   "           room WALLS, so nothing else claims that pixel. */\n        if (_needCommander('the doors')) return true;\n        d.toggle();",
  },
  {
    name: '#1 karma colours painted with no commander in the chair',
    file: F('game.js'),
    from: "      const km  = _hasCommander() ? (c.result?.karma || 0) : 0;",
    to:   "      const km  = (c.result?.karma || 0);",
  },
  {
    name: '#2 air — breathing back to the old trickle',
    file: F('oxygen.js'),
    from: "  BREATHING:      0.04,",
    to:   "  BREATHING:      0.014,",
  },
  {
    name: '#2 air — a hull breach back to the old leak',
    file: F('oxygen.js'),
    from: "  DRAIN_BREACH:   0.16,",
    to:   "  DRAIN_BREACH:   0.07,",
  },
  {
    name: '#3 the red wash over a broken module, restored',
    file: F('systems.js'),
    from: "    if (this.ionDamage > 0) {\n      ctx.fillStyle = `rgba(77,184,255,",
    to:   "    if (this.damagedLevels > 0) {\n      const a = Math.min(0.5, this.damagedLevels / this.level * 0.5);\n      ctx.fillStyle = `rgba(255,45,68,${a})`;\n      ctx.fillRect(x, y, w, h);\n    }\n    if (this.ionDamage > 0) {\n      ctx.fillStyle = `rgba(77,184,255,",
  },
  {
    name: '#10 medbay reads operators again, so the cat is skipped',
    file: F('ship.js'),
    from: "      sys.crew = sys.roomId\n        ? (sys.type === 'medbay' ? this.medbayPatients(sys.roomId)\n                                 : this.crewOperating(sys.roomId))\n        : [];",
    to:   "      sys.crew = sys.roomId ? this.crewOperating(sys.roomId) : [];",
  },
  {
    name: '#10 the station clinic turns the cat away again',
    file: F('station.js'),
    from: "      c.isPlayer && !c.isVermin && !c.isSpider &&",
    to:   "      c.isPlayer && !c.isBeast &&",
  },
  {
    name: '#14 uninstall unbolts first and loses the gun',
    file: F('base.js'),
    from: "    const pending = [...(ship.weaponCargo ?? []), w.defKey];",
    to:   "    ship.uninstallWeapon(slot);\n    const pending = [...(ship.weaponCargo ?? []), w.defKey];",
  },
  {
    name: '#13 SELL sells on the first click again',
    file: F('basescreen.js'),
    from: "        _confirm = { act: 'doSellShip', arg,",
    to:   "        return _act('doSellShip', arg);\n        // eslint-disable-next-line no-unreachable\n        _confirm = { act: 'doSellShip', arg,",
  },
  {
    name: '#11 the hangar resets to the first hull',
    file: F('basescreen.js'),
    from: "      const want = b.lastShipKey;",
    to:   "      const want = null;",
  },
  {
    name: '#7 the base picks the first four hands for the player',
    file: F('basescreen.js'),
    from: "    if (remembered.length) remembered.forEach(id => _picked.add(id));\n    else if (!b.lastCrew) homeCrew.slice(0, 4).forEach(c => _picked.add(c.id));",
    to:   "    homeCrew.slice(0, 4).forEach(c => _picked.add(c.id));",
  },
  {
    name: '#8 the enemy badge hangs on the stale flag again',
    file: F('renderer.js'),
    from: "    if (foeAlive && typeof Commander !== 'undefined' && Commander.enemy && Commander.enemy()) {",
    to:   "    if (typeof Commander !== 'undefined' && Commander.enemy && Commander.enemy()) {",
  },
  {
    name: '#15 the boss chip goes back to the exit the boss never takes',
    file: F('game.js'),
    from: "    if (!_bossJustBeaten()) return null;",
    to:   "    if (true) return null;",
  },
  {
    name: '#6 recruits draw names with replacement again',
    file: F('base.js'),
    from: "    const c = new CrewMember({ name: pickUniqueName(CREW_NAMES, takenNames()) });",
    to:   "    const c = new CrewMember({});",
  },
  {
    name: '#6 rename lets two people share a name',
    file: F('base.js'),
    from: "    if (clash) return { ok: false, message: `${clean} is already somebody aboard.` };",
    to:   "    if (false) return { ok: false, message: 'unreachable' };",
  },
  {
    name: '#9 victory declared the moment their hull dies',
    file: F('combat.js'),
    from: "      if (!this.intrudersAboard()) {",
    to:   "      if (true) {",
  },
  {
    name: '#9 our hands bandage their boarders again',
    file: F('ship.js'),
    from: "      if (body.isPlayer !== this.isPlayer) return;\n      /* AND NOBODY KNEELS DOWN",
    to:   "      /* AND NOBODY KNEELS DOWN",
  },
  {
    name: '#9 first aid in the middle of a brawl again',
    file: F('ship.js'),
    from: "      if (this.roomContested(body.roomId)) return;\n      // Already lying in a powered medbay",
    to:   "      // Already lying in a powered medbay",
  },
  {
    name: '#5 pips drawn as one bar again',
    file: F('renderer.js'),
    from: "    for (let i = 0; i < n; i++) {\n      ctx.fillStyle = i < lit ? col : '#1a2030';\n      ctx.fillRect(x + i * (bw + gap), y, bw, h);\n    }",
    to:   "    ctx.fillStyle = col;\n    ctx.fillRect(x, y, w * (v / (max || 1)), h);",
  },
  {
    name: '#5 the orders panel back to its old width',
    file: F('renderer.js'),
    from: "  const ORDER_BW = 48, ORDER_BH = 18, ORDER_GAP = 4, ORDER_X = 14;",
    to:   "  const ORDER_BW = 58, ORDER_BH = 18, ORDER_GAP = 4, ORDER_X = 14;",
  },
  {
    name: '#12 gun strips dimmed by the cloak again',
    file: F('ship.js'),
    from: "    if (cloaked) ctx.globalAlpha = 1;\n    this._drawWeaponMounts(ctx);",
    to:   "    this._drawWeaponMounts(ctx);",
  },
  /* ── SUBTLER REVERTS ──────────────────────────────────────
     The obvious ones above were all caught on the second pass. These
     break the CORNERS of the same fixes — the places where a test can
     pass for the wrong reason. */
  {
    name: '#9 a rat in the hold counts as a boarding party',
    file: F('combat.js'),
    from: "    if (p.crew.some(c => c && c.alive && !c.isPlayer &&\n                         !c.isVermin && !c.isSpider)) return true;",
    to:   "    if (p.crew.some(c => c && c.alive && !c.isPlayer)) return true;",
  },
  {
    name: '#9/#10 the medbay treats people through a brawl',
    file: F('ship.js'),
    from: "  medbayPatients(roomId) {\n    if (this.roomContested(roomId)) return [];",
    to:   "  medbayPatients(roomId) {\n    if (false) return [];",
  },
  {
    name: '#15 the boss chip remembers THAT it paid, not WHICH boss',
    file: F('game.js'),
    from: "    if (!hull || _bossChipPaidFor === hull) return null;",
    to:   "    if (!hull || _bossChipPaidFor) return null;",
  },
  {
    name: '#5 a man on his last hit point shows an empty row',
    file: F('renderer.js'),
    from: "    const lit = v <= 0 ? 0 : Math.max(1, Math.round((v / (max || 1)) * n));",
    to:   "    const lit = Math.round((v / (max || 1)) * n);",
  },
  {
    name: '#6 rename accepts a blank name',
    file: F('base.js'),
    from: "    if (!clean) return { ok: false, message: 'A name cannot be empty.' };",
    to:   "    if (false) return { ok: false, message: 'unreachable' };",
  },
  {
    name: '#2 one pip of power no longer holds the air (refill left behind)',
    file: F('oxygen.js'),
    from: "  REFILL_PER_POWER: 0.06,",
    to:   "  REFILL_PER_POWER: 0.03,",
  },
  {
    name: '#13 CANCEL sells anyway',
    file: F('basescreen.js'),
    from: "      case 'confirmNo':  _confirm = null; break;",
    to:   "      case 'confirmNo':  { const c0 = _confirm; _confirm = null; if (c0) return _act(c0.act, c0.arg); break; }",
  },

  /* ── update55 ─────────────────────────────────────────── */
  {
    name: '#1 their crew counted only on their own deck',
    file: F('game.js'),
    from: "        _enemyCrewAliveCount() === 0) {\n      _derelictOffered = true;",
    to:   "        _enemyShip.crew.filter(c => !c.isPlayer && c.alive).length === 0) {\n      _derelictOffered = true;",
  },
  {
    name: '#1 the void does not count for the victory check either',
    file: F('combat.js'),
    from: "    return this.inFlightIntruders() > 0;",
    to:   "    return false;",
  },
  {
    name: '#2 TAB always jumps back to the top of the list',
    file: F('game.js'),
    from: "        UI.selectCrew(roster[at === -1 ? 0 : (at + 1) % roster.length]);",
    to:   "        UI.selectCrew(roster[0]);",
  },
  {
    name: '#2 TAB steps onto the dead',
    file: F('game.js'),
    from: "        .filter(c => c && c.isPlayer && c.alive && !c.isBeast);",
    to:   "        .filter(c => c && c.isPlayer && !c.isBeast);",
  },
  {
    name: '#4 an open hatch is cut through anyway',
    file: F('game.js'),
    from: "    if (waiting > 0 && !party.doorBroken &&\n        (party.entryDoor.mode === 'open' || party.entryDoor.openness >= 1)) {",
    to:   "    if (false) {",
  },
  {
    name: '#4 their commander does not seal the ship',
    file: F('game.js'),
    from: "    if (typeof Commander !== 'undefined' && Commander.enemy?.() && !_enemySealed) {",
    to:   "    if (false) {",
  },
  {
    name: '#5 every hostile back to one flat red',
    file: F('crew.js'),
    from: "    const corp = CORP_DEFS[this.race];\n    return corp ? corp.color : CrewMember.ENEMY_COLOR;",
    to:   "    return CrewMember.ENEMY_COLOR;",
  },
  {
    name: '#5 no side ring on hostiles',
    file: F('crew.js'),
    from: "    if (!this.isPlayer && !this.down && !this.isBeast) this.drawSideRing(ctx);",
    to:   "    /* no ring */",
  },
  {
    name: '#5 enemy crews stop scaling with the sector',
    file: F('crew.js'),
    from: "  const nSkills = s >= 3 ? 3 : 2;\n  const base    = s >= 5 ? 2 : 1;\n  const topUp   = s >= 5 ? 3 : (s >= 3 ? 2 : 1);",
    to:   "  const nSkills = 2;\n  const base    = 1;\n  const topUp   = 1;",
  },
  {
    name: '#6 Terra back to a hundred hit points',
    file: F('crew.js'),
    from: "    maxHp: 80,",
    to:   "    /* no maxHp */",
  },
  {
    name: '#6 an explicit maxHp no longer wins (old saves re-cut)',
    file: F('crew.js'),
    from: "    this.maxHp = cfg.maxHp ?? (CORP_DEFS[cfg.race]?.maxHp ?? 100);",
    to:   "    this.maxHp = (CORP_DEFS[cfg.race]?.maxHp ?? cfg.maxHp ?? 100);",
  },
  {
    name: '#7 RENAME back on top of the skill pips',
    file: F('basescreen.js'),
    from: "      _btn(ctx, x + 306, y + 56, 50, 10, 'RENAME',",
    to:   "      _btn(ctx, x + 300, y + 40, 54, 16, 'RENAME',",
  },
  {
    name: '#8 the barracks goes back to a bar',
    file: F('basescreen.js'),
    from: "        Renderer.drawPips(ctx, bx, by, bw, 7, h.hp, h.max, h.col);",
    to:   "        ctx.fillStyle = '#0a1018'; ctx.fillRect(bx, by, bw, 7);\n        ctx.fillStyle = h.col; ctx.fillRect(bx, by, Math.round(bw * h.pct), 7);",
  },

  /* ── update56 ─────────────────────────────────────────── */
  {
    name: '#He3 the ore is fuel after all',
    file: F('cargo.js'),
    from: "    w: 1, h: 1, value: 30, col: '#cfe4ff', kind: 'trade', tag: 'he3',",
    to:   "    w: 1, h: 1, value: 30, col: '#cfe4ff', kind: 'fuel', tag: 'he3',",
  },
  {
    name: '#He3 never drifts in a wreck',
    file: F('cargo.js'),
    from: "    ['he3_ore',        2 + Math.floor(sector / 2)],",
    to:   "    ['he3_ore',        0],",
  },
  {
    name: '#He3 counting by tag ignores damage',
    file: F('cargo.js'),
    from: "      (n, it) => n + (it.def.tag === tag && !it.damaged\n        ? (it.isStack ? it.qty : 1) : 0), 0);",
    to:   "      (n, it) => n + (it.def.tag === tag\n        ? (it.isStack ? it.qty : 1) : 0), 0);",
  },
  {
    name: '#He3 the port charges before checking the hold',
    file: F('station.js'),
    from: "    const probe = CargoGrid.deserialise(hold.serialise());\n    avail -= probe.addStack('he3_ore', avail);\n    if (avail <= 0) return { ok: false, message: 'No room in the hold for ore.' };",
    to:   "    /* no dry run */",
  },
  {
    name: '#He3 a port never stocks any',
    file: F('station.js'),
    from: "      he3: ri(0, 2 + Math.floor(s / 2)),",
    to:   "      he3: 0,",
  },
  {
    name: '#region a new run has no address',
    file: F('save.js'),
    from: "      region:    DEFAULT_REGION,",
    to:   "      region:    undefined,",
  },
  {
    name: '#region an old save is not migrated',
    file: F('save.js'),
    from: "    if (_data && _data.run && !_data.run.region) _data.run.region = DEFAULT_REGION;",
    to:   "    /* no migration */",
  },
  {
    name: '#region the map stops saying where it is',
    file: F('renderer.js'),
    from: "    ctx.fillText(regionLabel ? `${regionLabel} · SECTOR ${sectorMap.sector} MAP`\n                             : `SECTOR ${sectorMap.sector} MAP`, ox - 10, oy - 18);",
    to:   "    ctx.fillText(`SECTOR ${sectorMap.sector} MAP`, ox - 10, oy - 18);",
  },
  {
    name: '#gate the tab is gone',
    file: F('basescreen.js'),
    from: "'MEMORIAL', 'WANTED', 'GATE'];",
    to:   "'MEMORIAL', 'WANTED'];",
  },
  {
    name: '#gate the parts list stops reading the shelf',
    file: F('basescreen.js'),
    from: "    if (part.tag) return g.countOfTag ? g.countOfTag(part.tag) : 0;",
    to:   "    if (part.tag) return 0;",
  },
  {
    name: '#gate it grows a BUILD button',
    file: F('basescreen.js'),
    from: "    ctx.fillText('Construction is not available in this version — keep the parts.',",
    to:   "    _btn(ctx, px + pw / 2 - 60, py + ph - 44, 120, 24, 'BUILD', { act: 'buildGate' });\n    ctx.fillText('Construction is not available in this version — keep the parts.',",
  },
  {
    name: '#hangar a returning hull is refused again',
    file: F('base.js'),
    from: "    if (!returning && b.ships.length >= shipSlots()) return false;",
    to:   "    if (b.ships.length >= shipSlots()) return false;",
  },
  {
    /* This revert used to be a COMMENT — it changed nothing at all and
       was reported as a leak, which is exactly right: a revert that
       does not revert anything is worse than no revert. It now removes
       the cap from BUYING, which is the half that must stay. */
    name: '#hangar the cap stops applying to purchases too',
    file: F('base.js'),
    from: "    if (b.ships.length >= shipSlots()) {\n      return { ok: false, message: 'No free berth — buy another slot.' };\n    }",
    to:   "    if (false) {\n      return { ok: false, message: 'unreachable' };\n    }",
  },

  /* ── update57 ─────────────────────────────────────────── */
  {
    name: '#roster the barracks goes back to raw array order',
    file: F('base.js'),
    from: "    return [...b.barracks].sort((x, y) => (x.joined ?? 0) - (y.joined ?? 0));",
    to:   "    return [...b.barracks];",
  },
  {
    name: '#roster the ticket is dropped when a man flies',
    file: F('crew.js'),
    from: "      joined: this.joined,",
    to:   "      /* ticket not carried */",
  },
  {
    name: '#roster a returning hand is re-ticketed to the bottom',
    file: F('base.js'),
    from: "    if (typeof data.joined !== 'number') data.joined = b.joinedSeq++;",
    to:   "    data.joined = b.joinedSeq++;",
  },
  {
    name: '#continue the title screen keeps it',
    file: F('game.js'),
    from: "const MENU_ITEMS = ['ENTER BASE','OPTIONS'];",
    to:   "const MENU_ITEMS = ['ENTER BASE','CONTINUE','OPTIONS'];",
  },
  {
    name: '#continue the base does not offer it',
    file: F('basescreen.js'),
    from: "      _btn(ctx, W - 60 - 190, y + 4, 190, 30, 'CONTINUE',",
    to:   "      if (false) _btn(ctx, W - 60 - 190, y + 4, 190, 30, 'CONTINUE',",
  },
  {
    name: '#continue pressing it does nothing',
    file: F('basescreen.js'),
    from: "      case 'continue': return 'continue';",
    to:   "      case 'continue': return null;",
  },
  {
    name: '#launch a live contract is written off in silence',
    file: F('basescreen.js'),
    from: "        if (typeof Save !== 'undefined' && Save.hasShipInFlight && Save.hasShipInFlight()) {",
    to:   "        if (false) {",
  },
  {
    name: '#launch the warning fires on a blank run record too',
    file: F('save.js'),
    from: "    return !!(_data.run && _data.run.shipKey);",
    to:   "    return _data.run !== null;",
  },
  {
    name: '#launch the button stops warning on its face',
    file: F('basescreen.js'),
    from: "              : flying  ? 'a contract is still out there'",
    to:   "              : flying  ? 'contract begins'",
  },

  /* update57, corners */
  {
    name: '#roster tickets collide (one pass instead of two)',
    file: F('base.js'),
    from: "    list.forEach(c => {\n      if (typeof c.joined === 'number') next = Math.max(next, c.joined + 1);\n    });\n    list.forEach(c => { if (typeof c.joined !== 'number') c.joined = next++; });",
    to:   "    list.forEach(c => {\n      if (typeof c.joined !== 'number') c.joined = next++;\n      else next = Math.max(next, c.joined + 1);\n    });",
  },
  {
    name: '#continue offered with nothing in the air',
    file: F('basescreen.js'),
    from: "    const flying = (typeof Save !== 'undefined' && Save.hasShipInFlight\n                    && Save.hasShipInFlight());",
    to:   "    const flying = true;",
  },
  {
    name: '#launch the question stops saying what it costs',
    file: F('basescreen.js'),
    from: "                       detail: 'That ship, her crew and her whole hold are written off. '",
    to:   "                       detail: 'Go on then. '",
  },
  /* '#launch CANCEL launches anyway' was here and its anchor never
     matched anything — the script said ANCHOR MISSING, which is the
     right answer to a revert that reverts nothing. Dropped rather than
     re-aimed: CANCEL goes through the ONE `confirmNo` case, and
     '#13 CANCEL sells anyway' above already breaks exactly that. Two
     reverts of one line would just be two copies of one test. */

  /* ── update58 ─────────────────────────────────────────── */
  {
    name: '#ore the HUD readout is gone',
    file: F('renderer.js'),
    from: "      ctx.fillText(`He3 ${ore}`, resX + 248, 28);",
    to:   "      /* no readout */",
  },
  {
    name: '#ore the readout reads a mirror instead of the hold',
    file: F('renderer.js'),
    from: "      const ore = ship.cargo?.countOfTag ? ship.cargo.countOfTag('he3') : 0;",
    to:   "      const ore = run.he3 ?? 0;",
  },
  {
    name: '#ore the map stops showing it',
    file: F('renderer.js'),
    from: "        ctx.fillText(`He3 ${ore}`, ox + 540, oy - 18);",
    to:   "        /* no readout */",
  },
  {
    name: '#ore the pictogram is dropped',
    file: F('renderer.js'),
    from: "      drawStatIcon(ctx, 'ore', resX + 232, 18, 11, oreCol);",
    to:   "      /* no icon */",
  },
  {
    name: '#moons the table holds only Luna again',
    file: F('save.js'),
    from: "    europa:    { key: 'europa',    label: 'EUROPA',    body: 'Jupiter', locked: true,",
    to:   "    europa_disabled: { key: 'europa', label: 'EUROPA', body: 'Jupiter', locked: true,",
  },
  {
    name: '#moons every moon reads as open',
    file: F('save.js'),
    from: "  function regionUnlocked(key) { return unlockedRegions().includes(key); }",
    to:   "  function regionUnlocked(key) { return true; }",
  },
  {
    name: '#moons the Gate stops listing them',
    file: F('basescreen.js'),
    from: "      ctx.fillText('DESTINATIONS', dx, dy0);",
    to:   "      /* no list */",
  },
  {
    name: '#moons the contracts lose their address',
    file: F('basescreen.js'),
    from: "        ctx.fillText(`${reg.label} · CONTRACTS — more moons open with the Moon Gate`,",
    to:   "        ctx.fillText(`CONTRACTS`,",
  },

  /* ── update59 ─────────────────────────────────────────── */
  {
    name: '#ammo an empty rack refuses in silence again',
    file: F('combat.js'),
    from: "    const refusal = this.fireRefusal(weapon);\n    if (refusal) return refusal;",
    to:   "    if (!weapon || !weapon.armed) return;\n    if (this.state !== COMBAT_STATE.ACTIVE) return;\n    if (weapon.def.missileUse > 0) {\n      const h = this.playerShip?.cargo;\n      if (h && h.countOf('missiles') < weapon.def.missileUse) return;\n    }",
  },
  {
    name: '#ammo the refusal stops naming the ammo',
    file: F('combat.js'),
    from: "        return `${weapon.label} is out of ammo — it needs ${need} missile`",
    to:   "        return `cannot fire`;\n        return `${weapon.label} needs ${need} missile`",
  },
  {
    name: '#ammo every refusal says the same thing',
    file: F('combat.js'),
    from: "    if (!weapon.armed)    return `${weapon.label} is still charging`;",
    to:   "    if (!weapon.armed)    return `${weapon.label} is out of ammo`;",
  },
  {
    name: '#ammo an unmanned bay blocks the shot (invented rule)',
    file: F('combat.js'),
    from: "    if (!weapon.armed)    return `${weapon.label} is still charging`;",
    to:   "    if (weapon.unmanned)  return `${weapon.label} has nobody on it`;\n    if (!weapon.armed)    return `${weapon.label} is still charging`;",
  },
  {
    name: '#ammo the click stops passing the reason on',
    file: F('game.js'),
    from: "        const why = CombatManager.playerFire(_selectedWeapon, room);\n        if (why) UI.notify(why, 'warn');",
    to:   "        CombatManager.playerFire(_selectedWeapon, room);",
  },
  {
    name: '#ammo the card stops marking a dry gun',
    file: F('renderer.js'),
    from: "                 : dry        ? `${i+1}· NO AMMO!`",
    to:   "                 : dry        ? `${i+1}· ${w.label.slice(0,14)}`",
  },
  {
    /* The first version of this revert flipped the guard to `true &&`,
       which changes NOTHING: a gun with missileUse 0 fails the inner
       `have < 0` test anyway. A revert that reverts nothing is a revert
       that tests nothing — the script called it a leak and was right.
       This one marks every ammo-eating gun as dry whether or not the
       racks are full, which the section's "the mark goes away when the
       racks are filled" assertion catches. */
    name: '#ammo a loaded gun still reads NO AMMO',
    file: F('renderer.js'),
    from: "      const dry = (w.def.missileUse > 0) && (() => {\n        // `ship` is the hull this bar belongs to — _drawPowerBar's own\n        // argument. `state` is drawHUD's and does not reach in here.\n        const hold = ship?.cargo;\n        const have = hold ? hold.countOf('missiles') : (run?.missiles ?? 0);\n        return have < w.def.missileUse;\n      })();",
    to:   "      const dry = (w.def.missileUse > 0);",
  },

  {
    name: '#ammo an unready gun cannot be selected, in silence',
    file: F('game.js'),
    from: "        if (w && !w.armed) {\n          const why = CombatManager.fireRefusal(w);\n          if (why) UI.notify(why, 'warn');\n        }",
    to:   "        /* silent again */",
  },

  /* ── update60 ─────────────────────────────────────────── */
  /* '#bay a gun finds its module by position again' was here. It only
     added a dead duplicate method — a revert that reverts nothing, which
     the script reported as a leak and was right to. The real revert of
     that fix is the next entry, which removes the roomId lookup. */
  {
    name: '#bay the gun stops remembering its bay at all',
    file: F('ship.js'),
    from: "    if (w.roomId) {\n      const room = this.getRoomById(w.roomId);\n      if (room && room.type === 'weapons') return room;\n    }",
    to:   "    /* positional only */",
  },
  {
    name: '#bay installing a gun does not stamp the bay',
    file: F('ship.js'),
    from: "    w.roomId = this.weaponRooms[slot]?.id ?? null;",
    to:   "    w.roomId = null;",
  },
  {
    name: '#bay power comes from the positional module again',
    file: F('ship.js'),
    from: "      const sys = this.weaponRoomFor(w)?.system ?? null;",
    to:   "      const sys = this.weaponSystemFor(i);",
  },
  {
    name: '#bay manning comes from the positional module again',
    file: F('ship.js'),
    from: "      const room   = this.weaponRoomFor(w);",
    to:   "      const room   = this.weaponRooms[i];",
  },
  {
    name: '#bay the bay is not written to the save',
    file: F('ship.js'),
    from: "roomId: w.roomId ?? null } : null),",
    to:   "} : null),",
  },
  {
    name: '#bay a saved bay is ignored on load',
    file: F('ship.js'),
    from: "        if (wd.roomId && ship.weapons[wd.slot]) ship.weapons[wd.slot].roomId = wd.roomId;",
    to:   "        /* saved bay dropped */",
  },
  /* ── update61 — the world reads karma ─────────────────── */
  {
    name: '#61 ports stop charging a bad name a surcharge',
    file: F('station.js'),
    from: "  fuelCost(amt = 1)       { return Math.round(amt * FUEL_PRICE          * this._priceFactor()); }",
    to:   "  fuelCost(amt = 1)       { return Math.round(amt * FUEL_PRICE); }",
  },
  {
    name: '#61 hull plating stops charging a bad name a surcharge',
    file: F('station.js'),
    from: "  hullRepairCost(hp = 1)  { return Math.round(hp  * REPAIR_PRICES.hull * this._priceFactor()); }",
    to:   "  hullRepairCost(hp = 1)  { return Math.round(hp  * REPAIR_PRICES.hull); }",
  },
  {
    name: '#61 missiles stop charging a bad name a surcharge',
    file: F('station.js'),
    from: "  missileCost(amt = 1)    { return Math.round(amt * MISSILE_PRICE       * this._priceFactor()); }",
    to:   "  missileCost(amt = 1)    { return Math.round(amt * MISSILE_PRICE); }",
  },
  {
    name: '#61 ore stops charging a bad name a surcharge',
    file: F('station.js'),
    from: "    return Math.round(amt * base * (1.1 + this.sector * 0.05) * this._priceFactor());",
    to:   "    return Math.round(amt * base * (1.1 + this.sector * 0.05));",
  },
  {
    name: '#61 the till does its own sum again instead of asking the quote',
    file: F('station.js'),
    from: "    const cost = this.fuelCost(avail);",
    to:   "    const cost = avail * FUEL_PRICE;",
  },
  {
    name: '#61 a discount at the top of the scale (variant A by the back door)',
    file: F('commander.js'),
    from: "  { upTo: 100, surcharge: 0,    label: null },",
    to:   "  { upTo: 100, surcharge: -0.1, label: null },",
  },
  {
    name: '#61 the surcharge band edges slide by one',
    file: F('commander.js'),
    from: "  { upTo: 20,  surcharge: 0.25, label: 'NOTORIOUS' },",
    to:   "  { upTo: 19,  surcharge: 0.25, label: 'NOTORIOUS' },",
  },
  {
    name: '#61 karma outside 0-100 stops clamping',
    file: F('commander.js'),
    from: "    return (typeof k === 'number') ? Utils.clamp(k, 0, 100) : 50;",
    to:   "    return (typeof k === 'number') ? k : 50;",
  },
  {
    name: '#61 EVERY port refuses a shunned commander (strands the run)',
    file: F('commander.js'),
    from: "    return (Math.abs(Math.round(seed)) % 3) === 0;",
    to:   "    return true;",
  },
  {
    name: '#61 refusal rolls fresh each visit instead of sticking to the port',
    file: F('commander.js'),
    from: "  function portRefuses(seed = 0, karma = karmaNow()) {\n    if (karma > KARMA_SHUNNED) return false;",
    to:   "  function portRefuses(seed = 0, karma = karmaNow()) {\n    if (karma > KARMA_SHUNNED) return false;\n    return Math.random() < 0.34;",
  },
  {
    name: '#61 an ordinary commander gets turned away too',
    file: F('commander.js'),
    from: "const KARMA_SHUNNED = 10;",
    to:   "const KARMA_SHUNNED = 60;",
  },
  {
    name: '#61 a shut dock sells fuel anyway',
    file: F('station.js'),
    from: "  buyFuel(amount, run, ship = null) {\n    const closed = this.refusal();\n    if (closed) return { ok: false, message: closed };",
    to:   "  buyFuel(amount, run, ship = null) {",
  },
  {
    name: '#61 a shut dock still welds plating',
    file: F('station.js'),
    from: "  buyHullRepair(hp, ship) {\n    const closed = this.refusal();\n    if (closed) return { ok: false, message: closed };",
    to:   "  buyHullRepair(hp, ship) {",
  },
  {
    name: '#61 the shut dock gives no reason on screen',
    file: F('station.js'),
    from: "    return `${this.name} will not trade with you. `\n         + 'Word of what you did got here first.';",
    to:   "    return ' ';",
  },
  {
    name: '#61 the barracks go back to the flat list price',
    file: F('base.js'),
    from: "    const fee = recruitPrice();\n    if (cc() < fee) return { ok: false, message: `Need ${fee} CC.` };\n    spend(fee);",
    to:   "    if (cc() < PRICE.recruit) return { ok: false, message: `Need ${PRICE.recruit} CC.` };\n    spend(PRICE.recruit);",
  },
  {
    name: '#61 a good name stops buying a cheaper recruit',
    file: F('commander.js'),
    from: "    if (karma >= 80)            return 0.85;",
    to:   "    if (karma >= 80)            return 1;",
  },
  {
    name: '#61 a bad name stops costing more at the hiring hall',
    file: F('commander.js'),
    from: "    if (karma <= KARMA_SHUNNED) return 1.6;\n    if (karma <= 35)            return 1.25;",
    to:   "    if (karma <= KARMA_SHUNNED) return 1;\n    if (karma <= 35)            return 1;",
  },
  {
    name: '#61 the hiring hall stops caring who is asking',
    file: F('station.js'),
    from: "    const cCount = Utils.clamp(ri(0, 3) + interest, 0, 3);",
    to:   "    const cCount = ri(0, 3);",
  },
  {
    name: '#61 a port hand costs the same whoever hires him',
    file: F('station.js'),
    from: "    return Math.round(CREW_PRICE * f);",
    to:   "    return CREW_PRICE;",
  },
  {
    name: '#61 the dossier stops saying what the karma costs',
    file: F('renderer.js'),
    from: "      Commander.karmaWorldLines(karma).forEach(t =>",
    to:   "      [].forEach(t =>",
  },
  {
    name: '#61 the shut-dock warning is shown to everyone',
    file: F('commander.js'),
    from: "    if (karma <= KARMA_SHUNNED) out.push('Some ports will not trade with you at all');",
    to:   "    out.push('Some ports will not trade with you at all');",
  },
  {
    name: '#61 the shop stops showing the karma banner at all',
    /* Only a REAL browser sees this one — the shop is DOM. */
    browser: true,
    file: path.join(ROOT, 'js', 'ui.js'),
    from: "      _stationEl.insertBefore(banner, tabs);",
    to:   "      void banner;",
  },
  {
    name: '#61 a shut dock shows a normal empty shop instead of the reason',
    /* Only a REAL browser sees this one — the shop is DOM. */
    browser: true,
    file: path.join(ROOT, 'js', 'ui.js'),
    from: "      if (refused) { tabs.remove(); document.getElementById('station-content').remove(); return; }",
    to:   "",
  },
  {
    name: '#61 the repair button multiplies its own copy of the price again',
    /* Only a REAL browser sees this one — the shop is DOM. */
    browser: true,
    file: path.join(ROOT, 'js', 'ui.js'),
    from: "                                              : `+${n} HP — ${s.hullRepairCost(n)} CC`,",
    to:   "                                              : `+${n} HP — ${n * REPAIR_PRICES.hull} CC`,",
  },

  /* ── update62 — nobody strikes to a butcher ────────────── */
  {
    name: '#62 the surrender roll goes back to a flat coin, ignoring karma',
    file: F('combat.js'),
    from: "      ? Commander.surrenderChance() : 0.5;",
    to:   "      ? 0.5 : 0.5;",
  },
  {
    name: '#62 a butcher is offered surrenders again',
    file: F('commander.js'),
    from: "    if (karma <= KARMA_SHUNNED) return 0;\n    if (karma <= 35)            return 0.25;",
    to:   "    if (karma <= KARMA_SHUNNED) return 0.5;\n    if (karma <= 35)            return 0.5;",
  },
  {
    name: '#62 a good name stops buying more surrenders',
    file: F('commander.js'),
    from: "    if (karma >= 80)            return 0.75;",
    to:   "    if (karma >= 80)            return 0.5;",
  },
  {
    name: '#62 the no-quarter refusal is silent again',
    file: F('combat.js'),
    from: "          UI.notify('They will not surrender to you. They know what you do to prisoners.', 'alert');",
    to:   "          void 0;",
  },
  {
    name: '#62 the hull roll fires every frame instead of once',
    file: F('combat.js'),
    from: "      this._hullRolled = true;\n      if (this.noQuarter()) {",
    to:   "      if (this.noQuarter()) {",
  },
  {
    name: '#62 the beaten hull stops offering anything at all',
    file: F('combat.js'),
    from: "      } else if (Math.random() < this.surrenderOdds()) {\n        this._raiseSurrender();",
    to:   "      } else if (false) {\n        this._raiseSurrender();",
  },
  {
    name: '#62 a cleared deck is a hulk again, commander or not',
    file: F('game.js'),
    from: "      _event = (foeCap && !noQuarter) ? {",
    to:   "      _event = (false) ? {",
  },
  {
    name: '#62 sparing their commander is free — no karma for it',
    file: F('game.js'),
    from: "        { label: 'Let him go — board it and cast off',\n          result: { searchDerelict: true,\n                    karma: Commander?.KARMA?.HELP_AT_COST ?? 5 } },",
    to:   "        { label: 'Let him go — board it and cast off',\n          result: { searchDerelict: true } },",
  },
  {
    name: '#62 finishing a struck commander is not a helpless kill',
    file: F('game.js'),
    from: "          result: { destroyDerelict: true, takeBody: true,\n                    karma: Commander?.KARMA?.KILL_HELPLESS ?? -10 } });",
    to:   "          result: { destroyDerelict: true, takeBody: true } });",
  },
  {
    name: '#62 a butcher gets the surrender event anyway',
    file: F('game.js'),
    from: "      const noQuarter = CombatManager.noQuarter?.() ?? false;",
    to:   "      const noQuarter = false;",
  },
  {
    name: '#62 the commander who would rather burn says nothing',
    file: F('game.js'),
    from: "        UI.notify(`${foeCap.name} would rather burn with his ship than be your prisoner.`, 'alert');",
    to:   "        void 0;",
  },
  {
    name: '#62 the struck commander is nameless in the text',
    file: F('game.js'),
    from: "        text: `Nobody aboard is left standing. ${foeCap.name} puts down his sidearm `",
    to:   "        text: `Nobody aboard is left standing. Somebody puts down his sidearm `",
  },
  {
    name: '#62 the dossier stops mentioning surrenders',
    file: F('commander.js'),
    from: "    out.push(sc === 0 ? 'Beaten crews fight you to the last man — they never surrender'",
    to:   "    if (false) out.push(sc === 0 ? 'Beaten crews fight you to the last man — they never surrender'",
  },

  /* ── update63 — the brig ───────────────────────────────── */
  {
    name: '#63 cells stop following the module level',
    file: F('ship.js'),
    from: "    return b ? Math.max(0, b.workingLevels) : 0;",
    to:   "    return b ? 1 : 0;",
  },
  {
    name: '#63 the brig overfills instead of refusing',
    file: F('ship.js'),
    from: "    if (!rec || this.freeCells() <= 0) return false;",
    to:   "    if (!rec) return false;",
  },
  {
    name: '#63 a hull with no brig can still hold men',
    file: F('ship.js'),
    from: "  brigCapacity() {\n    const b = this.getSystem('brig');",
    to:   "  brigCapacity() {\n    return 3;\n    // eslint-disable-next-line no-unreachable\n    const b = this.getSystem('brig');",
  },
  {
    name: '#63 an unpowered brig holds them anyway',
    file: F('ship.js'),
    from: "    const held = !!brig && !brig.isDisabled();",
    to:   "    const held = true;",
  },
  {
    name: '#63 restoring power no longer resets the lock',
    file: F('ship.js'),
    from: "      this.prisoners.forEach(p => { p.escapeT = 0; p.warned = false; });\n      return;",
    to:   "      return;",
  },
  {
    name: '#63 nobody is warned before a prisoner walks',
    file: F('ship.js'),
    from: "          UI.notify(`${p.name} is working the cell door — get the brig powered!`, 'alert');",
    to:   "          void 0;",
  },
  {
    name: '#63 the warning repeats every frame',
    file: F('ship.js'),
    from: "        p.warned = true;",
    to:   "        p.warned = false;",
  },
  {
    name: '#63 an escaped prisoner leaves in silence',
    file: F('ship.js'),
    from: "      UI.notify(poster",
    to:   "      if (false) UI.notify(poster",
  },
  {
    name: '#63 the escape clock never runs out',
    file: F('ship.js'),
    from: "      if (p.escapeT >= Ship.ESCAPE_SECONDS) gone.push(p);",
    to:   "      if (false) gone.push(p);",
  },
  {
    name: '#63 the cells are not written to the save',
    file: F('ship.js'),
    from: "      prisoners: this.prisoners.map(p => ({ ...p })),",
    to:   "      prisoners: [],",
  },
  {
    name: '#63 a loaded prisoner comes back mid-escape',
    file: F('ship.js'),
    from: "      id: p.id, name: p.name, bounty: p.bounty ?? 0, escapeT: 0, warned: false,",
    to:   "      id: p.id, name: p.name, bounty: p.bounty ?? 0, escapeT: p.escapeT, warned: false,",
  },
  {
    name: '#63 the loaded prisoner loses his price',
    file: F('ship.js'),
    from: "    ship.prisoners = (data.prisoners ?? []).map(p => ({",
    to:   "    ship.prisoners = (data.prisoners ?? []).map(p => ({ ...p, bounty: 0 })).map(p => ({",
  },
  {
    name: '#63 the cell door is offered with nowhere to put him',
    file: F('game.js'),
    from: "      if (foeCap && foeCap.wantedId && !noQuarter && cells > 0) {",
    to:   "      if (foeCap && foeCap.wantedId && !noQuarter) {",
  },
  {
    name: '#63 the body price stops being half the living one',
    file: F('game.js'),
    from: "        { label: `Finish him off — his body is worth ${Math.round(bounty / 2)} CC`,",
    to:   "        { label: `Finish him off — his body is worth 30 CC`,",
  },
  {
    name: '#63 accepting no longer locks him up',
    file: F('game.js'),
    from: "      if (result.capture) _lockUpCommander();",
    to:   "      void 0;",
  },
  {
    name: '#63 the prisoner is locked up under the wrong price',
    file: F('game.js'),
    from: "      id: cap.id, name: cap.name, bounty: _commanderBounty(cap),",
    to:   "      id: cap.id, name: cap.name, bounty: 30,",
  },
  {
    name: '#63 the bag stops carrying the man\'s own price',
    file: F('cargo.js'),
    from: "    if (this.def.tag === 'body' && this.meta && this.meta.bounty > 0) v = this.meta.bounty;",
    to:   "    void 0;",
  },
  {
    name: '#63 a bagged body shrinks to one cell',
    file: F('cargo.js'),
    from: "    w: 2, h: 1, value: 60, col: '#8a94a8', kind: 'trade', tag: 'body',",
    to:   "    w: 1, h: 1, value: 60, col: '#8a94a8', kind: 'trade', tag: 'body',",
  },
  {
    name: '#63 the dock stops paying for prisoners',
    file: F('base.js'),
    from: "        if (paid > 0) earn(paid);\n        report.bounty += paid;\n        report.prisoners++;",
    to:   "        report.prisoners++;",
  },
  {
    name: '#63 the handed-over prisoner stays on the hull (paid twice)',
    file: F('base.js'),
    from: "      d.prisoners = [];",
    to:   "      void 0;",
  },
  {
    name: '#63 the claimed body stays in the hold (paid twice)',
    file: F('base.js'),
    from: "        hold.items = hold.items.filter(it => !bags.includes(it));",
    to:   "        void 0;",
  },
  {
    name: '#63 the dock stops paying for bodies',
    file: F('base.js'),
    from: "          const paid = Math.max(0, Math.round(it.meta?.bounty ?? CARGO_ITEMS[it.defKey]?.value ?? 0));",
    to:   "          const paid = 0;",
  },

  /* ── update64 — the wanted list ────────────────────────── */
  {
    name: '#64 an old save gets no wanted list at all',
    file: F('save.js'),
    from: "    _data.wanted = [makeWanted(1)];",
    to:   "    _data.wanted = [];",
  },
  {
    name: '#64 an emptied board refills itself on every load',
    file: F('save.js'),
    from: "    if (Array.isArray(_data.wanted)) return;",
    to:   "    if (Array.isArray(_data.wanted) && _data.wanted.length) return;",
  },
  {
    name: '#64 the board grows without a ceiling',
    file: F('save.js'),
    from: "    if (_data.wanted.length >= WANTED_MAX) return null;\n    const w = makeWanted(sector);",
    to:   "    if (false) return null;\n    const w = makeWanted(sector);",
  },
  {
    name: '#64 two posters can carry the same name',
    file: F('save.js'),
    from: "    const pool  = PIRATE_NAMES.filter(n => !taken.has(n));",
    to:   "    const pool  = PIRATE_NAMES;",
  },
  {
    name: '#64 the bounty stops following the level',
    file: F('save.js'),
    from: "  function wantedBounty(level) { return Math.round(80 + level * 20); }",
    to:   "  function wantedBounty(level) { return 100; }",
  },
  {
    name: '#64 wantedById hands back a COPY, so the base and the fight drift',
    file: F('save.js'),
    from: "  function wantedById(id) { return (_data?.wanted ?? []).find(w => w.id === id) || null; }",
    to:   "  function wantedById(id) { const w = (_data?.wanted ?? []).find(x => x.id === id); return w ? { ...w } : null; }",
  },
  {
    name: '#64 a delivered man stays on the board',
    file: F('save.js'),
    from: "    _data.wanted.splice(i, 1);",
    to:   "    void 0;",
  },
  {
    name: '#64 a sighting no longer records where',
    file: F('save.js'),
    from: "    w.state  = 'sighted';",
    to:   "    void 0;",
  },
  {
    name: '#64 no fight ever seats a wanted man',
    file: F('game.js'),
    from: "      if (boss && !BossManager.isActive) boss = _seatWantedPirate(boss, sec);",
    to:   "      void 0;",
  },
  {
    name: '#64 the seated pirate is a COPY, not the poster',
    file: F('game.js'),
    from: "    cap.wantedId = w.id;",
    to:   "    cap.wantedId = null;",
  },
  {
    name: '#64 meeting him does not mark the board',
    file: F('game.js'),
    from: "    Save.markSighted(w.id);",
    to:   "    void 0;",
  },
  {
    name: '#64 the fight prices him off his rank, not off the poster',
    file: F('game.js'),
    from: "    if (cap.bounty > 0) return Math.round(cap.bounty);",
    to:   "    void 0;",
  },
  {
    name: '#64 a delivered man is hunted again',
    file: F('game.js'),
    from: "    return (id && typeof Save !== 'undefined' && Save.wantedById)\n      ? Save.wantedById(id) : null;",
    to:   "    return (id && typeof Save !== 'undefined' && Save.wantedById)\n      ? (Save.wantedById(id) || { id, name: 'Ghost', bounty: 1, escapes: 0, level: 1 }) : null;",
  },
  {
    name: '#64 the prisoner forgets which poster he came off',
    file: F('game.js'),
    from: "      wantedId: cap.wantedId ?? null,\n    });",
    to:   "      wantedId: null,\n    });",
  },
  {
    name: '#64 the body bag forgets which poster it came off',
    file: F('game.js'),
    from: "        wantedId: cap.wantedId ?? null });",
    to:   "        wantedId: null });",
  },
  {
    name: '#64 the cell record drops the poster id',
    file: F('ship.js'),
    from: "      wantedId: rec.wantedId ?? null,",
    to:   "      wantedId: null,",
  },
  {
    name: '#64 handing a prisoner over does not close the case',
    file: F('base.js'),
    from: "        if (p.wantedId) { Save.deliverWanted(p.wantedId, paid); report.wanted++; }",
    to:   "        void 0;",
  },
  {
    name: '#64 delivering a body does not close the case',
    file: F('base.js'),
    from: "          if (it.meta?.wantedId) {\n            Save.deliverWanted(it.meta.wantedId, paid); report.wanted++;\n          }",
    to:   "          void 0;",
  },
  {
    name: '#64 the WANTED tab is gone from the base',
    file: F('basescreen.js'),
    from: "'MEMORIAL', 'WANTED', 'GATE'];",
    to:   "'MEMORIAL', 'GATE'];",
  },
  {
    name: '#64 the base loses its wanted board',
    file: F('basescreen.js'),
    from: "    if (_tab === 'WANTED')   _drawWanted(ctx, px, py, pw, ph);",
    to:   "    void 0;",
  },
  {
    name: '#64 the board caches the list instead of reading it',
    file: F('basescreen.js'),
    from: "    const list = (typeof Save !== 'undefined' && Save.wanted) ? Save.wanted() : [];",
    to:   "    const list = (_wantedCache = _wantedCache || ((typeof Save !== 'undefined' && Save.wanted) ? Save.wanted() : []));",
  },
  {
    name: '#64 an empty board draws nothing instead of explaining itself',
    file: F('basescreen.js'),
    from: "      ctx.fillText('The board is empty. Finish a contract and the yard will find somebody.',",
    to:   "      ctx.fillText('',",
  },
  {
    name: '#64 the board stops showing the price for a body',
    file: F('basescreen.js'),
    from: "      ctx.fillText(`${Math.round(w.bounty / 2)} CC for the body`, px + pw - 34, y + 46);",
    to:   "      void 0;",
  },
  {
    name: '#64 the board hides whether he has been sighted',
    file: F('basescreen.js'),
    from: "      const seen = w.state === 'sighted'\n        ? (where ? `last seen: ${where}` : 'sighted')\n        : 'no sighting yet';",
    to:   "      const seen = 'no sighting yet';",
  },
  {
    name: '#64 the brig goes back to being hard to find',
    file: F('station.js'),
    from: "        ...(r() < 0.60 ? [{ type: 'brig',       cost: 80 + this.sector * 10, sold: false }] : []),",
    to:   "        ...(r() < 0.05 ? [{ type: 'brig',       cost: 80 + this.sector * 10, sold: false }] : []),",
  },

  /* ── update65 — bodies: the player decides ─────────────── */
  {
    name: '#65 an open hatch throws the dead out again, unasked',
    file: F('ship.js'),
    from: "            if (b.dead) return b.bodyOrder === 'vent';",
    to:   "            if (b.dead) return true;",
  },
  {
    name: '#65 the corpse dispatch ignores the order again',
    file: F('ship.js'),
    from: "        if (body.dead && body.bodyOrder === 'vent' && !body.carriedBy &&",
    to:   "        if (body.dead && body.decaying && !body.carriedBy &&",
  },
  {
    name: '#65 the wounded stop being collected on their own',
    file: F('ship.js'),
    from: "            // wounded: pointless to carry if there's no medbay at all\n            return !!medRoom;",
    to:   "            return b.bodyOrder === 'treat' && !!medRoom;",
  },
  {
    name: '#65 TREAT is offered for a corpse',
    file: F('ship.js'),
    from: "      if (body.dead) return 'he is dead';",
    to:   "      if (false) return 'he is dead';",
  },
  {
    name: '#65 TREAT is offered with no medbay aboard',
    file: F('ship.js'),
    from: "      if (!med) return 'no medbay aboard';",
    to:   "      if (false) return 'no medbay aboard';",
  },
  {
    name: '#65 VENT is offered on a hull with no airlock at all',
    file: F('ship.js'),
    from: "      if (!this.doors.some(d => d.isAirlock)) return 'no airlock on this hull';",
    to:   "      if (false) return 'no airlock on this hull';",
  },
  {
    name: '#65 BAG happens with nobody free to do it',
    file: F('ship.js'),
    from: "      if (!hands) return 'nobody free to do it';",
    to:   "      if (false) return 'nobody free to do it';",
  },
  {
    name: '#65 BAG is accepted into a full hold',
    file: F('ship.js'),
    from: "      if (!probe.add(Ship.bagKeyFor(body))) return 'no room in the hold';",
    to:   "      if (false) return 'no room in the hold';",
  },
  {
    name: '#65 the order stops giving the menu\'s reason',
    file: F('ship.js'),
    from: "    if (why) return { ok: false, message: `Cannot ${act}: ${why}.` };",
    to:   "    if (why) return { ok: false, message: 'No.' };",
  },
  {
    name: '#65 a cat needs two cells like a man',
    file: F('ship.js'),
    from: "  static bagKeyFor(body) { return body && body.isPet ? 'pet_bag' : 'body_bag'; }",
    to:   "  static bagKeyFor(body) { return 'body_bag'; }",
  },
  {
    name: '#65 the bagged man is left lying on the deck',
    file: F('ship.js'),
    from: "    this.crew = this.crew.filter(c => c !== body);",
    to:   "    void 0;",
  },
  {
    name: '#65 the bag forgets whose it is',
    file: F('ship.js'),
    from: "      crewBody: true,",
    to:   "      crewBody: false,",
  },
  {
    name: '#65 venting your own dead is free',
    file: F('ship.js'),
    from: "        Commander.shift(Commander.active(), Ship.VENT_KARMA);",
    to:   "        void 0;",
  },
  {
    name: '#65 a man who walked out on his own costs karma too',
    file: F('ship.js'),
    from: "      if (this.isPlayer && c.dead && c.bodyOrder === 'vent' &&",
    to:   "      if (this.isPlayer && c.dead &&",
  },
  {
    name: '#65 a crew bag is priced like merchandise',
    file: F('cargo.js'),
    from: "    if (this.meta && this.meta.crewBody) return 0;",
    to:   "    void 0;",
  },
  {
    name: '#65 the pet bag grows to two cells',
    file: F('cargo.js'),
    from: "    w: 1, h: 1, value: 30, col: '#8a94a8', kind: 'trade', tag: 'body',",
    to:   "    w: 2, h: 1, value: 30, col: '#8a94a8', kind: 'trade', tag: 'body',",
  },
  {
    name: '#65 the dock stops burying your own and sells them instead',
    file: F('base.js'),
    from: "          if (it.meta?.crewBody) {",
    to:   "          if (false) {",
  },
  {
    name: '#65 the burial pays no karma',
    file: F('base.js'),
    from: "              Commander.shift(Commander.active(), Ship.BURIAL_KARMA);",
    to:   "              void 0;",
  },
  {
    name: '#65 the memorial is never told he came home',
    file: F('base.js'),
    from: "            Save.markBuried?.(it.meta.crewId, it.meta.name);",
    to:   "            void 0;",
  },
  {
    name: '#65 the mark matches nobody at all',
    file: F('save.js'),
    from: "    const rec = list.find(g => g && ((id && g.id === id) || (!id && name && g.name === name)))\n             || list.find(g => g && name && g.name === name);",
    to:   "    const rec = null;",
  },
  {
    name: '#65 a man can be buried twice',
    file: F('save.js'),
    from: "    if (!rec || rec.buried) return false;",
    to:   "    if (!rec) return false;",
  },
  {
    name: '#65 the memorial stops saying who came home',
    file: F('basescreen.js'),
    from: "    ctx.fillText(g.buried ? 'brought home and buried' : 'no body recovered',",
    to:   "    ctx.fillText('',",
  },
  {
    name: '#65 the menu rows overlap each other',
    file: F('renderer.js'),
    from: "        y: py + BODY_MENU_PAD + i * BODY_MENU_ROW,",
    to:   "        y: py + BODY_MENU_PAD + i * 4,",
  },
  {
    name: '#65 the menu opens off the edge of the screen',
    file: F('renderer.js'),
    from: "    const px = Utils.clamp(x - BODY_MENU_W / 2, 4, _W - BODY_MENU_W - 4);\n    const py = Utils.clamp(y + BODY_MENU_DROP, 4, _H - h - 4);",
    to:   "    const px = x - BODY_MENU_W / 2;\n    const py = y + BODY_MENU_DROP;",
  },
  {
    name: '#65 the drawing keeps its own copy of the row geometry',
    file: F('renderer.js'),
    from: "      ctx.fillText(LABEL[it.act], it.x + 4, it.y + 10);",
    to:   "      ctx.fillText(LABEL[it.act], it.x + 4, it.y + 40);",
  },

  /* ── update66 — the hunt on the map, and four rations ──── */
  {
    name: '#66 no sector ever carries a poster',
    file: F('map.js'),
    from: "    this._seatWanted();",
    to:   "    void 0;",
  },
  {
    name: '#66 EVERY sector carries one',
    file: F('map.js'),
    from: "    if (this._rng() >= SectorMap.WANTED_ON_MAP) return;",
    to:   "    if (false) return;",
  },
  {
    name: '#66 the poster moves on every reload (loose Math.random)',
    file: F('map.js'),
    from: "    const node = this._rngPick(fights);",
    to:   "    const node = Utils.pick(fights);",
  },
  {
    name: '#66 the poster can land on the boss or the first hop',
    file: F('map.js'),
    from: "      n.type === 'combat' && !n.isBoss && !n.isExit && n.col > 1);",
    to:   "      n.type === 'combat');",
  },
  {
    name: '#66 the node keeps its own copy of the pirate',
    file: F('map.js'),
    from: "    return Save.wantedById(this.wantedId);",
    to:   "    return { name: 'Ghost', bounty: 1 };",
  },
  {
    name: '#66 a wanted node looks like every other fight',
    file: F('map.js'),
    from: "  get label() { return this.wanted ? this.wanted.name : this.def.label; }",
    to:   "  get label() { return this.def.label; }",
  },
  {
    name: '#66 the wanted node loses its marker',
    file: F('map.js'),
    from: "  get icon()  { return this.wanted ? '☠' : this.def.icon; }",
    to:   "  get icon()  { return this.def.icon; }",
  },
  {
    name: '#66 the wanted node loses its colour',
    file: F('map.js'),
    from: "  get color() { return this.wanted ? '#ff9a4d' : this.def.color; }",
    to:   "  get color() { return this.def.color; }",
  },
  {
    name: '#66 the fight rolls for a wanted man again instead of reading the node',
    file: F('game.js'),
    from: "    const w = _wantedOnThisNode();\n    if (!w) return cap;",
    to:   "    const w = Math.random() < 0.35 ? Utils.pick(Save.wanted()) : null;\n    if (!w) return cap;",
  },
  {
    name: '#66 his node may still roll no commander at all',
    file: F('game.js'),
    from: "      const chance = (BossManager.isActive || posted)\n        ? 1 : Math.min(0.55, 0.12 + sec * 0.12);",
    to:   "      const chance = BossManager.isActive ? 1 : Math.min(0.55, 0.12 + sec * 0.12);",
  },
  {
    name: '#66 the sighting stops recording how deep',
    file: F('save.js'),
    from: "    w.sector = _data?.run?.sector ?? w.sector ?? null;",
    to:   "    void 0;",
  },
  {
    name: '#66 the standard ration quietly changes value',
    file: F('cargo.js'),
    from: "    stackMax: 5, unitValue: 8, hunger: 50, meat: true,",
    to:   "    stackMax: 5, unitValue: 8, hunger: 25, meat: true,",
  },
  {
    name: '#66 a field meal shrinks to one cell',
    file: F('cargo.js'),
    from: "    w: 2, h: 1, col: '#c08f5a', kind: 'food', tag: 'food',",
    to:   "    w: 1, h: 1, col: '#c08f5a', kind: 'food', tag: 'food',",
  },
  {
    name: '#66 greens are meat after all',
    file: F('cargo.js'),
    from: "    stackMax: 5, unitValue: 12, hunger: 50, meat: false,",
    to:   "    stackMax: 5, unitValue: 12, hunger: 50, meat: true,",
  },
  {
    name: '#66 every meal feeds the same again (the old flat table)',
    file: F('ship.js'),
    from: "                        : { hunger: meal.def?.hunger ?? 50, hp: 4 };",
    to:   "                        : { hunger: 50, hp: 4 };",
  },
  {
    name: '#66 the cat eats the greens',
    file: F('ship.js'),
    from: "    if (who.isPet && item.def.meat === false) return false;",
    to:   "    if (false) return false;",
  },
  {
    name: '#66 a hungry mouth helps itself to what it will not touch',
    file: F('ship.js'),
    from: "      it.def?.tag === 'food' && !it.damaged && this.willEat(who, it));\n    const meal = egg || ration;",
    to:   "      it.def?.tag === 'food' && !it.damaged);\n    const meal = egg || ration;",
  },
  {
    name: '#66 FEED is offered to a man who is not hungry',
    file: F('ship.js'),
    from: "    if ((who.hunger ?? 100) >= 100) return `${who.name} is not hungry`;",
    to:   "    if (false) return `${who.name} is not hungry`;",
  },
  {
    name: '#66 FEED is offered to a man mid-meal',
    file: F('ship.js'),
    from: "    if (who._eatT > 0) return `${who.name} is already eating`;",
    to:   "    if (false) return `${who.name} is already eating`;",
  },
  {
    name: '#66 the order stops giving the menu\'s reason for FEED',
    file: F('ship.js'),
    from: "    const why = this.feedRefusal(who, item);\n    if (why) return { ok: false, message: why };",
    to:   "    const why = this.feedRefusal(who, item);\n    if (why) return { ok: false, message: 'No.' };",
  },
  {
    name: '#66 the menu offers FEED to a corpse and TREAT to the living',
    file: F('game.js'),
    from: "    return (person.dead || person.down) ? ['treat', 'vent', 'bag'] : ['feed'];",
    to:   "    return ['treat', 'vent', 'bag'];",
  },
  {
    name: '#66 a port can stock nothing to eat at all',
    file: F('station.js'),
    from: "        if (!Object.keys(out).length) out.ration_pack = ri(2, 6 + s);",
    to:   "        void 0;",
  },
  {
    name: '#66 every port stocks all four kinds',
    file: F('station.js'),
    from: "        KINDS.forEach(k => { if (r() < 0.55) out[k] = ri(2, 8 + s); });",
    to:   "        KINDS.forEach(k => { out[k] = ri(2, 8 + s); });",
  },
  {
    name: '#66 the meal counter charges before checking the hold',
    file: F('station.js'),
    from: "    avail -= probe.addStack(key, avail);\n    if (avail <= 0) return { ok: false, message: 'No room in the hold.' };",
    to:   "    if (false) return { ok: false, message: 'No room in the hold.' };",
  },
  {
    name: '#66 the meal counter sells anything at all',
    file: F('station.js'),
    from: "    if (!def || def.tag !== 'food') return { ok: false, message: 'Not food.' };",
    to:   "    if (!def) return { ok: false, message: 'Not food.' };",
  },

  /* ── update67 — debts paid ─────────────────────────────── */
  {
    name: '#67 the hangar reads the LAYOUT instead of the hull',
    file: F('basescreen.js'),
    from: "  function _entryLevels(entry) {\n    const sh = _entryShip(entry);",
    to:   "  function _entryLevels(entry) {\n    const sh = new Ship(entry.key, true, 0, 0);",
  },
  {
    name: '#67 the module strip stops drawing the modules',
    file: F('basescreen.js'),
    from: "    const mods = all.filter(m => m.type !== 'reactor');",
    to:   "    const mods = all.filter(m => m.type !== 'reactor').slice(0, 3);",
  },
  {
    name: '#67 an installed module is dropped from the save',
    file: F('ship.js'),
    from: "      extraModules: [...(this._extraModules ?? [])],",
    to:   "      extraModules: [],",
  },
  {
    name: '#67 prisoners stop eating',
    file: F('ship.js'),
    from: "        if ((meal.qty ?? 0) > 1) meal.qty--; else this.cargo.remove(meal);\n        out.fed++;",
    to:   "        out.fed++;",
  },
  {
    name: '#67 a starving prisoner just stays in his cell',
    file: F('ship.js'),
    from: "      this.prisoners.splice(this.prisoners.indexOf(p), 1);\n      out.starved.push(p.name);",
    to:   "      out.starved.push(p.name);",
  },
  {
    name: '#67 a starved prisoner leaves no body',
    file: F('ship.js'),
    from: "      const bag = this.cargo?.add?.('body_bag', {\n        name: p.name, bounty: Math.round((p.bounty ?? 0) / 2),",
    to:   "      const bag = null && this.cargo?.add?.('body_bag', {\n        name: p.name, bounty: Math.round((p.bounty ?? 0) / 2),",
  },
  {
    name: '#67 a starved prisoner is worth full price as a body',
    file: F('ship.js'),
    from: "        name: p.name, bounty: Math.round((p.bounty ?? 0) / 2),\n        wantedId: p.wantedId ?? null,",
    to:   "        name: p.name, bounty: (p.bounty ?? 0),\n        wantedId: p.wantedId ?? null,",
  },
  {
    name: '#67 the jump stops feeding the brig',
    file: F('game.js'),
    from: "    _playerShip?.feedPrisoners?.();",
    to:   "    void 0;",
  },
  {
    name: '#67 an escaper never goes back on the board',
    file: F('ship.js'),
    from: "      poster = Save.reWanted({ wantedId: c.wantedId ?? null, name: c.name,",
    to:   "      poster = null; void ({ wantedId: c.wantedId ?? null, name: c.name,",
  },
  {
    name: '#67 an escaper goes back at the same price',
    file: F('save.js'),
    from: "  const ESCAPE_BOUNTY_RAISE = 1.5;",
    to:   "  const ESCAPE_BOUNTY_RAISE = 1;",
  },
  {
    name: '#67 an escaper who was already listed gets a SECOND poster',
    file: F('save.js'),
    from: "    const known = _data.wanted.find(w => w.id === rec.wantedId);",
    to:   "    const known = null;",
  },
  {
    name: '#67 an escaper comes back still marked as sighted',
    file: F('save.js'),
    from: "      known.state  = 'wanted';",
    to:   "      void 0;",
  },
  {
    name: '#67 the board grows past its ceiling for escapers',
    file: F('save.js'),
    from: "    if (_data.wanted.length >= WANTED_MAX) return null;\n    const w = {",
    to:   "    if (false) return null;\n    const w = {",
  },
  {
    name: '#67 an ENEMY brig losing a man puts him on our board',
    file: F('ship.js'),
    from: "    if (this.isPlayer && typeof Save !== 'undefined' && Save.reWanted) {",
    to:   "    if (typeof Save !== 'undefined' && Save.reWanted) {",
  },
  {
    name: '#67 an escaper comes back at the same rank',
    file: F('save.js'),
    from: "    w.level   = Utils.clamp((w.level ?? 5) + ESCAPE_LEVEL_GAIN, 1, 24);",
    to:   "    w.level   = Utils.clamp((w.level ?? 5), 1, 24);",
  },
  {
    name: '#67 the escape counter latches instead of counting',
    file: F('save.js'),
    from: "    w.escapes = (w.escapes ?? 0) + 1;",
    to:   "    w.escapes = 1;",
  },
  {
    name: '#67 a re-listed man is only dearer, never harder',
    file: F('save.js'),
    from: "      _harden(known);\n      known.bounty = raise(known.bounty);",
    to:   "      known.bounty = raise(known.bounty);",
  },
  {
    name: '#67 the fight ignores the rank the board promised',
    file: F('game.js'),
    from: "    if (w.level > (cap.level ?? 1) && Commander.rollEnemy) {",
    to:   "    if (false) {",
  },
  {
    name: '#67 an escapee gets no better hull than anybody else',
    file: F('game.js'),
    from: "    if (escapee && escapee.escapes > 0) difficulty = 'hard';",
    to:   "    void 0;",
  },

  /* ── update68 — the player's bug list ──────────────────── */
  {
    name: '#68 the hangar preview cache forgets what the hull IS',
    file: F('basescreen.js'),
    from: "    const sig = entry.data ? JSON.stringify(entry.data) : 'fresh';\n    const key = `${_shipIdx}|${entry.key}|${sig}|",
    to:   "    const sig = entry.data ? JSON.stringify(entry.data) : 'fresh';\n    void sig;\n    const key = `${_shipIdx}|${entry.key}|",
  },
  {
    name: '#68 body bags are unloaded onto the warehouse shelf again',
    file: F('game.js'),
    from: "        if (yardRefuses(it)) continue;",
    to:   "        if (false) continue;",
  },
  {
    name: '#68 the commander leaves the chair before the burial pays him',
    file: F('game.js'),
    from: "    if (_commander) {\n      _commander.away = false;\n      Base.saveCommander?.(_commander);\n    }\n    Commander?.setActive?.(null);\n\n    const bits = [];",
    to:   "    const bits = [];",
  },
  {
    name: '#68 the sorting screen offers your own dead for sale',
    file: F('game.js'),
    from: "    const holdHasGoods = !!hold?.items?.some(it => !yardRefuses(it));",
    to:   "    const holdHasGoods = !!hold?.items?.length;",
  },
  {
    name: '#68 VENT needs a hatch the player opened first',
    file: F('ship.js'),
    from: "      if (!this.doors.some(d => d.isAirlock)) return 'no airlock on this hull';",
    to:   "      if (!this.hasOpenAirlock()) return 'every airlock is shut';",
  },
  {
    name: '#68 the bearer walks to a shut hatch and stands there',
    file: F('ship.js'),
    from: "        const air = this.doors.filter(d => d.isAirlock)",
    to:   "        const air = this.doors.filter(d => d.isAirlock && d.mode === 'open')",
  },
  {
    name: '#68 the burial leaves the airlock hanging open',
    file: F('ship.js'),
    from: "              if (c._ventOpened === air.id) { air.mode = 'closed'; air.open = false; }",
    to:   "              void 0;",
  },
  {
    name: '#68 the order names a man and never sends him',
    file: F('ship.js'),
    from: "      pick.moveToOnShip?.(this, body.x, body.y);\n    }\n    return { ok: true, message: act === 'treat'",
    to:   "      void 0;\n    }\n    return { ok: true, message: act === 'treat'",
  },
  {
    name: '#68 BAG demands somebody already standing over him',
    file: F('ship.js'),
    from: "        c && c.alive && c.isPlayer === this.isPlayer && !c.carrying);\n      if (!hands) return 'nobody free to do it';",
    to:   "        c && c.alive && c.isPlayer === this.isPlayer && c.roomId === body.roomId);\n      if (!hands) return 'nobody free to do it';",
  },
  {
    name: '#68 a man sent to bag a body never finishes the job',
    file: F('ship.js'),
    from: "    this.bagArrivals();",
    to:   "    void 0;",
  },
  {
    name: '#68 the menu opens with nobody selected',
    file: F('game.js'),
    from: "      const sel = UI.getSelectedCrewAll();\n      const body = sel.length ? _bodyUnderCursor(mx, my) : null;",
    to:   "      const body = _bodyUnderCursor(mx, my);",
  },
  {
    name: '#68 a greyed row swallows the click in silence',
    file: F('game.js'),
    from: "        const why = _playerShip.menuRefusal(body, hit.act);\n        if (why) {",
    to:   "        const why = null;\n        if (why) {",
  },
  {
    name: '#68 a body is drawn on top of the man standing over it',
    file: F('crew.js'),
    from: "  static get BODY_DROP() { return 10; }",
    to:   "  static get BODY_DROP() { return 0; }",
  },
  {
    name: '#68 the body hit test forgets the offset the drawing uses',
    file: F('game.js'),
    from: "      const dy = (c.dead || c.down) ? CrewMember.BODY_DROP : 0;",
    to:   "      const dy = 0;",
  },
  {
    name: '#68 a won fight can still leave you stranded',
    file: F('game.js'),
    from: "      if (_fuelAboard() <= 0) {\n        const r = _addFuel(1);",
    to:   "      if (false) {\n        const r = _addFuel(1);",
  },
  {
    name: '#68 the map jump asks only about fuel again',
    file: F('game.js'),
    from: "      const why = _jumpRefusal();\n      if (why) {",
    to:   "      const why = _fuelAboard() <= 0 ? 'no fuel' : null;\n      if (why) {",
  },
  {
    name: '#68 nobody has to be at the helm',
    file: F('game.js'),
    from: "    if (!at.length) return 'Nobody at the helm — put a hand in the cockpit.';",
    to:   "    if (false) return 'Nobody at the helm — put a hand in the cockpit.';",
  },
  {
    name: '#68 a dead cockpit no longer stops a jump',
    file: F('game.js'),
    from: "    if (!pil || pil.effectivePower() <= 0) return 'Cockpit offline — cannot jump!';",
    to:   "    if (false) return 'Cockpit offline — cannot jump!';",
  },
  {
    name: '#68 the crew bonus stacks across contracts again',
    file: F('crew.js'),
    from: "      baseMaxHp: this.baseMaxHp ?? this.maxHp,",
    to:   "",
  },
  {
    name: '#68 a wanted man flies an ordinary patrol boat',
    file: F('game.js'),
    from: "      const w = _wantedHere;\n      if (w) {",
    to:   "      const w = null;\n      if (w) {",
  },
  {
    name: '#68 his two guns are the same gun twice',
    file: F('game.js'),
    from: "          if (_enemyShip.weapons[slot]) _enemyShip.uninstallWeapon(slot);",
    to:   "          void 0;",
  },
  {
    name: '#68 a wanted man gets a one-bay hull he cannot arm',
    file: F('game.js'),
    from: "    const layoutKey = (difficulty === 'hard' || _wantedHere)",
    to:   "    const layoutKey = (difficulty === 'hard')",
  },
  {
    name: '#68 blowing up a wanted man leaves no body',
    file: F('game.js'),
    from: "    _bagWantedCommander();\n\n    // The enemy commander leaves with his ship (update50).",
    to:   "    // The enemy commander leaves with his ship (update50).",
  },
  {
    name: '#68 an ordinary commander leaves a body too',
    file: F('game.js'),
    from: "    if (!cap || !cap.wantedId) return false;",
    to:   "    if (!cap) return false;",
  },
  {
    name: '#68 the region line lands back on the CONTRACT header',
    file: F('basescreen.js'),
    from: "                     56 + _contractW + 14, y + 22);",
    to:   "                     60, y + 18);",
  },
  {
    name: '#68 the memorial loses the not-recovered panel',
    file: F('basescreen.js'),
    from: "      const lost = (typeof Save !== 'undefined' && Save.notRecovered)\n        ? Save.notRecovered() : [];",
    to:   "      const lost = [];",
  },
  {
    name: '#68 a buried man is still listed as never recovered',
    file: F('save.js'),
    from: "    return (_data?.graveyard ?? []).filter(g => g && !g.buried);",
    to:   "    return (_data?.graveyard ?? []);",
  },
  {
    name: '#68 a lost commander leaves no trace at all',
    file: F('game.js'),
    from: "      Save.addCommanderToGraveyard?.(_commander);",
    to:   "      void 0;",
  },
  {
    name: '#68 a cat is listed as one of the hands',
    file: F('save.js'),
    from: "      pet:     !!crewMember.isPet,",
    to:   "      pet:     false,",
  },
  {
    name: '#68 an empty not-recovered list draws nothing',
    file: F('basescreen.js'),
    from: "        ctx.fillText('Everybody came home.', x, y0 + 4);",
    to:   "        ctx.fillText('', x, y0 + 4);",
  },
  {
    name: '#68 both sicknesses go back to the same colour',
    file: F('renderer.js'),
    from: "  const DISEASE_COL = { plague: '#3fd96b', virus: '#d9463c' };",
    to:   "  const DISEASE_COL = { plague: '#3fd96b', virus: '#3fd96b' };",
  },
  {
    name: '#68 SICK hides his hit points again',
    file: F('renderer.js'),
    from: "                : c.state === 'injured' ? { t: 'INJURED',  col: '#ffd700' }\n                : null;",
    to:   "                : c.state === 'injured' ? { t: 'INJURED',  col: '#ffd700' }\n                : c.infected ? { t: '\\u2623 SICK', col: '#3fd96b' }\n                : null;",
  },
  {
    name: '#68 a medkit stops curing the plague',
    file: F('game.js'),
    from: "      if (sick) {\n        sick.infected = false;",
    to:   "      if (false) {\n        sick.infected = false;",
  },
  {
    name: '#68 a medkit cures a void-spider bite too',
    file: F('game.js'),
    from: "        .filter(c => c.isPlayer && !c.dead && c.infected && !c.virus)[0];",
    to:   "        .filter(c => c.isPlayer && !c.dead && (c.infected || c.virus))[0];",
  },


  /* ── update69 ──────────────────────────────────────────── */
  {
    name: '#69 the door hit box swells back into the module',
    file: F('ship.js'),
    from: "  static get GRAB() { return 5; }",
    to:   "  static get GRAB() { return 13; }",
  },
  {
    name: '#69 the hit box stops following the door at all',
    file: F('game.js'),
    from: "      if (d.hits(mx, my)) {",
    to:   "      if (Utils.dist(mx, my, d.x, d.y) < 16) {",
  },
  {
    name: '#69 a hatch under the open menu eats the order again',
    file: F('game.js'),
    from: "    if (_bodyMenu) return false;\n    for (const d of _playerShip.doors) {",
    to:   "    for (const d of _playerShip.doors) {",
  },
  {
    name: '#69 the menu opens beside the man instead of under him',
    file: F('renderer.js'),
    from: "    const px = Utils.clamp(x - BODY_MENU_W / 2, 4, _W - BODY_MENU_W - 4);\n    const py = Utils.clamp(y + BODY_MENU_DROP, 4, _H - h - 4);",
    to:   "    const px = Utils.clamp(x + 8, 4, _W - BODY_MENU_W - 4);\n    const py = Utils.clamp(y - h / 2, 4, _H - h - 4);",
  },
  {
    name: '#69 the menu goes wide again',
    file: F('renderer.js'),
    from: "  const BODY_MENU_W = 50, BODY_MENU_ROW = 15, BODY_MENU_PAD = 3;",
    to:   "  const BODY_MENU_W = 74, BODY_MENU_ROW = 15, BODY_MENU_PAD = 3;",
  },
  {
    name: '#69 the menu follows the cursor instead of the man',
    file: F('game.js'),
    from: "      const ax = body ? body.x : mx;",
    to:   "      const ax = mx;",
  },
  {
    name: '#69 the cat gets her Polish names back',
    file: F('crew.js'),
    from: "  'Sputnik', 'Comet', 'Soot', 'Luna', 'Domino', 'Rusty',",
    to:   "  'Sputnik', 'Mruk', 'Pyza', 'Luna', 'Kropka', 'Rusty',",
  },
  {
    name: '#69 the barracks paints the virus green again',
    file: F('basescreen.js'),
    from: "    if (c?.virus)    return { glyph: '☣', col: COL.virus  ?? '#d9463c', tip: 'VIRUS' };",
    to:   "    if (c?.virus)    return { glyph: '☣', col: '#9fff7a', tip: 'VIRUS' };",
  },
  {
    name: '#69 the roster prints a bare number again',
    file: F('renderer.js'),
    from: "          ctx.fillText(`${mm}:${String(ss).padStart(2, '0')}`, markX, crewY + 22);",
    to:   "          ctx.fillText(String(mm), markX, crewY + 22);",
  },
  {
    name: '#69 the bite stops counting down at all',
    file: F('ship.js'),
    from: "      c.virusT = before - dt;",
    to:   "      c.virusT = before;",
  },
  {
    name: '#69 the infection clock never runs',
    file: F('ship.js'),
    from: "    // ── The bite and the egg case, both on the clock ──\n    this.infectionTick(dt);",
    to:   "    // ── The bite and the egg case, both on the clock ──",
  },
  {
    name: '#69 the man who turns leaves a corpse as well',
    file: F('ship.js'),
    from: "    c.bagged = true;\n    this.crew = this.crew.filter(k => k !== c);",
    to:   "    c.bagged = true;",
  },
  {
    name: '#69 the egg forgets which room it was laid in',
    file: F('ship.js'),
    from: "      roomId: c.roomId,\n      x: c.x, y: (room ? room.cy + 6 : c.y),",
    to:   "      x: c.x, y: (room ? room.cy + 6 : c.y),",
  },
  {
    name: '#69 the stone stops saying what became of him',
    file: F('ship.js'),
    from: "    c.killedBy = 'the void-spider virus — he left an egg case';",
    to:   "    c.killedBy = 'unknown';",
  },
  {
    name: '#69 the egg stops hatching',
    file: F('ship.js'),
    from: "      m.hatchT = (m.hatchT ?? EGG_SECONDS) - dt;",
    to:   "      m.hatchT = (m.hatchT ?? EGG_SECONDS);",
  },
  {
    name: '#69 the spiders come out of a random module',
    file: F('ship.js'),
    from: "    const home = this.getRoomById(m.roomId) ||",
    to:   "    const home = null ||",
  },
  {
    name: '#69 the yard shelves the egg case with the ore',
    file: F('game.js'),
    from: "    const yardRefuses = (it) => isBody(it) || isEgg(it);",
    to:   "    const yardRefuses = (it) => isBody(it);",
  },
  {
    name: '#69 the crew help themselves to the rations again',
    file: F('ship.js'),
    from: "      if (c.hunger > H.HUNGRY) c._starveWarned = false;",
    to:   "      if (c.hunger > H.HUNGRY) c._starveWarned = false;\n      if (!c.isPet && c.alive && c.hunger < H.HUNGRY) this._startMeal(c);",
  },
  {
    name: '#69 the cat stops feeding herself too',
    file: F('ship.js'),
    from: "      if (cat.hunger < H.HUNGRY && this._startMeal(cat)) return;",
    to:   "      if (false) return;",
  },
  {
    name: '#69 an errand re-posts the man who ran it',
    file: F('crew.js'),
    from: "        const post = this._errandRoomId ?? this.homeRoomId;",
    to:   "        const post = this.homeRoomId;",
  },
  {
    name: '#69 the stretcher-bearer is re-stationed in the sick bay',
    file: F('ship.js'),
    from: "            c._errandRoomId = medRoom.id;",
    to:   "            c.homeRoomId = medRoom.id;",
  },
  {
    name: '#69 the errand never ends',
    file: F('ship.js'),
    from: "      if (c._errandRoomId && !c.carrying && !c._rescueId && !c._bagTargetId &&\n          c.roomId === c._errandRoomId) {\n        c._errandRoomId = null;\n      }",
    to:   "      void 0;",
  },
  {
    name: '#69 a second cat is offered to a ship that has one',
    file: F('map.js'),
    from: "  if (wantsPet && ship?.crew?.some(c => c.isPet && !c.dead)) return false;",
    to:   "  if (false) return false;",
  },
  {
    name: '#69 a maxed module is offered an upgrade',
    file: F('map.js'),
    from: "  if (up && sys.level >= (sys.def?.maxLevel ?? 8)) return false;",
    to:   "  if (false) return false;",
  },
  {
    name: '#69 the shield tuner comes back',
    file: F('map.js'),
    from: "  /* THE SHIELD TUNER IS GONE (update69, player's call).",
    to:   "  {\n    id: 'shield_tuner',\n    title: 'Shield Tuner',\n    text: 'A tender matches your course.',\n    requires: 'shields',\n    choices: [\n      { label: 'Let her aboard (30 CC)', result: { cost: 30, system_upgrade: 'shields' } },\n      { label: 'Wave her off', result: {} },\n    ],\n  },\n  /* THE SHIELD TUNER IS GONE (update69, player's call).",
  },
  {
    name: '#69 boarding a hull that is not there is allowed again',
    file: F('game.js'),
    from: "    const gone = !_enemyShip || _enemyShip.destroyed || _enemyShip.hull <= 0;",
    to:   "    const gone = !_enemyShip;",
  },
  {
    name: '#69 an ordinary captain is offered a cell again',
    file: F('game.js'),
    from: "      if (foeCap && foeCap.wantedId && !noQuarter && cells > 0) {",
    to:   "      if (foeCap && !noQuarter && cells > 0) {",
  },
  {
    name: '#69 the popup promises a cell to a man nobody pays for',
    file: F('game.js'),
    from: "            + (!foeCap.wantedId\n                ? 'Nobody is paying for this one — he is not on any board.'",
    to:   "            + (false\n                ? 'Nobody is paying for this one — he is not on any board.'",
  },

  /* ── update70 ──────────────────────────────────────────── */
  {
    name: '#70 a poster is pinned to no contract at all',
    file: F('save.js'),
    from: "      region: _data?.run?.region ?? DEFAULT_REGION,\n      mission: _spreadMission(),\n    };\n  }",
    to:   "      region: _data?.run?.region ?? DEFAULT_REGION,\n      mission: null,\n    };\n  }",
  },
  {
    name: '#70 the board stacks every name on one contract',
    file: F('save.js'),
    from: "    const min  = Math.min(...keys.map(k => count[k]));\n    const pool = keys.filter(k => count[k] === min);",
    to:   "    const pool = keys.slice(0, 1);",
  },
  {
    name: '#70 an old save never gets its addresses',
    file: F('save.js'),
    from: "    if (_addressOldPosters()) save();",
    to:   "    void 0;",
  },
  {
    name: '#70 the map seats anybody on anything again',
    file: F('map.js'),
    from: "    const open = Save.wantedFor ? Save.wantedFor(mission) : Save.wanted();",
    to:   "    const open = Save.wanted();",
  },
  {
    name: '#70 the board stops saying which contract to take',
    file: F('basescreen.js'),
    from: "      ctx.fillText(job, px + 34 + ctx.measureText(`${corp.label || w.race} · level ${w.level}`).width + 12,\n                   y + 42);",
    to:   "      void job;",
  },
  {
    name: '#70 the poster rate goes back to two sectors in five',
    file: F('map.js'),
    from: "const WANTED_ON_MAP = 0.50;",
    to:   "const WANTED_ON_MAP = 0.40;",
  },
  {
    name: '#70 a clean commander is offered the black market',
    file: F('commander.js'),
    from: "  function pirateWillDeal(karma = karmaNow()) { return priceSurcharge(karma) > 0; }",
    to:   "  function pirateWillDeal(karma = karmaNow()) { return true; }",
  },
  {
    name: '#70 the pirate stops discounting anything',
    file: F('commander.js'),
    from: "    return karma <= KARMA_SHUNNED ? 0.45 : 0.30;",
    to:   "    return 0;",
  },
  {
    name: '#70 the shunned get no deeper cut than the merely distrusted',
    file: F('commander.js'),
    from: "    return karma <= KARMA_SHUNNED ? 0.45 : 0.30;",
    to:   "    return 0.30;",
  },
  {
    name: '#70 the parley is offered on every fight',
    file: F('game.js'),
    from: "    if (!w) return 'not a poster';",
    to:   "    if (false) return 'not a poster';",
  },
  {
    name: '#70 the parley never opens at all',
    file: F('game.js'),
    from: "      if (_maybeParley(diff)) return;",
    to:   "      if (false) return;",
  },
  {
    name: '#70 the parley loses a door',
    file: F('game.js'),
    from: "        { label: `Accept, then open fire (${robbery} karma)`,\n          result: { combat: difficulty, ambush: true, karma: robbery } },",
    to:   "",
  },
  {
    name: '#70 treachery is free',
    file: F('game.js'),
    from: "          result: { combat: difficulty, ambush: true, karma: robbery } },",
    to:   "          result: { combat: difficulty, ambush: true } },",
  },
  {
    name: '#70 the ambush leaves his shields up',
    file: F('game.js'),
    from: "      if (ss) { ss._shieldBars = 0; ss._shieldTimer = 0; }",
    to:   "      if (ss) { ss._shieldTimer = 0; }",
  },
  {
    name: '#70 trading leaves him on the node to be fought anyway',
    file: F('game.js'),
    from: "    if (node) node.wantedId = null;",
    to:   "    void 0;",
  },
  {
    name: '#70 trading takes him off the board as well',
    file: F('game.js'),
    from: "    const node = _sectorMap?.current?.();\n    if (node) node.wantedId = null;",
    to:   "    const node = _sectorMap?.current?.();\n    if (node) node.wantedId = null;\n    Save.deliverWanted?.(wantedId, 0);",
  },
  {
    name: '#70 the black market turns away the men it exists for',
    file: F('station.js'),
    from: "    if (this.blackMarket) return null;",
    to:   "    if (false) return null;",
  },
  {
    name: '#70 the pirate sells at port prices',
    file: F('station.js'),
    from: "  _goodsFactor() { return this.blackMarket ? this._priceFactor() : 1; }",
    to:   "  _goodsFactor() { return 1; }",
  },
  {
    name: '#70 a port starts charging karma on guns',
    file: F('station.js'),
    from: "  _goodsFactor() { return this.blackMarket ? this._priceFactor() : 1; }",
    to:   "  _goodsFactor() { return this._priceFactor(); }",
  },
  {
    name: '#70 the counter and the buy button quote different prices',
    file: F('ui.js'),
    from: "          const cost = s.weaponCost(item);",
    to:   "          const cost = def.cost;",
  },
  {
    name: '#70 his hold is empty of contraband',
    file: F('station.js'),
    from: "    push('contraband', ri(1, deep ? 4 : 3));",
    to:   "    void 0;",
  },
  {
    name: '#70 he sells no chips',
    file: F('station.js'),
    from: "      push(chipKeys[ri(0, chipKeys.length)]);",
    to:   "      void 0;",
  },
  {
    name: '#70 he does dockyard work after all',
    file: F('station.js'),
    from: "      hullRepair: 0,\n      // He will spare a cell or two, at his price.",
    to:   "      hullRepair: 20,\n      // He will spare a cell or two, at his price.",
  },
  {
    name: '#70 buying a crate does not charge for it',
    file: F('station.js'),
    from: "    Save.updateRun({ scrap: run.scrap - cost });\n    Audio.sfx.scrapCollect?.();\n    return { ok: true, cost, message: `Loaded ${placed.label}.` };",
    to:   "    Audio.sfx.scrapCollect?.();\n    return { ok: true, cost, message: `Loaded ${placed.label}.` };",
  },
  {
    name: '#70 the same crate can be sold twice',
    file: F('station.js'),
    from: "    item.sold = true;\n    Save.updateRun({ scrap: run.scrap - cost });\n    Audio.sfx.scrapCollect?.();",
    to:   "    Save.updateRun({ scrap: run.scrap - cost });\n    Audio.sfx.scrapCollect?.();",
  },
  {
    name: '#70 hunger stops mattering to the work',
    file: F('crew.js'),
    from: "  repairSpeed()    { return (1 + this.getSkillLevel('repair') * 0.5)\n                          * (1 + this._capBonus().repair) * this.effortFactor(); }",
    to:   "  repairSpeed()    { return (1 + this.getSkillLevel('repair') * 0.5)\n                          * (1 + this._capBonus().repair); }",
  },
  {
    name: '#70 a fire burns the same whatever he has eaten',
    file: F('crew.js'),
    from: "  firefightSpeed() { return (1 + this.getSkillLevel('firefight') * 0.5)\n                          * (1 + this._capBonus().firefight) * this.effortFactor(); }",
    to:   "  firefightSpeed() { return (1 + this.getSkillLevel('firefight') * 0.5)\n                          * (1 + this._capBonus().firefight); }",
  },
  {
    name: '#70 a breach is patched the same on an empty stomach',
    file: F('crew.js'),
    from: "  breachSpeed()    { return (1 + this.getSkillLevel('breach')    * 0.5)\n                          * (1 + this._capBonus().breach) * this.effortFactor(); }",
    to:   "  breachSpeed()    { return (1 + this.getSkillLevel('breach')    * 0.5)\n                          * (1 + this._capBonus().breach); }",
  },
  {
    name: '#70 a full stomach is worth nothing over a half-empty one',
    file: F('crew.js'),
    from: "    if (h >= HUNGER.FED)      return E.fed;",
    to:   "    if (false)                return E.fed;",
  },
  {
    name: '#70 starving costs no more than hungry',
    file: F('crew.js'),
    from: "    if (h <= HUNGER.STARVING) return E.starving;",
    to:   "    if (false) return E.starving;",
  },
  {
    name: '#70 hunger reaches the gunnery and the knife too',
    file: F('crew.js'),
    from: "  combatDamage()   { return 1 + this.getSkillLevel('combat')   * 0.3; }",
    to:   "  combatDamage()   { return (1 + this.getSkillLevel('combat') * 0.3) * this.effortFactor(); }",
  },
  {
    name: '#70 vermin are slowed by a hunger they do not have',
    file: F('crew.js'),
    from: "    if (!this.eats) return 1;\n    const h = this.hunger ?? 100;",
    to:   "    const h = this.hunger ?? 0;",
  },

  /* ── update71 ──────────────────────────────────────────── */
  {
    name: '#71 a contract carries no side jobs at all',
    file: F('game.js'),
    from: "    Save.rollRunGoals?.(mission.sectors ?? 1);",
    to:   "    void 0;",
  },
  {
    name: '#71 the goals stop scaling with the contract',
    file: F('save.js'),
    from: "      need: (s) => 4 + 3 * s, cc: (s) => 25 + 15 * s,",
    to:   "      need: (s) => 4, cc: (s) => 25,",
  },
  {
    name: '#71 two goals can be the same goal',
    file: F('save.js'),
    from: "    const keys = Utils.shuffle(Object.keys(RUN_GOAL_DEFS)).slice(0, Math.max(0, n));",
    to:   "    const keys = new Array(Math.max(0, n)).fill(Object.keys(RUN_GOAL_DEFS)[0]);",
  },
  {
    name: '#71 a kill is never counted',
    file: F('crew.js'),
    from: "      Save.goalEvent?.('crew_kills');",
    to:   "      void 0;",
  },
  {
    name: '#71 vermin count as enemy crew',
    file: F('crew.js'),
    from: "    if (this.isPlayer && !victim.isBeast && typeof Save !== 'undefined') {",
    to:   "    if (this.isPlayer && typeof Save !== 'undefined') {",
  },
  {
    name: '#71 losing your own hull counts as a kill again',
    file: F('ship.js'),
    from: "    if (!this.isPlayer) {\n      Save.recordKill();\n      Save.goalEvent?.('ships');\n    }",
    to:   "    Save.recordKill();\n    Save.goalEvent?.('ships');",
  },
  {
    name: '#71 a destroyed hull is not counted at all',
    file: F('ship.js'),
    from: "      Save.goalEvent?.('ships');",
    to:   "      void 0;",
  },
  {
    name: '#71 a stripped wreck is not counted',
    file: F('game.js'),
    from: "    Save.goalEvent?.('wrecks');",
    to:   "    void 0;",
  },
  {
    name: '#71 nobody is named for the fire they beat',
    file: F('crew.js'),
    from: "          fire.suppress(dt * this.firefightSpeed(), this);",
    to:   "          fire.suppress(dt * this.firefightSpeed());",
  },
  {
    name: '#71 their fires count as ours',
    file: F('fire.js'),
    from: "      if (by && by.isPlayer && typeof Save !== 'undefined') Save.goalEvent?.('fires');",
    to:   "      if (typeof Save !== 'undefined') Save.goalEvent?.('fires');",
  },
  {
    name: '#71 a goal finishes before it is finished',
    file: F('save.js'),
    from: "      if (g.n >= g.need) g.done = true;",
    to:   "      g.done = true;",
  },
  {
    name: '#71 the counter runs past what was asked for',
    file: F('save.js'),
    from: "      g.n = Math.min(g.need, (g.n ?? 0) + amount);",
    to:   "      g.n = (g.n ?? 0) + amount;",
  },
  {
    name: '#71 a goal pays every frame',
    file: F('save.js'),
    from: "    if (!g || !g.done || g.paid) return false;",
    to:   "    if (!g || !g.done) return false;",
  },
  {
    name: '#71 nothing is ever paid out',
    file: F('game.js'),
    from: "      if (run) Save.updateRun({ scrap: (run.scrap ?? 0) + g.cc });",
    to:   "      void 0;",
  },
  {
    name: '#71 the payout is never drained',
    file: F('game.js'),
    from: "    _payRunGoals();",
    to:   "    void 0;",
  },
  {
    name: '#71 the HUD hands out the live records',
    file: F('save.js'),
    from: "    return (_data?.run?.goals ?? []).map(g => ({ ...g }));",
    to:   "    return (_data?.run?.goals ?? []);",
  },
  {
    name: '#71 the objective line is never drawn',
    file: F('renderer.js'),
    from: "    _drawRunGoals(ctx, resX);",
    to:   "    void 0;",
  },
  {
    name: '#71 the objective line draws on a run with no goals',
    file: F('renderer.js'),
    from: "    if (!goals.length) return;\n    const y = 40, h = 17;",
    to:   "    const y = 40, h = 17;",
  },
  {
    name: '#71 the objective line stops showing progress',
    file: F('renderer.js'),
    from: "      const txt = g.done ? `✓ ${g.label}` : `${g.label} ${g.n}/${g.need}`;",
    to:   "      const txt = g.done ? `✓ ${g.label}` : `${g.label}`;",
  },
  {
    name: '#71 the objective line wraps onto a second row',
    file: F('renderer.js'),
    from: "      ctx.fillText(txt, x, y + 12);\n      x += ctx.measureText(txt).width + 14;",
    to:   "      ctx.fillText(txt, x, y + 12 + i * 11);\n      x += ctx.measureText(txt).width + 14;",
  },
  {
    name: '#71 the goals survive into the next contract',
    file: F('save.js'),
    from: "      goals: [],\n\n      seed: Math.floor(Math.random() * 1e9),",
    to:   "      goals: _data?.run?.goals ?? [],\n\n      seed: Math.floor(Math.random() * 1e9),",
  },
  {
    name: '#71 the difficulty ladder gets a karma gate too',
    file: F('base.js'),
    from: "    label: 'Courier Run',",
    to:   "    label: 'Courier Run',\n    karmaGate: 'high',",
  },
  {
    name: '#71 the relief run is open to anybody',
    file: F('base.js'),
    from: "  if (m.karmaGate === 'high' && col < 4) {",
    to:   "  if (false) {",
  },
  {
    name: '#71 the dirty contract is offered to a saint',
    file: F('base.js'),
    from: "  if (m.karmaGate === 'low' && col > 2) {",
    to:   "  if (false) {",
  },
  {
    name: '#71 the gate stops reading the board\'s own wall',
    file: F('base.js'),
    from: "  const col = (typeof Chips !== 'undefined' && Chips.wallColumn)\n    ? Chips.wallColumn(k) : 3;",
    to:   "  const col = k >= 50 ? 5 : 1;",
  },
  {
    name: '#71 a shut contract can be launched anyway',
    file: F('base.js'),
    from: "      const why = missionRefusal(MISSIONS[mission]);\n      if (why) return { ok: false, message: why };",
    to:   "      void 0;",
  },
  {
    name: '#71 a shut contract is silent about why',
    file: F('basescreen.js'),
    from: "        _wrap(ctx, closed, x + 12, my + 42, CARDW - 24, 13, 3);",
    to:   "        void 0;",
  },
  {
    name: '#73 the reason is cut off where the card ends',
    file: F('basescreen.js'),
    from: "        _wrap(ctx, closed, x + 12, my + 42, CARDW - 24, 13, 3);",
    to:   "        ctx.fillText(_clip(ctx, closed, CARDW - 24), x + 12, my + 42);",
  },
  {
    name: '#71 a shut contract is still clickable',
    file: F('basescreen.js'),
    from: "      if (!closed) _zones.push({ x, y: my, w: CARDW, h: 88, act: 'mission', arg: m.id });",
    to:   "      _zones.push({ x, y: my, w: CARDW, h: 88, act: 'mission', arg: m.id });",
  },
  {
    name: '#71 the blurb runs over the line below it again',
    file: F('basescreen.js'),
    from: "      _wrap(ctx, m.blurb, x + 12, my + 38, CARDW - 24, 13, 2);",
    to:   "      _wrap(ctx, m.blurb, x + 12, my + 38, CARDW - 24, 13);",
  },
  {
    name: '#71 the relief run pays no karma',
    file: F('game.js'),
    from: "    if (mission.karmaPay && _commander && typeof Commander !== 'undefined') {",
    to:   "    if (false && _commander && typeof Commander !== 'undefined') {",
  },
  {
    name: '#71 the relief run brings nothing home from the lab',
    file: F('game.js'),
    from: "    if (mission.chipReward) _awardChip({ minLevel: 1, maxLevel: 2 }, 'the people you got out');",
    to:   "    void 0;",
  },
  {
    name: '#71 the dirty contract costs nothing',
    file: F('base.js'),
    from: "    karmaPay: 'ROBBERY',",
    to:   "    karmaPay: null,",
  },
  {
    name: '#71 the dirty contract pays no better than an honest one',
    file: F('base.js'),
    from: "    ccBonus: 160,                // this is why anybody takes it",
    to:   "    ccBonus: 60,                 // this is why anybody takes it",
  },

  /* ── update72 ──────────────────────────────────────────── */
  {
    name: '#72 a boarding party beats the man it came to free',
    file: F('crew.js'),
    from: "      const foes = ship.crew.filter(k =>\n        k.alive && k.inRoom !== false && !k.isPrisoner &&",
    to:   "      const foes = ship.crew.filter(k =>\n        k.alive && k.inRoom !== false &&",
  },
  {
    name: '#72 a prisoner swings back',
    file: F('crew.js'),
    from: "    if (ship && this.inRoom !== false && !this.isPrisoner) {",
    to:   "    if (ship && this.inRoom !== false) {",
  },
  {
    name: '#72 the prisoner flag does not survive a save',
    file: F('crew.js'),
    from: "      isPrisoner: this.isPrisoner, rescued: this.rescued,",
    to:   "      rescued: this.rescued,",
  },
  {
    name: '#72 walking into the cell block frees nobody',
    file: F('ship.js'),
    from: "    // ── Anybody's prisoners, found by somebody else's boarders ──\n    this.freeCaptives();",
    to:   "    // ── Anybody's prisoners, found by somebody else's boarders ──",
  },
  {
    name: '#72 a freed man is still theirs',
    file: F('ship.js'),
    from: "      p.isPrisoner = false;\n      p.isPlayer   = true;",
    to:   "      p.isPrisoner = false;",
  },
  {
    name: '#72 nobody records who was rescued',
    file: F('ship.js'),
    from: "      p.rescued    = true;",
    to:   "      void 0;",
  },
  {
    name: '#72 a freed man stays painted in their red',
    file: F('ship.js'),
    from: "      if (p.race === 'hostile' && typeof CORP_KEYS !== 'undefined') {\n        p.race = Utils.pick(CORP_KEYS);\n      }",
    to:   "      void 0;",
  },
  {
    name: '#72 the man breaking out is "rescued" by his own guards',
    file: F('ship.js'),
    from: "    const held = this.crew.filter(c => c.isPrisoner && c.alive && !c._breakingOut);",
    to:   "    const held = this.crew.filter(c => c.isPrisoner && c.alive);",
  },
  {
    name: '#72 a man in their cell counts as a defender again',
    file: F('game.js'),
    from: "      ? _enemyShip.crew.filter(c => !c.isPlayer && !c.isBeast && !c.isPrisoner && c.alive).length",
    to:   "      ? _enemyShip.crew.filter(c => !c.isPlayer && !c.isBeast && c.alive).length",
  },
  {
    name: '#72 captives are seated in a compartment that does not exist',
    file: F('game.js'),
    from: "      if (!room) return 0;",
    to:   "      if (false) return 0;",
  },
  {
    name: '#72 every hull with a brig carries captives',
    file: F('game.js'),
    from: "    if (Math.random() >= CAPTIVE_CHANCE) return 0;",
    to:   "    if (false) return 0;",
  },
  {
    name: '#72 no hull ever carries captives',
    file: F('game.js'),
    from: "    _seatCaptives();",
    to:   "    void 0;",
  },
  {
    name: '#72 the yard pays nothing for the people you got out',
    file: F('game.js'),
    from: "    if (rep.rescued > 0 && _commander && typeof Commander !== 'undefined') {",
    to:   "    if (false && _commander && typeof Commander !== 'undefined') {",
  },
  {
    name: '#72 the dock stops counting who was rescued',
    file: F('base.js'),
    from: "      if (c && c.rescued) report.rescued++;",
    to:   "      void 0;",
  },
  {
    name: '#72 the escape goes back to being a line of text',
    file: F('ship.js'),
    from: "      this.addCrew(runner, true);",
    to:   "      void runner;",
  },
  {
    name: '#72 the escaper is one of ours',
    file: F('ship.js'),
    from: "        isPlayer: false, isPrisoner: true,",
    to:   "        isPlayer: true, isPrisoner: true,",
  },
  {
    name: '#72 the escaper keeps his name to himself',
    file: F('ship.js'),
    from: "        name: p.name, race: p.race || 'hostile',",
    to:   "        race: p.race || 'hostile',",
  },
  {
    name: '#72 the board is written the moment the cell opens',
    file: F('ship.js'),
    from: "      const brig = this.getRoomById(this.getSystem('brig')?.roomId) || this.rooms[0];",
    to:   "      Save.reWanted?.({ wantedId: p.wantedId ?? null, name: p.name, bounty: p.bounty });\n      const brig = this.getRoomById(this.getSystem('brig')?.roomId) || this.rooms[0];",
  },
  {
    name: '#72 he walks out through a locked hatch',
    file: F('ship.js'),
    from: "      } else if (air.hackBy('enemy', dt)) {",
    to:   "      } else if (true) {",
  },
  {
    name: '#72 he never reaches the airlock at all',
    file: F('ship.js'),
    from: "    if (!c._waypoints?.length) c.moveToOnShip?.(this, air.x, air.y);",
    to:   "    void 0;",
  },
  {
    name: '#72 an escaped commander goes up as a beginner',
    file: F('ship.js'),
    from: "      runner.level    = p.level;",
    to:   "      runner.level    = p.level ?? 1;",
  },
  {
    name: '#72 an escaper poster has no contract on it',
    file: F('save.js'),
    from: "      mission: _spreadMission(),\n    };\n    _harden(w);",
    to:   "    };\n    _harden(w);",
  },
  {
    name: '#72 a cornered man cannot be put back',
    file: F('game.js'),
    from: "    if (person.isPrisoner) return person.dead ? ['vent', 'bag'] : ['cell'];",
    to:   "    if (false) return ['cell'];",
  },
  {
    name: '#72 the cell order is accepted with the brig dark',
    file: F('ship.js'),
    from: "    if (brig.isDisabled()) return 'the brig has no power';",
    to:   "    if (false) return 'the brig has no power';",
  },
  {
    name: '#72 a man put back in the cell is also left in the corridor',
    file: F('ship.js'),
    from: "    this.crew = this.crew.filter(k => k !== c);\n    return { ok: true, message: `${c.name} is back in the cell.` };",
    to:   "    return { ok: true, message: `${c.name} is back in the cell.` };",
  },
  {
    name: '#72 the cursor cannot find the man out of the cell',
    file: F('game.js'),
    from: "      if (!c || (!c.isPlayer && !c.isPrisoner) || c.ejected) return false;",
    to:   "      if (!c || !c.isPlayer || c.ejected) return false;",
  },
  {
    name: '#72 a prisoner is put to work like a crewman',
    file: F('ship.js'),
    from: "      if (c.isPrisoner) { this._prisonerWalk(c, dt); return; }",
    to:   "      if (c.isPrisoner) { this._prisonerWalk(c, dt); }",
  },
];

/* ── WHAT EACH REVERT COSTS, AND WHY (update72) ──────────────
 *
 * One full run used to be 368 reverts x three suites, and the three
 * suites are not the same price at all:
 *
 *     run_tests.js    9.3 s     caught 7000 of the 7003 reverts ever
 *     smoke_draw.js   0.3 s     caught none — it is a crash net
 *     browser_test.js 19.1 s    caught THREE, all of them the shop
 *
 * So two thirds of a three-hour run was a browser starting up 368
 * times to answer a question it has answered three times in the
 * project's history. It still runs — on the BASELINE, where a real
 * Chromium is the only thing that can see a broken <script> tag or a
 * DOM shop that will not open — and per revert only where the fix it
 * guards actually lives, which is the handful marked `browser: true`.
 *
 * If a revert is ever reported as NOT CAUGHT and the missing test is a
 * browser one, the answer is to mark that revert rather than to put
 * the browser back in front of all 368. The leak report is what tells
 * you; that is the whole point of it.
 */
const SUITES_BASELINE = ['run_tests.js', 'smoke_draw.js', 'browser_test.js'];
const SUITES_FAST     = ['run_tests.js', 'smoke_draw.js'];

function runSuites(list = SUITES_FAST) {
  for (const s of list) {
    try {
      execFileSync(process.execPath, [path.join(__dirname, s)],
                   { stdio: 'pipe', timeout: 180000 });
    } catch (e) {
      return { failed: true, suite: s };
    }
  }
  return { failed: false };
}

// ── Baseline: everything must be green before we start ──
console.log('baseline…');
{
  const base = runSuites(SUITES_BASELINE);
  if (base.failed) {
    console.log(`REFUSING TO RUN: ${base.suite} is already red on a clean tree.`);
    process.exit(2);
  }
  console.log('baseline green\n');
}

/* An optional substring filter, so a single revert can be re-checked in
   seconds instead of re-running all of them: `node tests/break_check.js "#68 the menu"`.
   With no argument every revert runs, exactly as before. */
const ARGS = process.argv.slice(2);
/* ── SPLIT THE RUN ACROSS TWO TREES (update72) ───────────────
 * `--shard=1/2` takes every other revert. Each shard must be its own
 * CHECKOUT: a revert writes to js/ and puts it back, so two shards in
 * one directory would be breaking each other's files rather than the
 * code under test. Unpack with `git archive HEAD` and run one shard in
 * each, then read the two leak lists together. */
const shardArg = ARGS.find(a => a.startsWith('--shard='));
const [SHARD_I, SHARD_N] = shardArg
  ? shardArg.slice(8).split('/').map(Number) : [1, 1];
const FILTER = ARGS.filter(a => !a.startsWith('--')).join(' ').trim();

const leaks = [];
let ran = 0;
let seen = 0;
for (const b of BREAKS) {
  if (FILTER && !b.name.includes(FILTER)) continue;
  if (SHARD_N > 1 && (seen++ % SHARD_N) !== (SHARD_I - 1)) continue;
  ran++;
  const src = fs.readFileSync(b.file, 'utf8');
  const hits = src.split(b.from).length - 1;
  if (hits !== 1) {
    console.log(`!! ANCHOR ${hits === 0 ? 'MISSING' : 'AMBIGUOUS'} (${hits}): ${b.name}`);
    leaks.push(`${b.name}  [anchor ${hits === 0 ? 'missing' : 'ambiguous'}]`);
    continue;
  }
  fs.writeFileSync(b.file, src.replace(b.from, b.to));
  let res;
  try {
    res = runSuites(b.browser ? SUITES_BASELINE : SUITES_FAST);
  } finally {
    fs.writeFileSync(b.file, src);      // always put it back
  }
  if (res.failed) {
    console.log(`  caught  (${res.suite})  ${b.name}`);
  } else {
    console.log(`  LEAK              ${b.name}`);
    leaks.push(b.name);
  }
}

console.log(`\n${ran - leaks.length}/${ran} reverts caught by the tests`);
if (leaks.length) {
  console.log('\nNOT CAUGHT — these fixes have no test that fails without them:');
  leaks.forEach(l => console.log('  · ' + l));
}
process.exit(leaks.length ? 1 : 0);
