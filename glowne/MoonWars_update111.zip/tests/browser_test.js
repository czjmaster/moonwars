'use strict';
/* ============================================================
 * MOON WARS — REAL BROWSER TEST (Playwright + Chromium)
 * ============================================================
 * The vm harness stubs the canvas, the DOM and the audio graph, so it
 * cannot see: a missing <script> tag, a real Canvas2D API that rejects
 * what the stub swallowed, the station shop (which is DOM, not canvas),
 * or anything that only breaks once a browser is actually running the
 * loop. That is what this file is for.
 *
 * It serves the repo over http://127.0.0.1 and drives the REAL game:
 * real clicks at real canvas coordinates, real drags, real page errors.
 *
 *   session 1 — boot, ENTER BASE, every tab, the shelf, LAUNCH
 *   session 2 — an OUT-OF-DATE index.html and the runtime self-repair
 *   session 3 — the salvage screen with a real drag & drop
 *   session 4 — the station shop: stat chips and the reactor quote
 *   session 5 — the shop reads karma: surcharge banner and a shut dock
 *   session 6 — real sprite pixels: what lives in the duct has to fit
 *
 * Without playwright installed this exits CLEANLY (0) — it is an extra
 * pair of eyes, not a gate on machines that lack the browser.
 *
 * REBUILT in update43: the original file was lost (never tracked in
 * git, absent from the archive). Assertion count therefore differs from
 * the pre-update43 figure of 45 — see HANDOFF §4.
 * ============================================================ */

const http = require('http');
const fs   = require('fs');
const path = require('path');

const ROOT = path.join(__dirname, '..');

let chromium;
try {
  ({ chromium } = require('playwright'));
} catch (e) {
  console.log('playwright is not installed — skipping the browser test.');
  console.log('  install it with:  npm install playwright');
  process.exit(0);
}

let passed = 0, failed = 0;
function ok(cond, msg) {
  if (cond) { passed++; console.log('  ok   ' + msg); }
  else { failed++; console.error('  FAIL ' + msg); }
}
function section(name) { console.log('\n— ' + name + ' —'); }

// ── Static server ───────────────────────────────────────────

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js':   'text/javascript; charset=utf-8',
  '.css':  'text/css; charset=utf-8',
  '.png':  'image/png', '.jpg': 'image/jpeg', '.svg': 'image/svg+xml',
};

/** `overrides` lets a session serve a DIFFERENT index.html without ever
 *  touching the file on disk — session 2 needs a stale one. */
function serve(overrides = {}) {
  const server = http.createServer((req, res) => {
    let rel = decodeURIComponent(req.url.split('?')[0]);
    if (rel === '/') rel = '/index.html';
    if (overrides[rel] !== undefined) {
      res.writeHead(200, { 'Content-Type': MIME['.html'] });
      res.end(overrides[rel]);
      return;
    }
    const file = path.join(ROOT, rel);
    if (!file.startsWith(ROOT) || !fs.existsSync(file) || fs.statSync(file).isDirectory()) {
      res.writeHead(404); res.end('not found'); return;
    }
    res.writeHead(200, { 'Content-Type': MIME[path.extname(file)] ?? 'application/octet-stream' });
    fs.createReadStream(file).pipe(res);
  });
  return new Promise(resolve => {
    server.listen(0, '127.0.0.1', () => resolve({
      server,
      url: 'http://127.0.0.1:' + server.address().port + '/',
      close: () => new Promise(r => server.close(r)),
    }));
  });
}

// ── Page helpers ────────────────────────────────────────────

/** Everything the page shouted about while a session ran.
 *  Only OUR files count: the stylesheet pulls Orbitron from Google
 *  Fonts and the browser asks for a favicon, and neither failing says
 *  anything about the game. */
function watchErrors(page, origin) {
  const errors = [];
  page.on('pageerror', e => errors.push('pageerror: ' + e.message));
  page.on('console', m => {
    if (m.type() !== 'error') return;
    const src = m.location()?.url ?? '';
    if (src && !src.startsWith(origin)) return;         // third-party asset
    if (/favicon/i.test(src)) return;
    errors.push('console.error: ' + m.text() + (src ? '  [' + src + ']' : ''));
  });
  return errors;
}

/** Wait until Game.init() has finished and the menu loop is running. */
async function waitForBoot(page) {
  await page.waitForFunction(
    () => typeof Assets !== 'undefined' && typeof Renderer !== 'undefined'
       && !!Renderer.getCtx() && document.getElementById('loading-bar')
       && document.getElementById('loading-bar').style.width === '100%',
    null, { timeout: 30000 });
  // …plus the half-second the boot sequence spends on 'Ready.'
  await page.waitForTimeout(900);
}

/** Canvas game coordinates → a real mouse click on the page. */
async function canvasPoint(page, gx, gy) {
  return page.evaluate(([x, y]) => {
    const c = document.getElementById('game-canvas');
    const r = c.getBoundingClientRect();
    // update109: the backing is real pixels — the game's space is the renderer's.
    return { x: r.left + x * (r.width / Renderer.getWidth()), y: r.top + y * (r.height / Renderer.getHeight()) };
  }, [gx, gy]);
}
async function clickCanvas(page, gx, gy) {
  const p = await canvasPoint(page, gx, gy);
  await page.mouse.move(p.x, p.y);
  await page.waitForTimeout(60);      // let a frame register the hover
  await page.mouse.click(p.x, p.y);
  await page.waitForTimeout(160);     // …and a few frames act on the click
}
/**
 * Move a crate the way a PLAYER does since update48: click it, walk the
 * cursor over, click again. The old helper held the button down for the
 * whole trip, which is the interaction that was removed — a crate now
 * stays in the hand between the two clicks, and passing the cursor over
 * other crates on the way must change nothing.
 */
async function dragCanvas(page, from, to) {
  const a = await canvasPoint(page, from[0], from[1]);
  const b = await canvasPoint(page, to[0], to[1]);
  await page.mouse.move(a.x, a.y);
  await page.waitForTimeout(60);
  await page.mouse.click(a.x, a.y);
  await page.waitForTimeout(80);
  // Several steps, deliberately passing over whatever lies between.
  for (let i = 1; i <= 6; i++) {
    await page.mouse.move(a.x + (b.x - a.x) * i / 6, a.y + (b.y - a.y) * i / 6);
    await page.waitForTimeout(35);
  }
  await page.mouse.click(b.x, b.y);
  await page.waitForTimeout(160);
}

/** Click a base-screen button by the ACTION its zone carries, so the
 *  test presses what the player presses — not what we hope is there. */
async function clickBaseAct(page, act, argMatch = null) {
  const zone = await page.evaluate(([a, m]) => {
    const zs = BaseScreen._zonesFor(a);
    const z = m === null ? zs[0] : zs.find(q => JSON.stringify(q.arg) === JSON.stringify(m));
    return z ? { x: z.x, y: z.y, w: z.w, h: z.h } : null;
  }, [act, argMatch]);
  if (!zone) return false;
  await clickCanvas(page, zone.x + zone.w / 2, zone.y + zone.h / 2);
  return true;
}

// ════════════════════════════════════════════════════════════
// SESSION 1 — boot, base, every tab, the shelf, LAUNCH
// ════════════════════════════════════════════════════════════

async function session1(browser) {
  section('SESSION 1 — boot → ENTER BASE → tabs → shelf → LAUNCH');
  const host = await serve();
  const page = await browser.newPage({ viewport: { width: 1280, height: 720 } });
  const errors = watchErrors(page, host.url);

  try {
    await page.goto(host.url, { waitUntil: 'load' });
    await waitForBoot(page);

    ok(await page.evaluate(() => typeof Base !== 'undefined'),
       'base.js loaded from index.html');
    ok(await page.evaluate(() => typeof BaseScreen !== 'undefined'),
       'basescreen.js loaded from index.html');
    ok(await page.evaluate(() => typeof LootScreen !== 'undefined'),
       'lootscreen.js loaded from index.html');
    ok(await page.evaluate(() => typeof CargoGrid !== 'undefined'),
       'cargo.js loaded from index.html');
    ok(await page.evaluate(() => typeof DockingGame !== 'undefined'),
       'wreck.js loaded from index.html');
    ok(await page.evaluate(() => typeof Commander !== 'undefined'),
       'commander.js loaded from index.html');

    // ENTER BASE — first item of MENU_ITEMS, canvas coordinates from _drawMenu
    await clickCanvas(page, 640, 360);
    const inBase = await page.waitForFunction(
      () => !!BaseScreen._state() && !!BaseScreen._zonesFor('tab').length,
      null, { timeout: 5000 }).then(() => true).catch(() => false);
    ok(inBase, 'ENTER BASE opens the base screen (it used to click and do nothing)');

    // Every tab, checked by WHICH TAB OPENED — not by "no error".
    // A coordinate-only loop went on quietly clicking the wrong tabs for
    // several updates and stayed green the whole time.
    for (const tab of ['HANGAR', 'ARMOURY', 'CREW', 'MESS', 'SUPPLY', 'UPGRADES', 'MEMORIAL']) {
      const clicked = await clickBaseAct(page, 'tab', tab);
      const now = await page.evaluate(() => BaseScreen._state().tab);
      ok(clicked && now === tab, `tab ${tab} opens ${tab} (opened: ${now})`);
    }

    /* THE MESS (update43), driven the way the player drives it: build
       it, promote somebody, and check the barracks actually shrank. */
    await clickBaseAct(page, 'tab', 'MESS');
    await page.evaluate(() => {
      Save.addScrapBank(2000);
      // A veteran worth promoting, put in by hand so the test does not
      // depend on the random skills a recruit happens to roll.
      const b = Base.get();
      b.barracks.push({ id: 'probe1', name: 'Probe', race: 'terra', hp: 100, maxHp: 100,
                        skills: { repair: { level: 3, xp: 0 } } });
      Save.save();
    });
    await clickBaseAct(page, 'tab', 'CREW');
    await clickBaseAct(page, 'tab', 'MESS');
    ok(await page.evaluate(() => Base.messLevel() === 1 && Base.messCap() === 1),
       'the mess stands at level I with one berth, unbought (update44)');
    ok(!(await clickBaseAct(page, 'buyMess')),
       'and carries no BUILD button of its own — berths are bought on UPGRADES');
    const bunksBefore = await page.evaluate(() => Base.crew().length);
    const promoted = await clickBaseAct(page, 'promote', 'probe1');
    ok(promoted, 'a promotable veteran gets a PROMOTE button');
    ok(await page.evaluate(() => Base.commanders().length === 1),
       'pressing it puts him in the mess');
    ok(await page.evaluate(() => Base.crew().length) === bunksBefore - 1,
       'and takes him OUT of the barracks — he does not exist twice');
    ok(await page.evaluate(() => BaseScreen._state().commanderId === Base.commanders()[0].id),
       'the new commander is the one flying the next contract');

    /* ── THE PROMOTION SCREEN IS IN THE WAY, ON PURPOSE (update52) ──
     * He arrives owing one attribute point per level (update98), and the
     * screen opens for them straight away rather than waiting behind a
     * button. That is the behaviour under test here — and then the
     * points have to actually be spendable, or the base is unreachable. */
    await page.waitForTimeout(200);
    ok(await page.evaluate(() => Game.state() === 'promo'),
       'the promotion screen opens the moment he takes the chair');
    const owed = await page.evaluate(() =>
      Commander.pointsOwed(Base.commanders()[0]));
    ok(owed >= 1, `and it owes him one attribute point per level (${owed})`);

    for (let i = 0; i < owed + 2; i++) {
      if (await page.evaluate(() => Game.state() !== 'promo')) break;
      await clickCanvas(page, 640, 428);       // one of the four attribute rows (update98)
      await page.waitForTimeout(120);
    }
    ok(await page.evaluate(() => Game.state() === 'base'),
       'spending the last point hands the base back');
    ok(await page.evaluate(() => Commander.pointsOwed(Base.commanders()[0]) === 0),
       'and every level he had is now spent on something');
    ok(await page.evaluate(() =>
         Commander.pointsSpent(Base.commanders()[0]) === Base.commanders()[0].level),
       'one point per level, no more and no fewer');

    // The shelf / PACK HOLD screen (one screen since update35)
    await clickBaseAct(page, 'tab', 'SUPPLY');
    const openedShelf = await clickBaseAct(page, 'warehouse');
    const shelfUp = await page.evaluate(() => LootScreen.isOpen());
    ok(openedShelf && shelfUp, 'OPEN SHELF puts the two-grid pack screen up');
    ok(await page.evaluate(() => !!LootScreen._gridRect('hold')),
       'the pack screen has a hold grid to drop things into');
    ok(await page.evaluate(() => !!LootScreen._gridRect('wreck')),
       'the pack screen has the shelf on the other side');

    // Back out of it the way the player does.
    const closeZone = await page.evaluate(() => {
      const z = LootScreen._zoneFor('close') || LootScreen._zoneFor('done');
      return z ? { x: z.x, y: z.y, w: z.w, h: z.h } : null;
    });
    if (closeZone) await clickCanvas(page, closeZone.x + closeZone.w / 2, closeZone.y + closeZone.h / 2);
    else await page.keyboard.press('Escape');
    await page.waitForTimeout(300);
    ok(!(await page.evaluate(() => LootScreen.isOpen())), 'the pack screen closes again');

    // HANGAR: pick the hull we own
    await clickBaseAct(page, 'tab', 'HANGAR');
    ok(await page.evaluate(() => BaseScreen._state().tab === 'HANGAR'), 'back in the hangar');
    ok(await page.evaluate(() => Base.ships().length > 0), 'there is a hull in the berth to fly');

    /* THE PRE-FLIGHT BRIEFING (update111): the bar's button opens it,
       ESCAPE closes it, ENTER opens it again — and START is in it. */
    ok(await clickBaseAct(page, 'briefing'), 'the PRE-FLIGHT button is on the base');
    await page.waitForTimeout(250);
    ok(await page.evaluate(() => BaseScreen._state().briefing), 'it opens the briefing');
    ok(await page.evaluate(() => BaseScreen._zonesFor('tab').length === 0),
       'nothing behind it can be pressed');
    await page.keyboard.press('Escape');
    await page.waitForTimeout(250);
    ok(await page.evaluate(() => !BaseScreen._state().briefing), 'ESCAPE closes it');
    await page.keyboard.press('Enter');
    await page.waitForTimeout(250);
    ok(await page.evaluate(() => BaseScreen._state().briefing), 'ENTER opens it from the base');
    {
      const before = await page.evaluate(() => BaseScreen._state().hold?.countOf('fuel') ?? 0);
      const pressed = await clickBaseAct(page, 'loadKind', 'fuel');
      await page.waitForTimeout(200);
      const after = await page.evaluate(() => BaseScreen._state().hold?.countOf('fuel') ?? 0);
      ok(!pressed || after > before, `the He2 + button packs a cell off the shelf (${before} → ${after})`);
    }

    // LAUNCH — START CONTRACT, inside the briefing
    const launched = await clickBaseAct(page, 'launch');
    ok(launched, 'the LAUNCH button exists and is armed');
    const inRun = await page.waitForFunction(
      () => Save.hasActiveRun() && !!Save.getRun(),
      null, { timeout: 8000 }).then(() => true).catch(() => false);
    ok(inRun, 'LAUNCH starts a contract');
    ok(await page.evaluate(() => !!Save.getRun().commanderId),
       'and the commander sails with it');
    ok(await page.evaluate(() => (Base.commanders()[0] || {}).away === true),
       'his berth is still his while he is out there');
    ok(await page.evaluate(() => (Save.getRun().sector ?? 1) >= 1),
       'the run begins in a sector');

    await page.waitForTimeout(700);   // a few frames of the map/ship view
    ok(errors.length === 0, 'no page errors during the whole base tour'
       + (errors.length ? ':\n       ' + errors.join('\n       ') : ''));
  } finally {
    await page.close();
    await host.close();
  }
}

// ════════════════════════════════════════════════════════════
// SESSION 2 — a stale index.html repairs itself at runtime
// ════════════════════════════════════════════════════════════

async function session2(browser) {
  section('SESSION 2 — an OUT-OF-DATE index.html self-repairs');

  const real = fs.readFileSync(path.join(ROOT, 'index.html'), 'utf8');
  // Exactly what a player has who copied js/ over an old checkout.
  const LATE = ['js/base.js', 'js/basescreen.js', 'js/cargo.js',
                'js/lootscreen.js', 'js/wreck.js', 'js/commander.js'];
  let stale = real;
  LATE.forEach(src => {
    stale = stale.replace(new RegExp(`\\s*<script src="${src.replace('.', '\\.')}"></script>`, 'g'), '');
  });
  ok(LATE.every(s => !stale.includes(s)),
     'test setup: the stale page really is missing the late modules');
  ok(stale.includes('js/game.js'), 'test setup: the stale page still boots game.js');

  const host = await serve({ '/index.html': stale });
  const page = await browser.newPage({ viewport: { width: 1280, height: 720 } });
  const errors = watchErrors(page, host.url);

  try {
    await page.goto(host.url, { waitUntil: 'load' });
    await waitForBoot(page);

    const healed = await page.evaluate(() =>
      ['Base', 'BaseScreen', 'CargoGrid', 'LootScreen', 'DockingGame', 'Commander']
        .filter(n => typeof window[n] === 'undefined'));
    ok(healed.length === 0,
       `the game loads its own missing modules (still missing: ${healed.join(', ') || 'none'})`);

    const autoloaded = await page.evaluate(() =>
      [...document.querySelectorAll('script[data-autoloaded="true"]')].map(s => s.getAttribute('src')));
    ok(autoloaded.length === LATE.length,
       `all ${LATE.length} late modules were injected at runtime, got ${autoloaded.length}`);
    ok(LATE.every(s => autoloaded.includes(s)),
       'every missing script is the one that got injected');

    // And the repaired page must actually WORK, not merely define things.
    await clickCanvas(page, 640, 360);
    const inBase = await page.waitForFunction(
      () => !!BaseScreen._zonesFor('tab').length, null, { timeout: 5000 })
      .then(() => true).catch(() => false);
    ok(inBase, 'ENTER BASE works on the repaired page — this is the bug it exists for');

    ok(errors.filter(e => e.startsWith('pageerror')).length === 0,
       'a self-repaired page throws nothing'
       + (errors.length ? ':\n       ' + errors.join('\n       ') : ''));
  } finally {
    await page.close();
    await host.close();
  }
}

// ════════════════════════════════════════════════════════════
// SESSION 3 — the salvage screen, with a REAL drag & drop
// ════════════════════════════════════════════════════════════

async function session3(browser) {
  section('SESSION 3 — the salvage screen: a REAL drag & drop');
  const host = await serve();
  const page = await browser.newPage({ viewport: { width: 1280, height: 720 } });
  const errors = watchErrors(page, host.url);

  try {
    await page.goto(host.url, { waitUntil: 'load' });
    await waitForBoot(page);

    /* The two-grid salvage screen is ONE mechanism — the derelict hold,
       PACK HOLD and the weapon locker all open the same LootScreen. The
       shelf is the only one the player can reach in four clicks, so the
       drag is done there, driven by the GAME'S OWN loop: nothing here
       fakes a frame, a click or a coordinate. The derelict's own grid is
       checked separately below. */

    // Put something on the shelf to drag.
    const stocked = await page.evaluate(() => {
      Base.buySupply?.('fuel', 4);
      const g = Base.warehouseGrid();
      if (!g.items.length) { g.add('ration_pack'); Base.commitWarehouse(g); }
      return Base.warehouseGrid().items.length;
    });
    ok(stocked > 0, `the shelf has something on it to move (${stocked} stacks)`);

    await clickCanvas(page, 640, 360);                 // ENTER BASE
    await page.waitForFunction(() => !!BaseScreen._zonesFor('tab').length,
                               null, { timeout: 5000 });
    await clickBaseAct(page, 'tab', 'SUPPLY');
    await clickBaseAct(page, 'warehouse');             // OPEN SHELF
    await page.waitForTimeout(300);
    ok(await page.evaluate(() => LootScreen.isOpen()),
       'the two-grid salvage screen is up, driven by the real game loop');

    /* Where IS a given cell on screen? _gridRect does not publish its
       cell size, so the point is found through _cellAt — the same
       function the game uses to decide what the mouse is over. */
    const geom = await page.evaluate(() => {
      const pointFor = (which, cx, cy) => {
        const r = LootScreen._gridRect(which);
        if (!r) return null;
        for (let y = r.y + 2; y < r.y + r.h; y += 2)
          for (let x = r.x + 2; x < r.x + r.w; x += 2) {
            const c = LootScreen._cellAt(which, x, y);
            if (c && c.cx === cx && c.cy === cy) return [x, y];
          }
        return null;
      };
      const shelf = LootScreen._gridRect('wreck').grid;
      const hold  = LootScreen._gridRect('hold').grid;
      const it = shelf.items[0];
      if (!it) return { error: 'the shelf grid came up empty' };
      // A cell in the hold nothing occupies yet.
      let dest = null;
      for (let y = 0; y < hold.rows && !dest; y++)
        for (let x = 0; x < hold.cols && !dest; x++)
          if (!hold.at(x, y)) dest = [x, y];
      return {
        id: it.id, defKey: it.defKey,
        shelfBefore: shelf.items.length,
        holdBefore:  hold.items.length,
        from: pointFor('wreck', it.x, it.y),
        to:   dest ? pointFor('hold', dest[0], dest[1]) : null,
      };
    });
    ok(!geom.error && geom.from && geom.to,
       'a crate on the shelf and an empty cell in the hold can both be pointed at'
       + (geom.error ? ' — ' + geom.error : ''));

    if (geom.from && geom.to) {
      await dragCanvas(page, geom.from, geom.to);

      const after = await page.evaluate(() => ({
        shelf: LootScreen._gridRect('wreck').grid.items.length,
        hold:  LootScreen._gridRect('hold').grid.items.length,
        ids:   LootScreen._gridRect('hold').grid.items.map(i => i.id),
        keys:  LootScreen._gridRect('hold').grid.items.map(i => i.defKey),
      }));
      ok(after.hold === geom.holdBefore + 1,
         `the dragged crate landed in the hold (${geom.holdBefore} → ${after.hold})`);
      ok(geom.id && after.ids.includes(geom.id),
         `the crate that landed is THE crate that was dragged `
         + `(${geom.defKey} #${geom.id}; hold now holds ${after.keys.join(', ')})`);
      ok(after.shelf === geom.shelfBefore - 1,
         'the crate LEFT the shelf — an item is on the shelf OR in the hold, never both '
         + `(${geom.shelfBefore} → ${after.shelf})`);
    }

    // Closing the screen must PERSIST what was packed: those items have
    // physically left the shelf, so they have to be somewhere.
    const closed = await page.evaluate(() => {
      const z = LootScreen._zoneFor('close') || LootScreen._zoneFor('done');
      return z ? { x: z.x, y: z.y, w: z.w, h: z.h } : null;
    });
    if (closed) await clickCanvas(page, closed.x + closed.w / 2, closed.y + closed.h / 2);
    else await page.keyboard.press('Escape');
    await page.waitForTimeout(400);
    ok(!(await page.evaluate(() => LootScreen.isOpen())), 'the salvage screen closes');
    ok(await page.evaluate(() => (Base.packedHold()?.items?.length ?? 0) > 0),
       'what was packed is written back to the base — it cannot evaporate on reload');

    // ── The derelict builds the same kind of grid the drag just used ──
    const wreck = await page.evaluate(() => {
      const w = makeDerelict(1, 850, 120);
      return {
        power: w.reactor.totalPower,
        half: w.reactor.capacity - Math.floor(w.reactor.capacity / 2),
        rooms: w.rooms.length,
        hasO2: !!w.getSystem('oxygen'),
        weapons: w.weapons.length,
      };
    });
    // update90a: half the reactor works on a wreck now, not one emergency unit.
    ok(wreck.power === wreck.half, `a derelict keeps half its reactor (${wreck.half}), got ${wreck.power}`);
    ok(wreck.hasO2, 'and runs its life support — that is what makes boarding possible');
    ok(wreck.weapons === 0, 'a derelict has no guns left');

    ok(errors.length === 0, 'no page errors while salvaging'
       + (errors.length ? ':\n       ' + errors.join('\n       ') : ''));
  } finally {
    await page.close();
    await host.close();
  }
}

// ════════════════════════════════════════════════════════════
// SESSION 4 — the station shop (the only test that sees it: it is DOM)
// ════════════════════════════════════════════════════════════

async function session4(browser) {
  section('SESSION 4 — the station shop: stat chips and the reactor quote');
  const host = await serve();
  const page = await browser.newPage({ viewport: { width: 1280, height: 720 } });
  const errors = watchErrors(page, host.url);

  try {
    await page.goto(host.url, { waitUntil: 'load' });
    await waitForBoot(page);

    await page.evaluate(() => {
      Save.load(); Save.startRun();
      Save.updateRun({ scrap: 9999 });
      const ship = new Ship('frigate', true, 80, 120);
      ship._allocateDefaultPower();
      window.__shop = { ship, station: new Station(2, 7) };
      UI.openStation(window.__shop.station, ship);
    });
    ok(await page.evaluate(() => !!document.getElementById('station-screen')),
       'the station overlay is built');

    // ── WEAPONS tab: every stat chip carries its OWN pictogram ──
    await page.click('.station-tab[data-tab="weapons"]');
    await page.waitForTimeout(200);

    const chips = await page.evaluate(() => {
      const out = [];
      document.querySelectorAll('#station-content span').forEach(sp => {
        // A stat chip is LABEL · icon · number
        if (sp.children.length >= 2 && sp.querySelector('svg')) {
          out.push({ text: sp.textContent.trim(), svg: sp.querySelector('svg').outerHTML });
        }
      });
      return out;
    });
    ok(chips.length > 0, `the shop rack renders stat chips (found ${chips.length})`);
    ok(chips.every(c => /<svg/.test(c.svg)), 'every stat chip carries an inline SVG pictogram');
    const shapes = new Set(chips.map(c => c.svg));
    ok(shapes.size > 1,
       `chips must not all share ONE pictogram — a stat with no icon of its own is a stat `
       + `nobody can read (distinct icons: ${shapes.size})`);

    const bare = await page.evaluate(() =>
      [...document.querySelectorAll('#station-content span')]
        .filter(sp => /^(DMG|SHOTS|POWER|SHIELDS|CREW|STUN|FIRE|BREACH)$/i.test(sp.textContent.trim()))
        .filter(sp => !sp.parentElement || !sp.parentElement.querySelector('svg')).length);
    ok(bare === 0, `no stat label is left as a bare word without its icon (bare: ${bare})`);

    // ── MODULES tab: THE PRICE THE SHOP QUOTES MUST BE THE PRICE IT CHARGES ──
    await page.click('.station-tab[data-tab="modules"]');
    await page.waitForTimeout(200);

    // Click the reactor on the blueprint, level by level, and compare
    // the quoted number with the seller's own price every single time.
    // Until update34 the button drew a LINEAR price while the till used
    // an exponential one, so from level 6 up the button lit, the player
    // clicked, and got "Insufficient CC." holding the money.
    const quoteWalk = await page.evaluate(async () => {
      const { ship, station } = window.__shop;
      const bad = [];
      const clickReactor = () => {
        const d = [...document.querySelectorAll('#station-content div')]
          .find(x => x.children.length === 2 && /^RCT/.test(x.textContent));
        if (!d) return false;
        d.click();
        return true;
      };
      /* A HARD STEP CAP. With a broken quote the purchase is refused,
         the level never rises and this walk would spin forever — a test
         that hangs is a test nobody runs. Bail out and report instead. */
      let guard = ship.reactor.maxLevel + 2;
      while (ship.reactor.level < ship.reactor.maxLevel) {
        if (guard-- <= 0) { bad.push({ stuck: ship.reactor.level }); break; }
        if (!clickReactor()) return { error: 'could not find the reactor on the blueprint' };
        await new Promise(r => setTimeout(r, 30));
        const txt = document.querySelector('#station-content')?.textContent ?? '';
        const m = txt.match(/UPGRADE\s+(\d+)\s+CC/);
        if (!m) { if (/MAX LEVEL/.test(txt)) break; return { error: 'no quote and not maxed: ' + txt.slice(0, 120) }; }
        const quoted = Number(m[1]);
        const real   = station.reactorCost(ship);
        const lvl    = ship.reactor.level;
        if (quoted !== real) bad.push({ lvl, quoted, real });
        // Pay EXACTLY what the button asked for, then buy.
        Save.updateRun({ scrap: quoted });
        const r = station.buyReactorUpgrade(ship, Save.getRun());
        if (!r.ok) bad.push({ lvl, quoted, real, refused: r.message });
        clickReactor();                     // deselect
        await new Promise(r2 => setTimeout(r2, 20));
      }
      return { bad, level: ship.reactor.level, max: ship.reactor.maxLevel };
    });

    ok(!quoteWalk.error, 'the reactor is reachable on the shop blueprint'
       + (quoteWalk.error ? ' — ' + quoteWalk.error : ''));
    if (!quoteWalk.error) {
      ok(quoteWalk.bad.length === 0,
        'the quoted reactor price is ALWAYS enough to buy with'
        + (quoteWalk.bad.length ? ': ' + JSON.stringify(quoteWalk.bad) : ''));
      ok(quoteWalk.level === quoteWalk.max,
        `walking the quotes upgraded the reactor to the cap (${quoteWalk.level}/${quoteWalk.max})`);
    }

    // DEPART closes it again — leaving a port is a state change.
    await page.click('#station-close-btn');
    await page.waitForTimeout(200);
    ok(!(await page.evaluate(() =>
        document.getElementById('station-screen').classList.contains('visible'))),
       'DEPART closes the port overlay');

    ok(errors.length === 0, 'no page errors in the shop'
       + (errors.length ? ':\n       ' + errors.join('\n       ') : ''));
  } finally {
    await page.close();
    await host.close();
  }
}


// ════════════════════════════════════════════════════════════
// SESSION 5 — the shop reads karma (update61)
// ════════════════════════════════════════════════════════════

async function session5(browser) {
  section('SESSION 5 — the shop reads karma: surcharge banner and a shut dock');
  const host = await serve();
  const page = await browser.newPage({ viewport: { width: 1280, height: 720 } });
  const errors = watchErrors(page, host.url);

  try {
    await page.goto(host.url, { waitUntil: 'load' });
    await waitForBoot(page);

    /* Pick the seeds HERE, in the page, from the same rule the game
       uses — hard-coding "seed 7 refuses" would make this test a
       hostage of the seed arithmetic rather than a test of the shop. */
    const seeds = await page.evaluate(() => {
      let shut = null, open = null;
      for (let s = 0; s < 40 && (shut === null || open === null); s++) {
        if (Commander.portRefuses(s, 0)) { if (shut === null) shut = s; }
        else if (open === null) open = s;
      }
      return { shut, open };
    });
    ok(seeds.shut !== null && seeds.open !== null,
       `some ports shut a shunned commander out and some do not (${seeds.shut} / ${seeds.open})`);

    const openShop = (karma, seed) => page.evaluate(({ karma, seed }) => {
      Save.load(); Save.startRun();
      Save.updateRun({ scrap: 9999 });
      const cap = Commander.fromCrew({ id: 'bk', name: 'Rook', race: 'terra', skills: {} });
      cap.karma = karma;
      Commander.setActive(cap);
      const ship = new Ship('frigate', true, 80, 120);
      ship._allocateDefaultPower();
      ship.hull = Math.max(1, ship.hullMax - 20);
      const station = new Station(2, seed);
      station.stock.hullRepair = 40;
      window.__shop = { ship, station };
      UI.openStation(station, ship);
    }, { karma, seed });

    // ── AN ORDINARY COMMANDER: no banner at all ──────────────
    await openShop(50, seeds.open);
    await page.waitForTimeout(150);
    ok(await page.evaluate(() => !document.getElementById('station-karma-banner')),
       'an ordinary commander sees no banner — the shop is unchanged for him');
    const parPrice = await page.evaluate(() => window.__shop.station.hullRepairCost(5));

    // ── A DISTRUSTED ONE: the surcharge is said out loud ─────
    await openShop(30, seeds.open);
    await page.waitForTimeout(150);
    const warned = await page.evaluate(() => {
      const b = document.getElementById('station-karma-banner');
      return { text: b ? b.textContent : null,
               tabs: document.querySelectorAll('.station-tab').length,
               price: window.__shop.station.hullRepairCost(5) };
    });
    ok(warned.text && /DISTRUSTED/.test(warned.text),
       `the banner names him: "${warned.text}"`);
    ok(/10%/.test(warned.text), 'and gives the figure, not just an adjective');
    ok(warned.tabs > 0, 'the shop stays OPEN to him — a surcharge is not a refusal');
    ok(warned.price > parPrice,
       `and the yard really charges it (${warned.price} vs ${parPrice} CC for 5 HP)`);

    /* THE LABEL ON THE BUTTON IS THE PRICE THAT WILL BE TAKEN. The
       whole reason the shop asks the station for a quote instead of
       multiplying its own copy. */
    await page.click('.station-tab[data-tab="repair"]');
    await page.waitForTimeout(200);
    const label = await page.evaluate(() => {
      const s = window.__shop.station;
      const want = `+5 HP — ${s.hullRepairCost(5)} CC`;
      const seen = [...document.querySelectorAll('#station-content span')]
        .map(e => e.textContent.trim()).filter(t => /^\+5 HP/.test(t));
      return { want, seen };
    });
    ok(label.seen.includes(label.want),
       `the repair button quotes the karma price ("${label.want}" among ${JSON.stringify(label.seen)})`);

    // ── A SHUNNED ONE AT A DOCK THAT REFUSES HIM ─────────────
    await openShop(5, seeds.shut);
    await page.waitForTimeout(150);
    const shut = await page.evaluate(() => {
      const b = document.getElementById('station-karma-banner');
      return { text: b ? b.textContent : null,
               tabs: document.querySelectorAll('.station-tab').length,
               content: !!document.getElementById('station-content'),
               depart: !!document.getElementById('station-close-btn') };
    });
    ok(shut.text && /DOCK CLOSED/.test(shut.text),
       `the shut dock says so on screen: "${shut.text}"`);
    ok(/will not trade/.test(shut.text), 'and gives the reason, so it does not read as a bug');
    ok(shut.tabs === 0 && !shut.content,
       'and shows no shop at all rather than an empty one');
    ok(shut.depart, 'DEPART is still there — the player is never trapped in a closed port');

    // ── THE SAME COMMANDER AT A DOCK THAT STILL DEALS ────────
    await openShop(5, seeds.open);
    await page.waitForTimeout(150);
    const still = await page.evaluate(() => {
      const b = document.getElementById('station-karma-banner');
      return { text: b ? b.textContent : null,
               tabs: document.querySelectorAll('.station-tab').length };
    });
    ok(still.tabs > 0, 'a port that will deal with him is open for business');
    ok(still.text && /NOTORIOUS/.test(still.text) && !/DOCK CLOSED/.test(still.text),
       `but it charges him for the name: "${still.text}"`);

    await page.evaluate(() => Commander.setActive(null));
    await page.click('#station-close-btn');
    await page.waitForTimeout(200);

    ok(errors.length === 0, 'no page errors in the karma shop'
       + (errors.length ? ':\n       ' + errors.join('\n       ') : ''));
  } finally {
    await page.close();
    await host.close();
  }
}

// ════════════════════════════════════════════════════════════
// SESSION 6 — what lives in the duct has to fit in the duct
// ════════════════════════════════════════════════════════════

/*
 * This one can only be asked here. The sprites are drawn onto real
 * canvases at boot and the Node harness has a canvas that draws
 * nothing, so "is the cat taller than the duct" is a question with no
 * answer outside a browser — and update73 got it wrong by eye, picking
 * a one-tile duct that the spider did not fit in standing still.
 *
 * So: render every beast frame at the size the game actually draws it,
 * count the non-transparent pixels, and compare the tallest against
 * VENT_H. Redraw the cat and this fails on the day it is redrawn, not
 * on the day somebody notices it clipping.
 */
async function session6(browser) {
  section('SESSION 6 — the duct is tall enough for what will live in it');
  const host = await serve();
  const page = await browser.newPage({ viewport: { width: 1280, height: 720 } });
  const errors = watchErrors(page, host.url);

  try {
    await page.goto(host.url, { waitUntil: 'load' });
    await waitForBoot(page);

    const out = await page.evaluate(() => {
      /* The size CrewMember.draw uses — read from the source of truth
         rather than typed in here, so the two cannot drift. */
      const SCREEN = 32;
      const ink = (frame) => {
        const c = document.createElement('canvas');
        c.width = SCREEN; c.height = SCREEN;
        const g = c.getContext('2d');
        g.drawImage(frame, 0, 0, SCREEN, SCREEN);
        const d = g.getImageData(0, 0, SCREEN, SCREEN).data;
        let top = 1e9, bot = -1;
        for (let y = 0; y < SCREEN; y++) {
          for (let x = 0; x < SCREEN; x++) {
            if (d[(y * SCREEN + x) * 4 + 3] > 12) {
              if (y < top) top = y;
              if (y > bot) bot = y;
            }
          }
        }
        return bot < 0 ? 0 : bot - top + 1;
      };
      const tallest = (mk) => {
        let h = 0;
        ['idle', 'walk', 'fight'].forEach(mode => {
          (mk(mode).frames || []).forEach(f => { h = Math.max(h, ink(f)); });
        });
        return h;
      };
      return {
        vent:   HULL_GRID.VENT_H,
        tile:   HULL_GRID.TILE,
        rat:    tallest(m => Animation.ratAnim(m, '#b3a189')),
        cat:    tallest(m => Animation.catAnim(m, '#3a3a42')),
        spider: tallest(m => Animation.spiderAnim(m, '#9fff7a')),
      };
    });

    ok(out.vent > 0, `the duct has a height (${out.vent}px)`);
    ['rat', 'cat', 'spider'].forEach(k => {
      ok(out[k] > 0, `${k}: the sprite draws something (${out[k]}px of ink)`);
      ok(out[k] <= out.vent,
         `${k} fits in the duct (${out[k]}px into ${out.vent}px)`);
    });

    /* AND IT IS NOT WASTEFULLY TALL EITHER. A duct three tiles high
       would pass the test above and eat the compartment; the point is
       that it is the SMALLEST whole number of tiles that works. */
    const need = Math.max(out.rat, out.cat, out.spider);
    ok(out.vent - need < out.tile,
       `and is the smallest duct that does (${out.vent}px for ${need}px of cat)`);

    /* WHICH WAY THE RAT FACES (update86a). Pest.draw mirrors the frame
       for a rat heading LEFT, so the unmirrored art has to face RIGHT —
       it faced left, and every rat walked tail first. Real pixels: the
       head and snout are the heavy end, the tail a thin line, so the ink
       on the head side of the frame's middle outweighs the other. */
    const facing = await page.evaluate(() => {
      const SCREEN = 32;
      const sides = (frame) => {
        const c = document.createElement('canvas');
        c.width = SCREEN; c.height = SCREEN;
        const g = c.getContext('2d');
        g.drawImage(frame, 0, 0, SCREEN, SCREEN);
        const d = g.getImageData(0, 0, SCREEN, SCREEN).data;
        let left = 0, right = 0, lo = SCREEN, hi = -1;
        for (let y = 0; y < SCREEN; y++) for (let x = 0; x < SCREEN; x++) {
          if (d[(y * SCREEN + x) * 4 + 3] > 12) { lo = Math.min(lo, x); hi = Math.max(hi, x); }
        }
        const mid = (lo + hi) / 2;
        for (let y = 0; y < SCREEN; y++) for (let x = 0; x < SCREEN; x++) {
          const a = d[(y * SCREEN + x) * 4 + 3];
          if (x < mid) left += a; else right += a;
        }
        return { left, right };
      };
      return ['idle', 'walk'].map(m => sides(Animation.ratAnim(m, '#b3a189').frames[0]));
    });
    ok(facing.every(f => f.right > f.left),
       `the rat's art faces right, head first (${facing.map(f => f.right + ' vs ' + f.left).join('; ')})`);

    ok(errors.length === 0, 'no page errors while measuring'
       + (errors.length ? ':\n       ' + errors.join('\n       ') : ''));
  } finally {
    await page.close();
    await host.close();
  }
}

// ════════════════════════════════════════════════════════════

/** Launch Chromium.
 *  Normally playwright finds its own download. Some environments ship a
 *  browser at a fixed path instead (and CI images pin a different build
 *  number than the npm package expects) — MOONWARS_CHROMIUM, or a couple
 *  of well-known locations, are tried before giving up. */
async function launchBrowser() {
  try {
    return await chromium.launch();
  } catch (e) {
    const candidates = [process.env.MOONWARS_CHROMIUM, '/opt/pw-browsers/chromium']
      .filter(Boolean).filter(p2 => { try { return fs.existsSync(p2); } catch (_) { return false; } });
    for (const executablePath of candidates) {
      try { return await chromium.launch({ executablePath }); } catch (_) { /* next */ }
    }
    console.log('could not start Chromium — skipping the browser test.');
    console.log('  ' + String(e && e.message || e).split('\n')[0]);
    console.log('  install the browser with:  npx playwright install chromium');
    return null;
  }
}

(async () => {
  const browser = await launchBrowser();
  if (!browser) process.exit(0);
  try {
    await session1(browser);
    await session2(browser);
    await session3(browser);
    await session4(browser);
    await session5(browser);
    await session6(browser);
  } catch (e) {
    failed++;
    console.error('\nFATAL: ' + (e && e.stack ? e.stack : e));
  } finally {
    await browser.close();
  }
  console.log('');
  console.log(`${passed} passed, ${failed} failed`);
  process.exit(failed ? 1 : 0);
})();
