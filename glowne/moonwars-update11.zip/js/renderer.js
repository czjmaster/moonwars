/* ============================================================
   MOON WARS — renderer.js
   Main canvas rendering pipeline.
   Owns the canvas, manages resolution, orchestrates all
   draw calls in correct layer order.
   ============================================================ */

'use strict';

const Renderer = (() => {

  let _canvas  = null;
  let _ctx     = null;
  let _W       = 1280;
  let _H       = 720;
  let _pixelRatio = 1;

  // Parallax star layers
  const _starLayers = [
    { speed: 0.05, alpha: 0.6 },
    { speed: 0.12, alpha: 0.8 },
  ];
  let _starOffset = 0;

  // ── Init ────────────────────────────────────────────────

  function init(canvasEl) {
    _canvas = canvasEl;
    _ctx    = _canvas.getContext('2d');
    _resize();
    window.addEventListener('resize', _resize);
    return _ctx;
  }

  function _resize() {
    const winW  = window.innerWidth;
    const winH  = window.innerHeight;
    const scale = Math.min(winW / _W, winH / _H);

    _canvas.style.width  = Math.round(_W * scale) + 'px';
    _canvas.style.height = Math.round(_H * scale) + 'px';
    _canvas.width        = _W;
    _canvas.height       = _H;

    // Inform input system of CSS→canvas scale
    const rect = _canvas.getBoundingClientRect();
    Input.setScale(
      rect.width  / _W || 1,
      rect.height / _H || 1
    );

    Camera.resize(_W, _H);
  }

  function getCtx()    { return _ctx; }
  function getWidth()  { return _W; }
  function getHeight() { return _H; }

  // ── Clear ───────────────────────────────────────────────

  function clear() {
    _ctx.clearRect(0, 0, _W, _H);
    _ctx.fillStyle = '#07080f';
    _ctx.fillRect(0, 0, _W, _H);
  }

  // ── Starfield background ─────────────────────────────────

  function drawBackground(scrollX = 0) {
    const stars = Assets.get('bg_stars');
    const moon  = Assets.get('bg_moon');

    if (stars) {
      // Layer 1: slow parallax
      const off1 = ((-scrollX * 0.05) % _W + _W) % _W;
      _ctx.globalAlpha = 0.7;
      _ctx.drawImage(stars, off1 - _W, 0, _W, _H);
      _ctx.drawImage(stars, off1,      0, _W, _H);

      // Layer 2: faster
      _ctx.globalAlpha = 0.5;
      const off2 = ((-scrollX * 0.15) % _W + _W) % _W;
      _ctx.drawImage(stars, off2 - _W, 0, _W, _H);
      _ctx.drawImage(stars, off2,      0, _W, _H);
      _ctx.globalAlpha = 1;
    } else {
      _ctx.fillStyle = '#07080f';
      _ctx.fillRect(0, 0, _W, _H);
    }

    // Moon in background
    if (moon) {
      _ctx.globalAlpha = 0.18;
      _ctx.drawImage(moon, _W - 260, 30, 200, 200);
      _ctx.globalAlpha = 1;
    }
  }

  // ── HUD ─────────────────────────────────────────────────

  const _powerClickZones = [];
  function getPowerClickZones() { return _powerClickZones; }

  /** Tiny status icon: 'crew' | 'fire' | 'noO2' — drawn at (x,y), ~12px */
  function _statusIcon(ctx, x, y, type) {
    ctx.save();
    if (type === 'crew') {
      // Little person: head + body
      ctx.fillStyle = '#4db8ff';
      ctx.beginPath(); ctx.arc(x, y - 3, 3, 0, Math.PI * 2); ctx.fill();
      ctx.fillRect(x - 3, y, 6, 6);
    } else if (type === 'fire') {
      // Orange flame triangle with yellow core
      ctx.fillStyle = '#ff7c20';
      ctx.beginPath();
      ctx.moveTo(x, y - 6); ctx.lineTo(x - 5, y + 5); ctx.lineTo(x + 5, y + 5);
      ctx.closePath(); ctx.fill();
      ctx.fillStyle = '#ffd700';
      ctx.beginPath();
      ctx.moveTo(x, y - 1); ctx.lineTo(x - 2, y + 4); ctx.lineTo(x + 2, y + 4);
      ctx.closePath(); ctx.fill();
    } else if (type === 'noO2') {
      // Blue circle with slash
      ctx.strokeStyle = '#4db8ff';
      ctx.lineWidth = 1.5;
      ctx.beginPath(); ctx.arc(x, y, 5.5, 0, Math.PI * 2); ctx.stroke();
      ctx.fillStyle = '#4db8ff';
      ctx.font = '8px monospace';
      ctx.textAlign = 'center';
      ctx.fillText('O', x, y + 3);
      ctx.strokeStyle = '#ff2d44';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(x - 5, y + 5); ctx.lineTo(x + 5, y - 5);
      ctx.stroke();
    }
    ctx.restore();
  }

  /** Status icons for a system's room: crew present, fire, low O2 */
  function _roomStatus(ship, sys) {
    const out = [];
    if (!sys.roomId) return out;
    if (ship.crew.some(c => !c.dead && c.roomId === sys.roomId)) out.push('crew');
    if (ship.fires.hasFireInRoom(sys.roomId)) out.push('fire');
    const ro = ship.oxygen.getRoom(sys.roomId);
    if (ro && ro.isWarning) out.push('noO2');
    return out;
  }

  function drawHUD(state) {
    _powerClickZones.length = 0;
    if (!state.playerShip) return;
    const ship = state.playerShip;
    const run  = Save.getRun();
    if (!run) return;
    const ctx  = _ctx;

    // ════ TOP-LEFT: Player hull bar (segmented, FTL style) ════
    _drawHeartBar(ctx, 14, 14, ship.hull, ship.hullMax, '#1aff8c', '#0a3018');

    // ONE status row under the hull: EVADE → OXYGEN → shield bubbles
    // (the old dark "evasion badge" circle looked like a phantom empty
    //  bubble — gone; pills no longer touch the crew list either)
    const shieldY = 58;
    const o2avg = ship.oxygen.averageO2();
    const o2col = o2avg < 0.25 ? '#ff2d44' : o2avg < 0.6 ? '#ffd700' : '#4db8ff';
    _statPill(ctx, 14, shieldY, 'EVADE',  Math.round(ship.evasion * 100) + '%', '#1aff8c');
    _statPill(ctx, 92, shieldY, 'OXYGEN', Math.round(o2avg * 100) + '%', o2col);
    {
      const ss = ship.getSystem('shields');
      const prog = ss ? ss.shieldChargeProgress : 0;
      for (let i = 0; i < ship.shieldMax; i++) {
        const lit = i < ship.shieldBars;
        _shieldBubble(ctx, 184 + i * 30, shieldY + 12, 11, lit,
                      i === ship.shieldBars ? prog : 0);
      }
    }

    // ════ LEFT: Crew portraits with HP bars ════
    let crewY = 108;
    ship.crew.forEach((c, i) => {
      const cx = 14, cw = 120, ch = 26;
      const sel = UI.getSelectedCrew && UI.getSelectedCrew() === c;

      ctx.fillStyle = sel ? 'rgba(26,140,255,0.25)' : 'rgba(13,17,32,0.85)';
      ctx.beginPath(); ctx.roundRect(cx, crewY, cw, ch, 3); ctx.fill();
      ctx.strokeStyle = sel ? '#4db8ff' : '#1e2d4a';
      ctx.lineWidth = sel ? 1.5 : 1;
      ctx.stroke();

      // Mini portrait square — corporation color
      ctx.fillStyle = c.color || (c.isPlayer ? '#4db8ff' : '#ff4444');
      ctx.fillRect(cx + 3, crewY + 3, 20, 20);
      ctx.fillStyle = '#c8d8f0';
      ctx.fillRect(cx + 6, crewY + 5, 14, 8); // helmet

      // Name
      ctx.fillStyle = '#c8d8f0';
      ctx.font = '10px Share Tech Mono, monospace';
      ctx.textAlign = 'left';
      ctx.fillText(c.name.slice(0, 8), cx + 28, crewY + 12);

      // HP bar
      ctx.fillStyle = '#0a1010';
      ctx.fillRect(cx + 28, crewY + 16, cw - 34, 6);
      ctx.fillStyle = c.hp / c.maxHp > 0.5 ? '#1aff8c' : c.hp / c.maxHp > 0.25 ? '#ffd700' : '#ff2d44';
      ctx.fillRect(cx + 28, crewY + 16, (cw - 34) * (c.hp / c.maxHp), 6);

      // Star
      const star = c.getStarRating();
      if (star !== 'none') {
        ctx.fillStyle = star === 'gold' ? '#ffd700' : '#aaaaaa';
        ctx.font = '10px monospace';
        ctx.textAlign = 'right';
        ctx.fillText('★', cx + cw - 3, crewY + 12);
      }

      // Click zone — select crew member
      _powerClickZones.push({ x: cx, y: crewY, w: cw, h: ch, crewIndex: i });

      crewY += ch + 4;
    });

    // ── Crew station + door buttons (two rows under the crew list) ──
    if (ship.crew.length) {
      const rows = [
        [ { label: 'SAVE POS',  key: 'crewSave',   color: '#4db8ff' },
          { label: 'RETURN',    key: 'crewReturn', color: '#1aff8c' } ],
        [ { label: 'OPEN ALL',  key: 'doorsOpen',  color: '#1aff8c' },
          { label: 'CLOSE ALL', key: 'doorsClose', color: '#ff5566' } ],
      ];
      const bw = 58, bh = 18, gap = 4;
      rows.forEach((btns, r) => {
        btns.forEach((b, i) => {
          const bx = 14 + i * (bw + gap), by = crewY + 2 + r * (bh + gap);
          ctx.fillStyle = 'rgba(13,17,32,0.9)';
          ctx.beginPath(); ctx.roundRect(bx, by, bw, bh, 3); ctx.fill();
          ctx.strokeStyle = b.color; ctx.lineWidth = 1; ctx.stroke();
          ctx.fillStyle = b.color;
          ctx.font = '9px Share Tech Mono, monospace';
          ctx.textAlign = 'center';
          ctx.fillText(b.label, bx + bw/2, by + 12);
          _powerClickZones.push({ x: bx, y: by, w: bw, h: bh, [b.key]: true });
        });
      });
      // Row label so it reads as the DOOR control panel
      ctx.fillStyle = '#4a6080';
      ctx.font = '8px Share Tech Mono, monospace';
      ctx.textAlign = 'left';
      ctx.fillText('DOORS', 14 + 2 * (bw + gap) + 2, crewY + 2 + (bh + gap) + 12);
    }

    // ════ LEFT SIDE: Vertical reactor column ════
    // Shows the reactor MODULE state: capacity slots from the bottom,
    // damaged slots (lost power) in red at the top, free power lit.
    const capacity   = ship.reactor.capacity ?? ship.reactor.totalPower;
    const totalPower = ship.reactor.totalPower;
    const usedPower  = totalPower - ship.availablePower();
    const rx = 20, rBarH = 14, rGap = 3;
    const rBottom = _H - 150;
    for (let i = 0; i < capacity; i++) {
      const by      = rBottom - i * (rBarH + rGap);
      const damaged = i >= totalPower;                 // knocked-out units
      const lit     = !damaged && i < (totalPower - usedPower);
      ctx.fillStyle = damaged ? 'rgba(200,40,60,0.85)'
                    : lit     ? '#ffb020'
                    : 'rgba(40,44,60,0.8)';
      ctx.fillRect(rx, by, 30, rBarH);
      ctx.strokeStyle = damaged ? '#ff5566' : '#07080f';
      ctx.lineWidth = 1;
      ctx.strokeRect(rx, by, 30, rBarH);
    }
    // Nebula: the topmost usable slots are drained — draw them violet
    if (state.nebula) {
      const dmg = capacity - (ship.reactor.sys?.damagedLevels ?? 0) >= 0
        ? (ship.reactor.sys?.damagedLevels ?? 0) : 0;
      for (let k = 0; k < (ship.reactor.penalty ?? 0); k++) {
        const slot = capacity - dmg - 1 - k;
        if (slot < 0) break;
        const by = rBottom - slot * (rBarH + rGap);
        ctx.fillStyle = 'rgba(150,70,220,0.75)';
        ctx.fillRect(rx, by, 30, rBarH);
        ctx.strokeStyle = '#cc44ff';
        ctx.strokeRect(rx, by, 30, rBarH);
      }
      ctx.fillStyle = '#cc44ff';
      ctx.font = '9px Share Tech Mono, monospace';
      ctx.textAlign = 'center';
      ctx.fillText('NEBULA −2', rx + 15, rBottom + rBarH + 26);
    }
    ctx.fillStyle = '#ffb020';
    ctx.font = '10px Share Tech Mono, monospace';
    ctx.textAlign = 'center';
    ctx.fillText(`PWR ${totalPower}/${capacity}`, rx + 15, rBottom + rBarH + 14);

    // ════ BOTTOM BAR: power management (FTL style) ════
    _drawPowerBar(ctx, ship, run);

    // ════ TOP-RIGHT: Enemy hull (if combat) ════
    // The whole enemy readout disappears the moment the ship is destroyed.
    if (state.enemyShip && state.enemyShip.hull > 0 && !state.enemyShip.destroyed) {
      const e = state.enemyShip;
      _drawHeartBar(ctx, _W - 320, 14, e.hull, e.hullMax, '#ff7c20', '#301505');

      // Enemy status: ONE row — EVADE → OXYGEN → bubbles (same style)
      const eo2  = e.oxygen.averageO2();
      const eCol = eo2 < 0.25 ? '#ff2d44' : eo2 < 0.6 ? '#ffd700' : '#4db8ff';
      _statPill(ctx, _W - 320, 52, 'EVADE',  Math.round(e.evasion * 100) + '%', '#ff7c20');
      _statPill(ctx, _W - 242, 52, 'OXYGEN', Math.round(eo2 * 100) + '%', eCol);
      {
        const es = e.getSystem('shields');
        const eprog = es ? es.shieldChargeProgress : 0;
        for (let i = 0; i < e.shieldMax; i++) {
          const lit = i < e.shieldBars;
          _shieldBubble(ctx, _W - 150 + i * 28, 64, 10, lit,
                        i === e.shieldBars ? eprog : 0);
        }
      }

      // ── Enemy module panel: BELOW the enemy ship, centered ──
      _drawEnemyModules(ctx, e);
    }

    // ════ Resources row (scrap/fuel/missiles/sector) top-center ════
    const resX = 470;
    ctx.fillStyle = 'rgba(13,17,32,0.85)';
    ctx.beginPath(); ctx.roundRect(resX, 10, 320, 26, 4); ctx.fill();
    ctx.strokeStyle = '#1e2d4a'; ctx.lineWidth = 1; ctx.stroke();
    ctx.font = '12px Share Tech Mono, monospace';
    ctx.textAlign = 'left';
    ctx.fillStyle = '#ffd700';
    ctx.fillText(`⬡${run.scrap}`, resX + 12, 28);
    ctx.fillStyle = '#1aff8c';
    ctx.fillText(`FUEL ${run.fuel}`, resX + 82, 28);
    ctx.fillStyle = '#ff7c20';
    ctx.fillText(`MSL ${run.missiles}`, resX + 172, 28);
    ctx.fillStyle = '#4db8ff';
    ctx.fillText(`SEC ${run.sector}`, resX + 256, 28);
  }

  /** One shield bubble — shared style for player AND enemy.
   *  `chargeProg` (0-1) draws a progress arc while this layer charges. */
  function _shieldBubble(ctx, x, y, r, lit, chargeProg = 0) {
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    if (lit) {
      const g = ctx.createRadialGradient(x - r*0.3, y - r*0.3, 1, x, y, r);
      g.addColorStop(0, '#d8f2ff');
      g.addColorStop(0.45, '#4db8ff');
      g.addColorStop(1, '#134a80');
      ctx.fillStyle = g;
    } else {
      ctx.fillStyle = 'rgba(16,30,52,0.75)';
    }
    ctx.fill();
    ctx.strokeStyle = lit ? '#9fdcff' : '#28486e';
    ctx.lineWidth = 1.5;
    ctx.stroke();
    if (lit) {   // inner glint
      ctx.beginPath();
      ctx.arc(x - r*0.35, y - r*0.35, r*0.22, 0, Math.PI*2);
      ctx.fillStyle = 'rgba(255,255,255,0.55)';
      ctx.fill();
    }
    // Recharge progress ring (like the crew repair ring)
    if (!lit && chargeProg > 0) {
      ctx.beginPath();
      ctx.arc(x, y, r + 3, -Math.PI/2, -Math.PI/2 + chargeProg * Math.PI * 2);
      ctx.strokeStyle = '#8fd4ff';
      ctx.lineWidth = 2.5;
      ctx.stroke();
    }
  }

  /** Readable stat pill: dark rounded badge, label + colored value */
  function _statPill(ctx, x, y, label, value, color) {
    const w = 74, h = 24;
    ctx.fillStyle = 'rgba(13,17,32,0.92)';
    ctx.beginPath(); ctx.roundRect(x, y, w, h, 5); ctx.fill();
    ctx.strokeStyle = color; ctx.lineWidth = 1; ctx.stroke();
    ctx.font = '8px Share Tech Mono, monospace';
    ctx.textAlign = 'left';
    ctx.fillStyle = '#7a90a8';
    ctx.fillText(label, x + 7, y + 9);
    ctx.font = 'bold 12px Share Tech Mono, monospace';
    ctx.fillStyle = color;
    ctx.fillText(value, x + 7, y + 20);
    return w;
  }

  /** FTL-style segmented health bar with heart icon */
  function _drawHeartBar(ctx, x, y, val, max, color, dimColor) {
    // Heart circle
    ctx.fillStyle = '#0d1120';
    ctx.beginPath(); ctx.arc(x + 16, y + 16, 17, 0, Math.PI*2); ctx.fill();
    ctx.strokeStyle = color; ctx.lineWidth = 2; ctx.stroke();
    ctx.fillStyle = color;
    ctx.font = '16px monospace';
    ctx.textAlign = 'center';
    ctx.fillText('♥', x + 16, y + 22);

    // Segments — width adapts so the bar never exceeds ~360px
    const gap  = 2;
    const segW = Math.max(7, Math.min(15, Math.floor(360 / max) - gap));
    const segH = 18;
    const startX = x + 40;
    for (let i = 0; i < max; i++) {
      const sx  = startX + i * (segW + gap);
      const lit = i < val;
      ctx.fillStyle = lit ? color : dimColor;
      ctx.beginPath();
      ctx.roundRect(sx, y + 7, segW, segH, 2);
      ctx.fill();
      if (lit && segW > 9) {
        ctx.fillStyle = 'rgba(255,255,255,0.25)';
        ctx.fillRect(sx + 2, y + 9, segW - 4, 3);
      }
    }
  }

  /**
   * FTL-style bottom power bar.
   * Icons in circles, clickable power pips above each icon,
   * weapons with charge segments, all connected by power line.
   * Click zones stored in _powerClickZones for game.js to consume.
   */

  /**
   * Compact FTL-style enemy systems readout, drawn BELOW the enemy ship.
   * Per column (one per system): status icons on top, power pips
   * (growing upward from a common baseline), system icon underneath.
   */
  function _drawEnemyModules(ctx, ship) {
    const systems = ship.systems.filter(s => s.maxPower > 0);
    if (!systems.length) return;
    const glyphs = {
      shields: '◙', weapons: '▲', engines: '≋',
      oxygen: 'O₂', medbay: '+', piloting: '◎', artillery: '✦',
      reactor: '⚡',
    };

    const colW = 34;
    const pw = 12, ph = 5, pg = 2;
    const step = ph + pg;                       // 7px per pip
    const maxPips = Math.max(...systems.map(s => s.maxPower));

    // Anchor: centered under the ship hull, below the plate (+14) and
    // weapon mounts; clamped to stay above the bottom power bar.
    const b  = ship.roomBounds();
    const x  = Utils.clamp(b.x + b.w / 2 - (systems.length * colW) / 2,
                           10, _W - systems.length * colW - 10);
    let  y   = b.y + b.h + 34;                  // top of the tallest pip stack
    const panelH = maxPips * step + 30;         // pips + icon circle
    y = Math.min(y, _H - 110 - panelH);         // keep clear of the bottom bar

    const baseline = y + maxPips * step;        // bottom edge of every stack

    let ix = x + colW / 2;
    systems.forEach(sys => {
      // Mini power pips — p=0 sits on the baseline, stack grows upward
      for (let p = 0; p < sys.maxPower; p++) {
        const py      = baseline - (p + 1) * step;
        const damaged = p >= sys.maxPower - sys.damagedLevels;
        const lit     = !damaged && p < sys.power;
        ctx.fillStyle = damaged ? '#cc2233'
                      : lit     ? '#ff9040'
                      : 'rgba(50,40,40,0.85)';
        ctx.fillRect(ix - pw/2, py, pw, ph);
        ctx.strokeStyle = damaged ? '#ff5566' : '#07080f';
        ctx.lineWidth = 0.5;
        ctx.strokeRect(ix - pw/2, py, pw, ph);
      }

      // Status icons (crew / fire / no-O2) just ABOVE this stack's top pip
      const topPipTop = baseline - sys.maxPower * step;
      const status = _roomStatus(ship, sys);
      status.forEach((st, si) => {
        _statusIcon(ctx, ix, topPipTop - 9 - si * 14, st);
      });

      // Icon below the baseline
      const disabled = sys.isDisabled();
      const iy = baseline + 15;
      ctx.fillStyle = '#0d1120';
      ctx.beginPath(); ctx.arc(ix, iy, 11, 0, Math.PI*2); ctx.fill();
      ctx.strokeStyle = disabled ? '#663333' : '#aa5522';
      ctx.lineWidth = 1.5; ctx.stroke();
      ctx.fillStyle = disabled ? '#884444' : '#ffb080';
      ctx.font = '10px monospace';
      ctx.textAlign = 'center';
      ctx.fillText(glyphs[sys.type] ?? '?', ix, iy + 3);

      ix += colW;
    });
  }

  /** Violet nebula clouds drifting behind the battle */
  function drawNebula(ctx, t) {
    ctx.save();
    for (let i = 0; i < 7; i++) {
      const cx = ((i * 231 + t * 18 * (1 + i * 0.13)) % (_W + 400)) - 200;
      const cy = 90 + ((i * 173) % (_H - 220));
      const r  = 140 + (i % 3) * 70;
      const g  = ctx.createRadialGradient(cx, cy, 0, cx, cy, r);
      g.addColorStop(0, 'rgba(150,60,210,0.10)');
      g.addColorStop(1, 'rgba(150,60,210,0)');
      ctx.fillStyle = g;
      ctx.fillRect(cx - r, cy - r, r * 2, r * 2);
    }
    ctx.restore();
  }

  function _drawPowerBar(ctx, ship, run) {

    const barY   = _H - 96;
    const iconR  = 20;
    let   ix     = 90;
    // Reactor is excluded — it's the SOURCE (shown as the left column),
    // not a power consumer you can allocate bars to.
    // Weapon modules are grouped at the END of the row, adjacent to
    // each other and to the gun cards on the right.
    const _all    = ship.systems.filter(s => s.maxPower > 0 && s.type !== 'reactor');
    const systems = [..._all.filter(s => s.type !== 'weapons'),
                     ..._all.filter(s => s.type === 'weapons')];

    // Power line along the bottom
    ctx.strokeStyle = '#ff7c20';
    ctx.lineWidth   = 2;
    ctx.beginPath();
    ctx.moveTo(36, _H - 130);
    ctx.lineTo(36, _H - 30);
    ctx.lineTo(_W - 60, _H - 30);
    ctx.stroke();

    const iconGlyphs = {
      shields: '◙', weapons: '▲', engines: '≋',
      oxygen: 'O₂', medbay: '+', piloting: '◎', artillery: '✦',
    };

    systems.forEach(sys => {
      const cy = _H - 52;

      // Vertical line from power rail to icon
      ctx.strokeStyle = '#ff7c20';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(ix, _H - 30);
      ctx.lineTo(ix, cy + iconR);
      ctx.stroke();

      // Icon circle
      const disabled = sys.isDisabled();
      ctx.fillStyle = '#0d1120';
      ctx.beginPath(); ctx.arc(ix, cy, iconR, 0, Math.PI*2); ctx.fill();
      ctx.strokeStyle = disabled ? '#663333' : (sys.power > 0 ? '#ffb020' : '#4a6080');
      ctx.lineWidth = 2;
      ctx.stroke();

      ctx.fillStyle = disabled ? '#884444' : (sys.power > 0 ? '#ffd780' : '#7a90a8');
      ctx.font = '15px monospace';
      ctx.textAlign = 'center';
      ctx.fillText(iconGlyphs[sys.type] ?? '?', ix, cy + 5);

      // Power pips ABOVE icon (click to add/remove)
      // Damaged levels render as RED squares at the top of the stack.
      const pipW = 22, pipH = 9, pipGap = 3;
      for (let p = 0; p < sys.maxPower; p++) {
        const py       = cy - iconR - 12 - p * (pipH + pipGap);
        const damaged  = p >= sys.maxPower - sys.damagedLevels;   // top slots break first
        const lit      = !damaged && p < sys.power;
        const ion      = sys.ionDamage > 0 && lit;

        ctx.fillStyle = damaged ? '#cc2233'
                      : ion     ? '#4db8ff'
                      : lit     ? '#ffb020'
                      : 'rgba(40,44,60,0.9)';
        ctx.fillRect(ix - pipW/2, py, pipW, pipH);
        ctx.strokeStyle = damaged ? '#ff5566' : '#07080f';
        ctx.lineWidth = 1;
        ctx.strokeRect(ix - pipW/2, py, pipW, pipH);

        if (!damaged) {
          _powerClickZones.push({
            x: ix - pipW/2 - 2, y: py - 2, w: pipW + 4, h: pipH + 4,
            sysIndex: ship.systems.indexOf(sys), pip: p,
          });
        }
      }

      // System label below icon (weapon modules are numbered)
      let label = sys.label;
      if (sys.type === 'weapons') {
        const wsysArr = systems.filter(s => s.type === 'weapons');
        if (wsysArr.length > 1) label = `WPN ${wsysArr.indexOf(sys) + 1}`;
      }
      ctx.fillStyle = '#7a90a8';
      ctx.font = '9px Share Tech Mono, monospace';
      ctx.fillText(label, ix, cy + iconR + 12);

      // Status icons just ABOVE the topmost pip (crew manning / fire / no O2)
      {
        const topPipTop = cy - iconR - 12 - (sys.maxPower - 1) * (pipH + pipGap);
        const status = _roomStatus(ship, sys);
        status.forEach((st, si) => {
          _statusIcon(ctx, ix, topPipTop - 10 - si * 14, st);
        });
      }

      // Icon click = toggle whole module on/off (power returns to reactor)
      _powerClickZones.push({
        x: ix - iconR, y: cy - iconR, w: iconR * 2, h: iconR * 2,
        sysToggleIndex: ship.systems.indexOf(sys),
      });

      ix += 62;
    });

    // ── Weapons section (right of systems) ──
    ix += 20;
    ship.weapons.forEach((w, i) => {
      if (!w) return;
      const wy = _H - 74;
      const ww = 130, wh = 42;

      // Weapon card
      const armed = w.armed;
      ctx.fillStyle = armed ? 'rgba(26,255,140,0.12)' : 'rgba(13,17,32,0.9)';
      ctx.beginPath(); ctx.roundRect(ix, wy, ww, wh, 4); ctx.fill();
      ctx.strokeStyle = armed ? '#1aff8c' : (w.powered ? '#ffb020' : '#3a4455');
      ctx.lineWidth = armed ? 2 : 1;
      ctx.stroke();

      // Number + name + power requirement
      ctx.fillStyle = w.unmanned ? '#ff5566' : armed ? '#1aff8c' : '#c8d8f0';
      ctx.font = '10px Share Tech Mono, monospace';
      ctx.textAlign = 'left';
      ctx.fillText(w.unmanned ? `${i+1}· NO CREW!` : `${i+1}· ${w.label.slice(0,12)}`,
                   ix + 6, wy + 14);
      // ⚡cost badge: orange when the module feeds it, grey when starved
      ctx.textAlign = 'right';
      ctx.fillStyle = w.powered ? '#ffb020' : '#4a6080';
      ctx.fillText(`⚡${w.powerCost}`, ix + ww - 5, wy + 14);
      ctx.textAlign = 'left';

      // Charge segments
      const segs = 4;
      const segW2 = (ww - 16) / segs - 3;
      for (let s = 0; s < segs; s++) {
        const filled = w.charge * segs > s;
        const full   = w.charge * segs >= s + 1;
        ctx.fillStyle = full ? (armed ? '#1aff8c' : '#4db8ff')
                      : filled ? 'rgba(77,184,255,0.4)'
                      : 'rgba(30,36,50,0.9)';
        ctx.fillRect(ix + 8 + s * (segW2 + 3), wy + 22, segW2, 12);
      }

      // Click zone to select/fire
      _powerClickZones.push({
        x: ix, y: wy, w: ww, h: wh,
        weapon: i,
      });

      // AUTO toggle button under the card
      const abW = 52, abH = 16;
      const abX = ix + ww/2 - abW/2, abY = wy + wh + 4;
      ctx.fillStyle = w.autoFire ? 'rgba(26,255,140,0.25)' : 'rgba(13,17,32,0.9)';
      ctx.beginPath(); ctx.roundRect(abX, abY, abW, abH, 3); ctx.fill();
      ctx.strokeStyle = w.autoFire ? '#1aff8c' : '#3a4455';
      ctx.lineWidth = 1; ctx.stroke();
      ctx.fillStyle = w.autoFire ? '#1aff8c' : '#7a90a8';
      ctx.font = '9px Share Tech Mono, monospace';
      ctx.textAlign = 'center';
      ctx.fillText(w.autoFire ? 'AUTO ON' : 'AUTO OFF', abX + abW/2, abY + 12);

      _powerClickZones.push({
        x: abX, y: abY, w: abW, h: abH,
        weaponAuto: i,
      });

      ix += ww + 12;
    });
  }

  // ── Panel (dark rounded rect) ─────────────────────────

  function _drawPanel(ctx, x, y, w, h) {
    ctx.fillStyle = 'rgba(13,17,32,0.88)';
    ctx.beginPath();
    ctx.roundRect(x, y, w, h, 6);
    ctx.fill();
    ctx.strokeStyle = 'rgba(30,45,74,0.8)';
    ctx.lineWidth   = 1;
    ctx.stroke();
  }

  function _drawLabelBar(ctx, x, y, w, label, val, max, barColor, labelColor) {
    ctx.fillStyle = labelColor ?? '#4db8ff';
    ctx.font      = '11px Share Tech Mono, monospace';
    ctx.textAlign = 'left';
    ctx.fillText(label, x, y + 10);

    const barX = x + 44, bw = w - 50, bh = 8;
    ctx.fillStyle = '#0a1020';
    ctx.fillRect(barX, y + 2, bw, bh);
    ctx.fillStyle = barColor;
    ctx.fillRect(barX, y + 2, bw * Utils.clamp(val / max, 0, 1), bh);
    ctx.strokeStyle = '#1e2d4a';
    ctx.lineWidth   = 0.5;
    ctx.strokeRect(barX, y + 2, bw, bh);

    // Value text
    ctx.fillStyle = '#c8d8f0';
    ctx.fillText(`${Math.ceil(val)}/${max}`, barX + bw + 4, y + 10);
  }

  function _drawShieldBars(ctx, x, y, bars, max) {
    ctx.fillStyle = '#4a6080';
    ctx.font      = '11px Share Tech Mono, monospace';
    ctx.textAlign = 'left';
    ctx.fillText('SHIELDS', x, y + 9);

    for (let i = 0; i < max; i++) {
      const lit = i < bars;
      ctx.fillStyle = lit ? '#4db8ff' : '#0a1828';
      ctx.beginPath();
      ctx.arc(x + 55 + i * 18, y + 5, 6, 0, Math.PI * 2);
      ctx.fill();
      if (lit) {
        ctx.strokeStyle = '#1a8cff';
        ctx.lineWidth   = 1;
        ctx.stroke();
      }
    }
  }

  // ── Main menu screen ─────────────────────────────────────

  function drawMainMenu(hoverBtn) {
    clear();
    drawBackground(Date.now() * 0.015);

    const ctx = _ctx;
    const cx  = _W / 2, cy = _H / 2;

    // Logo
    ctx.save();
    ctx.shadowBlur  = 24;
    ctx.shadowColor = '#1a8cff';
    ctx.fillStyle   = '#4db8ff';
    ctx.font        = '72px Orbitron, monospace';
    ctx.textAlign   = 'center';
    ctx.fillText('MOON WARS', cx, cy - 140);
    ctx.restore();

    // Subtitle
    ctx.fillStyle = '#4a6080';
    ctx.font      = '11px Share Tech Mono, monospace';
    ctx.textAlign = 'center';
    ctx.fillText('A TACTICAL SPACE SURVIVAL GAME', cx, cy - 108);

    // Buttons
    const buttons = [
      { id: 'new_game',  label: 'NEW GAME' },
      { id: 'continue',  label: 'CONTINUE' },
      { id: 'graveyard', label: 'GRAVEYARD' },
      { id: 'settings',  label: 'SETTINGS' },
    ];

    buttons.forEach((b, i) => {
      const bx = cx - 100, by = cy - 40 + i * 50, bw = 200, bh = 36;
      const hover = hoverBtn === b.id;

      ctx.fillStyle = hover ? 'rgba(26,140,255,0.25)' : 'rgba(13,17,32,0.85)';
      ctx.beginPath(); ctx.roundRect(bx, by, bw, bh, 4); ctx.fill();

      ctx.strokeStyle = hover ? '#4db8ff' : '#1e2d4a';
      ctx.lineWidth   = hover ? 1.5 : 1;
      ctx.stroke();

      ctx.fillStyle = hover ? '#4db8ff' : '#c8d8f0';
      ctx.font      = '14px Orbitron, monospace';
      ctx.textAlign = 'center';
      ctx.fillText(b.label, cx, by + 24);

      // Click regions registered by game.js _registerMenuButtons()
    });

    // Version
    ctx.fillStyle = '#1a2a3a';
    ctx.font      = '11px Share Tech Mono, monospace';
    ctx.textAlign = 'right';
    ctx.fillText('v0.1.0 — MOON WARS', _W - 10, _H - 10);
  }

  const _menuCallbacks = {};
  function onMenuButton(id, cb) { _menuCallbacks[id] = cb; }

  // ── Map screen ───────────────────────────────────────────

  function drawMapScreen(sectorMap, hoverNodeId = null) {
    clear();
    drawBackground(0);

    const ctx = _ctx;
    const ox  = (_W - 700) / 2;   // centered — ship view is separate
    const oy0 = (_H - 400) / 2;
    if (sectorMap && sectorMap.awaitingStartPick) {
      ctx.fillStyle = 'rgba(13,17,32,0.92)';
      ctx.beginPath(); ctx.roundRect(_W/2 - 190, oy0 - 46, 380, 30, 5); ctx.fill();
      ctx.strokeStyle = '#1aff8c'; ctx.lineWidth = 1; ctx.stroke();
      ctx.fillStyle = '#1aff8c';
      ctx.font = '12px Share Tech Mono, monospace';
      ctx.textAlign = 'center';
      ctx.fillText('⟨ CHOOSE YOUR STARTING LANE — TOP · MIDDLE · BOTTOM ⟩',
                   _W/2, oy0 - 26);
    }
    const oy  = (_H - 400) / 2;

    // Background panel
    _drawPanel(ctx, ox - 20, oy - 40, 740, 480);

    // Title
    ctx.fillStyle = '#c8d8f0';
    ctx.font      = '14px Orbitron, monospace';
    ctx.textAlign = 'left';
    ctx.fillText(`SECTOR ${sectorMap.sector} MAP`, ox - 10, oy - 18);

    const run = Save.getRun();
    if (run) {
      ctx.fillStyle = '#ffd700';
      ctx.font      = '13px Share Tech Mono, monospace';
      ctx.fillText(`⬡ ${run.scrap}   FUEL ${run.fuel}`, ox + 450, oy - 18);
    }

    sectorMap.draw(ctx, ox, oy);

    // Hover tooltip
    if (hoverNodeId) {
      const node = sectorMap.getNode(hoverNodeId);
      if (node && !node.locked) {
        const tx = node.x + ox + 24, ty = node.y + oy - 24;
        _drawPanel(ctx, tx, ty, 120, 48);
        ctx.fillStyle = node.color;
        ctx.font      = '14px Orbitron, monospace';
        ctx.textAlign = 'left';
        ctx.fillText(node.label, tx + 8, ty + 16);
        ctx.fillStyle = '#4a6080';
        ctx.font      = '11px Share Tech Mono, monospace';
        ctx.fillText('Click to travel', tx + 8, ty + 32);
      }
    }
  }

  // ── Combat screen layout ─────────────────────────────────

  function drawCombatLayout(playerShip, enemyShip) {
    // Both ships are drawn by their own draw() method;
    // this just handles the "combat arena" background line

    const ctx = _ctx;
    ctx.strokeStyle = 'rgba(30,45,70,0.3)';
    ctx.lineWidth   = 1;
    ctx.setLineDash([6, 6]);
    ctx.beginPath();
    ctx.moveTo(_W / 2, 20);
    ctx.lineTo(_W / 2, _H - 20);
    ctx.stroke();
    ctx.setLineDash([]);
  }

  // ── Retreat progress ─────────────────────────────────────

  function drawRetreatBar(progress) {
    const w  = 200, h = 20;
    const x  = _W / 2 - w / 2, y = _H - 50;
    _drawPanel(_ctx, x - 4, y - 4, w + 8, h + 8);
    _ctx.fillStyle = '#ff7c20';
    _ctx.fillRect(x, y, w * progress, h);
    _ctx.fillStyle = '#c8d8f0';
    _ctx.font      = '12px Share Tech Mono, monospace';
    _ctx.textAlign = 'center';
    _ctx.fillText('RETREATING…', _W / 2, y + 14);
  }

  // ── Event popup ──────────────────────────────────────────

  function drawEventPopup(event, hoverChoice = -1) {
    const ctx = _ctx;
    const W   = 480, H = 240;
    const x   = _W/2 - W/2, y = _H/2 - H/2;

    _drawPanel(ctx, x, y, W, H);

    ctx.fillStyle = '#4db8ff';
    ctx.font      = '15px Orbitron, monospace';
    ctx.textAlign = 'left';
    ctx.fillText(event.title, x + 20, y + 30);

    ctx.fillStyle = '#c8d8f0';
    ctx.font      = '12px Share Tech Mono, monospace';
    // Word-wrap text (simple)
    const words  = event.text.split(' ');
    let line     = '', cy2 = y + 55;
    words.forEach(w => {
      const test = line + w + ' ';
      if (ctx.measureText(test).width > W - 40) {
        ctx.fillText(line, x + 20, cy2); cy2 += 14; line = w + ' ';
      } else { line = test; }
    });
    if (line) { ctx.fillText(line, x + 20, cy2); }

    // Choices
    event.choices.forEach((c, i) => {
      const bx = x + 20, by = y + 150 + i * 36, bw = W - 40, bh = 28;
      const hover = hoverChoice === i;

      ctx.fillStyle = hover ? 'rgba(26,140,255,0.3)' : 'rgba(20,30,50,0.8)';
      ctx.beginPath(); ctx.roundRect(bx, by, bw, bh, 4); ctx.fill();
      ctx.strokeStyle = hover ? '#4db8ff' : '#1e2d4a';
      ctx.lineWidth   = 1;
      ctx.stroke();

      ctx.fillStyle = hover ? '#4db8ff' : '#c8d8f0';
      ctx.font      = '12px Share Tech Mono, monospace';
      ctx.textAlign = 'left';
      ctx.fillText(c.label, bx + 10, by + 18);

      // Click regions registered by game.js _registerEventChoices()
    });
  }

  const _eventCallbacks = {};
  function onEventChoice(idx, cb) { _eventCallbacks[idx] = cb; }

  // ── Victory / defeat splash ───────────────────────────────

  function drawOutcome(type, scrap = 0) {
    const ctx = _ctx;
    const cx  = _W / 2;

    ctx.fillStyle = 'rgba(7,8,15,0.75)';
    ctx.fillRect(0, 0, _W, _H);

    const isVictory = type === 'victory';
    ctx.fillStyle = isVictory ? '#1aff8c' : '#ff2d44';
    ctx.font      = '48px Orbitron, monospace';
    ctx.textAlign = 'center';
    ctx.fillText(isVictory ? 'VICTORY' : 'SHIP DESTROYED', cx, _H/2 - 40);

    if (isVictory && scrap > 0) {
      ctx.fillStyle = '#ffd700';
      ctx.font      = '16px Share Tech Mono, monospace';
      ctx.fillText(`+⬡${scrap} SCRAP COLLECTED`, cx, _H/2 + 10);
    }

    ctx.fillStyle = '#4a6080';
    ctx.font      = '12px Share Tech Mono, monospace';
    ctx.fillText('Press [SPACE] to continue', cx, _H/2 + 50);
  }

  // ── Public API ───────────────────────────────────────────

  return {
    init, getCtx, getWidth, getHeight,
    clear,
    drawBackground,
    drawNebula,
    drawHUD,
    getPowerClickZones,
    drawMainMenu,
    drawMapScreen,
    drawCombatLayout,
    drawRetreatBar,
    drawEventPopup,
    drawOutcome,
    onMenuButton,
    onEventChoice,
  };

})();
