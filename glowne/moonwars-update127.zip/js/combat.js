/* ============================================================
   MOON WARS — combat.js
   Battle state machine.
   Manages the combat loop between player and enemy ship:
   enemy AI targeting, auto-fire, boarding, retreat logic.
   ============================================================ */

'use strict';

// ── Combat state ──────────────────────────────────────────

const COMBAT_STATE = {
  IDLE:      'idle',       // no combat
  ENTERING:  'entering',   // ships flying in
  ACTIVE:    'active',     // combat ongoing
  VICTORY:   'victory',    // player won
  DEFEAT:    'defeat',     // player lost
  RETREATING:'retreating', // player is retreating
  ENEMY_FLED:'enemy_fled', // the ENEMY escaped
  FLED:      'fled',       // escaped
};

/* ── AN ASTEROID FIELD (update100, package C) ─────────────────
 *
 * jj: a condition of the fight on a node, like the nebula — every so
 * often a rock comes in and can hit a module. It falls on BOTH ships,
 * as the nebula starves both reactors. A rock is an ordinary projectile
 * with its own def, so everything a hit already does — evasion, the
 * bubble, the plate, a breach, a man in the room — happens to it the
 * same way, through `Ship.receiveHit`, and no second damage path exists.
 *
 * It is warned: `WARN` seconds before a rock, the room it will hit is
 * known (`asteroids.warn`) and drawn, so a crew can step out of it.
 * The state lives HERE, cleared by begin() and end() — a flag in game.js
 * would have to be remembered at every exit from a fight (the nebula's
 * `_nebulaCombat` is cleared in six places).
 */
const ASTEROID = {
  FIRST:    [5, 8],          // seconds to the first rock
  INTERVAL: [7, 12],         // between rocks
  WARN:     1.6,             // the target is shown this long before
  SPEED:    240,
  PLAYER_SHARE: 0.5,         // the rock falls on us half the time
  DEF: {
    label: 'Asteroid', type: 'asteroid',
    damage: 1, hull_damage: 1, moduleDamage: 1, shieldDamage: 1,
    pierceShields: false, breachChance: 0.3, crewDamage: [5, 15],
  },
};

// ── Enemy AI difficulty levels ────────────────────────────

const AI_DEFS = {
  easy:   { fireDelay: 1.5, targetRandom: 0.6, retreatHull: 0 },
  normal: { fireDelay: 1.0, targetRandom: 0.3, retreatHull: 0 },
  hard:   { fireDelay: 0.7, targetRandom: 0.1, retreatHull: 0 },
  boss:   { fireDelay: 0.5, targetRandom: 0.0, retreatHull: 0 },
};

class Combat {
  constructor() {
    this.state        = COMBAT_STATE.IDLE;
    this.playerShip   = null;
    this.enemyShip    = null;

    // All in-flight projectiles across both ships
    this._projectiles = [];

    // Enemy AI
    this._ai           = AI_DEFS.normal;
    this._aiFireTimers = [];    // one per enemy weapon
    this._aiTargetRoom = null;  // which player room AI is aiming at

    // Retreat
    this._retreatTimer = 0;
    this._retreatCost  = 0;   // fuel cost

    // Enter animation
    this._enterTimer   = 0;
    this._enterDone    = false;

    // Outcome
    this.scrapReward   = 0;
    this.weaponDrop    = null;

    // Timers
    this._stateTimer   = 0;
  }

  // ── Start / stop ─────────────────────────────────────────

  begin(playerShip, enemyShip, difficulty = 'normal') {
    this.state       = COMBAT_STATE.ENTERING;
    this.playerShip  = playerShip;
    this.enemyShip   = enemyShip;
    this._ai         = AI_DEFS[difficulty] || AI_DEFS.normal;
    this._projectiles = [];
    if (typeof WeaponArt !== 'undefined') WeaponArt.clear();   // no scorch from the last fight
    this._enterTimer  = 0;
    this._stateTimer  = 0;

    // A NEW BATTLE, for both hulls: re-lock every door against boarders
    // and put one more action on every living crew member's record.
    // This is the single place every fight passes through exactly once.
    [playerShip, enemyShip].forEach(sh => sh?.onBattleStart?.());
    /* A fight owes the commander a little knowledge back when it ends
       (update98) — once, however it ends. Set here, the one place
       every fight starts; paid in end(), the one place they all stop. */
    this._knowledgeDue = true;
    /* No field until the fight says so (`startAsteroidField`). */
    this.asteroids = null;

    // Initialise AI fire timers
    this._aiFireTimers = enemyShip.weapons.map(() => 0);

    /* Surrender machinery (rebuilt update62).
       `_hullRolled` is the ONE hull roll; `_surrenderMade` is whether a
       decision was actually put to the player. They are separate on
       purpose: a hull roll that comes up short must not stop a crew
       that is later beaten off its feet from striking. */
    this._hullRolled       = false;
    this._surrenderMade    = false;
    this.surrenderOffer    = false;
    // Their hull is intact and nobody has been told otherwise yet.
    this.enemyDown        = false;
    this._boardersNotice  = false;

    // Escape machinery
    this.RETREAT_TIME       = 9.0;   // player jump spool-up
    this._escapeRolled      = false;
    this._aloneRolled       = false;   // update127: the last man runs, once
    this.enemyEscapeActive  = false;
    this._enemyEscapeT      = 0;
    this.ENEMY_ESCAPE_TIME  = 11.0;
    this._escapeNotice      = false; // one-shot flag for the game layer
    /* The wreckage of the LAST fight is not this one's (update93b). */
    this.salvage            = null;
    this._salvageRolled     = false;   // the wreckage is rolled once per fight
    this._downHandled       = false;   // and their hull going is handled once
    /* WHY THEY RUN (update93): 'hull' — beaten below 45%; 'stalemate'
       — STALEMATE_SECONDS without hurting us. The player's rule:
       "wróg ucieka po 60 s bez zadanych obrażeń". */
    this.escapeWhy          = null;
    this.STALEMATE_SECONDS  = 60;
    this._noHarmT           = 0;
    this._harmSeen          = (typeof Ship !== 'undefined' && Ship.harmToPlayer) ? Ship.harmToPlayer() : 0;

    // Random scrap reward
    const sector = Save.getRun()?.sector ?? 1;
    this.scrapReward = Utils.randInt(10 + sector * 5, 30 + sector * 10);
    this.weaponDrop  = Math.random() < 0.25 ? randomWeaponDrop(sector) : null;

    Audio.playMusic('combat');
  }

  end() {
    /* KNOWLEDGE COMES BACK AFTER A FIGHT (update98): a share of the
       pool (Commander.KNOWLEDGE_AFTER_FIGHT), never during one. */
    if (this._knowledgeDue) {
      this._knowledgeDue = false;
      const cap = (typeof Commander !== 'undefined') ? Commander.active() : null;
      if (cap) {
        const got = Commander.refillKnowledge(cap, Commander.KNOWLEDGE_AFTER_FIGHT);
        if (got > 0 && typeof UI !== 'undefined') {
          UI.notify(`${cap.name} gathers himself — knowledge +${got}.`, 'info');
        }
      }
    }
    this._projectiles = [];
    this.state        = COMBAT_STATE.IDLE;
    this.playerShip   = null;
    this.enemyShip    = null;
    this.asteroids    = null;           // the field ends with the fight
    Audio.stopMusic(1.5);
  }

  /* ── The asteroid field ─────────────────────────────────── */

  /** Make this fight one fought in an asteroid field. */
  startAsteroidField() {
    this.asteroids = { t: Utils.randFloat(ASTEROID.FIRST[0], ASTEROID.FIRST[1]),
                       warn: null, rocks: 0 };
    return this.asteroids;
  }

  /** Where the next rock will fall: a side and a room, or null. */
  _pickRockTarget() {
    const sides = [];
    if (this.playerShip && !this.playerShip.destroyed && this.playerShip.hull > 0) sides.push('player');
    if (this.enemyShip && !this.enemyShip.destroyed && this.enemyShip.hull > 0) sides.push('enemy');
    if (!sides.length) return null;
    const side = sides.length === 1 ? sides[0]
               : (Math.random() < ASTEROID.PLAYER_SHARE ? 'player' : 'enemy');
    const ship = side === 'player' ? this.playerShip : this.enemyShip;
    const rooms = (ship.rooms ?? []).filter(r => r && r.w > 0 && r.h > 0);
    if (!rooms.length) return null;
    return { side, roomId: Utils.pick(rooms).id };
  }

  _updateAsteroids(dt) {
    const A = this.asteroids;
    if (!A) return;
    A.t -= dt;
    if (!A.warn && A.t <= ASTEROID.WARN) A.warn = this._pickRockTarget();
    if (A.t > 0) return;
    const w = A.warn || this._pickRockTarget();
    A.warn = null;
    A.t = Utils.randFloat(ASTEROID.INTERVAL[0], ASTEROID.INTERVAL[1]);
    if (!w) return;
    const ship = w.side === 'player' ? this.playerShip : this.enemyShip;
    const room = ship?.getRoomById?.(w.roomId);
    if (!room || ship.destroyed || ship.hull <= 0) return;
    const tx = room.cx, ty = room.cy;
    const p = new Projectile({
      x: tx + Utils.randFloat(-260, 260), y: -40, targetX: tx, targetY: ty,
      speed: ASTEROID.SPEED, type: 'asteroid', def: ASTEROID.DEF,
      /* `fromPlayer` decides WHICH hull receives it (_updateProjectiles):
         a rock for the enemy travels as if we had fired it. */
      fromPlayer: w.side === 'enemy',
    });
    p.fromField = true;            // a rock is nobody's shot (Ship.receiveHit)
    this._projectiles.push(p);
    A.rocks++;
  }

  initiateRetreat(fuelCost = 1) {
    if (this.state !== COMBAT_STATE.ACTIVE) return false;
    this.state         = COMBAT_STATE.RETREATING;
    this._retreatTimer = 0;
    this._retreatTimer = 0;
    this._retreatCost  = fuelCost;
    return true;
  }

  // ── Update ───────────────────────────────────────────────

  update(dt) {
    if (this.state === COMBAT_STATE.IDLE) return;

    this._stateTimer += dt;

    switch (this.state) {
      case COMBAT_STATE.ENTERING:   this._updateEntering(dt);   break;
      case COMBAT_STATE.ACTIVE:     this._updateActive(dt); this._updateAsteroids(dt); break;
      case COMBAT_STATE.RETREATING: this._updateRetreating(dt); break;
      case COMBAT_STATE.VICTORY:
      case COMBAT_STATE.DEFEAT:     /* handled by Game */        break;
    }

    // Always update projectiles
    this._updateProjectiles(dt);
  }

  _updateEntering(dt) {
    this._enterTimer += dt;
    if (this._enterTimer >= 1.5) {
      this.state = COMBAT_STATE.ACTIVE;
    }
  }

  _updateActive(dt) {
    if (!this.playerShip || !this.enemyShip) return;

    // Check win/lose. Hull gone = defeat outright. "No crew aboard"
    // is NOT decided here — the player may have sent everyone on a
    // boarding action; game.js owns that check because it can see the
    // boarding party and crew fighting on the enemy hull.
    if (this.playerShip.hull <= 0 || this.playerShip.destroyed) {
      this.state = COMBAT_STATE.DEFEAT;
      Audio.playMusic('explore');
      return;
    }
    /* THE HULL IS NOT THE BATTLE (update54).
     *
     * Victory used to be declared the instant the enemy hull reached
     * zero — while their boarding party was still swinging axes in our
     * medbay. The fight ended, the loot screen came up, and the men on
     * our deck were tidied away by the machinery rather than beaten.
     * A player who REFUSES a surrender and then blows the ship apart
     * had, in effect, won by pressing the button they were already
     * pressing.
     *
     * So: the ship dies when its hull dies — it explodes, it stops
     * shooting, there is nothing left to shoot back at — but the
     * BATTLE ends only once nobody of theirs is left standing on our
     * deck. Two separate facts, and the second one is the one the
     * victory screen waits on.
     */
    if (this.enemyShip.hull <= 0 || this.enemyShip.destroyed) {
      if (!this.enemyDown) {
        this.enemyDown = true;
        this.enemyShip.destroyed = true;
        Particles.explosion(
          this.enemyShip.worldX + this.enemyShip.spriteW / 2,
          this.enemyShip.worldY + this.enemyShip.spriteH / 2,
          2.0
        );
        Audio.sfx.explosion();
        Camera.shake(16, 0.6);
      }
      if (!this.intrudersAboard()) {
        this._onVictory();
        return;
      }
      if (!this._boardersNotice && typeof UI !== 'undefined') {
        this._boardersNotice = true;
        UI.notify('Their ship is gone — but their boarders are still aboard. Clear the decks!', 'alert');
      }
      /* A wreck does not aim. Everything below this line is the enemy
         SHIP acting, and it has stopped being a ship. */
      return;
    }

    /* ── BEATEN, TWO WAYS, ONE DECISION (update62) ──────────
     *
     * A ship is beaten when its HULL is nearly gone, or when nobody
     * aboard it can still fight. The second one used to lead nowhere:
     * you could kill every hand on their deck and be offered nothing,
     * because the only trigger in the game read the hull. That is the
     * hole a boarding party fell into — clearing their decks was just
     * a slower gun.
     *
     * Both roads end at `_raiseSurrender`, so there is exactly one
     * place that decides a surrender is on the table, one flag the
     * game layer reads, and no way for the two to disagree.
     */
    if (!this._surrenderMade && !this._hullRolled &&
        this._ai !== AI_DEFS.boss &&
        this.enemyShip.hull <= this.enemyShip.hullMax * 0.3) {
      this._hullRolled = true;
      if (this.noQuarter()) {
        /* NO QUARTER, AND HE IS TOLD WHY (update62). An offer that
           silently never comes is indistinguishable from a broken
           game, so the reason is said out loud, once, at the moment
           they would have struck. */
        if (typeof UI !== 'undefined') {
          UI.notify('They will not surrender to you. They know what you do to prisoners.', 'alert');
        }
      } else if (Math.random() < this.surrenderOdds()) {
        this._raiseSurrender();
      }
    }

    // …or try to RUN: needs their cockpit + engines alive. Rolled once
    // at ≤45% hull; never the boss, never while offering surrender.
    /* NOT A WRECK (update90b). A hulk's hull is always under 45%, so it
       rolled to run like a beaten ship and the player saw "FTL SPOOLING"
       over a derelict — a dead cockpit kept it from ever leaving, but the
       warning was a lie. Since 90a it has a working engine level too. */
    /* Nothing on the ground jumps away (update94): bunkers and mechs. */
    const grounded = !!this.enemyShip.layout?.grounded;
    if (!this._escapeRolled && !this.enemyShip.isDerelict && !grounded &&
        this.enemyShip.hull <= this.enemyShip.hullMax * 0.45) {
      this._escapeRolled = true;
      if (this._ai !== AI_DEFS.boss && !this.surrenderOffer && Math.random() < 0.45) {
        this.enemyEscapeActive = true;
        this._enemyEscapeT     = 0;
        this._escapeNotice     = true;
        this.escapeWhy         = 'hull';
      }
    }
    /* ── A FIGHT THEY CANNOT WIN, THEY LEAVE (update93) ────────
     * Sixty seconds of nothing landing on us — a shot that reaches the
     * hull, a module or a man, or a blow from one of their boarders —
     * and they spool the drive. The same escape as the hull roll: the
     * same 11 s, the same bar, the same counter (kill the cockpit or
     * the engines). Never the boss, never a wreck, never while a
     * surrender is on the table. The clock waits while it is. */
    if (this._ai !== AI_DEFS.boss && !this.enemyShip.isDerelict && !grounded && !this.enemyEscapeActive) {
      const seen = (typeof Ship !== 'undefined' && Ship.harmToPlayer) ? Ship.harmToPlayer() : 0;
      if (seen !== this._harmSeen) { this._harmSeen = seen; this._noHarmT = 0; }
      else if (!this.surrenderOffer) this._noHarmT += dt;
      if (this._noHarmT >= this.STALEMATE_SECONDS) {
        this.enemyEscapeActive = true;
        this._enemyEscapeT     = 0;
        this._escapeNotice     = true;
        this.escapeWhy         = 'stalemate';
      }
    }
    /* ── THE LAST MAN RUNS (update127, jj) ──────────────────────
     * One of theirs left alive, anywhere — the rest dead or taken —
     * and he spools the drive, whatever the hull says. Same bar, same
     * counter: kill the cockpit or the engines. Not the boss, not a
     * wreck, not on the ground, not while a surrender is on the table. */
    if (this._ai !== AI_DEFS.boss && !this.enemyShip.isDerelict && !grounded &&
        !this.enemyEscapeActive && !this.surrenderOffer && !this._aloneRolled) {
      const left = this.enemyShip.crew.filter(c => c.alive && !c.isPet && !c.isPrisoner && !c.isPlayer && !c.isPest);
      const away = (typeof Ship !== 'undefined') && this.playerShip?.crew?.some(c => c.alive && !c.isPlayer && !c.isPrisoner);
      if (left.length === 1 && !away) {
        this._aloneRolled      = true;
        this.enemyEscapeActive = true;
        this._enemyEscapeT     = 0;
        this._escapeNotice     = true;
        this.escapeWhy         = 'alone';
      }
    }
    if (this.enemyEscapeActive) {
      const ep = this.enemyShip.getSystem('piloting');
      const ee = this.enemyShip.getSystem('engines');
      const eok = ep && ee && !ep.isDisabled() && !ee.isDisabled();
      /* SOMEBODY HAS TO BE AT THE HELM (update127) — the rule our own jump
         keeps ("Nobody at the helm"). An empty cockpit HOLDS the spool
         rather than resetting it: a pilot off fixing the engines comes
         back to the bar where he left it. */
      const op = ep && this.enemyShip.consoleOperator ? this.enemyShip.consoleOperator(ep.roomId) : null;
      const helm = !!op && !op.isPlayer && !op.isPrisoner;
      if (!eok) {
        // Max-damaged drive = their charge resets; repairs restart it
        this._enemyEscapeT = 0;
      } else if (!helm) {
        /* held — nobody to fly her */
      } else if (typeof Chips !== 'undefined' && Chips.running('cone')) {
        /* FOUNDATION CONE (update102): anchored — their drive spools
           no further while it holds, but keeps what it had. */
      } else {
        this._enemyEscapeT += dt;
        if (this._enemyEscapeT >= this.ENEMY_ESCAPE_TIME) {
          this.state = COMBAT_STATE.ENEMY_FLED;
          return;
        }
      }
    }

    // Enemy AI
    this._updateAI(dt);
  }

  _updateRetreating(dt) {
    // Escape needs a WORKING cockpit and engines the whole time.
    // Knock-out of either resets the charge — repair and start over.
    const pil = this.playerShip.getSystem('piloting');
    const eng = this.playerShip.getSystem('engines');
    const ok  = pil && eng && !pil.isDisabled() && !eng.isDisabled() &&
                pil.effectivePower() > 0 && eng.effectivePower() > 0;
    if (!ok) {
      if (this._retreatTimer > 0 && typeof UI !== 'undefined') {
        UI.notify('Jump charge LOST — drive systems down!', 'alert');
      }
      this._retreatTimer = 0;
    } else {
      /* FLANK SPEED spools the jump at double time (update53). It
         goes through Commander.orderBonus like every other running
         order, so there is no second place a jump can be hurried
         from — and the bonus is 0 whenever nothing is running. */
      const flank = (typeof Commander !== 'undefined' && Commander.orderBonus)
        ? (Commander.orderBonus('jump') > 0 ? 2 : 1) : 1;
      this._retreatTimer += dt * flank;
      if (this._retreatTimer >= this.RETREAT_TIME) {
        /* Running burns He2 out of the CELLS in the hold (update39),
           the same as any jump — there is no tank behind them to
           quietly cover the cost. */
        const hold = this.playerShip?.cargo;
        if (hold) {
          hold.takeStack('fuel', this._retreatCost);
          Save.updateRun({ fuel: hold.countOf('fuel') });
        } else {
          const run = Save.getRun();
          if (run) Save.updateRun({ fuel: Math.max(0, run.fuel - this._retreatCost) });
        }
        this.state = COMBAT_STATE.FLED;
        return;
      }
    }
    // The battle rages on while the drive spools — enemy AI, win/lose
    // checks, surrender and escape rolls all keep running.
    this._updateActive(dt);
  }

  _onVictory() {
    this.state = COMBAT_STATE.VICTORY;
    // They died mid-escape: clear the spool-up so the "ENEMY ESCAPING"
    // bar and the warning marker over their hull don't linger on a
    // wreck for the rest of the victory screen.
    this.enemyEscapeActive = false;
    this._enemyEscapeT     = 0;
    this._escapeNotice     = false;

    // Award scrap to run
    const run = Save.getRun();
    if (run) {
      Save.updateRun({ scrap: run.scrap + this.scrapReward });
    }

    /* No blanket combat XP any more (update38).
     *
     * `combat` is the hand-to-hand skill. Handing 15 of it to EVERY
     * crew member for winning a gunnery duel taught the whole ship to
     * punch without anybody throwing a punch — and because a mastered
     * skill burns one of the three mastery slots, it quietly stole the
     * slot a gunner needed for `weapons`. Melee grants it, per swing,
     * to the man who swung (CrewMember.creditMeleeSwing) and nothing
     * else does. Gunners are already paid in `weapons` XP per shot. */

    /* The blast belongs to the HULL dying, and _updateActive already
       set it off at that moment. Firing it again here would explode a
       ship that has been a wreck for the length of a boarding fight. */
    if (!this.enemyDown) {
      Particles.explosion(
        this.enemyShip.worldX + this.enemyShip.spriteW / 2,
        this.enemyShip.worldY + this.enemyShip.spriteH / 2,
        2.0
      );
      Audio.sfx.explosion();
      Camera.shake(16, 0.6);
    }
    Audio.playMusic('explore');
  }

  // ── Enemy AI ──────────────────────────────────────────────

  /**
   * IS ANYBODY OF THEIRS STILL ON OUR DECK? (update54)
   *
   * One predicate, and it is the only thing that keeps a battle open
   * once the enemy hull is gone. Vermin do not count — a rat in the
   * duct is a chore, not a boarding party — and since update84 they
   * are not in the crew list at all, so nothing here has to say so.
   */
  intrudersAboard() {
    const p = this.playerShip;
    if (!p) return false;
    if (p.crew.some(c => c && c.alive && !c.isPlayer)) return true;
    /* AND THE ONES STILL IN THE VOID (update55). A boarder who has left
       his airlock and not yet reached ours belongs to NEITHER crew list
       — game.js owns the parties — so asking only the deck declared the
       battle won while an axe party was drifting towards us. game.js
       installs this counter at boot; the default keeps the class usable
       on its own. */
    return this.inFlightIntruders() > 0;
  }

  /** Overridden by game.js, which owns the boarding parties. */
  inFlightIntruders() { return 0; }

  /**
   * THE ODDS A BEATEN CREW STRIKES TO *THIS* COMMANDER (update62).
   *
   * One number, read from karma, used by both roads to a surrender —
   * the hull roll below and the cleared-decks branch in game.js. The
   * 0.5 fallback is exactly the flat roll this replaced, so a build
   * without commander.js behaves as it always did.
   */
  surrenderOdds() {
    return (typeof Commander !== 'undefined' && Commander.surrenderChance)
      ? Commander.surrenderChance() : 0.5;
  }

  /** True when nobody will ever surrender to him. The one predicate
   *  both roads ask, so they cannot disagree about who gets mercy. */
  noQuarter() { return this.surrenderOdds() <= 0; }

  /** The single door to a surrender offer. */
  _raiseSurrender() {
    this._surrenderMade = true;
    this.surrenderOffer = true;
  }

  _updateAI(dt) {
    const enemy  = this.enemyShip;
    const player = this.playerShip;

    // A hot core gets power taken off it (update93) — see Ship.coolingAI.
    enemy.coolingAI?.(dt);
    // …and puts back the units it lost to anything but heat (update127).
    enemy.rePowerAI?.(dt);

    // Pick target room (change occasionally)
    if (!this._aiTargetRoom || Math.random() < 0.005) {
      if (Math.random() < this._ai.targetRandom) {
        this._aiTargetRoom = Utils.pick(player.rooms);
      } else {
        // Prefer shields, then a RANDOM weapon module, then the reactor
        const wRooms = player.rooms.filter(r => r.type === 'weapons');
        this._aiTargetRoom =
          player.rooms.find(r => r.type === 'shields' && r.system) ||
          (wRooms.length ? Utils.pick(wRooms) : null) ||
          player.rooms.find(r => r.type === 'reactor') ||
          Utils.pick(player.rooms);
      }
    }

    // Fire each armed enemy weapon
    enemy.weapons.forEach((w, i) => {
      if (!w || !w.armed) return;

      this._aiFireTimers[i] = (this._aiFireTimers[i] ?? 0) + dt;
      if (this._aiFireTimers[i] < this._ai.fireDelay) return;
      this._aiFireTimers[i] = 0;

      // Their guns leave their barrels too (update80) — the same
      // function, so the rule is not "the player's side looks right".
      const eb = enemy.roomBounds ? enemy.roomBounds() : { x: enemy.worldX, y: enemy.worldY, w: 300, h: 200 };
      const em = enemy.muzzleFor ? enemy.muzzleFor(w) : null;
      const fromX = em ? em.x : eb.x - 10;
      const fromY = em ? em.y : eb.y + eb.h / 2;
      const toX   = this._aiTargetRoom.cx;
      const toY   = this._aiTargetRoom.cy;

      const projs = w.fire(fromX, fromY, toX, toY, false);
      Particles.muzzleFlash?.(fromX, fromY, -1, '#ff8a6a');
      this._projectiles.push(...projs);
    });

    // ── Enemy cloak ──
    //  Fire it when it actually saves them: a shot of ours in the air
    //  (update93a — it used to fire on a wounded hull with nothing
    //  coming, wasting the cooldown).
    {
      const cl = enemy.getSystem('cloaking');
      /* ONLY AGAINST A SHOT IN THE AIR (update93a). The player: the
         computer should cloak when it is ready AND he has fired — not
         the moment its hull dips under two thirds with nothing coming
         at it, which burnt the cooldown on empty space. */
      /* …but not while the Eye of Horus is on him (update101). */
      const watched = typeof Chips !== 'undefined' && Chips.running('horus');
      if (cl && cl.cloakReady && !watched) {
        const incoming  = this._projectiles.some(p => p.fromPlayer && !p.done && !p.flyOn);
        if (incoming) {
          if (cl.activateCloak() && typeof UI !== 'undefined') {
            UI.notify('⚠ Enemy CLOAKED — your shots will miss!', 'warn');
          }
        }
      }
    }

    // Enemy crew AI — dispatch exactly ONE crew member per problem,
    // picking the closest (repair skill breaks ties).
    /* ── THE POSTS THAT FIGHT STAY MANNED (update97) ──────────────
     *
     * jj watched all three of an enemy's crew go off repairing while the
     * cockpit, the gun and the shield console stood empty — the ship
     * stopped fighting the moment it took damage. The old rule kept the
     * pilot and the LAST gunner only while somebody else was idle, so
     * when the spare hand was busy it pulled them anyway.
     *
     * Now the man at each of the three posts that fight — the helm, each
     * gun that has a barrel on it, the shield console — is NOT a repair
     * hand. Whoever is left over repairs and fights fires. The one thing
     * that may pull a man off a post is the reactor (everything runs on
     * it) or a fire, and then only the shield man, never the helm and
     * never the last gun. A man at a post still fixes HIS OWN module in
     * place, as before. */
    const pilotRoomId = enemy.getSystem('piloting')?.roomId ?? null;
    const shieldRoomId = enemy.getSystem('shields')?.roomId ?? null;
    const wpnRoomIds = enemy.weaponRooms.filter((r, i) => enemy.weapons[i]).map(r => r.id);
    const postOf = (c) => {
      if (c.roomId === pilotRoomId && enemy.consoleOperator?.(pilotRoomId) === c) return 'helm';
      if (wpnRoomIds.includes(c.roomId) && enemy.consoleOperator?.(c.roomId) === c) return 'gun';
      if (c.roomId === shieldRoomId && enemy.consoleOperator?.(shieldRoomId) === c) return 'shields';
      return null;
    };
    const gunnersNow = enemy.crew.filter(c => c.alive && postOf(c) === 'gun').length;
    const pickBest = (x, y, skill, urgent = false) => {
      // Spiders do NOT crew the hulk they nest in. They were being
      // dispatched to repair modules and fight fires like a proper crew,
      // which is exactly what a nest would never do.
      /* Not a prisoner, and not one of OURS standing on their deck (update107,
         jj): a captive thawed out of their bay was handed a repair job here. */
      const idle = enemy.crew.filter(c => c.task === TASK.IDLE && c.alive && !c.isPet && !c._healing
                                       && !c.isPrisoner && !c.isPlayer);
      if (!idle.length) return null;
      let pool = idle.filter(c => !postOf(c));
      /* Nobody spare: only the reactor or a fire may take the shield man
         off his console — never the helm, never the last gun. */
      if (!pool.length && urgent) {
        pool = idle.filter(c => postOf(c) === 'shields' ||
                                (postOf(c) === 'gun' && gunnersNow > 1));
      }
      /* ── NOBODY SPARE AT ALL: A POST GOES (update127, jj) ─────────
       * "przeciwnik zawsze powinien starać się naprawić i uciec — dał
       * abordaż jednego załoganta, zostawił pilota i on nic nie robi,
       * czeka na śmierć". With every hand aboard sitting at a post, the
       * update97 rule meant a broken ship was never fixed by anybody.
       * Now, when there is not a single man off a post anywhere on
       * their deck and nobody is repairing yet, the nearest post-holder
       * goes — one at a time — and walks back when the job is done. */
      if (!pool.length) {
        const aboard = (c) => c.alive && !c.isPet && !c.isPrisoner && !c.isPlayer && enemy.getRoomById(c.roomId);
        const spare = enemy.crew.some(c => aboard(c) && !postOf(c));
        const fixing = enemy.crew.some(c => c.alive && c.task === TASK.REPAIR);
        if (!spare && !fixing) pool = idle.slice();
      }
      if (!pool.length) return null;
      pool.sort((a, b) => {
        const da = Utils.dist(a.x, a.y, x, y);
        const db = Utils.dist(b.x, b.y, x, y);
        if (Math.abs(da - db) > 40) return da - db;          // clearly closer wins
        return b.getSkillLevel(skill) - a.getSkillLevel(skill); // tie → better skill
      });
      return pool[0];
    };

    /* ── A WOUNDED MAN GOES TO THE WARD (update97) ───────────────
     * jj: an enemy hand down to 40% walked about with a working medbay
     * on board and never used it. Below ENEMY_HEAL_AT of his hit points
     * he walks there himself — when the bay works, and when the ship is
     * not burning or holed (those come first). Healed to ENEMY_HEALED,
     * or the bay goes dark, he walks back to his post. */
    {
      const med = enemy.getSystem('medbay');
      const medRoom = med ? enemy.getRoomById(med.roomId) : null;
      const bayOk = !!medRoom && !med.isDisabled();
      const calm = !enemy.fires.fires.some(f => !f.out) &&
                   !(enemy.breaches?.breaches ?? []).some(b => !b.sealed);
      const alive = enemy.crew.filter(c => c.alive && !c.isPet && !c.isPrisoner && !c.down && !c.dying);
      alive.forEach(c => {
        const frac = c.hp / Math.max(1, c.maxHp);
        if (c._healing) {
          if (frac >= ENEMY_HEALED || !bayOk) {
            c._healing = false; c._healRoomId = null;
            const home = enemy.getRoomById(c.homeRoomId);
            if (home) c.moveToOnShip(enemy, ...enemy.stationSpot(home, null, c));
          }
          return;
        }
        if (!bayOk || !calm || frac >= ENEMY_HEAL_AT || alive.length < 2) return;
        if (c.task !== TASK.IDLE) return;
        c._healing = true; c._healRoomId = medRoom.id;
        if (c.roomId !== medRoom.id) c.moveToOnShip(enemy, ...enemy.stationSpot(medRoom, null, c));
      });
    }

    /* ZERO-G MOVES THE ENGINES UP THE LIST (update91) — first pick of the
       idle hands, nothing more. The AI is not forced to fix them first:
       a man already in another room still fixes that room, and a fire is
       still a fire. */
    /* THE REACTOR FIRST, ALWAYS (update93a) — every other module runs
       on it, and a crew that fixes a gun while the core is down fixes
       nothing. In Zero-G the engines come right after it. */
    const rank = (s) => s.type === 'reactor' ? 0 : (enemy.zeroG && s.type === 'engines') ? 1 : 2;
    const repairOrder = [...enemy.systems].sort((a, b) => rank(a) - rank(b));
    repairOrder.forEach(sys => {
      if (sys.damagedLevels <= 0) return;
      // Someone already on it? Skip.
      const busy = enemy.crew.some(c =>
        !c.dead && !c.dying &&
        c.task === TASK.REPAIR && c.taskTarget === sys.roomId);
      if (busy) return;
      // Someone already standing in that room? They'll auto-repair it
      // (this keeps the pilot fixing his own cockpit without backup).
      const inRoom = enemy.crew.some(c => c.alive && !c.isPet && c.roomId === sys.roomId);
      if (inRoom) return;
      const best = pickBest(sys.cx, sys.cy, 'repair', sys.type === 'reactor');
      if (best) {
        best._offPost = best.homeRoomId ?? null;   // he comes back to it (below)
        best.moveToOnShip(enemy, sys.cx, sys.cy);
        best.assignTask(TASK.REPAIR, sys.roomId);
      }
    });

    /* A MAN SENT TO REPAIR GOES BACK TO HIS POST (update127) — the job
       done, idle, not wounded: straight to his own console. Left to the
       idle wander he sometimes got there and sometimes did not. */
    enemy.crew.forEach(c => {
      if (c._offPost == null || !c.alive || c.task !== TASK.IDLE || c._healing) return;
      if (c._waypoints?.length) return;
      const home = enemy.getRoomById(c._offPost);
      c._offPost = null;
      if (home && c.roomId !== home.id) c.moveToOnShip(enemy, ...enemy.stationSpot(home, null, c));
    });


    enemy.fires.fires.forEach(fire => {
      if (fire.out) return;
      const busy = enemy.crew.some(c =>
        c.task === TASK.FIRE && c.taskTarget === fire);
      if (busy) return;
      const best = pickBest(fire.x, fire.y, 'firefight', true);
      if (best) {
        best.moveToOnShip(enemy, fire.x, fire.y);
        best.assignTask(TASK.FIRE, fire);
      }
    });
  }

  // ── Projectile management ─────────────────────────────────

  /**
   * Player fires a weapon at the enemy.
   * @param {Weapon} weapon
   */
  /**
   * @param {Weapon} weapon
   * @param {Room|null} targetRoom - specific enemy room, or null = random
   */
  /**
   * WHY THIS GUN WILL NOT FIRE — or null if it will (update59).
   *
   * ONE implementation, and it is published, because three different
   * places need the same answer: `playerFire` refuses with it, game.js
   * SAYS it to the player, and the HUD greys the card with it. Before
   * this, `playerFire` simply `return`ed on an empty rack — no message,
   * no mark on the card, nothing. A Hull Cannon (missileUse: 1) that
   * ran the warheads out looked charged, powered and manned, and
   * clicking an enemy room did NOTHING, for the rest of that fight and
   * every fight after it. The player reported exactly that and it cost
   * him the run.
   *
   * Same rule as the special orders in update53: an action that refuses
   * has to say what is missing.
   */
  fireRefusal(weapon) {
    if (!weapon) return 'no gun';
    if (this.state !== COMBAT_STATE.ACTIVE) return 'not in a fight';
    /* ARMED IS THE POWER TEST TOO. `Weapon.update` clears `armed` the
       moment a gun loses power, so a separate `powered` check here would
       be a second copy of the same fact. And UNMANNED is deliberately
       NOT a refusal: an empty bay freezes CHARGING, but a shell already
       in the breech fires — checking it here would invent a rule the
       rest of the engine does not have. */
    if (!weapon.armed)    return `${weapon.label} is still charging`;
    return this._ammoRefusal(weapon);
  }

  /** The racks: does it have what one shot eats? */
  _ammoRefusal(weapon) {
    /* Missiles OR torpedoes (update94): weaponAmmo says which rack. */
    const a = weaponAmmo(weapon.def);
    if (a) {
      const need = a.use;
      const hold = this.playerShip?.cargo;
      const have = hold ? hold.countOf(a.kind)
                 : (a.kind === 'missiles' ? (Save.getRun()?.missiles ?? 0) : 0);
      if (have < need) {
        return `${weapon.label} is out of ammo — it needs ${need} ${a.word}`
             + `${need > 1 ? 's' : ''} a shot and the racks hold ${have}`;
      }
    }
    return null;
  }

  /**
   * CAN THIS GUN BE AIMED (update87)? Everything `fireRefusal` asks
   * EXCEPT whether it is charged — a charging gun can be pointed at a
   * room and will fire there when it is ready. One list of reasons, the
   * charge line left out, so the two cannot drift apart.
   */
  aimRefusal(weapon) {
    if (!weapon) return 'no gun';
    if (this.state !== COMBAT_STATE.ACTIVE) return 'not in a fight';
    /* The ammo is asked on its own: `fireRefusal` stops at "still
       charging" and never gets to the racks, so reading its answer let
       an EMPTY cannon be aimed — the first version did, and the test for
       it found out. */
    return this._ammoRefusal(weapon);
  }

  playerFire(weapon, targetRoom = null) {
    const refusal = this.fireRefusal(weapon);
    if (refusal) return refusal;

    // Missile ammo comes straight out of the racks in the hold — there is
    // no second, invisible ammo counter. run.missiles only MIRRORS the
    // hold so the HUD and old saves keep working. The RACKS were checked
    // by fireRefusal above; this is the withdrawal, not the check.
    const ammo = weaponAmmo(weapon.def);
    if (ammo && ammo.kind === 'torpedoes') {
      this.playerShip?.cargo?.takeStack('torpedoes', ammo.use);
    } else if (weapon.def.missileUse > 0) {
      const hold = this.playerShip?.cargo;
      if (hold) {
        hold.takeStack('missiles', weapon.def.missileUse);
        Save.updateRun({ missiles: hold.countOf('missiles') });
      } else {
        const run = Save.getRun();
        Save.updateRun({ missiles: run.missiles - weapon.def.missileUse });
      }
    }

    const enemy  = this.enemyShip;
    const target = targetRoom || Utils.pick(enemy.rooms);

    /* THE BOLT LEAVES THE BARREL (update80). This was the corner of
       the rectangle round the whole hull — `pb.x + pb.w + 10` — so
       every gun aboard fired from one pixel on the flank while the
       guns themselves were drawn in a row along the top. One position
       answers both now: see Ship.weaponMounts. The bounding box stays
       as the fallback for a gun that is somehow not on a mount, so a
       shot can never come from `undefined`. */
    const pb = this.playerShip.roomBounds ? this.playerShip.roomBounds() : { x: this.playerShip.worldX, y: this.playerShip.worldY, w: 300, h: 200 };
    const muzzle = this.playerShip.muzzleFor ? this.playerShip.muzzleFor(weapon) : null;
    const fromX = muzzle ? muzzle.x : pb.x + pb.w + 10;
    const fromY = muzzle ? muzzle.y : pb.y + pb.h / 2;

    // The crew standing in this gun's own bay get the credit for it.
    const gunRoom = this.playerShip.weaponRoomFor(weapon);
    const gunners = gunRoom ? this.playerShip.crewOperating(gunRoom.id) : [];
    const projs  = weapon.fire(fromX, fromY, target.cx, target.cy, true, gunners);
    Particles.muzzleFlash?.(fromX, fromY, 1, '#ffd780');
    this._projectiles.push(...projs);

    // FTL XP: crew manning THIS gun's module learn from each shot
    // The gun's OWN bay — see Ship.weaponRoomFor (update60).
    const wRoom = this.playerShip.weaponRoomFor(weapon);
    if (wRoom) {
      const gunner = this.playerShip.consoleOperator(wRoom.id);
      if (gunner) gunner.addXP('weapons', XP_RATES.weapons);
    }
    return null;      // fired
  }

  _updateProjectiles(dt) {
    this._projectiles.forEach(p => p.update(dt));

    /* THE BUBBLE STOPS IT WHERE IT IS (update126). A shot the shields
       will take used to fly on to the room it was aimed at and burst
       INSIDE the ship, the bubble round it untouched. Now it is
       resolved the moment it crosses the bubble — the same roll, the
       same strip, at the right place. Anything that ignores shields
       still goes in to its room. */
    this._projectiles.forEach(p => {
      if (p.done || p.hit || p._resolved || p.flyOn || p.launchDelay > 0 || p.type === 'beam') return;
      const ship = p.fromPlayer ? this.enemyShip : this.playerShip;
      if (!ship || !(ship.shieldBars > 0) || !ship.insideShield) return;
      if (Ship.piercesShields(p.def ?? {})) return;
      if (ship.insideShield(p.x, p.y)) { p.hit = true; p.done = true; p.atShield = true; }
    });

    // Handle hits
    this._projectiles.forEach(p => {
      if (!p.hit || p._resolved) return;
      p._resolved = true;

      const targetShip = p.fromPlayer ? this.enemyShip : this.playerShip;
      if (!targetShip) return;
      /* WESTCAR (update101): while it runs, the way is folded — a rock
         coming at OUR hull passes through and does nothing. */
      if (p.fromField && !p.fromPlayer && typeof Chips !== 'undefined' && Chips.running('westcar')) {
        Particles.floatText?.(p.x, p.y - 6, 'FOLDED', '#e8b04a', 12);
        Combat._flyOn(p);
        return;
      }
      /* TABLET OF DESTINIES (update102): fate is rewritten — their
         missiles and torpedoes pass through us harmlessly. Lasers,
         ions, beams and rocks still land. */
      if (!p.fromPlayer && !p.fromField && (p.type === 'missile' || p.type === 'torpedo')
          && typeof Chips !== 'undefined' && Chips.running('destinies')) {
        Particles.floatText?.(p.x, p.y - 6, 'FATE', '#7fd4ff', 12);
        Combat._flyOn(p);
        return;
      }

      const result = targetShip.receiveHit(p);

      if (result.dodged) Combat._flyOn(p);          // it missed: on it goes (update126)
      else if (typeof WeaponArt === 'undefined') Particles.laserHit(p.x, p.y);
    });

    // Remove spent projectiles
    this._projectiles = this._projectiles.filter(p => !p.done);
  }

  // ── Draw ─────────────────────────────────────────────────

  draw(ctx) {
    if (this.state === COMBAT_STATE.IDLE) return;
    /* update126: the scorches are burnt into the plate, under the
       shots; the blasts, flashes and ripples go over them. */
    if (typeof WeaponArt !== 'undefined') WeaponArt.draw(ctx, 'under');
    this._projectiles.forEach(p => p.draw(ctx));
    if (typeof WeaponArt !== 'undefined') WeaponArt.draw(ctx, 'over');
  }

  /** A shot that did not land keeps flying, past and off the screen. */
  static _flyOn(p) {
    if (p.type === 'beam' || p.type === 'asteroid') return;
    p.flyOn = true; p.done = false; p.hit = false; p.flyT = 0;
  }

  drawBeams(ctx) {
    this._projectiles.forEach(p => {
      if (p.type === 'beam') {
        const ship = p.fromPlayer ? this.enemyShip : this.playerShip;
        if (ship) p.drawBeam(ctx, ship.worldX, ship.worldY + ship.spriteH/2, ship.spriteW);
      }
    });
  }

  // ── Getters ──────────────────────────────────────────────

  isActive()   { return this.state === COMBAT_STATE.ACTIVE; }
  isVictory()  { return this.state === COMBAT_STATE.VICTORY; }
  isDefeat()   { return this.state === COMBAT_STATE.DEFEAT; }
  isFled()     { return this.state === COMBAT_STATE.FLED; }
  isEnemyFled(){ return this.state === COMBAT_STATE.ENEMY_FLED; }
  get retreatProgress() {
    return this.state === COMBAT_STATE.RETREATING
      ? Utils.clamp(this._retreatTimer / this.RETREAT_TIME, 0, 1) : 0;
  }
  get enemyEscapeProgress() {
    return this.enemyEscapeActive
      ? Utils.clamp(this._enemyEscapeT / this.ENEMY_ESCAPE_TIME, 0, 1) : 0;
  }
  consumeEscapeNotice() {
    if (!this._escapeNotice) return false;
    this._escapeNotice = false;
    return true;
  }
  inProgress() {
    return this.state === COMBAT_STATE.ACTIVE ||
           this.state === COMBAT_STATE.ENTERING ||
           this.state === COMBAT_STATE.RETREATING;
  }
}

// Singleton
/* THE ENEMY'S WOUNDED (update97): below this share of his hit points a
   hand walks to a working medbay himself; at this share he goes back. */
const ENEMY_HEAL_AT = 0.40;
const ENEMY_HEALED  = 0.90;

const CombatManager = new Combat();
