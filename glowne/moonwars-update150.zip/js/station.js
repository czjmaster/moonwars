/* ============================================================
   MOON WARS — station.js
   Station shop: random stock, limited supply,
   all shop categories with buy logic.
   ============================================================ */

'use strict';

// ── Station types ─────────────────────────────────────────

const STATION_TYPES = ['general','military','science','outpost'];

// ── Shop item templates ───────────────────────────────────

const REPAIR_PRICES   = { hull: 3, system: 40 };    // per hp / per system
const FUEL_PRICE      = 3;
const MISSILE_PRICE   = 6;
const TORPEDO_PRICE   = 14;   // update94 — a torpedo is a heavier round
const CREW_PRICE      = 60;

/**
 * THE WORLD READS KARMA (update61).
 *
 * Every price a port quotes goes through here, and NOWHERE ELSE
 * multiplies it a second time. The quote methods at the bottom of this
 * file are the only price register in the shop — the buy methods ask
 * them what something costs instead of doing the arithmetic again,
 * because two copies of a price drift the moment one of them learns
 * about karma and the other does not.
 *
 * Guarded on `typeof` so a harness that loads station.js alone still
 * prices things at par.
 */
function karmaPriceFactor() {
  return (typeof Commander !== 'undefined' && Commander.priceFactor)
    ? Commander.priceFactor() : 1;
}
/**
 * Upgrades get EXPONENTIALLY dearer. A linear price made maxing the
 * reactor a formality; now the last few pips are a real campaign goal.
 *
 *   reactor lvl  4 →  ~34 CC      lvl 10 → ~132 CC     lvl 15 → ~380 CC
 *
 * GROWTH is the per-level multiplier; the linear term keeps early
 * upgrades affordable so the curve only bites at the top.
 */
const UPGRADE_GROWTH  = 1.22;
const REACTOR_PRICE   = (level) =>
  Math.round((10 + level * 4) * Math.pow(UPGRADE_GROWTH, Math.max(0, level - 3)));

/* MODULE_DEFS IS GONE (update40).
 *
 * It was a second, flat price list for upgrading a module — 55-80 CC —
 * sitting beside the live exponential one (`systemUpgradeCost`), which
 * is exactly the disease that produced the reactor "you don't have
 * enough CC" bug in update34: two prices for one thing, and they drift.
 *
 * Worse, this half never even reached the player. Every station visit
 * rolled 1-3 of these into `stock.modules`, the station screen renders
 * `stock.newModules` (a different list) and never `stock.modules`, and
 * `buyModule` had no call site anywhere. The stock was generated and
 * thrown away on every single visit.
 *
 * The real path is: click a module on the blueprint → the detail panel
 * → UPGRADE at `systemUpgradeCost(sys)`. That one works, and it is now
 * the only one.
 */

// Crew name pool for recruits

// ── Station class ─────────────────────────────────────────

/** The fine for contraband found at a port's customs (update90a). */
const CUSTOMS_FINE = 100;

class Station {
  /**
   * CUSTOMS AT THE DOOR (update90a). The player, 01.10: dock at any port
   * but an outpost with contraband in the hold and it is taken off you,
   * with a 100 CC fine — paid from the purse if it can be, and what the
   * purse cannot cover is taken in goods from the hold, at this port's
   * prices. The outpost (and a wanted man's black market, which is one)
   * asks nothing: that is where contraband is FOR. Before this it was
   * only seized when you tried to SELL it at a fleet yard.
   *
   * Goods for the shortfall: the cheapest single item that covers what
   * is left, else the dearest and go again — so a 30 CC shortfall does
   * not cost a 200 CC gun when a crate of rations would do.
   *
   * Returns what happened, for the caller to say; null when customs had
   * nothing to do. `run` is { scrap } and is changed in place.
   */
  customs(ship, run) {
    if (this.type === 'outpost' || !ship?.cargo) return null;
    const hold = ship.cargo;
    const seized = hold.items.filter(it => it.def?.contraband);
    if (!seized.length) return null;
    seized.forEach(it => hold.remove(it));
    const purse = Math.max(0, run?.scrap ?? 0);
    const paid = Math.min(purse, CUSTOMS_FINE);
    if (run) run.scrap = purse - paid;
    let owed = CUSTOMS_FINE - paid;
    const taken = [];
    while (owed > 0) {
      const goods = hold.items.map(it => ({ it, v: it.value(this.type) }))
        .filter(g => g.v > 0).sort((a, b) => a.v - b.v);
      if (!goods.length) break;
      const pick = goods.find(g => g.v >= owed) ?? goods[goods.length - 1];
      hold.remove(pick.it);
      taken.push({ label: pick.it.label, value: pick.v });
      owed -= pick.v;
    }
    return { seized: seized.map(it => it.label), paid, taken, unpaid: Math.max(0, owed) };
  }

  /**
   * @param {number} sector - current sector (affects prices and stock)
   * @param {number} seed   - RNG seed for stock
   */
  constructor(sector = 1, seed = 0, opts = {}) {
    this.sector  = sector;
    this.seed    = seed;
    /* ── A HOLD IS NOT A PORT (update70) ───────────────────────
     *
     * The black market is a Station with a flag, not a second shop.
     * The counter, the buy methods, the hold probe and the whole UI
     * are the ones that already work; what changes is WHO is behind
     * the counter — his stock is short, it is cheap, and he does not
     * care what your name is. Building a second screen for it would
     * have been two shops to keep in step forever.
     */
    this.blackMarket = !!opts.blackMarket;
    this.owner       = opts.owner || null;      // the name off the board
    this.type    = this.blackMarket ? 'outpost' : Utils.pick(STATION_TYPES);
    this.name    = this.blackMarket
      ? `${this.owner || 'Somebody'}'s hold`
      : this._genName();
    this._rng    = this._makeRng(seed);

    // Stock (limited quantities)
    this.stock = this.blackMarket ? this._generateBlackStock() : this._generateStock();

    /* WHAT CHANGED HANDS THIS VISIT (update144): every crate across a
       counter, bought or sold, one line each — the receipt beside the
       counter reads it. Not saved: a port is left before a save. */
    this.ledger = [];
  }

  /* ── A PORT YOU CAN COME BACK TO (update150) ─────────────
   * jj: "przydałoby się, żeby do portu można było wejść, jeżeli dalej
   * jesteśmy w tym samym miejscu w sektorze". The port is kept in the
   * run while the ship stands at its node: its name, its kind, what is
   * left on its shelves (a gun bought is gone, a hand signed on is gone)
   * and this visit's receipt. A reload brings back the same port, not
   * a new one rolled over the old. */
  serialise() {
    const st = this.stock || {};
    return {
      v: 1, sector: this.sector, seed: this.seed, type: this.type, name: this.name,
      blackMarket: !!this.blackMarket, owner: this.owner ?? null,
      stock: {
        ...JSON.parse(JSON.stringify({ ...st, weapons: [], crew: [] })),
        weapons: (st.weapons ?? []).map(w => ({ key: w.key, sold: !!w.sold })),
        crew: (st.crew ?? []).map(c => ({ name: c.name, skill: c.skill, sold: !!c.sold,
                                          member: c.member?.serialise ? c.member.serialise() : null })),
      },
      ledger: (this.ledger ?? []).map(l => ({ ...l })),
    };
  }

  static deserialise(d) {
    if (!d || typeof d !== 'object' || !d.stock) return null;
    const s = Object.create(Station.prototype);
    s.sector = d.sector ?? 1;
    s.seed = d.seed ?? 0;
    s.blackMarket = !!d.blackMarket;
    s.owner = d.owner ?? null;
    s.type = d.type || 'general';
    s.name = d.name || 'Station';
    s._rng = s._makeRng(s.seed);
    const st = JSON.parse(JSON.stringify(d.stock));
    st.weapons = (st.weapons ?? []).filter(w => WEAPON_DEFS[w.key])
      .map(w => ({ key: w.key, def: WEAPON_DEFS[w.key], sold: !!w.sold }));
    st.crew = (st.crew ?? []).map(c => ({
      name: c.name, skill: c.skill, sold: !!c.sold,
      member: c.member ? CrewMember.deserialise(c.member)
                       : new CrewMember({ name: c.name, skills: { [c.skill]: { level: 1, xp: 0 } } }),
    }));
    s.stock = st;
    s.ledger = Array.isArray(d.ledger) ? d.ledger.map(l => ({ ...l })) : [];
    return s;
  }

  _note(label, qty, cc) {
    (this.ledger ??= []).push({ label, qty, cc });
    if (this.ledger.length > 40) this.ledger.shift();
  }

  /**
   * EVERY PRICE THIS COUNTER QUOTES GOES THROUGH HERE.
   *
   * A port adds the karma surcharge; a pirate takes a cut off instead
   * — and never both, because the surcharge is what the honest docks
   * charge a man the pirate is pleased to see.
   */
  _priceFactor() {
    if (!this.blackMarket) return karmaPriceFactor();
    const off = (typeof Commander !== 'undefined' && Commander.pirateDiscount)
      ? Commander.pirateDiscount() : 0.30;
    return Math.max(0.2, 1 - off);
  }

  _makeRng(seed) {
    let s = seed + 1;
    return () => { s ^= s<<13; s ^= s>>17; s ^= s<<5; return (s>>>0)/0xFFFFFFFF; };
  }

  _rngInt(a,b) { return Math.floor(this._rng()*(b-a))+a; }

  _genName() {
    const prefixes = ['Alpha','Beta','Delta','Echo','Foxtrot','Gamma','Kappa','Nova','Sigma','Theta'];
    const suffixes = ['Station','Post','Depot','Hub','Outpost','Base','Beacon'];
    return `${Utils.pick(prefixes)}-${Utils.pick(suffixes)}`;
  }

  _generateStock() {
    const s  = this.sector;
    const r  = this._rng.bind(this);
    const ri = this._rngInt.bind(this);

    const stock = {
      // Hull repair
      hullRepair: ri(5, 15 + s * 3),   // hp available to buy

      // Fuel
      fuel: ri(1, 4 + s),

      /* He-3 ORE (update56). A port sells it because miners bring it in;
         the player buys it because it is worth money at home and,
         later, because the Gate eats it. Thin stock on purpose — a
         station that could fill your hold with it would make the
         mineral meaningless the day it gets a use. */
      he3: ri(0, 2 + Math.floor(s / 2)),

      // Missiles
      missiles: ri(0, 6 + s),
      /* TORPEDOES (update94): from sector 2, a few. */
      torpedoes: s >= 2 ? ri(0, 2 + s) : 0,

      /* MEDICAL SUPPLIES (update87). The player: "ciężko jest zdobyć
         apteczki" — they only ever came out of wrecks. Every port keeps
         a few kits (five doses each), a few more deeper in. */
      medkits: ri(1, 4 + Math.floor(s / 2)),

      /* RATIONS (update66). A port carries a couple of KINDS, not the
         whole menu — which is why the four are a packing decision and
         not just a shopping list. Which kinds is deterministic in the
         station's seed, so a port you came back for still has what you
         came back for. */
      rations: (() => {
        const KINDS = ['ration_pack', 'protein_paste', 'field_meal', 'green_ration'];
        const out = {};
        KINDS.forEach(k => { if (r() < 0.55) out[k] = ri(2, 8 + s); });
        // Never a port with nothing to eat at all.
        if (!Object.keys(out).length) out.ration_pack = ri(2, 6 + s);
        return out;
      })(),

      // Weapons (1–2 random)
      weapons: [],

      // Modules
      // `modules` used to be rolled here and shown nowhere — see the
      // note above MODULE_DEFS. `newModules` is the live one.


      // Crew recruits (0–2)
      crew: [],

      // Upgrades are ALWAYS available at stations
      reactorUpgrade: true,

      // Brand-new MODULES — random whether a given one is in stock.
      // SHIELDS are here because the starter hull ships without them:
      // getting a shield bay is the first big purchase of a run, so it
      // has to be findable (60% — often, not always).
      newModules: [
        ...(r() < 0.60 ? [{ type: 'shields',    cost: 90 + this.sector * 15, sold: false }] : []),
        ...(r() < 0.35 ? [{ type: 'medbay',     cost: 70 + this.sector * 10, sold: false }] : []),
        ...(r() < 0.5  ? [{ type: 'cloaking',   cost: 85 + this.sector * 10, sold: false }] : []),
        ...(r() < 0.5  ? [{ type: 'autorepair', cost: 75 + this.sector * 10, sold: false }] : []),
        /* THE BRIG. Started at 30% in update63 on the theory that it
           is a module you go looking for; raised to 60% in update64,
           the player's call, because a cell you never find means the
           "Take him prisoner" door never opens and the whole bounty
           half of the game is untestable. To revisit at balance
           time — this is a number for playing, not a final one. */
        ...(r() < 0.60 ? [{ type: 'carbonite',       cost: 80 + this.sector * 10, sold: false }] : []),
      ],
    };

    // Weapons
    const wCount = ri(1, 3);
    const wPool  = Object.entries(WEAPON_DEFS)
      .filter(([,d]) => d.cost > 0 && d.cost <= 50 + s*15 && (d.minSector ?? 1) <= s);
    for (let i = 0; i < wCount && wPool.length; i++) {
      const idx = ri(0, wPool.length);
      const [key, def] = wPool.splice(idx, 1)[0];
      stock.weapons.push({ key, def, sold: false });
    }

    /* Crew — HOW MANY ARE EVEN INTERESTED (update61).
       A delta on the roll, never a second roll: a port that rolled
       nobody still has nobody, and a shunned commander finds two
       fewer berths filled than a saint would at the same port. */
    const interest = (typeof Commander !== 'undefined' && Commander.recruitInterest)
      ? Commander.recruitInterest() : 0;
    const cCount = Utils.clamp(ri(0, 3) + interest, 0, 3);
    for (let i = 0; i < cCount; i++) {
      /* One pool and one rule for every name (update93a): not one
         already in play, not one already on this board. */
      const name  = pickUniqueName(CREW_NAMES, [...CrewMember.namesInPlay(), ...stock.crew.map(x => x.name)]);
      const skill = Utils.pick(Object.keys(SKILL_DEFS));
      stock.crew.push({
        name,
        skill,
        sold: false,
        member: new CrewMember({
          name,
          skills: { [skill]: { level: 1, xp: 0 } },
        }),
      });
    }

    return stock;
  }

  /**
   * WHAT A MAN OFF THE WANTED BOARD HAS IN HIS HOLD (update70).
   *
   * Short, and all of it the kind of thing a port either does not
   * carry or will not admit to carrying: guns, a module or two out of
   * somebody else's ship, sealed contraband and chips. No hull repair,
   * no recruits, no reactor work — he is not a dockyard, he is a man
   * with a hold full of other people's property.
   *
   * The prices are the same catalogue every port uses; what makes them
   * cheap is `_priceFactor`, in one place, so "how much under the port
   * price" is a single number and not a second price list.
   */
  _generateBlackStock() {
    const s  = this.sector;
    const r  = this._rng.bind(this);
    const ri = this._rngInt.bind(this);
    const deep = (typeof Commander !== 'undefined' && Commander.KARMA_SHUNNED != null &&
                  Commander.karmaNow)
      ? Commander.karmaNow() <= Commander.KARMA_SHUNNED : false;

    const stock = {
      hullRepair: 0,
      // He will spare a cell or two, at his price.
      fuel: ri(0, 3 + (deep ? 2 : 0)),
      he3: 0,
      missiles: ri(0, 4 + s),
      rations: {},
      weapons: [],
      crew: [],
      reactorUpgrade: false,
      newModules: [],
      /* CRATES HE SELLS OVER THE COUNTER. Ports have no such list —
         this is the one thing the black market adds to the shop
         rather than reprices. */
      goods: [],
    };

    // ── guns: more than a port, and the better ones show up deeper in ──
    const wCount = ri(2, 4 + (deep ? 2 : 0));
    const wPool  = Object.entries(WEAPON_DEFS)
      .filter(([, d]) => d.cost > 0 && d.cost <= 70 + s * 20 && (d.minSector ?? 1) <= s);
    for (let i = 0; i < wCount && wPool.length; i++) {
      const [key, def] = wPool.splice(ri(0, wPool.length), 1)[0];
      stock.weapons.push({ key, def, sold: false });
    }

    // ── a module or two, out of a hull that is not using it any more ──
    const MODS = ['shields', 'cloaking', 'carbonite', 'medbay', 'autorepair'];
    Utils.shuffle(MODS);
    MODS.slice(0, ri(1, deep ? 4 : 3)).forEach(type => {
      stock.newModules.push({ type, cost: 70 + this.sector * 12, sold: false });
    });

    // ── the goods ──
    const push = (key, n = 1) => {
      for (let i = 0; i < n; i++) {
        const def = (typeof CARGO_ITEMS !== 'undefined') ? CARGO_ITEMS[key] : null;
        if (!def) return;
        stock.goods.push({ key, cost: Math.round((def.value ?? 20) * 1.1), sold: false });
      }
    };
    push('contraband', ri(1, deep ? 4 : 3));
    if (r() < (deep ? 0.9 : 0.6)) push('alien_relic');
    /* No tablets here (update99): jj's tablets come from bosses and from
       the crates of wrecks and pirates, never off a counter. The chips
       this market used to sell are gone with the chips. */
    return stock;
  }

  /** What this counter wants for a gun off the rack, and for a module
   *  out of the back. A PORT quotes the catalogue price it always has
   *  — karma has never touched guns and quietly adding it here would
   *  re-balance every station in the game. A pirate takes his cut off
   *  the same figure, which is the whole point of dealing with him. */
  _goodsFactor() { return this.blackMarket ? this._priceFactor() : 1; }
  weaponCost(item) { return Math.round((item?.def?.cost ?? 0) * this._goodsFactor()); }
  moduleCost(item) { return Math.round((item?.cost    ?? 0) * this._goodsFactor()); }
  goodsCost(item)  { return Math.round((item?.cost    ?? 0) * this._goodsFactor()); }

  /**
   * Buy a crate over the counter. Same shape as `buyRations`: probe a
   * COPY of the hold first, so nothing is charged for that cannot be
   * carried, and the crate is placed by the grid rather than counted.
   */
  buyGoods(idx, run, ship) {
    const closed = this.refusal();
    if (closed) return { ok: false, message: closed };
    const item = (this.stock.goods ?? [])[idx];
    if (!item || item.sold) return { ok: false, message: 'Item not available.' };
    const hold = ship?.cargo;
    if (!hold) return { ok: false, message: 'Nothing to load it into.' };
    const cost = this.goodsCost(item);
    if (!run || run.scrap < cost) return { ok: false, message: 'Insufficient CC.' };
    const probe = CargoGrid.deserialise(hold.serialise());
    if (!probe.add(item.key)) return { ok: false, message: 'No room in the hold.' };
    const placed = hold.add(item.key);
    if (!placed) return { ok: false, message: 'No room in the hold.' };
    item.sold = true;
    Save.updateRun({ scrap: run.scrap - cost });
    Audio.sfx.scrapCollect?.();
    return { ok: true, cost, message: `Loaded ${placed.label}.` };
  }

  // ── Buy actions ──────────────────────────────────────────

  /**
   * Buy hull repair.
   * @param {number}  hp     - amount of HP to repair
   * @param {Ship}    ship
   * @returns {{ ok, cost, message }}
   */
  buyHullRepair(hp, ship) {
    const closed = this.refusal();
    if (closed) return { ok: false, message: closed };
    const available = Math.min(hp, this.stock.hullRepair);
    if (available <= 0) return { ok: false, message: 'No hull repair available.' };

    const cost = this.hullRepairCost(available);
    const run  = Save.getRun();
    if (!run || run.scrap < cost) return { ok: false, message: 'Insufficient CC.' };

    ship.hull = Math.min(ship.hullMax, ship.hull + available);
    this.stock.hullRepair -= available;
    Save.updateRun({ scrap: run.scrap - cost });
    this._note(`hull welded +${available} HP`, 1, -cost);
    Audio.sfx.repair();
    return { ok: true, cost, message: `Hull repaired +${available} HP.` };
  }

  /**
   * He2 is physical now (update39): it goes into CELLS in the hold, and
   * the hold can be full. Same shape as buyMissiles, including the
   * dry-run probe so the player is only ever charged for what fits.
   * `ship` is optional so old call sites still work.
   */
  buyFuel(amount, run, ship = null) {
    const closed = this.refusal();
    if (closed) return { ok: false, message: closed };
    let avail = Math.min(amount, this.stock.fuel);
    if (avail <= 0) return { ok: false, message: 'No He2 available.' };

    const hold = ship?.cargo;
    // Medium tanks first, then bottles for the gaps, then drums.
    const KEYS = ['he2_med', 'he2_small', 'he2_large'];
    const pour = (grid, n) => {
      let left = n;
      for (const k of KEYS) { if (left <= 0) break; left = grid.addStack(k, left); }
      return left;
    };
    if (hold) {
      const probe = CargoGrid.deserialise(hold.serialise());
      avail -= pour(probe, avail);
      if (avail <= 0) return { ok: false, message: 'No room in the hold for He2.' };
    }

    const cost = this.fuelCost(avail);
    if (run.scrap < cost) return { ok: false, message: 'Insufficient CC.' };

    this.stock.fuel -= avail;
    if (hold) {
      pour(hold, avail);
      Save.updateRun({ scrap: run.scrap - cost, fuel: hold.countOf('fuel') });
    } else {
      Save.updateRun({ scrap: run.scrap - cost, fuel: run.fuel + avail });
    }
    Audio.sfx.scrapCollect();
    return { ok: true, cost, message: `Loaded ${avail} He2 into the hold.` };
  }

  /**
   * He-3 ORE ACROSS THE COUNTER (update56).
   *
   * Deliberately the same shape as `buyFuel` — probe a COPY of the hold
   * first, so a purchase that will not fit is refused before any money
   * moves, and the player is never charged for ore left on the dock.
   *
   * What it is NOT: fuel. It never touches `run.fuel`, and the hold
   * counts it as trade goods, because the ship does not burn it.
   */
  buyHe3(amount, run, ship = null) {
    const closed = this.refusal();
    if (closed) return { ok: false, message: closed };
    let avail = Math.min(amount, this.stock.he3 ?? 0);
    if (avail <= 0) return { ok: false, message: 'No He-3 at this port.' };

    const hold = ship?.cargo;
    if (!hold) return { ok: false, message: 'Nothing to load it into.' };

    const probe = CargoGrid.deserialise(hold.serialise());
    avail -= probe.addStack('he3_ore', avail);
    if (avail <= 0) return { ok: false, message: 'No room in the hold for ore.' };

    const cost = this.he3Cost(avail);
    if (run.scrap < cost) return { ok: false, message: 'Insufficient CC.' };

    this.stock.he3 -= avail;
    hold.addStack('he3_ore', avail);
    Save.updateRun({ scrap: run.scrap - cost });
    Audio.sfx.scrapCollect();
    return { ok: true, cost, message: `Loaded ${avail} He-3 into the hold.` };
  }

  /** What a port charges for a unit of ore. Dearer further out, the way
   *  everything else is — it is mined here, not made here. */
  he3Cost(amt = 1) {
    const base = (typeof CARGO_ITEMS !== 'undefined'
                  && CARGO_ITEMS.he3_ore?.unitValue) || 30;
    return Math.round(amt * base * (1.1 + this.sector * 0.05) * this._priceFactor());
  }

  /**
   * Missiles are physical now: they go into racks in the hold, and the
   * hold can be full. `ship` is optional so old call sites still work.
   */
  buyMissiles(amount, run, ship = null) {
    const closed = this.refusal();
    if (closed) return { ok: false, message: closed };
    let avail = Math.min(amount, this.stock.missiles);
    if (avail <= 0) return { ok: false, message: 'No missiles available.' };

    const hold = ship?.cargo;
    if (hold) {
      // Only charge for what actually fits — dry-run the load first.
      const probe = CargoGrid.deserialise(hold.serialise());
      const spill = probe.addStack('missile_rack', avail);
      avail -= spill;
      if (avail <= 0) return { ok: false, message: 'No room in the hold for missiles.' };
    }

    const cost = this.missileCost(avail);
    if (run.scrap < cost) return { ok: false, message: 'Insufficient CC.' };

    this.stock.missiles -= avail;
    if (hold) {
      hold.addStack('missile_rack', avail);
      Save.updateRun({ scrap: run.scrap - cost, missiles: hold.countOf('missiles') });
    } else {
      Save.updateRun({ scrap: run.scrap - cost, missiles: run.missiles + avail });
    }
    Audio.sfx.scrapCollect();
    return { ok: true, cost, message: `Loaded ${avail} missiles into the racks.` };
  }

  buyWeapon(idx, ship, run) {
    const closed = this.refusal();
    if (closed) return { ok: false, message: closed };
    const item = this.stock.weapons[idx];
    if (!item || item.sold) return { ok: false, message: 'Item not available.' };

    const cost = this.weaponCost(item);
    if (run.scrap < cost) return { ok: false, message: 'Insufficient CC.' };

    /* THE GOODS BEFORE THE MONEY (update75). This charged the player
       first and then found somewhere to put the gun — and "somewhere"
       was the weightless rack, which always had room, so the order
       never mattered. It matters now: the hold can be full, and a sale
       that cannot be delivered must not happen at all. */

    // ONE gun per weapon MODULE: install into the first free module,
    // otherwise it goes into a crate in the hold.
    let slot = -1;
    for (let i = 0; i < ship.weaponRooms.length; i++) {
      if (!ship.weapons[i]) { slot = i; break; }
    }
    let where = null;
    if (slot !== -1 && ship.installWeapon(item.key, slot)) {
      where = `installed in module ${slot + 1}.`;
    } else if (ship.boxWeapon(item.key)) {
      where = 'boxed and stowed in the hold — all modules are occupied.';
    } else {
      const probe = (typeof CargoItem !== 'undefined' && typeof cargoCrateForWeapon === 'function')
        ? new CargoItem(cargoCrateForWeapon(item.key)) : null;
      return { ok: false,
        message: probe
          ? `Every module is occupied and the hold has no ${probe.w}x${probe.h} space `
            + 'for the crate — make room first. Nothing was bought.'
          : 'Nowhere to put that gun — nothing was bought.' };
    }

    item.sold = true;
    Save.updateRun({ scrap: run.scrap - cost });
    Audio.sfx.powerUp();
    return { ok: true, cost, message: `${item.def.label} ${where}` };
  }

  /** Move a mounted gun into the cargo hold — free, station only. */
  /**
   * A gun taken off the hull has to go SOMEWHERE physical — into a crate
   * in the hold. If there is no room for the crate, the gun stays bolted
   * on: no invisible rack to park it on any more.
   */
  uninstallWeapon(ship, slot) {
    const peek = ship.weapons[slot];
    if (!peek) return { ok: false, message: 'Module is empty.' };

    /* THE ROOM CHECK MOVED INTO `Ship.uninstallWeapon` (update75).
       It used to live here as a hand-rolled scan of every cell, next to
       a second copy of it in base.js — and then this function had to
       UNDO what `Ship.uninstallWeapon` had just done, because that one
       pushed the gun onto the old rack. Three lines of reconciliation
       between two registers, all of it gone with the second register. */
    const key = ship.uninstallWeapon(slot);
    if (!key) {
      const probe = (typeof CargoItem !== 'undefined' && typeof cargoCrateForWeapon === 'function')
        ? new CargoItem(cargoCrateForWeapon(peek.defKey)) : null;
      return { ok: false,
        message: probe
          ? `No room in the hold for a ${probe.w}x${probe.h} crate — make space first. `
            + 'The gun stays on the mount.'
          : 'No room in the hold — the gun stays on the mount.' };
    }
    Audio.sfx.uiClick();
    return { ok: true,
      message: `${WEAPON_DEFS[key]?.label ?? key} boxed and stowed in the hold.` };
  }

  /**
   * Mount a BOXED gun from the hold into a specific empty module. The
   * crate is the thing that moves — it leaves the grid, and the space
   * it took comes back (update75; this used to take an index into the
   * old weightless rack).
   */
  installFromCargo(ship, crate, slot) {
    const key = crate?.meta;
    if (!crate || crate.def?.kind !== 'weapon' || !key) {
      return { ok: false, message: 'That is not a gun crate.' };
    }
    if (!ship.cargo?.items.includes(crate)) {
      return { ok: false, message: 'That crate is not in this hold.' };
    }
    if (ship.weapons[slot]) return { ok: false, message: `Module ${slot + 1} is occupied.` };
    if (!ship.installWeapon(key, slot)) return { ok: false, message: 'Install failed.' };
    ship.cargo.remove(crate);
    Audio.sfx.powerUp();
    return { ok: true,
      message: `${WEAPON_DEFS[key]?.label ?? key} installed in module ${slot + 1} `
             + '— the crate is out of the hold.' };
  }

  /** Sell a BOXED gun out of the hold for half its list price. */
  sellCargoWeapon(ship, run, crate) {
    const key = crate?.meta;
    if (!crate || crate.def?.kind !== 'weapon' || !key) {
      return { ok: false, message: 'That is not a gun crate.' };
    }
    if (!ship.cargo?.items.includes(crate)) {
      return { ok: false, message: 'That crate is not in this hold.' };
    }
    const price = Math.floor((WEAPON_DEFS[key]?.cost ?? 20) * 0.5);
    ship.cargo.remove(crate);
    Save.updateRun({ scrap: run.scrap + price });
    Audio.sfx.scrapPickup?.();
    return { ok: true, message: `Sold for ${price} CC — the hold has its space back.` };
  }

  /** Upgrade any ship system by INDEX — always available, price grows
   *  with current level. Shields upgrade a whole MODULE level at a
   *  time (+2 pips = +1 layer), capped at level 3. */
  upgradeSystemAt(ship, run, sysIndex) {
    const sys = ship.systems[sysIndex];
    if (!sys || sys.type === 'reactor')
      return { ok: false, message: 'Use the Reactor tab for that.' };
    const step = sys.type === 'shields' ? 2 : 1;
    const max  = sys.def?.maxLevel ?? 8;
    if (sys.level + step > max)
      return { ok: false, message: `${sys.label} already at max level.` };
    const cost = this.systemUpgradeCost(sys);
    if (run.scrap < cost) return { ok: false, message: 'Insufficient CC.' };
    sys.level += step;
    Save.updateRun({ scrap: run.scrap - cost });
    Audio.sfx.levelUp();
    const shown = sys.type === 'shields' ? `${sys.level / 2}/3` : `${sys.level}`;
    return { ok: true, cost, message: `${sys.label} upgraded to level ${shown}.` };
  }

  /**
   * Module upgrades climb exponentially too — the same reasoning as the
   * reactor. `step` for shields is a whole 2-pip layer, so its curve is
   * driven by LAYER number, not pip number.
   */
  systemUpgradeCost(sys) {
    if (sys.type === 'shields') {
      const layer = sys.level / 2;                 // layers already fitted
      return Math.round((40 + layer * 45) * Math.pow(UPGRADE_GROWTH, layer))
           + this.sector * 5;
    }
    const lvl = sys.level;
    return Math.round((18 + lvl * 10) * Math.pow(UPGRADE_GROWTH, Math.max(0, lvl - 1)))
         + this.sector * 5;
  }

  /** Buy a brand-new module from stock — converts an empty room. */
  buyNewModule(idx, ship, run) {
    const closed = this.refusal();
    if (closed) return { ok: false, message: closed };
    const item = this.stock.newModules[idx];
    if (!item || item.sold) return { ok: false, message: 'Item not available.' };
    if (ship.getSystem(item.type))
      return { ok: false, message: 'Already installed on this hull.' };
    if (!ship.rooms.some(r => r.type === 'empty'))
      return { ok: false, message: 'No empty room to convert.' };
    const cost = this.moduleCost(item);
    if (run.scrap < cost) return { ok: false, message: 'Insufficient CC.' };
    if (!ship.addModule(item.type)) return { ok: false, message: 'Install failed.' };
    item.sold = true;
    Save.updateRun({ scrap: run.scrap - cost });
    Audio.sfx.levelUp();
    return { ok: true, cost,
      message: `${SYSTEM_DEFS[item.type].label} installed — give it power!` };
  }

  /** Orbital med-clinic: heals everyone to full, gets the wounded back
   *  on their feet and cures the CORPSE PLAGUE. 12 CC a patient.
   *  It does NOT touch the void-spider virus — that needs a research
   *  post's quarantine ward. (The dead stay dead — eject the bodies.) */
  healCrew(ship, run) {
    /* `c.isPlayer` keeps enemy boarders off the bill (update42).
       THE CAT IS A PATIENT (update54) — she is ours, walks our decks
       and takes our wounds, and a vet costs the same as a doctor. The
       rat and spider clauses that kept stowaways off the bill went in
       update84: they live in the ducts now, not in the crew list. */
    const patients = this.clinicPatients(ship);
    if (!patients.length) return { ok: false, message: 'Nobody needs treatment.' };
    const cost = this.clinicCost(ship);
    if (run.scrap < cost) return { ok: false, message: `Need ${cost} CC for ${patients.length} patient(s).` };
    patients.forEach(c => {
      c.hp = c.maxHp;
      c.state = 'ok';
      c._bleedT = 0;
      c.infected = false;
    });
    Save.updateRun({ scrap: run.scrap - cost });
    this._note(`${patients.length} treated at the clinic`, 1, -cost);
    Audio.sfx.levelUp();
    return { ok: true, cost,
      message: `${patients.length} crew treated — healed and plague-free.` };
  }

  /* ONE PRICE LIST FOR THE CLINIC (update147): the clinic room and the
     old panel both read these — the 12 CC a head used to be written
     out twice. */
  static get CLINIC_EACH() { return 12; }
  /** Who the clinic would treat: ours, alive, and hurt, down or plague-sick. */
  clinicPatients(ship) {
    return (ship?.crew ?? []).filter(c =>
      c.isPlayer && !c.dead && (c.hp < c.maxHp || c.state === 'injured' || c.infected));
  }
  clinicCost(ship) { return this.clinicPatients(ship).length * Station.CLINIC_EACH; }

  /**
   * QUARANTINE WARD — research posts only.
   *
   * The ordinary clinic cannot touch the void-spider virus; letting it
   * would make the whole mechanic a 12 CC inconvenience. A `science`
   * port can, and charges for it.
   */
  quarantineCost(ship) {
    const n = ship.crew.filter(c => !c.dead && c.virus).length;
    return n * 45;
  }

  cureVirus(ship, run) {
    if (this.type !== 'science') {
      return { ok: false,
        message: 'No quarantine ward here — only a research post can treat it.' };
    }
    const patients = ship.crew.filter(c => !c.dead && c.virus);
    if (!patients.length) return { ok: false, message: 'Nobody is carrying it.' };
    const cost = this.quarantineCost(ship);
    if (run.scrap < cost) {
      return { ok: false, message: `Need ${cost} CC to treat ${patients.length}.` };
    }
    patients.forEach(c => c.cureVirus());
    Save.updateRun({ scrap: run.scrap - cost });
    this._note(`${patients.length} through quarantine`, 1, -cost);
    Audio.sfx.levelUp();
    return { ok: true, cost,
      message: `${patients.length} crew scrubbed clean — the virus is out of them.` };
  }

  /* ══ FUMIGATION (update90b) ═══════════════════════════════
   *
   * The player, 01.10: "na niektórych stacjach powinno być odkażanie —
   * jak ktoś nie ma kota i kłopoty, to może to zrobić na stacji". A
   * GENERAL or a RESEARCH port clears the ducts of every rat and spider
   * for 40 CC + 5 CC a head. Fleet yards and outposts do not do it.
   * Egg cases stay: they are cargo, and worth money, and that is the
   * player's call to make — "jaja zostają".
   */
  get offersFumigation() {
    return !this.blackMarket && (this.type === 'general' || this.type === 'science');
  }

  fumigationCost(ship) {
    const n = (ship?.pests ?? []).filter(p => p.alive).length;
    return n ? Station.FUMIGATE_BASE + Station.FUMIGATE_EACH * n : 0;
  }

  static get FUMIGATE_BASE() { return 40; }
  static get FUMIGATE_EACH() { return 5; }

  fumigate(ship, run) {
    if (!this.offersFumigation) {
      return { ok: false, message: 'Nobody here will go into your ducts.' };
    }
    const vermin = (ship?.pests ?? []).filter(p => p.alive);
    if (!vermin.length) return { ok: false, message: 'Your ducts are clean.' };
    const cost = this.fumigationCost(ship);
    if (run.scrap < cost) return { ok: false, message: `Need ${cost} CC to clear the ducts.` };
    // Let go of any cat up there with one first, then empty the ducts.
    vermin.forEach(p => {
      const cat = p._catId ? ship.crew.find(c => c && c.id === p._catId) : null;
      if (cat && ship._catLetGo) ship._catLetGo(cat);
    });
    for (let i = ship.pests.length - 1; i >= 0; i--) {
      if (vermin.includes(ship.pests[i])) ship.pests.splice(i, 1);
    }
    run.scrap -= cost;
    if (typeof Save !== 'undefined' && Save.updateRun) Save.updateRun({ scrap: run.scrap });
    this._note?.(`ducts fumigated (${vermin.length})`, 1, -cost);
    return { ok: true, cost, count: vermin.length,
      message: `The ducts are cleared — ${vermin.length} gone, ${cost} CC.` };
  }

  /** Room-targeted variants — the player clicks the destination room
   *  on the station's ship diagram. */
  buyNewModuleAt(idx, ship, run, roomId) {
    const closed = this.refusal();
    if (closed) return { ok: false, message: closed };
    const item = this.stock.newModules[idx];
    if (!item || item.sold) return { ok: false, message: 'Item not available.' };
    if (ship.getSystem(item.type))
      return { ok: false, message: 'Already installed on this hull.' };
    const cost = this.moduleCost(item);
    if (run.scrap < cost) return { ok: false, message: 'Insufficient CC.' };
    if (!ship.addModuleAt(item.type, roomId))
      return { ok: false, message: 'That compartment cannot take it.' };
    item.sold = true;
    Save.updateRun({ scrap: run.scrap - cost });
    Audio.sfx.levelUp();
    return { ok: true, cost,
      message: `${SYSTEM_DEFS[item.type].label} installed — give it power!` };
  }

  buyWeaponModuleAt(ship, run, roomId) {
    const closed = this.refusal();
    if (closed) return { ok: false, message: closed };
    if (ship.weaponRooms.length >= 3)
      return { ok: false, message: 'Hull supports at most 3 weapon modules.' };
    const cost = this.weaponModuleCost(ship);
    if (run.scrap < cost) return { ok: false, message: 'Insufficient CC.' };
    if (!ship.addModuleAt('weapons', roomId))
      return { ok: false, message: 'That compartment cannot take it.' };
    Save.updateRun({ scrap: run.scrap - cost });
    Audio.sfx.levelUp();
    return { ok: true, cost,
      message: `Weapon module ${ship.weaponRooms.length} installed — fit a gun into it.` };
  }

  /** Convert an empty room into a NEW weapon module (2nd: 60, 3rd: 120). */
  weaponModuleCost(ship) { return 60 * ship.weaponRooms.length; }

  buyWeaponModule(ship, run) {
    const closed = this.refusal();
    if (closed) return { ok: false, message: closed };
    if (ship.weaponRooms.length >= 3)
      return { ok: false, message: 'Hull supports at most 3 weapon modules.' };
    if (!ship.rooms.some(r => r.type === 'empty'))
      return { ok: false, message: 'No empty room to convert.' };
    const cost = this.weaponModuleCost(ship);
    if (run.scrap < cost) return { ok: false, message: 'Insufficient CC.' };
    if (!ship.addWeaponModule()) return { ok: false, message: 'Conversion failed.' };
    Save.updateRun({ scrap: run.scrap - cost });
    Audio.sfx.levelUp();
    return { ok: true, cost,
      message: `Weapon module ${ship.weaponRooms.length} installed — fit a gun into it.` };
  }

  buyCrew(idx, ship, run) {
    const closed = this.refusal();
    if (closed) return { ok: false, message: closed };
    const item = this.stock.crew[idx];
    if (!item || item.sold) return { ok: false, message: 'No crew available.' };
    /* ONE RULE FOR A FREE BUNK (update146): the living count, the same
       number the hiring panel and the bar show — a body in the brig or
       a dead man left aboard is not taking a bunk. */
    if (this.crewRoomLeft(ship) <= 0) return { ok: false, message: 'Crew quarters full.' };

    const cost = this.crewCost();
    if (run.scrap < cost) return { ok: false, message: 'Insufficient CC.' };

    item.sold = true;
    ship.addCrew(item.member);
    Save.updateRun({ scrap: run.scrap - cost });
    this._note(`${item.name} signed on`, 1, -cost);
    Audio.sfx.levelUp();
    return { ok: true, cost, message: `${item.name} joined the crew.` };
  }

  static get CREW_ROOM() { return 8; }
  /** Bunks left aboard: the room, less everybody still alive. */
  crewRoomLeft(ship) { return Station.CREW_ROOM - (ship?.crew ?? []).filter(c => !c.dead).length; }

  buyReactorUpgrade(ship, run) {
    const closed = this.refusal();
    if (closed) return { ok: false, message: closed };
    if (!this.stock.reactorUpgrade) return { ok: false, message: 'No reactor upgrade available.' };

    const cost = this.reactorCost(ship);
    // Max BEFORE money: a maxed reactor with a light purse used to be
    // reported as "Insufficient CC.", which is the wrong reason and sends
    // the player off to earn CC they can never spend.
    if (ship.reactor.level >= ship.reactor.maxLevel) {
      return { ok: false, message: 'Reactor at maximum.' };
    }
    if (run.scrap < cost) return { ok: false, message: `Insufficient CC — needs ${cost}.` };
    if (!ship.reactor.upgrade()) return { ok: false, message: 'Reactor at maximum.' };
    // Upgrades are always available — no one-per-station limit
    Save.updateRun({ scrap: run.scrap - cost });
    Audio.sfx.powerUp();
    return { ok: true, cost, message: `Reactor upgraded to level ${ship.reactor.level}.` };
  }

  // ── Price helpers ────────────────────────────────────────

  hullRepairCost(hp = 1)  { return Math.round(hp  * REPAIR_PRICES.hull * this._priceFactor()); }
  fuelCost(amt = 1)       { return Math.round(amt * FUEL_PRICE          * this._priceFactor()); }
  missileCost(amt = 1)    { return Math.round(amt * MISSILE_PRICE       * this._priceFactor()); }
  torpedoCost(amt = 1)    { return Math.round(amt * TORPEDO_PRICE       * this._priceFactor()); }

  /** Torpedoes into torpedo racks (update94) — the missile purchase, rack for rack. */
  buyTorpedoes(amount, run, ship = null) {
    const closed = this.refusal();
    if (closed) return { ok: false, message: closed };
    let avail = Math.min(amount, this.stock.torpedoes ?? 0);
    if (avail <= 0) return { ok: false, message: 'No torpedoes available.' };
    const hold = ship?.cargo;
    if (!hold) return { ok: false, message: 'Nothing to load them into.' };
    const probe = CargoGrid.deserialise(hold.serialise());
    avail -= probe.addStack('torpedo_rack', avail);
    if (avail <= 0) return { ok: false, message: 'No room in the hold for torpedoes.' };
    const cost = this.torpedoCost(avail);
    if (run.scrap < cost) return { ok: false, message: 'Insufficient CC.' };
    this.stock.torpedoes -= avail;
    hold.addStack('torpedo_rack', avail);
    Save.updateRun({ scrap: run.scrap - cost });
    Audio.sfx.scrapCollect();
    return { ok: true, cost, message: `Loaded ${avail} torpedo${avail > 1 ? 'es' : ''}.` };
  }
  reactorCost(ship)       { return Math.round(REACTOR_PRICE(ship.reactor.level) * this._priceFactor()); }

  /** What a port wants for one meal of a given kind. The item's own
   *  value is the base — one register — and karma is applied here the
   *  same way it is applied to everything else across this counter. */
  /** One kit, five doses (update93a) — the doses' own value, karma applied. */
  medkitCost(amt = 1) {
    const d = (typeof CARGO_ITEMS !== 'undefined') ? CARGO_ITEMS.medkit : null;
    const base = d ? (d.unitValue ?? 6) * (d.stackMax ?? 5) : 30;
    return Math.round(amt * base * this._priceFactor());
  }

  /** Buy kits: probe a copy of the hold first, charge only for what fits. */
  buyMedkits(amount, run, ship = null) {
    const closed = this.refusal();
    if (closed) return { ok: false, message: closed };
    let want = Math.min(amount, this.stock.medkits ?? 0);
    if (want <= 0) return { ok: false, message: 'None of that left here.' };
    const hold = ship?.cargo;
    if (!hold) return { ok: false, message: 'Nothing to load it into.' };
    const probe = CargoGrid.deserialise(hold.serialise());
    let fits = 0;
    while (fits < want && probe.add('medkit')) fits++;
    if (fits <= 0) return { ok: false, message: 'No room in the hold.' };
    const cost = this.medkitCost(fits);
    if (run.scrap < cost) return { ok: false, message: 'Insufficient CC.' };
    for (let i = 0; i < fits; i++) hold.add('medkit');
    this.stock.medkits -= fits;
    Save.updateRun({ scrap: run.scrap - cost });
    Audio.sfx.scrapCollect();
    return { ok: true, cost, message: `Loaded ${fits} × Medical Supplies (${fits * (CARGO_ITEMS.medkit?.stackMax ?? 5)} doses).` };
  }

  rationCost(key, amt = 1) {
    const base = (typeof CARGO_ITEMS !== 'undefined' && CARGO_ITEMS[key]?.unitValue) || 8;
    return Math.round(amt * base * this._priceFactor());
  }

  /**
   * Buy meals. Deliberately the same shape as `buyFuel` and
   * `buyMissiles` — probe a COPY of the hold first, so the player is
   * only ever charged for what actually fits.
   */
  buyRations(key, amount, run, ship = null) {
    const closed = this.refusal();
    if (closed) return { ok: false, message: closed };
    const def = (typeof CARGO_ITEMS !== 'undefined') ? CARGO_ITEMS[key] : null;
    if (!def || def.tag !== 'food') return { ok: false, message: 'Not food.' };
    let avail = Math.min(amount, this.stock.rations?.[key] ?? 0);
    if (avail <= 0) return { ok: false, message: 'None of that left here.' };

    const hold = ship?.cargo;
    if (!hold) return { ok: false, message: 'Nothing to load it into.' };
    const probe = CargoGrid.deserialise(hold.serialise());
    avail -= probe.addStack(key, avail);
    if (avail <= 0) return { ok: false, message: 'No room in the hold.' };

    const cost = this.rationCost(key, avail);
    if (run.scrap < cost) return { ok: false, message: 'Insufficient CC.' };

    this.stock.rations[key] -= avail;
    hold.addStack(key, avail);
    Save.updateRun({ scrap: run.scrap - cost });
    Audio.sfx.scrapCollect();
    return { ok: true, cost, message: `Loaded ${avail} × ${def.label}.` };
  }

  /* ── THE QUARTERMASTER'S COUNTER (update143) ─────────────
   *
   * jj, 20.10: the port is a promenade of stalls, and at the
   * quartermaster's you DRAG what you want off his counter into your
   * hold — the same cells, crates and hand as the loadout.
   *
   * The counter is not a second stock. `this.stock` stays the one
   * register (the DOM tabs, the tests and the black market all read
   * it); the counter is laid out FROM it every time it is opened, and
   * every crate that crosses it moves the stock and the money through
   * `transferAtCounter` — once, here, with the same quote methods the
   * buy buttons use, karma and all.
   */
  counterGrid() {
    const st = this.stock;
    const lay = (rows) => {
      const g = new CargoGrid(Station.COUNTER_COLS, rows);
      let left = 0;
      left += g.addStack('he2_med', st.fuel ?? 0);
      left += g.addStack('missile_rack', st.missiles ?? 0);
      left += g.addStack('torpedo_rack', st.torpedoes ?? 0);
      for (let i = 0; i < Math.floor(st.medkits ?? 0); i++) if (!g.add('medkit')) left++;
      Object.entries(st.rations ?? {}).forEach(([k, n]) => { left += g.addStack(k, n); });
      left += g.addStack('he3_ore', st.he3 ?? 0);
      return { g, left };
    };
    let rows = 6, out = lay(rows);
    while (out.left > 0 && rows < 24) out = lay(++rows);    // a long counter scrolls
    return out.g;
  }
  static get COUNTER_COLS() { return 6; }
  /** What he gives back for what he charges: half, before any karma. */
  static get COUNTER_BUYBACK() { return 0.5; }

  /** What this counter charges for `qty` of a crate's contents, or null
   *  when it is not his trade (a gun, a body, a chip, a spoiled crate). */
  counterPrice(it, qty = it?.qty) {
    if (!it || it.damaged || !(qty > 0)) return null;
    const k = it.def?.kind, key = it.defKey;
    if (key === 'he3_ore') return this.he3Cost(qty);
    if (!it.isStack) return null;
    if (k === 'fuel')      return this.fuelCost(qty);
    if (k === 'missiles')  return this.missileCost(qty);
    if (k === 'torpedoes') return this.torpedoCost(qty);
    if (key === 'medkit')  return this.medkitCost(1);
    if (k === 'food')      return this.rationCost(key, qty);
    return null;
  }
  /** What he pays for it across the counter, or null. */
  counterSellPrice(it, qty = it?.qty) {
    const p = this.counterPrice(it, qty);
    return p == null ? null : Math.floor(p / this._priceFactor() * Station.COUNTER_BUYBACK);
  }

  _counterStock(it, qty) {
    const st = this.stock, k = it.def.kind, key = it.defKey;
    if (key === 'he3_ore')      st.he3 = Math.max(0, (st.he3 ?? 0) + qty);
    else if (k === 'fuel')      st.fuel = Math.max(0, (st.fuel ?? 0) + qty);
    else if (k === 'missiles')  st.missiles = Math.max(0, (st.missiles ?? 0) + qty);
    else if (k === 'torpedoes') st.torpedoes = Math.max(0, (st.torpedoes ?? 0) + qty);
    else if (key === 'medkit')  st.medkits = Math.max(0, (st.medkits ?? 0) + Math.sign(qty));
    else if (k === 'food')      { st.rations ??= {}; st.rations[key] = Math.max(0, (st.rations[key] ?? 0) + qty); }
  }

  /**
   * One crate (or `qty` of it) across the counter. `dir` 'buy' takes it
   * off his counter into the hold; 'sell' puts it on his counter.
   * Refused with the reason, and then nothing moves.
   */
  transferAtCounter(it, qty, dir) {
    const closed = this.refusal();
    if (closed) return { ok: false, message: closed };
    if (!it) return { ok: false, message: 'Nothing in hand.' };
    if (it.damaged) return { ok: false, message: 'Spoiled — he will not touch it. The BROKER buys scrap.' };
    const price = this.counterPrice(it, qty);
    if (price == null) return { ok: false, message: 'The quartermaster does not deal in that — try the BROKER.' };
    /* A KIT IS SEALED. Stock is counted in kits, and a kit is five doses:
       half a kit across the counter would be half a box on his books. */
    if (it.defKey === 'medkit' && qty !== it.stackMax) {
      return { ok: false, message: 'He sells and takes back sealed kits only — five doses.' };
    }
    const run = Save.getRun();
    if (!run) return { ok: false, message: 'No contract running.' };
    if (dir === 'buy') {
      if (run.scrap < price) return { ok: false, message: `Not enough CC — ${price} CC, you have ${run.scrap}.` };
      Save.updateRun({ scrap: run.scrap - price });
      this._counterStock(it, -qty);
      this._note(it.label, qty, -price);
      Audio.sfx?.scrapCollect?.();
      return { ok: true, cost: price, message: `Bought ${qty > 1 ? qty + ' × ' : ''}${it.label} — ${price} CC` };
    }
    const paid = this.counterSellPrice(it, qty);
    Save.updateRun({ scrap: run.scrap + paid });
    this._counterStock(it, qty);
    this._note(it.label, qty, paid);
    Audio.sfx?.scrapCollect?.();
    return { ok: true, paid, message: `Sold ${qty > 1 ? qty + ' × ' : ''}${it.label} — ${paid} CC` };
  }

  /* ── THE BROKER (update144) ────────────────────────────────
   *
   * He buys what you carry, at what this KIND of port pays for it
   * (`CargoItem.value(type)` — a research post pays for data cores, a
   * frontier outpost pays little and asks nothing). One set of rules for
   * his counter AND the old CARGO panel, here, so the two can never
   * quote different prices:
   *   · `sellRefusal` — your own dead, an enemy bag outside a research
   *     post, ruined contraband — not for sale at all;
   *   · contraband at a fleet yard is SEIZED, with a fine, not bought.
   */
  static get CONTRABAND_FINE() { return 25; }

  brokerSeizes(it) { return !!it?.def?.contraband && this.type === 'military' && !this.blackMarket; }

  /** What he pays for `qty` of it (a whole crate by default), 0 for a
   *  seizure, null when it is not for sale here. */
  brokerPrice(it, qty = it?.qty) {
    if (!it) return null;
    if (it.sellRefusal?.(this.type)) return null;
    if (this.brokerSeizes(it)) return 0;
    const v = it.value(this.type);
    return (it.isStack && it.qty > 0) ? Math.round(v * qty / it.qty) : v;
  }

  /** The crate (or `qty` of it) is his. Refused with the reason, and then
   *  nothing moves. */
  sellToBroker(it, qty = it?.qty) {
    const closed = this.refusal();
    if (closed) return { ok: false, message: closed };
    if (!it) return { ok: false, message: 'Nothing in hand.' };
    const no = it.sellRefusal?.(this.type);
    if (no) return { ok: false, message: `Not for sale — ${no}.` };
    const run = Save.getRun();
    if (!run) return { ok: false, message: 'No contract running.' };
    if (this.brokerSeizes(it)) {
      const fine = Station.CONTRABAND_FINE;
      Save.updateRun({ scrap: Math.max(0, run.scrap - fine) });
      this._note(`${it.label} (seized)`, 1, -Math.min(fine, run.scrap));
      return { ok: true, seized: true, message: `Customs seized the ${it.label} — and fined you ${fine} CC` };
    }
    const price = this.brokerPrice(it, qty);
    Save.updateRun({ scrap: run.scrap + price });
    this._note(it.label, it.isStack ? qty : 1, price);
    Audio.sfx?.scrapCollect?.();
    return { ok: true, paid: price, message: `Sold ${it.isStack && qty > 1 ? qty + ' × ' : ''}${it.label} for ${price} CC` };
  }

  /** The broker's counter: empty when you walk up; what you sell lands on it. */
  brokerGrid() { return new CargoGrid(Station.COUNTER_COLS, 6); }

  /* ── THE GUNSMITH'S COUNTER (update145) ──────────────────
   *
   * His rack is `stock.weapons`, laid out as the very crates a yard
   * boxes a gun in (`cargoCrateForWeapon` — the crate `Ship.boxWeapon`
   * makes), so a gun bought here is a crate in your hold like any other,
   * and UNBOX & FIT bolts it on. One register again: each crate carries
   * its place in the stock (`_stock`), and buying marks that entry sold.
   * A gun sold to him goes back on his rack at his own price.
   */
  gunsmithGrid() {
    const g = new CargoGrid(Station.COUNTER_COLS, 6);
    (this.stock.weapons ?? []).forEach((w, i) => {
      if (w.sold || typeof cargoCrateForWeapon !== 'function') return;
      const it = new CargoItem(cargoCrateForWeapon(w.key), w.key);
      it._stock = i;
      if (!g.autoPlace(it)) { g.rows++; g.autoPlace(it); }
    });
    return g;
  }

  /** What his crate costs: the rack's price, karma and all. */
  gunPrice(it) {
    if (it?.def?.kind !== 'weapon' || it._stock == null) return null;
    const w = this.stock.weapons?.[it._stock];
    return w && !w.sold ? this.weaponCost(w) : null;
  }
  /** What he pays for a boxed gun of yours — half its list price, the
   *  same as the old CARGO panel's SELL (`sellCargoWeapon`). */
  gunSellPrice(it) {
    if (it?.def?.kind !== 'weapon' || !it.meta || it.damaged) return null;
    return Math.floor((WEAPON_DEFS[it.meta]?.cost ?? 20) * 0.5);
  }

  /** One crate across his counter: 'buy' off his rack, 'sell' onto it. */
  transferAtGunsmith(it, dir) {
    const closed = this.refusal();
    if (closed) return { ok: false, message: closed };
    if (it?.def?.kind !== 'weapon' || !it.meta) return { ok: false, message: 'He deals in guns — the BROKER takes the rest.' };
    const run = Save.getRun();
    if (!run) return { ok: false, message: 'No contract running.' };
    const label = WEAPON_DEFS[it.meta]?.label ?? it.label;
    if (dir === 'buy') {
      const price = this.gunPrice(it);
      if (price == null) return { ok: false, message: 'Not for sale.' };
      if (run.scrap < price) return { ok: false, message: `Not enough CC for the ${label} — ${price} CC, you have ${run.scrap}.` };
      Save.updateRun({ scrap: run.scrap - price });   // the gun is paid for
      this.stock.weapons[it._stock].sold = true;
      it._stock = null;
      this._note(label, 1, -price);
      Audio.sfx?.powerUp?.();
      return { ok: true, cost: price, message: `${label} — ${price} CC. UNBOX & FIT bolts it on.` };
    }
    if (it.damaged) return { ok: false, message: 'Spoiled — he will not take it. The BROKER buys scrap.' };
    const paid = this.gunSellPrice(it);
    Save.updateRun({ scrap: run.scrap + paid });
    (this.stock.weapons ??= []).push({ key: it.meta, def: WEAPON_DEFS[it.meta], sold: false });
    it._stock = this.stock.weapons.length - 1;
    this._note(label, 1, paid);
    Audio.sfx?.scrapPickup?.();
    return { ok: true, paid, message: `Sold the ${label} for ${paid} CC — it is on his rack now.` };
  }

  /** A hand's signing fee. Reads the BARRACKS side of karma, not the
   *  shop side — people are not stock, and a good name is worth a
   *  discount here where it buys nothing at the fuel pump. */
  crewCost() {
    const f = (typeof Commander !== 'undefined' && Commander.recruitFactor)
      ? Commander.recruitFactor() : 1;
    return Math.round(CREW_PRICE * f);
  }

  /**
   * WILL THIS PORT DEAL WITH HIM AT ALL (update61)?
   *
   * Returns the reason to put on screen, or null when the dock is
   * open. The decision itself lives in commander.js and is
   * deterministic in this station's own seed, so a port that turned
   * you away is still turning you away when you come back — and only
   * a small share of them ever do, or a low-karma run would simply
   * strand with no fuel to buy anywhere.
   */
  refusal() {
    /* HE DOES NOT CARE WHAT YOUR NAME IS (update70) — that is what he
       is FOR. The refusal below reads karma, and a black market that
       turned away the only commanders it exists to serve would be a
       door with nothing behind it. */
    if (this.blackMarket) return null;
    if (typeof Commander === 'undefined' || !Commander.portRefuses) return null;
    if (!Commander.portRefuses(this.seed)) return null;
    return `${this.name} will not trade with you. `
         + 'Word of what you did got here first.';
  }
}
