/* ============================================================
   MOON WARS — renderer.js
   Main canvas rendering pipeline.
   Owns the canvas, manages resolution, orchestrates all
   draw calls in correct layer order.
   ============================================================ */

'use strict';

const Renderer = (() => {

  let _canvas  = null;
  let _ctx     = null;
  let _W       = 1280;
  let _H       = 720;
  let _pixelRatio = 1;

  // Parallax star layers
  const _starLayers = [
    { speed: 0.05, alpha: 0.6 },
    { speed: 0.12, alpha: 0.8 },
  ];
  let _starOffset = 0;

  // ── Init ────────────────────────────────────────────────

  function init(canvasEl) {
    _canvas = canvasEl;
    _ctx    = _canvas.getContext('2d');
    _resize();
    window.addEventListener('resize', _resize);
    return _ctx;
  }

  function _resize() {
    const winW  = window.innerWidth;
    const winH  = window.innerHeight;
    const scale = Math.min(winW / _W, winH / _H);

    _canvas.style.width  = Math.round(_W * scale) + 'px';
    _canvas.style.height = Math.round(_H * scale) + 'px';
    _canvas.width        = _W;
    _canvas.height       = _H;

    // Inform input system of CSS→canvas scale
    const rect = _canvas.getBoundingClientRect();
    Input.setScale(
      rect.width  / _W || 1,
      rect.height / _H || 1
    );

    Camera.resize(_W, _H);
  }

  function getCtx()    { return _ctx; }
  function getWidth()  { return _W; }
  function getHeight() { return _H; }

  // ── Clear ───────────────────────────────────────────────

  function clear() {
    _ctx.clearRect(0, 0, _W, _H);
    _ctx.fillStyle = '#07080f';
    _ctx.fillRect(0, 0, _W, _H);
  }

  // ── Starfield background ─────────────────────────────────

  function drawBackground(scrollX = 0) {
    const stars = Assets.get('bg_stars');
    const moon  = Assets.get('bg_moon');

    if (stars) {
      // Layer 1: slow parallax
      const off1 = ((-scrollX * 0.05) % _W + _W) % _W;
      _ctx.globalAlpha = 0.7;
      _ctx.drawImage(stars, off1 - _W, 0, _W, _H);
      _ctx.drawImage(stars, off1,      0, _W, _H);

      // Layer 2: faster
      _ctx.globalAlpha = 0.5;
      const off2 = ((-scrollX * 0.15) % _W + _W) % _W;
      _ctx.drawImage(stars, off2 - _W, 0, _W, _H);
      _ctx.drawImage(stars, off2,      0, _W, _H);
      _ctx.globalAlpha = 1;
    } else {
      _ctx.fillStyle = '#07080f';
      _ctx.fillRect(0, 0, _W, _H);
    }

    // Moon in background
    if (moon) {
      _ctx.globalAlpha = 0.18;
      _ctx.drawImage(moon, _W - 260, 30, 200, 200);
      _ctx.globalAlpha = 1;
    }
  }

  // ── HUD ─────────────────────────────────────────────────

  const _powerClickZones = [];
  function getPowerClickZones() { return _powerClickZones; }
  /* The mark strip's hover boxes. A separate list from the click
     zones on purpose: a mark is not a button, and putting it in
     `_powerClickZones` would make every tooltip a thing game.js has to
     remember NOT to act on. */
  const _crewMarkZones = [];
  function getCrewMarkZones() { return _crewMarkZones; }

  /** Tiny status icon: 'crew' | 'fire' | 'noO2' — drawn at (x,y), ~12px */
  function _statusIcon(ctx, x, y, type) {
    ctx.save();
    if (type === 'crew') {
      // Little person: head + body
      ctx.fillStyle = '#4db8ff';
      ctx.beginPath(); ctx.arc(x, y - 3, 3, 0, Math.PI * 2); ctx.fill();
      ctx.fillRect(x - 3, y, 6, 6);
    } else if (type === 'fire') {
      // Orange flame triangle with yellow core
      ctx.fillStyle = '#ff7c20';
      ctx.beginPath();
      ctx.moveTo(x, y - 6); ctx.lineTo(x - 5, y + 5); ctx.lineTo(x + 5, y + 5);
      ctx.closePath(); ctx.fill();
      ctx.fillStyle = '#ffd700';
      ctx.beginPath();
      ctx.moveTo(x, y - 1); ctx.lineTo(x - 2, y + 4); ctx.lineTo(x + 2, y + 4);
      ctx.closePath(); ctx.fill();
    } else if (type === 'noO2') {
      // Blue circle with slash
      ctx.strokeStyle = '#4db8ff';
      ctx.lineWidth = 1.5;
      ctx.beginPath(); ctx.arc(x, y, 5.5, 0, Math.PI * 2); ctx.stroke();
      ctx.fillStyle = '#4db8ff';
      ctx.font = '8px monospace';
      ctx.textAlign = 'center';
      ctx.fillText('O', x, y + 3);
      ctx.strokeStyle = '#ff2d44';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(x - 5, y + 5); ctx.lineTo(x + 5, y - 5);
      ctx.stroke();
    }
    ctx.restore();
  }

  /** Status icons for a system's room: crew present, fire, low O2 */
  function _roomStatus(ship, sys) {
    const out = [];
    if (!sys.roomId) return out;
    if (ship.crew.some(c => !c.dead && c.roomId === sys.roomId)) out.push('crew');
    if (ship.fires.hasFireInRoom(sys.roomId)) out.push('fire');
    const ro = ship.oxygen.getRoom(sys.roomId);
    if (ro && ro.isWarning) out.push('noO2');
    return out;
  }

  /**
   * EVERY crew member the player owns, wherever they are standing.
   *
   * The roster used to be a flat `playerShip.crew.forEach`, which got it
   * wrong in both directions (update42): a boarding party is moved OUT
   * of playerShip.crew and INTO enemyShip.crew the moment it casts off,
   * so your away team vanished from the panel — no portrait, no HP bar,
   * no way to select them — for the whole fight they were sent to win;
   * meanwhile enemy boarders, spiders and rats standing on YOUR deck are
   * in playerShip.crew and got rows of their own.
   *
   * Own the list explicitly: our people on our hull, then our people on
   * theirs, flagged so the panel can say where they are.
   */
  function crewRoster(state) {
    const mine = (state.playerShip?.crew ?? []).filter(c => c.isPlayer);
    mine.forEach(c => { c._awayTeam = false; });
    const away = (state.enemyShip?.crew ?? []).filter(c => c.isPlayer);
    away.forEach(c => { c._awayTeam = true; });
    return mine.concat(away);
  }

  /* WHERE THE COMMANDER STRIP IS. Published, because update52a makes
     it clickable from the map and the hit test must be the very
     rectangle that was drawn — two copies of these four numbers would
     drift the first time the HUD moved. */
  function commanderStripRect() { return { x: 14, y: 84, w: 120, h: 20 }; }

  /* ══ THE COMMANDER'S DOSSIER (update52a) ═══════════════════
   *
   * Everything about one commander on one panel: who he is, what rank
   * and level, how far to the next, his karma and what it buys him,
   * what he has actually chosen his levels on, his specialisations,
   * and a read-only picture of his CPU board.
   *
   * It lives HERE rather than in the base screen because two places
   * open it — the mess card and the HUD strip out on the map — and a
   * second copy of this layout would be a second thing to keep true.
   * It draws and nothing else: the caller owns whether it is open and
   * where the click came from.
   *
   * Returns the rectangles the caller has to hit-test.
   */
  function drawCommanderDossier(ctx, cap, opts = {}) {
    const W = _W, H = _H;
    const PW = 520, PH = 400;
    const px = Math.round(W / 2 - PW / 2), py = Math.round(H / 2 - PH / 2);
    /* RENAME sits beside CLOSE (update54) — the file is where the
       player looks at a commander, so it is where he expects to be able
       to correct his name. Same rectangle list as everything else in
       here: the caller hit-tests exactly what was drawn. */
    const out = { panel: { x: px, y: py, w: PW, h: PH },
                  close:  { x: px + PW - 92,  y: py + PH - 38, w: 80, h: 26 },
                  rename: { x: px + PW - 184, y: py + PH - 38, w: 84, h: 26 } };
    if (!cap) return out;

    // Dim what is behind it, so the panel reads as modal.
    ctx.fillStyle = 'rgba(4,7,14,0.78)';
    ctx.fillRect(0, 0, W, H);

    ctx.fillStyle = 'rgba(13,17,32,0.98)';
    ctx.beginPath(); ctx.roundRect(px, py, PW, PH, 8); ctx.fill();
    ctx.strokeStyle = '#ffd700'; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.roundRect(px, py, PW, PH, 8); ctx.stroke();

    const corp = (typeof CORP_DEFS !== 'undefined' && CORP_DEFS[cap.race]?.label)
      || cap.race || '—';
    const lvl  = cap.level ?? 1;
    const rank = (typeof rankName !== 'undefined') ? rankName(lvl) : '';

    // ── header ──
    ctx.fillStyle = crewColor(cap);
    ctx.fillRect(px + 18, py + 18, 30, 30);
    ctx.fillStyle = '#c8d8f0';
    ctx.fillRect(px + 22, py + 22, 22, 11);          // helmet
    ctx.fillStyle = '#ffd700';
    ctx.font = '16px Orbitron, monospace';
    ctx.textAlign = 'left';
    ctx.fillText(String(cap.name || '—'), px + 58, py + 32);
    ctx.fillStyle = '#7a90a8';
    ctx.font = '11px Share Tech Mono, monospace';
    ctx.fillText(`${corp}   ·   SHIP COMMANDER`, px + 58, py + 48);

    ctx.textAlign = 'right';
    ctx.fillStyle = '#4dd8c0';
    ctx.font = '13px Share Tech Mono, monospace';
    ctx.fillText(rank, px + PW - 18, py + 32);
    ctx.fillStyle = '#7a90a8';
    ctx.font = '10px Share Tech Mono, monospace';
    const maxL = (typeof Commander !== 'undefined') ? Commander.MAX_LEVEL : 24;
    ctx.fillText(`LEVEL ${lvl} / ${maxL}`, px + PW - 18, py + 48);
    ctx.textAlign = 'left';

    /* ── the XP bar, on its own line with nothing beside it.
       Crowding this was exactly what made the mess card unreadable. */
    const need = (typeof Commander !== 'undefined') ? Commander.xpToNext(cap) : 0;
    const prog = (typeof Commander !== 'undefined') ? Commander.xpProgress(cap) : 0;
    ctx.fillStyle = '#0a1018';
    ctx.fillRect(px + 18, py + 62, PW - 36, 8);
    ctx.fillStyle = '#1a8cff';
    ctx.fillRect(px + 18, py + 62, (PW - 36) * Utils.clamp(prog, 0, 1), 8);
    ctx.fillStyle = '#5f7893';
    ctx.font = '9px Share Tech Mono, monospace';
    ctx.fillText(need ? `${Math.round(cap.xp || 0)} / ${need} XP to the next promotion`
                      : 'TOP OF THE LADDER — no promotions left',
                 px + 18, py + 82);

    // ── left column: karma, picks, bonuses ──
    const LX = px + 18;
    let ly = py + 108;
    const head = (t) => {
      ctx.fillStyle = '#4db8ff'; ctx.font = '10px Orbitron, monospace';
      ctx.fillText(t, LX, ly); ly += 16;
    };
    const line = (t, col = '#c8d8f0') => {
      ctx.fillStyle = col; ctx.font = '10px Share Tech Mono, monospace';
      ctx.fillText(t, LX, ly); ly += 14;
    };

    head('KARMA');
    const karma = Math.round(cap.karma ?? 50);
    if (typeof Chips !== 'undefined') {
      const wall = Chips.wallColumn(karma);
      line(`${karma} / 100`, karma >= 66 ? '#4dd8c0' : karma <= 34 ? '#ff9a4d' : '#c8d8f0');
      line(`${wall - 1} Ethos columns · ${Chips.COLS - wall} Dominance`, '#7a90a8');
    } else { line(`${karma} / 100`); }

    /* WHAT THE WORLD DOES ABOUT IT (update61). The chip wall used to
       be the only consequence on this card, which made karma read as a
       board-layout stat. These three lines are the ports and the
       barracks, worded in commander.js so the shop banner and this
       card cannot disagree. */
    if (typeof Commander !== 'undefined' && Commander.karmaWorldLines) {
      Commander.karmaWorldLines(karma).forEach(t =>
        line(t, /\+\d|not trade/.test(t) ? '#ff9a4d'
              : /less/.test(t) ? '#4dd8c0' : '#7a90a8'));
    }
    ly += 6;

    head('LEVEL-UP PICKS');
    const owed = (typeof Commander !== 'undefined') ? Commander.picksOwed(cap) : 0;
    if (owed > 0) line(`${owed} UNSPENT — the crew are not getting them`, '#ffd700');
    (typeof Commander !== 'undefined' ? Commander.bonusLines(cap) : [])
      .forEach(([v, label]) => line(`${v}  ${label}`, '#1aff8c'));
    ly += 6;

    /* ── SPECIALISATIONS. The one thing the mess card could not say
       before update52a, and the one the player most needs: a skill
       counts only when it is FULLY mastered, 3 of 3. A crewman with
       three skills at one square each brings NOTHING here, and the
       panel has to say so in words rather than by showing a blank. */
    head('SPECIALISATIONS');
    const spec = Array.isArray(cap.specialties) ? cap.specialties : [];
    if (!spec.length) {
      line('none', '#ff7c20');
      line('a skill counts only at 3/3', '#5f7893');
    } else {
      spec.forEach(k => line('· ' + ((typeof SKILL_DEFS !== 'undefined'
        && SKILL_DEFS[k]?.label) || k), '#4dd8c0'));
    }

    // ── right column: the CPU board, read-only ──
    if (typeof Chips !== 'undefined') {
      const CELL = 30, GAP = 4;
      const bw = Chips.COLS * CELL + (Chips.COLS - 1) * GAP;
      const bx = px + PW - 18 - bw, by = py + 122;
      ctx.fillStyle = '#4db8ff'; ctx.font = '10px Orbitron, monospace';
      ctx.textAlign = 'left';
      ctx.fillText('CPU BOARD', bx, by - 14);
      ctx.fillStyle = '#5f7893'; ctx.font = '9px Share Tech Mono, monospace';
      ctx.textAlign = 'right';
      ctx.fillText(`${Chips.cellsFor(lvl)}/${Chips.COLS * Chips.ROWS} cells`,
                   bx + bw, by - 14);
      ctx.textAlign = 'left';

      const grid = Chips.board(cap);
      for (let y = 0; y < Chips.ROWS; y++) {
        for (let x = 0; x < Chips.COLS; x++) {
          const cx = bx + x * (CELL + GAP), cy = by + y * (CELL + GAP);
          const open = Chips.cellOpen(cap, x, y);
          const wall = Chips.sideOfColumn(x, cap.karma) === 'wall';
          ctx.fillStyle = !open ? 'rgba(26,28,34,0.95)'
                        : wall  ? 'rgba(40,26,20,0.9)'
                                : 'rgba(13,17,32,0.85)';
          ctx.beginPath(); ctx.roundRect(cx, cy, CELL, CELL, 3); ctx.fill();
          ctx.strokeStyle = !open ? '#39404e' : wall ? '#4a3324' : '#1c2740';
          ctx.lineWidth = 1;
          ctx.beginPath(); ctx.roundRect(cx, cy, CELL, CELL, 3); ctx.stroke();
          if (!open) {
            ctx.fillStyle = 'rgba(150,158,175,0.55)';
            ctx.font = '9px Share Tech Mono, monospace';
            ctx.textAlign = 'center';
            ctx.fillText(String(Chips.cellOpensAt(x, y)), cx + CELL / 2, cy + CELL / 2 + 3);
            ctx.textAlign = 'left';
          }
        }
      }
      // The chips themselves, drawn over the grid.
      (grid?.items || []).forEach(it => {
        const cx = bx + it.x * (CELL + GAP), cy = by + it.y * (CELL + GAP);
        const w = it.w * CELL + (it.w - 1) * GAP, h = it.h * CELL + (it.h - 1) * GAP;
        const dead = Chips.isInert(cap, it);
        const col = (Chips.FAMILIES[it.def.chipFamily] || {}).col || '#b8c4d4';
        ctx.fillStyle = dead ? 'rgba(60,26,32,0.9)' : 'rgba(20,40,56,0.9)';
        ctx.beginPath(); ctx.roundRect(cx, cy, w, h, 3); ctx.fill();
        ctx.strokeStyle = dead ? '#ff5566' : col; ctx.lineWidth = 1;
        ctx.beginPath(); ctx.roundRect(cx, cy, w, h, 3); ctx.stroke();
        ctx.fillStyle = dead ? '#ff5566' : col;
        ctx.font = '9px Share Tech Mono, monospace';
        ctx.textAlign = 'center';
        ctx.fillText(Chips.roman(it.def.chipLevel ?? 1), cx + w / 2, cy + h / 2 + 3);
        ctx.textAlign = 'left';
      });

      ctx.fillStyle = '#5f7893';
      ctx.font = '9px Share Tech Mono, monospace';
      ctx.fillText('read-only — chips are moved at base',
                   bx, by + Chips.ROWS * (CELL + GAP) + 12);
    }

    // ── close ──
    const c = out.close;
    const hot = Utils.pointInRect(Input.mouse.x, Input.mouse.y, c.x, c.y, c.w, c.h);
    ctx.fillStyle = hot ? 'rgba(26,140,255,0.25)' : 'rgba(20,30,50,0.9)';
    ctx.beginPath(); ctx.roundRect(c.x, c.y, c.w, c.h, 4); ctx.fill();
    ctx.strokeStyle = '#4db8ff'; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.roundRect(c.x, c.y, c.w, c.h, 4); ctx.stroke();
    ctx.fillStyle = '#4db8ff';
    ctx.font = '11px Share Tech Mono, monospace';
    ctx.textAlign = 'center';
    ctx.fillText('CLOSE', c.x + c.w / 2, c.y + 17);

    const rn = out.rename;
    const rhot = Utils.pointInRect(Input.mouse.x, Input.mouse.y, rn.x, rn.y, rn.w, rn.h);
    ctx.fillStyle = rhot ? 'rgba(122,144,168,0.25)' : 'rgba(20,30,50,0.9)';
    ctx.beginPath(); ctx.roundRect(rn.x, rn.y, rn.w, rn.h, 4); ctx.fill();
    ctx.strokeStyle = '#7a90a8'; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.roundRect(rn.x, rn.y, rn.w, rn.h, 4); ctx.stroke();
    ctx.fillStyle = '#7a90a8';
    ctx.fillText('RENAME', rn.x + rn.w / 2, rn.y + 17);

    ctx.textAlign = 'left';
    return out;
  }


  /* ── WHERE EVERY ORDER BUTTON IS ─────────────────────────
   *
   * One function, one layout. game.js hit-tests BOARD, RECALL and
   * RETREAT against exactly the rectangles drawn here, so a button
   * cannot move on screen without its click moving with it.
   *
   * `top` is remembered from the last HUD frame because the panel
   * hangs under a crew list whose length changes as people die, and
   * the click arrives on the frame AFTER the draw.
   */
  /* ── PIPS INSTEAD OF BARS (update54) ──────────────────────
   *
   * A continuous bar says "some", "most", "nearly none". Pips say a
   * NUMBER: five boxes at twenty hit points each, so a crewman two
   * boxes down is forty off and the player can read that at a glance
   * without hovering. Same reasoning as the power bar, which has been
   * pips since the beginning — this brings the crew readouts in line
   * with the one readout in the game that was already legible.
   *
   * Twenty a box, not ten: ten boxes across a hundred-and-twenty pixel
   * card leaves each one four pixels wide with nothing between them,
   * which is a bar again, only uglier.
   *
   * ONE drawer for all of them, so the crew list, the roster panel and
   * the hover card cannot drift into three different-looking readouts
   * of the same number.
   */
  /* ── THE TWO SICKNESSES, AND THEIR COLOURS (update68) ──────
   *
   * ONE table, read by the crew roster here and by the crewman drawn
   * on the ship in crew.js — two places painting the same illness two
   * different greens is how the player ended up unable to tell a
   * nuisance from a death sentence.
   *
   *   plague — off a rotting body. Unpleasant, not fatal, and a
   *            medkit clears it. GREEN.
   *   virus  — off a void spider. Three fights and he is dead. RED.
   */
  const DISEASE_COL = { plague: '#3fd96b', virus: '#d9463c' };

  /* ══ WHAT IS WRONG WITH HIM, AND WHAT HE IS DOING (update76) ══
   *
   * Three complaints, one answer.
   *
   * ONE AT A TIME. The old drawing asked `c.virus ? … : c.infected ?
   * … : null`, so a man carrying BOTH showed only the virus and the
   * plague was invisible until he was cured of the worse thing. A
   * ladder of `?:` is a fine way to pick one colour and a terrible way
   * to report a condition.
   *
   * BESIDE THE NAME. They were drawn inside a 100px row that already
   * carries a portrait, a name, an HP bar and a star, so there was
   * room for exactly one mark and no room to ever add another. The
   * player asked for them "z boku" — the strip is its own column now,
   * clear of the row, and it grows sideways instead of fighting the
   * name for pixels.
   *
   * AND WHICH MODULE HE IS WORKING. The game has paid its skill bonus
   * to ONE man per module since update43 — the one at slot 0 — and has
   * never drawn that anywhere. Two gunners in a weapons bay look
   * identical to the player and only one of them is doing anything.
   * The mark is read off `consoleOperator`, the same call that pays
   * the bonus, so the picture cannot say one thing while the maths
   * does another.
   *
   * `crewMarks` is a FUNCTION, not a draw: the list can be asked for
   * and checked, which is how "both diseases show" is testable at all.
   */
/* WHERE THE LEFT COLUMN ENDS. The crew detail panel opens at this x
   and the mark strip has to live in the gutter before it, or the panel
   is drawn straight over the marks the moment anybody is selected —
   which is most of the time. Published, and read by ui.js, because
   two hand-written copies of one edge is how the panel came to sit on
   top of the strip in the first place (caught by the screenshot for
   update76, not by any assertion). */
  const CREW_PANEL_X = 142;
  function crewPanelX() { return CREW_PANEL_X; }

  /* The strip is 2 x 2, not a row of four: the gutter is 24px wide and
     four marks in a line would run under the panel. */
  const MARK_STEP = 12, MARK_ROWS = 2, MARK_MAX = 4;
  function crewMarks(c, ship = null) {
    if (!c || c.dead) return [];        // the row itself says DEAD
    const out = [];
    /* IN A SLAB — first, and on its own. Nothing else about him is
       happening while he is under, so nothing else needs saying. */
    if (c.frozen) {
      return [{ key: 'frozen', glyph: '\u2744', col: '#7fd4ff', pulse: false,
                tip: 'IN CARBONITE — every clock stopped' }];
    }
    if (c.virus)    out.push({ key: 'virus',  glyph: '☣', col: DISEASE_COL.virus,
                               pulse: true,  tip: 'VOID-SPIDER VIRUS' });
    if (c.infected) out.push({ key: 'plague', glyph: '☣', col: DISEASE_COL.plague,
                               pulse: true,  tip: 'CORPSE PLAGUE' });

    /* Hunger, off the same bands the work speed is read from — not a
       second set of thresholds beside `HUNGER.EFFORT`. A hungry man
       works slower and nothing on this screen said so. */
    if (c.eats && typeof HUNGER !== 'undefined') {
      const h = c.hunger ?? 100;
      if (h <= HUNGER.STARVING) {
        out.push({ key: 'starving', glyph: '▼', col: '#ff2d44', pulse: true,
                   tip: 'STARVING — half speed' });
      } else if (h < HUNGER.HUNGRY) {
        out.push({ key: 'hungry', glyph: '▼', col: '#ffb020', pulse: false,
                   tip: 'HUNGRY — slower' });
      }
    }

    /* STABLE OR STILL BLEEDING (update78). The row says INJURED for
       both, and until this package that was the whole story: a man on
       the floor was a man on the floor. Now a bandage stops the clock
       and a medkit stands him up, and the player is being asked to
       spend doses on the difference — so the difference has to be on
       the screen. Without it "who is about to die" is a guess. */
    if (c.down) {
      out.push(c._bandaged
        ? { key: 'stable',   glyph: '✚', col: '#7fe08a', pulse: false,
            tip: 'BANDAGED — stable, but still down' }
        : { key: 'bleeding', glyph: '✚', col: '#ff2d44', pulse: true,
            tip: 'BLEEDING OUT — he is on a clock' });
    }

    /* HANDS FULL (update78). Every one of the new orders takes a few
       seconds, and for those seconds the man is off his console —
       `crewOperating` drops him. Without this the row simply lost its
       module glyph and gave no reason, which reads as a bug. The mark
       goes before the console branch because `consoleOperator` will
       already have answered "nobody" for him. */
    if (c.busy) {
      const act = c._busyAct;
      out.push(act === 'eat'
        ? { key: 'eating', glyph: '◓', col: '#7fe08a', pulse: false,
            tip: 'EATING — hands full' }
        : { key: 'aiding', glyph: '✚', col: '#7fe08a', pulse: false,
            tip: act === 'medkit' ? 'USING A MEDKIT — hands full'
                                  : 'BANDAGING — hands full' });
    }

    if (c._awayTeam) {
      // On the enemy hull, so he is at nobody's console — and asking
      // OUR ship about HIS room id would match by coincidence and put
      // a module mark on a man who is not aboard.
      out.push({ key: 'away', glyph: '»', col: '#ff7c20', pulse: false,
                 tip: 'ON THE ENEMY HULL' });
    } else if (ship && typeof ship.consoleOperator === 'function'
               && ship.consoleOperator(c.roomId) === c) {
      const room = ship.getRoomById ? ship.getRoomById(c.roomId) : null;
      const type = room?.system?.type ?? null;
      if (type) {
        out.push({ key: 'console', glyph: systemGlyph(type), col: '#4db8ff',
                   pulse: false, tip: `WORKING ${String(type).toUpperCase()}` });
      }
    }
    return out.slice(0, MARK_MAX);
  }

  const PIP_HP = 20;          // hit points per box

  function drawPips(ctx, x, y, w, h, value, max, col, per = PIP_HP) {
    const n = Math.max(1, Math.ceil((max || 1) / per));
    const gap = n > 6 ? 1 : 2;
    const bw = Math.max(2, (w - gap * (n - 1)) / n);
    const v = Utils.clamp(value ?? 0, 0, max || 0);
    // A man on his last few points still shows ONE lit box: an empty
    // row would read as dead, and he is not.
    const lit = v <= 0 ? 0 : Math.max(1, Math.round((v / (max || 1)) * n));
    for (let i = 0; i < n; i++) {
      ctx.fillStyle = i < lit ? col : '#1a2030';
      ctx.fillRect(x + i * (bw + gap), y, bw, h);
    }
  }

  let _orderTop = 300;
  /* Narrowed from 58 to 48 in update54 — the panel is 100 across now,
     matching the crew cards above it, and both stopped covering a
     quarter of the player's own hull. */
  const ORDER_BW = 48, ORDER_BH = 18, ORDER_GAP = 4, ORDER_X = 14;

  function orderRects() {
    const x2 = ORDER_X + ORDER_BW + ORDER_GAP;
    const row = (r) => _orderTop + 12 + r * (ORDER_BH + ORDER_GAP);
    const full = ORDER_BW * 2 + ORDER_GAP;
    const out = {
      crewSave:   { x: ORDER_X, y: row(0), w: ORDER_BW, h: ORDER_BH },
      crewReturn: { x: x2,      y: row(0), w: ORDER_BW, h: ORDER_BH },
      doorsOpen:  { x: ORDER_X, y: row(1), w: ORDER_BW, h: ORDER_BH },
      doorsClose: { x: x2,      y: row(1), w: ORDER_BW, h: ORDER_BH },
      board:      { x: ORDER_X, y: row(2), w: ORDER_BW, h: ORDER_BH },
      recall:     { x: x2,      y: row(2), w: ORDER_BW, h: ORDER_BH },
      retreat:    { x: ORDER_X, y: row(3), w: full,     h: ORDER_BH },
      specials:   [],
    };
    /* The special orders: four to a row, square, under a heading of
       their own. Which ones exist is the commander's business. */
    const list = (typeof Commander !== 'undefined' && Commander.active
                  && Commander.active())
      ? Commander.ordersFor(Commander.active()) : [];
    const SB = 26, SGAP = 4, top = row(4) + 14;
    list.forEach((def, n) => {
      out.specials.push({
        key: def.key, def,
        x: ORDER_X + (n % 4) * (SB + SGAP),
        y: top + Math.floor(n / 4) * (SB + SGAP),
        w: SB, h: SB,
      });
    });
    out.specialsTop = top;
    return out;
  }

  /* ── THE BODY MENU (update65) ─────────────────────────────
   *
   * ONE function describes it, and both the drawing below and the
   * click test in game.js read this — the rule that came out of the
   * BOARD button and `orderRects` above. A rectangle written out twice
   * is a button that drifts off the thing it is under.
   *
   * Anchored so it never runs off the canvas: a menu that opens half
   * outside the window is a menu the player cannot use, and the body
   * it belongs to can be anywhere on either hull.
   */
  /* NARROWER AND SHORTER (update68). 150x20 rows carried the full
     refusal text and the player's verdict was that the whole thing is
     "za duże za długie ze wszystkimi napisami" — a context menu that
     covers the room you are looking at.
     The reason now goes to the NOTIFICATION line instead of onto the
     row: a greyed row still tells you it is refused, and the sentence
     shows up where every other refusal in this game already shows up
     when you click it. */
  /* AND IT HANGS UNDER HIM (update69). Opening it to the SIDE put it
     on the wall — which is where the doors are — so the click that was
     meant for VENT toggled a hatch instead. Under his feet there is
     nothing but floor: the menu belongs to the man, so it sits on the
     man. Narrower again (50px) now that nothing but four short words
     has ever been drawn on a row. */
  const BODY_MENU_W = 50, BODY_MENU_ROW = 15, BODY_MENU_PAD = 3;
  const BODY_MENU_DROP = 12;              // below his feet, clear of the sprite
  function bodyMenuRects(x, y, acts = ['treat', 'eject', 'bag']) {
    const h = BODY_MENU_PAD * 2 + acts.length * BODY_MENU_ROW;
    const px = Utils.clamp(x - BODY_MENU_W / 2, 4, _W - BODY_MENU_W - 4);
    const py = Utils.clamp(y + BODY_MENU_DROP, 4, _H - h - 4);
    const out = { panel: { x: px, y: py, w: BODY_MENU_W, h }, items: [] };
    acts.forEach((act, i) => {
      out.items.push({
        act,
        x: px + BODY_MENU_PAD,
        y: py + BODY_MENU_PAD + i * BODY_MENU_ROW,
        w: BODY_MENU_W - BODY_MENU_PAD * 2,
        h: BODY_MENU_ROW - 2,
      });
    });
    return out;
  }

  /**
   * Draw it. `refusal(act)` is asked for EVERY row — the same question
   * the click will answer — so a row can never look live and then do
   * nothing, and the reason is printed rather than left to be guessed.
   */
  function drawBodyMenu(ctx, x, y, name, refusal, acts) {
    const R = bodyMenuRects(x, y, acts);
    const p = R.panel;
    ctx.fillStyle = 'rgba(8,12,22,0.96)';
    ctx.beginPath(); ctx.roundRect(p.x, p.y, p.w, p.h, 4); ctx.fill();
    ctx.strokeStyle = '#4db8ff'; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.roundRect(p.x, p.y, p.w, p.h, 4); ctx.stroke();

    /* EJECT, not VENT (update75). Since update73 the ship has a real
       ventilation duct along every ceiling — fire moves through it,
       vermin live in it, and the player reads "vent" as that. This
       button is the airlock: the body goes out into the black and does
       not come back. Two different things had one word, on one screen.

       EJECT and not JETTISON because the row is 44px of 9px monospace:
       the longer word runs off the end of its own button. */
    const LABEL = { treat: 'TREAT', eject: 'EJECT', bag: 'BAG', feed: 'FEED',
                    cell: 'CELL', freeze: 'FREEZE', thaw: 'THAW', medkit: 'MEDKIT' };
    const COL   = { treat: '#1aff8c', eject: '#ff5566', bag: '#ffd700',
                    feed: '#8fa8c0', cell: '#4db8ff',
                    freeze: '#7fd4ff', thaw: '#ffb020', medkit: '#1aff8c' };
    ctx.textAlign = 'left';
    R.items.forEach(it => {
      const why = refusal ? refusal(it.act) : null;
      const col = why ? '#3a4560' : COL[it.act];
      ctx.fillStyle = why ? 'rgba(13,17,32,0.6)' : 'rgba(20,30,50,0.9)';
      ctx.fillRect(it.x, it.y, it.w, it.h);
      ctx.strokeStyle = col; ctx.lineWidth = 1;
      ctx.strokeRect(it.x + 0.5, it.y + 0.5, it.w - 1, it.h - 1);
      ctx.fillStyle = col;
      ctx.font = '9px Share Tech Mono, monospace';
      ctx.fillText(LABEL[it.act], it.x + 4, it.y + 10);
    });
    return R;
  }

  /** Trim a string to fit a width — small local helper, no ellipsis
   *  library, and it never returns something wider than asked for. */
  function _clipTo(ctx, text, max) {
    let t = String(text);
    if (ctx.measureText(t).width <= max) return t;
    while (t.length > 1 && ctx.measureText(t + '…').width > max) t = t.slice(0, -1);
    return t + '…';
  }

  function _drawOrderPanel(ctx, top, inCombat) {
    _orderTop = top;
    const R = orderRects();
    /* update51: these ARE the commander's orders. Without a commander
       the clicks are refused, so they must not look live — and the
       question asked here is the very one game.js answers when the
       click arrives, not a second guess at it. */
    const has = (typeof Game !== 'undefined' && Game.hasCommander)
      ? Game.hasCommander() : true;
    const DEAD = '#3a4560';

    ctx.fillStyle = has ? '#4a6080' : '#ff7c20';
    ctx.font = '8px Share Tech Mono, monospace';
    ctx.textAlign = 'left';
    ctx.fillText(has ? 'ORDERS' : 'ORDERS — NO COMMANDER', ORDER_X, top + 8);

    const btn = (rect, label, colour, live) => {
      const col = live ? colour : DEAD;
      ctx.fillStyle = 'rgba(13,17,32,0.9)';
      ctx.beginPath(); ctx.roundRect(rect.x, rect.y, rect.w, rect.h, 3); ctx.fill();
      ctx.strokeStyle = col; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.roundRect(rect.x, rect.y, rect.w, rect.h, 3); ctx.stroke();
      ctx.fillStyle = col;
      ctx.font = '9px Share Tech Mono, monospace';
      ctx.textAlign = 'center';
      ctx.fillText(label, rect.x + rect.w / 2, rect.y + 12);
      ctx.textAlign = 'left';
    };

    btn(R.crewSave,   'SAVE POS',  '#4db8ff', has);
    btn(R.crewReturn, 'RETURN',    '#1aff8c', has);
    btn(R.doorsOpen,  'OPEN ALL',  '#1aff8c', has);
    btn(R.doorsClose, 'CLOSE ALL', '#ff5566', has);
    _powerClickZones.push({ ...R.crewSave,   crewSave: true });
    _powerClickZones.push({ ...R.crewReturn, crewReturn: true });
    _powerClickZones.push({ ...R.doorsOpen,  doorsOpen: true });
    _powerClickZones.push({ ...R.doorsClose, doorsClose: true });

    /* BOARD, RECALL and RETREAT are fight-only, and they are drawn
       DARK rather than hidden out of combat — a panel that changes
       shape between the map and a fight is a panel the player has to
       relearn every jump. game.js owns their clicks, against these
       very rectangles. */
    const boardN = (typeof UI !== 'undefined' && UI.getSelectedCrewAll)
      ? UI.getSelectedCrewAll().filter(c => c.alive).length : 0;
    btn(R.board,   boardN ? `BOARD ${Math.min(boardN, 3)}` : 'BOARD',
        '#ff2d44', has && inCombat);
    btn(R.recall,  'RECALL',  '#4db8ff', has && inCombat);
    btn(R.retreat, 'RETREAT [R]', '#ff7c20', has && inCombat);

    // ── the special orders ──
    const cmdr = (typeof Commander !== 'undefined' && Commander.active)
      ? Commander.active() : null;
    ctx.fillStyle = R.specials.length ? '#4dd8c0' : '#3a4560';
    ctx.font = '8px Share Tech Mono, monospace';
    ctx.textAlign = 'left';
    ctx.fillText(R.specials.length ? `SPECIAL (${R.specials.length})`
                                   : 'NO SPECIALISATIONS',
                 ORDER_X, R.specialsTop - 4);

    R.specials.forEach(sp => {
      const used = Commander.orderUsed(sp.key);
      const live = has && inCombat && !used;
      const running = sp.def.effect ? Commander.orderLeft(sp.def.effect) > 0 : 0;
      const col = used ? '#3a4560' : live ? '#4dd8c0' : '#2c5f57';
      ctx.fillStyle = running ? 'rgba(77,216,192,0.22)' : 'rgba(13,17,32,0.9)';
      ctx.beginPath(); ctx.roundRect(sp.x, sp.y, sp.w, sp.h, 3); ctx.fill();
      ctx.strokeStyle = running ? '#4dd8c0' : col; ctx.lineWidth = running ? 2 : 1;
      ctx.beginPath(); ctx.roundRect(sp.x, sp.y, sp.w, sp.h, 3); ctx.stroke();
      ctx.fillStyle = col;
      ctx.font = '13px Share Tech Mono, monospace';
      ctx.textAlign = 'center';
      ctx.fillText(sp.def.glyph, sp.x + sp.w / 2, sp.y + sp.h / 2 + 5);
      ctx.textAlign = 'left';

      /* A SPENT ORDER IS STRUCK THROUGH. Grey alone reads as "not yet"
         and this one is never coming back until the next fight. */
      if (used) {
        ctx.strokeStyle = '#5a6478'; ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(sp.x + 4, sp.y + sp.h - 4);
        ctx.lineTo(sp.x + sp.w - 4, sp.y + 4);
        ctx.stroke();
      }
      _powerClickZones.push({ ...sp, specialOrder: sp.key });
    });

    /* THE HOVERED ORDER EXPLAINS ITSELF. Eight glyphs in a row are
       eight riddles otherwise — the label and what it does have to be
       readable without pressing anything. */
    const hov = R.specials.find(sp =>
      Utils.pointInRect(Input.mouse.x, Input.mouse.y, sp.x, sp.y, sp.w, sp.h));
    if (hov) {
      const ty = R.specialsTop + 34;
      ctx.fillStyle = '#4dd8c0';
      ctx.font = '9px Share Tech Mono, monospace';
      ctx.fillText(hov.def.label, ORDER_X, ty);
      ctx.fillStyle = Commander.orderUsed(hov.key) ? '#ff7c20' : '#7a90a8';
      ctx.font = '8px Share Tech Mono, monospace';
      const words = String(hov.def.desc).split(' ');
      let line = '', ly = ty + 11;
      words.forEach(w => {
        const test = line + w + ' ';
        if (ctx.measureText(test).width > 150) {
          ctx.fillText(line, ORDER_X, ly); ly += 9; line = w + ' ';
        } else line = test;
      });
      if (line) ctx.fillText(line, ORDER_X, ly);
      if (Commander.orderUsed(hov.key)) {
        ctx.fillStyle = '#ff7c20';
        ctx.fillText('ALREADY GIVEN THIS FIGHT', ORDER_X, ly + 10);
      }
    }
  }

  function drawHUD(state) {
    _powerClickZones.length = 0;
    _crewMarkZones.length = 0;
    if (!state.playerShip) return;
    const ship = state.playerShip;
    const run  = Save.getRun();
    if (!run) return;
    const ctx  = _ctx;

    // ════ TOP-LEFT: Player hull bar (segmented, FTL style) ════
    _drawHeartBar(ctx, 14, 14, ship.hull, ship.hullMax, '#1aff8c', '#0a3018', 360);

    // ONE status row under the hull: EVADE → OXYGEN → shield bubbles
    // (the old dark "evasion badge" circle looked like a phantom empty
    //  bubble — gone; pills no longer touch the crew list either)
    const shieldY = 58;
    const o2avg = ship.oxygen.averageO2();
    const o2col = o2avg < 0.25 ? '#ff2d44' : o2avg < 0.6 ? '#ffd700' : '#4db8ff';
    _statPill(ctx, 14, shieldY, 'EVADE',  Math.round(ship.evasion * 100) + '%', '#1aff8c');
    _statPill(ctx, 92, shieldY, 'OXYGEN', Math.round(o2avg * 100) + '%', o2col);
    {
      const ss = ship.getSystem('shields');
      const prog = ss ? ss.shieldChargeProgress : 0;
      for (let i = 0; i < ship.shieldMax; i++) {
        const lit = i < ship.shieldBars;
        _shieldBubble(ctx, 184 + i * 30, shieldY + 12, 11, lit,
                      i === ship.shieldBars ? prog : 0);
      }
    }

    /* ════ THE COMMANDER (update43) ════
       One strip above the crew list — who is in the chair, what level
       he is, and how close the next promotion is. He is not a body on
       the deck, so he gets no portrait among the crew and no click
       target in the fight: the mess is where you deal with him. */
    if (typeof Commander !== 'undefined' && Commander.active && Commander.active()) {
      const cap = Commander.active();
      const R = commanderStripRect();
      const cy0 = R.y, cw = R.w, chh = R.h;
      ctx.fillStyle = 'rgba(13,17,32,0.85)';
      ctx.beginPath(); ctx.roundRect(14, cy0, cw, chh, 3); ctx.fill();
      ctx.strokeStyle = '#ffd700'; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.roundRect(14, cy0, cw, chh, 3); ctx.stroke();

      ctx.fillStyle = crewColor(cap);
      ctx.fillRect(17, cy0 + 3, 14, 14);
      ctx.fillStyle = '#ffd700';
      ctx.font = '9px Share Tech Mono, monospace';
      ctx.textAlign = 'left';
      ctx.fillText(`${String(cap.name).slice(0, 7)} L${cap.level}`, 35, cy0 + 9);

      // Progress to the next promotion — full when he has topped out.
      const prog = Commander.xpProgress ? Commander.xpProgress(cap) : 0;
      ctx.fillStyle = '#0a1018';
      ctx.fillRect(35, cy0 + 12, cw - 28, 4);
      ctx.fillStyle = '#1a8cff';
      ctx.fillRect(35, cy0 + 12, (cw - 28) * Utils.clamp(prog, 0, 1), 4);
    }

    /* ── AND THEIRS (update50) ──
       The player is told a corporation and a level, and nothing else:
       no board, no chip list. That is the whole of what the spec
       allows him to see, and it is enough to read a fight — a level 7
       Phoenix commander means their boarders hit harder, and you find
       that out from the badge rather than from a surprise. */
    /* THE BADGE HANGS ON THE HULL, NOT ON A FLAG (update54).
       `Commander.setEnemy(null)` had to be remembered at FIVE exits
       from a fight — win, lose, jump away, evacuate, boss defeated —
       and the boss path forgot, so a beaten commander's badge sat on
       the HUD over empty space until the next battle overwrote it.
       The badge is not a fact of its own: it is "there is an enemy ship
       in front of me and somebody is commanding it". Asking the hull
       cannot go stale, because when the hull is gone so is the badge —
       and no future exit has to remember anything. */
    const foeShip = state.enemyShip;
    const foeAlive = !!foeShip && !foeShip.destroyed && foeShip.hull > 0;
    if (foeAlive && typeof Commander !== 'undefined' && Commander.enemy && Commander.enemy()) {
      const foe = Commander.enemy();
      const w2 = 118, x2 = _W - w2 - 14, y2 = 84;
      ctx.fillStyle = 'rgba(28,10,14,0.85)';
      ctx.beginPath(); ctx.roundRect(x2, y2, w2, 20, 3); ctx.fill();
      ctx.strokeStyle = '#ff5566'; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.roundRect(x2, y2, w2, 20, 3); ctx.stroke();
      ctx.fillStyle = crewColor(foe);
      ctx.fillRect(x2 + 3, y2 + 3, 14, 14);
      ctx.fillStyle = '#ff8a95';
      ctx.font = '9px Share Tech Mono, monospace';
      ctx.textAlign = 'left';
      const corp = (typeof CORP_DEFS !== 'undefined' && CORP_DEFS[foe.race]?.label)
        || foe.race || '?';
      ctx.fillText(`${String(corp).slice(0, 8)} L${foe.level}`, x2 + 21, y2 + 13);
    }

    // ════ LEFT: Crew portraits with HP bars & CONDITION tags ════
    let crewY = 108;
    const roster = crewRoster(state);
    roster.forEach((c, i) => {
      const cx = 14, cw = 100, ch = 26;   // update54: was 120
      const away = c._awayTeam;
      // Condition tag (drawn after the row background below)
      /* ── SICK IS NOT A CONDITION THAT HIDES HIS HP (update68) ──
       *
       * The corpse plague used to replace the whole HP row with the
       * word SICK, so the one thing a player needs to decide anything —
       * how close to dead the man is — vanished the moment he caught
       * something. His words: "jak jest sick to zniknęło hp info z
       * listy załogantów".
       *
       * A tag REPLACES the bar only when hit points are meaningless:
       * he is dead, he is rotting, or he is on the floor. Being ill is
       * a mark beside the bar, not instead of it. */
      const tag = c.decaying          ? { t: 'DECAYING', col: DISEASE_COL.plague }
                : c.dead              ? { t: 'DEAD',     col: '#98a0b8' }
                : c.state === 'injured' ? { t: 'INJURED',  col: '#ffd700' }
                : null;
      c._rosterTag = tag;
      const sel = UI.getSelectedCrew && UI.getSelectedCrew() === c;

      ctx.fillStyle = sel ? 'rgba(26,140,255,0.25)' : 'rgba(13,17,32,0.85)';
      ctx.beginPath(); ctx.roundRect(cx, crewY, cw, ch, 3); ctx.fill();
      ctx.strokeStyle = sel ? '#4db8ff' : away ? '#ff7c20' : '#1e2d4a';
      ctx.lineWidth = sel || away ? 1.5 : 1;
      ctx.stroke();

      // Mini portrait square — corporation color
      ctx.fillStyle = crewColor(c);
      ctx.fillRect(cx + 3, crewY + 3, 20, 20);
      ctx.fillStyle = '#c8d8f0';
      ctx.fillRect(cx + 6, crewY + 5, 14, 8); // helmet

      // Name (greyed out for the dead)
      ctx.fillStyle = c.dead ? '#7a8298' : '#c8d8f0';
      ctx.font = '10px Share Tech Mono, monospace';
      ctx.textAlign = 'left';
      ctx.fillText(c.name.slice(0, 7), cx + 28, crewY + 12);
      /* The away-team chevron used to be painted over the portrait
         here. It is a MARK — it says something is true of the man —
         so it lives with the other marks now, in the strip beside the
         row, and there is one place to look instead of three. */

      // Condition tag OR the HP bar
      if (c._rosterTag) {
        ctx.fillStyle = c._rosterTag.col;
        ctx.font = 'bold 9px Share Tech Mono, monospace';
        ctx.fillText(c._rosterTag.t, cx + 28, crewY + 23);
      } else {
        drawPips(ctx, cx + 28, crewY + 16, cw - 34, 6, c.hp, c.maxHp,
                 c.hp / c.maxHp > 0.5 ? '#1aff8c'
                   : c.hp / c.maxHp > 0.25 ? '#ffd700' : '#ff2d44');
      }

      // The star stays IN the row: it is what he is worth, not what
      // is happening to him, and it never needs to sit beside four
      // other things.
      const star = c.getStarRating();
      if (star !== 'none') {
        ctx.fillStyle = star === 'gold' ? '#ffd700' : '#aaaaaa';
        ctx.font = '10px monospace';
        ctx.textAlign = 'right';
        ctx.fillText('★', cx + cw - 3, crewY + 12);
      }

      /* ── THE MARK STRIP, BESIDE THE ROW (update76) ───────────
       *
       * Everything that is TRUE OF THE MAN rather than part of his
       * identity: both diseases at once, hunger, whether he is off the
       * ship, and which module he is actually working. The list comes
       * from `crewMarks` so the picture and the test read the same
       * sentence.
       *
       * The pulse still means WARNING and nothing else — it is on the
       * two things that get worse if ignored (a disease, and a man who
       * has stopped eating), and off everything that is merely true. */
      const marks = crewMarks(c, ship);
      marks.forEach((m, mi) => {
        const mx = cx + cw + 4 + (mi % MARK_ROWS) * MARK_STEP;
        const my = crewY + (mi < MARK_ROWS ? 0 : 12);
        const pulse = m.pulse
          ? 0.55 + 0.45 * (0.5 + 0.5 * Math.sin((c._rosterPulse = (c._rosterPulse ?? 0) + 0.02)))
          : 1;
        ctx.globalAlpha = pulse;
        ctx.fillStyle = m.col;
        ctx.font = 'bold 10px monospace';
        ctx.textAlign = 'left';
        ctx.fillText(m.glyph, mx, my + 11);
        ctx.globalAlpha = 1;
        _crewMarkZones.push({ x: mx - 2, y: my + 1, w: MARK_STEP, h: 12, tip: m.tip });
      });

      // Click zone — select crew member. `crewRef` is the crew member
      // himself: the row used to carry only an index into
      // _playerShip.crew, which stopped being the roster the moment
      // boarders started appearing in it from the enemy hull.
      _powerClickZones.push({ x: cx, y: crewY, w: cw, h: ch, crewIndex: i, crewRef: c });

      crewY += ch + 4;
    });

    /* ════ THE ORDER PANEL (rebuilt in update53) ═══════════
     *
     * EVERY order the commander can give, in ONE place, under the
     * crew he is giving them to. Until update53 the doors and the
     * saved stations were here while BOARD, RECALL and RETREAT sat
     * across the top of the screen — three buttons that were orders
     * in every sense except where they were drawn. The player had to
     * know two places to look, and the two drifted: the BOARD
     * rectangle was written out by hand at the draw site AND at the
     * click site, which is a bug waiting for the first time somebody
     * moves one of them.
     *
     * `orderRects()` is now the single source of that geometry and
     * both the picture and the hit test read it.
     */
    if (roster.length) {
      _drawOrderPanel(ctx, crewY + 2, !!state.enemyShip);
    }

    /* WHAT THAT LITTLE SYMBOL MEANS. Drawn after the whole left column,
       so the tip is never painted under the next row. A mark that needs
       a legend elsewhere on the screen is a mark the player will ignore
       — this one explains itself where his hand already is. */
    const hov = _crewMarkZones.find(z => z.tip &&
      Utils.pointInRect(Input.mouse.x, Input.mouse.y, z.x, z.y, z.w, z.h));
    if (hov) {
      ctx.font = '10px Share Tech Mono, monospace';
      const tw = ctx.measureText(hov.tip).width + 12;
      const tx = Math.min(hov.x + 14, _W - tw - 4);
      const ty = hov.y - 2;
      ctx.fillStyle = 'rgba(8,12,22,0.96)';
      ctx.beginPath(); ctx.roundRect(tx, ty, tw, 16, 3); ctx.fill();
      ctx.strokeStyle = '#4db8ff'; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.roundRect(tx, ty, tw, 16, 3); ctx.stroke();
      ctx.fillStyle = '#c8d8f0';
      ctx.textAlign = 'left';
      ctx.fillText(hov.tip, tx + 6, ty + 11);
    }

    // The reactor used to have its own tall column over here, wired to
    // every module with an orange rail. It is a module like any other
    // now and lives in the bottom row with the rest — see _drawPowerBar.

    // ════ BOTTOM BAR: power management (FTL style) ════
    _drawPowerBar(ctx, ship, run);

    // ════ TOP-RIGHT: Enemy hull (if combat) ════
    // The whole enemy readout disappears the moment the ship is destroyed.
    if (state.enemyShip && state.enemyShip.hull > 0 && !state.enemyShip.destroyed) {
      const e = state.enemyShip;
      /* RIGHT-ANCHORED (update40). A fixed left edge at _W − 320 sent a
         big enemy hull bar straight off the canvas; measure it and hang
         it off the right margin instead, so it always ends on screen
         whatever the hull. The status row below follows the bar. */
      const eBarW = _heartBarWidth(e.hullMax, 300);
      const eX    = Math.min(_W - 14 - eBarW, _W - 320);
      _drawHeartBar(ctx, eX, 14, e.hull, e.hullMax, '#ff7c20', '#301505', 300);

      // Enemy status: ONE row — EVADE → OXYGEN → bubbles (same style)
      const eo2  = e.oxygen.averageO2();
      const eCol = eo2 < 0.25 ? '#ff2d44' : eo2 < 0.6 ? '#ffd700' : '#4db8ff';
      _statPill(ctx, eX, 52, 'EVADE',  Math.round(e.evasion * 100) + '%', '#ff7c20');
      _statPill(ctx, eX + 78, 52, 'OXYGEN', Math.round(eo2 * 100) + '%', eCol);
      {
        const es = e.getSystem('shields');
        const eprog = es ? es.shieldChargeProgress : 0;
        /* THE LAST BUBBLE WAS BEING SHAVED OFF (update42). The row hung
           off a hardcoded `_W - 150` while everything around it is
           right-anchored off eX, so the pips grew RIGHTWARD into the
           canvas edge: the 6th one started at x=1270 on a 1280 canvas
           and the charge ring on the partly-charged pip clipped even
           earlier. Anchor the row's RIGHT edge instead and it grows
           leftward, staying on screen at any shield count. */
        const R = 10, PITCH = 28;
        const edge = R + 5;                   // stroke + 2.5px charge ring at r+3
        const lastCx = _W - 14 - edge;
        for (let i = 0; i < e.shieldMax; i++) {
          const lit = i < e.shieldBars;
          const cx  = lastCx - (e.shieldMax - 1 - i) * PITCH;
          _shieldBubble(ctx, cx, 64, R, lit,
                        i === e.shieldBars ? eprog : 0);
        }
      }

      // ── Enemy module panel: BELOW the enemy ship, centered ──
      _drawEnemyModules(ctx, e);
    }

    // ════ Resources row (scrap/fuel/missiles/sector) top-center ════
    const resX = 470;
    ctx.fillStyle = 'rgba(13,17,32,0.85)';
    // Widened in update58 to make room for the ore readout.
    ctx.beginPath(); ctx.roundRect(resX, 10, 390, 26, 4); ctx.fill();
    ctx.strokeStyle = '#1e2d4a'; ctx.lineWidth = 1; ctx.stroke();
    ctx.font = '12px Share Tech Mono, monospace';
    ctx.textAlign = 'left';
    // CC green (money), He2 red (the thing that strands you)
    ctx.fillStyle = '#1aff8c';
    ctx.fillText(`${run.scrap} CC`, resX + 12, 28);
    ctx.fillStyle = run.fuel <= 2 ? '#ff2d44' : '#ff5566';
    ctx.fillText(`He2 ${run.fuel}`, resX + 82, 28);
    // A WARHEAD, not just the letters MSL. The pictogram already
    // existed (STAT_ICONS.ammo) and had exactly one caller in the whole
    // game — the base armoury — so the readout the player watches in a
    // fight was the one place it never appeared.
    const mslCol = run.missiles <= 0 ? '#7a5030' : '#ff7c20';
    drawStatIcon(ctx, 'ammo', resX + 166, 18, 11, mslCol);
    ctx.fillStyle = mslCol;
    ctx.fillText(`${run.missiles}`, resX + 182, 28);
    /* He-3 ORE (update58). The player asked why the mineral he is
       carrying is invisible, and he was right: it lived in the hold and
       nowhere else on screen. Read STRAIGHT OFF THE HOLD — the cells
       ARE the amount, exactly like the He2 cells and the missile racks,
       so there is no second number to keep in step.
       Drawn dim at zero rather than hidden: a readout that appears and
       disappears is a readout the player never learns to look at. */
    {
      const ore = ship.cargo?.countOfTag ? ship.cargo.countOfTag('he3') : 0;
      const oreCol = ore > 0 ? '#cfe4ff' : '#3d4a63';
      drawStatIcon(ctx, 'ore', resX + 232, 18, 11, oreCol);
      ctx.fillStyle = oreCol;
      ctx.fillText(`He3 ${ore}`, resX + 248, 28);
    }
    ctx.fillStyle = '#4db8ff';
    ctx.fillText(`SEC ${run.sector}`, resX + 322, 28);

    /* THE CELLS, ONLY WHEN THERE ARE ANY (update63).
     *
     * Unlike the ore readout above, this one DOES appear and vanish —
     * and for the opposite reason: a permanent 0/0 on a hull with no
     * brig would be noise on every run for a feature most runs never
     * touch. What must never be silent is a man about to walk, so the
     * moment the brig loses power the readout goes red and counts the
     * clock down in seconds the player can act on.
     */
    const cells = ship.carboniteCapacity ? ship.carboniteCapacity() : 0;
    /* BOTH KINDS OF OCCUPANT (update77). A slab is a slab whether the
       man in it is a convict you are hauling in or your own gunner
       with a bite. Counting only prisoners would have shown 0/3 on a
       bay with three of your own crew in it. */
    const held  = (ship.prisoners ? ship.prisoners.length : 0)
                + (ship.frozenCrew ? ship.frozenCrew().length : 0);
    if (cells > 0 || held > 0) {
      const brig    = ship.getSystem('carbonite');
      // Only a PRISONER works a lock. A frozen man whose slab goes
      // cold simply wakes up, which is `carboniteTick`, not an escape.
      const locks    = ship.prisoners ? ship.prisoners.length : 0;
      const slipping = locks > 0 && (!brig || brig.isDisabled());
      const worst   = slipping
        ? Math.max(...ship.prisoners.map(p => p.escapeT ?? 0)) : 0;
      const left    = Math.max(0, Math.ceil(Ship.ESCAPE_SECONDS - worst));
      const col     = slipping ? '#ff2d44' : held > 0 ? '#ffd700' : '#3d4a63';
      ctx.fillStyle = 'rgba(13,17,32,0.85)';
      ctx.beginPath(); ctx.roundRect(resX + 396, 10, 118, 26, 4); ctx.fill();
      ctx.strokeStyle = slipping ? '#ff2d44' : '#1e2d4a';
      ctx.lineWidth = 1; ctx.stroke();
      ctx.fillStyle = col;
      ctx.font = '12px Share Tech Mono, monospace';
      ctx.fillText(slipping ? `CARB ${left}s!` : `CARB ${held}/${cells}`, resX + 406, 28);
    }

    _drawRunGoals(ctx, resX);
  }

  /* ── WHAT ELSE THIS RUN IS BEING ASKED FOR (update71) ────────
   *
   * ONE LINE, under the resources row, and it is the whole of the
   * side-objective UI — the design says so in as many words: "jedna
   * linia na HUD… nie robimy z tego drugiego ekranu". A goal is a
   * counter with a price on it; a screen would make it look like a
   * system.
   *
   * It draws nothing at all when the contract carries no goals, so a
   * player who never looks at it never has it in the way.
   */
  /* WHERE THAT LINE LIVES, as a rectangle anybody can ask for
     (update74). The map/cargo buttons sit in the same strip of screen
     and were drawn straight through it — the player's report was
     "OBJ nachodzi na SHOW MAP i CARGO". Giving the line a published
     box means the buttons can be placed BELOW it and a test can say
     so, instead of two sets of coordinates being nudged past each
     other by eye until they happen to miss. */
  const RUN_GOALS_BOX = { y: 40, h: 17, w: 390 };
  /** WHERE the line lives, always — whether or not this contract has
   *  anything to put on it. Anything laid out AROUND the line wants
   *  this one, so that the layout does not move when a contract
   *  happens to carry no objectives. */
  function runGoalsBox() { return { ...RUN_GOALS_BOX }; }
  /** The line as drawn RIGHT NOW, or null when there is nothing on it. */
  function runGoalsRect(resX = 470) {
    const goals = (typeof Save !== 'undefined' && Save.runGoals) ? Save.runGoals() : [];
    if (!goals.length) return null;
    return { x: resX, y: RUN_GOALS_BOX.y, w: RUN_GOALS_BOX.w, h: RUN_GOALS_BOX.h };
  }

  function _drawRunGoals(ctx, resX) {
    const goals = (typeof Save !== 'undefined' && Save.runGoals) ? Save.runGoals() : [];
    if (!goals.length) return;
    const y = RUN_GOALS_BOX.y, h = RUN_GOALS_BOX.h;
    ctx.fillStyle = 'rgba(13,17,32,0.85)';
    ctx.beginPath(); ctx.roundRect(resX, y, RUN_GOALS_BOX.w, h, 3); ctx.fill();
    ctx.strokeStyle = '#1e2d4a'; ctx.lineWidth = 1; ctx.stroke();
    ctx.font = '9px Share Tech Mono, monospace';
    ctx.textAlign = 'left';
    ctx.fillStyle = '#4a6080';
    ctx.fillText('OBJ', resX + 8, y + 12);
    let x = resX + 30;
    goals.forEach((g, i) => {
      /* A FINISHED JOB STAYS ON THE LINE, greyed and ticked. Taking it
         away the moment it pays would leave the player wondering
         whether he imagined it — and the line is the only place the
         run's own bookkeeping is ever shown. */
      const col = g.done ? '#3d4a63' : (g.n > 0 ? '#ffd700' : '#7a90a8');
      const txt = g.done ? `✓ ${g.label}` : `${g.label} ${g.n}/${g.need}`;
      if (i > 0) {
        ctx.fillStyle = '#2a3346';
        ctx.fillText('·', x - 7, y + 12);
      }
      ctx.fillStyle = col;
      ctx.fillText(txt, x, y + 12);
      x += ctx.measureText(txt).width + 14;
    });
  }

  /** One shield bubble — shared style for player AND enemy.
   *  `chargeProg` (0-1) draws a progress arc while this layer charges. */
  function _shieldBubble(ctx, x, y, r, lit, chargeProg = 0) {
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    if (lit) {
      const g = ctx.createRadialGradient(x - r*0.3, y - r*0.3, 1, x, y, r);
      g.addColorStop(0, '#d8f2ff');
      g.addColorStop(0.45, '#4db8ff');
      g.addColorStop(1, '#134a80');
      ctx.fillStyle = g;
    } else {
      ctx.fillStyle = 'rgba(16,30,52,0.75)';
    }
    ctx.fill();
    ctx.strokeStyle = lit ? '#9fdcff' : '#28486e';
    ctx.lineWidth = 1.5;
    ctx.stroke();
    if (lit) {   // inner glint
      ctx.beginPath();
      ctx.arc(x - r*0.35, y - r*0.35, r*0.22, 0, Math.PI*2);
      ctx.fillStyle = 'rgba(255,255,255,0.55)';
      ctx.fill();
    }
    // Recharge progress ring (like the crew repair ring)
    if (!lit && chargeProg > 0) {
      ctx.beginPath();
      ctx.arc(x, y, r + 3, -Math.PI/2, -Math.PI/2 + chargeProg * Math.PI * 2);
      ctx.strokeStyle = '#8fd4ff';
      ctx.lineWidth = 2.5;
      ctx.stroke();
    }
  }

  /** Readable stat pill: dark rounded badge, label + colored value */
  function _statPill(ctx, x, y, label, value, color) {
    const w = 74, h = 24;
    ctx.fillStyle = 'rgba(13,17,32,0.92)';
    ctx.beginPath(); ctx.roundRect(x, y, w, h, 5); ctx.fill();
    ctx.strokeStyle = color; ctx.lineWidth = 1; ctx.stroke();
    ctx.font = '8px Share Tech Mono, monospace';
    ctx.textAlign = 'left';
    ctx.fillStyle = '#7a90a8';
    ctx.fillText(label, x + 7, y + 9);
    ctx.font = 'bold 12px Share Tech Mono, monospace';
    ctx.fillStyle = color;
    ctx.fillText(value, x + 7, y + 20);
    return w;
  }

  /** FTL-style segmented health bar with heart icon */
  /**
   * How wide a heart bar actually comes out, for a given pip count.
   *
   * `Math.max(7, …)` is a FLOOR on the segment width, so the bar does
   * NOT in fact "never exceed 360px" the way the old comment claimed:
   * a 28-pip gunship hull came out 376px wide, and the enemy copy is
   * anchored at _W − 320, so the last five pips were drawn off the
   * right-hand edge of the canvas. Callers ask for the width now and
   * place the bar accordingly.
   */
  function _heartBarWidth(max, budget = 360) {
    const gap  = 2;
    const segW = Math.max(5, Math.min(15, Math.floor(budget / Math.max(1, max)) - gap));
    return 40 + max * (segW + gap);
  }

  function _drawHeartBar(ctx, x, y, val, max, color, dimColor, budget = 360) {
    // Heart circle
    ctx.fillStyle = '#0d1120';
    ctx.beginPath(); ctx.arc(x + 16, y + 16, 17, 0, Math.PI*2); ctx.fill();
    ctx.strokeStyle = color; ctx.lineWidth = 2; ctx.stroke();
    ctx.fillStyle = color;
    ctx.font = '16px monospace';
    ctx.textAlign = 'center';
    ctx.fillText('♥', x + 16, y + 22);

    // Segments — sized to the budget the caller gave us.
    const gap  = 2;
    const segW = Math.max(5, Math.min(15, Math.floor(budget / Math.max(1, max)) - gap));
    const segH = 18;
    const startX = x + 40;
    for (let i = 0; i < max; i++) {
      const sx  = startX + i * (segW + gap);
      const lit = i < val;
      ctx.fillStyle = lit ? color : dimColor;
      ctx.beginPath();
      ctx.roundRect(sx, y + 7, segW, segH, 2);
      ctx.fill();
      if (lit && segW > 9) {
        ctx.fillStyle = 'rgba(255,255,255,0.25)';
        ctx.fillRect(sx + 2, y + 9, segW - 4, 3);
      }
    }
  }

  /**
   * FTL-style bottom power bar.
   * Icons in circles, clickable power pips above each icon,
   * weapons with charge segments, all connected by power line.
   * Click zones stored in _powerClickZones for game.js to consume.
   */

  /**
   * Compact FTL-style enemy systems readout, drawn BELOW the enemy ship.
   * Per column (one per system): status icons on top, power pips
   * (growing upward from a common baseline), system icon underneath.
   */
  function _drawEnemyModules(ctx, ship) {
    const _es = ship.systems.filter(s => s.maxPower > 0);
    // Reactor FIRST (leftmost): its tall stack no longer climbs over
    // the hull of tall ships like the Apophis station.
    const systems = [..._es.filter(s => s.type === 'reactor'),
                     ..._es.filter(s => s.type !== 'reactor')];
    if (!systems.length) return;
    const glyphs = {
      shields: '◙', weapons: '▲', engines: '≋',
      oxygen: 'O₂', medbay: '+', piloting: '◎', artillery: '✦',
      reactor: '⚡',
    };

    const colW = 34;
    const pw = 12, ph = 5, pg = 2;
    const step = ph + pg;                       // 7px per pip
    const maxPips = Math.max(...systems.map(s => s.maxPower));

    // Anchor: centered under the ship hull, below the plate (+14) and
    // weapon mounts; clamped to stay above the bottom power bar.
    const b  = ship.roomBounds();
    const x  = Utils.clamp(b.x + b.w / 2 - (systems.length * colW) / 2,
                           10, _W - systems.length * colW - 10);
    let  y   = b.y + b.h + 34;                  // top of the tallest pip stack
    const panelH = maxPips * step + 30;         // pips + icon circle
    y = Math.min(y, _H - 110 - panelH);         // keep clear of the bottom bar

    const baseline = y + maxPips * step;        // bottom edge of every stack

    let ix = x + colW / 2;
    systems.forEach(sys => {
      // Mini power pips — p=0 sits on the baseline, stack grows upward
      for (let p = 0; p < sys.maxPower; p++) {
        const py      = baseline - (p + 1) * step;
        const damaged = p >= sys.maxPower - sys.damagedLevels;
        const lit     = !damaged && p < sys.power;
        ctx.fillStyle = damaged ? '#cc2233'
                      : lit     ? '#ff9040'
                      : 'rgba(50,40,40,0.85)';
        ctx.fillRect(ix - pw/2, py, pw, ph);
        ctx.strokeStyle = damaged ? '#ff5566' : '#07080f';
        ctx.lineWidth = 0.5;
        ctx.strokeRect(ix - pw/2, py, pw, ph);
      }

      // Status icons (crew / fire / no-O2) just ABOVE this stack's top pip
      const topPipTop = baseline - sys.maxPower * step;
      const status = _roomStatus(ship, sys);
      status.forEach((st, si) => {
        _statusIcon(ctx, ix, topPipTop - 9 - si * 14, st);
      });

      // Icon below the baseline
      const disabled = sys.isDisabled();
      const iy = baseline + 15;
      ctx.fillStyle = '#0d1120';
      ctx.beginPath(); ctx.arc(ix, iy, 11, 0, Math.PI*2); ctx.fill();
      ctx.strokeStyle = disabled ? '#663333' : '#aa5522';
      ctx.lineWidth = 1.5; ctx.stroke();
      ctx.fillStyle = disabled ? '#884444' : '#ffb080';
      ctx.font = '10px monospace';
      ctx.textAlign = 'center';
      ctx.fillText(glyphs[sys.type] ?? '?', ix, iy + 3);

      ix += colW;
    });
  }

  /** Violet nebula clouds drifting behind the battle */
  function drawNebula(ctx, t) {
    ctx.save();
    for (let i = 0; i < 7; i++) {
      const cx = ((i * 231 + t * 18 * (1 + i * 0.13)) % (_W + 400)) - 200;
      const cy = 90 + ((i * 173) % (_H - 220));
      const r  = 140 + (i % 3) * 70;
      const g  = ctx.createRadialGradient(cx, cy, 0, cx, cy, r);
      g.addColorStop(0, 'rgba(150,60,210,0.10)');
      g.addColorStop(1, 'rgba(150,60,210,0)');
      ctx.fillStyle = g;
      ctx.fillRect(cx - r, cy - r, r * 2, r * 2);
    }
    ctx.restore();
  }

  function _drawPowerBar(ctx, ship, run) {

    const barY   = _H - 96;
    const iconR  = 20;
    let   ix     = 44;
    // Reactor is excluded — it's the SOURCE (shown as the left column),
    // not a power consumer you can allocate bars to.
    // Weapon modules are grouped at the END of the row, adjacent to
    // each other and to the gun cards on the right.
    const _all    = ship.systems.filter(s => s.maxPower > 0 && s.type !== 'reactor');
    const systems = [..._all.filter(s => s.type !== 'weapons'),
                     ..._all.filter(s => s.type === 'weapons')];

    // No plumbing. The orange rail that snaked from the reactor to every
    // module added nothing but clutter — the pips already say who is
    // drawing power.
    const iconGlyphs = SYSTEM_GLYPHS;

    // ── The reactor sits IN the row, on the same baseline as every
    //    other module: same circle, same pips, same click-to-toggle.
    {
      const r  = ship.reactor;
      const cy = _H - 52;
      const off = !!r.offline;
      const rated = r.ratedPower ?? r.totalPower;
      const free  = r.totalPower - (r.totalPower - ship.availablePower());

      ctx.fillStyle = '#0d1120';
      ctx.beginPath(); ctx.arc(ix, cy, iconR, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = off ? '#663333' : '#ffb020';
      ctx.lineWidth = 2; ctx.stroke();
      ctx.fillStyle = off ? '#884444' : '#ffd780';
      ctx.font = '15px monospace';
      ctx.textAlign = 'center';
      ctx.fillText(iconGlyphs.reactor ?? '⚛', ix, cy + 5);

      // Pips = capacity. Lit = still unspent, dark = handed out,
      // red = knocked out. Same visual grammar as the modules.
      const pipW = 22, pipH = 9, pipGap = 3;
      const cap  = r.capacity ?? rated;
      for (let p = 0; p < cap; p++) {
        const py      = cy - iconR - 12 - p * (pipH + pipGap);
        const damaged = p >= rated;
        const lit     = !off && !damaged && p < free;
        ctx.fillStyle = damaged ? '#cc2233' : lit ? '#ffb020' : 'rgba(40,44,60,0.9)';
        ctx.fillRect(ix - pipW / 2, py, pipW, pipH);
        ctx.strokeStyle = damaged ? '#ff5566' : '#07080f';
        ctx.lineWidth = 1;
        ctx.strokeRect(ix - pipW / 2, py, pipW, pipH);
      }

      ctx.fillStyle = off ? '#ff5566' : '#7a90a8';
      ctx.font = '9px Share Tech Mono, monospace';
      ctx.fillText(off ? 'SCRAMMED' : 'REACTOR', ix, cy + iconR + 12);
      ctx.fillStyle = off ? '#884444' : '#ffb020';
      ctx.fillText(`${free}/${rated}`, ix, cy + iconR + 23);
      if ((r.penalty ?? 0) > 0) {
        ctx.fillStyle = '#cc44ff';
        ctx.fillText(`NEBULA −${r.penalty}`, ix, cy + iconR + 34);
      }

      _powerClickZones.push({
        x: ix - iconR, y: cy - iconR, w: iconR * 2, h: iconR * 2,
        reactorToggle: true,
      });
      ix += 62;
    }

    systems.forEach(sys => {
      const cy = _H - 52;

      // Icon circle
      const disabled = sys.isDisabled();
      ctx.fillStyle = '#0d1120';
      ctx.beginPath(); ctx.arc(ix, cy, iconR, 0, Math.PI*2); ctx.fill();
      ctx.strokeStyle = disabled ? '#663333' : (sys.power > 0 ? '#ffb020' : '#4a6080');
      ctx.lineWidth = 2;
      ctx.stroke();

      ctx.fillStyle = disabled ? '#884444' : (sys.power > 0 ? '#ffd780' : '#7a90a8');
      ctx.font = '15px monospace';
      ctx.textAlign = 'center';
      ctx.fillText(iconGlyphs[sys.type] ?? '?', ix, cy + 5);

      // ── CLOAK: the module icon IS the activate button (FTL style) ──
      // Ring around the icon = active countdown, then recharge. The
      // seconds sit right under it, so the whole ability lives with the
      // module it belongs to instead of a stray button at the top.
      if (sys.type === 'cloaking') {
        const dur = sys.def.cloakDuration ?? 6;
        const cd  = sys.def.cloakCooldown ?? 22;
        let ringCol = null, ringProg = 0, subLabel = '';
        if (sys.cloakActive) {
          ringCol = '#cc44ff'; ringProg = Utils.clamp(sys.cloakTimer / dur, 0, 1);
          subLabel = `${Math.ceil(sys.cloakTimer)}s`;
        } else if (sys.cloakCd > 0) {
          ringCol = '#4a6080'; ringProg = Utils.clamp(1 - sys.cloakCd / cd, 0, 1);
          subLabel = `${Math.ceil(sys.cloakCd)}s`;
        } else if (!disabled) {
          ringCol = '#cc44ff'; ringProg = 1; subLabel = 'READY [C]';
        } else {
          subLabel = 'NO PWR';
        }
        if (ringCol && ringProg > 0) {
          ctx.strokeStyle = ringCol;
          ctx.lineWidth = 3;
          ctx.beginPath();
          ctx.arc(ix, cy, iconR + 4, -Math.PI / 2, -Math.PI / 2 + ringProg * Math.PI * 2);
          ctx.stroke();
        }
        if (sys.cloakActive) {
          ctx.fillStyle = 'rgba(204,68,255,0.18)';
          ctx.beginPath(); ctx.arc(ix, cy, iconR, 0, Math.PI * 2); ctx.fill();
        }
        ctx.fillStyle = sys.cloakActive ? '#cc44ff' : (sys.cloakCd > 0 ? '#4a6080' : (disabled ? '#884444' : '#cc44ff'));
        ctx.font = '8px Share Tech Mono, monospace';
        ctx.fillText(subLabel, ix, cy + iconR + 22);
      }

      // Power pips ABOVE icon (click to add/remove)
      // Damaged levels render as RED squares at the top of the stack.
      const pipW = 22, pipH = 9, pipGap = 3;
      for (let p = 0; p < sys.maxPower; p++) {
        const py       = cy - iconR - 12 - p * (pipH + pipGap);
        const damaged  = p >= sys.maxPower - sys.damagedLevels;   // top slots break first
        const lit      = !damaged && p < sys.power;
        const ion      = sys.ionDamage > 0 && lit;

        ctx.fillStyle = damaged ? '#cc2233'
                      : ion     ? '#4db8ff'
                      : lit     ? '#ffb020'
                      : 'rgba(40,44,60,0.9)';
        ctx.fillRect(ix - pipW/2, py, pipW, pipH);
        ctx.strokeStyle = damaged ? '#ff5566' : '#07080f';
        ctx.lineWidth = 1;
        ctx.strokeRect(ix - pipW/2, py, pipW, pipH);

        if (!damaged) {
          _powerClickZones.push({
            x: ix - pipW/2 - 2, y: py - 2, w: pipW + 4, h: pipH + 4,
            sysIndex: ship.systems.indexOf(sys), pip: p,
          });
        }
      }

      // System label below icon (weapon modules are numbered)
      let label = sys.label;
      if (sys.type === 'weapons') {
        const wsysArr = systems.filter(s => s.type === 'weapons');
        if (wsysArr.length > 1) label = `WPN ${wsysArr.indexOf(sys) + 1}`;
      }
      ctx.fillStyle = '#7a90a8';
      ctx.font = '9px Share Tech Mono, monospace';
      ctx.fillText(label, ix, cy + iconR + 12);

      // Terra cyborg bonus: an extra CYAN pip above the stack proves
      // the +1 effective power is live on this module
      if (sys.effectivePower() > Math.min(sys.power, sys.workingLevels)) {
        const bonusY = cy - iconR - 12 - sys.power * (pipH + pipGap);
        ctx.fillStyle = '#4dffd8';
        ctx.fillRect(ix - pipW/2, bonusY, pipW, pipH);
        ctx.strokeStyle = '#0affc8'; ctx.lineWidth = 1;
        ctx.strokeRect(ix - pipW/2, bonusY, pipW, pipH);
      }

      // Status icons just ABOVE the topmost pip (crew manning / fire / no O2)
      {
        const topPipTop = cy - iconR - 12 - (sys.maxPower - 1) * (pipH + pipGap);
        const status = _roomStatus(ship, sys);
        status.forEach((st, si) => {
          _statusIcon(ctx, ix, topPipTop - 10 - si * 14, st);
        });
      }

      // Icon click = toggle whole module on/off (power returns to
      // reactor) — EXCEPT the cloak, whose icon fires the ability
      // (its power is still set with the pips above it).
      _powerClickZones.push({
        x: ix - iconR, y: cy - iconR, w: iconR * 2, h: iconR * 2,
        ...(sys.type === 'cloaking'
          ? { sysActivateIndex: ship.systems.indexOf(sys) }
          : { sysToggleIndex: ship.systems.indexOf(sys) }),
      });

      ix += 62;
    });

    // ── Weapons section (right of systems) ──
    ix += 20;
    ship.weapons.forEach((w, i) => {
      if (!w) return;
      const wy = _H - 84;
      const wcol = weaponStyleColor(w.defKey, w.def.type);
      // The card is as wide as its charge strip needs — a nine-second
      // gun simply gets a wider card than a six-second one.
      // The count comes from the CREW-ADJUSTED time: put a good gunner
      // on a 10s laser and it shows eight boxes and says 8s, instead of
      // ten boxes that mysteriously filled in eight seconds.
      const secs = (typeof w.chargeSeconds === 'function')
        ? w.chargeSeconds()
        : Math.max(1, Math.round(w.def.chargeTime ?? 1));
      const boosted = !!w.chargeBoosted;
      const segW = 9, segGap = 3;
      const ww = Math.max(140, 16 + secs * (segW + segGap));
      const wh = 52;

      // Weapon card
      const armed = w.armed;
      ctx.fillStyle = armed ? 'rgba(26,255,140,0.10)' : 'rgba(13,17,32,0.92)';
      ctx.beginPath(); ctx.roundRect(ix, wy, ww, wh, 4); ctx.fill();
      ctx.strokeStyle = armed ? '#1aff8c' : (w.powered ? wcol : '#3a4455');
      ctx.lineWidth = armed ? 2 : 1;
      ctx.stroke();

      // THE GUN ITSELF, in its own colour — you pick weapons by shape
      // here, not by reading four truncated words.
      drawWeaponIcon(ctx, w.defKey, ix + 6, wy + 5, 40, 16,
                     { dir: 1, powered: w.powered, type: w.def.type });

      /* OUT OF AMMO IS A STATE OF THE GUN, and it belongs on the gun's
         own card (update59). A weapon that eats warheads and has none
         left is charged, powered, manned — and completely inert, which
         is indistinguishable from "ready" unless the card says so. The
         card asks CombatManager, the same voice that refuses the shot,
         so the label and the refusal can never disagree. */
      const dry = (w.def.missileUse > 0) && (() => {
        // `ship` is the hull this bar belongs to — _drawPowerBar's own
        // argument. `state` is drawHUD's and does not reach in here.
        const hold = ship?.cargo;
        const have = hold ? hold.countOf('missiles') : (run?.missiles ?? 0);
        return have < w.def.missileUse;
      })();

      // Number + name + power requirement
      ctx.fillStyle = w.unmanned ? '#ff5566' : dry ? '#ff7c20'
                    : armed ? '#1aff8c' : '#c8d8f0';
      ctx.font = '10px Share Tech Mono, monospace';
      ctx.textAlign = 'left';
      ctx.fillText(w.unmanned ? `${i+1}· NO CREW!`
                 : dry        ? `${i+1}· NO AMMO!`
                              : `${i+1}· ${w.label.slice(0,14)}`,
                   ix + 50, wy + 16);
      ctx.textAlign = 'right';
      ctx.fillStyle = w.powered ? '#ffb020' : '#4a6080';
      ctx.fillText(`⚡${w.powerCost}`, ix + ww - 6, wy + 16);
      ctx.textAlign = 'left';

      // ── Charge in SECONDS, in the gun's colour ──
      const done = (w.powered ? Math.max(0, Math.min(1, w.charge)) : 0) * secs;
      for (let sI = 0; sI < secs; sI++) {
        const sx = ix + 8 + sI * (segW + segGap);
        const full = sI < Math.floor(done);
        const part = !full && sI === Math.floor(done) ? done - Math.floor(done) : 0;
        ctx.fillStyle = 'rgba(6,9,16,0.9)';
        ctx.fillRect(sx, wy + 28, segW, 13);
        if (full || part > 0) {
          ctx.fillStyle = armed ? '#c8ffe0' : wcol;
          ctx.fillRect(sx, wy + 28, full ? segW : Math.max(1, segW * part), 13);
        }
        ctx.strokeStyle = armed ? '#1aff8c' : 'rgba(120,140,170,0.35)';
        ctx.lineWidth = 1;
        ctx.strokeRect(sx + 0.5, wy + 28.5, segW - 1, 12);
      }
      // Green when the gunner is shortening the wait, with the factory
      // figure struck through beside it so the gain is legible.
      ctx.font = '8px Share Tech Mono, monospace';
      ctx.textAlign = 'right';
      ctx.fillStyle = boosted ? '#1aff8c' : '#5f7893';
      ctx.fillText(`${secs}s`, ix + ww - 6, wy + 49);
      if (boosted) {
        const base = `${Math.max(1, Math.round(w.def.chargeTime ?? 1))}s`;
        const sw = ctx.measureText?.(`${secs}s`)?.width ?? 12;
        const bw = ctx.measureText?.(base)?.width ?? 12;
        const bx = ix + ww - 10 - sw;
        ctx.fillStyle = '#4a6080';
        ctx.fillText(base, bx, wy + 49);
        ctx.strokeStyle = '#4a6080'; ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(bx - bw, wy + 46.5); ctx.lineTo(bx, wy + 46.5);
        ctx.stroke();
      }
      ctx.textAlign = 'left';

      // Click zone to select/fire
      _powerClickZones.push({
        x: ix, y: wy, w: ww, h: wh,
        weapon: i,
      });

      // AUTO toggle button under the card
      const abW = 52, abH = 16;
      const abX = ix + ww/2 - abW/2, abY = wy + wh + 3;
      ctx.fillStyle = w.autoFire ? 'rgba(26,255,140,0.25)' : 'rgba(13,17,32,0.9)';
      ctx.beginPath(); ctx.roundRect(abX, abY, abW, abH, 3); ctx.fill();
      ctx.strokeStyle = w.autoFire ? '#1aff8c' : '#3a4455';
      ctx.lineWidth = 1; ctx.stroke();
      ctx.fillStyle = w.autoFire ? '#1aff8c' : '#7a90a8';
      ctx.font = '9px Share Tech Mono, monospace';
      ctx.textAlign = 'center';
      ctx.fillText(w.autoFire ? 'AUTO ON' : 'AUTO OFF', abX + abW/2, abY + 12);

      _powerClickZones.push({
        x: abX, y: abY, w: abW, h: abH,
        weaponAuto: i,
      });

      ix += ww + 12;
    });
  }

  // ── Panel (dark rounded rect) ─────────────────────────

  function _drawPanel(ctx, x, y, w, h) {
    ctx.fillStyle = 'rgba(13,17,32,0.88)';
    ctx.beginPath();
    ctx.roundRect(x, y, w, h, 6);
    ctx.fill();
    ctx.strokeStyle = 'rgba(30,45,74,0.8)';
    ctx.lineWidth   = 1;
    ctx.stroke();
  }

  function _drawLabelBar(ctx, x, y, w, label, val, max, barColor, labelColor) {
    ctx.fillStyle = labelColor ?? '#4db8ff';
    ctx.font      = '11px Share Tech Mono, monospace';
    ctx.textAlign = 'left';
    ctx.fillText(label, x, y + 10);

    const barX = x + 44, bw = w - 50, bh = 8;
    ctx.fillStyle = '#0a1020';
    ctx.fillRect(barX, y + 2, bw, bh);
    ctx.fillStyle = barColor;
    ctx.fillRect(barX, y + 2, bw * Utils.clamp(val / max, 0, 1), bh);
    ctx.strokeStyle = '#1e2d4a';
    ctx.lineWidth   = 0.5;
    ctx.strokeRect(barX, y + 2, bw, bh);

    // Value text
    ctx.fillStyle = '#c8d8f0';
    ctx.fillText(`${Math.ceil(val)}/${max}`, barX + bw + 4, y + 10);
  }

  function _drawShieldBars(ctx, x, y, bars, max) {
    ctx.fillStyle = '#4a6080';
    ctx.font      = '11px Share Tech Mono, monospace';
    ctx.textAlign = 'left';
    ctx.fillText('SHIELDS', x, y + 9);

    for (let i = 0; i < max; i++) {
      const lit = i < bars;
      ctx.fillStyle = lit ? '#4db8ff' : '#0a1828';
      ctx.beginPath();
      ctx.arc(x + 55 + i * 18, y + 5, 6, 0, Math.PI * 2);
      ctx.fill();
      if (lit) {
        ctx.strokeStyle = '#1a8cff';
        ctx.lineWidth   = 1;
        ctx.stroke();
      }
    }
  }

  // ── Main menu screen ─────────────────────────────────────

  function drawMainMenu(hoverBtn) {
    clear();
    drawBackground(Date.now() * 0.015);

    const ctx = _ctx;
    const cx  = _W / 2, cy = _H / 2;

    // Logo
    ctx.save();
    ctx.shadowBlur  = 24;
    ctx.shadowColor = '#1a8cff';
    ctx.fillStyle   = '#4db8ff';
    ctx.font        = '72px Orbitron, monospace';
    ctx.textAlign   = 'center';
    ctx.fillText('MOON WARS', cx, cy - 140);
    ctx.restore();

    // Subtitle
    ctx.fillStyle = '#4a6080';
    ctx.font      = '11px Share Tech Mono, monospace';
    ctx.textAlign = 'center';
    ctx.fillText('A TACTICAL SPACE SURVIVAL GAME', cx, cy - 108);

    // Buttons
    /* TWO DOORS (update57). CONTINUE moved into the base — see the note
       on MENU_ITEMS in game.js. The ids and the order here must match
       MENU_ITEMS, because game.js dispatches on the INDEX. */
    const buttons = [
      { id: 'new_game',  label: 'ENTER BASE' },
      { id: 'settings',  label: 'SETTINGS' },
    ];

    buttons.forEach((b, i) => {
      const bx = cx - 100, by = cy - 40 + i * 50, bw = 200, bh = 36;
      const hover = hoverBtn === b.id;

      ctx.fillStyle = hover ? 'rgba(26,140,255,0.25)' : 'rgba(13,17,32,0.85)';
      ctx.beginPath(); ctx.roundRect(bx, by, bw, bh, 4); ctx.fill();

      ctx.strokeStyle = hover ? '#4db8ff' : '#1e2d4a';
      ctx.lineWidth   = hover ? 1.5 : 1;
      ctx.stroke();

      ctx.fillStyle = hover ? '#4db8ff' : '#c8d8f0';
      ctx.font      = '14px Orbitron, monospace';
      ctx.textAlign = 'center';
      ctx.fillText(b.label, cx, by + 24);

      // Click regions registered by game.js _registerMenuButtons()
    });

    // Version
    ctx.fillStyle = '#1a2a3a';
    ctx.font      = '11px Share Tech Mono, monospace';
    ctx.textAlign = 'right';
    ctx.fillText('v0.1.0 — MOON WARS', _W - 10, _H - 10);
  }

  const _menuCallbacks = {};
  function onMenuButton(id, cb) { _menuCallbacks[id] = cb; }

  // ── Map screen ───────────────────────────────────────────

  /* The map screen is handed the ship's hold so the ore readout can be
     read off the cells rather than off a mirrored number (update58).
     Optional, so an old call site still draws. */
  let _mapHold = null;
  function drawMapScreen(sectorMap, hoverNodeId = null, hold = null) {
    _mapHold = hold;
    clear();
    drawBackground(0);

    const ctx = _ctx;
    const ox  = (_W - 700) / 2;   // centered — ship view is separate
    const oy0 = (_H - 400) / 2;
    if (sectorMap && sectorMap.awaitingStartPick) {
      ctx.fillStyle = 'rgba(13,17,32,0.92)';
      ctx.beginPath(); ctx.roundRect(_W/2 - 190, oy0 - 76, 380, 30, 5); ctx.fill();
      ctx.strokeStyle = '#1aff8c'; ctx.lineWidth = 1; ctx.stroke();
      ctx.fillStyle = '#1aff8c';
      ctx.font = '12px Share Tech Mono, monospace';
      ctx.textAlign = 'center';
      ctx.fillText('⟨ CHOOSE YOUR STARTING LANE — TOP · MIDDLE · BOTTOM ⟩',
                   _W/2, oy0 - 56);
    }
    const oy  = (_H - 400) / 2;

    // Background panel
    _drawPanel(ctx, ox - 20, oy - 40, 740, 480);

    // Title
    ctx.fillStyle = '#c8d8f0';
    ctx.font      = '14px Orbitron, monospace';
    ctx.textAlign = 'left';
    /* THE MOON'S NAME ABOVE THE SECTOR (update56). One region exists,
       and saying so is the point: a player who reads "LUNA · SECTOR 2"
       knows there is somewhere else to be, which is what the Moon Gate
       is for. Reads Save's region table — no second copy of the name. */
    const regionLabel = (typeof Save !== 'undefined' && Save.currentRegion)
      ? (Save.currentRegion()?.label ?? '') : '';
    ctx.fillText(regionLabel ? `${regionLabel} · SECTOR ${sectorMap.sector} MAP`
                             : `SECTOR ${sectorMap.sector} MAP`, ox - 10, oy - 18);
    /* Say WHY the map is half empty, so a player who has not found a
       probe yet does not read the fog as a rendering bug. One WORD up
       here — the CC and He2 readouts own the rest of this line — and
       the explanation goes in the empty space at the foot of the panel. */
    ctx.font      = '10px Share Tech Mono, monospace';
    ctx.fillStyle = sectorMap.revealed ? '#4dffd0' : '#5f7893';
    ctx.fillText(sectorMap.revealed ? '● SURVEYED' : '◌ UNSURVEYED', ox + 188, oy - 18);

    const run = Save.getRun();
    if (run) {
      ctx.font      = '13px Share Tech Mono, monospace';
      ctx.textAlign = 'right';
      ctx.fillStyle = run.fuel <= 2 ? '#ff2d44' : '#ff5566';
      ctx.fillText(`He2 ${run.fuel}`, ox + 450, oy - 18);   // mirrors the cells
      ctx.fillStyle = '#1aff8c';
      ctx.fillText(`${run.scrap} CC`, ox + 360, oy - 18);
      // The ore rides here too — the map is where the player decides
      // whether a detour for salvage is worth it (update58).
      {
        const hold = Save.getRun && _mapHold;
        const ore = _mapHold?.countOfTag ? _mapHold.countOfTag('he3') : 0;
        const oreCol = ore > 0 ? '#cfe4ff' : '#3d4a63';
        ctx.fillStyle = oreCol;
        ctx.fillText(`He3 ${ore}`, ox + 540, oy - 18);
        ctx.textAlign = 'left';
        drawStatIcon(ctx, 'ore', ox + 544, oy - 27, 11, oreCol);
      }
      ctx.textAlign = 'left';
    }

    sectorMap.draw(ctx, ox, oy);

    if (!sectorMap.revealed) {
      ctx.font      = '11px Share Tech Mono, monospace';
      ctx.fillStyle = '#4a6080';
      ctx.textAlign = 'center';
      ctx.fillText('Sensors reach one jump ahead. Burn a Survey Probe from the hold '
                 + 'to resolve the whole sector.', ox + 350, oy + 412);
      ctx.textAlign = 'left';
    }

    // Hover tooltip
    if (hoverNodeId) {
      const node = sectorMap.getNode(hoverNodeId);
      if (node && !node.locked && sectorMap.visibilityOf?.(node) === 'known') {
        const tx = node.x + ox + 24, ty = node.y + oy - 24;
        _drawPanel(ctx, tx, ty, 120, 48);
        ctx.fillStyle = node.color;
        ctx.font      = '14px Orbitron, monospace';
        ctx.textAlign = 'left';
        ctx.fillText(node.label, tx + 8, ty + 16);
        ctx.fillStyle = '#4a6080';
        ctx.font      = '11px Share Tech Mono, monospace';
        ctx.fillText('Click to travel', tx + 8, ty + 32);
      }
    }
  }

  // ── Combat screen layout ─────────────────────────────────

  function drawCombatLayout(playerShip, enemyShip) {
    // Both ships are drawn by their own draw() method;
    // this just handles the "combat arena" background line

    const ctx = _ctx;
    ctx.strokeStyle = 'rgba(30,45,70,0.3)';
    ctx.lineWidth   = 1;
    ctx.setLineDash([6, 6]);
    ctx.beginPath();
    ctx.moveTo(_W / 2, 20);
    ctx.lineTo(_W / 2, _H - 20);
    ctx.stroke();
    ctx.setLineDash([]);
  }

  // ── Retreat progress ─────────────────────────────────────

  function drawRetreatBar(progress) {
    const w  = 200, h = 20;
    const x  = _W / 2 - w / 2, y = _H - 50;
    _drawPanel(_ctx, x - 4, y - 4, w + 8, h + 8);
    _ctx.fillStyle = '#ff7c20';
    _ctx.fillRect(x, y, w * progress, h);
    _ctx.fillStyle = '#c8d8f0';
    _ctx.font      = '12px Share Tech Mono, monospace';
    _ctx.textAlign = 'center';
    _ctx.fillText('RETREATING…', _W / 2, y + 14);
  }

  // ── Event popup ──────────────────────────────────────────

  function drawEventPopup(event, hoverChoice = -1) {
    const ctx = _ctx;
    const W   = 480, H = 240;
    const x   = _W/2 - W/2, y = _H/2 - H/2;

    _drawPanel(ctx, x, y, W, H);

    ctx.fillStyle = '#4db8ff';
    ctx.font      = '15px Orbitron, monospace';
    ctx.textAlign = 'left';
    ctx.fillText(event.title, x + 20, y + 30);

    ctx.fillStyle = '#c8d8f0';
    ctx.font      = '12px Share Tech Mono, monospace';
    // Word-wrap text (simple)
    const words  = event.text.split(' ');
    let line     = '', cy2 = y + 55;
    words.forEach(w => {
      const test = line + w + ' ';
      if (ctx.measureText(test).width > W - 40) {
        ctx.fillText(line, x + 20, cy2); cy2 += 14; line = w + ' ';
      } else { line = test; }
    });
    if (line) { ctx.fillText(line, x + 20, cy2); }

    // Choices
    event.choices.forEach((c, i) => {
      const bx = x + 20, by = y + 150 + i * 36, bw = W - 40, bh = 28;
      const hover = hoverChoice === i;

      ctx.fillStyle = hover ? 'rgba(26,140,255,0.3)' : 'rgba(20,30,50,0.8)';
      ctx.beginPath(); ctx.roundRect(bx, by, bw, bh, 4); ctx.fill();
      ctx.strokeStyle = hover ? '#4db8ff' : '#1e2d4a';
      ctx.lineWidth   = 1;
      ctx.stroke();

      ctx.fillStyle = hover ? '#4db8ff' : '#c8d8f0';
      ctx.font      = '12px Share Tech Mono, monospace';
      ctx.textAlign = 'left';
      ctx.fillText(c.label, bx + 10, by + 18);

      /* ── WHAT IT COSTS HIM, BEFORE HE CLICKS (update50) ────
         The spec is explicit: show the karma change AND the chips it
         will switch off BEFORE the choice, not in a notification
         afterwards. A moral decision the player only understands in
         hindsight is not a decision. */
      const km = c.result?.karma;
      const cap = (typeof Commander !== 'undefined' && Commander.active)
        ? Commander.active() : null;
      if (km && cap) {
        const pv = Commander.preview ? Commander.preview(cap, km) : null;
        const bits = [`KARMA ${km > 0 ? '+' : ''}${km}`];
        if (pv?.killed) bits.push(`${pv.killed} chip(ów) zgaśnie`);
        else if (pv?.wallMoved) bits.push('blokada CPU się przesunie');
        ctx.textAlign = 'right';
        ctx.fillStyle = km > 0 ? '#1aff8c' : '#ff5566';
        ctx.font = '10px Share Tech Mono, monospace';
        ctx.fillText(bits.join(' · '), bx + bw - 10, by + 18);
        ctx.textAlign = 'left';
      }

      // Click regions registered by game.js _registerEventChoices()
    });
  }

  const _eventCallbacks = {};
  function onEventChoice(idx, cb) { _eventCallbacks[idx] = cb; }

  // ── Victory / defeat splash ───────────────────────────────

  /** Mini blueprint of a hull, drawn from its REAL room layout.
   *  Used by the hangar, the shipyard and anywhere else the player is
   *  choosing between ships — a wall of text does not tell you that a
   *  hull has three free bays, but a picture does.
   *  @param {string} layoutKey  key into SHIP_LAYOUTS
   *  @param {object} opts       { rooms: [{id,type}] } to override the
   *                             stock layout with a ship's real state */
  /** ONE glyph table for the whole game: power bar, thumbnails, panels. */
  const SYSTEM_GLYPHS = {
    shields: '◙', weapons: '▲', engines: '≋', reactor: '⌁',
    oxygen: 'O₂', medbay: '+', piloting: '◎', artillery: '✦',
    cloaking: '◈', autorepair: '⚙', empty: '·',
    /* The brig had no glyph and drew '?' — on the power bar, on the
       thumbnails, and now on the mark strip. A module that cannot say
       what it is is worse than one that is not drawn at all. */
    carbonite: '▣',
  };

  function systemGlyph(type) { return SYSTEM_GLYPHS[type] ?? '?'; }

  /* ── Weapon graphics ──────────────────────────────────────
     One drawing routine for every gun in the game, so a Burst Laser
     looks like a Burst Laser on the hull, in the shop, in the armoury
     and on a crate. Everything is drawn into a w x h box pointing
     RIGHT by default; pass dir:-1 to face left. */

  const WEAPON_COLORS = {
    laser:   '#4db8ff',
    missile: '#ffb347',
    ion:     '#8a7dff',
    cannon:  '#ff7c20',
    flak:    '#ffd780',
    beam:    '#ff5566',
  };

  function weaponColor(type) { return WEAPON_COLORS[type] || '#4db8ff'; }

  /**
   * Every gun in the game gets its OWN silhouette — not one per damage
   * type. A Burst Laser has three short emitters, a Heavy Laser one fat
   * one; you can tell them apart on the hull without reading a label.
   * `key` is the WEAPON_DEFS key; a bare type still works as a fallback.
   */
  const WEAPON_STYLE = {
    laser_basic:   { col: '#ff5566', form: 'rail',    barrels: 1 },
    laser_burst:   { col: '#ff7a88', form: 'rail',    barrels: 3 },
    laser_heavy:   { col: '#ff3344', form: 'heavy',   barrels: 1 },
    missile_basic: { col: '#ffb347', form: 'pods',    barrels: 2 },
    ion_basic:     { col: '#8a7dff', form: 'coil',    barrels: 1 },
    cannon_basic:  { col: '#ff7c20', form: 'howitzer',barrels: 1 },
    flak_basic:    { col: '#ffd780', form: 'drum',    barrels: 4 },
    beam_basic:    { col: '#ff2d6a', form: 'emitter', barrels: 1 },
  };

  /** Just the colour a given gun should wear. */
  function weaponStyleColor(key, type) { return weaponStyle(key, type).col; }

  function weaponStyle(key, type) {
    return WEAPON_STYLE[key]
        || WEAPON_STYLE[Object.keys(WEAPON_STYLE).find(k => k.startsWith(type + '_'))]
        || { col: weaponColor(type), form: 'rail', barrels: 1 };
  }

  function drawWeaponIcon(ctx, key, x, y, w, h, opts = {}) {
    const type = opts.type
      || (typeof WEAPON_DEFS !== 'undefined' && WEAPON_DEFS[key]?.type)
      || key;
    const st   = weaponStyle(key, type);
    const { dir = 1, powered = true, dim = false } = opts;
    const col  = dim ? '#4a5568' : st.col;
    const body = dim ? '#161d2b' : 'rgba(20,30,50,0.95)';

    ctx.save();
    ctx.translate(x + (dir < 0 ? w : 0), y);
    ctx.scale(dir < 0 ? -1 : 1, 1);

    const midY = h / 2;
    const hb   = Math.max(4, h * 0.55);
    const bx   = w * 0.50;

    // Housing — shaped by the family, so even the base reads differently.
    ctx.fillStyle = body;
    ctx.beginPath();
    if (st.form === 'howitzer')      ctx.roundRect(0, midY - hb * 0.75, w * 0.50, hb * 1.5, 3);
    else if (st.form === 'emitter')  ctx.roundRect(0, midY - hb * 0.45, w * 0.50, hb * 0.9, 6);
    else if (st.form === 'pods')     ctx.roundRect(0, midY - hb * 0.65, w * 0.48, hb * 1.3, 1);
    else                             ctx.roundRect(0, midY - hb / 2, w * 0.50, hb, 2);
    ctx.fill();
    ctx.strokeStyle = col; ctx.lineWidth = 1; ctx.stroke();

    ctx.fillStyle = dim ? '#232c3d' : '#2a3a55';
    ctx.fillRect(w * 0.10, midY + hb * 0.62, w * 0.20, Math.max(2, h * 0.14));

    ctx.fillStyle = col;
    ctx.strokeStyle = col;

    switch (st.form) {
      case 'pods': {                    // missile launcher: stacked tubes
        for (let i = 0; i < st.barrels; i++) {
          const oy = midY + (i - (st.barrels - 1) / 2) * (hb * 0.62);
          ctx.fillRect(bx, oy - hb * 0.20, w * 0.42, hb * 0.40);
          ctx.fillStyle = dim ? '#2a3346' : '#07080f';
          ctx.fillRect(bx + w * 0.36, oy - hb * 0.20, w * 0.06, hb * 0.40);
          ctx.fillStyle = col;
        }
        break;
      }
      case 'drum': {                    // flak: short barrels round a drum
        ctx.beginPath();
        ctx.ellipse(bx + w * 0.06, midY, w * 0.07, h * 0.34, 0, 0, Math.PI * 2);
        ctx.fill();
        for (let i = 0; i < st.barrels; i++) {
          const oy = midY + (i - (st.barrels - 1) / 2) * (h * 0.17);
          ctx.fillRect(bx + w * 0.10, oy - 1.2, w * 0.28, 2.4);
        }
        break;
      }
      case 'howitzer': {                // hull cannon: one fat barrel
        ctx.fillRect(bx, midY - h * 0.17, w * 0.34, h * 0.34);
        ctx.fillRect(bx + w * 0.30, midY - h * 0.26, w * 0.12, h * 0.52);
        ctx.fillStyle = dim ? '#2a3346' : '#07080f';
        ctx.fillRect(bx + w * 0.40, midY - h * 0.10, w * 0.03, h * 0.20);
        break;
      }
      case 'coil': {                    // ion: rod through coils
        ctx.fillRect(bx, midY - 1.5, w * 0.44, 3);
        for (let i = 0; i < 4; i++) {
          const cx2 = bx + w * (0.05 + i * 0.11);
          ctx.beginPath();
          ctx.ellipse(cx2, midY, Math.max(1.5, w * 0.022), h * 0.26, 0, 0, Math.PI * 2);
          ctx.stroke();
        }
        break;
      }
      case 'emitter': {                 // beam: focusing dish
        ctx.fillRect(bx, midY - 2, w * 0.22, 4);
        ctx.beginPath();
        ctx.moveTo(bx + w * 0.22, midY - h * 0.34);
        ctx.lineTo(bx + w * 0.48, midY);
        ctx.lineTo(bx + w * 0.22, midY + h * 0.34);
        ctx.closePath();
        ctx.fill();
        ctx.fillStyle = dim ? '#2a3346' : '#fff2f5';
        ctx.beginPath();
        ctx.arc(bx + w * 0.30, midY, Math.max(1.5, h * 0.09), 0, Math.PI * 2);
        ctx.fill();
        break;
      }
      case 'heavy': {                   // heavy laser: one thick emitter
        ctx.fillRect(bx, midY - h * 0.13, w * 0.40, h * 0.26);
        ctx.fillRect(bx + w * 0.34, midY - h * 0.24, w * 0.08, h * 0.48);
        break;
      }
      default: {                        // rail: 1..3 slim emitters
        const n = st.barrels;
        for (let i = 0; i < n; i++) {
          const oy = midY + (i - (n - 1) / 2) * (h * 0.24);
          ctx.fillRect(bx, oy - 1.5, w * 0.42, 3);
        }
        ctx.fillRect(bx + w * 0.38, midY - h * 0.20, w * 0.06, h * 0.40);
        break;
      }
    }

    if (!powered && !dim) {
      ctx.globalAlpha = 0.45;
      ctx.fillStyle = '#0b0f18';
      ctx.fillRect(0, 0, w, h);
    }
    ctx.restore();
  }

  /** Same icon as a data URL, for the DOM station panels. Cached. */
  const _wIconCache = new Map();
  function weaponIconURL(type, w = 44, h = 18) {
    const key = `${type}_${w}x${h}`;
    if (_wIconCache.has(key)) return _wIconCache.get(key);
    let url = '';
    try {
      const cv = document.createElement('canvas');
      cv.width = w * 2; cv.height = h * 2;
      const c2 = cv.getContext('2d');
      c2.scale(2, 2);
      drawWeaponIcon(c2, type, 1, 1, w - 2, h - 2, {});
      url = cv.toDataURL('image/png');
    } catch (e) { url = ''; }
    _wIconCache.set(key, url);
    return url;
  }

  function drawShipThumb(ctx, layoutKey, x, y, w, h, opts = {}) {
    const L = (typeof SHIP_LAYOUTS !== 'undefined') ? SHIP_LAYOUTS[layoutKey] : null;
    if (!L) return;

    // save/restore — this helper centres its bay labels, and leaking
    // that textAlign threw the CALLER's next line of text half a width
    // to the left (the hangar stats ended up outside the card).
    ctx.save();
    const rooms = L.rooms;
    const minX = Math.min(...rooms.map(r => r.x));
    const minY = Math.min(...rooms.map(r => r.y));
    const maxX = Math.max(...rooms.map(r => r.x + r.w));
    const maxY = Math.max(...rooms.map(r => r.y + r.h));
    const scale = Math.min(w / (maxX - minX), h / (maxY - minY));
    const ox = x + (w - (maxX - minX) * scale) / 2;
    const oy = y + (h - (maxY - minY) * scale) / 2;

    // Room colours echo the power bar so the same module reads the same
    // everywhere in the game.
    const COL = {
      engines:'#1aff8c', weapons:'#ff5566', shields:'#4db8ff', piloting:'#9fdcff',
      oxygen:'#4dd8ff',  medbay:'#3aff6a',  reactor:'#ffb020', cloaking:'#cc44ff',
      autorepair:'#ffd700', artillery:'#ff7c20', empty:'#39445c',
    };
    // Icons, not letter codes: buying a hull you can SEE what is in it
    // without learning that "SHD" means shields.
    const SHORT = {
      engines:'ENG', weapons:'WPN', shields:'SHD', piloting:'PIL', oxygen:'O₂',
      medbay:'MED', reactor:'RCT', cloaking:'CLK', autorepair:'REP', artillery:'ART',
      empty:'—',
    };
    const levels = new Map((opts.levels ?? []).map(l => [l.id, l.level]));

    const override = new Map((opts.rooms ?? []).map(r => [r.id, r.type]));

    rooms.forEach(r => {
      const type = override.get(r.id) ?? r.type;
      const rx = ox + (r.x - minX) * scale;
      const ry = oy + (r.y - minY) * scale;
      const rw = r.w * scale, rh = r.h * scale;
      const col = COL[type] || '#39445c';
      const bare = type === 'empty';

      ctx.fillStyle = bare ? 'rgba(30,38,58,0.5)' : col + '22';
      ctx.fillRect(rx, ry, rw - 1, rh - 1);
      ctx.strokeStyle = bare ? '#39445c' : col + '99';
      ctx.lineWidth = 1;
      if (bare) ctx.setLineDash([3, 3]);
      ctx.strokeRect(rx + 0.5, ry + 0.5, rw - 2, rh - 2);
      ctx.setLineDash([]);

      // The GLYPH always fits; the word only goes in when there is room
      // for it underneath. An empty bay gets a dashed box and nothing else.
      ctx.textAlign = 'center';
      if (!bare) {
        const gs = Utils.clamp(Math.min(rw, rh) * 0.55, 8, 17);
        ctx.fillStyle = col;
        ctx.font = `${gs}px Share Tech Mono, monospace`;
        const wordFits = rw > 30 && rh > 22;
        ctx.fillText(systemGlyph(type), rx + rw / 2,
                     ry + rh / 2 + (wordFits ? -1 : gs * 0.35));
        if (wordFits) {
          ctx.fillStyle = col + 'cc';
          ctx.font = `${Math.max(6, Math.min(8, rw / 5))}px Share Tech Mono, monospace`;
          ctx.fillText(SHORT[type] ?? '?', rx + rw / 2, ry + rh / 2 + 11);
        }
        // Level pips along the bottom edge — how good the module is.
        const lvl = levels.get(r.id);
        if (lvl > 0 && rw > 18) {
          const pw = Math.min(4, (rw - 6) / Math.max(1, lvl) - 1);
          for (let i = 0; i < lvl; i++) {
            ctx.fillStyle = col;
            ctx.fillRect(rx + 3 + i * (pw + 1), ry + rh - 4, pw, 2);
          }
        }
      } else if (rw > 14 && rh > 12) {
        ctx.fillStyle = '#5a6a86';
        ctx.font = `${Math.max(8, Math.min(12, rw / 3))}px Share Tech Mono, monospace`;
        ctx.fillText('+', rx + rw / 2, ry + rh / 2 + 4);
      }
    });

    // Hull outline, so it reads as ONE ship rather than loose boxes
    ctx.strokeStyle = 'rgba(77,184,255,0.35)';
    ctx.lineWidth = 1;
    ctx.strokeRect(ox - 2.5, oy - 2.5, (maxX - minX) * scale + 4, (maxY - minY) * scale + 4);
    ctx.restore();
  }

  function drawOutcome(type, scrap = 0) {
    const ctx = _ctx;
    const cx  = _W / 2;

    ctx.fillStyle = 'rgba(7,8,15,0.75)';
    ctx.fillRect(0, 0, _W, _H);

    const isVictory = type === 'victory';
    ctx.fillStyle = isVictory ? '#1aff8c' : '#ff2d44';
    ctx.font      = '48px Orbitron, monospace';
    ctx.textAlign = 'center';
    ctx.fillText(isVictory ? 'VICTORY' : 'SHIP DESTROYED', cx, _H/2 - 40);

    if (isVictory && scrap > 0) {
      ctx.fillStyle = '#ffd700';
      ctx.font      = '16px Share Tech Mono, monospace';
      ctx.fillText(`+${scrap} CC COLLECTED`, cx, _H/2 + 10);
    }

    ctx.fillStyle = '#4a6080';
    ctx.font      = '12px Share Tech Mono, monospace';
    ctx.fillText('Press [ENTER] to continue', cx, _H/2 + 50);
  }

  /* ── Weapon stat icons ────────────────────────────────────
     ONE definition, TWO renderers.

     The station shop is DOM and the base armoury is canvas, so the same
     little DMG/CHARGE/POWER pictograms had to exist twice. Rather than
     draw them twice and let them drift apart, each icon is a tiny list
     of primitives in a 0..10 box, and there is one interpreter per
     surface. Change the shape once and both surfaces move together. */

  const STAT_ICONS = {
    /* A CUT CRYSTAL OF ORE (update58) — the mineral readout needed a
       pictogram of its own, and this set is where the game's pictograms
       live. Not a canister (that is He2, the fuel) and not a crate: a
       rough hexagonal stone with a facet, so it reads as something dug
       up rather than something poured. */
    ore: [['poly', [5,0, 9.4,3, 8,8.6, 2,8.6, 0.6,3], true],
          ['line', 5, 0, 5, 8.6], ['line', 0.6, 3, 9.4, 3]],
    // A shell bursting on impact.
    dmg: [['poly', [5,0, 6.4,3.6, 10,5, 6.4,6.4, 5,10, 3.6,6.4, 0,5, 3.6,3.6], true]],
    // A stopwatch: dial plus a hand pointing at one o'clock.
    charge: [['circle', 5, 5.4, 4.2, false],
             ['line', 5, 5.4, 5, 2.4], ['line', 5, 5.4, 7.2, 6.4],
             ['line', 3.6, 0.4, 6.4, 0.4]],
    // The mains bolt, the same shape the ⚡ chip always meant.
    power: [['poly', [5.8,0, 1.6,5.6, 4.4,5.6, 3.8,10, 8.4,4.2, 5.4,4.2], true]],
    // Rounds in flight — three tracers, biggest in front.
    shots: [['poly', [10,5, 6.6,3.2, 6.6,6.8], true],
            ['line', 4.6, 5, 1.6, 5], ['line', 3.0, 2.6, 0.6, 2.6],
            ['line', 3.0, 7.4, 0.6, 7.4]],
    // A warhead: cone, body, fins.
    ammo: [['poly', [10,5, 6.4,2.4, 6.4,7.6], true],
           ['rect', 2.2, 3.4, 4.4, 3.2, true],
           ['poly', [2.2,3.4, 0.2,1.4, 0.2,4.0, 2.2,4.0], true],
           ['poly', [2.2,6.6, 0.2,8.6, 0.2,6.0, 2.2,6.0], true]],
    // A shield: flat top, pointed foot.
    shield: [['poly', [5,0.2, 9.4,2.0, 9.4,5.4, 5,9.8, 0.6,5.4, 0.6,2.0], false]],
    // Hull plating: a riveted plate.
    hull: [['rect', 0.6, 1.6, 8.8, 6.8, false],
           ['circle', 2.4, 5, 0.7, true], ['circle', 7.6, 5, 0.7, true]],
  };

  /** Paint one stat icon onto a canvas, fitted into `size` pixels. */
  function drawStatIcon(ctx, kind, x, y, size, col) {
    const ops = STAT_ICONS[kind];
    if (!ops) return;
    const s = size / 10;
    ctx.save();
    ctx.translate(x, y);
    ctx.fillStyle = col; ctx.strokeStyle = col;
    ctx.lineWidth = Math.max(1, size / 10);
    ctx.lineJoin = 'round'; ctx.lineCap = 'round';
    ops.forEach(op => {
      const [kindOp] = op;
      if (kindOp === 'poly') {
        const [, pts, fill] = op;
        ctx.beginPath();
        for (let i = 0; i < pts.length; i += 2) {
          const px = pts[i] * s, py = pts[i + 1] * s;
          if (i === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
        }
        ctx.closePath();
        if (fill) ctx.fill(); else ctx.stroke();
      } else if (kindOp === 'circle') {
        const [, cxx, cyy, r, fill] = op;
        ctx.beginPath(); ctx.arc(cxx * s, cyy * s, r * s, 0, Math.PI * 2);
        if (fill) ctx.fill(); else ctx.stroke();
      } else if (kindOp === 'line') {
        const [, x1, y1, x2, y2] = op;
        ctx.beginPath(); ctx.moveTo(x1 * s, y1 * s); ctx.lineTo(x2 * s, y2 * s); ctx.stroke();
      } else if (kindOp === 'rect') {
        const [, rx, ry, rw, rh, fill] = op;
        if (fill) ctx.fillRect(rx * s, ry * s, rw * s, rh * s);
        else ctx.strokeRect(rx * s, ry * s, rw * s, rh * s);
      }
    });
    ctx.restore();
  }

  /** The SAME icon as inline SVG markup, for the DOM station shop. */
  function statIconSVG(kind, col, size = 10) {
    const ops = STAT_ICONS[kind];
    if (!ops) return '';
    const body = ops.map(op => {
      const [k] = op;
      if (k === 'poly') {
        const [, pts, fill] = op;
        const d = [];
        for (let i = 0; i < pts.length; i += 2) d.push(`${pts[i]},${pts[i + 1]}`);
        return `<polygon points="${d.join(' ')}" fill="${fill ? col : 'none'}"` +
               `${fill ? '' : ` stroke="${col}" stroke-width="1"`}/>`;
      }
      if (k === 'circle') {
        const [, cxx, cyy, r, fill] = op;
        return `<circle cx="${cxx}" cy="${cyy}" r="${r}" fill="${fill ? col : 'none'}"` +
               `${fill ? '' : ` stroke="${col}" stroke-width="1"`}/>`;
      }
      if (k === 'line') {
        const [, x1, y1, x2, y2] = op;
        return `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="${col}" ` +
               `stroke-width="1" stroke-linecap="round"/>`;
      }
      const [, rx, ry, rw, rh, fill] = op;
      return `<rect x="${rx}" y="${ry}" width="${rw}" height="${rh}" ` +
             `fill="${fill ? col : 'none'}"${fill ? '' : ` stroke="${col}" stroke-width="1"`}/>`;
    }).join('');
    return `<svg viewBox="0 0 10 10" width="${size}" height="${size}" ` +
           `style="vertical-align:-1px;flex:none">${body}</svg>`;
  }

  // ── Public API ───────────────────────────────────────────

  return {
    init, getCtx, getWidth, getHeight,
    clear,
    drawBackground,
    drawNebula,
    drawHUD, commanderStripRect, drawCommanderDossier, orderRects,
    DISEASE_COL,
    bodyMenuRects, drawBodyMenu,
    drawPips, PIP_HP,
    crewRoster,
    getPowerClickZones,
    crewMarks, getCrewMarkZones, crewPanelX,
    drawMainMenu,
    drawMapScreen,
    drawCombatLayout,
    drawRetreatBar,
    drawEventPopup,
    drawOutcome,
    drawShipThumb, systemGlyph, runGoalsRect, runGoalsBox,
    drawWeaponIcon, weaponIconURL, weaponColor, weaponStyleColor, weaponStyle,
    drawStatIcon, statIconSVG, STAT_ICONS,
    onMenuButton,
    onEventChoice,
  };

})();
