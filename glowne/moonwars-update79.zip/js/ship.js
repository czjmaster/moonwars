/* ============================================================
   MOON WARS — ship.js
   Ship class: layout, rooms, systems, hull, crew roster,
   weapons rack, elevator integration, damage resolution.
   Both player and enemy ships use this class.
   ============================================================ */

'use strict';

// ── Door ──────────────────────────────────────────────────

/** Seconds for a door panel to travel from shut to fully open. */
const DOOR_CYCLE = 1.0;

class Door {
  /**
   * Door between two adjacent rooms — or an AIRLOCK to space (roomB = null).
   * Doors are BINARY: 'open' or 'closed'. Green = open, red = closed.
   *        'closed' (player-locked shut).
   * Open airlocks vent the room's oxygen to space (FTL fire-fighting tactic).
   */
  constructor(roomA, roomB, x, y, isAirlock = false) {
    this.roomA  = roomA;
    this.roomB  = roomB;        // null = space
    this.x      = x;
    this.y      = y;
    this.isAirlock = isAirlock;
    // Doors are strictly BINARY: open or closed. Interior doors start
    // open (air flows), airlocks start closed. Click toggles.
    this.mode   = isAirlock ? 'closed' : 'open';
    // A door is no longer instant. `openness` runs 0..1 over DOOR_CYCLE
    // seconds and `open` means FULLY open — nobody squeezes through a
    // door that is still moving.
    this.openness = isAirlock ? 0 : 1;
    this.open   = !isAirlock;
    // Auto-passage: an INTERIOR door a crew member walks up to slides
    // open briefly even if the player locked it 'closed', then closes
    // again. Airlocks NEVER auto-open (they must be breached).
    this._tempT = 0;   // seconds left holding open for a passer-by
    this.breached = false;   // legacy: airlock smashed open (see hack())

    /* ── HACKING ──────────────────────────────────────────────
       A door belongs to the hull it is bolted into: it slides open for
       the crew who live there and stays shut to everyone else. An
       intruder has to work the lock, and the first door of a fight is
       the airlock they came through.

       Per SIDE, and per fight: once a boarding party has cracked a
       particular door it stays cracked for them until the battle ends
       (Ship.markCombatStart resets them), so they are not re-hacking
       the same corridor on the way back. */
    this.hacked = { player: false, enemy: false };
    this.hackT  = 0;
  }

  /** Seconds of work to crack one lock. */
  static get HACK_TIME() { return 2.5; }

  /**
   * An intruder from `side` works this lock. Returns true once the door
   * will actually let them through.
   */
  hackBy(side, dt = 0) {
    if (this.hacked[side]) {
      // Already theirs — from here on it behaves like their own door.
      this._tempT = Math.max(this._tempT, 0.6);
      return this.open;
    }
    this.hackT += dt;
    if (this.hackT >= Door.HACK_TIME) {
      this.hacked[side] = true;
      this.hackT = 0;
      this._tempT = Math.max(this._tempT, 1.2);
      Audio.sfx.doorMove?.();
    }
    return false;
  }

  /** Force a door open to a side without the work — the boarding party
   *  cutting the outer hatch has already spent its time doing that. */
  hackOpen(side, hold = 2.2) {
    this.hacked[side] = true;
    this.hackT = 0;
    this._tempT = Math.max(this._tempT, hold);
  }

  isHackedBy(side) { return !!this.hacked[side]; }
  get hackProgress() { return Utils.clamp(this.hackT / Door.HACK_TIME, 0, 1); }

  /** New battle: every lock is a stranger's lock again. */
  resetHacks() { this.hacked = { player: false, enemy: false }; this.hackT = 0; }

  /** Player click: open ↔ closed. The panel then takes a second to cycle. */
  toggle() {
    this.mode = this.mode === 'open' ? 'closed' : 'open';
    this._tempT = 0;
    Audio.sfx.uiClick();
    Audio.sfx.doorMove?.();
  }

  /** Where the panel should end up, 1 = open. */
  get _target() {
    if (this.breached) return 1;
    // A hacked airlock cycles like any other door instead of staying a
    // hole in the hull. The old boarding code smashed it permanently,
    // which vented that room for the rest of the run with no way to
    // ever seal it again.
    if (this.isAirlock) return (this._tempT > 0 || this.mode === 'open') ? 1 : 0;
    return (this._tempT > 0 || this.mode === 'open') ? 1 : 0;
  }

  /** A crew member is standing at this door wanting through.
   *  INTERIOR doors slide open (with a short delay so it reads as a
   *  door cycling). Returns true once it's actually open to pass. */
  requestPassage(dt) {
    if (this.isAirlock) return this.open;   // airlocks don't auto-open
    // Ask for it, then WAIT. The door needs its full second; returning
    // true early let crew walk through a half-open panel.
    this._tempT = Math.max(this._tempT, 0.6);
    return this.open;
  }

  update(dt, crew) {
    if (this._tempT > 0) this._tempT -= dt;

    // Slide toward the target at a fixed rate — one full second end to
    // end, whichever way it is going. A breached airlock is simply gone,
    // so it snaps.
    const target = this._target;
    if (this.breached) {
      this.openness = 1;
    } else if (this.openness !== target) {
      const step = dt / DOOR_CYCLE;
      this.openness = target > this.openness
        ? Math.min(target, this.openness + step)
        : Math.max(target, this.openness - step);
    }
    // FULLY open, not "on its way".
    this.open = this.openness >= 1;

    if (!this.isAirlock) return;

    // Venting particles for open airlocks (throttled)
    if (this.open) {
      this._ventT = (this._ventT ?? 0) + dt;
      if (this._ventT > 0.15) {
        this._ventT = 0;
        Particles.emit({
          x: this.x, y: this.y + Utils.randFloat(-12, 12),
          vx: (this.x < 640 ? -1 : 1) * Utils.randFloat(40, 90),
          vy: Utils.randFloat(-15, 15), ay: 0,
          color: '#aaccee', size: 2, sizeEnd: 0,
          life: 0.4, alpha: 0.7, alphaEnd: 0,
        });
      }
    }
  }

  /* THE DOOR IS 6 x 34 PIXELS, and that is the only place those two
     numbers live (update69). The drawing below reads them, and so does
     `hits()` — the hit test used to be a 32px circle around the same
     point, five times wider than the leaf you can see, reaching well
     into the module behind it. Clicks meant for the room, and for the
     menu that opens over it, were eaten by a hatch that was nowhere
     near the cursor. The player's words: "drzwi mają siatkę klikania
     za bardzo oddaloną od samych drzwi i nachodzi mocno na moduł". */
  static get W() { return 6; }
  static get H() { return 34; }
  /** Generous enough to hit with a mouse, tight enough to stay ON the
   *  door: the leaf plus 5px of wall either side, and nothing more. */
  static get GRAB() { return 5; }

  hits(mx, my) {
    return Math.abs(mx - this.x) <= Door.W / 2 + Door.GRAB &&
           Math.abs(my - this.y) <= Door.H / 2;
  }

  draw(ctx) {
    const w = Door.W, h = Door.H;

    // Somebody is working this lock — show how far they have got.
    if (this.hackT > 0) {
      const p = this.hackProgress;
      ctx.fillStyle = 'rgba(6,9,16,0.85)';
      ctx.fillRect(this.x - 9, this.y - h / 2 - 9, 18, 4);
      ctx.fillStyle = '#ffd700';
      ctx.fillRect(this.x - 9, this.y - h / 2 - 9, 18 * p, 4);
      ctx.strokeStyle = 'rgba(255,215,0,0.6)'; ctx.lineWidth = 1;
      ctx.strokeRect(this.x - 9.5, this.y - h / 2 - 9.5, 19, 5);
    }

    if (this.isAirlock) {
      // Airlock — same one-second cycle as an interior door, so the
      // outer hatches read as machinery too, not as an instant toggle.
      const ao   = Utils.clamp(this.openness ?? (this.open ? 1 : 0), 0, 1);
      const half = h / 2;
      const leaf = half * (1 - ao);
      const moving = ao > 0 && ao < 1;

      if (ao > 0) {                       // vacuum showing through the gap
        ctx.fillStyle = `rgba(255,60,60,${(0.30 * ao).toFixed(2)})`;
        ctx.fillRect(this.x - w/2 - 3, this.y - half - 3, w + 6, h + 6);
      }
      if (leaf > 0.5) {                   // the hatch leaves themselves
        ctx.fillStyle = this.breached ? '#4a2020' : '#3a2a1a';
        ctx.fillRect(this.x - w/2, this.y - half, w, leaf);
        ctx.fillRect(this.x - w/2, this.y + half - leaf, w, leaf);
      }
      if (ao >= 1) {                      // fully open: hot edges
        ctx.fillStyle = '#ff4455';
        ctx.fillRect(this.x - w/2, this.y - half, w, 6);
        ctx.fillRect(this.x - w/2, this.y + half - 6, w, 6);
      }
      ctx.strokeStyle = this.breached ? '#ff2d44'
                      : moving ? '#ffb020' : (ao >= 1 ? '#ff4455' : '#ff7c20');
      ctx.lineWidth = 1;
      ctx.strokeRect(this.x - w/2, this.y - half, w, h);
      return;
    }

    // Interior door — TWO PANELS that actually slide apart, so a door
    // mid-cycle reads as mid-cycle. Green fully open, red shut, amber
    // while it is moving (and crew are waiting on it).
    const o    = Utils.clamp(this.openness ?? (this.open ? 1 : 0), 0, 1);
    const half = h / 2;
    const panel = half * (1 - o);          // how much each leaf still covers
    const moving = o > 0 && o < 1;
    const col  = o >= 1 ? '#1aff8c' : moving ? '#ffb020' : '#ff5566';

    if (panel > 0.5) {
      ctx.fillStyle = o >= 1 ? '#2a5a3a' : moving ? '#5a4a1a' : '#5a2a2a';
      ctx.fillRect(this.x - w / 2, this.y - half, w, panel);
      ctx.fillRect(this.x - w / 2, this.y + half - panel, w, panel);
    }
    // Frame: doubled and offset when fully open, exactly as before.
    ctx.strokeStyle = col;
    ctx.lineWidth = 1;
    if (o >= 1) {
      ctx.fillStyle = 'rgba(26,255,140,0.25)';
      ctx.fillRect(this.x - w / 2, this.y - half, w, 6);
      ctx.fillRect(this.x - w / 2, this.y + half - 6, w, 6);
      ctx.strokeRect(this.x - w / 2 - 2, this.y - half - 2, w + 4, h + 4);
    } else {
      ctx.strokeRect(this.x - w / 2, this.y - half, w, h);
    }
  }
}

// ── Room ──────────────────────────────────────────────────

class Room {
  constructor(cfg) {
    this.id      = cfg.id;
    this.type    = cfg.type ?? 'empty';   // system type or 'empty'
    this.x       = cfg.x;
    this.y       = cfg.y;
    this.w       = cfg.w ?? 96;
    this.h       = cfg.h ?? 80;
    this.floor   = cfg.floor ?? 0;        // which floor (0=bottom)
    this.cx      = this.x + this.w / 2;
    this.cy      = this.y + this.h / 2;
    this.isVacuum = false;

    // Adjacent room ids (set after all rooms created)
    this.adjacent = cfg.adjacent ?? [];

    // Linked system instance (set by Ship)
    this.system  = null;
  }

  contains(wx, wy) {
    return Utils.pointInRect(wx, wy, this.x, this.y, this.w, this.h);
  }

  /* ── THE CEILING DUCT (update73) ──────────────────────────
   *
   * Every module carries its own duct along the top row of its tiles:
   * oxygen pipes and power runs, wide enough for vermin and the cat and
   * nobody else. It is part of the room rather than a band of its own
   * so that a one-deck hull has one too, and so that the duct NETWORK
   * needs no geometry — it is `adjacent`, which this class has carried
   * since the beginning.
   *
   * Derived, never stored: the module owns its size and the duct is a
   * reading of it. A stored `ventY` would be the same number twice and
   * would go stale the first time a hull moved.
   *
   * The mechanics come later (fire through the grille, air leaving the
   * duct first, rats walking it). What lands now is the SPACE and the
   * fact that the player can see it.
   */
  get ventY()  { return this.y; }
  get ventH()  { return HULL_GRID.VENT_H; }
  /** Where the deck the crew stand on actually begins. */
  get floorTop() { return this.y + HULL_GRID.VENT_H; }
  /** Height of the part anybody walks in. */
  get floorH()   { return this.h - HULL_GRID.VENT_H; }

  /** Repair the system in this room */
  repair(amount, crew) {
    if (this.system) this.system.repair(amount, crew);
  }
}

// ── Ship layouts ──────────────────────────────────────────

/* ============================================================
   THE HULL GRID (update41)

   Every hull in this game is now built from ONE module size. Before
   this there were three — 80x72, 96x80 and 96x60 — with three
   different deck pitches, because each layout hard-coded its own pixel
   coordinates and they drifted apart one hull at a time. That made a
   shared set of art impossible: a floor tile drawn for the scout was
   the wrong size on the frigate and the wrong shape on the station.

   Layouts are declared in GRID COORDINATES now — (col, row) — and the
   pixels are derived. Adding a hull is listing squares; changing the
   module size is changing one number here and every hull, every door,
   every lift stop and every crew station follows.

       MODULE_W x MODULE_H     one compartment
       DECK_PITCH              MODULE_H + DECK_GAP, floor to floor
       SHAFT_W                 a lift trunk sits in the gap BETWEEN two
                               columns, never inside a room
       ENGINE_W / PROW_W       exterior tiles, one per deck, hung off
                               the stern and the bow (see engineSlots
                               and prowSlots). Stations have neither.

   The art kit is cut to these numbers. Do not nudge them for one hull.

   ── EVERYTHING IS A WHOLE NUMBER OF TILES (update73) ──────

   One more rule on top of update41's: every length here is a multiple
   of TILE. That is what lets the art kit be a handful of 10x10 squares
   — a corner, an edge, a floor, a duct — instead of one bespoke
   drawing per hull. Section 247 of the test suite asserts it, so a
   number nudged by a pixel for one screen fails the suite rather than
   quietly making one tile in one hull the wrong size.

   ── THE MODULE LIES DOWN (update73) ───────────────────────

   80x72 was very nearly a square (1.11:1), which read as a cell rather
   than a compartment — and the duct below would only have made it look
   taller. 100x60 is 1.67:1: a room you walk along.

   Measured against the 1280 canvas before it was chosen, because the
   camera never zooms (`Camera.setZoom` is called from nowhere) and so
   both hulls are always drawn 1:1. Two Hapis — the widest pair in the
   game at four columns — come to 1080px and leave 200px between them.
   At 120 wide the same pair left twelve pixels and Hapi would have had
   to lose a column; at 100 no hull has to change at all.

   ── THE DUCT IS THE TOP ROW OF EVERY MODULE (update73) ────

   VENT_H is the ceiling duct: oxygen pipes and power runs, the width
   of one tile, inside the module rather than in a band of its own.
   Three things follow, and they are why it sits here and not in the
   gap between decks:

     · it exists on a ONE-DECK hull, which a band between decks cannot;
     · it needs no geometry of its own — it has the module's;
     · the vent NETWORK is `Room.adjacent`, which this engine has had
       since the beginning. Vermin walk the duct from room to adjacent
       room and no new pathfinding is written.

   DECK_GAP is therefore 0: the duct is the gap now, and a visible one.
   ============================================================ */

const TILE = 10;

const HULL_GRID = {
  TILE,
  MODULE_W: 10 * TILE,   // 100
  MODULE_H:  7 * TILE,   // 70 — INCLUDING the duct along its ceiling
  /* TWO TILES, AND IT WAS MEASURED (update73a). One tile was chosen
     by eye in update73 and the eye was wrong: the sprites were
     rendered in a browser at the size the game draws them and their
     pixels counted, walking, idling and fighting.
         rat     10px  — fits a one-tile duct exactly
         spider  11px  — one over, even standing still
         cat     13px walking, 16 sitting
     The cat is the tall one because it SITS UP, which was a
     deliberate update45 decision so its silhouette could never be
     mistaken for the rat's. That decision does not fit in ten pixels.
     The INTERIOR is unchanged at 50: the module grew, the deck did
     not, so nothing about the crew moves. */
  VENT_H:    2 * TILE,   // the duct: the module's top rows of tiles
  DECK_GAP:  0,          // the duct IS the gap between decks now
  SHAFT_W:   3 * TILE,   // 30
  MARGIN:    1 * TILE,   // hull plate overhang past the outermost room
  /* The exterior tiles came down a tile each with the wider module
     (update73). Two hulls at four columns now come to 1040px of the
     1280 the canvas has, and the twenty pixels this gives back per
     ship are twenty pixels of open space between them — which is
     where the shells fly. They are dressing; the compartments are
     the ship. */
  ENGINE_W:  4 * TILE,   // stern tile, one per deck
  PROW_W:    3 * TILE,   // bow tile, one per deck
  WALK_FRAC: 0.65,       // crew feet, as a fraction of the INTERIOR
};
HULL_GRID.DECK_PITCH = HULL_GRID.MODULE_H + HULL_GRID.DECK_GAP;   // 60

/**
 * How far below a room's TOP the crew's feet stand.
 *
 * ONE DEFINITION, and it has to be (update73). This number lived in
 * two places before: `buildHull` multiplied WALK_FRAC by the whole
 * module to place its lift stops, and `floorWalkY` had a bare 0.65
 * written out beside it. They agreed only because the module had no
 * duct — the moment the ceiling stopped being walkable they would have
 * disagreed by seven pixels, which is a lift that stops just above the
 * floor its passengers are standing on.
 *
 * Measured from the INTERIOR, not the module: the duct is ceiling, and
 * nobody's feet are ever in it.
 */
function walkOffset() {
  return HULL_GRID.VENT_H
       + (HULL_GRID.MODULE_H - HULL_GRID.VENT_H) * HULL_GRID.WALK_FRAC;
}

/** World X of a column, counting the shafts that sit before it. */
function gridColX(originX, col, shaftAfter) {
  const before = shaftAfter.filter(c => c < col).length;
  return originX + col * HULL_GRID.MODULE_W + before * HULL_GRID.SHAFT_W;
}

/** World Y of a deck. Row 0 is the BOTTOM deck, as `floor` always was. */
function gridRowY(originY, row, decks) {
  return originY + (decks - 1 - row) * HULL_GRID.DECK_PITCH;
}

/** World X of the CENTRE of the shaft that follows column `afterCol`. */
function gridShaftX(originX, afterCol, shaftAfter) {
  const before = shaftAfter.filter(c => c < afterCol).length;
  return originX + (afterCol + 1) * HULL_GRID.MODULE_W
       + before * HULL_GRID.SHAFT_W + HULL_GRID.SHAFT_W / 2;
}

/**
 * Expand a compact hull spec into the `rooms` / `elevators` shape the
 * rest of the engine already consumes, so nothing downstream had to
 * change when the grid arrived.
 *
 * Lift stops are DERIVED — every shaft stops on the crew walk line of
 * every deck it passes. They used to be hand-typed per hull, which is
 * how the boss station ended up with a cabin hanging out of the roof.
 */
function buildHull(spec) {
  const { originX, originY, decks, shaftAfter = [], grid = [] } = spec;
  const W = HULL_GRID.MODULE_W, H = HULL_GRID.MODULE_H;

  spec.floors = decks;
  spec.rooms = grid.map(r => ({
    id: r.id, type: r.type ?? 'empty',
    x: gridColX(originX, r.col, shaftAfter),
    y: gridRowY(originY, r.row, decks),
    w: W, h: H,
    floor: r.row,
    adjacent: r.adjacent ?? [],
  }));

  const stops = [];
  for (let row = decks - 1; row >= 0; row--) {
    stops.push(gridRowY(originY, row, decks) + walkOffset());
  }
  spec.elevators = shaftAfter.map((afterCol, i) => ({
    id: 'ev' + i,
    x: gridShaftX(originX, afterCol, shaftAfter),
    floors: stops.slice(),
  }));
  return spec;
}

const SHIP_LAYOUTS = {

  /** FREE STARTER HULL — the same class of boat the ordinary raiders
   *  fly, refitted for you. Two decks, no medbay (field aid only),
   *  smaller reactor. The empty bay is the first real refit decision. */
  scout: buildHull({
    label: 'Bastet',
    spriteKey: 'ship_player',
    hullMax: 22,
    originX: 20, originY: 90, decks: 2, shaftAfter: [0],
    grid: [
      { id:'r_engines',  type:'engines',  col:0, row:0, adjacent:['r_weapons'] },
      { id:'r_weapons',  type:'weapons',  col:1, row:0, adjacent:['r_engines'] },
      { id:'r_piloting', type:'piloting', col:0, row:1, adjacent:['r_oxygen'] },
      { id:'r_oxygen',   type:'oxygen',   col:1, row:1, adjacent:['r_piloting','r_reactor'] },
      { id:'r_reactor',  type:'reactor',  col:2, row:1, adjacent:['r_oxygen','r_hold'] },
      /* SHE IS NOT A RECTANGLE ANY MORE (update73).
       *
       * Six modules, same as ever — but the free bay MOVED from the
       * lower deck's third column to a fourth column on the upper
       * deck, and nothing was put underneath it. A spur on top, a
       * notch below, and the first hull in this game with a profile
       * rather than an outline.
       *
       * Moved, not added, and that matters: the first attempt at this
       * put a NEW bay on the spur and left the old one where it was,
       * which quietly handed the starter ship a second free module —
       * "the empty bay is the first real refit decision" is what the
       * comment above this hull has always said, and two bays is not
       * a decision. Section 43 caught it on the next run. */
      { id:'r_hold',     type:'empty',    col:3, row:1, adjacent:['r_reactor'] },
    ],
    startSystems: ['engines','weapons','piloting','oxygen','reactor'],
    systemLevels: { weapons: 2, engines: 2 },
    startWeapons: ['laser_basic'],
    reactorLevel: 6,
    reactorMax: 12,
    weaponSlots: 1,
    cargoCols: 5, cargoRows: 3,
  }),

  /** Bought hull — Bastet's bigger sister: the same two-deck design
   *  with EIGHT bays instead of six, three of them starting empty. */
  hauler: buildHull({
    label: 'Hapi',
    spriteKey: 'ship_player',
    hullMax: 26,
    originX: 20, originY: 90, decks: 2, shaftAfter: [0],
    grid: [
      { id:'r_engines',  type:'engines',  col:0, row:0, adjacent:['r_weapons'] },
      { id:'r_weapons',  type:'weapons',  col:1, row:0, adjacent:['r_engines','r_hold1'] },
      { id:'r_hold1',    type:'empty',    col:2, row:0, adjacent:['r_weapons','r_hold2'] },
      { id:'r_hold2',    type:'empty',    col:3, row:0, adjacent:['r_hold1'] },
      { id:'r_piloting', type:'piloting', col:0, row:1, adjacent:['r_oxygen'] },
      { id:'r_oxygen',   type:'oxygen',   col:1, row:1, adjacent:['r_piloting','r_reactor'] },
      { id:'r_reactor',  type:'reactor',  col:2, row:1, adjacent:['r_oxygen','r_hold3'] },
      { id:'r_hold3',    type:'empty',    col:3, row:1, adjacent:['r_reactor'] },
    ],
    startSystems: ['engines','weapons','piloting','oxygen','reactor'],
    systemLevels: { weapons: 2, engines: 2 },
    startWeapons: ['laser_basic'],
    reactorLevel: 8,
    reactorMax: 14,
    weaponSlots: 1,
    cargoCols: 7, cargoRows: 5,
  }),

  /** Three decks and two lift trunks. The side bays on the top deck
   *  start EMPTY and become weapon modules at a station. */
  frigate: buildHull({
    label: 'Horus',
    spriteKey: 'ship_player',
    hullMax: 30,
    originX: 20, originY: 90, decks: 3, shaftAfter: [0, 1],
    grid: [
      { id:'r_engines',  type:'engines',  col:0, row:0, adjacent:['r_weapons'] },
      { id:'r_weapons',  type:'weapons',  col:1, row:0, adjacent:['r_engines','r_shields'] },
      { id:'r_shields',  type:'shields',  col:2, row:0, adjacent:['r_weapons'] },
      { id:'r_piloting', type:'piloting', col:0, row:1, adjacent:['r_oxygen'] },
      { id:'r_oxygen',   type:'oxygen',   col:1, row:1, adjacent:['r_piloting','r_medbay'] },
      { id:'r_medbay',   type:'medbay',   col:2, row:1, adjacent:['r_oxygen'] },
      { id:'r_crew1',    type:'empty',    col:0, row:2, adjacent:['r_reactor'] },
      { id:'r_reactor',  type:'reactor',  col:1, row:2, adjacent:['r_crew1','r_crew3'] },
      { id:'r_crew3',    type:'empty',    col:2, row:2, adjacent:['r_reactor'] },
    ],
    startSystems: ['engines','weapons','shields','piloting','oxygen','medbay','reactor'],
    systemLevels: { shields: 2, weapons: 2, engines: 2 },
    startWeapons: ['laser_basic'],
    reactorLevel: 8,
    reactorMax: 16,
    weaponSlots: 1,
    cargoCols: 6, cargoRows: 4,
  }),

  enemy_frigate: buildHull({
    label: 'Set',
    spriteKey: 'ship_enemy',
    hullMax: 20,
    originX: 20, originY: 90, decks: 2, shaftAfter: [0],
    grid: [
      { id:'r_engines',  type:'engines',  col:0, row:0, adjacent:['r_weapons'] },
      { id:'r_weapons',  type:'weapons',  col:1, row:0, adjacent:['r_engines','r_shields'] },
      { id:'r_shields',  type:'shields',  col:2, row:0, adjacent:['r_weapons'] },
      { id:'r_piloting', type:'piloting', col:0, row:1, adjacent:['r_oxygen'] },
      { id:'r_oxygen',   type:'oxygen',   col:1, row:1, adjacent:['r_piloting','r_reactor'] },
      { id:'r_reactor',  type:'reactor',  col:2, row:1, adjacent:['r_oxygen'] },
    ],
    startSystems: ['engines','weapons','shields','piloting','oxygen','reactor'],
    systemLevels: { shields: 2, weapons: 2, engines: 2 },
    startWeapons: ['laser_basic'],
    reactorLevel: 8,
    reactorMax: 12,
    weaponSlots: 1,
  }),

  /** TWO weapon bays — the hull elites favour. */
  enemy_gunship: buildHull({
    label: 'Sobek',
    spriteKey: 'ship_enemy',
    hullMax: 20,
    originX: 20, originY: 90, decks: 2, shaftAfter: [0],
    grid: [
      { id:'r_piloting', type:'piloting', col:0, row:0, adjacent:['r_reactor'] },
      { id:'r_reactor',  type:'reactor',  col:1, row:0, adjacent:['r_piloting','r_engines'] },
      { id:'r_engines',  type:'engines',  col:2, row:0, adjacent:['r_reactor'] },
      { id:'r_weapons',  type:'weapons',  col:0, row:1, adjacent:['r_weapons2'] },
      { id:'r_weapons2', type:'weapons',  col:1, row:1, adjacent:['r_weapons','r_oxygen'] },
      { id:'r_oxygen',   type:'oxygen',   col:2, row:1, adjacent:['r_weapons2','r_shields'] },
      { id:'r_shields',  type:'shields',  col:3, row:1, adjacent:['r_oxygen'] },
    ],
    startSystems: ['engines','weapons','shields','piloting','oxygen','reactor'],
    systemLevels: { shields: 2, weapons: 2, engines: 2 },
    startWeapons: ['laser_basic'],
    reactorLevel: 8,
    reactorMax: 14,
    weaponSlots: 2,
  }),

  enemy_raider: buildHull({
    label: 'Anubis',
    spriteKey: 'ship_enemy',
    hullMax: 20,
    originX: 20, originY: 90, decks: 2, shaftAfter: [0],
    grid: [
      { id:'r_weapons',  type:'weapons',  col:0, row:0, adjacent:['r_reactor'] },
      { id:'r_reactor',  type:'reactor',  col:1, row:0, adjacent:['r_weapons','r_engines'] },
      { id:'r_engines',  type:'engines',  col:2, row:0, adjacent:['r_reactor'] },
      { id:'r_shields',  type:'shields',  col:0, row:1, adjacent:['r_piloting'] },
      { id:'r_piloting', type:'piloting', col:1, row:1, adjacent:['r_shields','r_oxygen'] },
      { id:'r_oxygen',   type:'oxygen',   col:2, row:1, adjacent:['r_piloting'] },
    ],
    startSystems: ['engines','weapons','shields','piloting','oxygen','reactor'],
    systemLevels: { shields: 2, weapons: 2, engines: 2 },
    startWeapons: ['laser_basic'],
    reactorLevel: 8,
    reactorMax: 12,
    weaponSlots: 1,
  }),

  /** APOPHIS — a STATION, not a ship: no engines hung off the stern,
   *  no bow. Five decks of two bays, ten compartments, one trunk up
   *  the middle. It used to be six decks of 96x60 compartments, which
   *  was the only reason a third module size existed at all. */
  boss_station: buildHull({
    label: 'Apophis',
    spriteKey: 'ship_enemy',
    hullMax: 40,
    isStation: true,
    originX: 40, originY: 20, decks: 5, shaftAfter: [0],
    grid: [
      { id:'r_engines',  type:'engines',  col:0, row:0, adjacent:['r_medbay'] },
      { id:'r_medbay',   type:'medbay',   col:1, row:0, adjacent:['r_engines'] },
      { id:'r_reactor',  type:'reactor',  col:0, row:1, adjacent:['r_oxygen'] },
      { id:'r_oxygen',   type:'oxygen',   col:1, row:1, adjacent:['r_reactor'] },
      { id:'r_weapons3', type:'weapons',  col:0, row:2, adjacent:['r_shields'] },
      { id:'r_shields',  type:'shields',  col:1, row:2, adjacent:['r_weapons3'] },
      { id:'r_weapons',  type:'weapons',  col:0, row:3, adjacent:['r_weapons2'] },
      { id:'r_weapons2', type:'weapons',  col:1, row:3, adjacent:['r_weapons'] },
      { id:'r_piloting', type:'piloting', col:0, row:4, adjacent:['r_top'] },
      { id:'r_top',      type:'empty',    col:1, row:4, adjacent:['r_piloting'] },
    ],
    startSystems: ['engines','medbay','reactor','oxygen','weapons','shields','piloting'],
    systemLevels: { shields: 4, engines: 3, piloting: 2, oxygen: 2, medbay: 2, weapons: 2 },
    startWeapons: [],
    reactorLevel: 8,
    reactorMax: 20,
    weaponSlots: 3,
  }),
};

class Ship {
  /**
   * How far ABOVE the floor's walk line the console operator stands.
   *
   * Enough to read as "at the console" and — the part that matters for
   * input — to keep him off the exact middle of the room, so the floor
   * underneath him stays free for module orders. Clicking a crewman
   * always selects that crewman (that is the gesture players reach for
   * most), so ordering crew INTO a manned module means clicking the
   * part of it nobody is standing on. Sitting him high leaves most of
   * the room to click.
   */
  static get OPERATOR_LIFT() { return 14; }

  /**
   * @param {string}  layoutKey  - key into SHIP_LAYOUTS
   * @param {boolean} isPlayer
   * @param {number}  worldX     - ship world X origin
   * @param {number}  worldY     - ship world Y origin
   */
  constructor(layoutKey, isPlayer = true, worldX = 0, worldY = 0) {
    this.layoutKey = layoutKey;
    this.layout    = SHIP_LAYOUTS[layoutKey];
    if (!this.layout) throw new Error(`Unknown ship layout: ${layoutKey}`);

    this.isPlayer = isPlayer;
    this.worldX   = worldX;
    this.worldY   = worldY;

    this.label    = this.layout.label;
    this.hull     = this.layout.hullMax;
    this.hullMax  = this.layout.hullMax;

    // ── Build rooms ──────────────────────────────────────
    this.rooms = this.layout.rooms.map(cfg => new Room({
      ...cfg,
      x: worldX + cfg.x,
      y: worldY + cfg.y,
    }));

    // ── Build systems — ONE per system-type room ──────────
    // Multiple rooms of the same type (e.g. two 'weapons' modules)
    // each get their OWN independent system instance.
    this.systems = [];
    this.reactor  = new Reactor(this.layout.reactorLevel,
                                this.layout.reactorMax ?? 16);

    this.rooms.forEach(room => {
      if (room.type === 'empty' || !SYSTEM_DEFS[room.type]) return;
      const lvl = room.type === 'reactor'
        ? this.reactor.capacity
        : (this.layout.systemLevels ?? {})[room.type] ?? 1;
      const sys = new ShipSystem(room.type, lvl);
      this.systems.push(sys);

      // Link to room
      room.system = sys;
      this._fitSystemToRoom(sys, room);
    });

    // Link the reactor budget object to its room system —
    // from now on damage to the reactor ROOM = lost power.
    this.reactor.sys = this.getSystem('reactor');

    // Default power allocation
    this._allocateDefaultPower();

    /* ── Weapon mounts — ONE gun per weapon module room ────
     *
     * `weaponCargo` DELETED (update75). It was a bare list of gun keys
     * that weighed nothing, took no space and was drawn nowhere the
     * player could point at — a second warehouse standing beside the
     * grid hold, which already holds boxed guns as ordinary crates.
     *
     * Two lists for one thing drift, and this pair drifted in public:
     * a gun handed over by a surrendering crew went onto the rack and
     * the player never saw it; the station had to push a gun onto the
     * rack, box it, and then splice it back OFF the rack, three lines
     * of reconciliation for one move; and the shop drew the same gun
     * twice, once per list, with buttons to shuffle it between them.
     *
     * There is now exactly one answer to "where is that gun": BOLTED
     * ON, or IN A CRATE IN THE HOLD. */
    this.weapons     = [];

    /* ── The brig's cells. NOT crew, deliberately — see takePrisoner. */
    this.prisoners   = [];

    // ── Cargo hold ──────────────────────────────────────
    // A grid, not a list: salvage has a shape, so hull choice and hold
    // upgrades finally mean something. Sized by the layout. (cargo.js
    // may be absent in a stripped-down test — degrade, do not explode.)
    this.cargo = (typeof CargoGrid !== 'undefined')
      ? new CargoGrid(this.layout.cargoCols ?? 5, this.layout.cargoRows ?? 4)
      : null;

    // Slots = number of weapon MODULE rooms (boss may override upward)
    this.weaponSlots = Math.max(this.weaponRooms.length,
                                this.layout.weaponSlots ?? 0);
    this.layout.startWeapons.forEach((wk, i) => {
      this.installWeapon(wk, i);
    });

    // ── Crew ────────────────────────────────────────────
    this.crew = [];

    // ── Subsystems ──────────────────────────────────────
    this.oxygen   = new OxygenManager();
    this.rooms.forEach(r => this.oxygen.addRoom(r.id));

    this.fires    = new FireManager();
    this.breaches = new BreachManager();
    // Expose breaches list directly for compatibility
    Object.defineProperty(this, 'breachesList', {
      get: () => this.breaches.breaches
    });

    // ── Elevators ────────────────────────────────────────
    this.elevators = new ElevatorManager();
    (this.layout.elevators ?? []).forEach(ev => {
      this.elevators.addShaft(ev.id, worldX + ev.x,
        ev.floors.map(fy => worldY + fy));
    });

    // Shafts are air columns: give each one an oxygen cell so open
    // shaft doors equalise O2 between the rooms on either side
    // (replaces the old direct doors that used to cross the shaft).
    this.elevators.shafts.forEach(s => this.oxygen.addRoom(`shaft_${s.id}`));

    // ── Doors between horizontally adjacent rooms ───────
    // If an elevator shaft sits in the gap between two rooms, they get
    // NO direct door — passage/airflow goes through the shaft's own
    // doors instead (a shaft and a room never share space).
    this.doors = [];
    const donePairs = new Set();
    this.rooms.forEach(room => {
      room.adjacent.forEach(adjId => {
        const other = this.getRoomById(adjId);
        if (!other || other.floor !== room.floor) return;
        const key = [room.id, other.id].sort().join('|');
        if (donePairs.has(key)) return;
        donePairs.add(key);
        if (this._shaftBetween(room, other)) return;   // shaft occupies the gap
        // Door at shared vertical edge, hung on the floor's door line
        const doorX = room.x < other.x ? room.x + room.w : other.x + other.w;
        const doorY = this.floorDoorY(room.floor, room.y + room.h * 0.5);
        // Only if rooms actually touch horizontally
        if (Math.abs((room.x + room.w) - other.x) < 30 ||
            Math.abs((other.x + other.w) - room.x) < 30) {
          this.doors.push(new Door(room.id, other.id, doorX, doorY));
        }
      });
    });

    // Elevator shaft doors — each shaft gets a door on BOTH sides
    // at every floor it serves (shaft is its own vertical module)
    this.elevators.shafts.forEach(shaft => {
      // Hand the shaft the line its doors sit on, so the landing plates
      // and the cabin are drawn level with them instead of a dozen
      // pixels lower on the crew walk line. Presentation only.
      shaft.setDoorYs?.(shaft.floorYs.map(fy =>
        this.floorDoorY(this.floorAtY(fy), fy)));
      // …and how far the hull runs, so the trunk spans the ship exactly
      // rather than by a constant tuned for one deck height.
      shaft.setExtent?.(Math.min(...this.rooms.map(r => r.y)),
                        Math.max(...this.rooms.map(r => r.y + r.h)));
      shaft.floorYs.forEach(fy => {
        // Find rooms adjacent to shaft on this floor (left and right)
        const floorIdx = this.floorAtY(fy);
        const onFloor  = this.rooms.filter(r => r.floor === floorIdx);
        const shaftDoorY = this.floorDoorY(floorIdx, fy);
        onFloor.forEach(room => {
          const touchesLeft  = Math.abs((room.x + room.w) - (shaft.x - shaft.width/2)) < 26;
          const touchesRight = Math.abs(room.x - (shaft.x + shaft.width/2)) < 26;
          if (touchesLeft) {
            this.doors.push(new Door(room.id, `shaft_${shaft.id}`,
              shaft.x - shaft.width/2, shaftDoorY, false));
          }
          if (touchesRight) {
            this.doors.push(new Door(room.id, `shaft_${shaft.id}`,
              shaft.x + shaft.width/2, shaftDoorY, false));
          }
        });
      });
    });

    // Airlocks — one on the outer wall of the leftmost and rightmost
    // room of each floor (FTL-style venting hatches)
    const floors = [...new Set(this.rooms.map(r => r.floor))];
    floors.forEach(f => {
      const onFloor = this.rooms.filter(r => r.floor === f);
      if (!onFloor.length) return;
      const leftmost  = onFloor.reduce((a, r) => r.x < a.x ? r : a);
      const rightmost = onFloor.reduce((a, r) => r.x + r.w > a.x + a.w ? r : a);
      const airY = this.floorDoorY(f, leftmost.y + leftmost.h * 0.5);
      this.doors.push(new Door(leftmost.id,  null, leftmost.x,               airY, true));
      if (rightmost.id !== leftmost.id) {
        this.doors.push(new Door(rightmost.id, null, rightmost.x + rightmost.w, airY, true));
      }
    });

    // ── In-flight projectiles ───────────────────────────
    this.projectiles = [];

    // ── Visual body = room bounding box ──────────────────
    const _b = this.roomBounds();
    this.spriteW = _b.w + 28;
    this.spriteH = _b.h + 28;

    // Shield visual
    this._shieldPulse = null;
    this._shieldAlpha = 0;

    // Destruction
    this.destroyed    = false;
    this._deathTimer  = 0;
    this._explosionTimer = new Utils.Interval(0.18);
  }

  // ── Accessors ────────────────────────────────────────────

  getSystem(type) { return this.systems.find(s => s.type === type) || null; }
  getRoomById(id) { return this.rooms.find(r => r.id === id) || null; }

  getAdjacentRooms(roomId) {
    const room = this.getRoomById(roomId);
    if (!room) return [];
    return room.adjacent.map(id => this.getRoomById(id)).filter(Boolean);
  }

  /** Elevator shaft standing in the horizontal gap between two rooms, or null */
  _shaftBetween(a, b) {
    if (!this.elevators) return null;
    const left  = a.x < b.x ? a : b;
    const right = a.x < b.x ? b : a;
    return this.elevators.shafts.find(s =>
      s.x >= left.x + left.w && s.x <= right.x) || null;
  }

  /** Both shaft-side doors open at the given room pair's floor? */
  _shaftChannelOpen(shaft, roomA, roomB) {
    const sid  = `shaft_${shaft.id}`;
    const near = (d, room) =>
      d.roomB === sid && d.roomA === room.id &&
      d.y > room.y - 6 && d.y < room.y + room.h + 6;
    const dA = this.doors.find(d => near(d, roomA));
    const dB = this.doors.find(d => near(d, roomB));
    return !!(dA && dB && dA.open && dB.open);
  }

  /**
   * Every same-floor neighbour, each tagged with whether the way in is
   * actually OPEN. Fire uses this (update42).
   *
   * `getOpenAdjacentRooms` below is the strict version and had exactly
   * zero callers: fire.js spread through walls unconditionally, so
   * shutting a door did nothing at all and the doors were decoration in
   * a fire. Heat DOES cross a shut bulkhead — just far more slowly —
   * so fire needs the whole list plus the state of each way through,
   * not a pre-filtered one.
   */
  adjacentThermal(roomId) {
    const room = this.getRoomById(roomId);
    if (!room) return [];
    const openIds = new Set(this.getOpenAdjacentRooms(roomId).map(r => r.id));
    return (room.adjacent ?? [])
      .map(id => this.getRoomById(id))
      .filter(r => r && r.floor === room.floor)
      .map(r => ({ room: r, open: openIds.has(r.id) }));
  }

  /** Adjacent rooms reachable through OPEN doors (fire spread uses this) */
  getOpenAdjacentRooms(roomId) {
    const room = this.getRoomById(roomId);
    if (!room) return [];
    return room.adjacent
      .map(id => this.getRoomById(id))
      .filter(r => {
        if (!r) return false;
        // Different floor — no door, fire cannot spread vertically
        if (r.floor !== room.floor) return false;
        const door = this.doors.find(d =>
          (d.roomA === roomId && d.roomB === r.id) ||
          (d.roomB === roomId && d.roomA === r.id));
        if (door) return door.open;
        // Rooms separated by an elevator shaft: fire crosses only
        // when BOTH shaft doors on this floor are open.
        const shaft = this._shaftBetween(room, r);
        if (shaft) return this._shaftChannelOpen(shaft, room, r);
        return true;  // genuinely touching, no door = open corridor
      });
  }

  /** Which floor index is at world Y? Returns -1 if outside */
  floorAtY(wy) {
    let best = -1, bestDist = Infinity;
    this.rooms.forEach(r => {
      if (wy >= r.y - 10 && wy <= r.y + r.h + 10) {
        const d = Math.abs(r.cy - wy);
        if (d < bestDist) { bestDist = d; best = r.floor; }
      }
    });
    return best;
  }

  /** Canonical door centre-line for a floor.
   *  EVERY hatch on a floor — interior, elevator and airlock — hangs
   *  here. Each door used to take the centre of whichever room spawned
   *  it, so rooms of different heights pushed their doors to different
   *  levels and the outer airlocks sat visibly off from the interior
   *  doors on every hull in the game. */
  floorDoorY(floorIndex, fallbackY = 0) {
    const roomsOnFloor = this.rooms.filter(r => r.floor === floorIndex);
    if (!roomsOnFloor.length) return fallbackY;
    /* The middle of the DOORWAY, which is the middle of the walkable
       compartment and not of the module (update73) — a hatch does not
       run up into the ceiling duct any more than a man does. Still
       deliberately a different line from `floorWalkY`: movement goes
       by the feet, doors and the lift cabin are drawn by this one,
       and confusing the two is the "empty trunk lower than the doors"
       bug from update34. */
    const top = Math.min(...roomsOnFloor.map(r => r.floorTop));
    const bot = Math.max(...roomsOnFloor.map(r => r.y + r.h));
    return (top + bot) / 2;
  }

  /* ── WHERE A MODULE SITS IN ITS ROOM (update73) ───────────
   *
   * Three copies of these six lines stood in this file — the hull
   * builder and both of the refit paths. Once the duct arrived all
   * three needed the same correction, which is three chances to
   * correct two of them. One method now.
   *
   * A system occupies the room's INTERIOR. The duct along the ceiling
   * is not part of the compartment, and the first screenshot of this
   * package showed exactly why it matters: the module badge was drawn
   * at `room.y + 3`, which is now inside the grille, so O₂ read as a
   * letter hidden behind a vent.
   */
  _fitSystemToRoom(sys, room) {
    sys.roomId = room.id;
    sys.roomX  = room.x;
    sys.roomY  = room.floorTop;
    sys.roomW  = room.w;
    sys.roomH  = room.floorH;
    sys.cx     = room.cx;
    sys.cy     = room.floorTop + room.floorH / 2;
  }

  /** Walking Y line for a floor (crew feet level).
   *
   *  Reads `walkOffset()` — the SAME function the lift stops are built
   *  from. It used to carry its own `0.65` written out longhand, which
   *  was the second copy of a number the grid already owned. */
  floorWalkY(floorIndex, fallbackY = 0) {
    const roomsOnFloor = this.rooms.filter(r => r.floor === floorIndex);
    if (!roomsOnFloor.length) return fallbackY;
    return roomsOnFloor[0].y + walkOffset();
  }

  get shieldBars() {
    const ss = this.getSystem('shields');
    return ss ? ss.shieldBars : 0;
  }

  get shieldMax() {
    const ss = this.getSystem('shields');
    return ss ? ss.shieldMax : 0;
  }

  get evasion() {
    const pilot = this.getSystem('piloting');
    const eng   = this.getSystem('engines');

    // FTL rule: no pilot in cockpit = no evasion at all. `alive` is the
    // one liveness test used throughout here — the old code mixed
    // `!dead && !dying` for the gate with a bare `!dead` for the bonus,
    // so a crewman bleeding out on the cockpit floor still flew the ship.
    const pilotRoom = pilot ? this.getRoomById(pilot.roomId) : null;
    // crewOperating: our own pilot, and only while nobody is fighting
    // him for the chair.
    const hasPilot = pilotRoom ? this.crewOperating(pilotRoom.id).length > 0 : false;
    if (!hasPilot) return 0;

    const pilotPct = pilot ? pilot.effectivePower() * 0.03 : 0;   // 3%/level
    const engPct   = eng   ? eng.effectivePower()   * 0.02 : 0;   // 2%/level
    const cloak    = this.getSystem('cloaking');
    // Cloak now gives a big evasion spike ONLY while actively cloaked.
    const cloakPct = (cloak && cloak.cloakActive) ? 0.60 : 0;

    // ── Crew skill bonuses ──
    // The pilots at the helm, AND the engine gang keeping the drive
    // responsive. Engine crew have always EARNED engines XP on every
    // dodge (see receiveHit) and CrewMember.engineBonus() has always
    // existed — but nothing ever called it, so levelling Engines paid
    // out exactly nothing in evasion. Terra crews even get double
    // engines XP, which made the dead end worse. The loop is closed now.
    // ONE pilot at the helm, ONE engineer at the drive console
    // (update43) — a crowded cockpit no longer stacks evasion.
    const helm     = this.consoleOperator(pilotRoom.id);
    const skillPct = helm ? helm.pilotBonus() : 0;
    const engRoom  = eng ? this.getRoomById(eng.roomId) : null;
    const engHand  = engRoom ? this.consoleOperator(engRoom.id) : null;
    const engSkill = engHand ? engHand.engineBonus() : 0;

    /* A COMMANDER'S ORDER, while it is running (update53). It goes
       through Commander.orderBonus like every other "what is the boss
       worth right now" question, and it is INSIDE the same clamp as
       everything else — an order that could push evasion past the cap
       would be a different rule for one source, which is how caps stop
       meaning anything. Only OUR hull: the accessor answers for the
       active commander, and the enemy has his own. */
    const order = (this.isPlayer && typeof Commander !== 'undefined'
                   && Commander.orderBonus) ? Commander.orderBonus('evasion') : 0;

    const cap = (cloak && cloak.cloakActive) ? 0.9 : 0.75;
    return Utils.clamp(pilotPct + engPct + cloakPct + skillPct + engSkill + order,
                       0, cap);
  }

  get hullPct() { return this.hull / this.hullMax; }

  // ── Crew helpers ─────────────────────────────────────────

  addCrew(member, keepPosition = false) {
    // Never add the same member twice (boarding recovery could
    // otherwise duplicate crew on the roster).
    if (this.crew.includes(member)) return;
    if (keepPosition) {
      // Caller already placed x/y/roomId precisely (e.g. a boarder
      // storming into the room they just breached) — don't scramble it.
      member.targetX = member.x;
      member.targetY = member.y;
      this.crew.push(member);
      return;
    }
    // Place each crew member in a different room (cycle through rooms)
    const idx  = this.crew.length % this.rooms.length;
    const room = this.rooms[idx] || this.rooms[0];
    if (room) {
      const [sx, sy] = this.stationSpot(room);
      member.x = sx;
      member.y = sy;
      member.roomId = room.id;
      // A recruit with no station never settles anywhere and reads as
      // "broken" to the player — give them the room they walked into.
      if (!member.homeRoomId) member.homeRoomId = room.id;
    } else {
      member.x = this.worldX + 100;
      member.y = this.worldY + 100;
    }
    member.targetX = member.x;
    member.targetY = member.y;
    this.crew.push(member);
  }

  /**
   * Assign home stations by priority:
   * cockpit → engines → shields → weapons → oxygen → medbay.
   * Prefers crew whose corporation matches the module.
   */
  assignStations() {
    // Weapons need a live OPERATOR per module now — stations cover
    // piloting first, then EVERY weapon room, then the rest.
    const prefer = { piloting:'pegasus', engines:'terra', shields:'aquarius', weapons:'phoenix' };
    // Animals do not stand watches. (isBeast = spider or rat.)
    const unassigned = this.crew.filter(c => !c.dead && !c.isBeast);
    const posts = [];
    const pilot = this.getSystem('piloting');
    if (pilot?.roomId) posts.push({ type:'piloting', roomId: pilot.roomId });
    this.weaponRooms.forEach(r => posts.push({ type:'weapons', roomId: r.id }));
    ['shields','engines','oxygen','medbay'].forEach(t => {
      const sys = this.getSystem(t);
      if (sys?.roomId) posts.push({ type: t, roomId: sys.roomId });
    });

    /* WHO GETS THE CONSOLE (update43).
       Since only the operator at slot 0 supplies the module's bonus,
       picking by CORPORATION alone would sit a Phoenix rookie at the
       gun while a mastered Aquarius gunner stood behind him doing
       nothing. Rank by the skill the post actually uses, and keep the
       corporation preference as the tiebreak it was always meant to
       be — a Terra crew still gravitates to the engine room. */
    const POST_SKILL = { piloting: 'piloting', engines: 'engines',
                         shields: 'shields',   weapons: 'weapons' };
    posts.forEach(post => {
      if (!unassigned.length) return;
      const skill = POST_SKILL[post.type];
      let idx = 0, bestScore = -1;
      unassigned.forEach((cand, i) => {
        const lvl   = skill ? cand.getSkillLevel(skill) : 0;
        const score = lvl * 10 + (cand.race === prefer[post.type] ? 1 : 0);
        if (score > bestScore) { bestScore = score; idx = i; }
      });
      const c = unassigned.splice(idx, 1)[0];
      const room = this.getRoomById(post.roomId);
      // Ask which SPOT is free, not how many heads are in there. The
      // head count once handed the first man into an empty module the
      // LEFT flank (because setting homeRoomId first counted him as an
      // occupant of his own room) and left the console unmanned.
      c.homeRoomId = post.roomId;
      if (room) c.moveToOnShip(this, ...this.stationSpot(room, null, c));
    });
  }

  /**
   * Where a crew member should STAND in a room.
   *
   *      empty room   →  the console, dead centre and a little high
   *      one already  →  the newcomer takes the LEFT of him
   *      two already  →  the third takes the RIGHT
   *
   * That order matters: walking into an empty module and standing off
   * to one side of the console looked like the man had missed his post,
   * which is why hitting RETURN (which sends everyone to room.cx/cy)
   * always "looked right" and ordinary orders did not.
   *
   * The old comment here warned that a crewman on the exact centre
   * swallowed every click aimed at the module. That was true when the
   * pick radius was 20px around a point 14px above his head; the
   * operator now stands OPERATOR_LIFT pixels above the walk line, up at
   * the console, which leaves the whole lower half of the room clear
   * for module clicks.
   */
  stationSpot(room, forCrew = null) {
    /* THE HEAD-COUNT BRANCH IS GONE (update79). This used to take an
       `occupants` number and answer `min(occupants, 2)` — a second way
       of picking a spot, by counting people instead of asking which
       spots are held. Nothing had called it with a number for many
       packages; both callers passed null and fell through to the line
       below. An unreachable second answer to a question that already
       has one is worse than no code, because the next person to read
       it believes there are two ways to place a man. */
    return this.stationSlot(
      room, this.freeStationSlot(room, forCrew ? [forCrew] : [],
                                 forCrew ? forCrew.isPlayer : this.isPlayer));
  }

  /**
   * HOW MANY PEOPLE FIT IN A MODULE, and it is per SIDE (update79).
   *
   * There used to be two answers to this and they disagreed. At home
   * the count filtered on `alive` alone, so two boarders standing in
   * your medbay meant you could send ONE medic — the intruders ate
   * your places. On the enemy hull the very same rule filtered on
   * `isPlayer`, so three of yours could walk into a room that already
   * held four defenders. Two rules, written out by hand at two click
   * sites, and the player met both of them in one fight.
   *
   * One rule now, and it is the player's: THREE A SIDE. A module holds
   * three of yours and three of theirs — six men in a brawl — and
   * neither side can lock the other out by standing there.
   *
   * Downed bodies do not count. A room with three wounded on its floor
   * used to read as full and silently refused every repair order, which
   * is how a breached, shot-out module could look unfixable.
   */
  roomSpaceFor(roomId, side, exclude = []) {
    const here = this.crew.filter(c =>
      c && c.alive && c.isPlayer === side && !exclude.includes(c) &&
      (c.roomId === roomId || c.homeRoomId === roomId)).length;
    return Math.max(0, Ship.ROOM_SLOTS - here);
  }

  /** Standing spots per side in one module. The one number. */
  static get ROOM_SLOTS() { return 3; }

  /** The i-th standing spot in a room: 0 = console, 1 = left, 2 = right. */
  stationSlot(room, i = 0) {
    const slot = [0, -1, 1][Utils.clamp(i, 0, Ship.ROOM_SLOTS - 1)];
    const x = Utils.clamp(room.cx + slot * 26, room.x + 14, room.x + room.w - 14);
    const y = this.floorWalkY(room.floor, room.cy)
            - (slot === 0 ? Ship.OPERATOR_LIFT : 0);
    return [x, y];
  }

  /** How close to a slot counts as standing on it. */
  static get SLOT_GRIP() { return 13; }

  /**
   * Which of the three standing spots in `room` is a crewman on (or
   * heading for)? -1 if he is somewhere else in the room entirely.
   */
  slotIndexAt(x, y, room, tol = Ship.SLOT_GRIP) {
    let best = -1, bd = tol;
    for (let i = 0; i < Ship.ROOM_SLOTS; i++) {
      const [sx, sy] = this.stationSlot(room, i);
      const d = Math.hypot(x - sx, y - sy);
      if (d < bd) { bd = d; best = i; }
    }
    return best;
  }

  /**
   * The set of spots in `room` that are spoken for.
   *
   * "Spoken for" means somebody is standing on it OR walking to it —
   * see CrewMember.destPoint. Counting heads instead of spots is what
   * used to stack crew: the count said "one man in here, you take slot
   * 1", but that man might himself be standing on slot 1 because the
   * room was busier when HE was sent.
   *
   * @param {Room} room
   * @param {CrewMember[]} exclude  people whose claim does not count
   * @param {boolean} residentsOnly  count only crew POSTED to this room —
   *        used to decide whether a stack is real. Somebody merely
   *        crossing the room stands in the way (so you do not walk into
   *        him) but he never owns the console and never evicts anyone.
   */
  takenStationSlots(room, exclude = [], residentsOnly = false,
                    side = this.isPlayer) {
    const taken = new Set();
    if (!room) return taken;
    this.crew.forEach(c => {
      if (!c.alive || c.isBeast || exclude.includes(c)) return;
      /* A MAN COMPETES FOR SPOTS ONLY WITH HIS OWN SIDE (update79).
         This had no side filter at all, so an intruder standing on the
         console HELD slot 0 against your own crew — your gunner was
         shoved onto the flank of his own bay by the man who came to
         kill him. Now that six can share a module the filter is not
         cosmetic: without it the two sides would have three places
         between them and the loser of the race would stand nowhere. */
      if (c.isPlayer !== side) return;
      if (residentsOnly && c.homeRoomId !== room.id) return;
      // Only people who belong in, or are inside, this room can hold a
      // spot in it — somebody in another room is irrelevant.
      if (c.roomId !== room.id && c.homeRoomId !== room.id) return;
      const p = c.destPoint ? c.destPoint() : { x: c.x, y: c.y };
      const i = this.slotIndexAt(p.x, p.y, room);
      if (i !== -1) taken.add(i);
    });
    return taken;
  }

  /**
   * The best FREE spot in `room`: the console first, then the left
   * flank, then the right. Falls back to the right flank when all
   * three are held (the room is full and the caller should have
   * stopped earlier).
   */
  freeStationSlot(room, exclude = [], side = this.isPlayer) {
    const taken = this.takenStationSlots(room, exclude, false, side);
    for (let i = 0; i < Ship.ROOM_SLOTS; i++) if (!taken.has(i)) return i;
    return Ship.ROOM_SLOTS - 1;
  }

  /**
   * Hand out one free spot per crew member, in order.
   *
   * This is the ONLY correct way to place several people into the same
   * module at once: each pick has to see the picks made before it, or
   * the whole group lands on the console together.
   *
   * @returns {number[]} slot index per member of `movers`
   */
  allocStationSlots(room, movers = []) {
    /* A group order is always one side's, so the side is read off the
       men being moved rather than passed in as a fourth argument
       nobody would remember to give. */
    const side = movers.length ? movers[0].isPlayer : this.isPlayer;
    const taken = this.takenStationSlots(room, movers, false, side);
    return movers.map(() => {
      let i = 0;
      while (i < Ship.ROOM_SLOTS - 1 && taken.has(i)) i++;
      taken.add(i);
      return i;
    });
  }

  /**
   * OUR crew, able, in this room.
   *
   * The `isPlayer === this.isPlayer` filter is the important half and it
   * was missing entirely. `this.crew` holds everyone physically aboard —
   * including enemy boarders, who are added to the DEFENDING ship's
   * roster when they come through the airlock. Without the filter an
   * intruder standing in your weapons bay MANNED YOUR GUN, one in the
   * shield room sped up YOUR recharge and earned YOUR shields XP, one in
   * the medbay was healed by YOUR doctors, and one in the cockpit added
   * his piloting skill to YOUR evasion.
   */
  crewInRoom(roomId) {
    // Only fully-able crew count for manning/repairs — the downed
    // and the dead lie on the floor (see bodiesInRoom).
    return this.crew.filter(c =>
      c.roomId === roomId && c.alive && c.inRoom !== false &&
      c.isPlayer === this.isPlayer);
  }

  /**
   * A battle is beginning aboard this hull.
   *
   * Done HERE rather than in markCombatStart because CombatManager.begin
   * is the one place every fight passes through exactly once, for both
   * ships — game.js calls markCombatStart from three different places
   * and would have counted some battles twice.
   */
  onBattleStart() {
    // Every lock is a stranger's lock again: boarders work for the ship
    // a second time rather than strolling through last fight's holes.
    this.doors.forEach(d => d.resetHacks?.());
    // And everyone still standing has one more action on their record.
    this.crew.forEach(c => { if (c.alive) c.battles = (c.battles ?? 0) + 1; });
  }

  /** EVERYONE physically in the room, whoever's side they are on.
   *  Weapons fire, stun and fire burns do not care whose uniform you
   *  are wearing — only manning does. */
  occupantsOf(roomId) {
    return this.crew.filter(c => c.roomId === roomId && c.alive && c.inRoom !== false);
  }

  /** Hostiles from both sides sharing a room: nobody is working. */
  roomContested(roomId) {
    const here = this.occupantsOf(roomId);
    return here.some(c => c.isPlayer) && here.some(c => !c.isPlayer);
  }

  /**
   * Who is actually OPERATING the module in this room.
   *
   * A module with a fight going on in it is not being run: the crew are
   * swinging at each other, not flying the ship. A contested cockpit
   * gives no evasion, a contested weapons bay stops charging, contested
   * shields stop recharging — which is what makes boarding a way to shut
   * a ship down rather than only a way to chip at its hull.
   */
  /**
   * THE PEOPLE WORKING THIS MODULE.
   *
   * Empty for a CONTESTED room, and — since update45 — never an
   * animal. `isBeast` has always been the "this is not a person"
   * filter for manning, carrying and firefighting, but a rat is enemy
   * crew and so was excluded by the side check anyway. A cat is OURS,
   * which made it the first beast that could ever have reached this
   * list — and a cat that mans the gun is not a joke the player would
   * enjoy twice.
   */
  crewOperating(roomId) {
    if (this.roomContested(roomId)) return [];
    /* AND NOT A MAN WHOSE HANDS ARE FULL (update78). The busy clock
       is new and for one package nothing read it: a gunner could eat
       a ration and still be the gunner, a medic could be kneeling
       over a casualty and still be piloting. Standing in the room was
       the whole test, so "busy" was a word in the panel and nothing
       in the fight.
       This is the one place that answers "who is WORKING here", so it
       is the one place that has to know. The cost falls out of it
       everywhere at once — the gun goes quiet, the cyborg's +1 drops,
       the console mark leaves his row — because all three ask this. */
    return this.crewInRoom(roomId).filter(c => !c.isBeast && !c.busy);
  }

  /**
   * WHO A POWERED MEDBAY TREATS (update54).
   *
   * Not `crewOperating` — that answers "who is WORKING here", and it
   * throws out the animals so the cat cannot man a gun. A medbay is
   * not a console: lying on the table is not a job, and the ship's cat
   * bleeds like everybody else. It used to be the only creature aboard
   * that could not be patched up anywhere, on the ship or at a station.
   *
   * The contested check stays, and it is the same one: a compartment
   * being fought over is not treating anybody. That is the ship-side
   * half of "the fight comes first, the bandages come after".
   *
   * Side is already settled by `crewInRoom`, so enemy boarders standing
   * in your medbay are not healed by it — and vermin, being nobody's
   * crew, are not either.
   */
  medbayPatients(roomId) {
    if (this.roomContested(roomId)) return [];
    /* ABLE AND DOWN ALIKE (update78). This returned `crewInRoom`,
       which is the ABLE only — so the one function in the file named
       for "who a powered medbay treats" left out the casualties lying
       on its floor, and the healing loop had to ask `bodiesInRoom`
       instead and therefore never touched anybody on his feet.
       Two lists, each missing half the patients, and between them the
       medbay could not do the job it is bought for. */
    return this.crew.filter(c =>
      c && !c.dead && c.roomId === roomId && c.inRoom !== false &&
      c.isPlayer === this.isPlayer);
  }

  /**
   * WHO IS ACTUALLY AT THE CONSOLE (update43).
   *
   * Every skill bonus a module grants — gunnery, shields, piloting,
   * engines — used to be the SUM over everyone standing in the room.
   * Three mastered gunners came to 0.9 and were stopped only by the
   * 0.75 clamp, which exists to keep `dt / 0` from killing the frame.
   * So the strongest move in the game was to shove three people into
   * one compartment: nobody designed that, and the player could not
   * see it. A module has ONE console (slot 0, the raised spot), and
   * the man sitting at it is the one working it.
   *
   * The other two in the room are not useless — they fight boarders,
   * put out fires and repair the module — they just do not make the
   * gun charge faster.
   *
   * Returns null for an empty or CONTESTED room, exactly like
   * crewOperating(), so an invaded compartment stops paying out.
   */
  consoleOperator(roomId) {
    const room = this.getRoomById(roomId);
    if (!room) return null;
    const manned = this.crewOperating(roomId);
    if (!manned.length) return null;
    return manned.find(c => this.slotIndexAt(c.x, c.y, room) === 0) || null;
  }

  /* SIDE MATTERS FOR BODIES TOO (update42). This used to return every
     downed body in the room regardless of whose it was, which is how
     your crew ended up stretchering enemy boarders to your medbay and
     your medbay healed them back onto their feet — mid-boarding. Pass
     `false` only where you genuinely mean "everyone lying here". */
  bodiesInRoom(roomId, ownSideOnly = true) {
    return this.crew.filter(c =>
      c.roomId === roomId && c.down && c.inRoom !== false &&
      (!ownSideOnly || c.isPlayer === this.isPlayer));
  }

  /** Called by Game whenever a new battle begins: unburied corpses
   *  start to ROT — and rotting corpses spread the plague. */
  markCombatStart() {
    this.crew.forEach(c => {
      if (!c.dead) return;
      c._deadCombats = (c._deadCombats ?? 0) + 1;
      if (c._deadCombats >= 1 && !c.decaying) {
        this._startDecay(c);
      }
    });
  }

  _startDecay(c) {
    if (c.decaying) return;
    c.decaying = true;
    if (this.isPlayer && typeof UI !== 'undefined') {
      UI.notify(`${c.name}'s body is DECAYING — eject it or bag it.`, 'alert');
    }
  }

  /* ══ WHAT TO DO WITH A BODY (update65) ═════════════════════
   *
   * Three answers, and the player gives them. The machinery that
   * carries people around is untouched — what changed is who decides
   * where a corpse goes. `bodyOrder` is that decision and the ONLY
   * thing that moves a dead man off the deck.
   */

  /** Can this body be treated / vented / bagged right now, and if not,
   *  why not? ONE function, so the menu greys exactly what the order
   *  would refuse — a button that looks live and then does nothing is
   *  the bug this shape exists to prevent. */
  bodyRefusal(body, act) {
    if (!body) return 'nobody there';
    if (act === 'treat') {
      if (body.dead) return 'he is dead';
      const med = this.getSystem('medbay');
      if (!med) return 'no medbay aboard';
      return null;
    }
    /* ── THE MEDKIT (update78) ────────────────────────────────
     * The one way to get a man back on his feet on a hull with no
     * medbay — which is most hulls, and both of the ones the player
     * starts in. It costs supplies, not a module. */
    if (act === 'medkit') {
      if (body.dead) return 'he is dead';
      if (!body.down && body.hp >= body.maxHp) return 'he is not hurt';
      if (!this.hasDoses(Ship.MEDKIT_DOSES)) {
        return `not enough medical supplies (needs ${Ship.MEDKIT_DOSES}, `
             + `you have ${this.doseCount()})`;
      }
      return null;
    }
    if (act === 'eject') {
      if (!body.dead) return 'he is still alive';
      /* NOT "is a hatch open" any more (update68) — the man carrying
         him opens one. The only thing that can refuse a burial now is
         a hull with no airlock at all. */
      if (!this.doors.some(d => d.isAirlock)) return 'no airlock on this hull';
      return null;
    }
    if (act === 'bag') {
      if (!body.dead) return 'he is still alive';
      /* NOT "is somebody standing there" any more (update68). The order
         SENDS a man, exactly like every other order on this ship — the
         player's words: "jeżeli mamy zaznaczonego załoganta i najedziemy
         na trupa i damy bag lub vent to on to zrobi niezależnie w którym
         jest module". What can still refuse it is having nobody free to
         send, and a hold with no room in it. */
      const hands = this.crew.some(c =>
        c && c.alive && c.isPlayer === this.isPlayer && !c.carrying);
      if (!hands) return 'nobody free to do it';
      if (!this.cargo) return 'no hold';
      const probe = CargoGrid.deserialise(this.cargo.serialise());
      if (!probe.add(Ship.bagKeyFor(body))) return 'no room in the hold';
      return null;
    }
    return 'unknown order';
  }

  /**
   * A BOARDER IN THE CELL BLOCK LETS THEM OUT (update72).
   *
   * No order, no button: walking in IS the rescue. Anything else would
   * be a second decision on top of the one the player already made —
   * he sent people across a vacuum to a hull with a brig on it, which
   * is the decision.
   *
   * What a freed man becomes is the trick that keeps this small: he
   * turns into one of OURS, standing on THEIR hull. The recovery that
   * brings a boarding party home already sweeps up every `isPlayer`
   * crewman left on the enemy ship, so the ride home, the docking, the
   * barracks and the report are all machinery that already exists. He
   * is not cargo, not a passenger list and not a second register —
   * he is a man on a deck, like everybody else in this game.
   */
  freeCaptives() {
    /* ONE GUARD, and it is `_breakingOut` — a man who has just kicked
       his own cell door open is not waiting to be rescued. An
       `isPlayer` early-out on top of it read as belt and braces and
       was really a mask: it made this filter unreachable on the only
       hull where the difference matters. */
    const held = this.crew.filter(c => c.isPrisoner && c.alive && !c._breakingOut);
    if (!held.length) return 0;
    let freed = 0;
    held.forEach(p => {
      const saviour = this.crew.find(c =>
        c.isPlayer && c.alive && !c.isBeast && c.roomId === p.roomId);
      if (!saviour) return;
      p.isPrisoner = false;
      p.isPlayer   = true;
      p.rescued    = true;
      /* HIS OWN NAME AND HIS OWN CORPORATION. He was drawn in hostile
         red while he was theirs; the moment he is ours he is drawn as
         one of ours, because that is what he is. */
      if (p.race === 'hostile' && typeof CORP_KEYS !== 'undefined') {
        p.race = Utils.pick(CORP_KEYS);
      }
      p.homeRoomId = p.roomId;
      freed++;
      if (typeof UI !== 'undefined') {
        UI.notify(`${saviour.name} got the cell open — ${p.name} is with us.`, 'good');
      }
    });
    return freed;
  }

  /**
   * WHAT A LOOSE PRISONER DOES (update72).
   *
   * On somebody ELSE'S hull — an enemy's cell — nothing at all: he
   * waits to be found. On OURS he is a man who has just got the cell
   * door open, and the player's own decision was that he does not
   * fight: "uciekinier NIE WALCZY — biegnie do śluzy i ucieka".
   *
   * So: the nearest airlock, and out. He walks there like anybody
   * else, which is the whole point — a closed door stops him, and a
   * player who is watching can trap him in a compartment and have him
   * put back. That is why this is a WALK and not the line of text it
   * used to be: text cannot be interrupted.
   */
  _prisonerWalk(c, dt) {
    if (!c || !c.alive) return;
    if (!c._breakingOut) return;           // somebody else's prisoner: he sits
    const air = this.doors.filter(d => d.isAirlock)
      .sort((a, b) => Utils.dist(c.x, c.y, a.x, a.y) -
                      Utils.dist(c.x, c.y, b.x, b.y))[0];
    if (!air) return;                      // no way off this hull; he waits
    /* ── HE IS "THERE" WHEN HE IS IN THE AIRLOCK'S ROOM ───────
     *
     * Not "within 24 pixels of the hatch": an airlock is bolted to a
     * WALL, and the crew step-inside rule nudges anybody who reaches
     * one back into the compartment — so a radius around the door
     * turned into a man bouncing in and out of it, picking the lock
     * for one frame in thirteen and never finishing. The room he is
     * standing in does not flicker. */
    if (c.roomId === air.roomA || Utils.dist(c.x, c.y, air.x, air.y) < 24) {
      /* ── HE WORKS THE OUTER LOCK, LIKE ANY INTRUDER ─────────
       *
       * Not a free exit. He got the CELL open, so he can get this one
       * open too — but it costs him the same `Door.HACK_TIME` a
       * boarding party pays for a strange door, and that is the time
       * the player was promised: shut the hatch in his face and you
       * have seconds to get a hand to him and put him back.
       *
       * The same lock, the same clock, the same side ('enemy' — he is
       * not ours while he is running): no second mechanic for a door
       * that already knows how to be picked. */
      if (air.mode === 'open' && air.open) {
        this._prisonerGone(c);
      } else if (air.hackBy('enemy', dt)) {
        air.mode = 'open'; air.open = true;
      }
      return;
    }
    if (!c._waypoints?.length) c.moveToOnShip?.(this, air.x, air.y);
  }

  /** Off the hull for good — and back onto the board if he was on it. */
  _prisonerGone(c) {
    this.crew = this.crew.filter(k => k !== c);
    /* THE BOARD IS WRITTEN HERE, and only here — the moment he is off
       the hull. A man still walking the corridor has not escaped yet,
       and the update67 version wrote the poster the instant the cell
       door opened, which is why trapping him could never have meant
       anything. A prisoner who was never on the board goes up for the
       first time; `reWanted` has always known how to do both. */
    let poster = null;
    if (this.isPlayer && typeof Save !== 'undefined' && Save.reWanted) {
      poster = Save.reWanted({ wantedId: c.wantedId ?? null, name: c.name,
                               bounty: c.bounty, level: c.level, race: c.race });
    }
    if (this.isPlayer && typeof UI !== 'undefined') {
      UI.notify(poster
        ? `${c.name} is out the airlock and away — back on the board at ${poster.bounty} CC.`
        : `${c.name} is out the airlock and away.`, 'alert');
    }
    return poster;
  }

  /**
   * PUT HIM BACK (update72).
   *
   * The other half of making the escape a walk: a player who shut a
   * door in his face has caught him, and catching him has to be worth
   * something. One free cell and a powered brig, and he goes back in —
   * the same `takePrisoner` the fight uses, so a man re-taken is worth
   * exactly what he was worth before.
   */
  /**
   * WHAT THE BAY ITSELF SAYS NO TO — the half of the question that is
   * the same whoever is going in: is there a bay, is it lit, is there
   * a slab left.
   *
   * Written once (update77). `cellRefusal` and `freezeRefusal` had
   * three identical lines each; the first time one of them gained a
   * condition the two would have started answering differently about
   * the same module, which is the whole reason a convict and a
   * crewman spend the SAME capacity.
   */
  _slabRefusal() {
    const pod = this.getSystem('carbonite');
    if (!pod) return 'no carbonite bay on this hull';
    /* `isDisabled()` DELETED from here (update77). Since capacity is
       min(levels, power), a dark bay has no slabs at all — so that
       check could never be the reason any more and the player was
       being told "every slab is taken" about a module with nothing in
       it. The capacity is the honest question, and it answers for a
       shot-out bay and a browned-out one with the same sentence. */
    if (this.carboniteCapacity() <= 0) return 'the carbonite bay is cold — no power';
    if (this.freeCells() <= 0) return 'every slab is taken';
    return null;
  }

  cellRefusal(c) {
    if (!c || !c.isPrisoner || !c.alive) return 'nobody to lock up';
    return this._slabRefusal();
  }

  returnToCell(c) {
    const why = this.cellRefusal(c);
    if (why) return { ok: false, message: `Cannot jail: ${why}.` };
    const ok = this.takePrisoner({
      id: c.wantedId ?? c.id, name: c.name, bounty: c.bounty ?? 0,
      wantedId: c.wantedId ?? null,
    });
    if (!ok) return { ok: false, message: 'No free cell.' };
    this.crew = this.crew.filter(k => k !== c);
    return { ok: true, message: `${c.name} is back in the cell.` };
  }

  /** A cat is one cell, a man is two. Same tag, so one rule at the
   *  dock covers both — only the shape differs. */
  static bagKeyFor(body) { return body && body.isPet ? 'pet_bag' : 'body_bag'; }

  /**
   * Give the order. Returns {ok, message} like every other order in
   * this game, and refuses out loud rather than doing nothing.
   */
  orderBody(body, act, doer = null) {
    const why = this.bodyRefusal(body, act);
    if (why) return { ok: false, message: `Cannot ${act}: ${why}.` };

    /* WHO DOES IT. The man the player has selected, if he is fit for
       it; otherwise the nearest free hand. Every other order on this
       ship works that way and the player asked for this one to as
       well — before update68 BAG simply refused unless somebody
       already happened to be standing over the body. */
    const pick = (doer && doer.alive && doer.isPlayer === this.isPlayer &&
                  !doer.carrying && doer !== body)
      ? doer
      : this.crew.filter(c => c && c.alive && c.isPlayer === this.isPlayer &&
                              !c.carrying && c !== body)
          .sort((a, b) => Utils.dist(a.x, a.y, body.x, body.y) -
                          Utils.dist(b.x, b.y, body.x, body.y))[0];

    if (act === 'bag') {
      /* Already over him? Do it now. Otherwise walk him over and the
         ship finishes the job when he arrives. */
      if (pick && pick.roomId === body.roomId) return this._bagBody(body);
      if (!pick) return { ok: false, message: 'Nobody free to do it.' };
      body.bodyOrder = 'bag';
      pick._bagTargetId  = body.id;
      pick._errandRoomId = body.roomId;
      pick.moveToOnShip?.(this, body.x, body.y);
      return { ok: true, message: `${pick.name} is going for ${body.name}.` };
    }

    body.bodyOrder = act;
    /* AND HE WALKS. Setting the claim without sending him was the whole
       reason VENT looked dead in update67: the man was assigned and
       stayed exactly where he stood, because the only code that moved
       anybody was the automatic dispatch for bodies nobody was near. */
    if (pick) {
      pick._rescueId     = body.id;
      pick._errandRoomId = body.roomId;
      pick.moveToOnShip?.(this, body.x, body.y);
    }
    return { ok: true, message: act === 'treat'
      ? `${body.name} — stretcher on the way.`
      : `${pick ? pick.name : 'A hand'} is carrying ${body.name} to the airlock.` };
  }

  /* ── THE BITE AND THE EGG, BOTH ON A CLOCK (update69) ──────
   *
   * This used to live in game.js and fire once per WON FIGHT, which
   * made the whole thing a between-battles bookkeeping step: a man
   * could not turn at the gun, and an egg could not hatch in the
   * middle of a boarding action. The player asked for exactly that —
   * "czas jest liczony tylko podczas kontraktu, tak aby to moglo sie
   * stac w kazdym momencie walki".
   *
   * It lives HERE because this is the only clock that runs when the
   * ship is flying and stops when she is docked: the base does not
   * update the hull, so a contract is precisely the time that counts.
   * No second timer, no "are we in a run" flag to get out of step.
   */
  infectionTick(dt) {
    if (!this.isPlayer) return;

    // ── the bitten ──
    this.crew.forEach(c => {
      /* THE CLOCK STOPS IN THE SLAB (update77) — and it is a STOP, not
         a reset: `virusT` is left exactly where it stood, so he comes
         out as ill as he went in. Carbonite does not cure anybody. It
         buys the time to reach somewhere that can. */
      if (!c || !c.isPlayer || c.dead || c.frozen || !c.virus) return;
      const before = c.virusT ?? VIRUS_SECONDS;
      c.virusT = before - dt;
      // One warning at the halfway mark and one near the end — a line
      // every second would bury the log it is trying to warn from.
      [VIRUS_SECONDS / 2, 60].forEach(mark => {
        if (before > mark && c.virusT <= mark && typeof UI !== 'undefined') {
          UI.notify(`${c.name} is getting worse — ${Math.round(mark)}s left. `
                  + 'A research post can still cure it.', 'warn');
        }
      });
      if (c.virusT > 0) return;
      this._hatchFrom(c);
    });

    // ── the eggs ──
    (this.cargo?.items ?? []).filter(it => it.def?.tag === 'egg').forEach(egg => {
      const m = (egg.meta && typeof egg.meta === 'object') ? egg.meta : null;
      if (!m) { egg.meta = { hatchT: EGG_SECONDS }; return; }
      m.hatchT = (m.hatchT ?? EGG_SECONDS) - dt;
      if (m.hatchT > 0) return;
      this._splitEgg(egg);
    });
  }

  /**
   * HE DOES NOT LEAVE A BODY (update69).
   *
   * The old version killed him where he stood and then ALSO put an egg
   * in the hold, so the player had a corpse to bury and a case to sell
   * out of one man — "jak sie zamieni w jajko to nie ma ciala, znika".
   * There is one of him: what is left is the case.
   *
   * The memorial still gets his name, with the note that says what
   * happened to him, because the one thing worse than no gravestone is
   * a gravestone that cannot explain itself.
   */
  _hatchFrom(c) {
    const room = this.getRoomById(c.roomId);
    const egg = this.cargo?.add('spider_egg', {
      name: c.name,
      /* WHERE HE FELL. The drawing reads this, so the case the player
         can see in the room and the case in his hold are ONE item —
         sell it, or let the cat at it, and it is gone from both. */
      roomId: c.roomId,
      x: c.x, y: (room ? room.cy + 6 : c.y),
      hatchT: EGG_SECONDS,
    });
    c.virus = false;
    c.hp = 0;
    c.state = 'dead';
    c.dead = true;
    /* THE NOTE ON THE STONE (update69). The memorial already prints
       "killed by …", so what happened to him goes THERE rather than
       into a field of its own — the player asked for "na cmentarzu
       tylko notatka co sie stalo, male info", and a second column for
       one sentence would be a register to keep in step for nothing. */
    c.killedBy = 'the void-spider virus — he left an egg case';
    c._waypoints = [];
    if (typeof Save !== 'undefined' && !c._graved) {
      Save.addToGraveyard?.(c);
      c._graved = true;
    }
    /* OFF THE DECK, NOT ONTO IT. `bagged` is the same flag a body bag
       uses: it says "he is no longer a thing lying in a room", which
       is what keeps the corpse rules, the airlock and the stretcher
       crew from finding a man who is not there any more. */
    c.bagged = true;
    this.crew = this.crew.filter(k => k !== c);
    if (typeof UI !== 'undefined') {
      UI.notify(egg
        ? `${c.name} did not make it — there is an egg case where he fell.`
        : `${c.name} did not make it, and the hold had no room for what came out of him.`,
        'alert');
    }
    return !!egg;
  }

  /** The case splits and they are loose aboard. */
  _splitEgg(egg) {
    const m = (egg.meta && typeof egg.meta === 'object') ? egg.meta : {};
    this.cargo.remove(egg);
    const home = this.getRoomById(m.roomId) ||
                 Utils.pick(this.rooms.filter(r => r.system)) || this.rooms[0];
    const n = Utils.randInt(1, 4);            // 1..3
    if (typeof makeSpiders === 'function') {
      makeSpiders(n, 0).forEach(sp => {
        sp.x = (home ? home.cx : 0) + Utils.randFloat(-14, 14);
        sp.y = (home ? home.cy : 0) + 8;
        sp.roomId = home?.id; sp.homeRoomId = home?.id;
        this.addCrew(sp, true);
      });
    }
    if (typeof UI !== 'undefined') {
      UI.notify(`The egg case split open — ${n} spider${n > 1 ? 's' : ''} loose aboard!`,
                'alert');
    }
    if (typeof Audio !== 'undefined') Audio.sfx?.bossWarning?.();
    return n;
  }

  /** A man sent to bag a body finishes the job when he gets there. */
  bagArrivals() {
    this.crew.forEach(c => {
      if (!c || !c._bagTargetId || !c.alive) return;
      const body = this.crew.find(b => b && b.id === c._bagTargetId);
      if (!body || !body.dead) { c._bagTargetId = null; return; }
      if (c.roomId !== body.roomId) return;
      c._bagTargetId  = null;
      c._errandRoomId = null;
      const r = this._bagBody(body);
      if (!r.ok && this.isPlayer && typeof UI !== 'undefined') {
        UI.notify(r.message, 'warn');
      }
    });
  }

  /**
   * Bag him where he lies. No walk: the order already required a hand
   * in the room, so the man doing it is standing over the body — and
   * inventing a second carry destination for a job that happens on the
   * spot would have been a road with nothing at the end of it.
   */
  _bagBody(body) {
    const it = this.cargo.add(Ship.bagKeyFor(body), {
      name: body.name,
      crewId: body.id,
      /* HIS OWN, not a bounty. The dock reads this to tell a man
         brought home for burial from a man brought in for money —
         one item, one rule at the till, two reasons to be in it. */
      crewBody: true,
    });
    if (!it) return { ok: false, message: 'No room in the hold.' };
    /* OFF THE DECK HERE, not by way of the `ejected` flag. Setting that
       would hand him to the airlock cleanup in `_updateBodies`, which
       would announce "body committed to space" over a man who is
       safely in the hold — and charge the venting karma for it. */
    body.bagged = true;
    this.crew = this.crew.filter(c => c !== body);
    if (this.isPlayer && typeof UI !== 'undefined') {
      UI.notify(`${body.name} is bagged and stowed. He comes home.`, 'good');
    }
    return { ok: true, message: `${body.name} bagged.` };
  }

  /** Is there anywhere to actually put a corpse right now?
   *  You cannot throw a body through a shut hatch (update42). */
  hasOpenAirlock() {
    return this.doors.some(d => d.isAirlock && d.mode === 'open');
  }

  /** Carry the wounded to the medbay, carry the dead to an airlock,
   *  rot unburied corpses onto the crew, remove the ejected. */
  _updateBodies(dt) {
    // Remove anyone who went out the airlock (self-ejected plague
    // victims and committed corpses alike) — the roster entry goes.
    const ejected = this.crew.filter(c => c.ejected);
    ejected.forEach(c => {
      if (c.carriedBy) c.carriedBy.carrying = null;
      if (this.isPlayer && typeof UI !== 'undefined') {
        UI.notify(c.dead ? `${c.name}'s body committed to space.` :
                           `${c.name} walked out of the airlock…`, c.dead ? 'info' : 'alert');
      }
      /* ── THE PRICE OF THE AIRLOCK (update65) ────────────────
       *
       * Only for a body the player ORDERED out, and only his own
       * people — `bagged` men never come through here, and a plague
       * victim who walked out on his own is not a decision anybody
       * made. Karma is for what you do to those who cannot answer,
       * and this is the cheapest way to be rid of one of your own.
       */
      if (this.isPlayer && c.dead && c.bodyOrder === 'eject' &&
          typeof Commander !== 'undefined' && Commander.active && Commander.active()) {
        Commander.shift(Commander.active(), Ship.EJECT_KARMA);
        if (typeof UI !== 'undefined') {
          UI.notify(`No burial for ${c.name}. (${Ship.EJECT_KARMA} karma)`, 'warn');
        }
      }
      Particles.emit?.({ x: c.x, y: c.y, vx: this.isPlayer ? -60 : 60, vy: -10,
        ay: 0, color: '#aaccee', size: 3, sizeEnd: 0, life: 1, alpha: 0.8, alphaEnd: 0 });
    });
    if (ejected.length) this.crew = this.crew.filter(c => !c.ejected);

    const medbay = this.getSystem('medbay');
    const medRoom = medbay ? this.getRoomById(medbay.roomId) : null;

    const medPowered = medbay && medRoom && medbay.effectivePower() > 0;

    const medUsable = !!medRoom && !!medPowered;

    /* ── ROT IS A CLOCK NOW (update42) ────────────────────────
       Decay used to be a COMBAT COUNTER: a corpse only began to rot at
       the start of the NEXT fight. Combined with the pickup rule below
       — which hauled a corpse to the airlock the instant anybody walked
       into the room — that meant a body was always gone long before it
       could rot, and the entire plague subsystem never fired once in a
       real game. A corpse left aboard now starts to stink on its own. */
    this.crew.forEach(c => {
      if (!c.dead || c.decaying || c.ejected) return;
      c._rotT = (c._rotT ?? 0) + dt;
      if (c._rotT >= Ship.DECAY_SECONDS) this._startDecay(c);
    });

    /* ── BLEEDING OUT (update42) ─────────────────────────────
       A downed crew member used to lie there indefinitely. That was a
       soft-lock: the last enemy standing goes DOWN instead of dying,
       nobody on his ship is left to treat him, and the fight can never
       end. Being down is now a countdown — save them, or lose them. */
    this.crew.forEach(c => {
      if (c.dead || !c.down) { if (c._bleedT) c._bleedT = 0; return; }
      /* A BANDAGED MAN IS NOT ON A CLOCK ANY MORE (update78). He is
         still down, still helpless and still one hit from dead — he
         has simply stopped running out of time. */
      if (c._bandaged) { c._bleedT = 0; return; }
      /* AND NEITHER IS A MAN ON THE TABLE. A powered medbay is
         treatment; a clock that kept running while the ward worked on
         him would have been the ward losing a race against its own
         patient. Found by the test that carries a casualty across the
         ship: he arrived, and died on the table with the bay lit. */
      if (this._wardIsOpen() && c.roomId === this.getSystem('medbay')?.roomId) {
        c._bleedT = 0; return;
      }
      /* THE SHIP'S CAT SITS WITH HIM (update45). It cannot treat a
         wound — it is a cat — but a body somebody is beside is a body
         somebody notices, and the clock runs slower while it is there.
         40 s becomes about 66. This is what an animal does on the
         nine jumps out of ten when there are no rats to hunt. */
      const vigil = (typeof CAT_TUNING !== 'undefined' && this.petVigilOver(c))
        ? CAT_TUNING.VIGIL_FACTOR : 1;

      /* THE GOLDEN HOUR IS STAMPED WHEN HE FALLS (update49).
         The chip lengthens the window, but the spec is explicit that
         the length is fixed AT THE MOMENT of the wound: swinging the
         karma mid-fight must not reset, renew or shorten a clock that
         is already running over a man on the floor. So it is read
         once, here, on the first tick of the count. */
      if (!(c._bleedT > 0)) {
        c._bleedMax = Ship.BLEEDOUT_SECONDS
          + ((this.isPlayer && typeof Commander !== 'undefined')
             ? Commander.shipBonus('bleedout') : 0);
      }
      c._bleedT = (c._bleedT ?? 0) + dt * vigil;
      if (c._bleedT >= (c._bleedMax ?? Ship.BLEEDOUT_SECONDS)) {
        c._bleedT = 0;
        c.killOutright?.();
        if (this.isPlayer && typeof UI !== 'undefined') {
          UI.notify(`${c.name} bled out.`, 'alert');
        }
      }
    });

    const airOpen = this.hasOpenAirlock();

    // ── RESCUE DISPATCH ──────────────────────────────────────
    // Pickup below only ever triggers for a body in the SAME room, so a
    // crew member who went down somewhere else just bled out while the
    // rest of the ship carried on (the enemy pilot ignoring his downed
    // gunner). Send the nearest able hand to them — to carry them to a
    // medbay if the ship has one, or to patch them up on the spot if it
    // doesn't (most enemy hulls carry no medbay at all).
    {
      // Drop stale claims first (target rescued, dead or already lifted)
      this.crew.forEach(c => {
        if (!c._rescueId) return;
        const t = this.crew.find(b => b.id === c._rescueId);
        // A claim on a DECAYING corpse is a body-collection order and is
        // valid precisely because the target is dead (update42).
        const corpseRun = !!t && t.dead && t.bodyOrder === 'eject';
        /* ── THE JOB IS DONE WHEN THE BLEEDING STOPS (update78) ──
         *
         * The claim used to be released when the man GOT UP, which
         * was the only outcome field aid had. A bandage leaves him on
         * the floor, so that condition never came true and the medic
         * stood over him for the rest of the contract — his console
         * empty, his post forgotten. Found by the test that watches a
         * stretcher-bearer go back to work.
         *
         * A stretcher order (`treat`) and a medkit order are still
         * jobs, so they keep the claim; a plain bandage is finished. */
        const stillWanted = !!t && (t.bodyOrder === 'treat' || t.bodyOrder === 'medkit');
        const patched = !!t && t._bandaged && !stillWanted;
        if (!t || patched || (!corpseRun && (t.dead || !t.down)) || t.carriedBy || !c.alive) {
          c._rescueId = null;
          /* AND HIS POST IS HIS AGAIN (update69). The errand room is
             cleared with the claim that created it, so the moment the
             job is off him the idle walk below takes him back to the
             console he was assigned to. */
          c._errandRoomId = null;
        }
      });

      /* AND SOMEONE GOES TO FETCH A ROTTING BODY (update42).
         Corpse collection was purely opportunistic — a body was only
         ever lifted by somebody who happened to already be standing in
         its room — so a corpse in a compartment nobody visits rotted
         forever and the only cure was to walk a crew member there by
         hand. Opening an airlock is now an ORDER: it sends a hand to
         carry the thing out. */
      /* update65: the order is VENT, not the open hatch. Same dispatch,
         and it no longer waits for the body to start rotting either —
         the player has already said what he wants done. */
      this.crew.forEach(body => {
        if (body.dead && body.bodyOrder === 'eject' && !body.carriedBy &&
            !this.crew.some(c => c._rescueId === body.id) &&
            this.crewInRoom(body.roomId).length === 0) {
          const hand = this.crew
            .filter(c => c.alive && !c.carrying && !c._rescueId && !c.isBeast &&
                         c.isPlayer === this.isPlayer &&
                         c.task !== TASK.REPAIR && c.task !== TASK.BREACH &&
                         c.task !== TASK.FIRE && c.task !== TASK.FIGHT)
            .sort((a, b) => Utils.dist(a.x, a.y, body.x, body.y) -
                            Utils.dist(b.x, b.y, body.x, body.y))[0];
          if (hand) {
            hand._rescueId     = body.id;
            hand._errandRoomId = body.roomId;
            hand.moveToOnShip(this, body.x, body.y);
          }
          return;
        }
        if (body.dead || !body.down || body.carriedBy) return;
        /* ── A BANDAGED MAN IS NOT AN EMERGENCY (update78) ─────
         *
         * The dispatch sends a hand to anybody who is DOWN, and with
         * field aid a man stopped being down as soon as he was
         * treated. He stays down now, so without this the ship sent
         * somebody to him again the moment the last one walked away —
         * for ever, one man permanently off his post per casualty.
         * Caught by the test that watches a stretcher-bearer go back
         * to his gun.
         *
         * A stretcher (`treat`) or a medkit is still a job worth
         * crossing the ship for, and so is a WORKING MEDBAY: that is
         * the only thing aboard that makes him whole, so a hull that
         * has one keeps fetching him. A hull that has not, and a man
         * who has stopped bleeding, is a man who can wait. */
        const wardOpen = !!medRoom && medPowered;
        if (body._bandaged && body.bodyOrder !== 'treat'
            && body.bodyOrder !== 'medkit' && !wardOpen) return;
        // Nobody runs across the ship to rescue an enemy boarder (update42).
        if (body.isPlayer !== this.isPlayer || body.isBeast) return;
        if (body.roomId === medRoom?.id && medPowered) return;  // already being treated
        if (this.crewInRoom(body.roomId).length > 0) return;    // someone's there already
        if (this.crew.some(c => c._rescueId === body.id)) return;

        const helper = this.crew
          .filter(c => c.alive && !c.carrying && !c._rescueId &&
                       c.isPlayer === this.isPlayer && !c.isBeast &&
                       c.task !== TASK.REPAIR && c.task !== TASK.BREACH &&
                       c.task !== TASK.FIRE && c.task !== TASK.FIGHT)
          .sort((a, b) => Utils.dist(a.x, a.y, body.x, body.y) -
                          Utils.dist(b.x, b.y, body.x, body.y))[0];
        if (!helper) return;
        helper._rescueId     = body.id;
        helper._errandRoomId = body.roomId;  // walk there; pickup/field aid takes over
        helper.moveToOnShip(this, body.x, body.y);
      });
    }

    this.crew.forEach(c => {
      if (!c.alive) return;
      /* THE ERRAND ENDS WHERE IT WAS DONE (update69). Nothing to
         carry, nobody claimed, and he is standing in the room he was
         sent to: the job is over and his own post is his again. One
         line, no timer, and it cannot leak — a man with no errand is
         simply a man at his station. */
      if (c._errandRoomId && !c.carrying && !c._rescueId && !c._bagTargetId &&
          c.roomId === c._errandRoomId) {
        c._errandRoomId = null;
      }
      /* ── A PRISONER HAS HIS OWN ONE JOB (update72) ───────────
       *
       * He does not repair, does not carry, does not man anything and
       * does not take orders — so he leaves this loop before any of
       * it. What he DOES do is his own three lines, below: sit still
       * in a cell that is not his, or, if this is the hull he has just
       * broken out of, walk to the nearest airlock and leave. */
      if (c.isPrisoner) { this._prisonerWalk(c, dt); return; }
      // Spiders are not a repair crew. They do not fix the wreck they
      // live in, do not haul bodies and do not man stations — they sit
      // in their rooms and kill whatever comes through the door.
      if (c.isBeast) return;
      // An EXPLICIT emergency job outranks opportunistic body-hauling.
      // Without this, a crew member sent to seal a breach or fix a
      // module would scoop up a wounded body on arrival and walk off to
      // the medbay, so the damage never got repaired at all.
      const onEmergency = c.task === TASK.REPAIR || c.task === TASK.BREACH ||
                          c.task === TASK.FIRE;
      // Same reasoning for the room they're standing in: while it is
      // burning, holed or shot out, that work comes first — otherwise
      // they seal the breach and immediately wander off with a body,
      // leaving the module broken.
      const hereRoom = this.getRoomById(c.roomId);
      const roomBusy = !!hereRoom && (
        this.fires.getFiresInRoom(hereRoom.id).length > 0 ||
        this.breaches.hasBreachInRoom(hereRoom.id) ||
        (hereRoom.system && hereRoom.system.damagedLevels > 0));
      // Pick up a body sharing the room (wounded first) — but NOT a
      // wounded crew member already lying in a working medbay (that
      // caused the endless carry-back-and-forth jitter), and only if
      // there's actually somewhere useful to take them.
      if (!c.carrying && !onEmergency && !roomBusy) {
        const body = this.bodiesInRoom(c.roomId)
          .filter(b => !b.carriedBy)
          .filter(b => {
            /* NOBODY LIFTS A CORPSE WITH NOWHERE TO PUT IT (update42).
               This used to be an unconditional `return true`, so a body
               was scooped up and shoved through a SHUT airlock — the
               hatch never even opened. Now the player has to open one,
               which is also what finally lets a corpse sit long enough
               to rot. */
            /* A CORPSE GOES NOWHERE WITHOUT AN ORDER (update65).
               This used to be "is an airlock open?", which made the
               PLAYER'S HATCH the decision: open one to fight a fire and
               your dead were quietly thrown out with it. The decay
               alert told him to open an airlock and the game did the
               rest — so the one moment in the game where a body is
               still his to do something about passed without a
               question being asked.
               Now he says VENT and this carries it out. The wounded are
               untouched: they are still picked up and taken to the
               medbay on their own, because a man bleeding on the floor
               is not a decision, he is an emergency. */
            if (b.dead) return b.bodyOrder === 'eject';
            // wounded: skip if already in a powered medbay (healing)
            /* A MAN ALREADY IN THE WARD IS NOT CARGO (update69). The
               `medPowered` half of this made a DARK medbay a pickup
               spot: the bearer laid him down, the filter let him pick
               the same man straight back up, and the two of them
               shuffled on the spot forever. Whether the lamp is on
               decides whether he HEALS, never whether he is lifted
               again — and now that an errand no longer re-posts the
               bearer, that loop had nothing holding it back. */
            if (medRoom && b.roomId === medRoom.id) return false;
            // wounded: pointless to carry if there's no medbay at all
            return !!medRoom;
          })
          .sort((a, b) => (a.dead ? 1 : 0) - (b.dead ? 1 : 0))[0];
        if (body) { body.carriedBy = c; c.carrying = body; c._rescueId = null; }
      }
      const body = c.carrying;
      if (!body) return;
      // The body rides on the carrier's shoulders
      body.x = c.x; body.y = c.y - 10; body.roomId = c.roomId;

      if (!body.dead) {
        // WOUNDED → medbay
        if (medRoom) {
          if (c.roomId === medRoom.id ||
              Utils.dist(c.x, c.y, medRoom.cx, medRoom.cy) < 30) {
            // Arrived: lay them down and STOP (carrier stays put so it
            // doesn't wander off and re-trigger a pickup next frame).
            body.carriedBy = null; c.carrying = null;
            body.x = medRoom.cx + Utils.randFloat(-16, 16);
            body.y = medRoom.cy + 10;
            body.roomId = medRoom.id;
            c._waypoints = [];
            /* HE STANDS STILL FOR A BEAT, THEN GOES BACK TO WORK
               (update69). Parking him here used to mean re-STATIONING
               him here: the man who carried one casualty in never
               returned to his gun. The errand holds him just long
               enough not to scoop the same body up again next frame,
               and `_errandDone` hands his own post back to him. */
            c._errandRoomId = medRoom.id;
          } else if (!c._waypoints.length) {
            c.moveToOnShip(this, medRoom.cx, medRoom.cy);
          }
        }
      } else {
        /* ── DEAD → THE NEAREST AIRLOCK, AND HE WORKS IT HIMSELF
         *    (rebuilt update68)
         *
         * This used to need an airlock the PLAYER had already opened,
         * which made VENT look broken: you gave the order, nothing
         * happened, and the row sat greyed out with no way to guess
         * that the hatch was the missing half. The player's words:
         * "powinno być wyrzuć ciało i wtedy podnosi i zanosi do
         * najbliższego vent, najpierw go otwiera, wyrzuca ciało a
         * następnie zamyka".
         *
         * So the order is now the WHOLE job: walk, open, put him out,
         * shut it again. Any airlock will do — the man carrying the
         * body is the one who opens it.
         *
         * Shutting it again matters: an airlock left open vents the
         * room it is attached to, and a player who asked for a burial
         * did not ask to lose the air in his cargo hold. */
        const air = this.doors.filter(d => d.isAirlock)
          .sort((a, b) => Utils.dist(c.x, c.y, a.x, a.y) -
                          Utils.dist(c.x, c.y, b.x, b.y))[0];
        if (air) {
          c._ejectWaitT = 0;
          if (Utils.dist(c.x, c.y, air.x, air.y) < 26) {
            if (air.mode !== 'open') {
              // Arrived with the body: crack the hatch and wait a beat.
              air.mode = 'open'; air.open = true;
            } else {
              body.ejected = true;
              body.carriedBy = null; c.carrying = null;
              /* AND SHUT IT BEHIND HIM. Only the hatch this order
                 opened — `_ventedBy` marks it, so a hatch the player
                 opened himself to fight a fire is left exactly as he
                 set it. */
              if (c._ventOpened === air.id) { air.mode = 'closed'; air.open = false; }
              c._ventOpened = null;
            }
            if (air.mode === 'open' && c._ventOpened == null) c._ventOpened = air.id;
          } else if (!c._waypoints.length) {
            c.moveToOnShip(this, air.x, air.y);
          }
        } else {
          // A hull with no airlock at all. Put him down rather than
          // stand there holding him forever.
          c._ejectWaitT = (c._ejectWaitT ?? 0) + dt;
          if (c._ejectWaitT >= Ship.CORPSE_HOLD_SECONDS) {
            c._ejectWaitT = 0;
            body.carriedBy = null; c.carrying = null; c._waypoints = [];
          }
        }
      }
    });

    /* ══ THE MEDBAY'S OWN JOB (update78) ════════════════════════
     *
     * Two things changed and together they are the whole reason to buy
     * one.
     *
     * IT IS THE ONLY MEDBAY LOOP NOW. There were two: this one, which
     * healed the men on the FLOOR, and one inside `ShipSystem.update`,
     * which healed the ones on their FEET. Two halves of one patient
     * list in two files, at two rates, agreeing only by accident —
     * and `medbayPatients`, the one function named for the answer,
     * was wired to neither of them.
     *
     * AND IT IS WHAT MAKES A MAN WHOLE. Field aid used to end with the
     * same sentence this loop ends with — up at 30% — so the module
     * was a faster bandage. A bandage stops the bleeding, a medkit
     * gets him up, and only this heals him to full.
     */
    if (medbay && medRoom && medbay.effectivePower() > 0) {
      this.medbayPatients(medRoom.id).forEach(b => {
        if (!b || b.dead || b.hp >= b.maxHp) return;
        b.hp = Math.min(b.maxHp, b.hp + Ship.MEDBAY_HPS * dt * medbay.effectivePower());
        if (b.down && b.hp >= b.maxHp * Ship.MEDKIT_SHARE) {
          b.state = 'ok';
          b._bleedT = 0;
          b._bandaged = false;
          b.bodyOrder = null;
          if (this.isPlayer && typeof UI !== 'undefined') {
            UI.notify(`${b.name} is back on their feet!`, 'good');
          }
        }
      });
    }

    /* ══ FIELD AID IS A BANDAGE, NOT A CURE (update78) ══════
     *
     * It used to heal 2.2 HP/s and STAND HIM UP at 30% — which is the
     * same sentence the medbay's own loop ends with, three times
     * slower. Two things doing one job means the expensive one does
     * not exist: a medbay was a faster bandage and nothing else.
     *
     * A bandage now does exactly what a bandage does. It STOPS THE
     * BLEEDING and leaves him on the floor. Getting him back on his
     * feet is a MEDKIT (any hull) or the MEDBAY (if you have one) —
     * see `_finishMedkit` and the medbay loop above.
     *
     * AND IT COSTS A DOSE. The player's call, and the reason is the
     * whole bleed-out clock: free automatic aid meant the clock never
     * ran out on anybody who fell within reach of a crewmate, so it
     * was a rule that almost never fired. Supplies turn it into the
     * question it was always meant to be — who do I spend the last
     * dose on.
     */
    this.crew.forEach(body => {
      if (body.dead || !body.down || body.carriedBy) return;
      /* NOBODY BANDAGES THE MAN WHO CAME TO BOARD HIM (update54).
         `crewInRoom` below is side-filtered, but this loop walks
         `this.crew`, which holds BOTH sides while a boarding action is
         on — so a downed enemy lying on our deck was quietly patched
         back up by our own hands, and ours by theirs on their hull. */
      if (body.isPlayer !== this.isPlayer) return;
      /* AND NOBODY KNEELS DOWN IN THE MIDDLE OF A FIGHT (update54).
         The same predicate `crewOperating` uses to refuse to man a
         console mid-brawl, so "a fight stops the room's other work" is
         one rule in one place. */
      if (this.roomContested(body.roomId)) return;
      const medic = this.crewInRoom(body.roomId)
        .find(c => !c.carrying && !c.isBeast && !c.busy && c !== body);
      if (!medic) return;

      /* THE PLAYER ASKED FOR A MEDKIT ON THIS MAN. Same loop, same
         pair of hands, a different box: the order rides on `bodyOrder`
         exactly like BAG and EJECT do, so there is ONE place that
         knows "a free hand is standing over a casualty" and the order
         decides what he does with them. */
      if (body.bodyOrder === 'medkit' && this.hasDoses(Ship.MEDKIT_DOSES)) {
        this._startBusy(medic, 'medkit', body.id);
        return;
      }
      if (body._bandaged) return;

      /* NO SUPPLIES, NO BANDAGE — and said once, when it matters,
         rather than every frame he lies there. */
      if (!this.hasDoses(Ship.AID_DOSES)) {
        if (this.isPlayer && !body._noAidWarned && typeof UI !== 'undefined') {
          body._noAidWarned = true;
          UI.notify(`No medical supplies for ${body.name} — he is still bleeding.`, 'alert');
        }
        return;
      }
      this._startBusy(medic, 'aid', body.id);
    });

    /* ── THE PLAGUE TRAVELS THROUGH THE VENTS (update42) ──────
       Infection used to reach only `crewInRoom(body.roomId)` — stand
       one door away and you were untouchable, which made the plague a
       non-event. A ship shares one air loop, so a rotting body taints
       the whole hull: fast in the room it lies in, slowly everywhere
       else, and the ship-wide half only while life support is actually
       circulating air. Cutting oxygen contains the outbreak — at the
       obvious price. */
    const vents = (this.getSystem('oxygen')?.effectivePower() ?? 0) > 0;
    const rotting = this.crew.filter(b => b.dead && b.decaying);
    if (rotting.length) {
      const rotRooms = new Set(rotting.map(b => b.roomId));
      const n = rotting.length;
      this.crew.forEach(c => {
        if (c.infected || !c.alive || c.isBeast) return;
        if (c.isPlayer !== this.isPlayer) return;
        const near = rotRooms.has(c.roomId);
        const rate = near ? Ship.PLAGUE_RATE_ROOM
                   : vents ? Ship.PLAGUE_RATE_VENT
                   : 0;
        if (rate <= 0) return;
        if (Math.random() < dt * rate * n) {
          c.infected = true;
          if (this.isPlayer && typeof UI !== 'undefined') {
            UI.notify(near ? `${c.name} caught the corpse plague! ☣`
                           : `${c.name} caught the plague through the VENTS! ☣`, 'alert');
          }
        }
      });
    }
  }

  /** Instantly charge shields to full (used at combat start) */
  prechargeShields() {
    const ss = this.getSystem('shields');
    if (!ss) return;
    const layers = Math.floor(ss.effectivePower() / (ss.def.powerPerLayer ?? 2));
    ss._shieldMax  = layers;
    ss._shieldBars = layers;
    ss._shieldTimer = 0;
    // A bubble knocked down LAST fight is not a lesson owed in this
    // one — the debt starts every battle at zero (update44).
    ss._shieldDebt = 0;
  }

  /** World Y of a deck's top edge. */
  _deckY(row) {
    const r = this.rooms.find(o => o.floor === row);
    return r ? r.y : this.roomBounds().y;
  }

  /**
   * THE EXTERIOR TILE SLOTS (update41).
   *
   * The hull is assembled like LEGO, one row per deck:
   *
   *     [engine][module][module][shaft][module][module][prow]
   *
   * The modules and the shaft are the interior, and the engine and the
   * prow are exterior tiles hung off either end — one per deck, every
   * deck the same. These two methods say exactly where they go, so the
   * art can be dropped in without anybody re-deriving the geometry.
   *
   * A STATION has neither: Apophis does not go anywhere.
   */
  engineSlots() {
    if (this.layout.isStation) return [];
    const G = HULL_GRID, b = this.roomBounds();
    // The stern faces AWAY from the enemy: left for you, right for them.
    const x = this.isPlayer ? b.x - G.ENGINE_W : b.x + b.w;
    const out = [];
    for (let row = this.layout.floors - 1; row >= 0; row--) {
      out.push({ x, y: this._deckY(row), w: G.ENGINE_W, h: G.MODULE_H,
                 deck: row, flip: !this.isPlayer });
    }
    return out;
  }

  /**
   * The bow, one tile per deck. Unlike the engine these are NOT all the
   * same tile: a nose is a taper, so the slice you need depends on how
   * tall the hull is and where in it you are —
   *
   *     1 deck   solo
   *     2 decks  top, bot
   *     3 decks  top, mid, bot
   *
   * `slice` names the tile to draw; `decks` names the set it comes from.
   */
  prowSlots() {
    if (this.layout.isStation) return [];
    const G = HULL_GRID, b = this.roomBounds();
    const decks = this.layout.floors;
    const x = this.isPlayer ? b.x + b.w : b.x - G.PROW_W;
    const out = [];
    for (let row = decks - 1; row >= 0; row--) {
      const slice = decks === 1 ? 'solo'
                  : row === decks - 1 ? 'top'
                  : row === 0 ? 'bot' : 'mid';
      out.push({ x, y: this._deckY(row), w: G.PROW_W, h: G.MODULE_H,
                 deck: row, decks, slice, flip: !this.isPlayer });
    }
    return out;
  }

  /** Weapon module rooms in slot order (slot i ↔ i-th weapons room) */
  get weaponRooms() {
    return this.rooms.filter(r => r.type === 'weapons');
  }

  /**
   * WHICH MODULE IS THIS GUN BOLTED INTO? (update60)
   *
   * A gun used to find its module by POSITION: `weaponRooms[slot]`,
   * where `weaponRooms` is `rooms.filter(type === 'weapons')` — a list
   * that is rebuilt from the room table every time it is read. Nothing
   * anchored a gun to a place; the pairing was an accident of ordering.
   * Add a weapons module in a room that sorts EARLIER than an existing
   * one and every gun aboard silently starts drawing power and crew
   * from somebody else's bay. No current hull can do it (checked all
   * three: none has an empty room before its weapons room), which is
   * exactly what makes it the kind of trap that goes off years later,
   * on the first layout somebody adds.
   *
   * A gun now remembers its ROOM. The fallback to the old positional
   * rule stays for two real cases: a save written before update60, and
   * the boss hulls, which mount more guns than they have bays.
   */
  weaponRoomFor(w) {
    if (!w) return null;
    if (w.roomId) {
      const room = this.getRoomById(w.roomId);
      if (room && room.type === 'weapons') return room;
    }
    return this.weaponRooms[w.slot] ?? null;
  }

  /** The weapon system powering slot i (its own module room).
   *  Kept slot-based for the boss overflow path; everything that has a
   *  WEAPON in hand should go through weaponRoomFor instead. */
  weaponSystemFor(slot) {
    return this.weaponRooms[slot]?.system ?? null;
  }

  /** Charge bonus for a SPECIFIC weapon: the gunner AT ITS CONSOLE.
   *  Used to sum over everyone in the bay — see consoleOperator(). */
  weaponCrewBonusFor(slot) {
    // Resolve through the GUN when there is one in this slot, so the
    // bonus comes from the bay the gun is actually in (update60).
    const room = this.weaponRoomFor(this.weapons[slot]) ?? this.weaponRooms[slot];
    if (!room) return 0;
    const gunner = this.consoleOperator(room.id);
    return gunner ? gunner.weaponChargeBonus() : 0;
  }

  weaponCrewBonus() {   // legacy aggregate (kept for compatibility)
    return this.weapons.reduce((a, w, i) =>
      Math.max(a, w ? this.weaponCrewBonusFor(i) : 0), 0);
  }

  // ── Weapons ──────────────────────────────────────────────

  /** ONE gun per weapon module. Fails if the slot is occupied or
   *  there is no module room for it (boss ships may override slots). */
  installWeapon(defKey, slot) {
    if (slot >= this.weaponSlots) return false;
    if (this.weapons[slot]) return false;
    const w = new Weapon(defKey, slot);
    // The bay it is being bolted into, remembered on the gun (update60).
    w.roomId = this.weaponRooms[slot]?.id ?? null;
    this.weapons[slot] = w;
    this._reallocWeaponPower();
    return true;
  }

  /** STATION UPGRADE: convert the first empty room into a brand-new
   *  MODULE of the given type (level 1 system). Weapons cap at 3 per
   *  hull; other module types cap at 1. */
  addModule(type) {
    type = systemType(type);      // an old save may still say 'brig'
    if (!SYSTEM_DEFS[type]) return false;
    if (type === 'weapons') {
      if (this.weaponRooms.length >= 3) return false;
    } else if (this.getSystem(type)) {
      return false;   // only one cloak / repair bay etc.
    }
    const room = this.rooms.find(r => r.type === 'empty');
    if (!room) return false;
    room.type = type;
    // Some modules are worthless at one pip — shields need a whole
    // 2-power layer before they can raise anything at all.
    const sys = new ShipSystem(type, SYSTEM_DEFS[type].startLevel ?? 1);
    sys.power = 0; sys.desiredPower = 0;   // new modules start UNPOWERED
    room.system = sys;
    this._fitSystemToRoom(sys, room);
    this.systems.push(sys);
    this._extraModules = this._extraModules ?? [];
    this._extraModules.push(type);
    if (type === 'weapons') {
      this.weaponSlots = Math.max(this.weaponSlots, this.weaponRooms.length);
    }
    return true;
  }

  addWeaponModule() { return this.addModule('weapons'); }

  /** Same as addModule, but into a SPECIFIC empty room chosen by the
   *  player on the station's ship diagram. */
  addModuleAt(type, roomId) {
    type = systemType(type);      // an old save may still say 'brig'
    if (!SYSTEM_DEFS[type]) return false;
    if (type === 'weapons') {
      if (this.weaponRooms.length >= 3) return false;
    } else if (this.getSystem(type)) {
      return false;
    }
    const room = this.getRoomById(roomId);
    if (!room || room.type !== 'empty') return false;
    room.type = type;
    // Some modules are worthless at one pip — shields need a whole
    // 2-power layer before they can raise anything at all.
    const sys = new ShipSystem(type, SYSTEM_DEFS[type].startLevel ?? 1);
    sys.power = 0; sys.desiredPower = 0;   // new modules start UNPOWERED
    room.system = sys;
    this._fitSystemToRoom(sys, room);
    this.systems.push(sys);
    this._extraModules = this._extraModules ?? [];
    this._extraModules.push({ type, roomId });
    if (type === 'weapons') {
      this.weaponSlots = Math.max(this.weaponSlots, this.weaponRooms.length);
    }
    return true;
  }

  /* ══ THE BRIG (update63) ═══════════════════════════════════
   *
   * A prisoner is NOT crew and never goes in `crew`. That list is
   * walked by station assignment, medbay hauling, the roster panel,
   * hunger, the victory check, docking and the barracks — update45
   * put a CAT in it and the game offered the animal a console. A man
   * who wants to kill you is a worse thing to hand that list.
   *
   * So: their own array, their own three rules, and one door in and
   * one door out.
   */

  /**
   * SLABS THAT ARE ACTUALLY COLD.
   *
   * One per working level AND one unit of power each — the player's
   * rule, and the whole shape of the decision: "1 poziom = 1 miejsce =
   * 1 prąd". Cutting a unit takes a slab away while the module is
   * still standing, which is what makes this a dial rather than a
   * switch. A shot-out bay is smaller before it is empty; a browned-out
   * one is smaller before it is dark.
   *
   * It used to read `workingLevels` alone, so power was all-or-nothing
   * and three cells stayed three cells right up until the lights went
   * out.
   */
  carboniteCapacity() {
    const b = this.getSystem('carbonite');
    if (!b) return 0;
    return Math.max(0, Math.min(b.workingLevels, b.effectivePower()));
  }

  /** Everyone in a slab: convicts you are hauling in, and your own men
   *  whose clock you have stopped. One list would have been wrong —
   *  a prisoner is not crew (see the note above) — but there is only
   *  ONE capacity, and both kinds spend it. */
  frozenCrew() { return this.crew.filter(c => c && c.frozen && !c.dead); }

  /** A medbay that is aboard, undamaged enough to work, and lit. One
   *  question, asked by the bleed clock, the dispatch and the healing
   *  loop alike (update78). */
  _wardIsOpen() {
    const med = this.getSystem('medbay');
    return !!med && !med.isDisabled() && med.effectivePower() > 0;
  }

  /** Slabs with nobody in them. */
  freeCells() {
    return Math.max(0, this.carboniteCapacity()
                     - this.prisoners.length - this.frozenCrew().length);
  }

  /**
   * WHY YOU CANNOT FREEZE THIS MAN. Null means you can.
   *
   * Asked by the button AND by the order, so a row can never look live
   * and then do nothing — the same contract the body menu has kept
   * since update68.
   *
   * He has to BE in the bay. Carbonite is a place, not a button: the
   * walk there is the cost you pay before the decision, in the seconds
   * his hands are off a console and in the risk of sending him across
   * a burning ship. Freezing a man from anywhere would make it free.
   */
  freezeRefusal(c) {
    if (!c || c.dead || !c.isPlayer) return 'not one of your crew';
    if (c.isBeast) return 'not an animal';
    if (c.frozen)  return 'already in a slab';
    const bay = this._slabRefusal();
    if (bay) return bay;
    // …and the half that is only about HIM: carbonite is a place.
    if (c.roomId !== this.getSystem('carbonite').roomId) {
      return 'he is not in the carbonite bay';
    }
    return null;
  }

  /** Put him under. Returns {ok, message} — the shape every order in
   *  this file answers in. */
  freezeCrew(c) {
    const why = this.freezeRefusal(c);
    if (why) return { ok: false, message: `Cannot freeze: ${why}.` };
    /* WHICH SLAB WENT IN LAST, so thawing can be last-in-first-out
       when the power drops — a rule the player can work out before he
       pulls the pip rather than after.
       COMPUTED from the men already under, not kept in a counter on
       the ship: a counter would be a second register that has to be
       saved, reloaded and kept in step with the crew it describes, and
       the crew already carry the answer.
       Read BEFORE he joins them, or he would be counting himself. */
    c._slabSeq = 1 + this.frozenCrew()
      .reduce((m, x) => Math.max(m, x._slabSeq ?? 0), 0);
    c.frozen = true;
    c._slabRoom = c.roomId;
    /* OUT OF EVERY ROOM QUERY. He keeps his x and y — the player can
       see him in the slab and click him to thaw him — but nothing that
       searches a ROOM finds him, so he cannot man a console, be shot
       at, catch fire, breathe or be counted as a defender. */
    c.roomId = null; c.inRoom = false;
    c.target = null; c.path = null;     // he was walking; now he is not
    if (this.isPlayer && typeof UI !== 'undefined') {
      UI.notify(`${c.name} is under. Nothing moves for him now.`, 'good');
    }
    return { ok: true, message: `${c.name} frozen.` };
  }

  /** Bring him back, exactly as he went in. */
  thawCrew(c, why = 'thawed') {
    if (!c || !c.frozen) return { ok: false, message: 'He is not in a slab.' };
    c.frozen = false;
    c._slabSeq = null;
    const pod  = this.getSystem('carbonite');
    const room = this.getRoomById(c._slabRoom ?? pod?.roomId) || this.rooms[0];
    if (room) {
      c.roomId = room.id;
      c.x = room.cx;
      c.y = this.floorWalkY(room.floor, room.cy);
      c.homeRoomId = c.homeRoomId ?? room.id;
    }
    if (this.isPlayer && typeof UI !== 'undefined') {
      UI.notify(`${c.name} is out of the slab — ${why}.`,
                why === 'thawed' ? 'good' : 'warn');
    }
    return { ok: true, message: `${c.name} thawed.` };
  }

  /**
   * THE SLAB THAT LOST ITS POWER LETS GO.
   *
   * The player's rule, word for word: "dwóch zamrożonych, ucinasz
   * jeden prąd → jeden się rozmraża, drugi nie". Capacity is a live
   * number now, so this is just "put back whoever no longer has a
   * slab" — LAST IN FIRST OUT, so which man it is, is something the
   * player can work out before he pulls the pip rather than after.
   *
   * Prisoners are NOT thawed here: a convict whose cell goes cold
   * starts working the lock instead, which is `prisonerTick`, and that
   * rule was already right.
   */
  carboniteTick() {
    const over = (this.prisoners.length + this.frozenCrew().length)
               - this.carboniteCapacity();
    if (over <= 0) return;
    const queue = this.frozenCrew().sort((a, b) => (b._slabSeq ?? 0) - (a._slabSeq ?? 0));
    queue.slice(0, over).forEach(c => this.thawCrew(c, 'his slab lost power'));
  }

  /**
   * Lock a man up. Refuses rather than overfilling — the caller is a
   * player decision and has to be able to say "you have no room".
   */
  takePrisoner(rec) {
    if (!rec || this.freeCells() <= 0) return false;
    this.prisoners.push({
      id: rec.id ?? `p${this.prisoners.length}`,
      name: rec.name ?? 'Prisoner',
      bounty: Math.max(0, Math.round(rec.bounty ?? 0)),
      /* Which poster he came off, or null. The ID, never a copy of the
         record — the list is the one place he lives. */
      wantedId: rec.wantedId ?? null,
      escapeT: 0,
      warned: false,
    });
    return true;
  }

  /**
   * WHAT KEEPS THEM IN IS POWER, NOT THE WALL.
   *
   * A powered brig is a room they sit in. Cut its power — or shoot it
   * out — and the clock starts; restore it and the clock goes back to
   * zero, because a man interrupted at a lock has to start again. Only
   * when the clock runs out is he gone, and the player is warned well
   * before that so it is never a silent loss.
   */
  prisonerTick(dt) {
    if (!this.prisoners.length) return;
    /* ── A SLAB EACH, NOT A DOOR FOR EVERYBODY (update77) ────
     *
     * This asked one yes-or-no question — is the bay powered — so
     * three convicts in a bay browned out from three units to one
     * stayed put, because the module was not DISABLED. Slabs are
     * counted now, so losing two units frees exactly two men to start
     * working their locks and leaves the third cold.
     *
     * PRISONERS HAVE THE FIRST CLAIM on what slabs remain, and your
     * own frozen men are the ones who come out (`carboniteTick`) —
     * a thaw can be undone, an escape cannot.
     *
     * Earliest taken keeps his slab, so the man who has been aboard
     * longest is not the one who gets a chance. */
    const slabs = Math.min(this.prisoners.length, this.carboniteCapacity());
    this.prisoners.slice(0, slabs).forEach(p => { p.escapeT = 0; p.warned = false; });
    const loose = this.prisoners.slice(slabs);
    if (!loose.length) return;
    const gone = [];
    loose.forEach(p => {
      p.escapeT += dt;
      if (!p.warned && p.escapeT >= Ship.ESCAPE_SECONDS * 0.4) {
        p.warned = true;
        if (this.isPlayer && typeof UI !== 'undefined') {
          UI.notify(`${p.name} is working the cell door — get the carbonite bay powered!`, 'alert');
        }
      }
      if (p.escapeT >= Ship.ESCAPE_SECONDS) gone.push(p);
    });
    gone.forEach(p => {
      this.prisoners.splice(this.prisoners.indexOf(p), 1);
      /* ── HE WALKS OUT, HE DOES NOT VANISH (update72) ────────
       *
       * update67 made the escape a LINE OF TEXT: the cell clock ran
       * out, a notification appeared and the man ceased to exist. The
       * player's own design said otherwise — "biegnie do śluzy i
       * ucieka… gracz ma realny czas, żeby go zablokować drzwiami" —
       * and text cannot be interrupted by a door.
       *
       * So he becomes what he always was: a man, standing in the brig,
       * heading for the nearest airlock. Shut the right door and he is
       * still aboard; order a hand to walk him back and he is back in
       * the cell at the same price. The board is written only when he
       * is actually GONE, which is now a thing that can fail to happen.
       */
      const brig = this.getRoomById(this.getSystem('carbonite')?.roomId) || this.rooms[0];
      const runner = new CrewMember({
        name: p.name, race: p.race || 'hostile',
        isPlayer: false, isPrisoner: true,
      });
      runner.wantedId = p.wantedId ?? null;
      runner.bounty   = p.bounty ?? 0;
      /* LEFT UNDEFINED WHEN THE CELL RECORD HAS NO LEVEL, on purpose:
         `reWanted` falls back to 5 for a man nobody has rated, and
         writing 1 here would have put every escaped commander on the
         board as a beginner. */
      runner.level    = p.level;
      runner.escapes  = p.escapes ?? 0;
      runner._breakingOut = true;
      runner.roomId = brig?.id;
      runner.x = brig ? brig.cx : 0;
      runner.y = brig ? this.floorWalkY(brig.floor, brig.cy) : 0;
      runner.homeRoomId = brig?.id;
      this.addCrew(runner, true);
      if (this.isPlayer && typeof UI !== 'undefined') {
        UI.notify(`${p.name} is OUT of the cell and making for an airlock — `
                + 'shut a door on him.', 'alert');
      }
    });
  }

  /**
   * A PRISONER EATS (update67).
   *
   * One meal per sector, taken out of the hold like anybody else's —
   * which is the real cost of carrying a man home: not the cell, the
   * RATIONS. A hold packed with ore and no food is a hold that starves
   * your bounty on the way back.
   *
   * Called once per jump, not per frame: hunger for prisoners is a
   * decision at the jump ("do I have food for him?"), and a meter of
   * its own would be a second hunger system beside the crew's.
   *
   * A man with nothing to eat dies, and a dead prisoner is a BODY —
   * still worth half, if the hold has room for him. That is the same
   * pair of prices as everywhere else, and it means starving him is a
   * loss, not a clean escape from the problem.
   */
  feedPrisoners() {
    const out = { fed: 0, starved: [], bagged: 0 };
    if (!this.prisoners.length) return out;
    this.prisoners.slice().forEach(p => {
      const meal = this.cargo?.items?.find(it =>
        it.def?.tag === 'food' && !it.damaged);
      if (meal) {
        if ((meal.qty ?? 0) > 1) meal.qty--; else this.cargo.remove(meal);
        out.fed++;
        return;
      }
      this.prisoners.splice(this.prisoners.indexOf(p), 1);
      out.starved.push(p.name);
      /* HIS BODY, IF THERE IS ROOM. Half his price, the same rule as
         a commander finished off in his cockpit. */
      const bag = this.cargo?.add?.('body_bag', {
        name: p.name, bounty: Math.round((p.bounty ?? 0) / 2),
        wantedId: p.wantedId ?? null,
      });
      if (bag) out.bagged++;
    });
    if (this.isPlayer && typeof UI !== 'undefined') {
      if (out.starved.length) {
        UI.notify(`${out.starved.join(', ')} starved in the cells.`, 'alert');
      } else if (out.fed) {
        UI.notify(`${out.fed} prisoner meal${out.fed > 1 ? 's' : ''} out of the hold.`,
                  'info');
      }
    }
    return out;
  }

  /** Missiles are physical: the racks in the hold ARE the ammo count. */
  missileCount() { return this.cargo?.countOf?.('missiles') ?? 0; }

  /** He2 is physical too (update39): the cells in the hold ARE the tank.
   *  No canisters aboard, no jump — exactly like the missile racks. */
  fuelCount() { return this.cargo?.countOf?.('fuel') ?? 0; }

  /**
   * Box a gun and stow it in the grid hold. A gun can only ever be
   * MOUNTED or BOXED — there is no weightless rack it can live on.
   * Returns the crate, or null if the hold has no room for it.
   */
  /**
   * Every spare gun aboard, as the crates they actually are.
   *
   * ONE definition of "a boxed gun" (update75). The filter — a crate
   * whose kind is `weapon` and which remembers WHICH gun in `meta` —
   * was written out by hand in the station screen twice, in the yard
   * and in the distress-beacon code. Four copies of one sentence is
   * four chances for one of them to start meaning something else.
   */
  boxedGuns() {
    return (this.cargo?.items ?? [])
      .filter(it => it.def?.kind === 'weapon' && it.meta);
  }

  boxWeapon(defKey, dest = this.cargo) {
    if (!dest || typeof cargoCrateForWeapon !== 'function') return null;
    return dest.add(cargoCrateForWeapon(defKey), defKey);
  }

  /**
   * Unbolt a gun and box it. Returns the gun's defKey, or null if the
   * mount was empty OR the crate would not fit — in which case THE GUN
   * STAYS BOLTED ON.
   *
   * `dest` is which grid the crate lands in: the ship's own hold out on
   * a contract, the base's armoury shelf when she is in the hangar.
   * ONE function unbolts a gun, and it is the one that holds the rule
   * that matters: if the crate cannot be placed, nothing moves at all —
   * a gun is never in the air between the mount and a shelf. The two
   * callers used to each carry their own copy of that check (update75).
   */
  uninstallWeapon(slot, dest = this.cargo) {
    const w = this.weapons[slot];
    if (!w) return null;
    if (!this.boxWeapon(w.defKey, dest)) return null;  // no room — she keeps her gun
    this.weapons[slot] = null;
    this._reallocWeaponPower();
    return w.defKey;
  }

  /**
   * Strip a bay while a hull is still being BUILT. The gun is not
   * stowed anywhere — it is gone, because it never really existed: this
   * is for swapping the layout's default gun out of an enemy hull
   * before anybody has seen her.
   *
   * It exists so that the destruction is written down (update75).
   * Enemy setup used to call `uninstallWeapon` for this and rely on the
   * gun landing in `weaponCargo`, a list nothing ever read on an enemy
   * — destruction by side effect, in a function whose whole promise is
   * that the gun is kept. With the rack gone, that call would have
   * boxed a crate into the enemy's hold, turning her starter laser into
   * loot the player was never meant to find, and would have FAILED on a
   * full hold, leaving the bay occupied and the swap silently undone.
   *
   * Never call this on a ship anybody owns. Taking a gun off a mount
   * and keeping it is `uninstallWeapon`, and that is the only one the
   * station and the hangar are allowed to use.
   */
  scrapWeapon(slot) {
    if (!this.weapons[slot]) return false;
    this.weapons[slot] = null;
    this._reallocWeaponPower();
    return true;
  }

  /* removeWeapon(slot) DELETED (update40).
   *
   * It sat directly below `uninstallWeapon(slot)` with no call sites and
   * the opposite behaviour: uninstall KEPT the gun, removeWeapon
   * DESTROYED it. Two contradictory rules for one action, one of them
   * silently confiscating a weapon the day anybody wired it up by
   * mistake. Still deleted, and now there is only one place a gun can
   * go when it comes off a mount, so the pair cannot grow back.
   */

  _reallocWeaponPower() {
    // Each gun draws power from ITS OWN weapon module. A damaged or
    // ionised module de-powers only the gun mounted in it (FTL rule,
    // one gun per module). Overflow slots without a room (boss ships)
    // share the FIRST module's leftover power.
    let sharedLeft = null;
    this.weapons.forEach((w, i) => {
      if (!w) return;
      const sys = this.weaponRoomFor(w)?.system ?? null;
      if (sys) {
        w.power = Math.min(w.powerCost, sys.effectivePower());
      } else {
        if (sharedLeft === null) {
          const first = this.weaponSystemFor(0);
          sharedLeft = first ? Math.max(0, first.effectivePower()
            - (this.weapons[0]?.power ?? 0)) : 0;
        }
        const give = Math.min(w.powerCost, sharedLeft);
        w.power    = give;
        sharedLeft -= give;
      }
    });
  }

  // ── Power management ──────────────────────────────────────

  /** Has this ship's power ever been laid out (by the auto-spread or
   *  by the player)? Used so a new battle does NOT stomp the layout the
   *  player set up in the previous one. */
  hasPowerPreference() {
    return this.systems.some(s => s.type !== 'reactor' && s.desiredPower > 0);
  }

  _allocateDefaultPower() {
    // Life support and helm first — the starting reactor (6 power)
    // cannot feed everything, and an unpowered O2 system suffocates.
    const prio = { oxygen:0, piloting:1, shields:2, weapons:3,
                   engines:4, medbay:5, artillery:6 };
    let remaining = this.reactor.totalPower;
    [...this.systems]
      .filter(s => s.type !== 'reactor')
      .sort((a, b) => (prio[a.type] ?? 9) - (prio[b.type] ?? 9))
      .forEach(sys => {
        const give = Math.min(sys.maxPower, remaining);
        sys.power        = give;
        sys.desiredPower = give;
        remaining       -= give;
      });
  }

  setPower(systemType, power) {
    const sys = this.getSystem(systemType);
    if (!sys) return;
    this.setPowerAt(this.systems.indexOf(sys), power);
  }

  /** Index-based power control — needed because a ship can carry
   *  SEVERAL systems of the same type (one per weapon module). */
  setPowerAt(sysIndex, power) {
    const sys = this.systems[sysIndex];
    if (!sys || sys.type === 'reactor') return;
    this.reactor.setPower(sys, power, this.systems);
    sys.desiredPower = sys.power;   // remember intent — restored after repair
    if (sys.type === 'weapons') this._reallocWeaponPower();
    Audio.sfx.powerUp();
  }

  availablePower() {
    return this.reactor.distribute(this.systems);
  }

  // ── Damage resolution ────────────────────────────────────

  /**
   * Receive a projectile hit.
   * Returns { absorbed, hullDamage, roomHit }
   */
  receiveHit(proj) {
    const def = proj.def;

    // ACTIVE CLOAK: nothing lands while the field is up. Not a high
    // evasion roll — a guaranteed miss for the whole duration. That is
    // the point of spending a cooldown on it.
    {
      const cl = this.getSystem('cloaking');
      if (cl && cl.cloakActive) {
        Particles.floatText(proj.x, proj.y - 6, 'CLOAKED', '#cc44ff', 12);
        return { absorbed: true, dodged: true, hullDamage: 0 };
      }
    }

    // Evasion dodge — pilot and engine crew gain XP (FTL)
    if (Math.random() < this.evasion) {
      Particles.floatText(proj.x, proj.y - 6, 'MISS', '#8fd4ff', 12);
      const pSys = this.getSystem('piloting');
      const eSys = this.getSystem('engines');
      const helmHand = pSys ? this.consoleOperator(pSys.roomId) : null;
      const engHand2  = eSys ? this.consoleOperator(eSys.roomId) : null;
      if (helmHand) helmHand.addXP('piloting', XP_RATES.piloting);
      if (engHand2) engHand2.addXP('engines',  XP_RATES.engines);
      return { absorbed: true, dodged: true, hullDamage: 0 };
    }

    // Who ignores shields: it is a property of the GUN now, not a list
    // of type names scattered through the damage code.
    const isBeam    = def.type === 'beam';
    const pierces   = def.pierceShields ?? (def.type === 'missile' || def.type === 'cannon' || isBeam);

    // Shield check. A bolt stopped by the bubble strips shieldDamage
    // BARS, not one — that is what makes an ion cannon or a flak burst
    // a shield-breaker rather than a slightly worse laser.
    if (!pierces && this.shieldBars > 0) {
      const shSys = this.getSystem('shields');
      const strip = Math.max(1, def.shieldDamage ?? def.shield_damage ?? 1);
      for (let i = 0; i < strip && this.shieldBars > 0; i++) shSys.hitShield();
      Particles.shieldHit(proj.x, proj.y);
      if (strip > 1) Particles.floatText(proj.x, proj.y - 6, `-${strip} SHIELD`, '#4db8ff', 11);
      this._shieldAlpha = 1;
      Camera.shake(4, 0.15);
      return { absorbed: true, hullDamage: 0, shieldStripped: strip };
    }

    // Damage lands in the room the projectile actually reached.
    // (Previously a random room was picked — targeting was cosmetic
    //  and fires appeared in modules that were never hit.)
    const roomHit =
      this.rooms.find(r => r.contains(proj.x, proj.y)) ||
      this.rooms.find(r => r.contains(proj.targetX, proj.targetY)) ||
      Utils.pick(this.rooms);

    /* EVERY EFFECT IS ITS OWN NUMBER.
       `damage` used to do four jobs at once — hull points, module levels,
       a multiplier on crew injury and, by implication, the breach roll —
       so there was no way to describe a gun that strips shields and
       harms nothing, or one that cuts up crew but leaves modules alone.
       Each one is a separate field on the def now (see WEAPON_DEFS). */
    const dmg = def.hull_damage ?? def.damage ?? 1;
    this.hull = Math.max(0, this.hull - dmg);

    // Floating damage feedback
    if (roomHit.type === 'reactor' && roomHit.system && dmg > 0) {
      Particles.floatText(roomHit.cx, roomHit.y + 10, `-${dmg} POWER`, '#ffb020', 12);
    } else if (dmg > 0) {
      Particles.floatText(roomHit.cx, roomHit.y + 10, `-${dmg}`, '#ff5566', 13);
    }

    // Module levels knocked out. 0 means this gun cannot break a module
    // at all, however hard it lands (ion, flak).
    const modDmg = def.moduleDamage ?? def.damage ?? 1;
    if (roomHit.system && modDmg > 0) roomHit.system.damageLevel(modDmg);

    // Crew in the hit room. An explicit [min,max] per weapon, so a flak
    // burst can hurt people without touching the machinery.
    const cd = def.crewDamage ?? [10 * dmg, 25 * dmg];
    if ((cd[1] ?? 0) > 0) {
      this.occupantsOf(roomHit.id).forEach(c => {
        const before = c.alive;
        // crewDamage is an inclusive range in WEAPON_DEFS, and the
        // stat chip prints it as one — so roll it as one.
        c.takeDamage(Utils.randIn(cd[0], cd[1]), 'weapons fire');
        // Credit the gunner who actually pulled the trigger — that is
        // what the memorial means by "kills".
        if (before && !c.alive) (proj.gunners ?? []).forEach(g => g.creditKill?.(c));
      });
    }

    // STUN — the module and everyone in it. One second per ion bolt.
    const stun = def.stunTime ?? (def.type === 'ion' ? 1 : 0);
    if (stun > 0) {
      if (roomHit.system) roomHit.system.ionHit(stun);
      this.occupantsOf(roomHit.id).forEach(c => c.stun?.(stun));
      Particles.floatText(roomHit.cx, roomHit.y + 22, 'STUNNED', '#8fd4ff', 11);
    }

    // Breach chance — per weapon now. It used to be "missiles always,
    // any 2+ hit 25% of the time", which made every heavy laser a hull
    // breacher and gave the designer no way to say otherwise.
    const breachP = def.breachChance ?? (pierces ? 0.5 : dmg >= 2 ? 0.25 : 0);
    if (breachP > 0 && Math.random() < breachP) {
      this.breaches.open(
        roomHit.id,
        roomHit.x + Utils.randFloat(8, roomHit.w - 8),
        roomHit.y + Utils.randFloat(8, roomHit.h - 8)
      );
    }

    // Fire chance — per weapon, 25% unless the def says otherwise
    // (the starting laser is deliberately tamer, see WEAPON_DEFS).
    if (Math.random() < (def.fireChance ?? 0.25)) {
      this.fires.start(roomHit.id, roomHit.cx, roomHit.cy);
    }

    Particles.explosion(proj.x, proj.y, 0.7);
    Camera.shake(6, 0.2);

    /* THE SECOND DAMAGE NUMBER IS GONE (update40).
       There were two floatText calls for one hit, at the same point:
       the guarded one above (`else if (dmg > 0)`) and an unguarded one
       here. Every laser hit painted two overlapping numbers in two
       sizes, which read as a smeared bold figure — and because ion and
       flak have hull_damage 0, the unguarded one proudly rendered
       "-0" over the room for the two guns whose whole identity is that
       they harm nothing. */
    roomHit._hitFlash = 1;          // drawn by Room.draw, fades out

    if (this.hull <= 0) this._beginDestruction();

    return { absorbed: false, hullDamage: dmg, roomHit };
  }

  _beginDestruction() {
    if (this.destroyed) return;
    this.destroyed = false;   // will flip after death animation
    this._deathTimer = 0;
    Audio.sfx.explosion();
    Camera.shake(20, 0.8);
    /* WHOSE HULL JUST WENT (update71). `recordKill` counted ANY ship
       breaking up — including the player's own — so the campaign's
       "enemies killed" went up by one every time he lost. It is the
       enemy's destruction that is a kill, and the same line feeds the
       side objective. */
    if (!this.isPlayer) {
      Save.recordKill();
      Save.goalEvent?.('ships');
    }
  }

  // ── Update ───────────────────────────────────────────────

  /**
   * Egg sacs split open once there is prey aboard.
   *
   * Anyone sharing a room with a sac sets it off IMMEDIATELY; the rest
   * hatch on their own stagger so a boarding party can never get stuck
   * unable to finish because one sac sits in a room nobody visits.
   */
  hatchNests(dt) {
    const sacs = this.crew.filter(c => c.dormant && !c.dead);
    if (!sacs.length) return 0;
    const intruders = this.crew.filter(c => c.isPlayer && !c.dead && !c.down);
    if (!intruders.length) return 0;      // still nobody aboard

    let hatched = 0;
    sacs.forEach(sac => {
      const inRoom = intruders.some(p => p.roomId === sac.roomId);
      /* WALKING IN IS HOW YOU FIND THEM.
         A sac is invisible until somebody is in the room with it — the
         wreck reads as empty and the nests are something you discover,
         not something the sensors hand you on the way in.
         Entering also makes it hatch six times faster (it was hatching
         INSTANTLY before, so the sac was never actually seen), which
         leaves a moment to register what you have just walked into. */
      if (inRoom) sac.revealed = true;
      /* THE CAT SMELLS THEM THROUGH THE BULKHEAD (update45). A boarding
         party walks in blind; an animal aboard gives you one room of
         warning, which is the difference between choosing to open that
         door and finding out afterwards. It reveals the sac WITHOUT
         speeding it up — knowing is not the same as disturbing. */
      if (!sac.revealed && typeof CAT_TUNING !== 'undefined') {
        const nearCat = this.crew.some(c => c.isPet && c.alive &&
          (c.roomId === sac.roomId ||
           this.adjacentThermal(c.roomId).some(a => a.room?.id === sac.roomId)));
        if (nearCat) {
          sac.revealed = true;
          sac.sensedByCat = true;
        }
      }
      sac.hatchT -= dt * (inRoom ? 6 : 1);
      if (sac.hatchT <= 0) {
        if (sac.hatch()) hatched++;
      }
    });
    if (hatched && typeof UI !== 'undefined') {
      UI.notify?.(`${hatched} egg sac${hatched > 1 ? 's' : ''} just split open!`, 'alert');
    }
    return hatched;
  }

  /**
   * MOON RATS, once they are aboard (update39).
   *
   * A rat is ordinary hostile crew — that is what lets your people
   * corner one and beat it to death using the melee code that already
   * works, and it is why "sometimes they go for a crewman" needs no
   * code at all. What DOES need code is the other half of the report:
   * a rat that finds a module chews through the loom and shorts it.
   * That is exactly a stun, so it goes through the same ionHit() an
   * ion bolt uses — the module stops working, the people in it stop
   * with it, and the readout already knows how to say so.
   *
   * They only chew DURING A FIGHT. A rat gnawing your shields flat in
   * open space is a chore; a rat gnawing them flat with a gunship
   * closing is a story, and the player asked for the story.
   */
  verminTick(dt) {
    const rats = this.crew.filter(c => c.isVermin && !c.dead);
    if (!rats.length) return 0;
    // Clear away anything that finally stopped moving, so a hunted-out
    // hull does not carry a list of corpses for the rest of the run.
    const gone = this.crew.filter(c => c.isVermin && c.dead);
    if (gone.length) this.crew = this.crew.filter(c => !(c.isVermin && c.dead));

    const fighting = (typeof CombatManager !== 'undefined')
      && (CombatManager.isActive?.() ?? false);
    let shorts = 0;
    rats.forEach(rat => {
      if (!rat.alive) return;
      rat._chewT = (rat._chewT ?? Utils.randFloat(4, Ship.RAT_CHEW_MAX)) - dt;
      if (rat._chewT > 0) return;
      rat._chewT = Utils.randFloat(Ship.RAT_CHEW_MIN, Ship.RAT_CHEW_MAX);

      const room = this.getRoomById(rat.roomId);
      // Somebody is already swinging at it — it has other problems.
      const cornered = room && this.crew.some(c =>
        c.isPlayer && c.alive && c.roomId === room.id);
      if (cornered) return;

      const sys = room?.system;
      // Already shorted? Leave it — chewing a dead loom does nothing,
      // and stacking stun on stun would hold a module down for ever.
      if (fighting && sys && !(sys.stunLeft > 0)) {
        sys.ionHit(Ship.RAT_SHORT_SECONDS);
        this.occupantsOf(room.id).forEach(c => c.stun?.(Ship.RAT_SHORT_SECONDS));
        Particles.floatText?.(room.cx, room.y + 22, 'SHORTED', '#ffd780', 11);
        if (this.isPlayer) Audio.sfx.ratChew?.();
        if (this.isPlayer && typeof UI !== 'undefined') {
          UI.notify(`Something chewed through the ${sys.label} loom — it is dead for `
                  + `${Ship.RAT_SHORT_SECONDS}s!`, 'alert');
        }
        shorts++;
        return;
      }

      // Otherwise it moves on to somewhere else worth chewing.
      const elsewhere = this.rooms.filter(r => r.id !== rat.roomId);
      if (!elsewhere.length) return;
      const to = Utils.pick(elsewhere);
      rat.homeRoomId = to.id;
      rat.moveToOnShip(this, to.cx + Utils.randFloat(-14, 14),
                             this.floorWalkY(to.floor, to.cy));
    });
    return shorts;
  }

  /** How long a chewed loom stays dead, and how often a rat tries. */
  static get RAT_SHORT_SECONDS() { return 3; }
  static get RAT_CHEW_MIN() { return 9; }
  static get RAT_CHEW_MAX() { return 22; }

  /* ── Casualty clocks (update42) ──────────────────────────
     Every one of these used to be an inline literal buried in
     _updateBodies, and two of them didn't exist at all. */
  /** Seconds a corpse lies aboard before it starts to rot. */
  static get DECAY_SECONDS() { return 40; }
  /** Seconds a DOWNED crew member has before they bleed out. */
  static get BLEEDOUT_SECONDS() { return 40; }
  /* ── THE PRICE LIST OF A BOX OF SUPPLIES (update78) ────────
   *
   * `FIELD_AID_HPS` DELETED. A bandage does not restore hit points any
   * more, so an HP-per-second for it was a number describing something
   * that no longer happens — and the medbay's own rate, three times
   * larger, is the one that heals.
   *
   * One box, two prices, and the automatic one is the cheap one so
   * that the expensive one stays a decision. */
  /** HP/s per unit of power a medbay restores — the only thing aboard
   *  that heals past the point a man stands up. */
  static get MEDBAY_HPS()   { return 6; }
  static get AID_DOSES()    { return 1; }   // stop the bleeding
  static get MEDKIT_DOSES() { return 2; }   // …and get him up
  /** What a medkit puts him back on his feet at, as a share of max. */
  static get MEDKIT_SHARE() { return 0.30; }
  /** Infection chance per second, sharing a room with a rotting body. */
  static get PLAGUE_RATE_ROOM() { return 0.05; }
  /** …and anywhere else on the ship, carried by the air handlers. */
  static get PLAGUE_RATE_VENT() { return 0.008; }
  /** How long a bearer waits with a body when every hatch is shut. */
  static get CORPSE_HOLD_SECONDS() { return 6; }

  /* ── WHERE THE TWO HULLS STAND IN A FIGHT (update73) ──────
   *
   * Written out FOUR times in game.js before this — `180, 180` at
   * three places where the player's hull is built or loaded, and
   * `850, 200` where the enemy is spawned. Four literals for two
   * positions, and every one of them needed the same correction when
   * the module got wider, which is four chances to correct three.
   *
   * MEASURED, not chosen. The widest player hull and the widest enemy
   * hull are 520px each and the canvas is 1280, so 240px is all there
   * is to divide. The orders panel on the left ends around x=120 and
   * the hull may not sit on top of it, which fixes the left margin at
   * about 140 and leaves 100 to split between the gap the shells
   * cross and the right-hand edge. 70 and 30.
   *
   * The enemy came in from 850, where he no longer fitted: at four
   * columns his stern ran eighty pixels off the right of the screen.
   */
  static get PLAYER_STATION() { return { x: 170, y: 180 }; }
  static get ENEMY_STATION()  { return { x: 750, y: 200 }; }
  /* Out the airlock is free in CC and costs you your name. The other
     half of this pair is the burial at the dock — see base.js.

     `VENT_KARMA` RENAMED to EJECT_KARMA (update75). Since update73 a
     "vent" is the duct along every ceiling — where the fire runs and
     the rats live — and the order that throws a body into the black
     had the same word. The airlock stays dangerous (player's call,
     22.09): the man carrying the body stands in vacuum for a few
     seconds and his suit holds eight, so the burial can cost you the
     bearer. That is the price of the decision, not a bug. */
  static get EJECT_KARMA()   { return -3; }
  static get BURIAL_KARMA() { return  3; }
  /* How long a man needs on an unpowered cell door. Long enough that
     restoring power is a real save, short enough that ignoring the
     warning costs you the bounty. */
  static get ESCAPE_SECONDS() { return 25; }

  /* ── HOW LONG A SALVAGE TEAM HAS (update74) ───────────────
   *
   * Fifty seconds, written out in FIVE places in game.js — three
   * `?? 50` defaults, a `_wreckSecs` initialiser and a floor of 20 —
   * which is five chances to change four of them.
   *
   * Fifty is also too long, and that is the player's report: *„za dużo
   * mamy teraz czasu do namysłu"*. In fifty seconds a hold can be
   * solved like a Tetris board, at leisure, which is the opposite of
   * what a clock on a derelict is for. Thirty makes it a decision
   * about what to take; the floor stops a booby trap or a bad roll
   * from turning it into no decision at all.
   *
   * One number, one place. Both are tuning dials — expect to move them
   * once he has flown with them. */
  static get LOOT_SECONDS() { return 30; }
  static get LOOT_SECONDS_MIN() { return 15; }


  /* ── THE SHIP'S CAT (update45) ────────────────────────────
   *
   * A cat is a passenger with an opinion. Nobody gives it orders it
   * has to obey — though the player CAN send it to a compartment, and
   * that beats whatever it had planned — and it works down a short
   * list of its own priorities:
   *
   *   1. eat, if it is in the middle of eating
   *   2. hunt, if there is vermin aboard
   *   3. sit with a downed crewman  ← what it does most of the time
   *   4. find food, if it is hungry
   *   5. wander
   *
   * Priority 3 is the whole reason a cat is worth a pen. Rats appear
   * on maybe a fifth of jumps, so an animal that only hunted them
   * would sit idle for entire contracts; sitting with the wounded
   * gives it work in every fight, and it costs nothing to explain —
   * the animal is simply there when somebody is bleeding.
   */
  petTick(dt) {
    const cats = this.crew.filter(c => c.isPet && !c.dead);
    if (!cats.length) return;
    const H = (typeof HUNGER !== 'undefined') ? HUNGER : null;
    if (!H) return;

    cats.forEach(cat => {
      if (!cat.alive) return;

      /* THE STOMACH MOVED OUT (update47). Draining the meter, the
         starvation damage and the warnings used to be written right
         here, for cats only. The crew eat now, and a second copy of
         the same arithmetic for people is exactly the two-registers
         mistake this project keeps paying for — so all of it went to
         hungerTick, for every mouth aboard, and petTick is left with
         what it was always about: what a CAT does. */

      // ── 1. Mid-meal ── (the timer itself ticks in hungerTick)
      if (cat.busy) return;

      // A standing order from the player outranks the cat's own plans,
      // right up until it arrives.
      if (cat._ordered && cat._waypoints?.length) return;
      cat._ordered = false;

      // ── 2. Vermin aboard ──
      const prey = this.crew.find(c => c.isVermin && c.alive);
      if (prey) {
        if (cat.roomId === prey.roomId) return;    // the room brawl has it
        this._petSendTo(cat, prey.roomId);
        return;
      }

      // ── 3. Sit with the wounded ──
      const hurt = this.crew.find(c => c.isPlayer && c.down && !c.dead && c.inRoom !== false);
      if (hurt) {
        if (cat.roomId !== hurt.roomId) this._petSendTo(cat, hurt.roomId);
        return;
      }

      // ── 4. Hungry: go and find something ──
      if (cat.hunger < H.HUNGRY && this._startMeal(cat)) return;

      // ── 5. Wander ──
      cat._roamT = (cat._roamT ?? Utils.randFloat(3, 9)) - dt;
      if (cat._roamT <= 0) {
        cat._roamT = Utils.randFloat(6, 14);
        const room = Utils.pick(this.rooms);
        if (room && room.id !== cat.roomId) this._petSendTo(cat, room.id);
      }
    });
  }

  /** Walk the cat to a room, the same way any crew order works. */
  _petSendTo(cat, roomId) {
    const room = this.getRoomById(roomId);
    if (!room) return false;
    cat.moveToOnShip?.(this, room.cx, this.floorWalkY(room.floor, room.cy));
    return true;
  }

  /**
   * Start a meal if there is anything in the hold this mouth will eat.
   *
   * EGGS BEFORE RATIONS for the cat, deliberately: a spider egg eaten
   * is a fight that never happens, and the player is far happier to
   * lose one of those than a ration pack he was counting on. The crew
   * do not eat spider eggs. There are limits.
   */
  _startMeal(who) {
    const hold = this.cargo;
    if (!hold?.items?.length) return false;
    const egg = who.isPet
      ? hold.items.find(it => it.def?.tag === 'egg' && !it.damaged) : null;
    const ration = hold.items.find(it =>
      it.def?.tag === 'food' && !it.damaged && this.willEat(who, it));
    const meal = egg || ration;
    if (!meal) return false;
    who._meal = meal;
    this._startBusy(who, 'eat');
    return true;
  }

  /**
   * WILL THIS MOUTH TOUCH THIS BOX (update66)?
   *
   * One question, asked by the cat's own meal and by the player's FEED
   * order alike, so a hand can never be ordered to eat something he
   * would not have taken on his own.
   *
   * Today it has exactly one rule and one live consumer: THE CAT does
   * not eat vat greens. That matters — it is what keeps `meat` from
   * being a flag with nothing reading it, waiting for religions to
   * arrive. When crew beliefs land, they add rules HERE and nowhere
   * else.
   */
  /** The best box aboard this mouth will actually open, or null. */
  mealFor(who) {
    return this.cargo?.items?.find(it =>
      it.def?.tag === 'food' && !it.damaged && this.willEat(who, it)) || null;
  }

  /**
   * Why FEED would refuse, or null. The menu greys the row with this
   * and `feedCrew` refuses with it — the same shape as `bodyRefusal`,
   * and for the same reason: a row that looks live and then does
   * nothing is the bug both of them exist to prevent.
   */
  feedRefusal(who, item = null) {
    if (!who || who.dead) return 'nobody there';
    if (who.down) return `${who.name} is down — treat him first`;
    if (who.busy) return `${who.name} has his hands full`;
    if ((who.hunger ?? 100) >= 100) return `${who.name} is not hungry`;
    const meal = item || this.mealFor(who);
    if (!meal) return `nothing aboard ${who.name} will eat`;
    if (!this.willEat(who, meal)) return `${who.name} will not touch the ${meal.def.label}`;
    return null;
  }

  /** ONE door for every row of the crew menu, whoever it belongs to. */
  menuRefusal(person, act) {
    if (act === 'cell')   return this.cellRefusal(person);
    if (act === 'freeze') return this.freezeRefusal(person);
    if (act === 'thaw')   return person?.frozen ? null : 'he is not in a slab';
    return act === 'feed' ? this.feedRefusal(person) : this.bodyRefusal(person, act);
  }

  willEat(who, item) {
    if (!who || !item) return false;
    if (item.def?.tag === 'egg') return !!who.isPet;   // crew have limits
    if (item.def?.tag !== 'food') return false;
    if (who.isPet && item.def.meat === false) return false;
    return true;
  }

  /**
   * FEED THIS ONE, NOW (update66).
   *
   * A hungry man helps himself, which is right — but it means the last
   * box on the shelf goes to whoever got hungry first, and the player
   * never gets a say. This is the say: name a mouth, and he eats next.
   * Refuses out loud, like every other order.
   */
  feedCrew(who, item = null) {
    const why = this.feedRefusal(who, item);
    if (why) return { ok: false, message: why };
    const meal = item || this.mealFor(who);
    who._meal = meal;
    this._startBusy(who, 'eat');
    return { ok: true, message: `${who.name} is eating the ${meal.def.label}.` };
  }

  /* ══ ONE TIMER FOR EVERY ACTION THAT TAKES A MOMENT (update78) ══
   *
   * The player's rule: eating, bandaging and opening a medkit each
   * take a couple of seconds. They share ONE timer on the man doing
   * them, because the first thing any of them needs to ask is "are
   * your hands already full" — and three separate timers is three
   * places for that one question to be answered differently.
   *
   * `act` says what finishes when it runs out; `onId` is the man it is
   * being done TO, as an ID, because he can die, be carried away or go
   * out an airlock while the seconds run.
   */
  _startBusy(who, act, onId = null, secs = null) {
    if (!who) return false;
    who._busyT   = secs ?? ((typeof HUNGER !== 'undefined') ? HUNGER.EAT_SECONDS : 3);
    who._busyAct = act;
    who._busyOn  = onId;
    return true;
  }

  _cancelBusy(who) {
    if (!who) return;
    who._busyT = 0; who._busyAct = null; who._busyOn = null; who._meal = null;
  }

  _busyTick(dt) {
    this.crew.forEach(c => {
      if (!c || !(c._busyT > 0)) return;
      /* A MAN WHO DIED MID-ACTION FINISHES NOTHING. Checked here and
         not in each finisher, so a new action cannot forget it. */
      if (c.dead) { this._cancelBusy(c); return; }
      c._busyT -= dt;
      if (c._busyT > 0) return;
      const act = c._busyAct, onId = c._busyOn;
      c._busyT = 0; c._busyAct = null; c._busyOn = null;
      const on = onId ? this.crew.find(x => x && x.id === onId) : null;
      if (act === 'eat')    this._finishMeal(c);
      if (act === 'aid')    this._finishAid(c, on);
      if (act === 'medkit') this._finishMedkit(c, on);
    });
  }

  /* ══ MEDICAL SUPPLIES: ONE BOX, TWO PRICES (update78) ══════
   *
   * A bandage costs ONE dose and stops a man bleeding. A MEDKIT costs
   * TWO and puts him back on his feet. One item in the hold, so there
   * is nothing to tell apart on the shelf and no second icon — and the
   * decision is sharp, because the automatic bandaging eats the same
   * doses the player is hoarding to stand people up.
   */
  doseCount() {
    return (this.cargo?.items ?? [])
      .filter(it => it.def?.kind === 'heal')
      .reduce((n, it) => n + (it.qty ?? 1), 0);
  }

  hasDoses(n = 1) { return this.doseCount() >= n; }

  /** Spend `n` doses. All or nothing: it never half-pays. */
  spendDoses(n = 1) {
    if (!this.hasDoses(n)) return false;
    let left = n;
    const hold = this.cargo;
    (hold?.items ?? []).filter(it => it.def?.kind === 'heal').forEach(it => {
      if (left <= 0) return;
      const take = Math.min(left, it.qty ?? 1);
      left -= take;
      if ((it.qty ?? 1) > take) it.qty -= take;
      else hold.remove(it);
    });
    return true;
  }

  /** The bandage is on: the clock stops, and he is still on the floor. */
  _finishAid(medic, body) {
    if (!body || body.dead || !body.down) return;
    if (body._bandaged) return;
    if (!this.spendDoses(Ship.AID_DOSES)) return;   // somebody used the last one
    body._bandaged = true;
    body._bleedT   = 0;
    medic?.addXP?.('repair', 5);
    if (this.isPlayer && typeof UI !== 'undefined') {
      UI.notify(`${medic?.name ?? 'Somebody'} stopped ${body.name}'s bleeding — `
              + 'he still needs a medkit or the medbay.', 'good');
    }
  }

  /** The medkit is open: he is on his feet, and the box is two lighter. */
  _finishMedkit(medic, body) {
    if (!body || body.dead) return;
    if (!this.spendDoses(Ship.MEDKIT_DOSES)) return;   // supplies went elsewhere
    const floor = Math.round(body.maxHp * Ship.MEDKIT_SHARE);
    /* NEVER DOWNWARDS. A man at half health who takes a medkit is not
       pushed back to thirty percent — the dose is a floor, not a
       setting. */
    body.hp     = Math.max(body.hp, floor);
    body.state  = 'ok';
    body._bleedT = 0;
    body._bandaged = false;        // nothing left to stop
    body.bodyOrder = null;
    medic?.addXP?.('repair', 8);
    if (this.isPlayer && typeof UI !== 'undefined') {
      UI.notify(`${body.name} is back on his feet — ${Ship.MEDKIT_DOSES} doses gone.`, 'good');
    }
  }

  /** The meal is over: the item leaves the hold ONCE and feeds ONCE. */
  _finishMeal(who) {
    const meal = who._meal;
    who._meal = null;
    const hold = this.cargo;
    if (!meal || !hold?.items?.includes(meal)) return;   // somebody moved it
    const isEgg = meal.def?.tag === 'egg';
    /* THE MEAL SAYS WHAT IT IS WORTH (update66). Rations carry their
       own `hunger` now — there are four of them and no such thing as
       "the" ration to look up. Eggs and rats are not cargo, so they
       stay in HUNGER.FOOD where they always were: a split by KIND, not
       two copies of one number. */
    const food  = isEgg ? HUNGER.FOOD.spider_egg
                        : { hunger: meal.def?.hunger ?? 50, hp: 4 };
    /* A RATION PACK IS A STACK, not a parcel: one man eats ONE unit
       out of it and the rest stays on the shelf. Removing the whole
       item would throw away four meals to serve one. */
    if (!isEgg && (meal.qty ?? 0) > 1) meal.qty--;
    else hold.remove(meal);
    who.hunger = Utils.clamp((who.hunger ?? 0) + food.hunger, 0, 100);
    who.hp     = Math.min(who.maxHp, who.hp + food.hp);
    if (this.isPlayer && typeof UI !== 'undefined') {
      UI.notify(isEgg ? `${who.name} ate a spider egg.`
                      : `${who.name} ate a ration.`, isEgg ? 'good' : 'info');
    }
  }

  /* ── EVERY MOUTH ABOARD (update47) ────────────────────────
   *
   * One stomach loop for the crew and the cat alike. It drains the
   * meter, starves whoever hits zero, keeps the meal timers, and
   * lets a hungry CREWMAN reach for a ration by himself — the cat's
   * own meals are started by petTick, because for a cat eating sits
   * in a priority list against hunting and sitting with the wounded.
   *
   * A man eats where he stands. He does not walk to the hold: the
   * whole point of a ration pack is that you tear it open at your
   * post, and a gunner who abandoned his console to have lunch in
   * the middle of a fight would be a bug, not a feature.
   */
  hungerTick(dt) {
    const H = (typeof HUNGER !== 'undefined') ? HUNGER : null;
    if (!H) return;

    this.crew.forEach(c => {
      // A frozen man does not get hungry either (update77). Every
      // clock he carries is stopped, not just the one that kills him.
      if (!c || c.dead || c.frozen || !c.eats) return;

      // Mid-meal — for everybody, cat included. The timer itself is
      // `_busyTick`, which every timed action shares.
      if (c.busy && c._busyAct === 'eat') return;

      const rate = c.hungerPerSec ? c.hungerPerSec() : 0;
      if (!rate) return;
      c.hunger = Utils.clamp((c.hunger ?? 100) - rate * dt, 0, 100);

      if (c.hunger <= 0) {
        /* STARVATION IS A SLOPE, NOT A CLIFF. It takes the better
           part of three minutes at zero to kill, and the warning has
           been up since the meter hit STARVING — nobody loses a hand
           or an animal without having been told. */
        c.takeDamage?.(H.STARVE_HP_PER_SEC * dt, 'starvation');
        if (c.dead) {
          if (this.isPlayer && typeof UI !== 'undefined') {
            UI.notify(`${c.name} starved.`, 'alert');
          }
          return;
        }
      }
      if (c.hunger <= H.STARVING && !c._starveWarned) {
        c._starveWarned = true;
        if (this.isPlayer && typeof UI !== 'undefined') {
          UI.notify(`${c.name} is starving — there are rations in the hold.`, 'warn');
        }
      }
      if (c.hunger > H.HUNGRY) c._starveWarned = false;

      /* NOBODY OPENS A RATION WITHOUT BEING TOLD (update69).
       *
       * This line was the whole of the player's complaint: "jedzenie
       * jest dalej zjadane automatycznie a nie powinno". A hungry man
       * reached into the hold by himself, so the four rations, the
       * FEED order and the decision about what to carry were all
       * decoration — the hold emptied whether the player looked at it
       * or not.
       *
       * Eating is an ORDER now, like every other thing a crewman does
       * with his hands. The warning above still fires, so nobody
       * starves silently; what he does about it is his to decide.
       *
       * The CAT still feeds herself in `petTick`, and that is not an
       * inconsistency: you cannot order an animal to stop being
       * hungry. She is exactly why the meat/greens flag has a living
       * reader. */
    });
  }

  /** Is a cat sitting with this body? Bleeding out runs slower if so. */
  petVigilOver(body) {
    if (!body?.roomId) return false;
    return this.crew.some(c => c.isPet && c.alive && c.roomId === body.roomId);
  }

  update(dt) {
    if (this.destroyed) return;

    if (this.isDerelict) this.hatchNests(dt);
    else this.verminTick(dt);
    this.hungerTick(dt);
    this.petTick(dt);

    // Death animation
    if (this.hull <= 0) {
      this._deathTimer += dt;
      if (this._explosionTimer.tick(dt)) {
        const db = this.roomBounds();
        const rx = db.x + Utils.randFloat(0, db.w);
        const ry = db.y + Utils.randFloat(0, db.h);
        Particles.explosion(rx, ry, Utils.randFloat(0.5, 1.5));
      }
      if (this._deathTimer > 2.5) {
        this.destroyed = true;
      }
      return;
    }

    // ── Bodies: carrying, medbay healing, decay plague, ejection ──
    this._updateBodies(dt);

    // ── The carbonite: cells, and the men working the locks ──
    this.prisonerTick(dt);
    this._busyTick(dt);

    // ── A man sent to bag a body, arriving ──
    this.bagArrivals();

    // ── The bite and the egg case, both on the clock ──
    this.infectionTick(dt);

    // ── Anybody's prisoners, found by somebody else's boarders ──
    this.freeCaptives();

    // Sync crew presence into each system (bonuses, cyborg power, medbay)
    this.systems.forEach(sys => {
      // A medbay reads its OCCUPANTS (cat included); every other module
      // reads its OPERATORS. See medbayPatients (update54).
      sys.crew = sys.roomId
        /* A MEDBAY'S CREW IS ITS STAFF, NOT ITS PATIENTS (update78).
           This asked `medbayPatients` because the healing used to live
           in ShipSystem.update and needed the list — the healing is in
           Ship.update now, so what is left of `sys.crew` is what it is
           for every other module: who is WORKING it. A man lying on
           the table was counting as an operator, which among other
           things let a wounded Terra cyborg keep the module lit while
           he was unconscious on its floor. */
        ? this.crewOperating(sys.roomId)
        : [];
      // WHO IS AT THE CONSOLE (update43) — the only one whose skill
      // counts, and the only one who learns from the module's work.
      sys.consoleCrew = sys.roomId ? this.consoleOperator(sys.roomId) : null;
      sys.shipIsPlayer = this.isPlayer;   // so a system can talk to the UI
    });

    // Systems
    this.systems.forEach(sys => sys.update(dt));

    // FTL power flow: each system draws up to its DESIRED power,
    // limited by working (undamaged) levels and reactor budget.
    // → repairing a module automatically re-lights its bars.
    {
      let remaining = this.reactor.totalPower;
      this.systems.forEach(sys => {
        // Use the SAME cyborg-substitution rule as Reactor.distribute/
        // setPower (ShipSystem.reactorDraw). This loop used to subtract
        // the raw allocation, so a unit the cyborg had freed was never
        // actually available here — the last modules in the list (the
        // medbay, typically) silently got starved and would not switch
        // on no matter how many times you clicked their pips.
        let want = Math.min(sys.desiredPower, sys.workingLevels);
        while (want > 0 && sys.reactorDraw(want) > remaining) want--;
        sys.power  = want;
        remaining -= sys.reactorDraw(want);
      });
    }

    /* THE SLABS ANSWER TO THE POWER THIS FRAME (update77), so this
       runs AFTER the flow above and not with the other per-frame
       ticks. Put before it, `carboniteTick` read last frame's budget
       and a man whose slab had just gone cold stayed under for one
       more frame — harmless on its own, and exactly the kind of
       one-frame lie that turns into "sometimes he does not wake up"
       the moment anything else reads the same number. */
    this.carboniteTick();

    // Repair Bay: powered nanobots slowly mend every damaged system.
    // Rate ≈ half a crew member per powered level (1 level / ~17s).
    const rbay = this.getSystem('autorepair');
    if (rbay) {
      const rate = rbay.effectivePower() * 0.5;
      if (rate > 0) {
        this.systems.forEach(sys => {
          if (sys !== rbay && sys.damagedLevels > 0) sys.repair(dt * rate);
        });
      }
    }

    this._reallocWeaponPower();   // damaged weapon module instantly de-powers ITS gun
    this.weapons.forEach((w, i) => {
      if (!w) return;
      // OPERATOR RULE: a gun charges only while a crew member stands
      // in ITS weapon module (slots without a room fall back to any
      // weapons-room operator — legacy boss overflow).
      const room   = this.weaponRoomFor(w);
      const manned = room
        ? this.crewOperating(room.id).length > 0
        : this.weaponRooms.some(r => this.crewOperating(r.id).length > 0);
      /* FORCED FIRE (update49) adds to the GUNNER's reduction and
         is then clipped by the same 75% ceiling inside the gun —
         a second, separate cap here would be a second copy of a
         limit that already exists. */
      const chipFire = (this.isPlayer && typeof Commander !== 'undefined')
        ? Commander.shipBonus('weaponCharge') : 0;
      w.update(dt, this.weaponCrewBonusFor(i) + chipFire, manned);
    });

    // Hit flashes fade; wrecked modules smoke so a broken ship LOOKS
    // broken even when you are not reading the power bar.
    this.rooms.forEach(room => {
      if (room._hitFlash > 0) room._hitFlash = Math.max(0, room._hitFlash - dt * 3.5);
      const sys = room.system;
      if (sys && sys.damagedLevels > 0 && Math.random() < dt * (1.2 * sys.damagedLevels)) {
        Particles.damageSmoke?.(room.cx + Utils.randFloat(-14, 14), room.cy);
      }
    });

    // Crew update and room assignment
    this.crew.forEach(c => {
      if (c.dead) return;
      /* ── A MAN IN A SLAB IS NOT IN A ROOM (update77) ────────
       *
       * ONE guard, here, and it is what makes carbonite mean anything:
       * he does not walk, does not fight, does not breathe, cannot be
       * set on fire and cannot be picked as the man at a console —
       * because everything that finds people finds them BY ROOM, and
       * this loop is the only thing that puts him in one.
       *
       * The alternative was `if (c.frozen) return;` in a dozen loops,
       * and the thirteenth loop written next month without one. */
      if (c.frozen) return;
      /* FIGHTS BELONG IN ROOMS, NOT IN THE WALLS (update42).
         `roomId` was never cleared when a crew member stepped OUT of
         every room rectangle — and there is real floor that belongs to
         no room: the 28px elevator trunk. Waiting for a cabin or riding
         one, a boarder kept the stale id of the room he had left, so
         melee matched him against someone on the other side of a wall,
         the brawl cancelled his ride, and if he lost, the corpse lay in
         the shaft while bodiesInRoom still reported him inside. Melee
         and the body loops now require you to actually BE in a room.

         Resolved BEFORE c.update, not after: melee runs inside update
         and has to judge where the man is standing NOW, not where he
         was last frame — and on his very first frame aboard there is
         no last frame at all. */
      const at = this.rooms.find(r => r.contains(c.x, c.y));
      c.inRoom = !!at;
      if (at) c.roomId = at.id;

      c.update(dt, this);

      // …and again afterwards, so everything that reads the roster
      // between frames sees where he ended up.
      const now = this.rooms.find(r => r.contains(c.x, c.y));
      c.inRoom = !!now;
      if (now) c.roomId = now.id;
    });
    /* CORPSES STAY (update40).
     *
     * This line was `filter(c => !c.dead)` — unconditional, and run at
     * the end of every single update, in the SAME call in which
     * CrewMember.update flips dying → dead. `_updateBodies` runs
     * BEFORE the crew loop, so it never once saw a body that had just
     * died, and the body was gone by the next frame.
     *
     * That quietly deleted an entire subsystem the game keeps telling
     * the player about: carrying the dead to an airlock, the
     * "…body is DECAYING — eject it before the crew gets sick!" warning
     * in markCombatStart, the corpse plague that spreads from a rotting
     * body to everyone in the room, the ☠/☣ head markers in
     * CrewMember.draw and the DECAYING tag in the crew panel. None of
     * it could ever fire. (The wounded half still worked, which is what
     * made the contradiction so easy to miss.)
     *
     * A body now lies where it fell until somebody carries it out —
     * `_updateBodies` removes the EJECTED, and that is the only way off
     * the ship. Animals are the exception: nobody holds a service for a
     * spider, and a hull that had been cleared of vermin should not
     * carry a list of little corpses for the rest of the run.
     *
     * Everything that counts people already filters `!c.dead`
     * (_playerCrewAliveCount, returnFromRun, crewInRoom, occupantsOf,
     * takenStationSlots, the wreck-cleared check), so keeping them in
     * the roster changes no count.
     */
    this.crew = this.crew.filter(c => !(c.dead && c.isBeast));

    // O2
    this.oxygen.update(dt, this);

    // Fires
    this.fires.update(dt, this);

    // Breaches
    this.breaches.update(dt);

    // Elevators
    this.elevators.update(dt);

    // Doors
    this.doors.forEach(d => d.update(dt, this.crew));

    // Rooms with an open airlock are venting to space
    this.rooms.forEach(room => {
      room.isVacuum = this.doors.some(d =>
        d.isAirlock && d.open && d.roomA === room.id);
    });

    // Shield fade
    this._shieldAlpha = Math.max(0, this._shieldAlpha - dt * 2);

    // Shield pulse
    if (this._shieldPulse) {
      this._shieldPulse.update(dt);
      if (this._shieldPulse.done) this._shieldPulse = null;
    }
  }

  // ── Draw ─────────────────────────────────────────────────

  /** Bounding box of all rooms (the visual ship body) */
  roomBounds() {
    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    this.rooms.forEach(r => {
      minX = Math.min(minX, r.x);      minY = Math.min(minY, r.y);
      maxX = Math.max(maxX, r.x + r.w); maxY = Math.max(maxY, r.y + r.h);
    });
    return { x: minX, y: minY, w: maxX - minX, h: maxY - minY };
  }

  /* ── AN EGG CASE IS A THING IN A ROOM (update69) ───────────
   *
   * It used to exist only as a line in the hold, which is how the
   * player ended up with a crewman who vanished and a crate that
   * appeared: "jezeli zalogant zamieni sie w jajko to one powinno byc
   * na statku w formie graficznej, nie tylko w ladowni".
   *
   * There is still only ONE of them — the cargo item. This draws that
   * item at the spot stored on it, so selling it, dumping it or
   * letting the cat at it takes the thing off the deck as well, with
   * nothing to keep in step.
   */
  /** One path covering every module, grown by the hull margin.
   *  `inset` shrinks it, which is how the rim is drawn (see draw). */
  _hullPlatePath(ctx, inset = 0) {
    const M = HULL_GRID.MARGIN - inset;
    const R = Math.max(2, HULL_GRID.TILE + 4 - inset);
    ctx.beginPath();
    this.rooms.forEach(r => {
      ctx.roundRect(r.x - M, r.y - M, r.w + M * 2, r.h + M * 2, R);
    });

    /* THE LIFT TRUNKS ARE INSIDE THE HULL, so the plate has to cross
       them. A shaft is SHAFT_W wide and the modules either side are
       grown by MARGIN — 30 against 2x10, which leaves a ten-pixel
       notch bitten out of the hull at every lift. Harmless while the
       plate was one rectangle over the bounding box; visible the
       moment it started following the modules. */
    const b = this.roomBounds();
    const half = HULL_GRID.SHAFT_W / 2 + M;
    (this.elevators?.shafts ?? []).forEach(sh => {
      ctx.roundRect(sh.x - half, b.y - M, half * 2, b.h + M * 2, R);
    });
  }

  /* ── THE DUCT, DRAWN (update73) ───────────────────────────
   *
   * It has to be SEEN, and that is not decoration — it is the whole
   * reason this is safe to build. Rats and spiders are moving into the
   * duct, and a threat the player cannot see is a threat he does not
   * know he has. The same rule the karma wall is waiting on: a
   * consequence is shown, not reported.
   *
   * It does a second job for free. DECK_GAP is 0 now, so without this
   * band two decks meet on a hairline and a two-deck hull reads as one
   * tall grid. The duct IS the seam between decks.
   *
   * Drawn after the rooms so the grille sits over the floor plate, and
   * before the doors, which are taller than it and should cross it.
   */
  _drawVents(ctx) {
    const H = HULL_GRID.VENT_H;
    this.rooms.forEach(room => {
      const x = room.x, y = room.ventY, w = room.w;
      ctx.fillStyle = 'rgba(6,9,16,0.92)';
      ctx.fillRect(x, y, w, H);

      // Grille: short ticks, one every other tile, so it reads as a
      // duct rather than as a shadow under the ceiling.
      ctx.strokeStyle = this.isPlayer ? 'rgba(77,184,255,0.22)'
                                      : 'rgba(255,90,90,0.20)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      for (let tx = x + HULL_GRID.TILE; tx < x + w - 1; tx += HULL_GRID.TILE * 2) {
        ctx.moveTo(tx + 0.5, y + 2);
        ctx.lineTo(tx + 0.5, y + H - 2);
      }
      ctx.stroke();

      // The lip the deck above stands on.
      ctx.strokeStyle = this.isPlayer ? 'rgba(30,58,92,0.9)' : 'rgba(92,30,30,0.9)';
      ctx.beginPath();
      ctx.moveTo(x, y + H + 0.5);
      ctx.lineTo(x + w, y + H + 0.5);
      ctx.stroke();
    });
  }

  _drawEggs(ctx) {
    const eggs = (this.cargo?.items ?? []).filter(it =>
      it.def?.tag === 'egg' && it.meta && typeof it.meta === 'object' &&
      it.meta.roomId != null);
    if (!eggs.length) return;
    const t = (typeof performance !== 'undefined' ? performance.now() : 0) * 0.003;
    eggs.forEach(egg => {
      const room = this.getRoomById(egg.meta.roomId);
      if (!room) return;
      const x = egg.meta.x ?? room.cx;
      const y = egg.meta.y ?? (room.cy + 6);
      // The nearer it is to splitting, the harder it moves.
      const left = Utils.clamp((egg.meta.hatchT ?? EGG_SECONDS) / EGG_SECONDS, 0, 1);
      const beat = 1 + 0.12 * (1 - left) * Math.sin(t * (2 + (1 - left) * 6));
      ctx.save();
      ctx.globalAlpha = 0.85;
      ctx.fillStyle = 'rgba(30,60,26,0.9)';
      ctx.beginPath();
      ctx.ellipse(x, y, 7 * beat, 9 * beat, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = egg.def.col || '#9fff7a';
      ctx.lineWidth = 1.5;
      ctx.stroke();
      ctx.globalAlpha = 1;
      ctx.fillStyle = egg.def.col || '#9fff7a';
      ctx.font = '9px monospace';
      ctx.textAlign = 'center';
      ctx.fillText('◓', x, y + 3);
      ctx.restore();
    });
  }

  draw(ctx) {
    // Cloaking field: powered cloak renders the whole ship as a
    // shimmering phantom (visual feedback for the evasion bonus)
    const cloakSys = this.getSystem('cloaking');
    const cloaked  = !!(cloakSys && cloakSys.cloakActive);
    if (cloaked) {
      ctx.save();
      const t = (typeof performance !== 'undefined' ? performance.now() : 0) * 0.004;
      ctx.globalAlpha = 0.55 + Math.sin(t) * 0.12;
    }

    /* ── THE PLATE FOLLOWS THE MODULES (update73) ───────────
     *
     * It used to be ONE rounded rectangle around `roomBounds()`, which
     * was fine while every hull in the game was a solid block. The
     * moment Bastet grew a spur on her upper deck the plate covered
     * the empty square beneath it, and the starter ship looked like a
     * ship with a hole in her — a bug, not a silhouette.
     *
     * So the plate is the UNION of the modules. Each room contributes
     * its own rounded rectangle to one path; overlapping fills merge
     * under nonzero winding, so what is left is an outline that walks
     * round the actual hull, notches and spurs included.
     *
     * The rim is done by filling twice rather than stroking, because
     * stroking a path of overlapping rectangles draws every internal
     * edge as well: fill the union in the rim colour, then fill it
     * again three pixels smaller in the plate colour.
     *
     * The 14 that used to be written here was MARGIN before MARGIN was
     * a tile wide. One more copy of a number the grid already owned. */
    const b = this.roomBounds();
    this._hullPlatePath(ctx, 0);
    ctx.fillStyle = this.isPlayer ? '#1e3a5c' : '#5c1e1e';
    ctx.fill();
    this._hullPlatePath(ctx, 3);
    ctx.fillStyle = 'rgba(10,14,26,0.97)';
    ctx.fill();

    // Engine glow at rear
    const engX = this.isPlayer ? b.x - 14 : b.x + b.w + 14;
    const g = ctx.createRadialGradient(engX, b.y + b.h/2, 2, engX, b.y + b.h/2, 30);
    g.addColorStop(0, this.isPlayer ? 'rgba(26,255,140,0.6)' : 'rgba(255,80,40,0.6)');
    g.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = g;
    ctx.fillRect(engX - 30, b.y + b.h/2 - 30, 60, 60);

    // Rooms (with systems, O2, fire, breach overlays)
    this.rooms.forEach(room => {
      if (room.system) {
        room.system.draw(ctx);
      } else {
        // Empty module — floor tile + visible frame (crew quarters,
        // or an enemy hull slot with no system installed)
        this._drawEmptyRoom(ctx, room);
      }

      // O2 overlay
      const ro = this.oxygen.getRoom(room.id);
      if (ro) ro.draw(ctx, room.x, room.y, room.w, room.h);

      // HIT FLASH — a shell landing here lights the compartment for a
      // moment. Without it a hit on a far room is easy to miss entirely.
      if (room._hitFlash > 0) {
        ctx.fillStyle = `rgba(255,255,255,${0.55 * room._hitFlash})`;
        ctx.fillRect(room.x, room.y, room.w, room.h);
        ctx.strokeStyle = `rgba(255,90,110,${room._hitFlash})`;
        ctx.lineWidth = 2;
        ctx.strokeRect(room.x + 1, room.y + 1, room.w - 2, room.h - 2);
      }
    });

    // The ceiling ducts — over the floor plates, under the doors.
    this._drawVents(ctx);

    // Elevators
    this.elevators.draw(ctx);

    // Doors
    this.doors.forEach(d => d.draw(ctx));

    // An egg case lies where its host fell — under the crew, like a body.
    this._drawEggs(ctx);

    // Crew (particles below crew)
    Particles.draw(ctx, 0);
    this.crew.forEach(c => c.draw(ctx));

    // Fires
    this.fires.draw(ctx);

    // Breaches
    this.breaches.draw(ctx);

    /* THE GUN STRIPS STAY SOLID UNDER A CLOAK (update54).
       Everything from here up was drawn through the cloak's pulsing
       globalAlpha, the charge boxes on the mounts included — so while
       either side was cloaked the one readout that says "how long until
       that gun fires" faded in and out at a third of its brightness and
       READ AS FROZEN. The guns were charging the whole time (nothing in
       the engine ties charge to a cloak, and section 173 nails that
       down); the player simply could not see them move. The field hides
       the hull, not its gunnery clock. */
    const cloakAlpha = ctx.globalAlpha;
    if (cloaked) ctx.globalAlpha = 1;
    this._drawWeaponMounts(ctx);
    if (cloaked) ctx.globalAlpha = cloakAlpha;

    // Shield ring
    this._drawShield(ctx);

    // Hull damage glow
    if (this.hull / this.hullMax < 0.35) {
      const b = this.roomBounds();
      const alpha = (0.35 - this.hull / this.hullMax) * 0.5;
      ctx.fillStyle = `rgba(255,45,68,${alpha})`;
      ctx.fillRect(b.x - 14, b.y - 14, b.w + 28, b.h + 28);
    }

    if (cloaked) {
      ctx.restore();
      // faint distortion ring so you can still find the hull outline
      const b = this.roomBounds();
      ctx.strokeStyle = 'rgba(120,200,255,0.25)';
      ctx.lineWidth = 2;
      ctx.strokeRect(b.x - 10, b.y - 10, b.w + 20, b.h + 20);
    }
  }

  /** Empty room: tiled floor, subtle grid line, clear frame */
  _drawEmptyRoom(ctx, room) {
    /* The INTERIOR, not the module (update73) — the same rule
       `_fitSystemToRoom` applies to a fitted module. A bay's floor
       plate stops where the ceiling duct begins, or the grille ends up
       drawn on top of a floor that is pretending to be up there. */
    const x = room.x, y = room.floorTop, w = room.w, h = room.floorH;
    const tile = Assets.has('room_default') ? Assets.get('room_default') : null;
    if (tile) {
      ctx.save();
      ctx.globalAlpha = 0.8;
      Assets.tileRect(ctx, tile, x, y, w, h, 48);
      ctx.restore();
    } else {
      ctx.fillStyle = 'rgba(16,22,38,0.9)';
      ctx.fillRect(x, y, w, h);
    }

    // Frame — always visible so the module reads as a room
    ctx.strokeStyle = 'rgba(110,135,175,0.55)';
    ctx.lineWidth = 1.5;
    ctx.strokeRect(x + 0.5, y + 0.5, w - 1, h - 1);
  }

  /**
   * Guns sit ON the hull, along the top edge, spread across its width —
   * they used to float off the nose in a vertical stack, which read as a
   * detached UI widget rather than as part of the ship.
   */
  _drawWeaponMounts(ctx) {
    const b = this.roomBounds();
    const mounted = this.weapons.filter(Boolean);
    if (!mounted.length) return;

    // Space the mounts by whichever is wider — the gun or its charge
    // strip — so an 18-second cannon's boxes never run into its neighbour.
    const GW = 44, GAP = 14;
    const widths = mounted.map(w => Math.max(GW, w.chargeStripWidth?.() ?? GW));
    const total = widths.reduce((a, b) => a + b, 0) + (mounted.length - 1) * GAP;
    // Centre the row on the hull; if the hull is narrow, start at its edge.
    const startX = Math.round(b.x + Math.max(6, (b.w - total) / 2));
    // Clear of the plating: the charge boxes hang under the gun, so
    // a tighter offset put them straight on top of the hull.
    const y = Math.round(b.y - 42);
    const dir = this.isPlayer ? 1 : -1;      // point at the enemy

    let gx = startX;
    mounted.forEach((w, i) => {
      // draw() centres itself on the 44px gun box, so offset by the
      // difference when the strip is the wider of the two.
      w.draw(ctx, gx + Math.round((widths[i] - GW) / 2), y, false, dir);
      gx += widths[i] + GAP;
    });
  }

  _drawShield(ctx) {
    if (this._shieldAlpha <= 0 && this.shieldBars <= 0) return;
    const b   = this.roomBounds();
    const cx  = b.x + b.w / 2;
    const cy  = b.y + b.h / 2;
    const rx  = b.w * 0.68 + 20;
    const ry  = b.h * 0.68 + 20;
    const alpha = Math.max(this._shieldAlpha, this.shieldBars > 0 ? 0.3 : 0);

    ctx.save();
    ctx.globalAlpha = alpha;

    // Shield rings — layered strokes instead of shadowBlur (GPU-cheap)
    for (let ring = 0; ring < this.shieldBars; ring++) {
      // Soft outer glow: wide translucent stroke
      ctx.strokeStyle = 'rgba(26,140,255,0.18)';
      ctx.lineWidth   = 7;
      ctx.beginPath();
      ctx.ellipse(cx, cy, rx + ring * 8, ry + ring * 8, 0, 0, Math.PI * 2);
      ctx.stroke();
      // Crisp core line
      ctx.strokeStyle = '#4db8ff';
      ctx.lineWidth   = 2;
      ctx.beginPath();
      ctx.ellipse(cx, cy, rx + ring * 8, ry + ring * 8, 0, 0, Math.PI * 2);
      ctx.stroke();
    }
    // Hit flash ring
    if (this._shieldAlpha > 0.3) {
      ctx.strokeStyle = '#bfe8ff';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.ellipse(cx, cy, rx + 4, ry + 4, 0, 0, Math.PI * 2);
      ctx.stroke();
    }
    ctx.restore();
  }

  // ── Serialise ────────────────────────────────────────────

  serialise() {
    return {
      layoutKey: this.layoutKey,
      hull: this.hull,
      // Systems serialised BY INDEX — layouts are deterministic, and a
      // ship can carry several systems of the same type (weapon modules).
      // Save the DESIRED allocation, not the momentary one: a module
      // that happened to be shot out when we jumped would otherwise
      // come back permanently switched off after repairs.
      systems: this.systems.map(s => ({
        type: s.type, level: s.level, power: Math.max(s.power, s.desiredPower ?? 0),
      })),
      weapons: this.weapons.map(w => w ? { defKey: w.defKey, slot: w.slot, roomId: w.roomId ?? null } : null),
      // `weaponCargo` is NOT written any more (update75) — a boxed gun
      // is a crate in `cargo`, like every other thing aboard.
      cargo: this.cargo ? this.cargo.serialise() : null,
      extraModules: [...(this._extraModules ?? [])],
      prisoners: this.prisoners.map(p => ({ ...p })),
      reactor: this.reactor.level,
    };
  }

  static deserialise(data, isPlayer, wx, wy) {
    const ship = new Ship(data.layoutKey, isPlayer, wx, wy);
    ship.hull  = data.hull;
    ship.reactor.level = data.reactor;

    // Re-apply purchased modules IN ORDER before restoring systems so
    // the systems array lines up index-for-index with the save.
    (data.extraModules ?? []).forEach(e => {
      if (typeof e === 'string') ship.addModule(e);
      else ship.addModuleAt(e.type, e.roomId) || ship.addModule(e.type);
    });

    data.systems.forEach((sd, i) => {
      const sys = ship.systems[i];
      // `systemType` so a hull saved with a 'brig' still lines up with
      // the carbonite bay the modules loop above just rebuilt.
      if (!sys || sys.type !== systemType(sd.type)) return;   // layout mismatch guard
      if (sd.type === 'reactor') return;  // pips derive from module level
      sys.level = sd.level; sys.power = sd.power; sys.desiredPower = sd.power;
    });
    /* Prisoners ride home in the hull's record. A save written before
       the brig existed simply has none. */
    ship.prisoners = (data.prisoners ?? []).map(p => ({
      id: p.id, name: p.name, bounty: p.bounty ?? 0, escapeT: 0, warned: false,
    }));

    // Saves written before the grid hold existed simply have no `cargo`
    // key — those ships keep the empty grid the constructor built.
    if (data.cargo && typeof CargoGrid !== 'undefined') {
      ship.cargo = CargoGrid.deserialise(data.cargo);
    }

    /* ── THE OLD RACK, EMPTIED INTO THE HOLD (update75) ──────
     *
     * A save written before the rack was deleted carries `weaponCargo`:
     * gun keys with no crate anywhere. Box each one now.
     *
     * AFTER the hold is restored, not before — boxing into the empty
     * grid the constructor built would put the crates somewhere that is
     * thrown away two lines later, and the guns would be gone with no
     * error anywhere to say so.
     *
     * A gun that will not fit is SAID OUT LOUD. The alternative is to
     * keep a second list alive to carry it, which is the exact thing
     * being deleted. */
    (data.weaponCargo ?? []).forEach(key => {
      if (ship.boxWeapon(key)) return;
      const label = (typeof WEAPON_DEFS !== 'undefined' && WEAPON_DEFS[key]?.label) || key;
      if (typeof UI !== 'undefined') {
        UI.notify?.(`${label} had no crate and the hold is full — it was left at the dock.`, 'warn');
      }
    });

    ship.weapons = [];
    data.weapons.forEach(wd => {
      if (wd) {
        ship.installWeapon(wd.defKey, wd.slot);
        /* A SAVE FROM BEFORE update60 carries no roomId; installWeapon
           has just stamped the positional one, which IS what that save
           meant. A newer save overrides it with the bay the gun was
           really in. */
        if (wd.roomId && ship.weapons[wd.slot]) ship.weapons[wd.slot].roomId = wd.roomId;
      }
    });

    return ship;
  }
}

/* The grid is the contract between the code and the art kit — the
   brief that the module, shaft, engine and prow tiles are cut to reads
   these numbers, so they have to be reachable from a test. */
if (typeof window !== 'undefined') {
  window.HULL_GRID = HULL_GRID;
  window.buildHull = buildHull;
}
