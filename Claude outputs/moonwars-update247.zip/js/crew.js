/* ============================================================
   MOON WARS — crew.js
   Crew member system.
   Skills, XP, pathfinding, task assignment, combat.
   Mirrors FTL crew mechanics: independent skill levelling,
   3 mastered skills max per crew member, star rating display.
   ============================================================ */

'use strict';

// ── Skill definitions ─────────────────────────────────────

const SKILL_DEFS = {
  piloting:   { label: 'Piloting',   color: '#ffd700', xpPerLevel: [50,150] },
  weapons:    { label: 'Weapons',    color: '#ff7c20', xpPerLevel: [50,150] },
  engines:    { label: 'Engines',    color: '#1aff8c', xpPerLevel: [50,150] },
  /* ONE SKILL FOR BOTH KINDS OF MENDING (update230, jj: „naprawianie dziur robimy jako
     naprawa"). A hole in the plating used to train its own skill, `breach`, which did
     nothing else — a man who had spent a run patching holes was no better at a broken
     module, and the sheet carried two rows for one trade. Patching is repair work now:
     it runs off `repair` and pays into it. The freed row is CRAFTING, which the kitchen
     and the workshop will use (jj: „w przyszłości dołożymy moduły kuchni do jedzenia
     i coś do robienia rzeczy dla załogi, broni itp"); nothing trains it yet. */
  repair:     { label: 'Repair',     color: '#4db8ff', xpPerLevel: [50,150] },
  firefight:  { label: 'Firefight',  color: '#ff2d44', xpPerLevel: [50,150] },
  crafting:   { label: 'Crafting',   color: '#cc44ff', xpPerLevel: [50,150] },
  shields:    { label: 'Shields',    color: '#1a8cff', xpPerLevel: [50,150] },
  // HAND-TO-HAND ONLY. Not gunnery, not defence — see meleeDamage().
  combat:     { label: 'Combat',     color: '#ff4444', xpPerLevel: [50,150] },
};

/* What the cat actually has. Hand to hand and
   nothing else: it cannot man a console, so a piloting row on its
   sheet is a number that can never move. */
const BEAST_SKILLS = ['combat'];

const MAX_SKILL_LEVEL = 3;

/* ── RANK IS THE SUM OF THE SQUARES (update52) ────────────────
 *
 * Eight skills, three levels each: twenty-four squares a crewman can
 * fill, and one rank for each of them plus the one he starts with.
 * There is NO second number here — a crewman's rank is COMPUTED from
 * his skill sheet every time it is asked, so it cannot drift out of
 * step with the sheet the way a stored `level` field would.
 *
 * update51 and earlier capped mastery at three skills per person
 * (`MAX_MASTERED`). That cap is GONE: it made 24 squares unreachable,
 * and with the promotion ladder now reading the sum directly, an
 * unreachable ceiling would mean the top eleven ranks and the last six
 * squares of every CPU board were decoration. A veteran who has flown
 * long enough really can end up knowing the whole ship.
 *
 * Twenty-five names, indexed by the sum. Do not reorder.
 */
const RANKS = [
  'Recruit',                //  0
  'Private',                //  1
  'Private First Class',    //  2
  'Specialist',             //  3
  'Corporal',               //  4
  'Senior Corporal',        //  5
  'Sergeant',               //  6
  'Senior Sergeant',        //  7
  'Staff Sergeant',         //  8
  'Warrant Officer',        //  9
  'Senior Warrant Officer', // 10
  'Chief Warrant Officer',  // 11
  'Second Lieutenant',      // 12
  'Lieutenant',             // 13
  'Captain',                // 14
  'Major',                  // 15
  'Lieutenant Colonel',     // 16
  'Colonel',                // 17
  'Commodore',              // 18
  'Rear Admiral',           // 19
  'Vice Admiral',           // 20
  'Admiral',                // 21
  'Grand Admiral',          // 22
  'High Lord',              // 23
  'Master Lord',            // 24
];

/** The highest rank index there is — and the top commander level. */
const MAX_RANK = RANKS.length - 1;      // 24

/**
 * A crew record's rank level: how many skill squares are filled.
 * Takes a serialised record OR a live CrewMember — both carry
 * `skills`, and this is read from nothing else.
 */
function rankLevelOf(rec) {
  let n = 0;
  Object.values(rec?.skills || {}).forEach(s => {
    n += Utils.clamp(s?.level ?? 0, 0, MAX_SKILL_LEVEL);
  });
  return Math.min(n, MAX_RANK);
}

/** The name for a rank level. */
function rankName(level) {
  return RANKS[Utils.clamp(Math.round(level ?? 0), 0, MAX_RANK)];
}

/* THE STAR IS GONE (update96). One star in two colours stood for all
   twenty-five ranks; every rank has its own insignia now
   (`Renderer.drawRankInsignia`), read off the same `rankLevelOf`. */

/* Melee constants. Kept here rather than inline so the room brawl and
   an ordered duel cannot drift apart again — they used to hit for
   7+lvl*3 and 10*(1+lvl*0.3) respectively, and only one of them taught
   the man anything. */
const MELEE_BASE_DAMAGE  = 7;
/* CRITICAL HITS (update173, jj: "jak ktoś wejdzie z dobrą bronią i ma
   specjalizację plus bonusy to robi miazgę"). Per level of the skill,
   plus a share for a man whose corporation trains that skill; capped. */
const CRIT = { PER_LEVEL: 0.08, SPEC: 0.06, MAX: 0.35 };

/* ── XP RATES — ONE SOURCE OF TRUTH (update43) ────────────────
 *
 * These eight numbers used to be bare literals scattered across six
 * files (ship.js, combat.js, systems.js, breach.js and two here), and
 * nobody could see them side by side. Measured against a real fight
 * they turned out to differ by a factor of SEVEN for no reason anyone
 * had chosen: a gunner mastered `weapons` in ONE fight (168 XP), while
 * `breach` needed some five hundred seconds of patching — about a
 * hundred hull breaches — and was therefore unreachable in practice.
 *
 * A skill costs 50 + 150 = 200 XP end to end. These rates are tuned so
 * that every skill takes roughly EIGHT TO TEN fights of dedicated work,
 * update52 deleted the three-per-person mastery cap that paragraph
 * was written for — see RANKS above. The rates below stand.
 *
 * Per-shot / per-event unless the comment says per second.
 * Change a number HERE — never at a call site.
 *
 * MEASURED (tools/xp probe, 8 fights, one dedicated operator each):
 * weapons 8.4 fights to master, repair 7.0, engines 11.8, piloting 12.5.
 * `firefight` and `breach` are not fights-to-master questions — those
 * jobs are rare and opportunistic — so they are set by WORK TIME
 * instead: 40 s of firefighting, 33 s of patching.
 * `shields` is the LEAST certain number here: its XP arrives one layer
 * at a time and only while somebody is stripping your bubble, so it
 * swings wildly between fights. Revisit it after real play. */
/* update51: EVERY rate DOUBLED. The measurements above stand — they
   are what the doubling is a reaction to. Mastery cost eight to ten
   fights of dedicated work and the commander's level 8 was four full
   Apophis runs out, so a player never saw the top of either tree.
   Doubling halves that WITHOUT changing the shape of the curve: the
   relative worth of a dodge against a patched breach is untouched, so
   which job pays best has not moved. Halve the fights-to-master
   numbers in the comment above to read the new pace. */
const XP_RATES = {
  weapons:   2.0,    // per shot from a manned gun      (update51: was 1.0)
  piloting:  16,     // per dodge, pilot at the helm    (update51: was 8)
  engines:   16,     // per dodge, hand at the drive    (update51: was 8)
  shields:   16,     // per recharged layer             (update51: was 8)
  repair:    0.5,    // PER SECOND of repairing — patching too, since update230
  firefight: 10.0,   // PER SECOND of firefighting      (update51: was 5.0)
  /* CRAFTING pays per thing made (update230). Nothing makes anything yet — the
     kitchen and the workshop are jj's next modules — but a skill with no rate is a
     skill nobody can train, and the table is where that decision belongs. */
  crafting:  6.0,
  combat:    20,     // per melee swing                 (update51: was 10)
};

// ── Names pool ────────────────────────────────────────────

/* NINETY-SIX NAMES (update93a). Thirty-two, drawn per hull, meant the
   same name kept turning up on both sides of a fight — "Vox" at our
   gun and "Vox" in their cell. The pool is three times bigger, and
   every name is now drawn against the names IN PLAY (CrewMember.
   namesInPlay — our hull, theirs, the barracks), not just the hull it
   lands on. */
const CREW_NAMES = [
  'Orion','Vega','Lyra','Atlas','Nova','Rex','Juno','Titan',
  'Zara','Cass','Drake','Mira','Pyx','Sol','Echo','Rigel',
  'Cora','Dax','Iris','Mars','Nyx','Pax','Quinn','Rho',
  'Sable','Talon','Uma','Vox','Wren','Xeno','Yuki','Zeb',
  'Frost','Blaze','Storm','Arc','Ash','Bryn','Cato','Dara',
  'Eli','Faye','Gale','Hale','Ilse','Jett','Kade','Lark',
  'Milo','Nash','Oona','Pike','Rafe','Sage','Tess','Ulf',
  'Vale','Wade','Yara','Zane','Ada','Bex','Cyr','Dov',
  'Ember','Fenn','Gus','Hux','Ivo','Jace','Kit','Lux',
  'Mace','Nell','Odo','Pia','Reno','Silas','Tycho','Una',
  'Vic','Wolf','Xan','Yves','Zola','Bram','Cleo','Dune',
  'Enzo','Flint','Gaia','Hugo','Ines','Jory','Kael','Lior',
];

/* HER, NOT HIM (update216, jj's review: "TAKE HIM ALONG / his file także przy kobietach — Cora, Iris").
   The pool's women's names; a renamed hand goes by the new name. Anything not on the list is "he". */
const CREW_WOMEN = new Set([
  'Vega','Lyra','Nova','Juno','Zara','Cass','Mira','Cora','Iris','Nyx','Uma','Wren','Yuki','Dara','Faye',
  'Ilse','Oona','Tess','Yara','Ada','Bex','Ember','Nell','Pia','Una','Zola','Cleo','Gaia','Ines','Sable',
]);
/** { he, him, his, He, Him, His } for a crew record or a crewman — by name. */
function crewPron(rec) {
  const name = String(rec?.name ?? '').replace(/^"|"$/g, '').trim();
  const f = rec?.female === true || (rec?.female !== false && CREW_WOMEN.has(name));
  const p = f ? { he: 'she', him: 'her', his: 'her' } : { he: 'he', him: 'him', his: 'his' };
  return { ...p, He: p.he[0].toUpperCase() + p.he.slice(1), Him: p.him[0].toUpperCase() + p.him.slice(1), His: p.his[0].toUpperCase() + p.his.slice(1) };
}

// ── Corporations (nations) ─────────────────────────────────
// How readily a bite takes hold, and how long the host has left.
const SPIDER_INFECT_CHANCE  = 0.35;
/* ── A CLOCK, NOT A TALLY OF FIGHTS (update69) ────────────────
 *
 * The bite used to be counted in BATTLES: survive six and you died.
 * Two things were wrong with that and the player named both. The
 * roster printed a bare "5" with nothing to say what it counted —
 * "pod migajaca choroba od pajaka jest liczba 5… zlikwiduj ta cyfre" —
 * and, worse, the whole thing could only ever happen in the quiet
 * moment after a victory. A man who was dying could not die at the
 * gun, in the middle of the fight, which is the only place it would
 * have meant anything.
 *
 * Now both are seconds, and they run while the ship is FLYING — the
 * hold, the map, the fight, all of it — and stop dead in the base,
 * because the base is not part of a contract. Five minutes each: long
 * enough to reach a research post, short enough that ignoring it is a
 * decision rather than a forgotten flag.
 */
const VIRUS_SECONDS = 300;   // bitten → he turns
const EGG_SECONDS   = 300;   // egg case → spiders loose aboard

/** What a corporation ACTUALLY does for you, in plain words (update146:
 *  one copy — the hiring panel and the bar both read it). */
const CORP_PERK_TEXT = {
  terra:    'Cyborg — powers the module they stand in, even with no reactor power.',
  pegasus:  'Vacuum-born — does not breathe, so hull breaches and boarding do not choke them.',
  aquarius: 'Fireproof hide — takes no burns while putting fires out.',
  phoenix:  'Hard-wired for a fight — learns their specialities twice as fast.',
};

const CORP_DEFS = {
  aquarius: {
    label: 'Aquarius', color: '#4db8ff',
    xpBonus: { shields: 2, repair: 2 },
  },
  pegasus: {
    label: 'Pegasus', color: '#9fdcff',
    xpBonus: { piloting: 2 },
  },
  terra: {
    label: 'Terra', color: '#ff9a40',
    xpBonus: { engines: 2 },
    cyborg: true,
    /* EIGHTY, NOT A HUNDRED (update55). A cyborg who also runs a module
       on nothing but his own implant was the strongest badge in the
       game with no cost attached to it. Four boxes instead of five is
       that cost, and it is legible: the crew readouts are pips now, so
       a Terra hand is visibly one box shorter than everybody else
       rather than a number nobody reads. */
    maxHp: 80,
  },
  phoenix: {
    label: 'Phoenix', color: '#ff5544',
    xpBonus: { weapons: 2, combat: 2, firefight: 2 },
  },
  /* MOON CATS (update45). The answer to the rats — but not an
     automatic one. A cat is a passenger with an opinion: it walks the
     ship on its own, hunts what it finds, sits with the wounded, and
     eats. Two of them, and the difference is a real trade: the black
     one wins fights faster and empties the ration racks faster too. */
  cat_black: {
    label: 'Moon Cat', color: '#3a3a42',
    pet: true,
  },
  cat_ginger: {
    label: 'Moon Cat', color: '#c8783a',
    pet: true,
  },
};
// Animals are NOT hireable — keep the cats out of the roll. (The
// spider and the rat had rows here until update84; they are PEST_DEFS.)
const CORP_KEYS = Object.keys(CORP_DEFS).filter(k => !CORP_DEFS[k].pet);

/* ── THE CATS (update45) ──────────────────────────────────────
 * Black: stronger in a scrap, burns through its food faster.
 * Ginger: slower to win, cheap to keep.
 * How fast each one empties its stomach lives in HUNGER.PER_SEC with
 * everybody else's — see the note there. */
const CAT_DEFS = {
  black:  { race: 'cat_black',  label: 'Black',  hp: 26, melee: 5.0 },
  ginger: { race: 'cat_ginger', label: 'Ginger', hp: 22, melee: 3.5 },
};

/* ENGLISH, LIKE EVERY OTHER WORD ON SCREEN (update69). Six of these
   were Polish — Mruk, Pyza, Bajtek, Filut, Bąbel, Kropka — and they
   were the only Polish left in the game's text. The ship's cat is
   named by her crew, and her crew speak English. */
const CAT_NAMES = [
  'Sputnik', 'Comet', 'Soot', 'Luna', 'Domino', 'Rusty',
  'Pixel', 'Bolt', 'Nimbus', 'Scrap', 'Ghost', 'Talon',
];

/* ── THE STOMACH — ONE TABLE FOR EVERY MOUTH (update47) ───────
 *
 * Hunger used to belong to the cat: the thresholds sat in CAT_TUNING
 * and the drain rate sat in CAT_DEFS, and both were written as though
 * nothing else aboard would ever eat. Now the crew eat too, and two
 * tables of the same thing is exactly the drift this project keeps
 * paying for — so the cat's numbers MOVED here rather than being
 * copied, and CAT_TUNING no longer has a FOOD block at all.
 *
 * The meter is 0-100. PER_SEC is keyed by RACE, so a corporation can
 * be a big eater the same way it can be a fast walker:
 *   · a crewman at 1/24 empties a full meter in forty minutes of
 *     flight — the better part of two contracts, so rations matter
 *     without ever becoming the game;
 *   · a black cat at 1/12 empties in twenty minutes, unchanged from
 *     update45, because that pace was measured against real flights.
 */
const HUNGER = {
  /* ── WHAT A FULL STOMACH IS WORTH (update70) ───────────────
   *
   * update69 stopped the crew feeding themselves, which left FEED as a
   * button with nothing behind it: the only thing hunger did was kill
   * you at the very bottom of the meter, so the honest play was to
   * ignore it until the warning came up. The player asked for the
   * middle — "najedzony pracuje szybciej, głodny wolniej" — and that
   * is what makes four kinds of ration a packing decision instead of a
   * shopping list.
   *
   * It multiplies the three things a pair of HANDS does: repairs,
   * fire-fighting, patching a hull breach. NOT gunnery, piloting,
   * shields or melee — a hungry man still aims and still fights for
   * his life, and putting the meter on everything would make it a
   * second difficulty slider rather than a thing you manage. */
  FED:      80,          // above this he is working on a full stomach
  HUNGRY:   40,          // below this a mouth is hungry (and the cat goes hunting)
  STARVING: 12,          // below this the warning shows and HP starts to go
  EFFORT: {
    fed:      1.20,
    ok:       1.00,
    hungry:   0.75,
    starving: 0.50,
  },
  STARVE_HP_PER_SEC: 1 / 6,
  EAT_SECONDS: 6,        // a meal takes a while (update87; was 3)
  PER_SEC: {
    _default:   1 / 24,
    cat_black:  1 / 12,
    cat_ginger: 1 / 18,
  },
  /* WHAT A CAUGHT PEST IS WORTH TO THE CAT (update90b). The player's
     figures, 01.10: a young rat 5, a half-grown one 15, a grown one 30,
     a spider 20 — points on the same 0–100 meter as a ration. A FED cat
     (above FED) does not hunt at all, so these decide how often she
     goes back up. Was a flat 45 for any rat. */
  PREY: {
    rat:    [{ hunger: 5, hp: 1 }, { hunger: 15, hp: 3 }, { hunger: 30, hp: 6 }],   // by level 1-3
    spider: { hunger: 20, hp: 4 },
  },
  FOOD: {
    rat:        { hunger: 45, hp: 6 },
    spider_egg: { hunger: 60, hp: 8 },
    /* `ration` IS GONE (update66) — a ration's worth lives on the cargo
       item now, because there are four of them. What is left here is
       the food that is NOT cargo: a rat and a spider egg. */
  },
};

/* ── BOTTLED AIR (update47) ───────────────────────────────────
 *
 * Everybody aboard now carries his own supply, in SECONDS. A vented
 * compartment stops being instant death and becomes a countdown you
 * can see: walk the man through it and out the far side and he lives.
 *
 * This replaced RoomOxygen's `_suffocateTimer` — the room used to
 * hold one three-second grace period for everyone standing in it,
 * which is the same quantity as a man's air supply kept in a second
 * place. The room's copy is gone; this is the only one.
 *
 * Keyed by race, so the tank is a corporation trait:
 *   · Pegasus fly deep-space salvage and carry a real bottle;
 *   · a cat's rig is small but it is a small animal, and it lasts
 *     longer than an ordinary suit;
 *   · a rat has none at all and dies in a vented compartment the
 *     moment its air is gone — see Ship._pestHazards. It is not in
 *     this table because it is not a body with a suit (update84).
 */
const SUIT_AIR = {
  /* DOUBLED (update185, jj 31.10: "trzeba zwiększyć ilość powietrza dla
     załogantów, podwojenie powinno wystarczyć"). */
  TANK: {
    _default:   16,
    pegasus:    52,
    terra:      32,   // update94, the player's call: "troszkę większy niż podstawa"

    cat_black:  32,
    cat_ginger: 32,
  },
  /**
   * WHO DOES NOT BREATHE AT ALL (update79).
   *
   * Read by `Pest.breathes` (update84) — the only animals it could
   * ever name live in the ducts now. The question it answers is not
   * "how long does its bottle last" but "does it want air at all",
   * and the spider does not.
   *
   * This was agreed with the player on 17.09 ("pająki … odporne na brak
   * tlenu; zabija je tylko ogień albo kot") and then never built, so
   * for three packages the design document and the code disagreed and
   * nobody noticed, because vermin had not been touched. He remembered
   * it and asked; the code was wrong.
   *
   * It is not a detail. Venting a compartment is the cheap answer to
   * everything that infests a hull, and while it worked on spiders the
   * parasite with the virus and the egg was removed by the same click
   * as a rat. Now fire and the cat are the only answers to a spider —
   * which is what makes keeping a cat worth the rations.
   */
  NO_LUNGS: { spider: true },
  /** Seconds of air regained per second of standing in breathable air. */
  REFILL_PER_SEC: 4,
  /** HP per second once the tank is dry. */
  DAMAGE_PER_SEC: 5,
  /** Below this fraction the bar goes red and the alarm sounds. */
  LOW_FRACTION: 0.34,
};

/** What the cat, and only the cat, cares about. */
const CAT_TUNING = {
  /** How much a cat aboard takes off the rat roll at each jump. */
  RAT_SPAWN_CUT: 0.12,
  /** Bleedout runs this much slower while a cat sits with the body. */
  VIGIL_FACTOR:  0.6,
  /** HUNGRY FROM THE START (update91). The player, 01.10: "kot niech
   *  zawsze będzie głodny na start". A fed cat (above HUNGER.FED) does not
   *  hunt since 90b, and a new cat had a full 100 — so she spent her first
   *  minutes ignoring the ducts. She comes aboard on 60: room for a rat or
   *  two, nowhere near the 40 at which she goes off to eat from the hold. */
  START_HUNGER:  60,
};

/**
 * Corporation colour for a live CrewMember OR for serialised crew data.
 *
 * serialise() does not write `color`, so anything reading the barracks
 * straight out of the save (the base CREW tab) used to fall back to
 * blue — a Terra veteran with a Pegasus-coloured swatch.
 */
function crewColor(c) {
  if (!c) return '#4db8ff';
  const corp = CORP_DEFS[c.race];
  if (corp) return corp.color;
  if (c.color) return c.color;
  return c.isPlayer === false ? '#ff4444' : '#4db8ff';
}

// ── Task states ───────────────────────────────────────────

const TASK = {
  IDLE:    'idle',
  MOVE:    'move',
  REPAIR:  'repair',
  FIRE:    'fire',   // firefighting
  BREACH:  'breach',
  FIGHT:   'fight',
  OPERATE: 'operate',
  FLEE:    'flee',
  DIE:     'die',
};

// ── Crew class ────────────────────────────────────────────

class CrewMember {
  /* How far below his standing position a downed man is drawn, so a
     body and the hand working over it are two separate things to look
     at and to click. Read by the drawing here and by the body hit test
     in game.js — one number, two readers. */
  static get BODY_DROP() { return 10; }

  /* WHERE HE IS, TO THE POINTER (update124). The man is 28 px tall now,
     head 9 px higher than the old sprite's, so the oval a click or a
     hover has to land in moved up with him: centre `cy` above his y,
     half-width `rx`, half-height `ry`. game.js `_hitsCrew` and
     `nameShown` both read it. */
  static get HIT() { return { cy: -9, rx: 9, ry: 15 }; }
  /** …and a man on the deck: his lying frame, flat and wide (add
   *  BODY_DROP — the hit test does). */
  static get HIT_LYING() { return { cy: 2, rx: 13, ry: 9 }; }
  /** How much higher the stack over his head rides (CrewArt.LIFT). */
  static get LIFT() { return typeof CrewArt !== 'undefined' ? CrewArt.LIFT : 0; }

  /* WHICH MARKS ARE WORTH PAINTING ON THE DECK (update80).
   *
   * The roster carries all of them; the deck carries the ones that
   * kill a man slowly while you are looking somewhere else — the two
   * diseases, an empty tank and an empty stomach. Not what he is
   * DOING: a spanner over every head in a busy hull is noise, and the
   * deck already shows you a man kneeling at a breach.
   *
   * One list, in one place, so "why is that icon over his head but
   * not in his row" has an answer you can read. */
  static get DECK_MARKS() {
    return ['virus', 'plague', 'air', 'starving', 'hungry'];
  }

  /** Hostile suits. One constant so no animation state can drift off it. */
  static get ENEMY_COLOR() { return '#ff2d44'; }
  /** A passenger's suit: civilian cream (update164). */
  static get PASSENGER_SUIT() { return '#d9d2c0'; }

  constructor(cfg = {}) {
    // The id has to SURVIVE serialisation: the barracks picker, the
    // memorial and the rescue bookkeeping all match on it, and minting a
    // fresh one on every load quietly broke every one of them.
    this.id       = cfg.id || Utils.uid();
    /* HIS PLACE IN THE BARRACKS LIST (update57). The base issues this
       ticket once, when he first signs on; it rides along with him on a
       contract for exactly the same reason `id` does — he has to come
       home as the same man, in the same place on the roster. Undefined
       for anyone who was never in a barracks (enemies, station
       recruits, the greenhorns the guild sends), and the base stamps
       one the moment they walk in. */
    this.joined   = cfg.joined;
    /* HIS FACE (update124): rolled once and saved, so he looks the same
       on every screen and after every reload (crewart.js). A record from
       before 124 gets one made from his name and corporation. */
    this.faceSeed = Number.isFinite(cfg.faceSeed) ? cfg.faceSeed
                  : typeof CrewArt === 'undefined' ? 0
                  : cfg.id != null ? CrewArt.seedOf(cfg)       // a saved man from before 124
                  : CrewArt.newSeed();                          // a new face

    /* SERVICE RECORD. What the memorial reads off the headstone: how
       many ship actions this crewman was aboard for, how many were won,
       how many were run from, and how many of the enemy he personally
       accounted for — with a boarding axe or with the gun he was
       manning when it fired. */
    this.battles  = cfg.battles  ?? 0;
    this.wins     = cfg.wins     ?? 0;
    this.escapes  = cfg.escapes  ?? 0;
    this.kills    = cfg.kills    ?? 0;
    this.name     = cfg.name  || pickUniqueName(CREW_NAMES, CrewMember.namesInPlay());
    this.isPlayer = cfg.isPlayer ?? true;

    // Corporation (nation): player crew belong to one of 4
    this.race     = cfg.race || (this.isPlayer ? Utils.pick(CORP_KEYS) : 'hostile');
    const corp    = CORP_DEFS[this.race];
    /* The cat is the one animal left in a crew list (update84) — the
       spider and rat flags went with them, into pests.js. */
    this.isPet    = !!corp?.pet;
    /* ── A PERSON WHO IS NOT CREW (update72) ───────────────────
     *
     * Two of them in the game and they are the same thing seen from
     * either side: somebody held in a cell on an enemy hull, and
     * somebody who has just got out of one of yours. Neither mans a
     * console, neither swings at anybody and neither is swung at.
     *
     * It is NOT another `isBeast`: a prisoner is a man, he has a name,
     * he eats, and once he is home he is a hand like any other. What
     * the flag says is only "he is not part of this crew TODAY", which
     * is why it goes off the moment he is freed. */
    this.isPrisoner = !!cfg.isPrisoner;
    /* A PASSENGER (update162, jj: "dodatkowy członek załogi, jakiś kapitan albo
       ktoś ważny — bierna postać, ale ma HP, głód itd."). One of ours to every
       hazard — air, fire, hunger, a boarder's blade — and to nothing else: he
       takes no post, no job and no order, and swings at nobody. `jobId` is the
       DISPATCH job he is the whole of. */
    this.isPassenger = !!cfg.isPassenger;
    this.jobId       = cfg.jobId ?? null;
    /* …and how he got aboard, for the dock to read. Set once, when a
       boarder cuts him loose; nothing else ever writes it. */
    this.rescued    = !!cfg.rescued;

    // ── Void-spider virus ──
    // Deliberately NOT `infected` — that flag is the older corpse
    // plague, which the ordinary clinic already cures. This one only a
    // research post can touch, and it ends with an egg case.
    this.virus       = !!cfg.virus;
    /* SECONDS LEFT, and an old save that counted fights simply starts
       its clock now: the field it used to carry meant nothing that
       could be converted honestly, and a wrong number here is a man
       who dies at the wrong moment. */
    this.virusT      = cfg.virusT ?? VIRUS_SECONDS;
    /* IN A SLAB (update77). Restored from the save, so a reload finds
       him exactly where the freeze left him — and, with him, the two
       fields that say which slab was filled last, because the thaw
       order when the power drops has to survive a reload too. */
    this.frozen      = !!cfg.frozen;
    /* ── WHAT HE IS IN THE MIDDLE OF (update78) ───────────────
     *
     * Eating, bandaging somebody, opening a medkit — the player's rule
     * is that every one of them takes a couple of seconds. ONE timer,
     * with the act written on it and the man it is being done TO, and
     * not a `_eatT` beside an `_aidT` beside a `_medkitT`: three
     * timers is three places for "he is already busy" to disagree,
     * and the first thing any of them would be used for is exactly
     * that question.
     *
     * `_busyOn` is an ID, never a reference — the man being bandaged
     * can die, be carried off or go out an airlock while the timer
     * runs, and a reference would outlive him.
     */
    this._busyT   = 0;
    this._busyAct = null;
    this._busyOn  = null;
    this._slabSeq    = cfg._slabSeq ?? null;
    this._slabRoom   = cfg._slabRoom ?? null;
    this._slabIdx    = cfg._slabIdx ?? null;     // which of the bay's three (update128)
    this._slab       = null;                     // its window, set by the ship
    this.color    = corp ? corp.color : '#ff2d44';
    this.cyborg   = corp ? !!corp.cyborg : false;
    this.corpLabel= corp ? corp.label : 'Hostile';

    // Home station — room to return to after tasks
    this.homeRoomId = cfg.homeRoomId ?? null;

    // World position (pixels)
    this.x = cfg.x ?? 0;
    this.y = cfg.y ?? 0;

    // Target position for movement
    this.targetX = this.x;
    this.targetY = this.y;

    // Room the crew is currently in
    this.roomId = cfg.roomId ?? null;

    // Health
    /* maxHp FIRST, then hp defaulting to it (update45). The two lines
       used to run the other way round with `hp ?? 100`, which was
       invisible while every crewman had 100 max — and handed a cat
       100/26 the moment an animal with its own maximum came aboard. */
    /* THE CORPORATION CAN SET THE FRAME (update55). One table, the same
       one that already holds the XP bonuses and the cyborg flag — a
       second place for "how tough is a Terra hand" is exactly the kind
       of pair of numbers that drifts. An explicit cfg.maxHp still wins,
       because loading a save must reproduce the man who was saved. */
    /* `this.race`, NOT `cfg.race` (update87). A man rolled a random
       corporation a few lines up, and this read the EMPTY config field —
       so every randomly-rolled Terra hand, the whole starting crew and
       every recruit, got the default hundred. Only a man built with an
       explicit `race: 'terra'` ever had his eighty. The player saw a
       Terra at 100 and asked for 80; it had been 80 on paper since
       update55. */
    const frame = CORP_DEFS[this.race]?.maxHp ?? 100;
    this.maxHp = cfg.maxHp ?? frame;
    this.hp    = cfg.hp    ?? this.maxHp;
    /* HIS FIGURE WITHOUT A COMMANDER'S BONUS ON IT (update68). Carried
       through the save so `reseatMaxHp` recomputes from it instead of
       stacking on top of last run's result — see serialise below. A
       record written before this existed simply has none, and the man
       is taken as he stands, which is what he was. */
    this.baseMaxHp = cfg.baseMaxHp ?? this.maxHp;
    /* …EXCEPT A TERRA SAVED ON THE WRONG FRAME (update87). A record
       written while the bug above was live carries 100 as his base. He
       comes back on his corporation's frame, the commander's bonus kept
       as the same fraction on top, his wounds kept as they were. */
    if (!this.isPet && CORP_DEFS[this.race]?.maxHp && this.baseMaxHp > frame) {
      const k = frame / this.baseMaxHp;
      this.baseMaxHp = frame;
      this.maxHp = Math.round(this.maxHp * k);
      this.hp = Math.min(this.hp, this.maxHp);
    }

    /* AN ANIMAL WITH A STOMACH (update45). This has to come AFTER the
       generic hp/maxHp above — setting it earlier looked right and was
       silently overwritten two lines later, which gave every cat a
       crewman's hundred hit points and made starvation take ten
       minutes instead of three. Serialised, because a cat that came
       home hungry must still be hungry tomorrow. */
    if (this.isPet) {
      this.catKind = cfg.catKind || 'black';
      const cdef   = CAT_DEFS[this.catKind] ?? CAT_DEFS.black;
      this.maxHp   = cfg.maxHp ?? cdef.hp;
      // hp was defaulted from the CREW maximum a few lines up, so it
      // has to be re-taken from the cat's own — otherwise a fresh cat
      // walks around on 100 of a possible 26.
      this.hp      = cfg.hp ?? this.maxHp;
    }

    /* THE STOMACH AND THE TANK — everybody has both (update47).
       Serialised, because a man who came home hungry must still be
       hungry tomorrow, and because a boarding party that has been
       breathing bottled air for a minute should not arrive with a
       full one. */
    this.hunger = cfg.hunger ?? 100;        // 100 = fed, 0 = starving
    this.air    = cfg.air    ?? this.airMax();

    /* Skills: { skillName: { level, xp } }
       AN ANIMAL DOES NOT HAVE EIGHT SKILLS (update47). The cat was
       built with a crewman's full sheet — piloting, shields, breach
       repair — because the constructor walked SKILL_DEFS for every
       body it made. It could not use any of them (crewOperating
       filters beasts out), but the hover panel showed all eight, and
       a row of empty human skills is a promise the game does not
       keep. A beast has ONE skill, and it is the only one it uses. */
    this.skills = {};
    for (const key of (this.isPet ? BEAST_SKILLS : Object.keys(SKILL_DEFS))) {
      this.skills[key] = {
        level: cfg.skills?.[key]?.level ?? 0,
        xp:    cfg.skills?.[key]?.xp    ?? 0,
      };
    }
    /* A SAVE FROM BEFORE update230 carries a `breach` sheet. The trade it stood for is
       repair now, so the man keeps what he earned: the better of the two rows wins. */
    const old = cfg.skills?.breach;
    if (old && this.skills.repair &&
        (old.level > this.skills.repair.level ||
         (old.level === this.skills.repair.level && (old.xp ?? 0) > this.skills.repair.xp))) {
      this.skills.repair = { level: old.level ?? 0, xp: old.xp ?? 0 };
    }

    // Task state
    this.task    = TASK.IDLE;
    this.taskTarget = null;  // room, fire, enemy ref

    // Waypoint queue for floor-aware movement
    this._waypoints = [];

    // Animation
    // Go through _setAnim so the CAT gets her own sprite from frame one.
    // Assigning crewIdle() straight here left _animState undefined, so an
    // animal that never changed state kept the human sprite.
    this.anim = null;
    this._setAnim('idle');
    if (!this.anim) this.anim = Animation.crewIdle(!this.isPlayer);

    this._facing = 1;   // 1=right, -1=left

    // Combat
    this.attackTimer = new Utils.Interval(2.0);
    this.killedBy    = null;
    /* HIS WEAPON (update174): a key into CREW_ARMS (crewarms.js), or
       null — bare hands. Saved with him; charges are not (a cell is full
       again after a rest). */
    this.sidearm     = cfg.sidearm ?? null;
    this.sidearmRarity = cfg.sidearmRarity ?? null;   // update178: metal … helium; null = metal

    // Death & condition states
    this.dying   = false;
    this.dead    = false;
    this._dieT   = 0;
    // 'ok' | 'injured' (downed, can be carried to medbay) | 'dead'
    this.state    = cfg.state ?? 'ok';
    this.infected = cfg.infected ?? false;   // corpse plague
    this.decaying = cfg.decaying ?? false;   // dead + a battle passed
    this._deadCombats = 0;
    this.ejected  = false;    // thrown/walked out the airlock
    this.carriedBy = null;    // crew member carrying this body
    this.carrying  = null;    // body this crew member carries
    this._infT     = 0;       // infected-behaviour timer
    if (this.state === 'dead') this.dead = true;
  }

  /** Downed: lying on the floor, can be picked up and carried */
  get down()  { return this.dead || this.state === 'injured'; }
  /** In the middle of something that takes a moment (update78). */
  get busy() { return this._busyT > 0; }
  /** Fully able: can move, man systems, repair, fight */
  get alive() { return !this.dead && !this.dying && this.state !== 'injured'; }

  // ── Life support (update47) ──────────────────────────────

  /** Seconds of air this body's suit holds, by race. */
  airMax() {
    const t = (typeof SUIT_AIR !== 'undefined') ? SUIT_AIR.TANK : null;
    if (!t) return 0;
    /* His commander's ENDURANCE (update98) lengthens the bottle — his
       own corporation only, which `_capBonus` already decides. A cat
       has no suit and no commander's blessing. */
    const air = this.isPet ? 0 : (this._capBonus().air || 0);
    /* THEIRS KEEP THE OLD BOTTLE (update186): the tanks were doubled for
       OUR hands (update185); a hostile crew on the old size is what keeps
       choking them worth trying — jj: "żeby łatwiej można było podusić". */
    const theirs = !this.isPlayer && !this.isPet && !this.isPrisoner ? 0.5 : 1;
    return (t[this.race] ?? t._default) * (1 + air) * theirs;
  }

  /**
   * HOW MUCH AIR THIS MOUTH TAKES OUT OF THE SHIP (update82).
   *
   * Shaped exactly like `hungerPerSec`, and on purpose: the two
   * questions a body asks of the hold and of the pipes are the same
   * question with a different table. A cat is half a man, a rat a
   * quarter — the player's figures, 24.09. (The rat's figure is read
   * by `Pest.breathPerSec` now; everybody in a crew list breathes, so
   * the `breathes()` that stood here went with the spider — update84.)
   */
  breathPerSec() {
    const t = (typeof OXYGEN !== 'undefined') ? OXYGEN.BREATH_PER_SEC : null;
    return t ? (t[this.race] ?? t._default) : 0;
  }

  /** Fraction of the tank left, 0-1. A body with no tank reads empty. */
  airFrac() {
    const max = this.airMax();
    return max > 0 ? Utils.clamp((this.air ?? 0) / max, 0, 1) : 0;
  }

  /* `eats` IS GONE (update84): it was false for spiders and rats and
     true for everybody else, and everybody else is all that is left in
     a crew list. */

  /** How fast its stomach empties, by race. */
  hungerPerSec() {
    const t = (typeof HUNGER !== 'undefined') ? HUNGER.PER_SEC : null;
    return t ? (t[this.race] ?? t._default) : 0;
  }

  /**
   * The colour of the name plate over this body's head.
   *
   * NOT the corporation colour any more, at least not blindly: a black
   * cat's corporation colour is #3a3a42, so its name was drawn in
   * near-black on a near-black backing plate and could not be read at
   * all. Ours in his own colour, an enemy in red, and an ANIMAL in a
   * fixed bright amber that has nothing to do with its fur.
   */
  /** Whether his name is drawn over him (update120): selected, or under the pointer. */
  nameShown() {
    try {
      if (typeof UI !== 'undefined' && UI.getSelectedCrewAll?.().includes(this)) return true;
      if (typeof Input === 'undefined' || !Input.mouse) return false;
      const H = this.isPet ? { cy: -1, rx: 8, ry: 14 } : CrewMember.HIT;
      const dx = (Input.mouse.x - this.x) / H.rx, dy = (Input.mouse.y - (this.y + H.cy)) / H.ry;
      return dx * dx + dy * dy <= 1;
    } catch (e) { return false; }
  }

  labelColor() {
    if (!this.isPlayer) return '#ff4444';
    if (this.isPet)   return '#ffc861';
    return this.color;
  }

  // ── Skill helpers ────────────────────────────────────────

  getSkillLevel(skill) { return this.skills[skill]?.level ?? 0; }

  /** The chance this man's blow (or shot) is a critical (update173). */
  critChance(skill) {
    if (this.isPet) return 0;
    const lvl = this.getSkillLevel(skill);
    const spec = CORP_DEFS[this.race]?.xpBonus?.[skill] ? CRIT.SPEC : 0;
    return Math.min(CRIT.MAX, lvl * CRIT.PER_LEVEL + (lvl > 0 ? spec : 0));
  }

  /**
   * Award XP. RETURNS THE AMOUNT ACTUALLY GRANTED (update43) — zero
   * when the skill is maxed or the man has already mastered his three.
   *
   * The return value used to be a "did he level up" boolean that no
   * call site ever read. It is now the number the CAPTAIN mirrors, and
   * that number has to be the real one: a crew of masters teaches him
   * nothing, which is precisely the pressure to keep hiring.
   */
  addXP(skill, amount) {
    if (!this.skills[skill]) return 0;
    // Corporation specialisation: 2x XP in signature skills
    const corp = CORP_DEFS[this.race];
    if (corp && corp.xpBonus && corp.xpBonus[skill]) amount *= corp.xpBonus[skill];
    const sk  = this.skills[skill];
    if (sk.level >= MAX_SKILL_LEVEL) return 0;

    /* update52: THE MASTERY CAP IS GONE. It used to refuse the last
       level of a fourth skill, which put 24 squares — and therefore
       the top of the rank ladder and the last six cells of a CPU
       board — permanently out of reach. Nothing replaces it: the
       cost of the levels is the limit now. */

    sk.xp += amount;
    if (typeof RunTally !== 'undefined') RunTally.noteXP(this, amount);   // the run's summary (update180)

    /* THE CAPTAIN LEARNS WHAT HIS PEOPLE LEARN. A copy, not a cut —
       the crewman keeps every point. Only our own PEOPLE count: an
       enemy boarder standing on our deck is in `ship.crew` too, and a
       rat swinging at somebody is not a lesson for anyone. */
    if (this.isPlayer && !this.isPet && typeof Commander !== 'undefined') {
      Commander.mirror(amount);
    }

    const threshold = SKILL_DEFS[skill].xpPerLevel[sk.level] ?? 200;
    if (sk.xp >= threshold) {
      sk.xp  -= threshold;
      sk.level++;
      Audio.sfx.levelUp();
    }
    return amount;
  }

  /** What the flying commander is worth to this crew member (zeroes when
   *  none is flying, or he is of another corporation). */
  _capBonus() {
    if (typeof Commander === 'undefined') {
      return { hp: 0, speed: 0, repair: 0, melee: 0,
               firefight: 0, breach: 0, meleeResist: 0, air: 0, hpFlat: 0 };
    }
    return Commander.bonusFor(this);
  }

  _countMastered() {
    return Object.values(this.skills).filter(s => s.level >= MAX_SKILL_LEVEL).length;
  }

  /** This crewman's rank level — the sum of his filled squares. */
  rankLevel() { return rankLevelOf(this); }
  /** …and its name. */
  rankName()  { return rankName(this.rankLevel()); }


  // ── Bonus multipliers ────────────────────────────────────

  /**
   * HOW HARD HE CAN WORK RIGHT NOW (update70).
   *
   * One number, read off the one hunger meter, and the four bands live
   * in `HUNGER.EFFORT` — not as four `if`s scattered through the three
   * speeds below.
   */
  effortFactor() {
    const h = this.hunger ?? 100;
    const E = HUNGER.EFFORT;
    if (h <= HUNGER.STARVING) return E.starving;
    if (h <  HUNGER.HUNGRY)   return E.hungry;
    if (h >= HUNGER.FED)      return E.fed;
    return E.ok;
  }

  repairSpeed()    { return (1 + this.getSkillLevel('repair') * 0.5)
                          * (1 + this._capBonus().repair) * this.effortFactor(); }
  firefightSpeed() { return (1 + this.getSkillLevel('firefight') * 0.5)
                          * (1 + this._capBonus().firefight) * this.effortFactor(); }
  /** Patching a hole is repair work (update230) — the same skill, the captain's own hull-seal perk on top. */
  breachSpeed()    { return (1 + this.getSkillLevel('repair')    * 0.5)
                          * (1 + this._capBonus().breach) * this.effortFactor(); }
  combatDamage()   { return 1 + this.getSkillLevel('combat')   * 0.3; }
  /* MELEE ONLY (update38).
   *
   * `combat` is a hand-to-hand skill and nothing else: it does not
   * touch gun damage, charge time, accuracy, evasion or boarding
   * defence — those belong to `weapons`, `piloting` and `engines`.
   * Both melee paths (the room brawl and an ordered duel) now go
   * through this one number, so a duel and a brawl hit for the same. */
  meleeDamage() {
    // A cat fights with what it has; no skills, no commander's blessing.
    if (this.isPet) return (CAT_DEFS[this.catKind] ?? CAT_DEFS.black).melee;
    /* A LASER KNIFE (update174) hits half as hard again; a gun is no
       help with your fists. `CrewArms.meleeMult` is 1 for everyone else. */
    const arm = (typeof CrewArms !== 'undefined') ? CrewArms.meleeMult(this) : 1;
    return (MELEE_BASE_DAMAGE + this.getSkillLevel('combat') * 3) * (1 + this._capBonus().melee) * arm;
  }
  /** How much faster than a fist he swings (update174): the knife. */
  swingRate() { return (typeof CrewArms !== 'undefined') ? CrewArms.swingRate(this) : 1; }
  /** A man with a GUN in his hand (update174) — he does not pair off in
   *  a brawl, he stands back and shoots. Never a cat, never a prisoner. */
  get shooter() {
    return !this.isPet && !this.isPrisoner && typeof CrewArms !== 'undefined' && CrewArms.isRanged(CrewArms.of(this));
  }
  /** XP for one swing. The ONLY way combat XP is ever earned. */
  creditMeleeSwing() { this.addXP('combat', XP_RATES.combat); }

  /**
   * WHO THIS MAN IS ACTUALLY FIGHTING (update79).
   *
   * Every fighter used to swing at `foes[0]` — the first enemy in the
   * ship's roster array. Three on three was therefore not three
   * duels: all six men piled onto one man per side, he dropped, and
   * the next name in the array took over. The player saw it and asked
   * for what a boarding action is supposed to look like: "jezeli walka
   * jest 2v2 lub 3v3 kazdy walczy odrzielnie miedzy soba, jezeli jest
   * przewaga to jeden wolny pomaga innemu w walce".
   *
   * Both sides are sorted by id and paired off by position — the i-th
   * of ours takes the i-th of theirs. Three properties fall out of
   * that and all three matter:
   *
   *  - IT IS MUTUAL. If I am 2nd of mine and pick their 2nd, he is 2nd
   *    of his and picks me. Nobody is swinging at a man whose back is
   *    turned to someone else, which is what made the old focus-fire
   *    look so wrong.
   *  - IT HOLDS STILL. No stored opponent, no timer, and yet the pair
   *    survives frame to frame, because the order is a property of the
   *    two rosters rather than of who happened to be nearest.
   *  - THE SURPLUS HELPS. With four against three the fourth man wraps
   *    round to the first pair — two on one — which is exactly the
   *    advantage the player asked to be worth having. It also means
   *    "outnumber them" beats "have one hero", and that is the FTL
   *    shape of a boarding fight.
   *
   * The comparator is on the STRING of the id on purpose: ids are
   * numbers today but arrive from a save file, and a numeric subtract
   * on an old string id returns NaN, which would silently unsort one
   * side and break the mutuality above.
   */
  /* ── WHERE HE STANDS IN A BRAWL (update93) ─────────────────
   *
   * The SAME pairing `meleeTarget` makes — both sides sorted by id, man
   * i of the bigger side takes man (i mod n) of the smaller — laid out
   * on the floor so it can be read: pair p of P gets an equal strip of
   * the room, ours stand on its left, theirs on its right, facing. A
   * man beyond the first P of his side is a second (third…) on pair
   * (i mod P), one step behind his mate. Returns
   * { x, pair, pairs, partnerX, lead } — `lead` is the first man of our
   * side in a pair, the one who draws the tie line under it. */
  static get DUEL_GLIDE() { return 40; }   // px/s into position
  static get DUEL_GAP()   { return 9; }    // half the space between a pair
  static get DUEL_BACK()  { return 7; }    // a helper, behind his mate

  duelSpot(ship, foes) {
    const room = ship?.getRoomById?.(this.roomId);
    if (!room || !foes || !foes.length) return null;
    const byId = (a, b) => String(a.id).localeCompare(String(b.id));
    /* A gunman stands back and shoots (update174): he is in nobody's pair. */
    const side = (pl) => ship.crew.filter(k =>
      k.alive && k.inRoom !== false && !k.isPrisoner && !k.frozen && !k.shooter &&
      k.roomId === this.roomId && k.isPlayer === pl).sort(byId);
    const mine = side(this.isPlayer), them = side(!this.isPlayer);
    const P = Math.min(mine.length, them.length);
    const i = mine.indexOf(this);
    if (P <= 0 || i < 0) return null;
    const pair = i % P, rank = Math.floor(i / P);
    /* Inside the same margin `_stepInsideRoom` keeps — a spot it would
       push him off of every frame is a man jittering on the spot. */
    const pad = Math.min(CrewMember.MELEE_INSET, Math.max(0, room.w / 2 - 1));
    const L = room.x + pad, U = Math.max(1, room.w - pad * 2);
    const cx = L + (pair + 0.5) * U / P;
    const gap = Math.max(4, Math.min(CrewMember.DUEL_GAP, U / P / 2 - 2));
    const dir = this.isPlayer ? -1 : 1;          // ours left, theirs right
    const x = Utils.clamp(cx + dir * (gap + rank * CrewMember.DUEL_BACK), L, L + U);
    return { x, pair, pairs: P, cx, partnerX: cx - dir * gap, lead: rank === 0, ours: this.isPlayer };
  }

  meleeTarget(ship, foes) {
    if (!foes || !foes.length) return null;
    if (foes.length === 1) return foes[0];
    const byId = (a, b) => String(a.id).localeCompare(String(b.id));
    const mine = ship.crew.filter(k =>
      k.alive && k.inRoom !== false && !k.isPrisoner && !k.shooter &&
      k.roomId === this.roomId && k.isPlayer === this.isPlayer).sort(byId);
    /* Fists find fists first; only when every man of theirs is a gunman
       standing back does he go for one of them (update174). */
    const hands = foes.filter(k => !k.shooter);
    const them = (hands.length ? hands : foes).slice().sort(byId);
    const i = mine.indexOf(this);
    return them[(i < 0 ? 0 : i) % them.length];
  }
  weaponChargeBonus() { return this.getSkillLevel('weapons')   * 0.1; }  // 10% faster per level
  shieldBonus()    { return this.getSkillLevel('shields')      * 0.15; }
  engineBonus()    { return this.getSkillLevel('engines')      * 0.05; }
  pilotBonus()     { return this.getSkillLevel('piloting')     * 0.05; }

  // ── Movement ─────────────────────────────────────────────

  /**
   * Direct move (same floor only) — used internally.
   */
  _setAnim(state) {
    /* EATING IS STANDING STILL WITH A TUBE AT THE VISOR (update124):
       the same 'idle' to everything that asks, its own frames to look
       at. `_animKey` is what is on screen. */
    /* …at his console too (update208, jj: "jak załogant je lub się leczy, ustawi się przodem zawsze,
       aby było widać, co robi"): a man eating or taking a dose at his post turns round to us */
    const still = state === 'idle' || state === 'operate';
    /* OPEN HAND (update223): while the scene plays, every man standing still stands to attention and salutes */
    const key = (still && !this.isPet && !this.down && typeof Finish !== 'undefined' && Finish.saluting?.()) ? 'salute'
              : (still && this._meal && !this.isPet) ? 'eat'
              : (still && this._busyAct === 'heal' && this._busyT > 0 && !this.isPet) ? 'heal'   // update128
              : state;
    if (this._animState === state && this._animKey === key) return;   // avoid churning instances
    this._animState = state;
    this._animKey = key;

    // A cat is not a man in a suit. It sits up when idle — a silhouette
    // that cannot be confused with the rat's, which matters when one is
    // welcome aboard and the other is not. (The rat and the spider are
    // drawn by pests.js since update84.)
    if (this.isPet) {
      const mode = state === 'fight' ? 'fight'
                 : state === 'walk'  ? 'walk' : 'idle';
      this.anim = Animation.catAnim(mode, this.color);
      return;
    }
    /* ONE colour, every state (update38).
     *
     * The enemy used to fall through to the uncoloured factory frames —
     * Animation.crewRepair/crewFight/crewDie — and those are generated
     * in the PLAYER's blue. So a hostile who walked over to patch a
     * module turned blue mid-fight and read as one of yours; the same
     * happened when he swung, and when he died. Everyone now goes
     * through the colour-keyed cache with his own suit colour, and the
     * enemy's suit is always hostile red. */
    /* HIS OWN FACE AND SUIT (update124), from crewart.js; the old
       frames only if that file is missing. */
    this.anim = (typeof CrewArt !== 'undefined')
      ? CrewArt.anim(key, this)
      : Animation.crewByColor(state === 'shoot' ? 'fight' : state, this.suitColor());
  }

  /**
   * The colour this man's suit is drawn in, whatever he is doing.
   *
   * ENEMIES WEAR THEIR CORPORATION TOO (update55). Every hostile was
   * painted one flat red, so a hull crewed by Terra, Phoenix and
   * Aquarius — which `ENEMY_CORP_MIX` has been rolling all along —
   * looked like four identical Phoenix men. The variety was there and
   * the player could not see any of it.
   *
   * The SIDE is not carried by this colour any more; it is carried by
   * the red ring `drawSideRing` puts around every hostile, which reads
   * at a glance and does not collide with a corporation that happens to
   * be orange. A man whose corporation is unknown ('hostile') keeps the
   * old red, so nothing is ever drawn in no colour at all.
   */
  suitColor() {
    /* A PASSENGER IN CREAM (update164, jj: „kremowy z hełmem i znaczkiem”):
       a civilian on a ship of suits — the helmet stays, the air is the same air. */
    if (this.isPassenger) return CrewMember.PASSENGER_SUIT;
    if (this.isPlayer) return this.color || '#4db8ff';
    const corp = CORP_DEFS[this.race];
    return corp ? corp.color : CrewMember.ENEMY_COLOR;
  }

  /** Every hostile gets this ring, whatever colour his suit is. It is
   *  what says "not yours" now that the suit no longer does. */
  drawSideRing(ctx) {
    if (this.isPlayer) return;
    ctx.strokeStyle = CrewMember.ENEMY_COLOR;
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    /* round the man as drawn — taller since update124 */
    if (!this.isPet && this.anim?.native) ctx.ellipse(this.x, this.y + CrewMember.HIT.cy, 10, 16, 0, 0, Math.PI * 2);
    else ctx.arc(this.x, this.y - 1, 9, 0, Math.PI * 2);
    ctx.stroke();
  }

  /* `isBeast` IS GONE (update84). It meant "spider, rat or cat" and
     guarded more than forty places against crewmen who were not
     people. The spider and the rat moved out of the crew list into the
     ducts (pests.js), so the only animal left in `ship.crew` is the
     cat — and a second name for `isPet` would be a second register of
     the same fact. Every one of those filters asks `isPet` now. */

  moveTo(x, y) {
    this._waypoints = [{ x, y }];
    this.task = TASK.MOVE;
    this._setAnim('walk');
  }

  /**
   * Where this man will END UP: the last waypoint if he is walking,
   * otherwise where he stands right now.
   *
   * Slot arbitration MUST use this. It used to compare against live
   * positions only, so two crew ordered into an empty cockpit both saw
   * the console as free, both walked to it, and both stood on the same
   * pixel for the rest of the run — neither would move again, because
   * from then on each of them WAS on slot 0 and the settle rule only
   * lets a man move UP to a lower-numbered slot. A man merely en route
   * to the console already owns the console.
   */
  destPoint() {
    const wp = this._waypoints?.[this._waypoints.length - 1];
    return wp ? { x: wp.x, y: wp.y } : { x: this.x, y: this.y };
  }

  /**
   * Floor-aware movement. Crew walk horizontally within a floor;
   * changing floors requires routing through an elevator shaft.
   * @param {Ship} ship
   * @param {number} tx - target world x
   * @param {number} ty - target world y
   */
  moveToOnShip(ship, tx, ty) {
    /* ── RE-ORDERED MID-RIDE ──────────────────────────────────
       A crewman inside a moving cabin has a Y that belongs to no deck,
       so floorAtY() returned -1 and the "same floor, just walk" branch
       below happily plotted a straight line — which is why he appeared
       to fly diagonally out of the shaft the moment the cabin let go,
       leaving the lift behind on the wrong deck.

       He is in a lift. The lift is how he gets there. If the shaft he is
       riding also serves the deck he has just been ordered to, send the
       cabin there instead and let the ride finish; it puts him down on
       the right floor and the walk continues from a position that
       actually exists. */
    /* …AND THE LIFT FINISHES ITS RIDE FIRST (update223, jj: "winda nie zmienia kierunku jazdy, dopóki nie zjedzie
       tam, gdzie miała jechać najpierw; teraz gracz może zmieniać kierunek, jak zmienia moduły"). The cabin is
       no longer turned round in mid-shaft: the new order is parked, he is put down where the ride was going,
       and the route is planned from that deck (`_rerouteAfterRide`, below in the ride waypoint). */
    if (this._ridingShaft) {
      this._rerouteAfterRide = { tx, ty };
      return true;
    }

    const curFloor = ship.floorAtY(this.y);
    const dstFloor = ship.floorAtY(ty);

    /* PEOPLE WALK ON THE FLOOR.
     *
     * The console spot sits OPERATOR_LIFT pixels above the deck's walk
     * line, and the previous version put that lifted Y straight into the
     * travel waypoint. A man leaving his console for another module
     * therefore set off at console height and stayed there, gliding
     * above the deck through every room he crossed.
     *
     * The route is built in three parts instead:
     *     step DOWN off the console, if he is on one
     *     walk the deck at walk height
     *     step UP to the console at the far end, if that is where he is
     *       going and the spot is free
     * Each is its own waypoint, so what you see is a man stepping down,
     * walking, and stepping up — which is what the player asked for. */
    const curWalk = ship.floorWalkY(curFloor !== -1 ? curFloor : dstFloor, this.y);
    const dstWalk = ship.floorWalkY(dstFloor !== -1 ? dstFloor : curFloor, ty);
    const liftAtEnd = Utils.clamp(dstWalk - ty, 0, (Ship.OPERATOR_LIFT ?? 0) + 1);

    const wps = [];
    // Standing above the deck right now? Come down first, where you are.
    if (curWalk - this.y > 1) wps.push({ x: this.x, y: curWalk });

    if (curFloor === dstFloor || curFloor === -1 || dstFloor === -1) {
      wps.push({ x: tx, y: dstWalk });
    } else {
      const route = ship.elevators.findPath(this.x, this.y, ty);
      if (!route) {
        // No usable elevator — cooldown stops per-frame retry spam
        this._pathRetryCd = 1.0;
        return false;
      }
      wps.push(
        { x: route.entryX, y: curWalk },                              // walk to shaft
        { x: route.entryX, y: dstWalk,                                // ride shaft
          elevator: route.shaft,
          srcY: route.entryY, dstY: route.exitY,
          srcFloor: route.srcFloor, dstFloor: route.dstFloor,
          phase: 'call' },
        { x: tx, y: dstWalk },                                        // walk to target
      );
    }
    // …and only NOW step up to the console.
    if (liftAtEnd > 1) wps.push({ x: tx, y: dstWalk - liftAtEnd });

    this._waypoints = wps;
    this.task = TASK.MOVE;
    this._setAnim('walk');
    return true;
  }

  assignTask(task, target = null) {
    this.task       = task;
    this.taskTarget = target;

    switch (task) {
      case TASK.REPAIR:  this._setAnim('repair'); break;
      case TASK.FIGHT:   this._setAnim('fight');  break;
      case TASK.FIRE:
      case TASK.BREACH:  this._setAnim('repair'); break;
      case TASK.IDLE:    this._setAnim('idle');   break;
      default: break;
    }
  }

  // ── Update ───────────────────────────────────────────────

  update(dt, ship) {
    // The dead take no actions (bodies are handled by the ship's
    // body pipeline). 'dying' is NOT guarded here — the dying branch
    // below must run so the death timer can finish.
    if (this.dead) return;

    if (this._pathRetryCd > 0) this._pathRetryCd -= dt;
    const _f0 = this.anim.frame;
    this.anim.update(dt);
    /* THE SHIELD'S SOUND (update246, jj): a layered man's eating animation folds his hologram shield away and back;
       the frames that start each move carry a cue. Only our own people are heard. */
    if (this.anim.cues && this.anim.frame !== _f0 && this.isPlayer) {
      const cue = this.anim.cues[this.anim.frame];
      if (cue && typeof Audio !== 'undefined') Audio.sfx?.[cue]?.();
    }
    // A meal begun or finished while he stands there changes the picture.
    if ((this._animState === 'idle' || this._animState === 'operate') && ((this._animKey === 'eat') !== !!(this._meal && !this.isPet))) {
      this._setAnim(this._animState);
    }
    // …and so does a dose (update128).
    const dosing = this._busyAct === 'heal' && this._busyT > 0 && !this.isPet;
    if ((this._animState === 'idle' || this._animState === 'operate') && ((this._animKey === 'heal') !== dosing)) this._setAnim(this._animState);
    // …and so does OPEN HAND's salute, on and off (update223)
    if ((this._animState === 'idle' || this._animState === 'operate') && !this.isPet &&
        ((this._animKey === 'salute') !== !!(typeof Finish !== 'undefined' && Finish.saluting?.() && !this.down))) this._setAnim(this._animState);
    /* WHAT IT DOES, OVER HIM (update128): a dose sends green crosses up
       off him, a meal drops crumbs. A few a second — a sign, not a cloud. */
    if ((dosing || (this._meal && this._busyAct === 'eat' && this._busyT > 0)) && typeof Particles !== 'undefined') {
      this._fxT = (this._fxT ?? 0) - dt;
      if (this._fxT <= 0) {
        this._fxT = dosing ? 0.35 : 0.5;
        if (dosing) Particles.floatText?.(this.x + Utils.randFloat(-6, 6), this.y - 16, '+', '#3aff6a', 10);
        else Particles.emit?.({ x: this.x + 3, y: this.y - 6, vx: Utils.randFloat(-8, 8), vy: -10, ay: 60,
                                color: '#e6c878', life: 0.6, size: 2, sizeEnd: 1 });
      }
    }

    /* STUNNED — an ion bolt landed in this room. No walking, no repairs,
       no fighting until it wears off. It is a real interval rather than
       a flag so that a burst genuinely holds people down longer, and so
       the pip above their head can count it out. */
    if (this._stunT > 0) {
      this._stunT = Math.max(0, this._stunT - dt);
      if (this._stunT === 0) this._stunKind = null;
      this._setAnim('idle');
      return;
    }

    if (this.dying) {
      // Fixed-length death (the old anim.done never fired → crew
      // looked alive forever and kept working). 1.2s, then a corpse.
      this._dieT += dt;
      if (this._dieT >= 1.2 || this.anim.done) {
        this.dead  = true;
        this.state = 'dead';
        this.carriedBy = null;
      }
      return;
    }

    // Downed (injured) crew lie where they fell — carried or not,
    // they take no actions until healed in the medbay.
    if (this.state === 'injured') return;

    // Corpse plague: infected crew act erratically — they abandon
    // their post for empty rooms, and sometimes walk straight out of
    // an airlock…
    /* A MAN ON THE TABLE STAYS ON THE TABLE (update82).
     *
     * The plague makes a man wander off to empty rooms and sometimes
     * straight out of an airlock, which is the whole character of it.
     * It also meant that the moment a ward could TREAT the plague, the
     * patient walked out of it: the first run of the level 3 cure got
     * seven seconds of a twenty-second course in forty seconds of
     * game, because he kept leaving.
     *
     * `_cureT` is only ever above zero while he is a patient in a ward
     * that can actually treat what he has — it is set by `Ship._cureTick`
     * and cleared the moment either stops being true — so it is the
     * condition already, and asking it here costs one line instead of
     * a second copy of "is this man being treated".
     */
    if (this.infected && ship && !(this._cureT > 0)) {
      this._infT += dt;
      if (this._infT >= 6) {
        this._infT = 0;
        const roll = Math.random();
        if (roll < 0.15) {
          // head for the nearest airlock — and step outside
          const air = ship.doors.filter(d => d.isAirlock)
            .sort((a, b) => Utils.dist(this.x, this.y, a.x, a.y) -
                            Utils.dist(this.x, this.y, b.x, b.y))[0];
          if (air) { this._suicideDoor = air; this.moveToOnShip(ship, air.x, air.y); }
        } else if (roll < 0.75) {
          const empt = ship.rooms.filter(r => r.type === 'empty' && r.id !== this.roomId);
          const target = empt.length ? Utils.pick(empt) : Utils.pick(ship.rooms);
          this.homeRoomId = target.id;
          this.moveToOnShip(ship, target.cx, target.cy);
        }
      }
      if (this._suicideDoor &&
          Utils.dist(this.x, this.y, this._suicideDoor.x, this._suicideDoor.y) < 16) {
        this.ejected = true;   // ship.update removes them
        return;
      }
    }

    // His gun's clock: cooldown, reload, the cell that refills (update174).
    if (typeof CrewArms !== 'undefined' && (this.sidearm || this._shot)) CrewArms.tick(this, dt);

    // ── ROOM COMBAT: enemies sharing a room fight it out ──
    /* BOTH FIGHTERS MUST ACTUALLY BE IN THE ROOM (update42).
       `roomId` is stale while a man stands in the elevator trunk or on a
       door line, so this used to start brawls through walls: two people
       swinging at each other from either side of a bulkhead, the fight
       cancelling the loser's lift ride, and the corpse dropping in the
       shaft. `inRoom` is set every frame by Ship.update from the actual
       room rectangles — no rectangle, no fight. */
    this._duel = null;   // set again below, every frame he is in a fight
    if (ship && this.inRoom !== false && !this.isPrisoner && !this.isPassenger) {   // a passenger swings at nobody (update162) — he can still be hit
      /* NOBODY FIGHTS A MAN IN HANDCUFFS (update72), in either
         direction: he does not swing (the guard above) and he is not
         swung at (the filter below). One place decides who is in this
         fight, so a prisoner cannot be quietly beaten to death by a
         boarding party that was sent to free him. */
      const foes = ship.crew.filter(k =>
        k.alive && k.inRoom !== false && !k.isPrisoner &&
        k.roomId === this.roomId && k.isPlayer !== this.isPlayer);
      /* HE MAY RUN (update194, jj: "załogant zaznaczony podczas walki — można go
         skierować, aby poszedł do innego modułu, może uciekać od walki"). An
         order to another room, given while he was in a fight, holds: he turns
         his back and goes (and they get their swings at him on the way). */
      if (this._disengage && (!this._waypoints.length || this.roomId !== this._disengage.from)) this._disengage = null;
      if (foes.length && this._disengage) {
        this._setAnim('walk');
        this._duel = null;
      } else if (foes.length) {
        this._waypoints = [];
        this._hacking = false;
        this._stepInsideRoom(ship);
        /* A GUN IN HIS HAND (update174): to his side's wall, and fire. */
        if (this.shooter) { CrewArms.shootInRoom(this, ship, foes, dt); return; }
        /* IN PAIRS (update93, the player's list point 29: "walka wręcz
           w czytelnych parach"). Each man walks to his own spot: one
           pair per opponent, spread across the room, ours on the left
           of each pair and theirs on the right; a man with nobody left
           to pair with stands behind the man he is helping. */
        const spot = this.duelSpot(ship, foes);
        if (spot) {
          const step = CrewMember.DUEL_GLIDE * dt;
          this.x += Utils.clamp(spot.x - this.x, -step, step);
          this._duel = spot;
        }
        // It LOOKS like a fight now. The melee branch used to leave the
        // walk/idle animation and whatever task the man was on, so a
        // boarding action played out as two people standing still.
        this._setAnim('fight');
        const target = this.meleeTarget(ship, foes);
        this._facing = (target.x >= this.x) ? 1 : -1;
        /* A KNIFE OR A FIST HAS TO BE AT ARM'S LENGTH (update194, jj: "ci, co
           walczą nożem, muszą zbliżyć się do przeciwnika"). Paired, he is; a
           gunman standing back at the wall he walks up to first. */
        const reach = (typeof CrewArms !== 'undefined' ? CrewArms.CLOSE : 24);
        if (Math.abs(target.x - this.x) > reach) {
          const step = CrewMember.DUEL_GLIDE * 1.5 * dt;
          const want = target.x - Math.sign(target.x - this.x) * (reach - 6);
          this.x += Utils.clamp(want - this.x, -step, step);
          this._setAnim('walk');
          return;
        }
        if (this.attackTimer.tick(dt * this.swingRate())) {
          this.strike(target, this.meleeDamage());
          if (typeof CrewArms !== 'undefined') CrewArms.afterStrike?.(this, target);   // a helium knife freezes (update178)
          Particles.laserHit?.(target.x, target.y - 10, typeof CrewArms !== 'undefined' ? CrewArms.hitCol?.(this) : undefined);   // a knife's sparks its rarity's (update210)
          this.creditMeleeSwing();
        }
        return;
      }
      /* ACROSS THE DOORS (update174). Nobody of theirs in his own room,
         but one in the next along the deck and the doors open: a man
         standing still shoots — at his console, at a breach, wherever
         he is. A man on the move does not. Nothing else stops for it. */
      if (this.shooter && !this._waypoints.length) CrewArms.shootAcross(this, ship);
      // ── BOARDER AI: aboard the OTHER side's ship, no defenders in
      //    sight → sabotage this module, then push to the next target
      if (this.isPlayer !== ship.isPlayer) {
        const room = ship.getRoomById(this.roomId);
        /* NOTHING TO SABOTAGE ON A WRECK.
           A derelict is already shot to pieces, and the one system left
           running is the life support keeping the boarding party alive —
           so the old behaviour had your own people methodically
           destroying the air supply they were standing in. On a wreck
           they search it and loot; they do not wreck it further. */
        if (ship.isDerelict) {
          this._updateMovement(dt, ship);
          return;
        }
        if (room?.system && room.system.damagedLevels < room.system.level) {
          this._sabT = (this._sabT ?? 0) + dt;
          if (this._sabT >= 5) {
            this._sabT = 0;
            room.system.damageLevel(1);
            Particles.repairSparks?.(this.x, this.y - 8);
          }
        } else if (!this._waypoints.length && !this._ordered) {
          /* WHERE NEXT (update90b). The player saw a boarder land in an
             empty compartment and stay there for good. The ONE target he
             picked could be out of reach — up a lift gone dark (update90)
             or shot up — and he stood waiting for it; and only the five
             listed module types were ever targets, so with those wrecked
             or unreachable he had nowhere to go. Now: every module he can
             break but the reactor, the listed ones first, the first he can
             actually get to; failing all of them, the nearest defender;
             failing that, he stays (a dead end, not a bug). */
          if (!(this._roamCd > 0)) {
            this._roamCd = 1.0;
            const prio = ['weapons', 'shields', 'piloting', 'engines', 'oxygen'];
            const rank = (r) => { const i = prio.indexOf(r.system?.type); return i < 0 ? prio.length : i; };
            /* ONE MODULE EACH (update93a). Every boarder ranked the same
               list the same way, so a party of two walked to the same
               module in single file: the player saw one "standing" in an
               empty compartment while the other did the work. A module a
               mate is already in, or already walking to, goes to the back
               of the list — the party spreads out. */
            const mates = ship.crew.filter(k => k && k !== this && k.alive &&
                                                k.isPlayer === this.isPlayer && !k.isPet);
            const claimed = (r) => mates.some(k => k.roomId === r.id ||
              (k._waypoints?.length && r.contains(k.destPoint().x, k.destPoint().y)));
            const targets = ship.rooms
              .filter(r => r.id !== this.roomId && r.system && r.system.type !== 'reactor' &&
                           r.system.damagedLevels < r.system.level)
              .sort((a, b) => (claimed(a) - claimed(b)) || (rank(a) - rank(b)));
            let went = false;
            for (const t of targets) {
              if (this.moveToOnShip(ship, t.cx, t.cy)) { went = true; break; }
            }
            if (!went) {
              const foes = ship.crew.filter(c => c && c.isPlayer === ship.isPlayer && c.alive &&
                                                  !c.isPet && c.roomId && c.roomId !== this.roomId)
                .sort((a, b) => Math.abs(a.x - this.x) + Math.abs(a.y - this.y)
                              - Math.abs(b.x - this.x) - Math.abs(b.y - this.y));
              for (const f of foes) {
                const r = ship.getRoomById(f.roomId);
                if (r && this.moveToOnShip(ship, r.cx, r.cy)) break;
              }
            }
          } else {
            this._roamCd -= dt;
          }
        }
        this._updateMovement(dt, ship);
        return;   // no normal duties on a hostile ship
      }
    }

    this._updateMovement(dt, ship);
    this._updateTask(dt, ship);
    this._regenHp(dt);
  }

  /** Melee happens INSIDE a module (update42).
   *  A boarder pinned on the door plane used to fight — and die — right
   *  in the doorway, so brawls and corpses ended up straddling the wall
   *  between two rooms. Pull whoever starts swinging clear of the edge
   *  before the first blow lands. */
  static get MELEE_INSET() { return 18; }

  _stepInsideRoom(ship) {
    const room = ship?.getRoomById?.(this.roomId);
    if (!room) return;
    const pad = CrewMember.MELEE_INSET;
    if (room.w <= pad * 2) return;
    this.x = Utils.clamp(this.x, room.x + pad, room.x + room.w - pad);
  }

  /** Door directly in the walking path.
   *  `includeOpen` matters for INTRUDERS: a boarder has to crack every
   *  door he crosses, even one the defenders left standing open, so for
   *  him an open door is still a door. */
  _doorBlocking(ship, dirX, includeOpen = false) {
    if (!ship?.doors) return null;
    return ship.doors.find(d =>
      (includeOpen || !d.open) &&
      Math.abs(d.y - this.y) < 30 &&
      Math.sign(d.x - this.x) === Math.sign(dirX) &&
      Math.abs(d.x - this.x) < 16) ?? null;
  }

  /** Am I an intruder on this hull? */
  _isIntruderOn(ship) { return !!ship && this.isPlayer !== ship.isPlayer; }

  _updateMovement(dt, ship = null) {
    /* A MEAL IS ALL HE DOES (update90a). update81 stopped a man working
       while he ate, but he could still walk — "jedzenie = jedzenie, żadnej
       innej aktywności". He stands where he is until the meal is over;
       the route he was given is kept, and he sets off when he is done.
       (A cabin already carrying him still carries him — that is the
       lift moving, not him.) */
    /* …and a DOSE is the same (update107, jj): "leczenie apteczką = nic nie
       robi, jak z jedzeniem" — he stands and takes it. */
    if (this._busyT > 0 && (this._busyAct === 'eat' || this._busyAct === 'heal' || this._busyAct === 'thaw')) {
      if (this._waypoints.length && !this._ridingShaft) this._setAnim('idle');
      return;
    }
    if (!this._waypoints.length) {
      if (this.task === TASK.MOVE) {
        this.task = TASK.IDLE;
        this._setAnim('idle');
      }
      return;
    }

    const wp = this._waypoints[0];

    // ── Elevator waypoint: call cabin → board → shaft carries us ──
    if (wp.elevator) {
      const shaft = wp.elevator;

      /* A man in the cabin keeps his route (update90): if the lift goes
         dark he waits inside for the power (update90a), and when it
         arrives the waypoint below takes him off — the arrival too, which
         comes AFTER the cabin has let him go. Dropping the route mid-ride
         used to leave `_elevatorArrived` hanging, for the next lift to
         trip over. */
      if (!shaft.isUsable() && !this._ridingShaft && !this._elevatorArrived) {
        this._waypoints.length = 0;
        this.task = TASK.IDLE;
        this._setAnim('idle');
        return;
      }

      // Currently riding — shaft drives our position; wait for release.
      /* …STANDING (update189, jj: "w windzie załogant stoi, nie macha
         nogami"): the cabin moves him, his legs do not. */
      if (this._ridingShaft) { if (this._animState === 'walk') this._setAnim('idle'); return; }

      if (this._elevatorArrived) {
        // Shaft released us at destination floor
        this._elevatorArrived = false;
        this.y = wp.y;
        this._waypoints.shift();
        // An order that arrived mid-ride and could not be served by this
        // shaft was parked until we were standing on a real deck again.
        if (this._rerouteAfterRide) {
          const r = this._rerouteAfterRide;
          this._rerouteAfterRide = null;
          this.moveToOnShip(ship, r.tx, r.ty);
        }
        return;
      }

      // Waiting at the shaft: summon cabin, board when it arrives
      if (shaft.cabinAt(wp.srcY, 14)) {
        shaft.board(this, wp.dstFloor);
      } else if (!shaft._moving && !shaft.passenger) {
        shaft.moveCabinTo(wp.srcFloor);
      }
      // If another crew member occupies the cabin we simply keep waiting.
      return;
    }

    // ── Regular walk waypoint ─────────────────────────────────
    // Door ahead? INTERIOR doors slide open for us (short delay);
    // AIRLOCKS to space are impassable unless breached — a normal
    // crew member simply can't walk out into vacuum, so we abort the
    // waypoint rather than freeze against it.
    {
      const dirX = wp.x - this.x;
      if (Math.abs(dirX) > 2) {
        const intruder = this._isIntruderOn(ship);
        const door = this._doorBlocking(ship, dirX, intruder);
        if (door) {
          if (door.isAirlock) {
            // No walking into space; drop this move order.
            this._waypoints.length = 0;
            if (this.task === TASK.MOVE) { this.task = TASK.IDLE; }
            this._setAnim('idle');
            this._hacking = false;
            return;
          }
          if (intruder) {
            /* BOARDERS HACK, THEY DO NOT SMASH.
               Doors used to be blind to whose ship they were on, so an
               enemy boarder walked through the player's LOCKED doors as
               easily as the player's own crew — latching a door bought
               about one second of delay and nothing else. A hostile has
               to stand and crack each lock now (once per fight, per
               side), which is what makes door control a real tactic. */
            const side = this.isPlayer ? 'player' : 'enemy';
            /* AN OPEN DOOR IS OPEN (update105, jj): a door its own crew
               left OPEN — and that is fully open — is walked through, by
               their boarders on our hull and by ours on theirs. Only a
               shut door is a lock to crack. */
            if (door.mode === 'open' && door.open) {
              this._hacking = false;
            } else if (!door.hackBy(side, dt)) {
              this._hacking = true;
              this._setAnim('repair');
              return;
            }
            this._hacking = false;
            if (!door.open) { this._setAnim('idle'); return; }
          } else {
            const canPass = door.requestPassage(dt);
            if (!canPass) { this._setAnim('idle'); return; }
          }
          // door is open — fall through and keep walking this frame
        } else {
          this._hacking = false;
        }
      }
    }

    const dx = wp.x - this.x;
    const dy = wp.y - this.y;
    const d  = Math.sqrt(dx*dx + dy*dy);
    /* GRAVITY (update91): 70% in zero-G; a casualty on his shoulders 50%
       in gravity and 120% without — Ship.moveFactor, GRAVITY_CONFIG. */
    const SPEED = (60 + this.getSkillLevel('engines') * 10) * (1 + this._capBonus().speed)
                * (ship?.moveFactor ? ship.moveFactor(this) : 1);

    if (d > 2) {
      const step = Math.min(SPEED * dt, d);
      this.x += (dx / d) * step;
      this.y += (dy / d) * step;
      if (Math.abs(dx) > 1) this._facing = dx > 0 ? 1 : -1;
      /* A MAN WHO MOVES, WALKS (update189, jj: "jak drzwi są zamknięte i
         załogant przechodzi, to jak przejdzie, nie ma animacji chodzenia,
         tylko jest z przodu i się przesuwa"). Waiting at a door, or off a
         lift, set him standing; nothing set him walking again. */
      if (this._animState === 'idle') this._setAnim('walk');
    } else {
      this.x = wp.x;
      this.y = wp.y;
      this._waypoints.shift();
      if (!this._waypoints.length && this.task === TASK.MOVE) {
        this.task = TASK.IDLE;
        this._setAnim('idle');
      }
    }
  }

  _updateTask(dt, ship) {
    if (!ship) return;

    /* HANDS FULL, WORK STOPS (update81).
     *
     * The busy clock has been read in more and more places since it
     * was added — the mark strip since 78, `crewOperating` since 79 —
     * and this was the last loop that did not know about it. So a man
     * could eat a ration and put out a fire with the same pair of
     * hands, which is the player's complaint in reverse: he asked for
     * "zostawi gaszenie czy zazadzanie modulem na rzecz jedzenia", and
     * the leaving half never happened.
     *
     * PAUSED, NOT CANCELLED. The task stays assigned, so when the
     * meal is over he goes straight back to the fire he left. That is
     * what "leaves it for a moment" means, and it is also the only
     * version that cannot lose an order.
     *
     * The room brawl is upstream of this and returns before it, so a
     * fight still pre-empts everything — including the meal.
     */
    if (this.busy) return;

    switch (this.task) {
      case TASK.REPAIR: {
        const room = ship.getRoomById(this.taskTarget);
        if (!room) { this.assignTask(TASK.IDLE); break; }
        // Done repairing?
        if (!room.system || room.system.damagedLevels <= 0) {
          this.assignTask(TASK.IDLE);
          break;
        }
        const dist = Utils.dist(this.x, this.y, room.cx, room.cy);
        if (dist < 34) {
          // Pass raw dt — the crew skill multiplier is applied once,
          // inside system.repair (it used to be counted twice).
          // Zero-G: 80% (update91). Applied here, once — not in repairSpeed.
          room.repair(dt * (ship.repairFactor ? ship.repairFactor() : 1), this);
          // Repair sparks feedback
          if (Math.random() < 0.15) Particles.repairSparks(this.x + Utils.randFloat(-8,8), this.y - 10);
        } else if (!this._waypoints.length && !(this._pathRetryCd > 0)) {
          // Walk to a FREE standing spot, not the dead centre of the
          // room — send two men to fix the same engine and they used to
          // arrive on the same pixel and stay there afterwards.
          this.moveToOnShip(ship, ...ship.stationSpot(room, null, this));
          this.task = TASK.REPAIR;
        }
        break;
      }

      case TASK.FIRE: {
        const fire = this.taskTarget;
        if (!fire || fire.out) { this.assignTask(TASK.IDLE); break; }
        const fdist = Utils.dist(this.x, this.y, fire.x, fire.y);
        if (fdist < 34) {
          fire.suppress(dt * this.firefightSpeed(), this);
          this.addXP('firefight', dt * XP_RATES.firefight);
        } else if (!this._waypoints.length && !(this._pathRetryCd > 0)) {
          this.moveToOnShip(ship, fire.x, fire.y);
          this.task = TASK.FIRE;
        }
        break;
      }

      case TASK.BREACH: {
        const breach = this.taskTarget;
        if (!breach || breach.sealed) { this.assignTask(TASK.IDLE); break; }
        const bdist = Utils.dist(this.x, this.y, breach.x, breach.y);
        if (bdist < 30) {
          // Zero-G: 70% (update91).
          /* THE SKILL ONCE (update93a). `HullBreach.repair` multiplies
             by `breachSpeed()` itself — passing it in here as well made
             a master patch holes 6.25× as fast instead of 2.5×. The same
             mistake repair had once; the same cure: the room counts the
             skill, the caller passes time. */
          breach.repair(dt * (ship.breachFactor ? ship.breachFactor() : 1), this);
        } else if (!this._waypoints.length && !(this._pathRetryCd > 0)) {
          this.moveToOnShip(ship, breach.x, breach.y);
          this.task = TASK.BREACH;
        }
        break;
      }

      case TASK.FIGHT: {
        const enemy = this.taskTarget;
        if (!enemy || enemy.dead) { this.assignTask(TASK.IDLE); break; }
        const cdist = Utils.dist(this.x, this.y, enemy.x, enemy.y);
        /* Ordered at a man his gun can reach (update174): he shoots from
           where he stands instead of walking up to him. */
        if (this.shooter && CrewArms.canHit(this, ship, enemy)) {
          this._waypoints = [];
          CrewArms.fireAt(this, ship, enemy);
          break;
        }
        if (cdist < 24) {
          this._stepInsideRoom(ship);
          if (this.attackTimer.tick(dt * this.swingRate())) {
            // Same swing, and the same lesson, as the room brawl.
            this.strike(enemy, this.meleeDamage());
            if (typeof CrewArms !== 'undefined') CrewArms.afterStrike?.(this, enemy);   // a helium knife freezes (update178)
            this.creditMeleeSwing();
            Audio.sfx.repair();
          }
        } else if (!this._waypoints.length && !(this._pathRetryCd > 0)) {
          this.moveToOnShip(ship, enemy.x, enemy.y);
          this.task = TASK.FIGHT;
        }
        break;
      }

      case TASK.OPERATE: {
        // Standing at system — handled by system itself
        break;
      }

      case TASK.IDLE: {
        // Animals keep to their room. They do not fight fires, seal
        // breaches or repair anything — spiders wait, rats chew.
        if (this.isPet) break;
        /* AND NEITHER DOES A PRISONER (update72). He is a man, not an
           animal, but he is not on this crew: he does not repair the
           module of the ship he is trying to get off, does not fight
           its fires and does not carry its wounded. The ship decides
           where he walks; this is the loop that would otherwise hand
           him a job on the way past.
           NOT enough to guard the ship-side loop — that one is about
           bodies and errands. THIS is where a crewman picks up work. */
        if (this.isPrisoner) break;
        if (this.isPassenger) break;       // …nor a passenger: he paid to sit, not to work (update162)

        // FTL behaviour: idle crew automatically handle problems in their room
        // Priority: fire > breach > repair damaged system
        const room = ship.getRoomById(this.roomId);
        if (!room) break;

        const fire = ship.fires.getFiresInRoom(room.id)[0];
        if (fire) { this.assignTask(TASK.FIRE, fire); break; }

        const breach = ship.breaches.getBreachesInRoom(room.id)[0];
        if (breach) { this.assignTask(TASK.BREACH, breach); break; }

        if (room.system && room.system.damagedLevels > 0) {
          this.assignTask(TASK.REPAIR, room.id);
          break;
        }

        // Nothing wrong here — return to assigned station (FTL behaviour).
        // stationSpot() picks the next FREE slot in that room, so drifting
        // back to your post no longer means standing inside a colleague.
        /* AN ERRAND IS NOT A POSTING (update69). A stretcher-bearer
           used to have his STATION rewritten to the medbay so that the
           idle walk-home below would not drag him off the job — and
           nothing ever wrote it back, so the man who carried one
           casualty in lived there for the rest of the fight. The
           player saw it on the other side: "przeciwnik jak uleczy
           rannego zaloganta to czesto zostaje w module w ktorym
           uleczyl". `_errandRoomId` is where he is WORKING; homeRoomId
           stays where he BELONGS, and the errand clears itself when
           the job is done. */
        /* A WOUNDED MAN'S POST IS THE WARD (update97) until he is
           mended — the enemy AI sets `_healing` and `_healRoomId`. */
        const post = (this._healing && this._healRoomId) || (this._errandRoomId ?? this.homeRoomId);
        if (post && this.roomId !== post &&
            !this._waypoints.length && !(this._pathRetryCd > 0)) {
          const home = ship.getRoomById(post);
          if (home) this.moveToOnShip(ship, ...ship.stationSpot(home, null, this));
          break;
        }

        /* SETTLE onto the right spot in my own module.
         *
         * Standing spots are handed out from whoever happened to be in
         * the room at the moment the order was given — and rooms empty
         * out afterwards. A crewman placed on the LEFT flank because a
         * colleague was passing through would then flank an empty
         * console for the rest of the run, which is exactly the "he
         * stands off to the side" the player kept seeing.
         *
         * Ranking by id (rather than by who notices first) keeps this
         * from oscillating: everyone in the room agrees on the order,
         * so slot 0 — the console — goes to one man and stays his. */
        if (!this._waypoints.length && post === room.id) {
          /* POSSESSION IS THE RULE. Whoever is standing on a slot keeps
             it; you may only move UP to a slot nobody is on.

             The first version ranked everyone in the room by id, so a
             newcomer with a lower id evicted the man already at the
             console, and somebody merely crossing the room could shove
             him aside for a moment. The operator owns his spot until he
             leaves it of his own accord. */
          /* WALKING COUNTS AS HOLDING (update38).
             This used to compare against live positions only. Order two
             men into an empty cockpit and both saw the console free
             while the other was still walking, so both went for it and
             both ended up on the same pixel — and once there, neither
             would ever move again, because the rule only lets you step
             UP to a lower slot and slot 0 is as low as it goes. A man
             en route to a spot owns that spot: Ship.takenStationSlots
             asks destPoint(), not x/y. */
          const slots = [0, 1, 2].map(i => ship.stationSlot(room, i));
          const mine  = ship.slotIndexAt(this.x, this.y, room, 5);
          const taken = ship.takenStationSlots(room, [this]);

          let want = -1;
          for (let i = 0; i < (mine === -1 ? 3 : mine); i++) {
            if (!taken.has(i)) { want = i; break; }
          }
          /* STACKED ON. If another RESIDENT of this room is standing on
             my spot too — two men on one slot, from an older save or a
             body dropped on the console — one of us steps aside rather
             than both pretending the room is fine.
             Residents only: a man crossing the room is in the way, but
             he does not own the console and must never evict anybody. */
          if (want === -1 && mine !== -1 &&
              ship.takenStationSlots(room, [this], true).has(mine)) {
            for (let i = 0; i < 3; i++) if (!taken.has(i)) { want = i; break; }
          }
          if (want !== -1) {
            this.moveToOnShip(ship, slots[want][0], slots[want][1]);
            break;
          }
        }

        /* Parked in a module that HAS a station: work it.
         *
         * The operator spot sits a few pixels above the walk line (see
         * Ship.stationSlot), so "am I at the console" is simply "am I
         * standing above the walk line". Anyone flanking him keeps the
         * ordinary idle bob, which is what makes the console man read
         * as the one actually running the module. `_setAnim` ignores a
         * repeat of the state it is already in, so this is free. */
        if (!this._waypoints.length && room.system) {
          const walkY = ship.floorWalkY(room.floor, room.cy);
          const atConsole = (walkY - this.y) > (Ship.OPERATOR_LIFT ?? 8) * 0.5;
          this._setAnim(atConsole ? 'operate' : 'idle');
        }
        break;
      }
    }
  }

  _regenHp(dt) {
    // NO natural regen anywhere — crew heal ONLY inside a medbay
    // that is undamaged and powered (handled by the medbay system).
  }

  // ── Damage / death ───────────────────────────────────────


  /** One more notch. Called for melee kills and for gunnery kills. */
  creditKill(victim) {
    if (!victim || victim.isPlayer === this.isPlayer) return false;
    this.kills = (this.kills ?? 0) + 1;
    /* ── AND THE YARD IS COUNTING TOO (update71) ───────────────
     *
     * Side objectives read the events the game already produces, and
     * this is the one choke point every kill by one of ours already
     * goes through — melee and gunnery alike. A second tally
     * somewhere else would be a second tally to keep in step.
     *
     * The "people, not vermin" clause and the cat's meal both left this
     * function in update84. Nothing on the other side of a brawl is an
     * animal any more, and a cat catches rats in the DUCT, which is not
     * a brawl — `Ship._catCaught` feeds her. Left here, the meal would
     * have fed her a rat's worth for every BOARDER she finished off. */
    return true;
  }

  strike(target, dmg) {
    if (!target || target.dead) return;
    const wasAlive = target.alive;
    /* BOARDING ARMOUR (update49). The chip belongs to the DEFENDER's
       commander, so the reduction is read off the man being hit, not
       the one swinging — and it is melee only: a Dominacja plate does
       nothing about fire, vacuum or a shell through the hull. */
    const resist = Utils.clamp(target._capBonus?.().meleeResist ?? 0, 0, 0.9);
    /* A CRIT IN THE BRAWL (update173): double, and said over his head. */
    const cp = this.critChance ? this.critChance('combat') : 0;
    if (cp > 0 && Math.random() < cp) {
      dmg *= 2;
      if (typeof Particles !== 'undefined') Particles.floatText?.(target.x, target.y - 26, 'CRIT!', '#ffe36b', 10);
    }
    target.takeDamage(dmg * (1 - resist), 'crew');
    /* ONE OF THEIRS HIT ONE OF OURS (update93) — the enemy is still
       hurting us, so it is not giving up yet. */
    if (target.isPlayer && !this.isPlayer && !this.isPet && typeof Ship !== 'undefined') {
      Ship.noteHarmToPlayer?.();
    }
    // The victim only ever recorded the STRING 'crew' as its killer —
    // nobody was ever credited with a kill. Now the man who swung is.
    if (wasAlive && !target.alive) {
      this.creditKill(target);
      if (typeof CrewTalk !== 'undefined') CrewTalk.noteKill(this, target, 'combat');   // a blow in the streak (update173)
    }
    // The bite that could carry the virus moved to Ship._spiderBite
    // (update84): a spider does not swing in a brawl any more, it drops.
  }

  /** True once the virus has run its course. */
  get virusFatal() {
    return this.virus && (this.virusT ?? VIRUS_SECONDS) <= 0;
  }

  /** Only a research post's quarantine ward can do this. */
  /** Knocked senseless for `seconds`. Stacks. */
  stun(seconds = 1) {
    if (this.dead) return false;
    this._stunT = (this._stunT ?? 0) + Math.max(0, seconds);
    this._waypoints = [];
    return true;
  }

  get stunned() { return (this._stunT ?? 0) > 0; }

  cureVirus() {
    const was = this.virus;
    this.virus = false; this.virusT = VIRUS_SECONDS;
    return was;
  }

  /**
   * Straight to dead — no 35% "goes down wounded" roll, no death
   * animation to wait out. The virus is not a wound somebody can drag
   * you to the medbay from; when it finishes, he is gone.
   */
  /** Once per death (update180): the run's tally, and a combo when the
   *  air or the fire took two or three of theirs close together. */
  _noteDeath(source) {
    if (this._deathNoted) return;
    this._deathNoted = true;
    if (typeof RunTally !== 'undefined') RunTally.noteDeath(this);
    if (typeof CrewTalk !== 'undefined') CrewTalk.noteDeath?.(this, source);
    if (typeof Finish !== 'undefined') Finish.noteDeath?.(this);   // OPEN HAND counts them (update182)
  }

  killOutright(source = 'unknown') {
    if (this.dead) return false;
    this.hp = 0;
    /* 'dead', NOT 'ok' (update40).
     *
     * serialise() writes `state` but not `dead`/`dying`, and the
     * constructor's only resurrection rule is `if (state === 'dead')
     * this.dead = true`. Writing 'ok' here meant a man killed by the
     * virus was saved as a LIVING crew member on 0 hp: reload, and he
     * was back at a console, uncounted by the game-over check, with his
     * headstone already on the hill. */
    this.state = 'dead';
    this.dying = false;
    this.dead  = true;
    this.killedBy = source;
    this._waypoints = [];
    this.task = TASK.IDLE;
    this._setAnim('die');
    this._noteDeath(source);
    Particles.crewDie?.(this.x, this.y);
    Audio.sfx.crewDie?.();
    if (this.isPlayer && !this._graved) { Save.addToGraveyard(this); this._graved = true; }
    return true;
  }

  takeDamage(amount, source = 'unknown') {
    if (this.dying || this.dead) return;
    // A downed crew member taking MORE damage dies outright
    if (this.state === 'injured') {
      this.hp = 0; this.dying = true; this._dieT = 0;
      this.killedBy = source; this._setAnim('die');
      this._noteDeath(source);
      if (this.isPlayer && !this._graved) { Save.addToGraveyard(this); this._graved = true; }
      return;
    }
    this.hp -= amount;
    if (this.hp <= 0) {
      // 35%: the crew member goes DOWN wounded instead of dying —
      // another crew member can carry them to the medbay.
      // Suffocation included: it leaves a body (or a casualty) too.
      // NOT vermin: nobody stretchers a rat to the med bay.
      if (!this.isPet && Math.random() < 0.35) {
        this.hp    = 1;
        this.state = 'injured';
        this._waypoints = [];
        this.task  = TASK.IDLE;
        // Fresh clock: Ship.BLEEDOUT_SECONDS to get help, or he is gone.
        this._bleedT = 0;
        if (this.isPlayer && typeof UI !== 'undefined') {
          const secs = (typeof Ship !== 'undefined' ? Ship.BLEEDOUT_SECONDS : 40);
          UI.notify(`${this.name} is DOWN — get someone to them within ${secs}s!`, 'warn');
        }
        return;
      }
      this.hp       = 0;
      this.dying    = true;
      this._dieT    = 0;
      this.killedBy = source;
      this._setAnim('die');
      this._noteDeath(source);
      Particles.crewDie(this.x, this.y);
      Audio.sfx.crewDie();

      // Add to persistent graveyard (once — killOutright may also run)
      if (this.isPlayer && !this._graved) { Save.addToGraveyard(this); this._graved = true; }
    }
  }

  heal(amount) {
    this.hp = Math.min(this.maxHp, this.hp + amount);
  }

  // ── Draw ─────────────────────────────────────────────────

  draw(ctx) {
    /* ── THE CAT, UP IN THE DUCT (update84) ─────────────────
     *
     * `_ductY` is set by `Ship._pestVsCat` while she has something
     * cornered up there and cleared the moment she lets go. Her x and
     * her room do not change — she is still in that compartment as far
     * as every rule aboard is concerned — so only the DRAWING goes up.
     * No name plate: the duct is twenty pixels and the plate would land
     * on the deck above. A thin bar under her says how she is doing,
     * which is the one thing the player is watching in that fight. */
    if (this._ductY != null && this.isPet && !this.dead) {
      ctx.save();
      if (this._facing === -1) {
        ctx.scale(-1, 1);
        ctx.translate(-this.x * 2, 0);
      }
      this.anim.draw(ctx, this.x, this._ductY, 32, 32);
      ctx.restore();
      const bw = 14;
      ctx.fillStyle = 'rgba(7,8,15,0.85)';
      ctx.fillRect(this.x - bw / 2 - 1, this._ductY + 9, bw + 2, 4);
      ctx.fillStyle = '#ffc861';
      ctx.fillRect(this.x - bw / 2, this._ductY + 10,
                   bw * Utils.clamp(this.hp / (this.maxHp || 1), 0, 1), 2);
      return;
    }

    /* ── A MAN IN A SLAB LOOKS LIKE ONE (update77) ──────────
     *
     * The roster mark says he is frozen; the DECK said nothing at all,
     * so a player looking at his ship saw three men standing in a room
     * and two of them could not do a thing. A screenshot caught that,
     * because no assertion can: the strip and the deck were both
     * "correct" and the ship still lied.
     *
     * Drawn as a slab AROUND him rather than a tint ON him: a tint
     * reads as damage or as an enemy, and this man is neither — he is
     * fine, he is just outside time. */
    if (this.frozen && !this.dead) {
      /* Geometry taken from the STANDING draw below — `anim.draw` is
         given his centre, so the slab is built round the same point.
         Writing the numbers out again is how a slab ends up floating
         over a man's head, which is what the first version of this did
         and what the screenshot showed. */
      /* taller since update124: the slab grows with the man */
      const L = this.anim?.native ? CrewMember.LIFT : 0;
      /* IN THE SLAB'S OWN WINDOW (update128, jj: "nie są na równo z
         ilustracją modułu, za duży lód"). The bay's picture already has
         three slabs with a frame each; the ice is that window and nothing
         bigger, and he is scaled to stand inside it. A man with no window
         (an old save before the ship has placed him) keeps the old box. */
      const slab = this._slab;
      const W = slab ? slab.w : (L ? 24 : 20), H = slab ? slab.h : 34 + L;
      const top = slab ? slab.y : this.y - 17 - L;
      const cx = slab ? slab.x + slab.w / 2 : this.x;
      ctx.save();
      ctx.globalAlpha = 0.55;              // him, behind the ice
      if (slab) {
        const sc = Math.min(1, (H - 2) / (34 + L), (W + 6) / 26);
        ctx.beginPath(); ctx.rect(slab.x, slab.y, slab.w, slab.h); ctx.clip();
        ctx.translate(cx, top + H / 2);
        ctx.scale(sc, sc);
        this.anim.draw(ctx, 0, L / 2, 32, 32);
      } else {
        this.anim.draw(ctx, this.x, this.y, 32, 32);
      }
      ctx.restore();

      ctx.save();
      ctx.fillStyle = 'rgba(127,212,255,0.22)';
      ctx.strokeStyle = slab ? 'rgba(200,240,255,0.35)' : 'rgba(127,212,255,0.8)';
      ctx.lineWidth = 1;
      ctx.beginPath(); ctx.roundRect(cx - W / 2, top, W, H, slab ? 1 : 3);
      ctx.fill(); ctx.stroke();
      /* Frost across the face, so it reads as cold at a glance rather
         than as a selection box. */
      ctx.strokeStyle = 'rgba(200,240,255,0.5)';
      ctx.beginPath();
      ctx.moveTo(cx - W / 2 + 3, top + 10);
      ctx.lineTo(cx + W / 2 - 3, top + 16);
      ctx.moveTo(cx - W / 2 + 3, top + 24);
      ctx.lineTo(cx + W / 2 - 3, top + 18);
      ctx.stroke();
      /* THE SLAB IS WARMING (update127): the ice drains from the top
         as `SLAB_MELT_SECONDS` runs out, with a drip under it, so the
         player sees there is still time to get the bay's power back. */
      const melt = (this._meltT ?? 0) > 0 && typeof Ship !== 'undefined'
        ? Utils.clamp(this._meltT / Ship.SLAB_MELT_SECONDS, 0, 1) : 0;
      if (melt > 0) {
        ctx.fillStyle = 'rgba(7,8,15,0.55)';
        ctx.fillRect(cx - W / 2 + 1, top + 1, W - 2, (H - 2) * melt);
        ctx.fillStyle = '#ffb020';
        ctx.fillRect(cx - W / 2, top + H + 2, W * (1 - melt), 2);
        const dy = ((this._meltT * 18) % 8);
        ctx.fillStyle = 'rgba(127,212,255,0.8)';
        ctx.fillRect(cx - 1, top + H + 4 + dy, 2, 2);
      }
      ctx.restore();

      /* His name, and nothing else above him: no health bar, no
         markers. Nothing is happening to him — that is the point —
         but the player still has to know which of them is in there. */
      /* IN A SLAB, ONLY UNDER THE POINTER (update128): three slabs are
         sixteen pixels apart and three names over them ran into one bar.
         The roster says who is under; the slab says it when you point. */
      if (slab && typeof Input !== 'undefined' && Input.mouse &&
          !Utils.pointInRect(Input.mouse.x, Input.mouse.y, slab.x, slab.y, slab.w, slab.h)) return;
      ctx.font = '9px Share Tech Mono, monospace';
      ctx.textAlign = 'center';
      const lw = ctx.measureText(this.name).width + 6;
      ctx.fillStyle = 'rgba(7,8,15,0.8)';
      ctx.fillRect(cx - lw / 2, top - 13, lw, 11);
      ctx.fillStyle = '#7fd4ff';
      ctx.fillText(this.name, cx, top - 4);
      return;
    }

    /* THE SIDE RING (update55). Drawn before the body, on every hostile
       who is still on his feet — now that an enemy's suit shows his
       CORPORATION rather than a flat red, this is what says "not
       yours". Only the living get it: a body on the floor is nobody's
       threat, and a ring on it would just be noise. */
    /* …RETIRED in update128 (jj: "otoczki czerwone na załogantach wroga
       zlikwiduj, wyglądają jak osłony"). The side is now the hairline
       red frame round his health boxes (`Renderer.drawPips` edge). */

    /* THE PAIR, TIED UNDER THEIR FEET (update93). One short line from
       our man to his opponent's spot, drawn once per pair (by ours, the
       first of the pair), so a brawl of four reads as two fights. */
    if (this._duel && this._duel.lead && this._duel.ours && !this.down) {
      const d = this._duel, fy = this.y + 13;
      ctx.save();
      ctx.strokeStyle = 'rgba(255,214,120,0.55)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(this.x, fy); ctx.lineTo(d.partnerX, fy);
      ctx.stroke();
      ctx.fillStyle = 'rgba(255,214,120,0.8)';
      ctx.fillRect((this.x + d.partnerX) / 2 - 1, fy - 1, 2, 2);
      ctx.restore();
    }

    // Downed & dead crew stay VISIBLE — lying sideways, tinted so
    // there's no mistaking them for the living.
    if (this.down) {
      /* ── A BODY LIES LOW IN THE ROOM (update68) ──────────────
       *
       * A man on the floor was drawn at the same height as a man
       * standing over him, so the two overlapped into one shape and
       * the player could not tell whom he was right-clicking. His
       * words: "załogant jak i ciało leżą w tym samym miejscu, więc
       * przenieś ciała trochę niżej".
       *
       * `BODY_DROP` is the offset, used by the DRAWING and by the hit
       * test in game.js alike — put it in one place and the thing you
       * can click stays exactly the thing you can see. */
      ctx.save();
      if (this.anim?.native && typeof CrewArt !== 'undefined') {
        /* A MAN ON HIS BACK, ON HIS BOTTLES (update124) — his own lying
           frame, not the standing one turned on its side. */
        const lie = CrewArt.anim('die', this);
        ctx.globalAlpha = this.dead ? 0.75 : 0.9;
        lie.draw(ctx, this.x, this.y + CrewMember.BODY_DROP, 30, 30);
      } else {
        ctx.translate(this.x, this.y + 8 + CrewMember.BODY_DROP);
        ctx.rotate(-Math.PI / 2);
        ctx.globalAlpha = this.dead ? 0.75 : 0.9;
        this.anim.draw(ctx, 0, 0, 30, 30);
      }
      ctx.restore();
      // colour wash + glyph
      ctx.save();
      ctx.globalAlpha = 0.35;
      ctx.fillStyle = this.decaying ? '#3aff6a' : this.dead ? '#556' : '#ffd700';
      ctx.beginPath();
      ctx.ellipse(this.x, this.y + 6 + CrewMember.BODY_DROP, 16, 8, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
      ctx.font = '11px monospace';
      ctx.textAlign = 'center';
      ctx.fillStyle = this.decaying ? '#3aff6a' : this.dead ? '#98a0b8' : '#ffd700';
      ctx.fillText(this.decaying ? '☣' : this.dead ? '☠' : '✚',
                   this.x, this.y - 12 + CrewMember.BODY_DROP);

      /* WHO IS THAT ON THE FLOOR? (update40)
         Bodies used to be deleted the frame they died, so nobody ever
         had to identify one. Now that they lie where they fell — and
         that a rotting one infects the room — the player has to be able
         to tell a casualty he can still save from a corpse he needs to
         get to an airlock, and which of his people it is. */
      if (this.isPlayer) {
        const tag = this.decaying ? 'DECAYING' : this.dead ? 'DEAD' : 'DOWN';
        const col = this.decaying ? '#3aff6a' : this.dead ? '#98a0b8' : '#ffd700';
        ctx.font = '9px Share Tech Mono, monospace';
        const label = `${this.name} · ${tag}`;
        const lw = ctx.measureText(label).width + 6;
        ctx.fillStyle = 'rgba(7,8,15,0.8)';
        ctx.fillRect(this.x - lw / 2, this.y - 34, lw, 11);
        ctx.fillStyle = col;
        ctx.fillText(label, this.x, this.y - 26);
      }
      if (this.decaying && Math.random() < 0.04) {
        Particles.emit?.({ x: this.x + Utils.randFloat(-8, 8), y: this.y,
          vx: 0, vy: -12, ay: 0, color: '#3aff6a', size: 2, sizeEnd: 0,
          life: 1.2, alpha: 0.5, alphaEnd: 0 });
      }
      return;
    }

    ctx.save();

    if (this._facing === -1) {
      ctx.scale(-1, 1);
      ctx.translate(-this.x * 2, 0);
    }

    /* A man who just fired from his console turns side on, gun up, for
       the moment the shot takes (update174) — his own task anim resumes. */
    const aimNow = this._aimT > 0 && this._animState !== 'shoot' && this.anim?.native &&
                   this.shooter && typeof CrewArt !== 'undefined';
    if (aimNow) {
      if (!this._aimAnim) this._aimAnim = CrewArt.anim('shoot', this);
      this._aimAnim.draw(ctx, this.x, this.y, 32, 32);
    } else this.anim.draw(ctx, this.x, this.y, 32, 32);

    ctx.restore();
    /* His weapon, his shot and his charges are NOT drawn here (update174):
       Ship.draw paints them in a pass over the whole crew, or a duel
       partner drawn after him would cover the blade in his hand. */

    /* ── The stack above his head ──────────────────────────
       This used to be three things fighting over the same twelve
       pixels: the plague glyph at y-26, the virus ring at y-26, and
       an OPAQUE name plate from y-32 to y-21 drawn last, on top of
       both. The blinking infection marker was simply painted over
       every frame — you could not see it at all.

       One stack now, bottom to top, nothing overlapping:
           y-19 … y-16   health bar
           y-31 … y-20   name plate
           y-44 … y-32   plague marker
       The name moved DOWN a couple of pixels and the marker sits
       clear above it.                                            */
    /* All of it LIFT higher over the taller man (update124). */
    const LIFT = this.anim?.native ? CrewMember.LIFT : 0;
    const NAME_TOP = this.y - 31 - LIFT, NAME_H = 11;
    const MARK_Y   = this.y - 38 - LIFT;   // centre of the plague marker

    /* Health bar, closest to the helmet.
       ALWAYS drawn (update38). It used to appear only once a man was
       hurt, so a boarding party read as "some of them have no HP bar" —
       the missing bar was the healthy one. A row of full green bars is
       also how you tell at a glance which of three men in a bay is the
       one bleeding. */
    /* …EXCEPT A MAN AT HIS CONSOLE WITH NOTHING WRONG WITH HIM (update133,
       jj: "pasek HP przy konsoli — ukrywać przy pełnym zdrowiu: tak").
       The bays are full of men at their posts, and a row of full boxes
       over every console says nothing. The moment he is hurt, or steps
       off the console, the boxes are back. */
    const quietAtPost = this._animKey === 'operate' && (this.hp ?? 0) >= (this.maxHp || 1);
    /* …and NEVER over a body adrift in the wreckage (update208, jj: "ciała po zniszczeniu mają dalej HP") */
    const noBar = quietAtPost || !!this._noHpBar;
    this._hpBarHidden = noBar;
    if (!noBar) {
      const bw = 24, bh = 3;
      const bx = this.x - bw/2;
      /* TWO ROWS, NOT ONE SMEAR (update79). Boarders stand between
         your men — thirteen pixels apart — and a 24px bar at that
         spacing runs into its neighbours, so six men in a compartment
         drew as ONE long green line across the room and told the
         player nothing. Theirs ride six pixels higher: your row and
         their row, each readable, and no bar width had to be traded
         away to get it. The space is free because a boarder has no
         name label above him any more, and the floor under his feet is
         the one band in a crowded compartment that nothing else uses:
         above him are your men's names, and moving his bar up there
         only traded one collision for another — the screenshot showed
         it sitting across "Echo" and "Mira". */
      const by = this.y + (this.isPlayer ? -19 - LIFT : 6);
      const frac = Utils.clamp((this.hp ?? 0) / (this.maxHp || 1), 0, 1);
      /* BOXES, NOT A BAR (update88) — the player: "energia załogantów
         powinna być pokazana nie w barze, a w kwadracikach, tak jak na
         liście". The same `drawPips` the roster uses, one box per 20 hp,
         so a Terra hand is one box shorter here too. */
      const col = frac > 0.5 ? '#1aff8c' : '#ff2d44';
      if (typeof Renderer !== 'undefined' && Renderer.drawPips) {
        Renderer.drawPips(ctx, bx, by, bw, bh, this.hp, this.maxHp, col, undefined,
                          this.isPlayer ? null : CrewMember.ENEMY_COLOR);
      } else {
        ctx.fillStyle = '#1a0a0a';
        ctx.fillRect(bx, by, bw, bh);
        ctx.fillStyle = col;
        ctx.fillRect(bx, by, bw * frac, bh);
      }
    }

    /* Name label — YOUR people only (update79), corporation-coloured,
       dark backing. Drawn BEFORE the markers, so it can never cover
       them.
       This is the rule the body tag twenty lines up has always used —
       "who is that on the floor" is only ever asked about your own —
       and the standing label simply never got it. It did not matter
       while a compartment held three men. Now it holds six, and the
       screenshot for this package showed three raider labels painted
       across each other AND across the names of the three men of
       yours they were fighting: the one place the player must be able
       to read at a glance was the one place that turned to mush.
       A raider's name is not information you act on. Your own men's
       names are, and now they are the only ones there. */
    /* ONLY WHEN YOU LOOK AT HIM (update120, jj's pick): the name of a
       man at his console sat right across the module's display, so a
       name is shown while he is under the pointer or selected — the way
       FTL does it — and the displays are always readable. */
    if (this.isPlayer && this.nameShown()) {
      ctx.save();
      ctx.font = '9px Share Tech Mono, monospace';
      const nw = ctx.measureText(this.name).width + 6;
      ctx.fillStyle = 'rgba(7,8,15,0.75)';
      ctx.fillRect(this.x - nw/2, NAME_TOP, nw, NAME_H);
      ctx.fillStyle = this.labelColor();
      ctx.textAlign = 'center';
      ctx.fillText(this.name, this.x, NAME_TOP + 9);
      ctx.restore();
    }

    /* …AND HIS MARK (update164): the gold ◆ of his job's chip, over his
       head — gone while his name is up there instead. */
    if (this.isPassenger && !this.nameShown()) {
      const my = this.y - 25 - LIFT, mx = this.x;
      ctx.save();
      ctx.fillStyle = '#ffd700'; ctx.strokeStyle = 'rgba(7,8,15,0.85)'; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(mx, my - 3.5); ctx.lineTo(mx + 3.5, my); ctx.lineTo(mx, my + 3.5); ctx.lineTo(mx - 3.5, my); ctx.closePath();
      ctx.fill(); ctx.stroke();
      ctx.restore();
    }

    // Stunned: little sparks orbiting the helmet, so you can see WHY
    // the man in the weapons bay has stopped doing anything.
    if (this._stunT > 0) {
      const t = (this._stunT * 6) % (Math.PI * 2);
      ctx.save();
      /* HELIUM (update178): frozen by the knife — an ice-blue shell round
         him; shocked by the pistol — violet sparks */
      if (this._stunKind === 'freeze') {
        ctx.fillStyle = 'rgba(170,230,255,0.28)'; ctx.strokeStyle = 'rgba(210,245,255,0.8)'; ctx.lineWidth = 1;
        ctx.beginPath(); ctx.roundRect?.(this.x - 9, this.y - 30 - LIFT, 18, 32, 3); ctx.fill(); ctx.stroke();
      }
      ctx.strokeStyle = this._stunKind === 'shock' ? '#c58bff' : this._stunKind === 'freeze' ? '#d8f6ff' : '#8fd4ff';
      ctx.lineWidth = 1.5;
      for (let i = 0; i < 3; i++) {
        const a = t + i * (Math.PI * 2 / 3);
        ctx.beginPath();
        ctx.arc(this.x + Math.cos(a) * 9, this.y - 16 - LIFT + Math.sin(a) * 4, 1.3, 0, Math.PI * 2);
        ctx.stroke();
      }
      ctx.restore();
    }

    /* Corpse plague — GREEN and pulsing (update68). The virus below is
       RED. They were the same green and the player could not tell a
       nuisance a medkit clears from a thing that kills a man in three
       fights. The colours come from ONE table in renderer.js, so the
       roster and the deck can never disagree about which is which. */
    if (this.infected && !this.virus) {
      const pulse = 0.55 + 0.45 * Math.sin((this._infT = (this._infT ?? 0) + 0.12));
      ctx.save();
      ctx.globalAlpha = pulse;
      ctx.font = '10px monospace';
      ctx.textAlign = 'center';
      ctx.fillStyle = (typeof Renderer !== 'undefined' && Renderer.DISEASE_COL)
        ? Renderer.DISEASE_COL.plague : '#3fd96b';
      ctx.fillText('☣', this.x, MARK_Y + 4);
      ctx.restore();
    }

    // Live virus. The COUNTDOWN lives on the crew roster; here we keep a
    // pulsing ring and a glyph so you can spot the carrier at a glance.
    /* ── WHAT IS WRONG WITH HIM, OVER HIS HEAD (update80) ───
     *
     * Three markers used to be drawn here by hand — a ring with a
     * biohazard character in it, a mess tin made of an ellipse and two
     * lines, and a bottle made of a rect and a fill — while the roster
     * row drew the SAME three facts as text characters in
     * `renderer.js`. Two pictures of one thing, in two files, in two
     * languages. The player's instruction was to make them one set:
     * "uzyj tych samych co sa nad zalogantami w statku, ta sama ikonka
     * glodu i brak powietrza co jest".
     *
     * So the deck asks `Renderer.crewMarks` — the same function the
     * roster asks — and paints whatever comes back with the same
     * `drawStatIcon`. The deck shows only the SLOW killers, because a
     * repair spanner over every head in a busy hull is noise the deck
     * does not need and the roster already carries; which marks those
     * are is `DECK_MARKS`, one list, right here.
     */
    if (!this.dead && typeof Renderer !== 'undefined'
        && typeof Renderer.crewMarks === 'function') {
      const marks = Renderer.crewMarks(this, null)
        .filter(m => CrewMember.DECK_MARKS.includes(m.key));
      const S = 11, GAP = 3;
      const total = marks.length * S + (marks.length - 1) * GAP;
      let mx = this.x - total / 2;
      marks.forEach(m => {
        const pulse = m.pulse
          ? 0.55 + 0.45 * Math.sin((this._infT = (this._infT ?? 0) + 0.04))
          : 1;
        ctx.save();
        ctx.globalAlpha = pulse;
        Renderer.drawStatIcon(ctx, m.icon, mx, MARK_Y - S / 2, S, m.col);
        ctx.restore();
        mx += S + GAP;
      });
    }
  }
  // ── Serialise / deserialise ───────────────────────────────

  serialise() {
    return {
      id: this.id, name: this.name, race: this.race, isPlayer: this.isPlayer,
      joined: this.joined, faceSeed: this.faceSeed,
      virus: this.virus, virusT: this.virusT,
      /* IN A SLAB, and for how long he has been in it (update77).
         Saved, because the whole promise of carbonite is that his
         clock is where he left it — and a reload that thawed him
         would tick it on while the player was not even playing. */
      frozen: this.frozen, _slabSeq: this._slabSeq, _slabRoom: this._slabRoom, _slabIdx: this._slabIdx,
      isPrisoner: this.isPrisoner, rescued: this.rescued,
      isPassenger: this.isPassenger, jobId: this.jobId,     // update162
      battles: this.battles, wins: this.wins,
      escapes: this.escapes, kills: this.kills,
      homeRoomId: this.homeRoomId,
      state: this.state, infected: this.infected, decaying: this.decaying,
      x: this.x, y: this.y, roomId: this.roomId,
      hp: this.hp, maxHp: this.maxHp,
      /* WHAT HE IS WORTH WITHOUT A COMMANDER (update68).
       *
       * `Commander.reseatMaxHp` raises maxHp by the commander's bonus
       * and remembers the untouched figure in `baseMaxHp` so it can be
       * recomputed instead of stacked. That field was never SAVED — so
       * a man banked in the barracks came back with his RAISED maxHp
       * as his new base, and the same +2% was applied to it again next
       * contract. 100 → 102 → 104 → 106, one free point per run, for
       * as long as the commander kept his chair.
       *
       * The player caught it exactly: "czyli powiela co wyprawę, źle".
       */
      baseMaxHp: this.baseMaxHp ?? this.maxHp,
      // A body that came home starving must still be starving tomorrow,
      // and one that came home on half a bottle of air keeps that too.
      catKind: this.catKind, hunger: this.hunger, air: this.air,
      sidearm: this.sidearm ?? null,                        // update174
      sidearmRarity: this.sidearmRarity ?? null,            // update178
      skills: Utils.deepClone(this.skills),
    };
  }

  static deserialise(data) {
    return new CrewMember(data);
  }
}

// ── Crew roster helper ────────────────────────────────────

/* ── ONE NAME, ONE MAN (update54) ──────────────────────────
 *
 * Every name in this game was `Utils.pick(CREW_NAMES)` — thirty-two
 * names drawn with replacement, so by the birthday rule a barracks of
 * seven had better than even odds of holding two of the same, and the
 * player was left picking between two identical rows. Cats drew from
 * their own list the same way.
 *
 * This is the only place a name is drawn now. `taken` is passed in by
 * the caller, because the list of names in use is not a fact this file
 * owns — it lives in the barracks, the pens and the hull, and a
 * registry kept in here would be a second copy of it that goes stale
 * the moment a man dies. When the pool runs dry the name gets a roman
 * numeral rather than repeating: "Vega II" is still one man's name.
 */
/* WHO IS ALREADY SOMEBODY (update93a). Overridden by game.js with the
   names on our hull, on theirs and in the barracks; the default keeps
   this file usable on its own. */
CrewMember.namesInPlay = () => [];

function pickUniqueName(pool, taken = []) {
  const used = new Set((taken || []).filter(Boolean));
  const free = (pool || []).filter(n => !used.has(n));
  if (free.length) return Utils.pick(free);
  const ROMAN = ['II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X'];
  const base = Utils.pick(pool && pool.length ? pool : ['Hand']);
  for (const r of ROMAN) {
    const tryName = `${base} ${r}`;
    if (!used.has(tryName)) return tryName;
  }
  // Eleven of one name aboard is not a case worth carrying code for,
  // but it must still not hand back a duplicate.
  let n = 11;
  while (used.has(`${base} ${n}`)) n++;
  return `${base} ${n}`;
}

/** Build a starting crew of 3 */
function makeStartingCrew() {
  const names = Utils.shuffle([...CREW_NAMES]).slice(0, 3);
  return [
    new CrewMember({ name: names[0], skills: { piloting: {level:1,xp:0}, engines:{level:1,xp:0} } }),
    new CrewMember({ name: names[1], skills: { weapons:  {level:1,xp:0}, combat: {level:0,xp:0} } }),
    new CrewMember({ name: names[2], skills: { repair:   {level:1,xp:0}, firefight:{level:0,xp:0} } }),
  ];
}

/* makeSpiders AND makeRats ARE GONE (update84). Both built hostile
   CrewMembers so that a spider or a rat could be fought room by room.
   Neither is crew any more — `new Pest({ kind })` in pests.js is how
   one is made, and it is made straight into a duct. */

/** Build a random enemy crew of given size */
/* WHO CREWS THE OTHER SHIP (update43).
 *
 * Enemy hands used to have no corporation at all: the constructor fell
 * through to `race = 'hostile'`, which is not a key in CORP_DEFS, so
 * every corporation lookup on an enemy quietly returned undefined. That
 * was harmless while nothing asked — and stopped being harmless the
 * moment enemy CAPTAINS arrived, because a commander pays his bonus to
 * crew of his own corporation and 'hostile' matches nobody.
 *
 * The mix is per hull and deliberately NOT uniform: a raider is a
 * boarding ship and fields Phoenix knives, a gunship leans on Terra
 * engineers, the boss station keeps Aquarius damage-control aboard.
 * Each entry is one weight unit.
 *
 * This is a real difficulty change and it is meant to be: a Pegasus
 * defender does not suffocate when you vent his compartment, an
 * Aquarius one does not burn while he fights the fire, and a Terra one
 * feeds his module an extra unit of power just by standing in it.
 * Pegasus is kept scarce for exactly that reason.
 */
const ENEMY_CORP_MIX = {
  enemy_frigate: ['terra', 'terra', 'phoenix', 'aquarius'],
  enemy_gunship: ['terra', 'terra', 'terra', 'phoenix', 'aquarius'],
  enemy_raider:  ['phoenix', 'phoenix', 'phoenix', 'terra', 'pegasus'],
  boss_station:  ['aquarius', 'aquarius', 'terra', 'terra', 'phoenix', 'pegasus'],
  default:       ['terra', 'phoenix', 'aquarius'],
};

/**
 * A hostile crew.
 *
 * THEIR TRADE COUNTS FOR AS MUCH AS OURS (update55). Every enemy hand
 * used to get exactly two skills at level 1, in sector 1 and in sector
 * 8 alike — while the player's gunners, pilots and engineers climbed to
 * 3/3 and the modules paid them for it. The same accessors serve both
 * sides (`consoleOperator`, `weaponCrewBonusFor`, `evasion`), so the
 * only thing missing was ever giving the other side anything to put in
 * them. Deeper in, their people are simply better:
 *
 *   sector 1-2 → two skills at 1
 *   sector 3-4 → three skills, one of them at 2
 *   sector 5+  → three skills at 2, one of them mastered at 3
 *
 * Names are drawn against the ones already on that hull, so a boarding
 * party is not three men called Vega.
 */
function makeEnemyCrew(size = 3, hullKey = null, sector = 1, opts = {}) {
  const mix = ENEMY_CORP_MIX[hullKey] || ENEMY_CORP_MIX.default;
  const result = [];
  const s = Math.max(1, sector | 0);
  const nSkills = s >= 3 ? 3 : 2;
  const base    = s >= 5 ? 2 : 1;
  const topUp   = s >= 5 ? 3 : (s >= 3 ? 2 : 1);
  const cap = (typeof MAX_SKILL_LEVEL !== 'undefined') ? MAX_SKILL_LEVEL : 3;
  for (let i = 0; i < size; i++) {
    const c = new CrewMember({
      isPlayer: false,
      race: Utils.pick(mix),
      name: pickUniqueName(CREW_NAMES, [...result.map(r => r.name), ...CrewMember.namesInPlay()]),
    });
    const skills = Utils.shuffle(Object.keys(SKILL_DEFS)).slice(0, nSkills);
    skills.forEach((sk, n) => {
      c.skills[sk].level = Math.min(cap, n === 0 ? topUp : base);
    });
    /* ARMED (update174): nobody in sector 1, then a growing share with a
       knife, a pistol or a rifle; the boss's people always (crewarms.js). */
    if (typeof CrewArms !== 'undefined') {
      c.sidearm = CrewArms.rollEnemy(s, !!opts.boss);
      c.sidearmRarity = c.sidearm ? CrewArms.rollEnemyRarity?.(!!opts.boss) ?? null : null;   // update178
    }
    result.push(c);
  }
  return result;
}

/** A cat, ready to be put in a pen or aboard a ship. */
function makeCat(kind = null, name = null, taken = []) {
  const k   = (kind && CAT_DEFS[kind]) ? kind : Utils.pick(Object.keys(CAT_DEFS));
  const def = CAT_DEFS[k];
  return new CrewMember({
    isPlayer: true,          // ours — the room brawl will set it on the rats
    race: def.race,
    catKind: k,
    // A cat draws from the cat list but against EVERY name in the base:
    // two Lunas are confusing whether or not one of them has whiskers.
    name: name || pickUniqueName(CAT_NAMES, taken),
    hunger: CAT_TUNING.START_HUNGER,
  });
}

if (typeof window !== 'undefined') {
  window.pickUniqueName = pickUniqueName;
  window.crewColor = crewColor;
  window.makeCat = makeCat;
  window.CAT_DEFS = CAT_DEFS;
  window.CAT_TUNING = CAT_TUNING;
  window.HUNGER = HUNGER;
  window.SUIT_AIR = SUIT_AIR;
  window.BEAST_SKILLS = BEAST_SKILLS;
  window.RANKS = RANKS;
  window.MAX_RANK = MAX_RANK;
  window.rankLevelOf = rankLevelOf;
  window.rankName = rankName;
  window.ENEMY_CORP_MIX = ENEMY_CORP_MIX;
}
