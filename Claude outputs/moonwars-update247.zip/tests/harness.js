'use strict';
/* Shared Node harness for MoonWars smoke/logic tests.
 * Loads every js/*.js file (dependency order) into one vm context with
 * stubbed DOM/Audio/localStorage, so classes like Ship/CrewMember/
 * Reactor/CombatManager can be exercised directly from Node. */
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const ROOT = path.join(__dirname, '..');

// ---- Proxy canvas context: accepts ANY method/property, does nothing ----
/* THE STYLE PROPERTIES ARE VALUES, NOT METHODS.
   The proxy below turns anything non-function into a no-op function,
   which meant `ctx.fillStyle = '#f00'` wrote a string and reading it
   back handed out a function — so every draw test that tried to assert
   a COLOUR was quietly comparing two functions and passing whatever it
   was given. These read back as what was written. */
const CTX_STYLE_PROPS = new Set([
  'fillStyle', 'strokeStyle', 'font', 'textAlign', 'textBaseline',
  'lineWidth', 'lineCap', 'lineJoin', 'globalAlpha', 'globalCompositeOperation',
  'shadowColor', 'shadowBlur', 'shadowOffsetX', 'shadowOffsetY', 'filter',
  'lineDashOffset', 'miterLimit', 'imageSmoothingEnabled', 'direction',
]);

function makeCtx() {
  const handler = {
    get(target, prop) {
      if (prop === 'canvas') return target._canvas;
      if (CTX_STYLE_PROPS.has(prop)) return target[prop];
      if (!(prop in target)) {
        target[prop] = (typeof target[prop] === 'function') ? target[prop] : undefined;
      }
      if (typeof target[prop] === 'function') return target[prop];
      // Any unknown method call → no-op function returning undefined
      return function () { return undefined; };
    },
    set(target, prop, value) { target[prop] = value; return true; },
  };
  const base = {
    _canvas: null,
    /* A REAL-ISH measurement (update40).
       This returned a flat 10 for every string, so anything that lays
       out text by measuring it — `_clip`, the name plates, the
       notification wrapper — was invisible to the whole suite: every
       string "fitted" no matter how long. The game's text is monospace
       at 9-13px, so character count × 6 is close enough to catch a
       label running out of its panel. */
    measureText: (t) => ({ width: String(t ?? '').length * 6 }),
    createLinearGradient: () => ({ addColorStop: () => {} }),
    createRadialGradient: () => ({ addColorStop: () => {} }),
    getImageData: () => ({ data: new Uint8ClampedArray(4) }),
    putImageData: () => {},
    save: () => {}, restore: () => {}, beginPath: () => {}, closePath: () => {},
    fill: () => {}, stroke: () => {}, clip: () => {},
    moveTo: () => {}, lineTo: () => {}, arc: () => {}, arcTo: () => {},
    rect: () => {}, roundRect: () => {}, ellipse: () => {}, bezierCurveTo: () => {},
    quadraticCurveTo: () => {}, translate: () => {}, rotate: () => {}, scale: () => {},
    setTransform: () => {}, resetTransform: () => {}, transform: () => {},
    fillRect: () => {}, strokeRect: () => {}, clearRect: () => {},
    fillText: () => {}, strokeText: () => {}, drawImage: () => {},
    setLineDash: () => {}, createPattern: () => ({}),
  };
  return new Proxy(base, handler);
}

// Canvas elements must be REAL instances of the HTMLCanvasElement
// global so animation.js's `f instanceof HTMLCanvasElement` blit guard
// passes for generated sprite frames.
class CanvasElementStub {
  constructor() {
    this.tagName = 'CANVAS';
    this.width = 1280;
    this.height = 720;
    this.style = makeStyle();
    this._ctx = makeCtx();
  }
  getContext() { return this._ctx; }
  addEventListener() {}
  removeEventListener() {}
  getBoundingClientRect() { return { left: 0, top: 0, width: this.width, height: this.height }; }
  toDataURL() { return 'data:,'; }
}

/** Style objects must answer the CSSOM calls real code makes —
 *  setProperty() for CSS custom properties, in particular. */
function makeStyle() {
  const st = {};
  Object.defineProperties(st, {
    setProperty:      { value: (k, v) => { st[k] = v; }, enumerable: false },
    getPropertyValue: { value: (k) => st[k] ?? '', enumerable: false },
    removeProperty:   { value: (k) => { delete st[k]; }, enumerable: false },
  });
  return st;
}

function makeElement(tag) {
  if (tag === 'canvas') return new CanvasElementStub();
  const el = {
    tagName: (tag || 'div').toUpperCase(),
    style: makeStyle(),
    classList: { add() {}, remove() {}, toggle() {}, contains() { return false; } },
    children: [],
    attrs: {},
    _listeners: {},
    appendChild(child) { this.children.push(child); return child; },
    /* The station screen puts its tab bar BEFORE the content pane, so
       the stub has to answer this too — without it the shop cannot be
       opened from a test at all (update70). */
    insertBefore(child, before) {
      const i = this.children.indexOf(before);
      if (i < 0) this.children.push(child); else this.children.splice(i, 0, child);
      return child;
    },
    removeChild(child) { this.children = this.children.filter(c => c !== child); return child; },
    setAttribute(k, v) { this.attrs[k] = v; },
    getAttribute(k) { return this.attrs[k]; },
    addEventListener(evt, fn) { (this._listeners[evt] = this._listeners[evt] || []).push(fn); },
    removeEventListener() {},
    focus() {}, blur() {}, click() {},
    // ui.js drives the station panel with real DOM queries — the stub
    // has to answer them or a station visit throws mid-test.
    querySelector() { return makeElement('div'); },
    querySelectorAll() { return []; },
    getBoundingClientRect() { return { left: 0, top: 0, width: 1280, height: 720 }; },
    get innerHTML() { return this._html || ''; },
    set innerHTML(v) { this._html = v; this.children = []; },
    insertAdjacentHTML() {},
    remove() {},
  };
  return el;
}

function makeLocalStorage() {
  const store = new Map();
  return {
    getItem: (k) => (store.has(k) ? store.get(k) : null),
    setItem: (k, v) => store.set(k, String(v)),
    removeItem: (k) => store.delete(k),
    clear: () => store.clear(),
  };
}

function buildSandbox({ realStart = false } = {}) {
  const sandbox = {};
  /* The economy tests start from an empty purse; a new game has 500 CC (update154).
     loadEngine({ realStart: true }) gets the game's own number. */
  if (!realStart) sandbox.MOONWARS_START_CC = 0;
  sandbox.console = console;
  sandbox.Math = Math;
  sandbox.JSON = JSON;
  sandbox.performance = performance;
  sandbox.setTimeout = setTimeout;
  sandbox.clearTimeout = clearTimeout;
  sandbox.setInterval = setInterval;
  sandbox.clearInterval = clearInterval;

  const fakeCanvas = makeElement('canvas');
  const elements = { 'game-canvas': fakeCanvas };

  const document = {
    getElementById: (id) => elements[id] || null,
    createElement: (tag) => makeElement(tag),
    addEventListener: () => {},
    removeEventListener: () => {},
    body: makeElement('body'),
    documentElement: makeElement('html'),
  };
  // ui-overlay / station-screen / station-content etc. resolved lazily
  ['ui-overlay', 'station-screen', 'station-content', 'station-close-btn',
   'loading-screen', 'notif-container'].forEach(id => { elements[id] = makeElement('div'); });

  // Every AudioParam accepts the full scheduling API — the real audio
  // scheduler calls ramps on gain AND frequency.
  const audioParam = (v = 0) => ({
    value: v,
    setValueAtTime() { return this; },
    setTargetAtTime() { return this; },
    setValueCurveAtTime() { return this; },
    linearRampToValueAtTime() { return this; },
    exponentialRampToValueAtTime() { return this; },
    cancelScheduledValues() { return this; },
  });
  const audioNode = (extra = {}) => Object.assign({
    connect() { return this; }, disconnect() { return this; },
    start() {}, stop() {},
  }, extra);

  const AudioContextStub = function () {
    return {
      createGain: () => audioNode({ gain: audioParam(1) }),
      createOscillator: () => audioNode({ frequency: audioParam(440), detune: audioParam(0), type: 'sine' }),
      createBufferSource: () => audioNode({ buffer: null, playbackRate: audioParam(1), loop: false }),
      createBuffer: (ch = 1, len = 1) => ({ getChannelData: () => new Float32Array(len), length: len }),
      createBiquadFilter: () => audioNode({ frequency: audioParam(350), Q: audioParam(1), gain: audioParam(0), type: 'lowpass' }),
      createDynamicsCompressor: () => audioNode({
        threshold: audioParam(-24), knee: audioParam(30), ratio: audioParam(12),
        attack: audioParam(0.003), release: audioParam(0.25),
      }),
      createStereoPanner: () => audioNode({ pan: audioParam(0) }),
      createWaveShaper: () => audioNode({ curve: null, oversample: 'none' }),
      destination: audioNode(),
      sampleRate: 44100,
      currentTime: 0,
      state: 'running',
      resume: () => Promise.resolve(),
      suspend: () => Promise.resolve(),
      close: () => Promise.resolve(),
    };
  };

  const windowStub = {
    addEventListener: () => {},
    removeEventListener: () => {},
    innerWidth: 1280,
    innerHeight: 720,
    devicePixelRatio: 1,
    AudioContext: AudioContextStub,
    webkitAudioContext: AudioContextStub,
    requestAnimationFrame: (fn) => setTimeout(() => fn(performance.now()), 16),
    cancelAnimationFrame: (id) => clearTimeout(id),
    localStorage: makeLocalStorage(),
    location: { href: 'http://localhost/' },
  };

  sandbox.window = windowStub;
  sandbox.document = document;
  sandbox.localStorage = windowStub.localStorage;
  sandbox.navigator = { userAgent: 'node-test' };
  sandbox.requestAnimationFrame = windowStub.requestAnimationFrame;
  sandbox.cancelAnimationFrame = windowStub.cancelAnimationFrame;
  sandbox.AudioContext = AudioContextStub;
  // animation.js guards its blits with `f instanceof HTMLCanvasElement
  // || f instanceof ImageBitmap` — both globals must EXIST or the draw
  // throws ReferenceError. Sprite frames made by document.createElement
  // ('canvas') are instances of the stub class, so blits still run.
  sandbox.HTMLCanvasElement = CanvasElementStub;
  sandbox.ImageBitmap = class ImageBitmap {};
  sandbox.Image = class Image { constructor() { this.width = 0; this.height = 0; } };
  sandbox.OffscreenCanvas = class OffscreenCanvas {
    constructor(w, h) { this.width = w; this.height = h; }
    getContext() { return makeCtx(); }
  };

  vm.createContext(sandbox);
  return sandbox;
}

const LOAD_ORDER = [
  'utils', 'palette', 'input', 'audio', 'assets', 'particles', 'animation', 'crewart', 'crew2data', 'crewlayers', 'weaponart', 'camera',
  'save', 'crew', 'pests', 'commander', 'systems', 'weapons', 'oxygen', 'fire', 'breach',
  'elevator', 'drones', 'chips', 'cargo', 'ship', 'combat', 'patrol', 'boss', 'crewtalk', 'finish', 'eva', 'chase', 'tanks', 'console', 'crewarms', 'map', 'mapterrain', 'combatground', 'station', 'base',
  'basescreen', 'lootscreen', 'wreck', 'renderer', 'ui', 'eventview', 'nodeview', 'rewardview', 'portview', 'dockart', 'prisonview', 'stationhull', 'townview', 'game',
];

// vm.runInContext top-level `const`/`let`/`class` bindings live in the
// context's lexical environment — visible to LATER runInContext calls,
// but NOT as own-properties of the sandbox object itself, so the Node
// host side (this test file) can't reach them directly. Hoist every
// top-level declaration onto globalThis so both sides can see it.
function hoistNames(src) {
  const names = new Set();
  const re = /^(?:const|let|class|function)\s+([A-Za-z_$][\w$]*)/gm;
  let m;
  while ((m = re.exec(src))) names.add(m[1]);
  if (!names.size) return src;
  const footer = '\n;(function(){ ' +
    [...names].map(n => `try { globalThis.${n} = ${n}; } catch(e) {}`).join(' ') +
    ' })();\n';
  return src + footer;
}

// Game is one big IIFE that only exports { init } — everything the
// boarding/derelict logic lives in is private. For TESTS ONLY we widen
// that export in-memory (the shipped file is never touched) so the
// suite can drive combat directly instead of faking a browser.
/* The WHOLE public return, verbatim — the harness swaps it for a
   wider one, so it must match what game.js actually writes, closing
   brace and all. A partial match would leave the tail of the real
   object dangling after the replacement. */
const GAME_EXPORT = `return {
    init,
    hasCommander: _hasCommander,
    /* WHICH SCREEN IS UP. One word, read-only. The promotion screen
       is the first full-screen panel with no module of its own to
       ask (\`LootScreen.isOpen()\` and friends answer for the rest),
       and a browser test that cannot see it would have to guess. */
    state: () => STATE,
  };`;
// `typeof` guards keep the harness loadable against an OLDER game.js
// that predates a helper — the baseline run then fails on the specific
// assertion instead of blowing up at load time.
const T_REF = (n) => `get ${n}() { return typeof ${n} !== 'undefined' ? ${n} : undefined; }`;
const GAME_TEST_EXPORT = `return { init, hasCommander: _hasCommander, state: () => STATE, __test: {
  ${['_makeParty', '_updateParty', '_drawParty', '_drawCombat', '_updateCombat',
     '_launchBoarders', '_recallBoarders', '_recoverBoarders', '_returnBoarder',
     '_resolveEvent', '_crewClickResolve', '_playerCrewAliveCount',
     '_enemyCrewAliveCount',
     '_recallRect', '_retreatRect', '_activateCloak',
     '_travelTo', '_onWin', '_startCombat', '_spawnEnemy',
     '_maybeSOS', '_openBase', '_updateBase', '_startContract',
     '_openHold', '_openWreckLoot', '_updateLoot', '_unpackCargo', '_holdBtnRect',
     '_mapToggleRect',
     '_openWeaponLocker', '_queueWeaponLocker', '_syncAmmo', '_addMissiles',
     '_openPackScreen', '_openCpuBoard', '_awardChip', '_bossJustBeaten',
     '_payBossChip',
     '_recoverBoarders',
     '_saveStations', '_returnToStations', '_updateStation', '_saveShip', '_continueRun',
     '_creditCrew',
     '_crewUnderCursor', '_crewMouseUpdate',
     '_updateDocking', '_beginDocking', '_startWreckBoarding', '_wreckCleared',
     '_clearWreckMode',
     '_ratChance', '_rollForRats', '_syncFuel', '_addFuel', '_burnFuel', '_fuelAboard',
     '_canRetreat', '_jumpRefusal', '_startEvac', '_tickEvac', '_completeEvac', '_podSeconds',
     '_podRect', '_drawEvac', '_updateOptions', '_drawOptions', '_optValue', '_optMuted', '_paletteMode', '_applyPalette', '_optBackRect', '_optMuteRect',
     '_purgeIntruders', '_setAllDoors', '_hasCommander', '_needCommander',
     '_openPromo', '_drawPromo', '_updatePromo', '_promoRects', '_checkPromo',
     '_drawEvent', '_drawEventResult', '_eventResultRects', '_drawJumpPrompt', '_jumpPromptRect', '_jumpPrompt', '_eventReporter', '_foeSpeaker', '_handleDoorClick', '_updateDossier',
     '_giveOrder', '_boardRect', '_handlePowerBarClick',
     '_bagWantedCommander', '_maybeParley', '_parleyRefusal', '_openBlackMarket', '_spawnEnemy',
     '_seatCaptives',
     '_boardPassenger', '_watchPassengers', '_deliverJobs', '_settleJobs', '_menuActsFor',
     '_boardConvicts', '_revealJobRoutes', '_openPrison', '_updatePrison',
     '_openSecret', '_havenize',
     '_payRunGoals', '_unpackCargo', '_bodyUnderCursor', '_bodyMenuHit', '_bodyMenuBody', '_menuActsFor',
     '_finishContract', '_dockAtBase', '_nextSector', '_onLose',
     '_draw', '_update', '_updateMap', '_loop', '_cycleCrew', '_mapView',
     '_step', '_canPause', '_drawPause', '_relieveInRoom', '_openCpuBoard',
     '_drawMenu', '_updateMenu', '_menuRect', '_menuStatus', '_menuHullKey', '_menuFlyby', '_menuShipFor',
     '_newGame', '_menuConfirmRects', '_filmsOn', '_optFilmsRect', '_hitsCrew', '_crewMid', '_menuFoeShip', '_menuFightTick', '_menuFight', '_menuFightCfg', '_menuHullRect', '_menuToConvoy', '_menuShipSource', '_menuChaseCfg', '_menuChaserKey', '_updateSalvage', '_openPort', '_openStall', '_openCounter', '_openBroker', '_openGunsmith', '_hireAtBar', '_portService', '_leavePort', '_redock', '_atPort', '_dockRect', '_portRecord', '_finishMercy', '_askMei', '_awardRecord', '_payBossChip', '_spawnSalvage', '_salvageCrateAt', '_drawSalvage', '_orderSalvage', '_searchBody', '_orderSearch', '_searchErrandTick', '_probeBtnRect', '_launchProbe', '_probesAboard', '_castOff', '_airlockRoute', '_sideLocks', '_salvageHatch', '_wreckDockRoomIds', '_survivorTick', '_updateLanding', '_drawLanding', '_homeLanding', '_landing', '_sortDockLeft', '_dockLeft', '_updateOutcome', '_leavePrison', '_prisonLeaving', '_showShipAfterTakeOff', '_mapNudge', '_foeBodyUnderCursor', '_foeHands', '_bodyGrid', '_addAir', '_fuelGainMessage', '_patrolEvent', '_fitPatrol', '_veteranPatrol', '_drawTractor'].map(T_REF).join(',\n  ')},
  get menuConfirm() { return typeof _menuConfirm !== 'undefined' ? _menuConfirm : undefined; },
  set menuConfirm(v) { try { _menuConfirm = v; } catch (e) {} },
  get paused() { return _paused; },          set paused(v) { _paused = v; },
  get sectorMap() { return _sectorMap; },    set sectorMap(v) { _sectorMap = v; },
  get derelictOfferedSupported() { return typeof _derelictOffered !== 'undefined'; },
  get wreckMode() { return _wreckMode; },      set wreckMode(v) { _wreckMode = v; },
  get wreckLooted() { return _wreckLooted; },
  get STATE() { return STATE; },            set STATE(v) { STATE = v; },
  get commander() { return typeof _commander !== 'undefined' ? _commander : undefined; },
  set commander(v) { try { _commander = v; } catch (e) {} },
  get playerShip() { return _playerShip; },  set playerShip(v) { _playerShip = v; },
  get enemyShip() { return _enemyShip; },    set enemyShip(v) { _enemyShip = v; },
  get boardingParty() { return _boardingParty; }, set boardingParty(v) { _boardingParty = v; },
  get enemyParty() { return _enemyParty; },  set enemyParty(v) { _enemyParty = v; },
  get event() { return _event; },            set event(v) { _event = v; },
  get eventResult() { return typeof _eventResult !== 'undefined' ? _eventResult : undefined; },
  set eventResult(v) { try { _eventResult = v; } catch (e) {} },
  get counterBoarded() { return _counterBoarded; },
  set counterBoarded(v) { _counterBoarded = v; },
  get chaseScroll() { return typeof _chaseScroll !== 'undefined' ? _chaseScroll : undefined; },
  advanceChaseScroll: (dt) => _advanceChaseScroll(dt),
  get bodyMenu() { return typeof _bodyMenu !== 'undefined' ? _bodyMenu : undefined; },
  set bodyMenu(v) { try { _bodyMenu = v; } catch (e) {} },
  get dossier() { return typeof _dossier !== 'undefined' ? _dossier : undefined; },
  set dossier(v) { try { _dossier = v; } catch (e) {} },
  get derelictOffered() { return typeof _derelictOffered !== 'undefined' ? _derelictOffered : undefined; },
  set derelictOffered(v) { try { _derelictOffered = v; } catch (e) {} },
  get station() { return typeof _station !== 'undefined' ? _station : undefined; },
  set station(v) { try { _station = v; } catch (e) {} },
  get portMode() { return typeof _portMode !== 'undefined' ? _portMode : undefined; },
  get prison() { return typeof _prison !== 'undefined' ? _prison : undefined; },
  get queuedRecords() { return typeof _queuedRecords !== 'undefined' ? _queuedRecords : undefined; },
  set prison(v) { try { _prison = v; } catch (e) {} },
} };`;

function exposeGameInternals(src) {
  if (!src.includes(GAME_EXPORT)) {
    throw new Error('harness: game.js export signature changed — update GAME_EXPORT');
  }
  return src.replace(GAME_EXPORT, GAME_TEST_EXPORT);
}

function loadEngine({ stopBefore, realStart = false } = {}) {
  const sandbox = buildSandbox({ realStart });
  for (const name of LOAD_ORDER) {
    if (stopBefore && name === stopBefore) break;
    const file = path.join(ROOT, 'js', name + '.js');
    let src = fs.readFileSync(file, 'utf8');
    if (name === 'game') src = exposeGameInternals(src);
    vm.runInContext(hoistNames(src), sandbox, { filename: file });
  }
  /* The ducts are painted once and stamped on a real page (update189); the
     tests read every stroke of them, so here they are drawn stroke by stroke.
     A test of the stamping turns it back on for itself. */
  /* THE TANK GATE (update201): a hull leaves the base only with something in
     her tanks. Every suite written before it launches factory-fresh hulls, dry;
     the gate is opened for them, and the tests of the gate close it again. */
  if (sandbox.Base?.TANK_GATE) sandbox.Base.TANK_GATE.on = false;
  /* …and the take-off before the map (update201) would hold their launches 5 s */
  if (sandbox.BaseScreen?.DEPART) sandbox.BaseScreen.DEPART.on = false;
  if (sandbox.BaseScreen?.HELM_GATE) sandbox.BaseScreen.HELM_GATE.on = false;   // nobody at the helm, no start (update208)
  if (sandbox.DockArt?.PORT_SEQ) sandbox.DockArt.PORT_SEQ.on = false;   // the port's landing (update205)
  if (sandbox.DockArt?.HOME_SEQ) sandbox.DockArt.HOME_SEQ.on = false;   // the home landing, the ship view after take-off, the hold after the report (update214)
  if (sandbox.Ship?.FOE_AWAY) sandbox.Ship.FOE_AWAY.on = false;   // enemy ships fly away from you (update215)
  if (sandbox.PATROL) sandbox.PATROL.on = false;   // the Lunar Patrol near a sector's end (update231): her own tests switch her on
  if (sandbox.Ship) { sandbox.Ship._cacheVentsReal = sandbox.Ship.cacheVents; sandbox.Ship.cacheVents = () => false; }
  return sandbox;
}

module.exports = { loadEngine, buildSandbox, LOAD_ORDER, makeCtx, exposeGameInternals };
