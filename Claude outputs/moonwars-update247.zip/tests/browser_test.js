'use strict';
/* ============================================================
 * MOON WARS — REAL BROWSER TEST (Playwright + Chromium)
 * ============================================================
 * The vm harness stubs the canvas, the DOM and the audio graph, so it
 * cannot see: a missing <script> tag, a real Canvas2D API that rejects
 * what the stub swallowed, the station shop (which is DOM, not canvas),
 * or anything that only breaks once a browser is actually running the
 * loop. That is what this file is for.
 *
 * It serves the repo over http://127.0.0.1 and drives the REAL game:
 * real clicks at real canvas coordinates, real drags, real page errors.
 *
 *   session 1 — boot, ENTER BASE, every tab, the shelf, LAUNCH
 *   session 2 — an OUT-OF-DATE index.html and the runtime self-repair
 *   session 3 — the salvage screen with a real drag & drop
 *   session 4 — the station shop: stat chips and the reactor quote
 *   session 5 — the shop reads karma: surcharge banner and a shut dock
 *   session 6 — real sprite pixels: what lives in the duct has to fit
 *
 * Without playwright installed this exits CLEANLY (0) — it is an extra
 * pair of eyes, not a gate on machines that lack the browser.
 *
 * REBUILT in update43: the original file was lost (never tracked in
 * git, absent from the archive). Assertion count therefore differs from
 * the pre-update43 figure of 45 — see HANDOFF §4.
 * ============================================================ */

const http = require('http');
const fs   = require('fs');
const path = require('path');

const ROOT = path.join(__dirname, '..');

let chromium;
try {
  ({ chromium } = require('playwright'));
} catch (e) {
  console.log('playwright is not installed — skipping the browser test.');
  console.log('  install it with:  npm install playwright');
  process.exit(0);
}

let passed = 0, failed = 0;
function ok(cond, msg) {
  if (cond) { passed++; console.log('  ok   ' + msg); }
  else { failed++; console.error('  FAIL ' + msg); }
}
function section(name) { console.log('\n— ' + name + ' —'); }

// ── Static server ───────────────────────────────────────────

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js':   'text/javascript; charset=utf-8',
  '.css':  'text/css; charset=utf-8',
  '.png':  'image/png', '.webp': 'image/webp', '.jpg': 'image/jpeg', '.svg': 'image/svg+xml',
};

/** `overrides` lets a session serve a DIFFERENT index.html without ever
 *  touching the file on disk — session 2 needs a stale one. */
function serve(overrides = {}) {
  const server = http.createServer((req, res) => {
    let rel = decodeURIComponent(req.url.split('?')[0]);
    if (rel === '/') rel = '/index.html';
    if (overrides[rel] !== undefined) {
      res.writeHead(200, { 'Content-Type': MIME['.html'] });
      res.end(overrides[rel]);
      return;
    }
    const file = path.join(ROOT, rel);
    if (!file.startsWith(ROOT) || !fs.existsSync(file) || fs.statSync(file).isDirectory()) {
      res.writeHead(404); res.end('not found'); return;
    }
    res.writeHead(200, { 'Content-Type': MIME[path.extname(file)] ?? 'application/octet-stream' });
    fs.createReadStream(file).pipe(res);
  });
  return new Promise(resolve => {
    server.listen(0, '127.0.0.1', () => resolve({
      server,
      url: 'http://127.0.0.1:' + server.address().port + '/',
      close: () => new Promise(r => server.close(r)),
    }));
  });
}

// ── Page helpers ────────────────────────────────────────────

/** Everything the page shouted about while a session ran.
 *  Only OUR files count: the stylesheet pulls Orbitron from Google
 *  Fonts and the browser asks for a favicon, and neither failing says
 *  anything about the game. */
function watchErrors(page, origin) {
  const errors = [];
  page.on('pageerror', e => errors.push('pageerror: ' + e.message));
  page.on('console', m => {
    if (m.type() !== 'error') return;
    const src = m.location()?.url ?? '';
    if (src && !src.startsWith(origin)) return;         // third-party asset
    if (/favicon/i.test(src)) return;
    errors.push('console.error: ' + m.text() + (src ? '  [' + src + ']' : ''));
  });
  return errors;
}

/** Wait until Game.init() has finished and the menu loop is running. */
async function waitForBoot(page) {
  await page.waitForFunction(
    () => typeof Assets !== 'undefined' && typeof Renderer !== 'undefined'
       && !!Renderer.getCtx() && document.getElementById('loading-bar')
       && document.getElementById('loading-bar').style.width === '100%',
    null, { timeout: 30000 });
  // …plus the half-second the boot sequence spends on 'Ready.'
  await page.waitForTimeout(900);
}

/** Canvas game coordinates → a real mouse click on the page. */
async function canvasPoint(page, gx, gy) {
  return page.evaluate(([x, y]) => {
    const c = document.getElementById('game-canvas');
    const r = c.getBoundingClientRect();
    // update109: the backing is real pixels — the game's space is the renderer's.
    return { x: r.left + x * (r.width / Renderer.getWidth()), y: r.top + y * (r.height / Renderer.getHeight()) };
  }, [gx, gy]);
}
async function clickCanvas(page, gx, gy) {
  const p = await canvasPoint(page, gx, gy);
  await page.mouse.move(p.x, p.y);
  await page.waitForTimeout(60);      // let a frame register the hover
  await page.mouse.click(p.x, p.y);
  await page.waitForTimeout(160);     // …and a few frames act on the click
}
/**
 * Move a crate the way a PLAYER does since update48: click it, walk the
 * cursor over, click again. The old helper held the button down for the
 * whole trip, which is the interaction that was removed — a crate now
 * stays in the hand between the two clicks, and passing the cursor over
 * other crates on the way must change nothing.
 */
async function dragCanvas(page, from, to) {
  const a = await canvasPoint(page, from[0], from[1]);
  const b = await canvasPoint(page, to[0], to[1]);
  await page.mouse.move(a.x, a.y);
  await page.waitForTimeout(60);
  await page.mouse.click(a.x, a.y);
  await page.waitForTimeout(80);
  // Several steps, deliberately passing over whatever lies between.
  for (let i = 1; i <= 6; i++) {
    await page.mouse.move(a.x + (b.x - a.x) * i / 6, a.y + (b.y - a.y) * i / 6);
    await page.waitForTimeout(35);
  }
  await page.mouse.click(b.x, b.y);
  await page.waitForTimeout(160);
}

/** Click a base-screen button by the ACTION its zone carries, so the
 *  test presses what the player presses — not what we hope is there. */
/** Open a base tab the way the player does since update115: its GROUP
 *  first, then the sub-tab if the group has more than one screen. */
async function clickBaseTab(page, tab) {
  /* update149/152: every screen is a building — out to the town by ◀ TOWN, in by its door */
  if (!(await page.evaluate(() => BaseScreen._state().town))) {
    await clickBaseAct(page, 'town');
    await page.waitForTimeout(120);
  }
  const okDoor = await clickBaseAct(page, 'building', tab);
  await page.waitForTimeout(80);
  return okDoor && await page.evaluate((t) => BaseScreen._state().tab === t && !BaseScreen._state().town, tab);
}

async function clickBaseAct(page, act, argMatch = null) {
  const zone = await page.evaluate(([a, m]) => {
    const zs = BaseScreen._zonesFor(a);
    const z = m === null ? zs[0] : zs.find(q => JSON.stringify(q.arg) === JSON.stringify(m));
    return z ? { x: z.x, y: z.y, w: z.w, h: z.h } : null;
  }, [act, argMatch]);
  if (!zone) return false;
  await clickCanvas(page, zone.x + zone.w / 2, zone.y + zone.h / 2);
  return true;
}

// ════════════════════════════════════════════════════════════
// SESSION 1 — boot, base, every tab, the shelf, LAUNCH
// ════════════════════════════════════════════════════════════

async function session1(browser) {
  section('SESSION 1 — boot → ENTER BASE → tabs → shelf → LAUNCH');
  const host = await serve();
  const page = await browser.newPage({ viewport: { width: 1280, height: 720 } });
  const errors = watchErrors(page, host.url);

  try {
    await page.goto(host.url, { waitUntil: 'load' });
    await waitForBoot(page);

    ok(await page.evaluate(() => typeof Base !== 'undefined'),
       'base.js loaded from index.html');
    ok(await page.evaluate(() => typeof BaseScreen !== 'undefined'),
       'basescreen.js loaded from index.html');
    ok(await page.evaluate(() => typeof LootScreen !== 'undefined'),
       'lootscreen.js loaded from index.html');
    ok(await page.evaluate(() => typeof CargoGrid !== 'undefined'),
       'cargo.js loaded from index.html');
    ok(await page.evaluate(() => typeof DockingGame !== 'undefined'),
       'wreck.js loaded from index.html');
    ok(await page.evaluate(() => typeof Commander !== 'undefined'),
       'commander.js loaded from index.html');
    ok(await page.evaluate(() => typeof CombatGround !== 'undefined'),
       'combatground.js loaded from index.html (update170)');

    /* THE HULL PICTURES REALLY LOAD (update116). The node suite can only
       read the files' headers; this is the browser decoding them, from
       the manifest, at boot — and a real ship accepting the one meant
       for her (a picture the wrong size would be refused, silently). */
    const hulls = await page.evaluate(() => {
      const names = Object.keys(SHIP_LAYOUTS).flatMap(k => [HULL_ART.name(k, true), HULL_ART.name(k, false)]);
      const loaded = names.filter(n => Assets.source(n) === 'file' && Assets.get(n)?.width > 0).length;
      const you = new Ship('scout', true, Ship.PLAYER_STATION.x, Ship.PLAYER_STATION.y);
      const them = new Ship('enemy_raider', false, Ship.ENEMY_STATION.x, Ship.ENEMY_STATION.y);
      return { n: names.length, loaded, you: !!you.hullArt(), them: !!them.hullArt() };
    });
    ok(hulls.loaded === hulls.n, `every hull picture is loaded at boot (${hulls.loaded}/${hulls.n})`);
    ok(hulls.you && hulls.them, 'and a ship of yours and one of theirs each take their own and draw it');

    /* …AND THEIR ROOFS (update118), and the films are on in the real game. */
    const roofs = await page.evaluate(() => {
      const names = Object.keys(SHIP_LAYOUTS).flatMap(k => [HULL_ART.roofName(k, true), HULL_ART.roofName(k, false)]);
      const loaded = names.filter(n => Assets.source(n) === 'file' && Assets.get(n)?.width > 0).length;
      const you = new Ship('scout', true, Ship.PLAYER_STATION.x, Ship.PLAYER_STATION.y);
      const them = new Ship('enemy_raider', false, Ship.ENEMY_STATION.x, Ship.ENEMY_STATION.y);
      return { n: names.length, loaded, you: !!you.roofArt(), them: !!them.roofArt(), films: JumpScene.enabled };
    });
    ok(roofs.loaded === roofs.n && roofs.you && roofs.them, `every roof is loaded at boot and taken by its hull (${roofs.loaded}/${roofs.n})`);
    ok(roofs.films === true, 'the jump and the arrival are filmed in the real game');

    /* …AND THE CREW, EACH WITH HIS OWN FACE (update124). */
    {
      const crew = await page.evaluate(() => {
        const c = new CrewMember({ name: 'Probe', race: 'terra', isPlayer: true });
        c._setAnim('operate');
        const f = c.anim.frames[0];
        const g = f.getContext('2d').getImageData(0, 0, f.width, f.height).data;
        let lit = 0; for (let i = 3; i < g.length; i += 4) if (g[i] > 0) lit++;
        const p = CrewArt.portraitCanvas(c.serialise());
        const pg = p.getContext('2d').getImageData(0, 0, 48, 48).data;
        let plit = 0; for (let i = 3; i < pg.length; i += 4) if (pg[i] > 0) plit++;
        return { loaded: typeof window.CrewArt, view: c.anim.view, w: f.width, h: f.height, lit, plit,
                 layered: !!c.anim.layered, ready: CrewLayers.ready(), native: c.anim.native };
      });
      /* update246: in the real game the crew is drawn from LAYERS (crewlayers.js, 40 x 34 units at 3 px); the
         24 x 32 pixel man is the floor for a page without the pictures (and the node tests). */
      ok(crew.ready && crew.layered, 'the layered crew is loaded in the real game (crewlayers.js, art/crew2_*.png)');
      ok(crew.loaded === 'object' && crew.view === 'back' && crew.w === 120 && crew.h === 102
         && crew.native?.w === 40 && crew.native?.h === 34 && crew.native?.smooth,
         `crewart.js hands a man at a console to the layers: from his back, 40 x 34 units at 3 px, smoothed (${crew.w}x${crew.h})`);

    /* …AND THE PORT IS A PROMENADE (update143): drawn in a real browser,
       the hull's own picture in the window, a real face at each counter. */
    {
      const port = await page.evaluate(() => {
        const st = new Station(2, 4242), sh = new Ship('scout', true, 80, 120);
        PortView.open(st, sh);
        const c = document.createElement('canvas'); c.width = 1280; c.height = 720;
        const g = c.getContext('2d');
        PortView.draw(g);
        const px = (x, y) => g.getImageData(x, y, 1, 1).data;
        /* her middle as the scene laid her out (update218: the stage has sky over the hangar now — a fixed pixel
           fell in a seam between her modules); the brightest of a few around it */
        const S = StationScene._state(), L = S.layout, o = S.ours.roomBounds(), W0 = StationScene.WIN;
        const mx = W0.x + L.k * (L.rx + o.w / 2), my = W0.y + L.k * (L.ry + o.h / 2);
        let best = [0, 0, 0];
        for (let dx = -24; dx <= 24; dx += 8) for (let dy = -12; dy <= 12; dy += 6) { const q = px(Math.round(mx + dx), Math.round(my + dy)); if (q[0] + q[1] + q[2] > best[0] + best[1] + best[2]) best = q; }
        const shipPx = best, face = px(PortView.stallRect(2).x + PortView.stallRect(2).w / 2, (176 + 94) * 2 - 30);
        PortView.close();
        return { loaded: typeof window.PortView, art: !!sh.hullArt(), shipLit: shipPx[0] + shipPx[1] + shipPx[2], faceA: face[3] };
      });
      ok(port.loaded === 'object' && port.art, 'portview.js is loaded, and the hull that docks has its picture');
      ok(port.shipLit > 60 && port.faceA > 0, `the promenade is painted: a hull in the window, a face at the counter (${port.shipLit}, ${port.faceA})`);
      /* update151: the plans — the ship roofless on the stage, a module's own picture on the card */
      const plans = await page.evaluate(() => {
        const st = new Station(2, 4242), sh = new Ship('scout', true, 80, 120);
        sh._allocateDefaultPower();
        PortView.open(st, sh); PortView.openPlans();
        const c = document.createElement('canvas'); c.width = 1280; c.height = 720;
        const g = c.getContext('2d');
        PortView.draw(g);
        const lit = (r) => { const d = g.getImageData(r.x, r.y, r.w, r.h).data; let n = 0; for (let i = 0; i < d.length; i += 4) if (d[i] + d[i + 1] + d[i + 2] > 120) n++; return n; };
        const room = sh.rooms.find(q => q.type !== 'empty'), R = PortView.planRoomRect(room.id), C = PortView.planRects().card;
        const out = { view: PortView.view(), room: lit({ x: Math.round(R.x), y: Math.round(R.y), w: Math.round(R.w), h: Math.round(R.h) }),
                      art: lit({ x: C.x + 26, y: C.y + 56, w: C.w - 52, h: 134 }), hasArt: !!moduleArt(room.type, hullBuilder(sh.layoutKey)) };
        PortView.close();
        return out;
      });
      ok(plans.view === 'plans' && plans.room > 300, `the plans draw the ship, its modules lit (${plans.room} bright pixels in ${'the first module'})`);
      ok(!plans.hasArt || plans.art > 300, `and the picked module's own picture on the card (${plans.art})`);
    }
      ok(crew.lit > 150 && crew.plit > 1500, `his frame and his portrait really have pixels in them (${crew.lit}, ${crew.plit})`);
    }

    /* …unless the player switched them off in OPTIONS (update122): a fresh
       page whose saved settings say so boots with no films. */
    {
      const p2 = await browser.newPage({ viewport: { width: 1280, height: 720 } });
      try {
        await p2.addInitScript(() => {
          try { localStorage.setItem('moonwars_settings_v1', JSON.stringify({ jumpFilms: false })); } catch (e) { /* none */ }
        });
        await p2.goto(host.url, { waitUntil: 'load' });
        await waitForBoot(p2);
        const off = await p2.evaluate(() => ({ en: JumpScene.enabled, set: Save.getSetting('jumpFilms') }));
        ok(off.en === false && off.set === false, 'films switched off in the saved settings: the game boots without them');
      } finally { await p2.close(); }
    }

    /* …AND THE INSIDE OF EVERY MODULE (update119). */
    const rooms = await page.evaluate(() => {
      const types = ['empty', ...Object.keys(SYSTEM_DEFS)];
      const yards = Object.keys(YARD_TRIM).filter(k => !k.startsWith('_'));
      const got = types.filter(t => moduleArt(t) && yards.every(y => moduleArt(t, y) && moduleArt(t, y) !== moduleArt(t))).length;
      return { n: types.length, got };
    });
    ok(rooms.got === rooms.n, `every module's picture is loaded at boot and fits a room, plain and in every yard's colours (${rooms.got}/${rooms.n})`);

    // ENTER BASE — first item of MENU_ITEMS, canvas coordinates from _drawMenu
    await clickCanvas(page, 640, 360);
    const inBase = await page.waitForFunction(
      () => !!BaseScreen._state() && !!BaseScreen._zonesFor('building').length,
      null, { timeout: 5000 }).then(() => true).catch(() => false);
    ok(inBase, 'ENTER BASE opens the base screen (it used to click and do nothing)');
    /* update149: and the base is the town — painted for real, nine doors */
    ok(await page.evaluate(() => BaseScreen._state().town && TownView.town()?.img?.width === 640
                             && new Set(BaseScreen._zonesFor('building').map(z => z.arg)).size === 9),
       'the base opens on the town: the painting is real and all nine doors are there (the old workshop is DISPATCH, update161)');

    // Every tab, checked by WHICH TAB OPENED — not by "no error".
    // A coordinate-only loop went on quietly clicking the wrong tabs for
    // several updates and stayed green the whole time.
    for (const tab of ['HANGAR', 'ARMOURY', 'CREW', 'MESS', 'SUPPLY', 'MEMORIAL']) {
      const clicked = await clickBaseTab(page, tab);
      const now = await page.evaluate(() => BaseScreen._state().tab);
      ok(clicked && now === tab, `tab ${tab} opens ${tab} (opened: ${now})`);
    }

    /* THE PODS OF update155: a real click on a man's pod opens his file. */
    await clickBaseTab(page, 'CREW');
    const pod = await page.evaluate(() => BaseScreen.barracksRects().pods.find(p => p.kind === 'man'));
    if (pod) {
      await clickCanvas(page, pod.x + pod.w / 2, pod.y + 60);
      ok(await page.evaluate((id) => BaseScreen.bunkSel() === id, pod.id), 'a real click on a pod opens that man\'s file');
    } else ok(true, 'no man in the barracks to click (fresh save)');

    /* THE HANGAR OF update154: a real click on a hull in the shipyard puts her in the
       cradle; a real ESC puts yours back. */
    await clickBaseTab(page, 'HANGAR');
    const saleKey = await page.evaluate(() => BaseScreen.hangarRects().yardTiles[0]?.key);
    await clickBaseAct(page, 'yardView', saleKey);
    ok(await page.evaluate((k) => BaseScreen._state().yardPick === k, saleKey), `a click on a hull for sale shows her in the cradle (${saleKey})`);
    await page.keyboard.press('Escape'); await page.waitForTimeout(150);
    ok(await page.evaluate(() => BaseScreen._state().yardPick === null && !BaseScreen._state().town), 'ESC: your own ship back, still in the hangar');

    /* THE MESS (update43), driven the way the player drives it: build
       it, promote somebody, and check the barracks actually shrank. */
    await clickBaseTab(page, 'MESS');
    await page.evaluate(() => {
      Save.addScrapBank(2000);
      // A veteran worth promoting, put in by hand so the test does not
      // depend on the random skills a recruit happens to roll.
      const b = Base.get();
      b.barracks.push({ id: 'probe1', name: 'Probe', race: 'terra', hp: 100, maxHp: 100,
                        skills: { repair: { level: 3, xp: 0 } } });
      Save.save();
    });
    await clickBaseTab(page, 'CREW');
    await clickBaseTab(page, 'MESS');
    ok(await page.evaluate(() => Base.messLevel() === 1 && Base.messCap() === 1),
       'the mess stands at level I with one berth, unbought (update44)');
    ok(!(await clickBaseAct(page, 'buyMess')),
       'and carries no BUILD button of its own — its chairs are built from the cook\'s box (update154)');
    const bunksBefore = await page.evaluate(() => Base.crew().length);
    const promoted = await clickBaseAct(page, 'promote', 'probe1');
    ok(promoted, 'a promotable veteran gets a PROMOTE button');
    ok(await page.evaluate(() => Base.commanders().length === 1),
       'pressing it puts him in the mess');
    ok(await page.evaluate(() => Base.crew().length) === bunksBefore - 1,
       'and takes him OUT of the barracks — he does not exist twice');
    ok(await page.evaluate(() => BaseScreen._state().commanderId === Base.commanders()[0].id),
       'the new commander is the one flying the next contract');

    /* ── THE PROMOTION SCREEN IS IN THE WAY, ON PURPOSE (update52) ──
     * He arrives owing one attribute point per level (update98), and the
     * screen opens for them straight away rather than waiting behind a
     * button. That is the behaviour under test here — and then the
     * points have to actually be spendable, or the base is unreachable. */
    await page.waitForTimeout(200);
    ok(await page.evaluate(() => Game.state() === 'promo'),
       'the promotion screen opens the moment he takes the chair');
    const owed = await page.evaluate(() =>
      Commander.pointsOwed(Base.commanders()[0]));
    ok(owed >= 1, `and it owes him one attribute point per level (${owed})`);

    for (let i = 0; i < owed + 2; i++) {
      if (await page.evaluate(() => Game.state() !== 'promo')) break;
      await clickCanvas(page, 640, 428);       // one of the four attribute rows (update98)
      await page.waitForTimeout(120);
    }
    ok(await page.evaluate(() => Game.state() === 'base'),
       'spending the last point hands the base back');
    ok(await page.evaluate(() => Commander.pointsOwed(Base.commanders()[0]) === 0),
       'and every level he had is now spent on something');
    ok(await page.evaluate(() =>
         Commander.pointsSpent(Base.commanders()[0]) === Base.commanders()[0].level),
       'one point per level, no more and no fewer');

    // The shelf / PACK HOLD screen (one screen since update35)
    await clickBaseTab(page, 'SUPPLY');
    const openedShelf = await clickBaseAct(page, 'warehouse');
    const shelfUp = await page.evaluate(() => LootScreen.isOpen());
    ok(openedShelf && shelfUp, 'OPEN SHELF puts the two-grid pack screen up');
    ok(await page.evaluate(() => !!LootScreen._gridRect('hold')),
       'the pack screen has a hold grid to drop things into');
    ok(await page.evaluate(() => !!LootScreen._gridRect('wreck')),
       'the pack screen has the shelf on the other side');

    // Back out of it the way the player does.
    const closeZone = await page.evaluate(() => {
      const z = LootScreen._zoneFor('close') || LootScreen._zoneFor('done');
      return z ? { x: z.x, y: z.y, w: z.w, h: z.h } : null;
    });
    if (closeZone) await clickCanvas(page, closeZone.x + closeZone.w / 2, closeZone.y + closeZone.h / 2);
    else await page.keyboard.press('Escape');
    await page.waitForTimeout(300);
    ok(!(await page.evaluate(() => LootScreen.isOpen())), 'the pack screen closes again');

    // HANGAR: pick the hull we own
    await clickBaseTab(page, 'HANGAR');
    ok(await page.evaluate(() => BaseScreen._state().tab === 'HANGAR'), 'back in the hangar');
    ok(await page.evaluate(() => Base.ships().length > 0), 'there is a hull in the berth to fly');

    /* THE LOADOUT AND THE DESTINATION (update113): the bar's button opens
       the loadout, ESCAPE closes it, ENTER opens it again; a crate is moved
       with the real mouse; START CONTRACT opens the destination, and LAUNCH
       there starts the contract. */
    ok(await clickBaseAct(page, 'loadout'), 'the LOADOUT button is on the base');
    await page.waitForTimeout(250);
    ok(await page.evaluate(() => BaseScreen._state().loadout), 'it opens the loadout');
    ok(await page.evaluate(() => BaseScreen._zonesFor('tabGroup').length === 0 && BaseScreen._zonesFor('tab').length === 0
                                 && BaseScreen._zonesFor('building').length === 0),
       'nothing behind it can be pressed');
    await page.keyboard.press('Escape');
    await page.waitForTimeout(250);
    ok(await page.evaluate(() => !BaseScreen._state().loadout), 'ESCAPE closes it');
    await page.keyboard.press('Enter');
    await page.waitForTimeout(250);
    ok(await page.evaluate(() => BaseScreen._state().loadout), 'ENTER opens it from the base');
    {
      // He2 from the shelf into the hold, by mouse: click it, click a free hold cell.
      const pts = await page.evaluate(() => {
        const R = BaseScreen.loadoutRects(), P = LootScreen.CELL + LootScreen.GAP;
        const g = BaseScreen.liveShelf(), v = BaseScreen._state().shelfView;
        const it = g.items.find(i => i.def.kind === 'fuel');
        if (!it) return null;
        const h = BaseScreen._state().hold;
        let free = null;
        for (let y = 0; y < h.rows && !free; y++) for (let x = 0; x < h.cols && !free; x++) if (h.fits(it, x, y)) free = { x, y };
        return { a: { x: R.shelf.x + (it.x - v.x) * P + P / 2, y: R.shelf.y + (it.y - v.y) * P + P / 2 },
                 b: { x: R.hold.x + free.x * P + P / 2, y: R.hold.y + free.y * P + P / 2 },
                 before: h.countOf('fuel') };
      });
      if (pts) {
        await clickCanvas(page, pts.a.x, pts.a.y);
        await page.waitForTimeout(450);
        await clickCanvas(page, pts.b.x, pts.b.y);
        await page.waitForTimeout(200);
        const after = await page.evaluate(() => BaseScreen._state().hold.countOf('fuel'));
        ok(after > pts.before, `a He2 crate dragged from the shelf into the hold with the mouse (${pts.before} → ${after})`);
      } else ok(true, '(no He2 on the shelf to move)');
    }
    /* HER TANKS FIRST (update201): a dry hull does not leave — the warehouse's
       bottles poured in, the pump for the rest. */
    {
      const dry = await page.evaluate(() => Base.tankRefusal(0));
      ok(!!dry, `a factory-fresh hull is dry: "${dry}"`);
      const r = await page.evaluate(() => [Base.fillShipTanks(0, 'pour'), Base.fillShipTanks(0, 'air'), Base.fillShipTanks(0, 'he2')].map(x => x.ok));
      ok(await page.evaluate(() => Base.tankRefusal(0) === null), `filled in the hangar, she may go (${r.join(',')})`);
    }
    ok(await clickBaseAct(page, 'toDest'), 'START CONTRACT is on the loadout');
    await page.waitForTimeout(250);
    ok(await page.evaluate(() => BaseScreen._state().dest), 'it opens the destination');

    // LAUNCH — on the destination screen, with Luna's contract picked
    const launched = await clickBaseAct(page, 'launch');
    const inRun = await page.waitForFunction(
      () => Save.hasActiveRun() && !!Save.getRun(),
      null, { timeout: 12000 }).then(() => true).catch(() => false);
    ok(inRun, 'LAUNCH starts a contract — after she takes off (update201)');
    ok(await page.evaluate(() => !!Save.getRun().commanderId),
       'and the commander sails with it');
    ok(await page.evaluate(() => (Base.commanders()[0] || {}).away === true),
       'his berth is still his while he is out there');
    ok(await page.evaluate(() => (Save.getRun().sector ?? 1) >= 1),
       'the run begins in a sector');

    await page.waitForTimeout(700);   // a few frames of the map/ship view
    ok(errors.length === 0, 'no page errors during the whole base tour'
       + (errors.length ? ':\n       ' + errors.join('\n       ') : ''));
  } finally {
    await page.close();
    await host.close();
  }
}

// ════════════════════════════════════════════════════════════
// SESSION 2 — a stale index.html repairs itself at runtime
// ════════════════════════════════════════════════════════════

async function session2(browser) {
  section('SESSION 2 — an OUT-OF-DATE index.html self-repairs');

  const real = fs.readFileSync(path.join(ROOT, 'index.html'), 'utf8');
  // Exactly what a player has who copied js/ over an old checkout.
  const LATE = ['js/base.js', 'js/basescreen.js', 'js/cargo.js',
                'js/lootscreen.js', 'js/wreck.js', 'js/commander.js'];
  let stale = real;
  LATE.forEach(src => {
    stale = stale.replace(new RegExp(`\\s*<script src="${src.replace('.', '\\.')}"></script>`, 'g'), '');
  });
  ok(LATE.every(s => !stale.includes(s)),
     'test setup: the stale page really is missing the late modules');
  ok(stale.includes('js/game.js'), 'test setup: the stale page still boots game.js');

  const host = await serve({ '/index.html': stale });
  const page = await browser.newPage({ viewport: { width: 1280, height: 720 } });
  const errors = watchErrors(page, host.url);

  try {
    await page.goto(host.url, { waitUntil: 'load' });
    await waitForBoot(page);

    const healed = await page.evaluate(() =>
      ['Base', 'BaseScreen', 'CargoGrid', 'LootScreen', 'DockingGame', 'Commander']
        .filter(n => typeof window[n] === 'undefined'));
    ok(healed.length === 0,
       `the game loads its own missing modules (still missing: ${healed.join(', ') || 'none'})`);

    const autoloaded = await page.evaluate(() =>
      [...document.querySelectorAll('script[data-autoloaded="true"]')].map(s => s.getAttribute('src')));
    ok(autoloaded.length === LATE.length,
       `all ${LATE.length} late modules were injected at runtime, got ${autoloaded.length}`);
    ok(LATE.every(s => autoloaded.includes(s)),
       'every missing script is the one that got injected');

    // And the repaired page must actually WORK, not merely define things.
    await clickCanvas(page, 640, 360);
    const inBase = await page.waitForFunction(
      () => !!BaseScreen._zonesFor('building').length, null, { timeout: 5000 })
      .then(() => true).catch(() => false);
    ok(inBase, 'ENTER BASE works on the repaired page — this is the bug it exists for');

    ok(errors.filter(e => e.startsWith('pageerror')).length === 0,
       'a self-repaired page throws nothing'
       + (errors.length ? ':\n       ' + errors.join('\n       ') : ''));
  } finally {
    await page.close();
    await host.close();
  }
}

// ════════════════════════════════════════════════════════════
// SESSION 3 — the salvage screen, with a REAL drag & drop
// ════════════════════════════════════════════════════════════

async function session3(browser) {
  section('SESSION 3 — the salvage screen: a REAL drag & drop');
  const host = await serve();
  const page = await browser.newPage({ viewport: { width: 1280, height: 720 } });
  const errors = watchErrors(page, host.url);

  try {
    await page.goto(host.url, { waitUntil: 'load' });
    await waitForBoot(page);

    /* The two-grid salvage screen is ONE mechanism — the derelict hold,
       PACK HOLD and the weapon locker all open the same LootScreen. The
       shelf is the only one the player can reach in four clicks, so the
       drag is done there, driven by the GAME'S OWN loop: nothing here
       fakes a frame, a click or a coordinate. The derelict's own grid is
       checked separately below. */

    // Put something on the shelf to drag.
    const stocked = await page.evaluate(() => {
      Base.buySupply?.('fuel', 4);
      const g = Base.warehouseGrid();
      if (!g.items.length) { g.add('ration_pack'); Base.commitWarehouse(g); }
      return Base.warehouseGrid().items.length;
    });
    ok(stocked > 0, `the shelf has something on it to move (${stocked} stacks)`);

    await clickCanvas(page, 640, 360);                 // ENTER BASE
    await page.waitForFunction(() => !!BaseScreen._zonesFor('building').length,
                               null, { timeout: 5000 });
    await clickBaseTab(page, 'SUPPLY');
    await clickBaseAct(page, 'warehouse');             // OPEN SHELF
    await page.waitForTimeout(300);
    ok(await page.evaluate(() => LootScreen.isOpen()),
       'the two-grid salvage screen is up, driven by the real game loop');

    /* Where IS a given cell on screen? _gridRect does not publish its
       cell size, so the point is found through _cellAt — the same
       function the game uses to decide what the mouse is over. */
    const geom = await page.evaluate(() => {
      const pointFor = (which, cx, cy) => {
        const r = LootScreen._gridRect(which);
        if (!r) return null;
        for (let y = r.y + 2; y < r.y + r.h; y += 2)
          for (let x = r.x + 2; x < r.x + r.w; x += 2) {
            const c = LootScreen._cellAt(which, x, y);
            if (c && c.cx === cx && c.cy === cy) return [x, y];
          }
        return null;
      };
      const shelf = LootScreen._gridRect('wreck').grid;
      const hold  = LootScreen._gridRect('hold').grid;
      const it = shelf.items[0];
      if (!it) return { error: 'the shelf grid came up empty' };
      // A cell in the hold nothing occupies yet.
      let dest = null;
      for (let y = 0; y < hold.rows && !dest; y++)
        for (let x = 0; x < hold.cols && !dest; x++)
          if (!hold.at(x, y)) dest = [x, y];
      return {
        id: it.id, defKey: it.defKey,
        shelfBefore: shelf.items.length,
        holdBefore:  hold.items.length,
        from: pointFor('wreck', it.x, it.y),
        to:   dest ? pointFor('hold', dest[0], dest[1]) : null,
      };
    });
    ok(!geom.error && geom.from && geom.to,
       'a crate on the shelf and an empty cell in the hold can both be pointed at'
       + (geom.error ? ' — ' + geom.error : ''));

    if (geom.from && geom.to) {
      await dragCanvas(page, geom.from, geom.to);

      const after = await page.evaluate(() => ({
        shelf: LootScreen._gridRect('wreck').grid.items.length,
        hold:  LootScreen._gridRect('hold').grid.items.length,
        ids:   LootScreen._gridRect('hold').grid.items.map(i => i.id),
        keys:  LootScreen._gridRect('hold').grid.items.map(i => i.defKey),
      }));
      ok(after.hold === geom.holdBefore + 1,
         `the dragged crate landed in the hold (${geom.holdBefore} → ${after.hold})`);
      ok(geom.id && after.ids.includes(geom.id),
         `the crate that landed is THE crate that was dragged `
         + `(${geom.defKey} #${geom.id}; hold now holds ${after.keys.join(', ')})`);
      ok(after.shelf === geom.shelfBefore - 1,
         'the crate LEFT the shelf — an item is on the shelf OR in the hold, never both '
         + `(${geom.shelfBefore} → ${after.shelf})`);
    }

    // Closing the screen must PERSIST what was packed: those items have
    // physically left the shelf, so they have to be somewhere.
    const closed = await page.evaluate(() => {
      const z = LootScreen._zoneFor('close') || LootScreen._zoneFor('done');
      return z ? { x: z.x, y: z.y, w: z.w, h: z.h } : null;
    });
    if (closed) await clickCanvas(page, closed.x + closed.w / 2, closed.y + closed.h / 2);
    else await page.keyboard.press('Escape');
    await page.waitForTimeout(400);
    ok(!(await page.evaluate(() => LootScreen.isOpen())), 'the salvage screen closes');
    ok(await page.evaluate(() => (Base.packedHold()?.items?.length ?? 0) > 0),
       'what was packed is written back to the base — it cannot evaporate on reload');

    // ── The derelict builds the same kind of grid the drag just used ──
    const wreck = await page.evaluate(() => {
      const w = makeDerelict(1, 850, 120);
      return {
        power: w.reactor.totalPower,
        half: w.reactor.capacity - Math.floor(w.reactor.capacity / 2),
        rooms: w.rooms.length,
        hasO2: !!w.getSystem('oxygen'),
        weapons: w.weapons.length,
      };
    });
    // update90a: half the reactor works on a wreck now, not one emergency unit.
    ok(wreck.power === wreck.half, `a derelict keeps half its reactor (${wreck.half}), got ${wreck.power}`);
    ok(wreck.hasO2, 'and runs its life support — that is what makes boarding possible');
    ok(wreck.weapons === 0, 'a derelict has no guns left');

    ok(errors.length === 0, 'no page errors while salvaging'
       + (errors.length ? ':\n       ' + errors.join('\n       ') : ''));
  } finally {
    await page.close();
    await host.close();
  }
}

// ════════════════════════════════════════════════════════════
// SESSION 4 — the station shop (the only test that sees it: it is DOM)
// ════════════════════════════════════════════════════════════

async function session4(browser) {
  section('SESSION 4 — the station shop: stat chips and the reactor quote');
  const host = await serve();
  const page = await browser.newPage({ viewport: { width: 1280, height: 720 } });
  const errors = watchErrors(page, host.url);

  try {
    await page.goto(host.url, { waitUntil: 'load' });
    await waitForBoot(page);

    await page.evaluate(() => {
      Save.load(); Save.startRun();
      Save.updateRun({ scrap: 9999 });
      const ship = new Ship('frigate', true, 80, 120);
      ship._allocateDefaultPower();
      window.__shop = { ship, station: new Station(2, 7) };
      UI.openStation(window.__shop.station, ship);
    });
    ok(await page.evaluate(() => !!document.getElementById('station-screen')),
       'the station overlay is built');

    // ── WEAPONS tab: every stat chip carries its OWN pictogram ──
    await page.click('.station-tab[data-tab="weapons"]');
    await page.waitForTimeout(200);

    /* update112: every gun on the station is the ONE WEAPON CARD, drawn on
       a canvas (the same drawer as the base rack and the mounts) — so the
       chips are pixels now, not DOM spans. Check the cards are there and
       really painted, and that the chips they paint carry distinct icons. */
    const cards = await page.evaluate(() => {
      const cvs = [...document.querySelectorAll('#station-content canvas')];
      const painted = cvs.filter(cv => {
        const g = cv.getContext('2d');
        const d = g.getImageData(0, 0, cv.width, cv.height).data;
        let n = 0; for (let i = 3; i < d.length; i += 4 * 37) if (d[i] > 0) n++;
        return n > 50;
      }).length;
      const def = Object.values(WEAPON_DEFS)[0];
      const icons = new Set(weaponStatChips(def).map(c => c.icon));
      return { n: cvs.length, painted, icons: icons.size };
    });
    ok(cards.n > 0, `the shop shows its guns as weapon cards (found ${cards.n})`);
    ok(cards.painted === cards.n, `and every card is really painted (${cards.painted}/${cards.n})`);
    ok(cards.icons > 1,
       `chips must not all share ONE pictogram — a stat with no icon of its own is a stat `
       + `nobody can read (distinct icons: ${cards.icons})`);

    const bare = await page.evaluate(() =>
      [...document.querySelectorAll('#station-content span')]
        .filter(sp => /^(DMG|SHOTS|POWER|SHIELDS|CREW|STUN|FIRE|BREACH)$/i.test(sp.textContent.trim()))
        .filter(sp => !sp.parentElement || !sp.parentElement.querySelector('svg')).length);
    ok(bare === 0, `no stat label is left as a bare word without its icon (bare: ${bare})`);

    // ── MODULES tab: THE PRICE THE SHOP QUOTES MUST BE THE PRICE IT CHARGES ──
    await page.click('.station-tab[data-tab="modules"]');
    await page.waitForTimeout(200);

    // Click the reactor on the blueprint, level by level, and compare
    // the quoted number with the seller's own price every single time.
    // Until update34 the button drew a LINEAR price while the till used
    // an exponential one, so from level 6 up the button lit, the player
    // clicked, and got "Insufficient CC." holding the money.
    const quoteWalk = await page.evaluate(async () => {
      const { ship, station } = window.__shop;
      const bad = [];
      const clickReactor = () => {
        const d = [...document.querySelectorAll('#station-content div')]
          .find(x => x.children.length === 2 && /^RCT/.test(x.textContent));
        if (!d) return false;
        d.click();
        return true;
      };
      /* A HARD STEP CAP. With a broken quote the purchase is refused,
         the level never rises and this walk would spin forever — a test
         that hangs is a test nobody runs. Bail out and report instead. */
      let guard = ship.reactor.maxLevel + 2;
      while (ship.reactor.level < ship.reactor.maxLevel) {
        if (guard-- <= 0) { bad.push({ stuck: ship.reactor.level }); break; }
        if (!clickReactor()) return { error: 'could not find the reactor on the blueprint' };
        await new Promise(r => setTimeout(r, 30));
        const txt = document.querySelector('#station-content')?.textContent ?? '';
        const m = txt.match(/UPGRADE\s+(\d+)\s+CC/);
        if (!m) { if (/MAX LEVEL/.test(txt)) break; return { error: 'no quote and not maxed: ' + txt.slice(0, 120) }; }
        const quoted = Number(m[1]);
        const real   = station.reactorCost(ship);
        const lvl    = ship.reactor.level;
        if (quoted !== real) bad.push({ lvl, quoted, real });
        // Pay EXACTLY what the button asked for, then buy.
        Save.updateRun({ scrap: quoted });
        const r = station.buyReactorUpgrade(ship, Save.getRun());
        if (!r.ok) bad.push({ lvl, quoted, real, refused: r.message });
        clickReactor();                     // deselect
        await new Promise(r2 => setTimeout(r2, 20));
      }
      return { bad, level: ship.reactor.level, max: ship.reactor.maxLevel };
    });

    ok(!quoteWalk.error, 'the reactor is reachable on the shop blueprint'
       + (quoteWalk.error ? ' — ' + quoteWalk.error : ''));
    if (!quoteWalk.error) {
      ok(quoteWalk.bad.length === 0,
        'the quoted reactor price is ALWAYS enough to buy with'
        + (quoteWalk.bad.length ? ': ' + JSON.stringify(quoteWalk.bad) : ''));
      ok(quoteWalk.level === quoteWalk.max,
        `walking the quotes upgraded the reactor to the cap (${quoteWalk.level}/${quoteWalk.max})`);
    }

    // DEPART closes it again — leaving a port is a state change.
    await page.click('#station-close-btn');
    await page.waitForTimeout(200);
    ok(!(await page.evaluate(() =>
        document.getElementById('station-screen').classList.contains('visible'))),
       'DEPART closes the port overlay');

    ok(errors.length === 0, 'no page errors in the shop'
       + (errors.length ? ':\n       ' + errors.join('\n       ') : ''));
  } finally {
    await page.close();
    await host.close();
  }
}


// ════════════════════════════════════════════════════════════
// SESSION 5 — the shop reads karma (update61)
// ════════════════════════════════════════════════════════════

async function session5(browser) {
  section('SESSION 5 — the shop reads karma: surcharge banner and a shut dock');
  const host = await serve();
  const page = await browser.newPage({ viewport: { width: 1280, height: 720 } });
  const errors = watchErrors(page, host.url);

  try {
    await page.goto(host.url, { waitUntil: 'load' });
    await waitForBoot(page);

    /* Pick the seeds HERE, in the page, from the same rule the game
       uses — hard-coding "seed 7 refuses" would make this test a
       hostage of the seed arithmetic rather than a test of the shop. */
    const seeds = await page.evaluate(() => {
      let shut = null, open = null;
      for (let s = 0; s < 40 && (shut === null || open === null); s++) {
        if (Commander.portRefuses(s, 0)) { if (shut === null) shut = s; }
        else if (open === null) open = s;
      }
      return { shut, open };
    });
    ok(seeds.shut !== null && seeds.open !== null,
       `some ports shut a shunned commander out and some do not (${seeds.shut} / ${seeds.open})`);

    const openShop = (karma, seed) => page.evaluate(({ karma, seed }) => {
      Save.load(); Save.startRun();
      Save.updateRun({ scrap: 9999 });
      const cap = Commander.fromCrew({ id: 'bk', name: 'Rook', race: 'terra', skills: {} });
      cap.karma = karma;
      Commander.setActive(cap);
      const ship = new Ship('frigate', true, 80, 120);
      ship._allocateDefaultPower();
      ship.hull = Math.max(1, ship.hullMax - 20);
      const station = new Station(2, seed);
      station.stock.hullRepair = 40;
      window.__shop = { ship, station };
      UI.openStation(station, ship);
    }, { karma, seed });

    // ── AN ORDINARY COMMANDER: no banner at all ──────────────
    await openShop(50, seeds.open);
    await page.waitForTimeout(150);
    ok(await page.evaluate(() => !document.getElementById('station-karma-banner')),
       'an ordinary commander sees no banner — the shop is unchanged for him');
    const parPrice = await page.evaluate(() => window.__shop.station.hullRepairCost(5));

    // ── A DISTRUSTED ONE: the surcharge is said out loud ─────
    await openShop(30, seeds.open);
    await page.waitForTimeout(150);
    const warned = await page.evaluate(() => {
      const b = document.getElementById('station-karma-banner');
      return { text: b ? b.textContent : null,
               tabs: document.querySelectorAll('.station-tab').length,
               price: window.__shop.station.hullRepairCost(5) };
    });
    ok(warned.text && /DISTRUSTED/.test(warned.text),
       `the banner names him: "${warned.text}"`);
    ok(/10%/.test(warned.text), 'and gives the figure, not just an adjective');
    ok(warned.tabs > 0, 'the shop stays OPEN to him — a surcharge is not a refusal');
    ok(warned.price > parPrice,
       `and the yard really charges it (${warned.price} vs ${parPrice} CC for 5 HP)`);

    /* THE LABEL ON THE BUTTON IS THE PRICE THAT WILL BE TAKEN. The
       whole reason the shop asks the station for a quote instead of
       multiplying its own copy. */
    await page.click('.station-tab[data-tab="repair"]');
    await page.waitForTimeout(200);
    const label = await page.evaluate(() => {
      const s = window.__shop.station;
      const want = `+5 HP — ${s.hullRepairCost(5)} CC`;
      const seen = [...document.querySelectorAll('#station-content span')]
        .map(e => e.textContent.trim()).filter(t => /^\+5 HP/.test(t));
      return { want, seen };
    });
    ok(label.seen.includes(label.want),
       `the repair button quotes the karma price ("${label.want}" among ${JSON.stringify(label.seen)})`);

    // ── A SHUNNED ONE AT A DOCK THAT REFUSES HIM ─────────────
    await openShop(5, seeds.shut);
    await page.waitForTimeout(150);
    const shut = await page.evaluate(() => {
      const b = document.getElementById('station-karma-banner');
      return { text: b ? b.textContent : null,
               tabs: document.querySelectorAll('.station-tab').length,
               content: !!document.getElementById('station-content'),
               depart: !!document.getElementById('station-close-btn') };
    });
    ok(shut.text && /DOCK CLOSED/.test(shut.text),
       `the shut dock says so on screen: "${shut.text}"`);
    ok(/will not trade/.test(shut.text), 'and gives the reason, so it does not read as a bug');
    ok(shut.tabs === 0 && !shut.content,
       'and shows no shop at all rather than an empty one');
    ok(shut.depart, 'DEPART is still there — the player is never trapped in a closed port');

    // ── THE SAME COMMANDER AT A DOCK THAT STILL DEALS ────────
    await openShop(5, seeds.open);
    await page.waitForTimeout(150);
    const still = await page.evaluate(() => {
      const b = document.getElementById('station-karma-banner');
      return { text: b ? b.textContent : null,
               tabs: document.querySelectorAll('.station-tab').length };
    });
    ok(still.tabs > 0, 'a port that will deal with him is open for business');
    ok(still.text && /NOTORIOUS/.test(still.text) && !/DOCK CLOSED/.test(still.text),
       `but it charges him for the name: "${still.text}"`);

    await page.evaluate(() => Commander.setActive(null));
    await page.click('#station-close-btn');
    await page.waitForTimeout(200);

    ok(errors.length === 0, 'no page errors in the karma shop'
       + (errors.length ? ':\n       ' + errors.join('\n       ') : ''));
  } finally {
    await page.close();
    await host.close();
  }
}

// ════════════════════════════════════════════════════════════
// SESSION 6 — what lives in the duct has to fit in the duct
// ════════════════════════════════════════════════════════════

/*
 * This one can only be asked here. The sprites are drawn onto real
 * canvases at boot and the Node harness has a canvas that draws
 * nothing, so "is the cat taller than the duct" is a question with no
 * answer outside a browser — and update73 got it wrong by eye, picking
 * a one-tile duct that the spider did not fit in standing still.
 *
 * So: render every beast frame at the size the game actually draws it,
 * count the non-transparent pixels, and compare the tallest against
 * VENT_H. Redraw the cat and this fails on the day it is redrawn, not
 * on the day somebody notices it clipping.
 */
async function session6(browser) {
  section('SESSION 6 — the duct is tall enough for what will live in it');
  const host = await serve();
  const page = await browser.newPage({ viewport: { width: 1280, height: 720 } });
  const errors = watchErrors(page, host.url);

  try {
    await page.goto(host.url, { waitUntil: 'load' });
    await waitForBoot(page);

    const out = await page.evaluate(() => {
      /* The size CrewMember.draw uses — read from the source of truth
         rather than typed in here, so the two cannot drift. */
      const SCREEN = 32;
      const ink = (frame) => {
        const c = document.createElement('canvas');
        c.width = SCREEN; c.height = SCREEN;
        const g = c.getContext('2d');
        g.drawImage(frame, 0, 0, SCREEN, SCREEN);
        const d = g.getImageData(0, 0, SCREEN, SCREEN).data;
        let top = 1e9, bot = -1;
        for (let y = 0; y < SCREEN; y++) {
          for (let x = 0; x < SCREEN; x++) {
            if (d[(y * SCREEN + x) * 4 + 3] > 12) {
              if (y < top) top = y;
              if (y > bot) bot = y;
            }
          }
        }
        return bot < 0 ? 0 : bot - top + 1;
      };
      const tallest = (mk) => {
        let h = 0;
        ['idle', 'walk', 'fight'].forEach(mode => {
          (mk(mode).frames || []).forEach(f => { h = Math.max(h, ink(f)); });
        });
        return h;
      };
      return {
        vent:   HULL_GRID.VENT_H,
        tile:   HULL_GRID.TILE,
        rat:    tallest(m => Animation.ratAnim(m, '#b3a189')),
        cat:    tallest(m => Animation.catAnim(m, '#3a3a42')),
        spider: tallest(m => Animation.spiderAnim(m, '#9fff7a')),
      };
    });

    ok(out.vent > 0, `the duct has a height (${out.vent}px)`);
    ['rat', 'cat', 'spider'].forEach(k => {
      ok(out[k] > 0, `${k}: the sprite draws something (${out[k]}px of ink)`);
      ok(out[k] <= out.vent,
         `${k} fits in the duct (${out[k]}px into ${out.vent}px)`);
    });

    /* AND IT IS NOT WASTEFULLY TALL EITHER. A duct three tiles high
       would pass the test above and eat the compartment; the point is
       that it is the SMALLEST whole number of tiles that works. */
    const need = Math.max(out.rat, out.cat, out.spider);
    ok(out.vent - need < out.tile,
       `and is the smallest duct that does (${out.vent}px for ${need}px of cat)`);

    /* WHICH WAY THE RAT FACES (update86a). Pest.draw mirrors the frame
       for a rat heading LEFT, so the unmirrored art has to face RIGHT —
       it faced left, and every rat walked tail first. Real pixels: the
       head and snout are the heavy end, the tail a thin line, so the ink
       on the head side of the frame's middle outweighs the other. */
    const facing = await page.evaluate(() => {
      const SCREEN = 32;
      const sides = (frame) => {
        const c = document.createElement('canvas');
        c.width = SCREEN; c.height = SCREEN;
        const g = c.getContext('2d');
        g.drawImage(frame, 0, 0, SCREEN, SCREEN);
        const d = g.getImageData(0, 0, SCREEN, SCREEN).data;
        let left = 0, right = 0, lo = SCREEN, hi = -1;
        for (let y = 0; y < SCREEN; y++) for (let x = 0; x < SCREEN; x++) {
          if (d[(y * SCREEN + x) * 4 + 3] > 12) { lo = Math.min(lo, x); hi = Math.max(hi, x); }
        }
        const mid = (lo + hi) / 2;
        for (let y = 0; y < SCREEN; y++) for (let x = 0; x < SCREEN; x++) {
          const a = d[(y * SCREEN + x) * 4 + 3];
          if (x < mid) left += a; else right += a;
        }
        return { left, right };
      };
      return ['idle', 'walk'].map(m => sides(Animation.ratAnim(m, '#b3a189').frames[0]));
    });
    ok(facing.every(f => f.right > f.left),
       `the rat's art faces right, head first (${facing.map(f => f.right + ' vs ' + f.left).join('; ')})`);

    /* REGOLITH GREYS THE PAINT (update137). The hull PNGs carry no state,
       so in the regolith palette they are drawn grey — real pixels, off
       the real screen, since the node suite has no images to read. */
    const reg = await page.evaluate(() => {
      const name = ['hull_frigate', 'hull_scout', 'hull_hauler'].find(n => Assets.source(n) === 'file');
      if (!name) return { none: true };
      const img = Assets.get(name), w = img.naturalWidth || img.width, h = img.naturalHeight || img.height;
      const spread = (paint) => {
        const c = document.createElement('canvas'); c.width = w; c.height = h;
        const g = c.getContext('2d'); Palette.install(g); paint(g);
        const d = g.getImageData(0, 0, w, h).data;
        let worst = 0;
        for (let i = 0; i < d.length; i += 4) if (d[i + 3] > 200) worst = Math.max(worst, Math.max(d[i], d[i + 1], d[i + 2]) - Math.min(d[i], d[i + 1], d[i + 2]));
        return worst;
      };
      const was = Palette.mode();
      Palette.set('classic'); const classic = spread(g => g.drawImage(img, 0, 0));
      Palette.set('regolith'); const regolith = spread(g => g.drawImage(img, 0, 0));
      Palette.set(was);
      return { name, classic, regolith };
    });
    ok(reg.none || (reg.classic > 40 && reg.regolith <= 9),
       `in regolith the hull art is grey (${reg.name}: colour spread ${reg.classic} → ${reg.regolith})`);

    ok(errors.length === 0, 'no page errors while measuring'
       + (errors.length ? ':\n       ' + errors.join('\n       ') : ''));
  } finally {
    await page.close();
    await host.close();
  }
}

async function session7(browser) {
  section('SESSION 7 — the prison (update163): the block is drawn from its rooms\' own pictures, the inmates are bare');
  const host = await serve();
  const page = await browser.newPage({ viewport: { width: 1280, height: 720 } });
  const errors = watchErrors(page, host.url);
  try {
    await page.goto(host.url, { waitUntil: 'load' });
    await waitForBoot(page);
    await page.waitForTimeout(600);
    const out = await page.evaluate(() => {
      const kinds = ['security', 'warden', 'intake', 'decon', 'mess', 'cell'];
      const files = kinds.filter(k => Assets.source('room_' + k) === 'file' && moduleArt(k, 'terra')?.width === 100);
      Save.startRun?.(); Save.updateRun?.({ scrap: 200 });
      const sh = new Ship('scout', true, 80, 120);
      PrisonView.open(Prison.make(1, 4242), sh, { hidden: () => 2 });
      const c = document.createElement('canvas'); c.width = 1280; c.height = 720;
      const g = c.getContext('2d');
      PrisonView.draw(g);
      const d = g.getImageData(700, 50, 580, 250).data;
      let orange = 0;
      /* update246: the layered suit is the colour SHADED (multiplied into the grey's lightness), not one flat value */
      for (let i = 0; i < d.length; i += 4) if (d[i] > 120 && d[i] - d[i + 1] > 55 && d[i + 1] - d[i + 2] > 25 && d[i + 2] < 90) orange++;
      const inkOf = (bare) => {
        const a = CrewArt.anim('idle', { name: 'Vic Hale', race: 'terra', bare, suitColor: () => '#e07020' }), f = a.frames[0];
        const q = document.createElement('canvas'); q.width = f.width; q.height = f.height; const qg = q.getContext('2d'); qg.drawImage(f, 0, 0);
        const px = qg.getImageData(0, 0, f.width, f.height).data; let ink = 0;
        for (let i = 3; i < px.length; i += 4) if (px[i] > 12) ink++;
        return ink;
      };
      const zones = PrisonView._zonesFor('depart').length + PrisonView._zonesFor('warden').length;
      PrisonView.close();
      return { files: files.length, orange, tankBare: inkOf(true), tankSuit: inkOf(false), zones };
    });
    ok(out.files === 6, `every room of the block has its picture, at the module's size (${out.files}/6)`);
    ok(out.orange > 40, `inmates in orange in the window (${out.orange} px)`);
    ok(out.tankSuit > out.tankBare && out.tankBare > 100, `an inmate is the man without the helmet's glass and the bottles (${out.tankSuit} px of ink → ${out.tankBare})`);
    ok(out.zones === 2, 'DEPART and the warden\'s deal are live');
    ok(errors.length === 0, 'no page errors at the prison' + (errors.length ? ':\n       ' + errors.join('\n       ') : ''));
  } finally {
    await page.close();
    await host.close();
  }
}

async function session8(browser) {
  section('SESSION 8 — the sector map is a chart of the moon (update167): the ground has craters, the fog is dark, the sectors differ');
  const host = await serve();
  const page = await browser.newPage({ viewport: { width: 1280, height: 720 } });
  const errors = watchErrors(page, host.url);
  try {
    await page.goto(host.url, { waitUntil: 'load' });
    await waitForBoot(page);
    const out = await page.evaluate(() => {
      Save.startRun?.();
      const o = SectorMap.origin(1280, 720), P = SectorMap.panelOf(o);
      const spread = (m) => {
        const at = (n) => ({ x: n.x + o.x - P.x, y: n.y + o.y - P.y });
        const g = MapTerrain.ground(m, P, at).getContext('2d'), d = g.getImageData(0, 0, P.w, P.h).data;
        let lo = 255, hi = 0, sum = [0, 0, 0], n = 0;
        for (let i = 0; i < d.length; i += 4 * 97) { const v = (d[i] + d[i + 1] + d[i + 2]) / 3; lo = Math.min(lo, v); hi = Math.max(hi, v); sum[0] += d[i]; sum[1] += d[i + 1]; sum[2] += d[i + 2]; n++; }
        return { range: hi - lo, warm: (sum[0] - sum[2]) / n };
      };
      const a = spread(new SectorMap(1, 8003, null, 3, true)), b = spread(new SectorMap(2, 8003, null, 3, true));
      const m = new SectorMap(1, 8003, null, 3, true);
      const at = (n) => ({ x: n.x + o.x - P.x, y: n.y + o.y - P.y });
      const fog = MapTerrain.fog(m, P, at, m.visibilityMap()).getContext('2d').getImageData(P.w - 40, P.h / 2, 1, 1).data[3];
      return { a, b, fog };
    });
    ok(out.a.range > 60, `the ground has light and shadow — craters, maria (${out.a.range.toFixed(0)} levels)`);
    ok(out.b.warm > out.a.warm + 3, `sector 2 is warmer than sector 1 (${out.a.warm.toFixed(1)} → ${out.b.warm.toFixed(1)})`);
    ok(out.fog > 150, `the far side of an unsurveyed sector is under the fog (alpha ${out.fog})`);
    ok(errors.length === 0, 'no page errors on the chart' + (errors.length ? ':\n       ' + errors.join('\n       ') : ''));
  } finally {
    await page.close();
    await host.close();
  }
}

async function session9(browser) {
  section('SESSION 9 — the port is a hull (update168): its rooms\' pictures load, every kind draws');
  const host = await serve();
  const page = await browser.newPage({ viewport: { width: 1280, height: 720 } });
  const errors = watchErrors(page, host.url);
  try {
    await page.goto(host.url, { waitUntil: 'load' });
    await waitForBoot(page);
    await page.waitForTimeout(500);
    const out = await page.evaluate(() => {
      const kinds = ['bar', 'storage', 'broker', 'customs', 'gate', 'dock', 'lab', 'quarters'];
      const files = kinds.filter(k => Assets.source('room_' + k) === 'file' && moduleArt(k, 'pegasus')?.width === 100).length;
      Save.startRun?.();
      const c = document.createElement('canvas'); c.width = 1280; c.height = 720; const g = c.getContext('2d');
      const drawn = ['general', 'military', 'science', 'outpost'].filter(type => {
        const st = new Station(1, 77, { type }); PortView.open(st, new Ship('scout', true, 80, 120)); PortView.draw(g); PortView.close();
        return StationScene._state().key.startsWith('station_' + type);
      }).length;
      return { files, drawn };
    });
    ok(out.files === 8, `every room of a port has its picture (${out.files}/8)`);
    ok(out.drawn === 4, `every kind of port draws its own hull (${out.drawn}/4)`);
    ok(errors.length === 0, 'no page errors at the port' + (errors.length ? ':\n       ' + errors.join('\n       ') : ''));
  } finally {
    await page.close();
    await host.close();
  }
}

// ════════════════════════════════════════════════════════════

/** Launch Chromium.
 *  Normally playwright finds its own download. Some environments ship a
 *  browser at a fixed path instead (and CI images pin a different build
 *  number than the npm package expects) — MOONWARS_CHROMIUM, or a couple
 *  of well-known locations, are tried before giving up. */
async function launchBrowser() {
  try {
    return await chromium.launch();
  } catch (e) {
    const candidates = [process.env.MOONWARS_CHROMIUM, '/opt/pw-browsers/chromium']
      .filter(Boolean).filter(p2 => { try { return fs.existsSync(p2); } catch (_) { return false; } });
    for (const executablePath of candidates) {
      try { return await chromium.launch({ executablePath }); } catch (_) { /* next */ }
    }
    console.log('could not start Chromium — skipping the browser test.');
    console.log('  ' + String(e && e.message || e).split('\n')[0]);
    console.log('  install the browser with:  npx playwright install chromium');
    return null;
  }
}

(async () => {
  const browser = await launchBrowser();
  if (!browser) process.exit(0);
  try {
    await session1(browser);
    await session2(browser);
    await session3(browser);
    await session4(browser);
    await session5(browser);
    await session6(browser);
    await session7(browser);
    await session8(browser);
    await session9(browser);
  } catch (e) {
    failed++;
    console.error('\nFATAL: ' + (e && e.stack ? e.stack : e));
  } finally {
    await browser.close();
  }
  console.log('');
  console.log(`${passed} passed, ${failed} failed`);
  process.exit(failed ? 1 : 0);
})();
