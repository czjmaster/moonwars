/* ============================================================
   MOON WARS — ship.js
   Ship class: layout, rooms, systems, hull, crew roster,
   weapons rack, elevator integration, damage resolution.
   Both player and enemy ships use this class.
   ============================================================ */

'use strict';

/* ══ GRAVITY (update91) ══════════════════════════════════════
 *
 * The spec (GPT, agreed by the player 01.10): artificial gravity is a
 * SECOND FUNCTION OF THE ENGINES, not a module. It is ON while the
 * engines have a working level and are running on power, and OFF
 * otherwise — no partial gravity. Nothing about it is stored: it is
 * read off the engines every time (`Ship.gravityActive`), so a save,
 * a repair or a power click can never leave it out of step.
 *
 * Zero-G costs and pays:
 *   · crew walk at 70%, repair at 80%, patch hull breaches at 70%
 *   · a casualty carried in gravity goes at 50% of a man's walk, in
 *     zero-G at 120% — the player's figure, faster than walking
 *   · a fire spreads at 20% of its rate; it still burns, eats air,
 *     hurts and is put out as before (zero-G is not vacuum)
 *   · the hold: every 20 s a 15% roll damages ONE item; and with ANY
 *     unpatched hull breach aboard (the player's call: the hold has no
 *     compartment of its own), every 10 s a 25% roll loses ONE item —
 *     one unit off a stack. Installed guns and modules are not cargo.
 * Every number is here and nowhere else. */
const GRAVITY_CONFIG = {
  crewMovementMultiplier:   0.70,
  normalRepairMultiplier:   0.80,
  breachRepairMultiplier:   0.70,
  fireSpreadMultiplier:     0.20,
  normalWoundedCarrySpeed:  0.50,
  zeroGWoundedCarrySpeed:   1.20,   // jj, 01.10: "50% / 120%" (the spec had 0.80)
  cargoDamageCheckInterval: 20,
  cargoDamageProbability:   0.15,
  cargoLossCheckInterval:   10,
  cargoLossProbability:     0.25,
};

/* ══ REACTOR HEAT (update92) ═════════════════════════════════
 *
 * The spec (GPT) with the player's gentler numbers, 01.10:
 *   · LOAD = what the MODULES draw / what the reactor gives now. The lifts'
 *     spare units do not count (the player's call: otherwise the default
 *     split sat at 100% from the first second);
 *   · HEAT 0–100 rises only from 80% load — to full in ~10 min at 80–89%,
 *     ~6 min at 90–99%, ~3 min at 100% — and falls only with 30% or more of
 *     the reactor FREE: slowly from 30%, faster from 40%, fast from 50%.
 *     Between (70–80% load) it holds. A scrammed reactor cools fast;
 *   · the same rules in a fight and out of one: the player cools down
 *     between fights by taking power off, and that is the point;
 *   · from 70% heat, once a second, a small chance of a fire in the reactor
 *     room; at 100%: OVERHEAT — one reactor level shot out (crew repair it
 *     like any module), heat back to 90%, and a 50% fire roll;
 *   · a bigger reactor runs a little cooler (thermal multiplier).
 * Rates are in heat-percent per second. Every number is here. */
const REACTOR_HEAT_CONFIG = {
  heatBands: [                          // highest load first
    { load: 1.00, perSec: 100 / 180 },  // 100%     → full in ~3 min
    { load: 0.90, perSec: 100 / 360 },  // 90–99%   → ~6 min
    { load: 0.80, perSec: 100 / 600 },  // 80–89%   → ~10 min
  ],
  coolBands: [                          // most free first
    { free: 0.50, perSec: 100 / 150 },  // 50%+ free → empty in ~2.5 min
    { free: 0.40, perSec: 100 / 300 },  // 40–49%    → ~5 min
    { free: 0.30, perSec: 100 / 600 },  // 30–39%    → ~10 min
  ],
  scramCoolPerSec: 100 / 150,           // offline, or nothing left to give
  /* A HAND AT THE REACTOR CONSOLE (update105, jj: "zmniejsza nagrzanie
     reaktora trochę"). The man at the console (slot 0) keeps the core a
     little cooler: −0.1 heat/s, 1.3 °C/s. A LITTLE — the 80% band heats
     at 0.17/s and 100% at 0.56/s, so he slows a hot core, holds a warm
     one, and cools a 70–79% one slowly; he never replaces taking power
     off. Both sides. */
  consoleCoolPerSec: 0.1,
  thermal: [                            // by reactor level: heat gain multiplier
    { upTo: 8,  mult: 1.00 },
    { upTo: 12, mult: 0.95 },
    { upTo: 16, mult: 0.90 },
    { upTo: Infinity, mult: 0.85 },
  ],
  hazardInterval: 1,                    // seconds between fire rolls
  fireChance: [                         // per roll, by heat; highest first
    { heat: 90, p: 0.020 },
    { heat: 80, p: 0.005 },
    { heat: 70, p: 0.001 },
  ],
  warnHeat:     70,
  criticalHeat: 90,
  overheatDamage: 1,
  overheatResetHeat: 90,
  overheatFireChance: 0.5,
  /* THE ENEMY KEEPS ITS CORE COOL (update93). From `shedAt` heat it
     takes one unit off a module every `stepSeconds` until the load is at
     `targetLoad` (30% free — the cooling line); from `restoreAt` it
     gives them back, one per step, last taken first. Never the reactor,
     life support below 1, the helm, the carbonite bay, the last gun or
     the shields below one bar. */
  ai: { shedAt: 75, restoreAt: 30, targetLoad: 0.70, stepSeconds: 1 },
  /* HOW HOT, IN DEGREES (update97). The simulation keeps heat 0–100 —
     every threshold above is in those units — and the SCREEN says it in
     degrees: jj, "żeby to brzmiało jak grzanie reaktora na statku, a nie
     laptopa". 100 is 1300 °C. One number, read by `heatCelsius`. */
  maxCelsius: 1300,
  /* WHAT IS IN THE HOLD (update93c). The player: an unstable core in the
     cargo heats the reactor too; a cooler crate in the hold cancels it,
     and a cooler with nothing to cancel cools the reactor. Anywhere in
     the hold, one for one: each core adds `corePerSec`, each cooler takes
     `coolerPerSec` off — the 80% band's rate, ~10 min to full per core. */
  cargo: { corePerSec: 100 / 600, coolerPerSec: 100 / 600 },
};

// ── Door ──────────────────────────────────────────────────

/** Seconds for a door panel to travel from shut to fully open. */
const DOOR_CYCLE = 1.0;

class Door {
  /**
   * Door between two adjacent rooms — or an AIRLOCK to space (roomB = null).
   * Doors are BINARY: 'open' or 'closed'. Green = open, red = closed.
   *        'closed' (player-locked shut).
   * Open airlocks vent the room's oxygen to space (FTL fire-fighting tactic).
   */
  constructor(roomA, roomB, x, y, isAirlock = false) {
    this.roomA  = roomA;
    this.roomB  = roomB;        // null = space
    this.x      = x;
    this.y      = y;
    this.isAirlock = isAirlock;
    // Doors are strictly BINARY: open or closed. Interior doors start
    // open (air flows), airlocks start closed. Click toggles.
    this.mode   = isAirlock ? 'closed' : 'open';
    // A door is no longer instant. `openness` runs 0..1 over DOOR_CYCLE
    // seconds and `open` means FULLY open — nobody squeezes through a
    // door that is still moving.
    this.openness = isAirlock ? 0 : 1;
    this.open   = !isAirlock;
    // Auto-passage: an INTERIOR door a crew member walks up to slides
    // open briefly even if the player locked it 'closed', then closes
    // again. Airlocks NEVER auto-open (they must be breached).
    this._tempT = 0;   // seconds left holding open for a passer-by
    this.breached = false;   // legacy: airlock smashed open (see hack())

    /* ── HACKING ──────────────────────────────────────────────
       A door belongs to the hull it is bolted into: it slides open for
       the crew who live there and stays shut to everyone else. An
       intruder has to work the lock, and the first door of a fight is
       the airlock they came through.

       Per SIDE, and per fight: once a boarding party has cracked a
       particular door it stays cracked for them until the battle ends
       (Ship.markCombatStart resets them), so they are not re-hacking
       the same corridor on the way back. */
    this.hacked = { player: false, enemy: false };
    this.hackT  = 0;
  }

  /** Seconds of work to crack one lock. */
  static get HACK_TIME() { return 2.5; }

  /**
   * An intruder from `side` works this lock. Returns true once the door
   * will actually let them through.
   */
  hackBy(side, dt = 0) {
    if (this.hacked[side]) {
      // Already theirs — from here on it behaves like their own door.
      this._tempT = Math.max(this._tempT, 0.6);
      return this.open;
    }
    this.hackT += dt;
    if (this.hackT >= Door.HACK_TIME) {
      this.hacked[side] = true;
      this.hackT = 0;
      this._tempT = Math.max(this._tempT, 1.2);
      Audio.sfx.doorMove?.();
    }
    return false;
  }

  /** Force a door open to a side without the work — the boarding party
   *  cutting the outer hatch has already spent its time doing that. */
  hackOpen(side, hold = 2.2) {
    this.hacked[side] = true;
    this.hackT = 0;
    this._tempT = Math.max(this._tempT, hold);
  }

  isHackedBy(side) { return !!this.hacked[side]; }
  get hackProgress() { return Utils.clamp(this.hackT / Door.HACK_TIME, 0, 1); }

  /** New battle: every lock is a stranger's lock again. */
  resetHacks() { this.hacked = { player: false, enemy: false }; this.hackT = 0; }

  /** Player click: open ↔ closed. The panel then takes a second to cycle. */
  toggle() {
    this.mode = this.mode === 'open' ? 'closed' : 'open';
    this._tempT = 0;
    Audio.sfx.uiClick();
    Audio.sfx.doorMove?.();
  }

  /** Where the panel should end up, 1 = open. */
  get _target() {
    if (this.breached) return 1;
    // A hacked airlock cycles like any other door instead of staying a
    // hole in the hull. The old boarding code smashed it permanently,
    // which vented that room for the rest of the run with no way to
    // ever seal it again.
    if (this.isAirlock) return (this._tempT > 0 || this.mode === 'open') ? 1 : 0;
    return (this._tempT > 0 || this.mode === 'open') ? 1 : 0;
  }

  /** A crew member is standing at this door wanting through.
   *  INTERIOR doors slide open (with a short delay so it reads as a
   *  door cycling). Returns true once it's actually open to pass. */
  requestPassage(dt) {
    if (this.isAirlock) return this.open;   // airlocks don't auto-open
    // Ask for it, then WAIT. The door needs its full second; returning
    // true early let crew walk through a half-open panel.
    this._tempT = Math.max(this._tempT, 0.6);
    return this.open;
  }

  update(dt, crew) {
    if (this._tempT > 0) this._tempT -= dt;

    // Slide toward the target at a fixed rate — one full second end to
    // end, whichever way it is going. A breached airlock is simply gone,
    // so it snaps.
    const target = this._target;
    if (this.breached) {
      this.openness = 1;
    } else if (this.openness !== target) {
      const step = dt / DOOR_CYCLE;
      this.openness = target > this.openness
        ? Math.min(target, this.openness + step)
        : Math.max(target, this.openness - step);
    }
    // FULLY open, not "on its way".
    this.open = this.openness >= 1;

    if (!this.isAirlock) return;

    // Venting particles for open airlocks (throttled)
    if (this.open) {
      this._ventT = (this._ventT ?? 0) + dt;
      if (this._ventT > 0.15) {
        this._ventT = 0;
        Particles.emit({
          x: this.x, y: this.y + Utils.randFloat(-12, 12),
          vx: (this.x < 640 ? -1 : 1) * Utils.randFloat(40, 90),
          vy: Utils.randFloat(-15, 15), ay: 0,
          color: '#aaccee', size: 2, sizeEnd: 0,
          life: 0.4, alpha: 0.7, alphaEnd: 0,
        });
      }
    }
  }

  /* THE DOOR IS 6 x 34 PIXELS, and that is the only place those two
     numbers live (update69). The drawing below reads them, and so does
     `hits()` — the hit test used to be a 32px circle around the same
     point, five times wider than the leaf you can see, reaching well
     into the module behind it. Clicks meant for the room, and for the
     menu that opens over it, were eaten by a hatch that was nowhere
     near the cursor. The player's words: "drzwi mają siatkę klikania
     za bardzo oddaloną od samych drzwi i nachodzi mocno na moduł". */
  static get W() { return 6; }
  static get H() { return 34; }
  /** Generous enough to hit with a mouse, tight enough to stay ON the
   *  door: the leaf plus 5px of wall either side, and nothing more. */
  static get GRAB() { return 5; }

  hits(mx, my) {
    return Math.abs(mx - this.x) <= Door.W / 2 + Door.GRAB &&
           Math.abs(my - this.y) <= Door.H / 2;
  }

  /** How wide a door is DRAWN (update120) — its click box stays W. */
  static get DRAWN_W() { return 2; }   // thinner again in update128 (jj)

  /** The frame round a door (update128): a header the lamp sits on and a
   *  sill, wider than the leaf, the way a ship's doors are framed. */
  static get FRAME() { return { w: 6, header: 3, sill: 2 }; }
  /** What of each leaf still shows when the door is open (update128). */
  static get POCKET() { return 3; }

  /** The steel of every door (update120): grey, a little blue. */
  static get STEEL() {
    return { base: [126, 134, 148], light: [190, 198, 210], dark: [54, 60, 72] };
  }

  /**
   * update120 (jj: "zdejmij zielone podświetlenie drzwi… drzwi albo
   * przejście bez żadnych zaznaczeń"): a door is drawn in the ship's own
   * trim. OPEN is an opening — a header and a sill. SHUT is two leaves
   * meeting in the middle. Over every door a lamp (update122): green
   * open, orange shut or moving, red damaged. The airlock keeps its
   * warning colours — it opens onto vacuum — on leaves in the ship's trim.
   * @param {object} [trim] the hull's YARD_TRIM (Ship#trim)
   */
  draw(ctx, trim = null, yard = null) {
    const w = Door.W, h = Door.H;
    this._onDrawnWall = Door.onDrawnWall(yard);
    this._onWall = this._onDrawnWall || !!Door.art(yard, this.isAirlock);   // update238/242: the lamp in the drawn head
    const T = trim ?? (typeof YARD_TRIM !== 'undefined' ? YARD_TRIM._you : null);
    /* ONE STEEL FOR EVERY DOOR (jj, 12.10: "drzwi dalej mało widoczne —
       standardowy kolor, szarawy metaliczny, ale żeby pasował"). In the
       yard's trim a door was the wall it sits in and disappeared; plain
       grey steel stands out against any yard and still belongs on it. */
    const S = Door.STEEL;
    const leafCol = trimRgba(S.base, 1);
    const edgeCol = trimRgba(S.light, 1);
    const darkCol = trimRgba(S.dark, 1);

    // Somebody is working this lock — show how far they have got.
    if (this.hackT > 0) {
      const p = this.hackProgress;
      ctx.fillStyle = 'rgba(6,9,16,0.85)';
      ctx.fillRect(this.x - 9, this.y - h / 2 - 9, 18, 4);
      ctx.fillStyle = '#ffd700';
      ctx.fillRect(this.x - 9, this.y - h / 2 - 9, 18 * p, 4);
      ctx.strokeStyle = 'rgba(255,215,0,0.6)'; ctx.lineWidth = 1;
      ctx.strokeRect(this.x - 9.5, this.y - h / 2 - 9.5, 19, 5);
    }

    const o    = Utils.clamp(this.openness ?? (this.open ? 1 : 0), 0, 1);
    const half = h / 2;
    const leaf = half * (1 - o);
    const moving = o > 0 && o < 1;


    if (this.isAirlock && !this.breached && this._drawArtDoor(ctx, yard, o)) return;   // update239: the drawn door, hazard stripes and all (update242: every ship)
    if (this.isAirlock) {
      if (o > 0) {                        // vacuum showing through the gap
        ctx.fillStyle = `rgba(255,60,60,${(0.30 * o).toFixed(2)})`;
        ctx.fillRect(this.x - w/2 - 3, this.y - half - 3, w + 6, h + 6);
      }
      if (leaf > 0.5) {                   // the hatch leaves, in the ship's trim
        ctx.fillStyle = this.breached ? '#4a2020' : leafCol;
        ctx.fillRect(this.x - w/2, this.y - half, w, leaf);
        ctx.fillRect(this.x - w/2, this.y + half - leaf, w, leaf);
        // the hazard band across the middle of a shut hatch
        if (o <= 0) {
          ctx.fillStyle = '#e8b020';
          ctx.fillRect(this.x - w/2, this.y - 3, w, 2);
          ctx.fillStyle = '#1a1a1a';
          ctx.fillRect(this.x - w/2, this.y - 1, w, 2);
        }
      }
      if (o >= 1) {                       // fully open: hot edges
        ctx.fillStyle = '#ff4455';
        ctx.fillRect(this.x - w/2, this.y - half, w, 6);
        ctx.fillRect(this.x - w/2, this.y + half - 6, w, 6);
      }
      // the lamp over it — the same as every door's (update122)
      this._drawLamp(ctx);
      return;
    }

    /* ── A SHIP'S DOOR (update128, jj: "drzwi do poprawki, słabo dalej
     * wyglądają — zrób cieńsze, przycisk połączony z drzwiami, próg na
     * dole i na górze jak na statkach; jak są otwarte, to powinny
     * wyglądać na otwarte, ale również że tam są") ───────────────────
     * A 2 px leaf in a 6 px frame: a HEADER over it that the lamp sits
     * on (the lamp is the door's own, not a light floating above), a
     * SILL under it. Open, the leaves are in the frame — their ends show
     * under the header and over the sill, and a rail runs between them,
     * so the doorway reads as open AND as a door. Shut: one steel leaf,
     * a seam where the halves meet, a lit edge. */
    const dw = Door.DRAWN_W, dx = this.x - dw / 2;
    const F = Door.FRAME, fx = this.x - F.w / 2;
    const top = this.y - half, bot = this.y + half;
    /* ON A DRAWN WALL (update238, jj 17.11: „pomarańczowe linie między modułami raczej niepotrzebne"): the wall has its
       own plain doorway and the plate for the lamp — an open door is only its lamp; a shut or moving one its leaves,
       no frame, no opening painted over the wall. (Until the drawn doors come.) */
    if (this._drawArtDoor(ctx, yard, o)) return;          // update242 (jj 17.11: „wstaw wszędzie nowe drzwi do wszystkich statków")
    if (Door.onDrawnWall(yard)) {
      if (leaf > 0.5) {
        ctx.fillStyle = leafCol;
        ctx.fillRect(dx - 1, top, dw + 2, leaf); ctx.fillRect(dx - 1, bot - leaf, dw + 2, leaf);
        ctx.fillStyle = darkCol;
        ctx.fillRect(dx - 1, top + leaf - 1, dw + 2, 1); ctx.fillRect(dx - 1, bot - leaf, dw + 2, 1);
      }
      this._drawLamp(ctx);
      return;
    }
    // the opening
    ctx.fillStyle = T ? trimRgba(T.dark.map(v => Math.round(v * 0.5)), 0.95) : 'rgba(6,9,14,0.95)';
    ctx.fillRect(dx, top, dw, h);
    // the rail the leaves run in
    ctx.fillStyle = darkCol;
    ctx.fillRect(dx + dw - 1, top, 1, h);
    // the leaves: retracted to their pockets (open) or meeting (shut)
    const stub = Door.POCKET;
    const lf = Math.max(stub, leaf);
    ctx.fillStyle = leafCol;
    ctx.fillRect(dx, top, dw, lf);
    ctx.fillRect(dx, bot - lf, dw, lf);
    ctx.fillStyle = edgeCol;                     // the lit edge of each leaf
    ctx.fillRect(dx, top, 1, lf);
    ctx.fillRect(dx, bot - lf, 1, lf);
    ctx.fillStyle = darkCol;                     // the leading edges
    ctx.fillRect(dx, top + lf - 1, dw, 1);
    ctx.fillRect(dx, bot - lf, dw, 1);
    // header (the lamp sits on it) and sill
    ctx.fillStyle = edgeCol;
    ctx.fillRect(fx, top - F.header, F.w, F.header);
    ctx.fillStyle = darkCol;
    ctx.fillRect(fx, top - 1, F.w, 1);
    ctx.fillStyle = leafCol;
    ctx.fillRect(fx, bot, F.w, F.sill);
    ctx.fillStyle = darkCol;
    ctx.fillRect(fx, bot + F.sill - 1, F.w, 1);
    this._drawLamp(ctx);
  }

  /* (update226 drew the doors from GPT v15 — a wide frame that lay over the modules; jj 10.11: „lipa". update227:
     the code's slim door again; the v16 modules keep a slim post each side for it.) */

  /* ── THE LAMP OVER THE DOOR (update122) ─────────────────────
     jj: "popraw lampkę nad drzwiami, zrób troszkę większą, i drzwi
     otwarte zielona lampka, drzwi zamknięte pomarańczowa, drzwi
     uszkodzone czerwona". Every door has one now, open ones included.
     Damaged is a lock somebody has cracked (a boarding party's work,
     it lets them through for the rest of the fight) or a hatch smashed
     in; a lock being worked blinks red. A door still sliding is not
     open yet: orange. */
  static get LAMP() {
    return { w: 4, h: 3, lift: 8,
             open: '#1aff8c', shut: '#ff9a20', damaged: '#ff2d44', rim: 'rgba(8,10,16,0.95)' };
  }

  /** Cracked or smashed — it no longer keeps anybody out. */
  get damaged() { return !!(this.breached || this.hacked?.player || this.hacked?.enemy); }

  /** 'open', 'shut' or 'damaged' — what the lamp over it says. */
  lampState() {
    if (this.damaged) return 'damaged';
    const o = Utils.clamp(this.openness ?? (this.open ? 1 : 0), 0, 1);
    if (o < 1) return 'shut';
    /* An airlock standing open is a hole to space, venting the room:
       red, not green. */
    return this.isAirlock ? 'damaged' : 'open';
  }

  /** Where the lamp is: centred over the door, `lift` above its top. */
  /* THE DRAWN DOOR (update239, jj 17.11: „drzwi oddzielają cały przedział… bez ramki… próg na dole, w który chowa się
     część drzwi; góra zabudowana do belki sufitu, miejsce na światełko obudowane"): GPT's Terra door, the whole height
     of the compartment at the seam — the HEAD from the ceiling down to the door (the lamp in its socket), the two LEAVES
     sliding apart (the upper one up under the head, the lower one down into the sill), the THRESHOLD on the floor.
     `door_{head,sill,leaf_top,leaf_bot}_<yard>` in art/ (tools/terra_v19/cut_doors.py); any missing — the code's. */
  static art(yard, airlock = false) {
    if (typeof Assets === 'undefined' || !Assets.source) return null;
    /* the airlock its own, heavier (update240) — or the inner door's when it has none. EVERY SHIP (update242, jj 17.11:
       „wstaw wszędzie nowe drzwi do wszystkich statków"): a yard with no doors of its own — and a hull with no yard —
       has Terra's. */
    const yards = [...new Set([yard, Door.ART_YARD].filter(Boolean))];
    for (const [pre, yd] of yards.flatMap(yd => (airlock ? ['door_air_', 'door_'] : ['door_']).map(p => [p, yd]))) {
      const n = ['head', 'sill', 'leaf_top', 'leaf_bot'].map(p => `${pre}${p}_${yd}`);
      if (!n.every(k => Assets.source(k) === 'file')) continue;
      const [head, sill, top, bot] = n.map(k => Assets.get(k));
      return { head, sill, top, bot, G: pre === 'door_air_' ? Door.ART_AIR : Door.ART };
    }
    return null;
  }
  /* STUB (jj 11:50: „niech nie chowają się całe, końcówki z żółto-czarnymi paskami dalej wystają z dołu i góry"):
     open, each leaf still shows its striped end under the head and over the threshold */
  static get ART() { return { W: 8, HEAD: 16, SILL: 4, LEAF_W: 6, STUB: 3 }; }   // game units: the head and the sill 8 wide, the leaves 6
  /** Whose drawn doors a yard without its own takes (update242). */
  static get ART_YARD() { return 'terra'; }
  static get ART_AIR() { return { W: 10, HEAD: 16, SILL: 5, LEAF_W: 8, STUB: 3 }; }   // the airlock (update240): heavier
  _drawArtDoor(ctx, yard, o) {
    const A = Door.art(yard, this.isAirlock);
    if (!A) return false;
    const G = A.G, half = Door.H / 2, top = this.y - half, x = this.x;
    const leaf = Math.max(G.STUB, half * (1 - o)), sm = ctx.imageSmoothingEnabled;
    this._drawSlot(ctx, G, top);
    ctx.imageSmoothingEnabled = true;
    {                           // the upper leaf shows the part of it still out under the head: its bottom
      const t = A.top, k = leaf / half;
      ctx.drawImage(t, 0, t.height * (1 - k), t.width, t.height * k, x - G.LEAF_W / 2, top, G.LEAF_W, leaf);
    }
    this._drawLowerArt(ctx, A, o);
    ctx.drawImage(A.head, x - G.W / 2, top - G.HEAD, G.W, G.HEAD);
    ctx.imageSmoothingEnabled = sm;
    this._drawLamp(ctx);
    return true;
  }
  /* THE DOOR'S SLOT (update241, jj 17.11 13:34: „brakuje małej kreski, co odznacza na ścianie i podłodze miejsce
     modułów, jak kratka — z otwartymi drzwiami to wygląda jak jeden długi moduł; na zarysach drzwi odznaczenie, może
     być małe"): the leaves' rails down the wall from the head to the threshold, a shade of recess between them. */
  _drawSlot(ctx, G, top) {
    const x = this.x, w = G.LEAF_W, y0 = top, y1 = this.y + Door.H / 2 - G.SILL;
    /* on a ship with no drawn wall (update242) the recess is deep: the old post or bulkhead at the seam behind it */
    ctx.fillStyle = this._onDrawnWall ? 'rgba(0,0,0,0.22)' : 'rgba(17,16,14,0.9)';
    ctx.fillRect(x - w / 2, y0, w, y1 - y0);                                                // the recess
    for (const s of [-1, 1]) {                                                              // the two rails
      const rx = x + s * (w / 2 + 0.35);
      ctx.fillStyle = '#15130f'; ctx.fillRect(rx - 0.45, y0, 0.9, y1 - y0);
      ctx.fillStyle = 'rgba(255,236,200,0.22)'; ctx.fillRect(rx + s * 0.45 - (s > 0 ? 0 : 0.35), y0, 0.35, y1 - y0);
    }
  }
  /* THE LOWER LEAF AND THE THRESHOLD (update240, jj: „na dole też powinna wystawać część drzwi, te pasy żółto-czarne,
     a załogant przechodzi za dolnym progiem, nie przed"): the lower leaf's striped end stays out OVER the threshold, and
     both are drawn again after the crew (Ship.draw → drawLowerOver), so a man in the doorway walks behind them. */
  _drawLowerArt(ctx, A, o) {
    const G = A.G, half = Door.H / 2, bot = this.y + half, x = this.x;
    const lo = Math.max(G.SILL + G.STUB, half * (1 - o)), b = A.bot, k = lo / half;
    ctx.drawImage(b, 0, 0, b.width, b.height * k, x - G.LEAF_W / 2, bot - lo, G.LEAF_W, lo);
    ctx.drawImage(A.sill, x - G.W / 2, bot - G.SILL, G.W, G.SILL);
  }
  /** After the crew (update240): the lower leaf and the threshold of a drawn door over whoever stands in it. */
  drawLowerOver(ctx, yard) {
    if (this.isAirlock && this.breached) return false;
    const A = Door.art(yard, this.isAirlock);
    if (!A) return false;
    const sm = ctx.imageSmoothingEnabled; ctx.imageSmoothingEnabled = true;
    this._drawLowerArt(ctx, A, Utils.clamp(this.openness ?? (this.open ? 1 : 0), 0, 1));
    ctx.imageSmoothingEnabled = sm;
    return true;
  }

  /** Is this yard's module a drawn wall with its own doorway (update238)? */
  static onDrawnWall(yard) { return !!(yard && typeof moduleWall === 'function' && moduleWall(yard, 'default')); }

  lampRect() {
    const L = Door.LAMP;
    /* ON THE HEADER (update128): the lamp is the door's button, so it
       sits on the door's frame, not `lift` pixels up in the wall. An
       airlock has no header and keeps its lamp where it was. */
    const y = (this.isAirlock && !this._onWall) ? this.y - Door.H / 2 - L.lift
                                                : this.y - Door.H / 2 - Door.FRAME.header - L.h;
    return { x: Math.round(this.x - L.w / 2), y: Math.round(y), w: L.w, h: L.h };
  }

  _drawLamp(ctx) {
    const L = Door.LAMP, r = this.lampRect();
    let st = this.lampState();
    // somebody working the lock: red and orange by turns
    if (st !== 'damaged' && this.hackT > 0 && Math.floor(this.hackT * 4) % 2 === 0) st = 'damaged';
    ctx.fillStyle = L.rim;
    ctx.fillRect(r.x - 1, r.y - 1, r.w + 2, r.h + 2);
    ctx.fillStyle = L[st];
    ctx.fillRect(r.x, r.y, r.w, r.h);
    ctx.fillStyle = 'rgba(255,255,255,0.5)';
    ctx.fillRect(r.x, r.y, 1, 1);
  }
}

// ── Room ──────────────────────────────────────────────────

class Room {
  constructor(cfg) {
    this.id      = cfg.id;
    this.type    = cfg.type ?? 'empty';   // system type or 'empty'
    this.x       = cfg.x;
    this.y       = cfg.y;
    this.w       = cfg.w ?? 96;
    this.h       = cfg.h ?? 80;
    this.floor   = cfg.floor ?? 0;        // which floor (0=bottom)
    this.cx      = this.x + this.w / 2;
    this.cy      = this.y + this.h / 2;
    this.isVacuum = false;

    // Adjacent room ids (set after all rooms created)
    this.adjacent = cfg.adjacent ?? [];
    /* WHAT AN EMPTY ROOM IS (update163): a cell, the mess, the warden's
       office — a room with no system, painted like a module of its kind. */
    this.art = cfg.art ?? null;

    // Linked system instance (set by Ship)
    this.system  = null;
  }

  contains(wx, wy) {
    return Utils.pointInRect(wx, wy, this.x, this.y, this.w, this.h);
  }

  /* ── THE CEILING DUCT (update73) ──────────────────────────
   *
   * Every module carries its own duct along the top row of its tiles:
   * oxygen pipes and power runs, wide enough for vermin and the cat and
   * nobody else. It is part of the room rather than a band of its own
   * so that a one-deck hull has one too, and so that the duct NETWORK
   * needs no geometry — it is `adjacent`, which this class has carried
   * since the beginning.
   *
   * Derived, never stored: the module owns its size and the duct is a
   * reading of it. A stored `ventY` would be the same number twice and
   * would go stale the first time a hull moved.
   *
   * The mechanics come later (fire through the grille, air leaving the
   * duct first, rats walking it). What lands now is the SPACE and the
   * fact that the player can see it.
   */
  /* UNDER THE DECK SINCE update120 (jj: "obrócimy i zrobimy, że
     wentylacja jest na podłodze, a podłoga metalowa z kratkami"). The
     duct is the BOTTOM row of the module now — the crew walk on its lid,
     a metal deck with grates in it — and the room the crew stand in is
     the top. Everything that lives in the duct reads these two getters,
     so the rats, the spiders, the cat and the fire went down with it. */
  get ventY()  { return HULL_GRID.DUCT_BELOW ? this.y + this.h - HULL_GRID.VENT_H : this.y; }
  get ventH()  { return HULL_GRID.VENT_H; }
  /** Where the room the crew stand in begins (its top). */
  get floorTop() { return HULL_GRID.DUCT_BELOW ? this.y : this.y + HULL_GRID.VENT_H; }
  /** Height of the part anybody walks in. */
  get floorH()   { return this.h - HULL_GRID.VENT_H; }

  /** Repair the system in this room */
  repair(amount, crew) {
    if (this.system) this.system.repair(amount, crew);
  }
}

/** Heat (0–100, the simulation's unit) as the °C the screen shows. */
function heatCelsius(heat) {
  return Math.round(Utils.clamp(heat ?? 0, 0, 100) / 100 * REACTOR_HEAT_CONFIG.maxCelsius);
}

// ── Ship layouts ──────────────────────────────────────────

/* ============================================================
   THE HULL GRID (update41)

   Every hull in this game is now built from ONE module size. Before
   this there were three — 80x72, 96x80 and 96x60 — with three
   different deck pitches, because each layout hard-coded its own pixel
   coordinates and they drifted apart one hull at a time. That made a
   shared set of art impossible: a floor tile drawn for the scout was
   the wrong size on the frigate and the wrong shape on the station.

   Layouts are declared in GRID COORDINATES now — (col, row) — and the
   pixels are derived. Adding a hull is listing squares; changing the
   module size is changing one number here and every hull, every door,
   every lift stop and every crew station follows.

       MODULE_W x MODULE_H     one compartment
       DECK_PITCH              MODULE_H + DECK_GAP, floor to floor
       SHAFT_W                 a lift trunk sits in the gap BETWEEN two
                               columns, never inside a room
       ENGINE_W / PROW_W       exterior tiles, one per deck, hung off
                               the stern and the bow (see engineSlots
                               and prowSlots). Stations have neither.

   The art kit is cut to these numbers. Do not nudge them for one hull.

   ── EVERYTHING IS A WHOLE NUMBER OF TILES (update73) ──────

   One more rule on top of update41's: every length here is a multiple
   of TILE. That is what lets the art kit be a handful of 10x10 squares
   — a corner, an edge, a floor, a duct — instead of one bespoke
   drawing per hull. Section 247 of the test suite asserts it, so a
   number nudged by a pixel for one screen fails the suite rather than
   quietly making one tile in one hull the wrong size.

   ── THE MODULE LIES DOWN (update73) ───────────────────────

   80x72 was very nearly a square (1.11:1), which read as a cell rather
   than a compartment — and the duct below would only have made it look
   taller. 100x60 is 1.67:1: a room you walk along.

   Measured against the 1280 canvas before it was chosen, because the
   camera never zooms (`Camera.setZoom` is called from nowhere) and so
   both hulls are always drawn 1:1. Two Hapis — the widest pair in the
   game at four columns — come to 1080px and leave 200px between them.
   At 120 wide the same pair left twelve pixels and Hapi would have had
   to lose a column; at 100 no hull has to change at all.

   ── THE DUCT IS THE TOP ROW OF EVERY MODULE (update73) ────

   VENT_H is the ceiling duct: oxygen pipes and power runs, the width
   of one tile, inside the module rather than in a band of its own.
   Three things follow, and they are why it sits here and not in the
   gap between decks:

     · it exists on a ONE-DECK hull, which a band between decks cannot;
     · it needs no geometry of its own — it has the module's;
     · the vent NETWORK is `Room.adjacent`, which this engine has had
       since the beginning. Vermin walk the duct from room to adjacent
       room and no new pathfinding is written.

   DECK_GAP is therefore 0: the duct is the gap now, and a visible one.
   ============================================================ */

const TILE = 10;

const HULL_GRID = {
  TILE,
  MODULE_W: 10 * TILE,   // 100
  MODULE_H:  7 * TILE,   // 70 — INCLUDING the duct along its ceiling
  /* TWO TILES, AND IT WAS MEASURED (update73a). One tile was chosen
     by eye in update73 and the eye was wrong: the sprites were
     rendered in a browser at the size the game draws them and their
     pixels counted, walking, idling and fighting.
         rat     10px  — fits a one-tile duct exactly
         spider  11px  — one over, even standing still
         cat     13px walking, 16 sitting
     The cat is the tall one because it SITS UP, which was a
     deliberate update45 decision so its silhouette could never be
     mistaken for the rat's. That decision does not fit in ten pixels.
     The INTERIOR is unchanged at 50: the module grew, the deck did
     not, so nothing about the crew moves. */
  VENT_H:    2 * TILE,   // the duct: two rows of tiles of the module
  DUCT_BELOW: true,      // …its BOTTOM two, under the deck (update120)
  DECK_GAP:  0,          // the duct IS the gap between decks now
  SHAFT_W:   3 * TILE,   // 30
  MARGIN:    1 * TILE,   // hull plate overhang past the outermost room
  /* The exterior tiles came down a tile each with the wider module
     (update73). Two hulls at four columns now come to 1040px of the
     1280 the canvas has, and the twenty pixels this gives back per
     ship are twenty pixels of open space between them — which is
     where the shells fly. They are dressing; the compartments are
     the ship. */
  ENGINE_W:  4 * TILE,   // stern tile, one per deck
  PROW_W:    3 * TILE,   // bow tile, one per deck
  /* LOWER, WITH A THIN FLOOR (update120, jj: "kafelki podłogi za
     wysoko… podłoga duża, słabo wygląda"). The walk line came down from
     0.65 of the interior to 0.8, which puts a man's boots (FEET below
     the line, measured off the sprite) five pixels above the bottom of
     the room: the floor is a thin deck now, not a band of tiles. */
  /* 0.9 with the duct under the deck (update120): a man's boots
     (FEET below the line) are on the lid of the duct — the deck. */
  WALK_FRAC: 0.9,        // the crew walk line, as a fraction of the INTERIOR
  FEET:      5,          // a standing man's boots, below that line
};
HULL_GRID.DECK_PITCH = HULL_GRID.MODULE_H + HULL_GRID.DECK_GAP;   // 60

/**
 * How far below a room's TOP the crew's feet stand.
 *
 * ONE DEFINITION, and it has to be (update73). This number lived in
 * two places before: `buildHull` multiplied WALK_FRAC by the whole
 * module to place its lift stops, and `floorWalkY` had a bare 0.65
 * written out beside it. They agreed only because the module had no
 * duct — the moment the ceiling stopped being walkable they would have
 * disagreed by seven pixels, which is a lift that stops just above the
 * floor its passengers are standing on.
 *
 * Measured from the INTERIOR, not the module: the duct is ceiling, and
 * nobody's feet are ever in it.
 */
function walkOffset() {
  return (HULL_GRID.DUCT_BELOW ? 0 : HULL_GRID.VENT_H)
       + (HULL_GRID.MODULE_H - HULL_GRID.VENT_H) * HULL_GRID.WALK_FRAC;
}

/** World X of a column, counting the shafts that sit before it. */
function gridColX(originX, col, shaftAfter) {
  const before = shaftAfter.filter(c => c < col).length;
  return originX + col * HULL_GRID.MODULE_W + before * HULL_GRID.SHAFT_W;
}

/** World Y of a deck. Row 0 is the BOTTOM deck, as `floor` always was. */
function gridRowY(originY, row, decks) {
  return originY + (decks - 1 - row) * HULL_GRID.DECK_PITCH;
}

/** World X of the CENTRE of the shaft that follows column `afterCol`. */
function gridShaftX(originX, afterCol, shaftAfter) {
  const before = shaftAfter.filter(c => c < afterCol).length;
  return originX + (afterCol + 1) * HULL_GRID.MODULE_W
       + before * HULL_GRID.SHAFT_W + HULL_GRID.SHAFT_W / 2;
}

/* ── THE HULL AS A PICTURE (update116) ──────────────────────
 *
 * A hull can now be a drawn PNG (art/hull_<layout>.png, and
 * art/hull_<layout>_enemy.png for the same hull flown at you — the
 * stern is on the other side, so it is a different picture, not a
 * mirrored one: the modules are not symmetric). When the file is not
 * there the plate is drawn in code exactly as before, so a hull can
 * get its picture one at a time and the game boots with none.
 *
 * THE PICTURE IS CUT TO THIS GEOMETRY AND NOTHING ELSE. The generator
 * (tools/gen_hull_art.js) asks this function where everything goes and
 * the game asks it where to put the picture — one definition, so the
 * art and the deck cannot drift apart. A picture whose size does not
 * match its hull (the layout changed, the art did not) is NOT drawn:
 * the code plate comes back, and section 303 fails, which is the
 * signal to run the generator again.
 *
 *   box      where the picture goes: the room bounds grown by
 *            PAD_STERN at the stern (the nozzles' overhang), PAD_BOW at
 *            the bow (the nose) and PAD_Y above and below (a nacelle
 *            each side, update121).
 *   plate    the rectangles whose union is the plate — the modules
 *            grown by MARGIN, plus the lift trunks — the same shape
 *            `_hullPlatePath` fills.
 *   engines  two nacelles at the stern end: one on top of the top
 *            deck, one under the bottom deck (`side` 'top'/'bottom'),
 *            each bolted three pixels into the plate (update121).
 *   prows    one nose per run of touching decks that reach the BOW.
 *
 * A station has neither engines nor a bow (it does not go anywhere).
 */
const HULL_ART = {
  /* ENGINES ON TOP AND UNDERNEATH (update121, jj: "silniki przesunąć na
     górę i dół kadłuba, nie z tyłu — zaoszczędzimy miejsce między
     statkami"). The stern needs only the nozzles' overhang now; the bow
     keeps room for its nose. The box is therefore NOT symmetric: */
  /* update128 (jj: "silniki większe, te są za płaskie; nie muszą wychodzić
     poza statek — jak wychodzą, tracimy trochę miejsca między statkami"):
     the nozzles end flush with the stern now, only the bell's lip shows. */
  PAD_STERN: HULL_GRID.TILE,                    // 10 — the bell's lip past the plate
  PAD_BOW:   HULL_GRID.PROW_W + HULL_GRID.TILE, // 40 — the nose
  PAD_Y:     3 * HULL_GRID.TILE,                // 30 — a nacelle above, one below
  /** A nacelle: how long it runs along the hull, how tall, how far its
   *  nozzle sticks out past the stern plate. */
  NACELLE: { len: 6 * HULL_GRID.TILE, h: 22, overhang: 0 },   // bigger, flush (update128)
  /** The sprite name for a hull, flown by you or at you. */
  name(layoutKey, isPlayer = true) {
    return 'hull_' + layoutKey + (isPlayer ? '' : '_enemy');
  },
  /** The roof over that hull's compartments (update118). */
  roofName(layoutKey, isPlayer = true) {
    return HULL_ART.name(layoutKey, isPlayer) + '_roof';
  },
  /** Does this picture fit this geometry? A shaped picture (update175)
   *  is `artScale` pixels per grid unit, a painted one exactly one. */
  fits(img, g) {
    if (!img || !g) return false;
    const s = g.artScale ?? 1;
    return img.width === Math.round(g.box.w * s) && img.height === Math.round(g.box.h * s);
  },
  /** The geometry of a hull whose picture is a SHAPED one (update175),
   *  or `g` unchanged when it has none — or when its file is not on
   *  disk, because the game must boot with no image files at all. */
  withPicture(g, layoutKey, isPlayer = true) {
    const spec = HULL_SHAPED[layoutKey];
    if (!g || !spec || typeof Assets === 'undefined' || !Assets.source) return g;
    if (Assets.source(HULL_ART.name(layoutKey, isPlayer)) !== 'file') return g;
    return shapedHullGeometry(g, spec, isPlayer);
  },
};

/* ── THE SHAPED HULLS (update175) ─────────────────────────
 *
 * jj, 29.10: "statki muszą wyglądać bardzo dobrze", Pegasus first. A
 * whole ship drawn by GPT over the hull's skeleton (v2: one free field
 * round her — the stern, the bow, ridges above and below the decks)
 * and fitted to the game's grid by mock/warp2.py: the MODULES and the
 * lift shaft sit exactly where the game has them, everything else is
 * the shape. Two layers, like every hull since update118:
 *
 *   hull_<key>.png        the cut-away — the windows over the
 *                         compartments transparent, the game's rooms
 *                         show through them
 *   hull_<key>_roof.png   the closed armour over the same outline
 *
 * and `_enemy` for both, mirrored: their bow points left.
 *
 * THE SHAPE IS ONLY A PICTURE. A shell hits a module and a click
 * picks a module — exactly as before; the shape is what she looks
 * like. Doors, rats and the crew are the game's, never the picture's.
 *
 * SCALE: 1.5 picture pixels per grid unit, which is what one grid unit
 * is on the Full HD screen (LOGICAL 1920 over DESIGN 1280, renderer.js),
 * so the picture is drawn at its own pixels and sharp (jj, 29.10, ×1,5).
 *
 * Per hull: the picture's size in pixels and where the corner of her
 * ROOM BOX (top-left of the modules) sits inside it, flown by you
 * (stern left). Written by tools/gen_shaped_hull_art.py with the
 * pictures; the enemy's is that mirrored. */
const HULL_SHAPED_SCALE = 1.5;
const HULL_SHAPED = {
  // filled by tools/gen_shaped_hull_art.py together with the art/ files
  enemy_hathor: { w: 920, h: 302, ox: 138, oy: 44,
    flames: [[46, 95.9, -1, 0, 38, 61], [861, 78.5, 1, 0, 27, 15], [47, 204.2, -1, 0, 39, 65], [731, 186.2, 1, 0, 45, 18]],
    top: [85, 302, 302, 302, 302, 64, 46, 41, 35, 34, 34, 24, 21, 21, 21, 18, 15, 11, 9, 6, 5, 4, 4, 4, 2, 2, 2, 2, 2, 2, 2, 5, 5, 7, 9, 9, 9, 9, 10, 14, 14, 10, 10, 10, 9, 10, 10, 11, 11, 11, 11, 11, 11, 11, 11, 9, 3, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 6, 9, 8, 8, 12, 21, 21, 21, 17, 15, 15, 15, 15, 15, 15, 2, 2, 2, 2, 2, 2, 2, 2, 2, 5, 9, 14, 19, 21, 22, 23, 23, 26, 28, 30, 33, 36, 39, 42, 44, 49, 57, 59, 61, 68, 84, 84, 93, 86, 86, 90, 95, 103],
    bottom: [100, 0, 0, 0, 0, 229, 246, 254, 256, 264, 264, 265, 268, 270, 281, 282, 282, 283, 282, 280, 284, 289, 291, 291, 292, 294, 299, 299, 299, 299, 299, 296, 296, 296, 296, 296, 295, 295, 295, 295, 291, 291, 288, 285, 285, 285, 285, 285, 285, 285, 287, 287, 287, 287, 288, 288, 290, 290, 291, 293, 293, 293, 293, 294, 290, 292, 299, 299, 299, 300, 300, 300, 300, 298, 293, 290, 285, 281, 284, 284, 283, 280, 273, 266, 225, 219, 213, 212, 211, 210, 210, 210, 208, 203, 198, 199, 199, 194, 190, 182, 175, 174, 177, 180, 180, 179, 178, 178, 172, 172, 172, 172, 167, 166, 160, 160, 149, 145, 139, 134, 128, 122, 117] },
  enemy_frigate: { w: 824, h: 362, ox: 156, oy: 82,
    flames: [[475, 28.9, 1, 0, 20, 20], [719, 97.3, 1, 0, 26, 24], [50, 130.1, -1, 0, 41, 60], [56, 238.8, -1, 0, 47, 65], [718, 279.1, 1, 0, 27, 24], [474, 337.2, 1, 0, 20, 20]],
    top: [120, 118, 362, 96, 96, 362, 95, 95, 79, 73, 73, 73, 64, 58, 52, 48, 47, 47, 45, 43, 42, 40, 40, 39, 36, 36, 36, 36, 36, 36, 36, 36, 36, 33, 33, 4, 4, 2, 2, 2, 2, 2, 2, 2, 2, 2, 4, 9, 8, 8, 10, 14, 13, 13, 19, 19, 17, 17, 17, 17, 16, 16, 16, 45, 41, 43, 44, 46, 47, 48, 50, 51, 52, 53, 54, 54, 55, 56, 56, 57, 55, 55, 55, 55, 55, 56, 58, 59, 62, 64, 67, 68, 71, 73, 77, 83, 117, 111, 114, 119, 126, 131, 137, 143, 151, 156, 163, 166, 173, 179],
    bottom: [251, 255, 0, 275, 275, 0, 277, 277, 292, 297, 297, 297, 305, 310, 316, 321, 322, 322, 325, 327, 329, 329, 329, 332, 334, 335, 335, 336, 336, 336, 335, 335, 337, 338, 338, 359, 360, 361, 361, 361, 361, 361, 361, 361, 361, 360, 356, 357, 357, 357, 356, 353, 353, 353, 348, 350, 350, 350, 350, 350, 352, 352, 351, 321, 325, 325, 324, 324, 323, 322, 321, 320, 320, 319, 318, 318, 317, 317, 317, 317, 320, 320, 320, 320, 320, 319, 317, 316, 314, 312, 309, 308, 306, 304, 299, 290, 267, 266, 262, 256, 250, 245, 239, 233, 226, 219, 212, 205, 202, 196] },
  isis: { w: 890, h: 447, ox: 135, oy: 62,
    flames: [[692, 37.7, 1, 0, 31, 16], [859, 87.2, 1, 0, 29, 23], [43, 118.3, -1, 0, 40, 68], [777, 144.9, 1, 0, 23, 17], [42, 217.8, -1, 0, 39, 70], [785, 289.8, 1, 0, 25, 18], [49, 322, -1, 0, 46, 76], [857, 343.8, 1, 0, 31, 23], [692, 407.2, 1, 0, 30, 17], [316, 426.9, 1, 0, 28, 19]],
    top: [447, 447, 447, 447, 447, 77, 67, 61, 61, 54, 54, 53, 51, 47, 44, 39, 36, 33, 32, 29, 28, 25, 20, 18, 18, 18, 20, 20, 20, 22, 2, 1, 1, 1, 1, 1, 1, 2, 2, 2, 3, 4, 7, 11, 18, 17, 17, 17, 17, 17, 18, 18, 18, 18, 20, 20, 20, 22, 25, 24, 25, 25, 25, 26, 27, 25, 25, 19, 16, 16, 16, 16, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 16, 16, 20, 20, 20, 22, 23, 23, 40, 53, 44, 41, 36, 36, 36, 36, 36, 36, 36, 36, 43, 46, 48, 48, 52, 53, 55, 55, 63, 65, 68, 447, 447, 447, 447],
    bottom: [0, 0, 0, 0, 0, 284, 370, 380, 381, 390, 392, 394, 395, 399, 404, 407, 414, 422, 424, 426, 427, 428, 435, 436, 437, 437, 438, 439, 440, 440, 441, 442, 444, 447, 447, 447, 447, 447, 447, 447, 447, 443, 421, 418, 419, 424, 426, 430, 430, 430, 430, 430, 431, 432, 432, 432, 431, 426, 424, 424, 424, 424, 422, 419, 418, 421, 421, 422, 427, 428, 431, 432, 432, 432, 432, 432, 432, 432, 432, 432, 432, 432, 432, 431, 431, 428, 425, 425, 425, 423, 422, 422, 403, 400, 399, 397, 399, 400, 400, 400, 400, 400, 400, 399, 393, 388, 387, 385, 384, 383, 379, 378, 375, 370, 367, 0, 0, 0, 0] },
  enemy_gunship: { w: 900, h: 351, ox: 142, oy: 70,
    pads: [[186, 305, 298, 349], [370, 305, 481, 349], [547, 305, 657, 349]],
    flames: [[16, 108.6, -1, 0, 42, 65.1], [16, 243.7, -1, 0, 42, 65.1]],
    top: [351, 351, 85, 66, 63, 57, 49, 49, 49, 47, 42, 38, 38, 38, 34, 24, 23, 20, 20, 18, 16, 16, 16, 16, 16, 16, 16, 16, 17, 17, 17, 17, 18, 21, 21, 21, 16, 14, 11, 10, 8, 3, 2, 2, 2, 2, 3, 3, 3, 2, 3, 2, 2, 2, 2, 2, 7, 9, 15, 15, 15, 21, 21, 21, 21, 21, 21, 17, 15, 15, 16, 10, 8, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 2, 2, 2, 2, 3, 6, 9, 12, 14, 17, 21, 21, 19, 17, 18, 17, 20, 20, 20, 20, 20, 21, 27, 27, 28, 36, 48, 49, 49, 49, 59, 63, 63, 77, 87, 91],
    bottom: [0, 0, 272, 288, 291, 300, 303, 311, 311, 314, 315, 319, 324, 331, 331, 335, 336, 336, 336, 335, 332, 335, 340, 344, 344, 349, 350, 350, 350, 350, 348, 347, 347, 347, 347, 350, 350, 350, 350, 345, 344, 342, 332, 332, 332, 332, 331, 342, 344, 344, 350, 350, 350, 350, 347, 347, 347, 347, 347, 350, 350, 350, 350, 347, 344, 344, 331, 332, 331, 331, 332, 344, 344, 345, 350, 350, 350, 350, 348, 347, 347, 347, 347, 350, 350, 350, 350, 344, 279, 272, 219, 211, 207, 208, 208, 208, 201, 195, 189, 189, 189, 189, 189, 189, 189, 191, 193, 193, 193, 189, 187, 187, 186, 178, 167, 154, 153, 141, 127, 124] },
  enemy_raider: { w: 750, h: 380, ox: 142, oy: 94,
    pads: [[160, 333, 283, 379], [332, 333, 456, 379], [522, 333, 643, 379]],
    flames: [[665, 62.3, 1, 0, 26, 15], [13, 131.5, -1, 0, 42, 65.1], [745, 167.5, 1, 0, 26, 15], [13, 260.8, -1, 0, 42, 65.1], [669, 298.3, 1, 0, 26, 15]],
    top: [380, 380, 101, 44, 42, 43, 43, 45, 2, 2, 4, 6, 8, 10, 13, 14, 17, 18, 21, 23, 25, 26, 27, 28, 30, 31, 32, 34, 35, 37, 37, 41, 42, 45, 49, 53, 53, 53, 51, 51, 48, 46, 46, 40, 40, 34, 32, 32, 32, 33, 33, 33, 33, 33, 33, 33, 33, 34, 34, 34, 34, 34, 34, 33, 33, 33, 33, 37, 42, 46, 46, 46, 47, 46, 45, 44, 45, 46, 50, 53, 53, 54, 54, 54, 55, 48, 47, 47, 51, 82, 88, 95, 101, 113, 124, 124, 131, 137, 144, 152],
    bottom: [0, 0, 295, 344, 343, 342, 342, 342, 342, 373, 372, 371, 370, 368, 368, 366, 364, 362, 360, 373, 374, 373, 378, 378, 378, 377, 377, 377, 377, 377, 375, 375, 378, 378, 378, 378, 373, 374, 360, 359, 359, 358, 359, 373, 373, 378, 378, 378, 378, 377, 375, 375, 375, 375, 375, 375, 378, 378, 378, 378, 373, 374, 371, 359, 359, 359, 359, 359, 359, 374, 374, 378, 378, 378, 378, 377, 377, 377, 377, 377, 377, 378, 378, 378, 378, 374, 339, 327, 319, 306, 258, 252, 237, 228, 212, 204, 202, 197, 190, 181] },
  osiris: { w: 900, h: 474, ox: 142, oy: 70,
    pads: [[183, 422, 324, 473], [400, 427, 525, 473], [608, 424, 742, 473]],
    flames: [[884, 95.8, 1, 0, 26, 21.6], [13, 105.6, -1, 0, 42, 65.1], [13, 228.9, -1, 0, 42, 65.1], [13, 345.7, -1, 0, 42, 65.1], [884, 353.9, 1, 0, 26, 20.7]],
    top: [474, 474, 75, 64, 62, 58, 42, 41, 36, 32, 29, 27, 27, 27, 20, 17, 15, 19, 15, 14, 15, 16, 15, 14, 14, 19, 19, 19, 19, 14, 14, 14, 14, 12, 13, 13, 13, 13, 7, 4, 3, 2, 2, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 4, 8, 10, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 9, 3, 2, 2, 3, 3, 3, 3, 3, 3, 3, 3, 3, 2, 3, 3, 4, 8, 13, 13, 14, 13, 14, 18, 24, 24, 23, 23, 23, 23, 18, 18, 15, 15, 15, 25, 26, 32, 39, 46, 51, 64, 64, 64, 68, 71, 77, 474, 474],
    bottom: [0, 0, 377, 390, 391, 405, 409, 412, 420, 426, 430, 436, 436, 436, 439, 449, 449, 449, 449, 448, 448, 465, 467, 467, 473, 473, 473, 473, 472, 473, 473, 473, 473, 473, 473, 473, 473, 473, 473, 473, 472, 473, 473, 471, 467, 465, 443, 443, 442, 443, 451, 464, 466, 472, 473, 473, 473, 473, 473, 473, 473, 473, 473, 473, 472, 473, 473, 473, 473, 473, 466, 465, 451, 442, 441, 443, 443, 442, 443, 466, 467, 473, 473, 473, 473, 473, 473, 472, 473, 473, 473, 473, 473, 473, 473, 473, 473, 473, 473, 468, 467, 465, 442, 440, 440, 440, 437, 438, 434, 430, 426, 417, 400, 397, 395, 395, 378, 371, 0, 0] },
  boss_station: { w: 728, h: 712, ox: 192, oy: 106,
    flames: [],
    top: [702, 686, 681, 670, 661, 649, 640, 633, 625, 557, 425, 336, 274, 99, 92, 86, 44, 44, 3, 4, 16, 16, 53, 51, 50, 41, 40, 38, 32, 32, 32, 32, 32, 32, 38, 41, 41, 40, 39, 40, 49, 51, 50, 33, 31, 33, 37, 40, 44, 44, 37, 33, 32, 32, 43, 51, 49, 41, 39, 39, 40, 44, 38, 32, 32, 32, 32, 32, 32, 35, 40, 41, 50, 51, 52, 16, 16, 38, 3, 38, 44, 63, 90, 97, 272, 334, 424, 508, 623, 632, 639, 648, 661, 668, 680, 686, 700, 712],
    bottom: [711, 711, 711, 711, 711, 711, 711, 711, 711, 711, 711, 711, 711, 711, 711, 711, 710, 710, 710, 710, 710, 711, 711, 711, 711, 711, 711, 710, 710, 710, 710, 710, 710, 710, 710, 710, 710, 710, 711, 711, 711, 711, 711, 711, 711, 710, 710, 710, 710, 711, 711, 710, 711, 711, 711, 711, 711, 711, 711, 710, 710, 710, 710, 711, 711, 711, 711, 711, 710, 710, 711, 711, 711, 711, 711, 711, 710, 710, 710, 710, 710, 711, 711, 711, 711, 711, 711, 711, 710, 711, 711, 711, 711, 711, 711, 711, 711, 0] },
  station_general: { w: 994, h: 440, ox: 94, oy: 86,
    flames: [],
    top: [218, 217, 216, 200, 130, 76, 70, 69, 57, 50, 50, 50, 50, 22, 19, 19, 2, 2, 32, 29, 28, 28, 31, 39, 41, 40, 36, 32, 31, 27, 26, 25, 26, 26, 26, 26, 28, 31, 33, 36, 41, 42, 40, 40, 40, 40, 40, 43, 42, 36, 32, 31, 28, 26, 26, 26, 26, 26, 29, 31, 34, 36, 43, 40, 40, 40, 40, 40, 43, 42, 36, 33, 31, 30, 26, 26, 26, 26, 26, 26, 26, 30, 32, 33, 37, 40, 40, 40, 29, 26, 22, 22, 22, 26, 30, 2, 2, 46, 50, 50, 50, 55, 63, 72, 83, 66, 43, 38, 37, 36, 36, 36, 35, 34, 33, 32, 31, 30, 28, 28, 26, 23, 23, 24, 72, 77, 147, 149, 150, 124, 123, 160, 213],
    bottom: [273, 430, 436, 436, 436, 436, 437, 438, 438, 438, 438, 438, 438, 436, 436, 436, 436, 436, 436, 436, 436, 436, 436, 436, 436, 436, 436, 436, 436, 438, 438, 438, 438, 438, 438, 438, 437, 436, 436, 436, 436, 436, 436, 436, 436, 436, 436, 436, 436, 436, 436, 436, 436, 438, 438, 438, 438, 438, 438, 436, 436, 436, 436, 436, 436, 436, 436, 436, 436, 436, 436, 436, 436, 436, 436, 438, 438, 438, 438, 438, 438, 438, 436, 436, 436, 436, 436, 436, 436, 436, 436, 436, 436, 436, 436, 438, 438, 438, 438, 438, 438, 438, 438, 436, 436, 436, 436, 436, 436, 436, 436, 436, 436, 436, 436, 436, 436, 436, 436, 436, 436, 438, 438, 438, 437, 437, 437, 437, 436, 436, 436, 436, 428] },
  station_outpost: { w: 621, h: 411, ox: 46, oy: 74,
    flames: [],
    top: [51, 45, 45, 45, 45, 44, 44, 45, 45, 46, 46, 46, 46, 46, 46, 45, 34, 33, 30, 24, 24, 24, 24, 24, 24, 24, 24, 26, 33, 33, 45, 45, 45, 33, 33, 28, 24, 24, 24, 24, 24, 24, 24, 24, 30, 33, 33, 45, 46, 36, 33, 32, 25, 24, 24, 24, 23, 24, 24, 24, 26, 33, 33, 37, 45, 46, 46, 46, 46, 45, 45, 45, 45, 47, 50, 15, 14, 3, 2, 5, 75, 85, 164],
    bottom: [409, 409, 409, 409, 409, 409, 409, 409, 409, 409, 409, 409, 409, 409, 409, 409, 409, 409, 409, 409, 409, 409, 409, 409, 409, 409, 409, 409, 409, 409, 409, 409, 409, 409, 409, 409, 409, 409, 409, 409, 409, 409, 409, 409, 409, 409, 409, 409, 409, 409, 409, 409, 409, 409, 409, 409, 409, 409, 409, 409, 409, 409, 408, 409, 409, 409, 409, 409, 409, 409, 409, 409, 409, 409, 409, 409, 409, 409, 409, 409, 409, 409, 285] },
  station_military: { w: 939, h: 476, ox: 36, oy: 98,
    flames: [],
    top: [242, 55, 48, 22, 4, 2, 3, 11, 29, 22, 20, 18, 18, 16, 16, 18, 15, 11, 11, 11, 11, 11, 16, 18, 19, 19, 21, 15, 14, 16, 21, 19, 19, 19, 19, 19, 19, 20, 19, 19, 20, 18, 13, 12, 14, 21, 21, 21, 17, 16, 16, 17, 19, 27, 24, 24, 23, 16, 16, 24, 24, 24, 20, 16, 16, 25, 25, 28, 26, 20, 19, 19, 21, 17, 16, 11, 11, 11, 11, 11, 16, 21, 15, 14, 22, 21, 19, 19, 19, 19, 19, 19, 15, 14, 15, 20, 16, 16, 15, 16, 20, 16, 14, 14, 14, 14, 14, 14, 14, 14, 14, 15, 20, 20, 24, 32, 10, 2, 2, 6, 24, 36, 39, 39, 39, 476],
    bottom: [278, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 474, 0] },
  station_science: { w: 874, h: 432, ox: 45, oy: 80,
    flames: [],
    top: [223, 223, 177, 171, 171, 171, 170, 170, 168, 160, 154, 152, 145, 144, 144, 144, 144, 144, 152, 121, 121, 42, 36, 34, 34, 36, 49, 3, 16, 17, 19, 51, 30, 47, 49, 49, 34, 33, 27, 26, 25, 25, 25, 25, 25, 25, 26, 30, 33, 46, 47, 47, 47, 33, 32, 26, 25, 25, 25, 25, 25, 25, 26, 26, 33, 34, 46, 47, 47, 38, 33, 29, 26, 25, 25, 25, 25, 25, 25, 26, 29, 33, 49, 49, 51, 53, 14, 12, 34, 9, 8, 9, 13, 19, 63, 67, 131, 129, 154, 167, 167, 166, 164, 164, 164, 164, 164, 164, 164, 165, 170, 170, 173, 173, 173, 178, 399],
    bottom: [253, 431, 431, 431, 431, 431, 430, 430, 431, 430, 431, 431, 431, 431, 431, 431, 431, 431, 431, 431, 431, 431, 430, 431, 431, 431, 431, 431, 430, 431, 431, 430, 430, 431, 431, 431, 431, 431, 431, 431, 431, 431, 431, 431, 431, 431, 431, 431, 431, 431, 431, 431, 431, 431, 431, 431, 431, 431, 431, 431, 431, 431, 430, 431, 431, 431, 431, 431, 431, 431, 431, 431, 431, 431, 431, 431, 431, 431, 431, 431, 431, 431, 431, 431, 431, 431, 431, 431, 431, 431, 431, 431, 431, 431, 431, 431, 431, 430, 431, 431, 431, 431, 431, 431, 431, 431, 431, 431, 431, 430, 430, 430, 431, 431, 431, 431, 430] },
  prison_block: { w: 954, h: 480, ox: 74, oy: 100,
    flames: [],
    top: [242, 37, 33, 33, 33, 9, 6, 3, 2, 3, 7, 26, 30, 24, 24, 22, 21, 23, 26, 26, 26, 26, 26, 24, 23, 23, 23, 23, 26, 26, 26, 26, 25, 25, 26, 26, 26, 26, 21, 20, 20, 20, 22, 25, 25, 25, 25, 25, 25, 23, 23, 16, 12, 6, 5, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 5, 5, 8, 14, 18, 23, 23, 25, 25, 25, 25, 24, 24, 21, 20, 20, 20, 23, 26, 26, 26, 26, 26, 26, 26, 26, 27, 24, 23, 23, 23, 23, 25, 25, 25, 25, 26, 26, 21, 21, 21, 24, 26, 4, 2, 2, 2, 5, 9, 34, 33, 33, 33, 38, 431],
    bottom: [470, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 478, 475] },
  frigate: { w: 722, h: 410, ox: 94, oy: 42,
    pads: [[102, 380, 200, 407], [529, 380, 628, 407]],
    wells: [[103, 370, 199, 407], [530, 370, 627, 407]],
    sockets: true,
    rings: [[136, 201, 2]],
    rings: [[136, 201, 2]],
    flames: [[18, 83, -1, 0, 42, 65.1], [18, 191.6, -1, 0, 42, 65.1], [18, 306.1, -1, 0, 42, 65.1]],
    top: [410, 410, 63, 55, 51, 41, 34, 29, 22, 18, 18, 12, 12, 12, 14, 14, 12, 7, 3, 3, 3, 3, 3, 3, 3, 3, 3, 7, 11, 11, 11, 11, 11, 11, 11, 12, 15, 18, 17, 18, 16, 14, 14, 14, 10, 8, 7, 7, 7, 7, 7, 8, 10, 15, 18, 18, 18, 18, 18, 15, 15, 14, 14, 14, 14, 14, 16, 15, 15, 15, 10, 8, 7, 7, 7, 7, 7, 8, 9, 15, 11, 11, 10, 6, 6, 6, 8, 9, 15, 22, 30, 41, 51, 66, 102, 128, 410],
    bottom: [0, 0, 339, 348, 354, 367, 373, 388, 392, 403, 403, 404, 407, 408, 408, 408, 408, 408, 408, 408, 408, 408, 408, 408, 408, 408, 408, 407, 407, 407, 404, 404, 404, 404, 404, 404, 404, 404, 404, 405, 406, 406, 405, 405, 404, 404, 404, 404, 404, 404, 404, 404, 404, 405, 405, 405, 405, 405, 404, 404, 404, 404, 404, 404, 404, 404, 404, 407, 407, 407, 408, 408, 408, 408, 408, 408, 408, 408, 408, 408, 408, 408, 408, 408, 406, 405, 400, 396, 388, 378, 369, 358, 343, 328, 304, 277, 0] },
  thoth: { w: 770, h: 423, ox: 38, oy: 57, aftReach: 60,
    pads: [[195, 394, 294, 421], [386, 394, 484, 421], [576, 394, 675, 421]],
    wells: [[196, 383, 293, 421], [387, 383, 483, 421], [577, 383, 674, 421]],
    sockets: true,
    rings: [[227, 296, 2], [422, 492, 9], [576, 651, 9]],
    rings: [[227, 296, 2], [422, 492, 9], [576, 651, 9]],
    flames: [[75, 98.1, -1, 0, 42, 65.1], [76, 328.4, -1, 0, 42, 65.1]],
    top: [182, 173, 164, 146, 146, 145, 145, 144, 143, 143, 76, 71, 71, 71, 63, 59, 56, 48, 43, 34, 28, 26, 24, 24, 24, 22, 18, 17, 16, 13, 6, 3, 2, 3, 3, 3, 3, 3, 3, 8, 16, 17, 17, 17, 19, 20, 24, 26, 27, 24, 24, 24, 24, 24, 27, 25, 15, 12, 11, 10, 10, 10, 10, 11, 12, 15, 25, 25, 25, 25, 24, 24, 24, 24, 24, 16, 13, 12, 11, 10, 10, 10, 10, 11, 12, 13, 15, 24, 24, 24, 24, 25, 26, 26, 27, 27, 30, 33, 39, 45, 55, 63, 84],
    bottom: [250, 259, 267, 283, 283, 284, 284, 284, 284, 284, 354, 359, 359, 359, 373, 377, 392, 400, 403, 410, 414, 414, 414, 415, 417, 418, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 418, 418, 416, 416, 415, 415, 415, 414, 416, 418, 418, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 418, 418, 415, 415, 415, 415, 415, 416, 416, 418, 418, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 418, 418, 416, 414, 414, 414, 410, 404, 394, 389, 380, 373, 354] },
  enemy_ra: { w: 674, h: 412, ox: 94, oy: 46,
    pads: [[102, 383, 201, 410], [482, 382, 582, 410]],
    wells: [[103, 374, 200, 410], [483, 374, 581, 410]],
    sockets: true,
    rings: [[138, 201, 1], [337, 398, 4], [481, 549, 4]],
    rings: [[138, 201, 1], [337, 398, 4], [481, 549, 4]],
    flames: [[17, 87.6, -1, 0, 42, 65.1], [18, 204, -1, 0, 42, 65.1], [18, 315.7, -1, 0, 42, 65.1]],
    top: [412, 412, 70, 62, 57, 47, 38, 33, 25, 19, 17, 15, 15, 16, 16, 14, 13, 9, 2, 2, 2, 2, 2, 2, 2, 2, 2, 8, 12, 12, 12, 12, 12, 12, 12, 14, 14, 19, 19, 19, 16, 16, 16, 10, 7, 6, 5, 5, 5, 5, 5, 6, 7, 9, 18, 20, 20, 18, 17, 16, 16, 16, 16, 10, 7, 6, 5, 5, 5, 5, 5, 6, 7, 8, 18, 16, 16, 16, 16, 17, 18, 18, 18, 19, 25, 33, 40, 46, 58, 75],
    bottom: [0, 0, 341, 350, 358, 370, 391, 395, 401, 407, 407, 407, 409, 411, 411, 411, 411, 411, 411, 411, 411, 411, 411, 411, 411, 411, 411, 409, 409, 409, 407, 407, 407, 407, 407, 406, 407, 407, 409, 409, 409, 409, 409, 409, 409, 409, 409, 409, 409, 409, 409, 409, 409, 409, 407, 406, 407, 406, 407, 407, 407, 407, 409, 409, 411, 411, 411, 411, 411, 411, 411, 411, 411, 411, 411, 411, 411, 411, 409, 409, 407, 406, 405, 404, 398, 390, 381, 371, 361, 345] },
  enemy_nephthys: { w: 884, h: 416, ox: 129, oy: 50,
    pads: [[138, 386, 237, 413], [402, 386, 501, 413], [666, 385, 766, 413]],
    wells: [[139, 377, 236, 413], [403, 377, 500, 413], [667, 377, 765, 413]],
    sockets: true,
    rings: [[166, 237, 1], [326, 395, 2], [510, 580, 2], [670, 740, 2]],
    rings: [[166, 237, 1], [326, 395, 2], [510, 580, 2], [670, 740, 2]],
    flames: [[17, 89.2, -1, 0, 42, 65.1], [17, 316.8, -1, 0, 42, 65.1]],
    top: [416, 416, 75, 69, 67, 66, 66, 52, 42, 39, 39, 31, 31, 24, 21, 19, 19, 18, 15, 15, 15, 10, 4, 2, 2, 3, 3, 3, 3, 2, 2, 2, 8, 14, 15, 15, 17, 18, 21, 19, 19, 16, 7, 6, 4, 3, 3, 3, 3, 3, 4, 5, 8, 19, 18, 18, 19, 18, 18, 18, 18, 18, 19, 20, 20, 19, 19, 16, 7, 6, 4, 3, 3, 3, 3, 3, 4, 5, 8, 19, 19, 18, 18, 18, 18, 19, 20, 16, 8, 6, 4, 3, 3, 3, 3, 3, 4, 5, 8, 19, 17, 17, 17, 18, 20, 20, 20, 21, 25, 25, 29, 35, 36, 39, 44, 50, 62, 74],
    bottom: [0, 0, 343, 349, 351, 353, 352, 367, 382, 390, 394, 401, 408, 408, 408, 411, 411, 411, 414, 414, 414, 414, 414, 414, 414, 414, 414, 414, 414, 414, 414, 414, 412, 412, 412, 412, 411, 411, 409, 411, 410, 410, 410, 411, 409, 410, 411, 411, 412, 412, 412, 412, 412, 414, 414, 414, 414, 414, 414, 414, 414, 414, 414, 414, 414, 414, 414, 412, 412, 412, 412, 412, 410, 410, 409, 410, 410, 410, 410, 410, 410, 410, 410, 410, 409, 412, 412, 412, 412, 414, 414, 414, 414, 414, 414, 414, 414, 414, 414, 414, 414, 414, 414, 412, 412, 412, 406, 405, 402, 395, 387, 383, 380, 374, 371, 365, 355, 342] },
  scout: { w: 894, h: 314, ox: 128, oy: 60,
    pads: [[135, 289, 210, 311], [391, 289, 466, 311]],
    wells: [[136, 283, 209, 311], [392, 283, 465, 311]],
    sockets: true,
    rings: [[175, 264, 1], [372, 430, 11], [507, 576, 11], [658, 729, 11]],
    rings: [[175, 264, 1], [372, 430, 11], [507, 576, 11], [658, 729, 11]],
    flames: [[15, 102.8, -1, 0, 42, 65.1], [15, 215.8, -1, 0, 42, 65.1]],
    top: [314, 314, 80, 76, 73, 73, 60, 56, 56, 55, 49, 42, 39, 38, 38, 38, 33, 26, 26, 26, 26, 20, 13, 5, 3, 3, 2, 2, 2, 2, 2, 2, 3, 2, 3, 8, 17, 19, 19, 19, 20, 27, 32, 33, 33, 32, 29, 19, 16, 14, 13, 12, 12, 12, 13, 13, 16, 19, 29, 32, 33, 33, 33, 33, 33, 32, 29, 19, 15, 14, 13, 12, 12, 13, 13, 13, 15, 18, 29, 31, 33, 33, 33, 33, 33, 31, 30, 17, 15, 13, 12, 12, 12, 12, 13, 15, 17, 23, 30, 31, 32, 32, 32, 35, 40, 44, 44, 44, 44, 44, 44, 49, 54, 58, 63, 67, 73, 77, 82, 89],
    bottom: [0, 0, 243, 247, 251, 251, 272, 280, 281, 291, 299, 301, 310, 310, 310, 311, 311, 311, 312, 312, 312, 312, 312, 312, 312, 312, 312, 312, 311, 311, 311, 310, 310, 310, 310, 310, 311, 311, 311, 311, 311, 311, 311, 311, 311, 311, 311, 311, 311, 311, 311, 311, 312, 312, 312, 312, 312, 312, 312, 312, 312, 312, 311, 311, 311, 310, 310, 310, 310, 310, 310, 311, 311, 311, 311, 307, 307, 307, 307, 307, 307, 307, 310, 310, 307, 307, 307, 307, 308, 308, 308, 308, 306, 300, 299, 298, 298, 295, 287, 287, 287, 284, 281, 278, 275, 272, 269, 266, 263, 260, 257, 256, 253, 252, 250, 245, 238, 112, 106, 96] },
  enemy_montu: { w: 891, h: 309, ox: 126, oy: 56,
    pads: [[134, 284, 210, 306], [539, 284, 615, 306]],
    wells: [[135, 278, 209, 306], [540, 278, 614, 306]],
    sockets: true,
    rings: [[314, 388, 2], [515, 582, 15], [661, 735, 15]],
    rings: [[314, 388, 2], [515, 582, 15], [661, 735, 15]],
    flames: [[101, 96.9, -1, 0, 42, 65.1], [15, 216.7, -1, 0, 42, 65.1]],
    top: [309, 309, 193, 189, 187, 187, 178, 169, 169, 169, 166, 162, 159, 78, 73, 72, 71, 69, 55, 55, 55, 55, 50, 43, 38, 36, 36, 36, 36, 36, 31, 26, 21, 21, 21, 21, 21, 21, 16, 13, 13, 6, 3, 4, 4, 3, 3, 3, 3, 4, 3, 4, 11, 15, 15, 15, 15, 16, 22, 28, 28, 28, 28, 28, 28, 30, 28, 20, 17, 16, 16, 16, 16, 16, 16, 16, 17, 18, 28, 30, 30, 29, 28, 28, 30, 30, 29, 22, 18, 16, 16, 16, 16, 16, 16, 16, 16, 17, 28, 29, 28, 28, 28, 31, 36, 39, 43, 43, 44, 47, 50, 53, 54, 57, 62, 66, 70, 75, 81],
    bottom: [0, 0, 242, 245, 248, 248, 248, 273, 277, 288, 297, 297, 306, 306, 306, 306, 306, 307, 307, 307, 307, 307, 307, 307, 307, 307, 308, 307, 306, 306, 306, 306, 306, 306, 306, 306, 306, 306, 306, 306, 306, 306, 306, 306, 306, 306, 306, 306, 306, 306, 306, 306, 306, 306, 306, 306, 306, 306, 306, 306, 306, 306, 306, 306, 306, 306, 306, 306, 306, 307, 307, 307, 307, 307, 307, 307, 307, 307, 307, 307, 307, 307, 306, 306, 306, 306, 306, 306, 306, 306, 299, 303, 303, 303, 304, 304, 301, 297, 297, 297, 297, 291, 286, 286, 283, 279, 276, 272, 269, 266, 260, 132, 128, 124, 119, 115, 110, 106, 99] },
  customs_cruiser: { w: 879, h: 423, ox: 129, oy: 56,
    pads: [[137, 391, 237, 420], [518, 391, 618, 420]],
    wells: [[138, 383, 236, 420], [519, 383, 617, 420]],
    sockets: true,
    rings: [[331, 395, 11], [509, 579, 11], [668, 740, 11]],
    rings: [[331, 395, 11], [509, 579, 11], [668, 740, 11]],
    flames: [[15, 104.1, -1, 0, 42, 65.1], [16, 316.2, -1, 0, 42, 65.1]],
    top: [423, 423, 76, 73, 70, 53, 52, 47, 41, 39, 39, 40, 39, 36, 32, 27, 27, 27, 24, 18, 11, 3, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 8, 21, 22, 22, 25, 31, 31, 33, 31, 16, 14, 13, 11, 11, 11, 11, 11, 13, 15, 19, 31, 32, 32, 32, 32, 30, 29, 30, 30, 32, 33, 33, 33, 31, 23, 16, 13, 13, 11, 11, 11, 11, 11, 13, 15, 20, 31, 32, 32, 30, 30, 30, 31, 31, 31, 16, 14, 13, 11, 11, 11, 11, 11, 13, 15, 19, 30, 30, 30, 29, 29, 33, 38, 43, 45, 45, 45, 46, 52, 58, 64, 71, 76, 83, 90],
    bottom: [0, 0, 348, 354, 356, 357, 379, 386, 388, 391, 402, 409, 417, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 421, 418, 421, 421, 421, 421, 421, 421, 421, 421, 415, 412, 412, 412, 412, 410, 406, 406, 406, 405, 405, 401, 398, 393, 390, 385, 381, 377, 373, 369, 94] },
  enemy_khnum: { w: 897, h: 422, ox: 129, oy: 54,
    pads: [[136, 390, 236, 419], [324, 390, 422, 419]],
    wells: [[137, 382, 235, 419], [325, 382, 421, 419]],
    sockets: true,
    rings: [[504, 571, 2], [677, 740, 2]],
    rings: [[504, 571, 2], [677, 740, 2]],
    flames: [[320, 90.3, -1, 0, 26, 20.7], [164, 203.8, -1, 0, 26, 19.8], [19, 314.4, -1, 0, 42, 65.1]],
    top: [422, 422, 299, 295, 292, 289, 289, 274, 267, 267, 267, 267, 261, 255, 248, 241, 237, 237, 237, 237, 237, 185, 180, 175, 172, 171, 159, 157, 157, 157, 156, 147, 140, 134, 128, 128, 128, 128, 128, 128, 128, 128, 68, 64, 59, 56, 55, 45, 40, 37, 37, 37, 37, 37, 32, 28, 26, 26, 26, 26, 26, 26, 26, 23, 17, 17, 11, 3, 3, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 8, 17, 17, 21, 27, 27, 27, 24, 23, 7, 6, 4, 3, 3, 3, 3, 3, 5, 6, 8, 24, 25, 25, 29, 32, 32, 32, 32, 32, 34, 37, 41, 44, 47, 50, 52, 56, 60, 65, 69, 75],
    bottom: [0, 0, 342, 346, 349, 352, 353, 374, 380, 388, 399, 407, 412, 420, 420, 420, 420, 420, 420, 420, 420, 420, 420, 420, 420, 420, 420, 420, 420, 420, 420, 420, 420, 420, 420, 420, 420, 420, 420, 420, 420, 420, 420, 420, 420, 420, 420, 420, 420, 420, 420, 420, 420, 420, 420, 420, 420, 420, 420, 420, 420, 420, 420, 420, 420, 420, 420, 420, 420, 420, 418, 418, 418, 418, 418, 418, 419, 419, 413, 411, 407, 404, 396, 396, 392, 388, 382, 378, 374, 370, 365, 290, 290, 287, 283, 279, 274, 270, 266, 260, 191, 191, 190, 183, 175, 169, 162, 155, 148, 141, 131, 131, 127, 123, 118, 114, 109, 105, 100, 94] },
  hauler: { w: 864, h: 321, ox: 132, oy: 62,
    pads: [[133, 292, 226, 319], [406, 291, 501, 319], [668, 292, 762, 319]],
    wells: [[134, 289, 225, 319], [407, 289, 500, 319], [669, 289, 761, 319]],
    sockets: true,
    rings: [[179, 268, 1], [372, 443, 9], [522, 598, 9], [677, 754, 9]],
    rings: [[179, 268, 1], [372, 443, 9], [522, 598, 9], [677, 754, 9]],
    flames: [[16, 104.3, -1, 0, 42, 65.1], [16, 219.7, -1, 0, 42, 65.1]],
    top: [321, 321, 80, 73, 71, 70, 70, 55, 50, 50, 50, 50, 44, 36, 30, 28, 28, 28, 28, 25, 22, 22, 18, 9, 3, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 4, 11, 19, 22, 22, 22, 28, 30, 29, 29, 29, 30, 29, 27, 14, 12, 11, 10, 10, 10, 10, 10, 12, 14, 20, 28, 30, 30, 29, 29, 29, 30, 30, 28, 17, 13, 12, 10, 10, 10, 10, 10, 11, 12, 15, 28, 30, 30, 29, 29, 29, 30, 30, 30, 27, 16, 13, 11, 10, 10, 10, 10, 10, 11, 13, 17, 27, 28, 28, 28, 28, 36, 43, 52, 59, 68, 76, 85, 93, 102, 321],
    bottom: [0, 0, 248, 254, 258, 259, 259, 287, 292, 292, 304, 311, 311, 318, 319, 319, 319, 320, 320, 320, 320, 320, 320, 320, 320, 320, 320, 320, 320, 320, 320, 320, 320, 320, 319, 319, 319, 319, 319, 319, 319, 319, 320, 320, 319, 320, 320, 320, 320, 320, 320, 320, 319, 319, 320, 320, 320, 320, 320, 320, 320, 320, 320, 320, 320, 320, 320, 320, 320, 320, 320, 320, 320, 320, 319, 319, 319, 319, 319, 319, 319, 319, 320, 320, 320, 319, 320, 320, 319, 320, 320, 320, 320, 320, 320, 320, 320, 320, 320, 320, 320, 320, 319, 319, 317, 307, 295, 284, 271, 259, 246, 234, 221, 209, 196, 0] },
  enemy_mech: { w: 820, h: 375, ox: 118, oy: 64,
    sockets: true,
    rings: [[356, 418, 16]],   // measured by hand: the roof beside it is the housing's, find_rings misses it
    flames: [],
    top: [78, 74, 62, 54, 46, 45, 45, 39, 33, 33, 28, 26, 26, 26, 15, 13, 12, 12, 13, 13, 10, 6, 4, 3, 3, 4, 3, 3, 4, 4, 4, 9, 17, 17, 7, 6, 6, 6, 6, 6, 6, 13, 25, 24, 26, 29, 23, 20, 19, 17, 17, 17, 17, 17, 19, 19, 22, 27, 33, 31, 30, 28, 28, 29, 30, 35, 58, 100, 99, 97, 97, 97, 97, 97, 97, 98, 95, 95, 95, 98, 98, 98, 98, 98, 98, 98, 105, 108, 112, 134, 136, 139, 147, 163, 210, 213, 216, 219, 222, 223, 223, 225, 226, 229, 233, 237, 244, 250, 262, 280],
    bottom: [263, 268, 293, 300, 303, 327, 334, 338, 338, 339, 338, 347, 353, 362, 365, 368, 368, 369, 369, 368, 368, 368, 368, 368, 368, 368, 368, 368, 368, 368, 368, 368, 368, 369, 368, 368, 368, 368, 368, 368, 368, 368, 368, 368, 368, 368, 368, 368, 368, 369, 368, 368, 368, 368, 368, 368, 368, 369, 368, 368, 368, 368, 368, 368, 368, 368, 368, 368, 368, 368, 368, 368, 368, 368, 368, 368, 368, 368, 368, 368, 368, 368, 367, 363, 355, 342, 345, 350, 353, 354, 354, 354, 354, 356, 363, 368, 363, 373, 373, 372, 374, 374, 369, 369, 359, 359, 346, 328, 312, 312] },
  bunker_small: { w: 1008, h: 378, ox: 256, oy: 78,
    sockets: true,
    rings: [[313, 355, 2], [486, 530, 2], [671, 724, 2]],
    flames: [],
    top: [371, 370, 370, 357, 350, 343, 341, 305, 295, 280, 264, 246, 227, 210, 195, 179, 164, 145, 129, 116, 107, 96, 87, 78, 65, 51, 45, 41, 33, 30, 30, 30, 30, 30, 30, 30, 31, 29, 27, 16, 14, 5, 4, 3, 3, 3, 3, 5, 13, 13, 18, 28, 31, 31, 30, 30, 30, 30, 31, 31, 27, 18, 14, 14, 5, 4, 3, 3, 3, 3, 4, 21, 14, 14, 26, 28, 31, 32, 30, 30, 30, 30, 30, 31, 30, 27, 18, 14, 14, 5, 4, 3, 3, 3, 3, 3, 5, 14, 14, 18, 27, 30, 30, 30, 30, 30, 30, 37, 42, 49, 60, 75, 86, 97, 108, 119, 137, 151, 169, 184, 200, 215, 232, 252, 269, 285, 299, 341, 341, 343, 355, 370, 370, 370, 372],
    bottom: [375, 375, 375, 376, 376, 376, 373, 376, 376, 376, 376, 376, 376, 376, 376, 376, 376, 377, 377, 377, 377, 376, 376, 376, 377, 377, 377, 377, 377, 377, 377, 377, 377, 376, 376, 376, 376, 376, 377, 377, 377, 377, 377, 377, 377, 377, 377, 377, 377, 377, 377, 377, 377, 377, 377, 377, 377, 377, 377, 377, 377, 377, 377, 377, 377, 377, 377, 377, 377, 376, 377, 377, 377, 377, 377, 377, 377, 377, 377, 377, 377, 377, 377, 377, 377, 377, 377, 377, 377, 377, 377, 377, 377, 377, 377, 377, 377, 377, 376, 376, 377, 377, 377, 377, 377, 377, 376, 377, 377, 376, 376, 377, 377, 377, 377, 377, 377, 377, 377, 377, 377, 376, 376, 376, 376, 376, 376, 375, 376, 376, 376, 375, 375, 375, 375] },
};

/**
 * Flames out of nozzles (update176) — for a ship in the world and for her
 * thumbnail alike (`k` the thumbnail's scale, nozzles already in its px).
 * A flame: length × width in the units of `ctx`, pointing (dx, dy).
 */
/* THE FLAME'S COLOURS PER SHIPYARD (update177): Pegasus burns cyan,
   Terra (copper and steel, green lamps) a hot amber; Aquarius teal,
   Phoenix (hydrogen drives) a fierce orange-red (update179). [glow, body, tail]
   as r,g,b; the core is white for all. */
/* ONE FLAME FOR EVERY YARD (update238, jj 17.11: „kolor odrzutu zawsze ten sam, niebieskawy przy spalaniu He2 w kosmosie,
   do wszystkich statków"): every drive burns the same He2, so every exhaust is the same pale blue — the yards' own
   colours (amber Terra, teal Aquarius, red Phoenix) are gone. */
const HE2_FLAME = { glow: '110,170,255', hot: '205,225,255', tail: '70,120,255' };
const THRUSTER_FLAME = { pegasus: HE2_FLAME, terra: HE2_FLAME, aquarius: HE2_FLAME, phoenix: HE2_FLAME };
function thrusterFlameFor(builder) { return THRUSTER_FLAME[builder] ?? THRUSTER_FLAME.pegasus; }

const FLAME_NARROW = 0.68;
function drawThrusterFlames(ctx, thrusters, on, t, k = 1, pal = THRUSTER_FLAME.pegasus) {
  if (!thrusters.length || !on) return;
  ctx.save();
  thrusters.forEach((f, i) => {
    const flick = 0.82 + 0.12 * Math.sin(t * 23 + i * 1.7) + 0.06 * Math.sin(t * 41 + i * 0.9);
    /* NARROWER (update242, jj 17.11: „animacja odrzutów za wysoka w stosunku do silników, zwęź ją w pionie"): the
       flame `FLAME_NARROW` of the nozzle's mouth, its glow squashed to an ellipse no taller than the nozzle */
    const L = Math.max(2, f.len * k * 1.25 * flick), Wd = Math.max(1.5, f.wid * k * FLAME_NARROW);
    const ang = Math.atan2(f.dy, f.dx);
    ctx.save();
    ctx.translate(f.x, f.y); ctx.rotate(ang);
    // the glow
    const R = Math.max(L, Wd) * 0.9, sq = Math.min(1, (f.wid * k * 0.5) / R);
    const gl = ctx.createRadialGradient(L * 0.25, 0, 0, L * 0.25, 0, R);
    gl.addColorStop(0, `rgba(${pal.glow},0.35)`); gl.addColorStop(1, `rgba(${pal.glow},0)`);
    ctx.save(); ctx.scale(1, sq);
    ctx.fillStyle = gl; ctx.fillRect(L * 0.25 - R, -R, R * 2, R * 2);
    ctx.restore();
    // the body: a cone from the nozzle
    const body = ctx.createLinearGradient(0, 0, L, 0);
    body.addColorStop(0, 'rgba(255,255,245,0.95)'); body.addColorStop(0.2, `rgba(${pal.hot},0.95)`);
    body.addColorStop(0.6, `rgba(${pal.tail},0.7)`); body.addColorStop(1, `rgba(${pal.tail},0)`);
    ctx.fillStyle = body;
    ctx.beginPath(); ctx.moveTo(-1, -Wd / 2); ctx.quadraticCurveTo(L * 0.45, -Wd * 0.55, L, 0);
    ctx.quadraticCurveTo(L * 0.45, Wd * 0.55, -1, Wd / 2); ctx.closePath(); ctx.fill();
    // the white core
    ctx.fillStyle = 'rgba(255,255,255,0.85)';
    ctx.beginPath(); ctx.ellipse(L * 0.12, 0, Math.max(1, L * 0.2), Math.max(0.8, Wd * 0.22), 0, 0, Math.PI * 2); ctx.fill();
    ctx.restore();
  });
  ctx.restore();
}

/** `g` re-cut to a shaped picture: the box is the picture, the plate is
 *  the modules' (it is what the bubble and the shells see), the engine
 *  glows burn one per deck at the stern end of the shape. */
function shapedHullGeometry(g, spec, isPlayer = true) {
  const s = spec.scale ?? HULL_SHAPED_SCALE, b = g.bounds;
  const W = spec.w / s, H = spec.h / s;
  const ox = isPlayer ? spec.ox / s : W - spec.ox / s - b.w;
  const box = { x: b.x - ox, y: b.y - spec.oy / s, w: W, h: H };
  const stern = isPlayer ? box.x : box.x + box.w;
  /* HER THRUSTERS (update176, jj: "silniki … animacja … na dziobie i na
     dole i górze; jak silniki nie działają, widać to"). GPT drew every one
     burning; tools/fit_gpt_hull.py took the flames out of the picture and
     wrote where each nozzle is: [x, y, dx, dy, length, width] in picture
     px, flown by you. Here in grid units, mirrored for theirs. The game
     burns them (Ship._drawThrusters) while her engines are running. */
  const thrusters = (spec.flames ?? []).map(([fx, fy, dx, dy, len, wid]) => ({
    x: isPlayer ? box.x + fx / s : box.x + box.w - fx / s, y: box.y + fy / s,
    dx: isPlayer ? dx : -dx, dy, len: len / s, wid: wid / s,
  }));
  const aft = thrusters.filter(t => t.dx === (isPlayer ? -1 : 1) && Math.abs(t.x - stern) < (spec.aftReach ?? 40));   // aftReach: Thoth's drives sit by her stern module (update235)
  const inset = (spec.nozzleInset ?? 12) / s;
  const engines = aft.length
    ? aft.map(t => ({ x: t.x - 0.5, y: t.y - t.wid / 2, w: 1, h: t.wid, side: 'stern', exhaustX: t.x }))
    : g.decks.map(d => ({
        x: isPlayer ? stern + inset : stern - inset - 1, y: d.y + d.h / 2 - 8, w: 1, h: 16,
        deck: d.floor, side: 'stern', exhaustX: isPlayer ? stern + inset : stern - inset,
      }));
  /* her outline, top and keel, every `step` units across (flown by you) —
     the guns stand on the one, her legs under the other (update176) */
  const step = 7.5 / s;
  const edge = (arr, x) => {
    if (!arr?.length) return null;
    const u = isPlayer ? x - box.x : box.x + box.w - x;
    const i = Math.floor(u / step);
    return (i >= 0 && i < arr.length) ? arr[i] : null;
  };
  const topAt = (x0, x1 = x0) => {
    let best = null;
    for (let x = x0; x <= x1 + 1e-6; x += step) { const v = edge(spec.top, x); if (v != null && v < spec.h) best = best == null ? v : Math.min(best, v); }
    return best == null ? null : box.y + best / s;
  };
  const keelAt = (x0, x1 = x0) => {
    let best = null;
    for (let x = x0; x <= x1 + 1e-6; x += step) { const v = edge(spec.bottom, x); if (v != null && v > 0) best = best == null ? v : Math.max(best, v); }
    return best == null ? null : box.y + best / s;
  };
  /* HER LANDING PADS (update199, jj: "na każdym kadłubie są gotowe już
     podwozie — chodzi o to, aby się opuściło"): where the yard drew them on
     her keel (tools/find_pads.py), in grid units, with the piece of her
     picture that is each one (`src`, picture px of THIS side's picture).
     The hangar lowers that piece to the apron (DockArt). */
  const pads = (spec.pads ?? []).map(([x0, y0, x1, y1]) => ({
    x0: isPlayer ? box.x + x0 / s : box.x + box.w - x1 / s,
    x1: isPlayer ? box.x + x1 / s : box.x + box.w - x0 / s,
    y0: box.y + y0 / s, y1: box.y + y1 / s,
    src: { x: isPlayer ? x0 : spec.w - x1, y: y0, w: x1 - x0, h: y1 - y0 },
  }));
  /* HER GEAR BAYS (update235, the Aquarius standard: one bay 64×24 under the keel per leg, the yard's mount in it,
     the pad tucked into its bottom): the bay of each pad, the same way. With it the hangar draws the mount in the
     bay as the pad goes down, not an empty hole. */
  (spec.wells ?? []).forEach(([x0, y0, x1, y1], i) => {
    if (pads[i]) pads[i].well = { x0: isPlayer ? box.x + x0 / s : box.x + box.w - x1 / s, x1: isPlayer ? box.x + x1 / s : box.x + box.w - x0 / s,
                                 y0: box.y + y0 / s, y1: box.y + y1 / s };
  });
  /* HER GUN SOCKETS (update242): the rings on her roof (tools/guns/find_rings.py) — a drawn gun drops its base into one */
  const rings = (spec.rings ?? []).map(([x0, x1, top]) => ({
    cx: isPlayer ? box.x + (x0 + x1) / 2 / s : box.x + box.w - (x0 + x1) / 2 / s, w: (x1 - x0) / s, top: box.y + top / s,
  }));
  return { ...g, box, engines, thrusters, prows: [], shaped: true, artScale: s, topAt, keelAt, pads, sockets: !!spec.sockets, rings };
}

/**
 * @param {Array<{x,y,w,h,floor}>} rooms
 * @param {number[]} shaftXs  centres of the lift trunks
 * @param {boolean}  isPlayer stern on the left (yours) or the right
 * @param {boolean}  isStation
 */
function hullArtGeometry(rooms, shaftXs = [], isPlayer = true, isStation = false) {
  if (!rooms || !rooms.length) return null;
  const G = HULL_GRID, M = G.MARGIN;
  let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
  rooms.forEach(r => {
    x0 = Math.min(x0, r.x); y0 = Math.min(y0, r.y);
    x1 = Math.max(x1, r.x + r.w); y1 = Math.max(y1, r.y + r.h);
  });
  const b = { x: x0, y: y0, w: x1 - x0, h: y1 - y0 };
  // The stern needs less room than the bow now (update121); a station has neither.
  const padL = isStation ? HULL_ART.PAD_STERN : isPlayer ? HULL_ART.PAD_STERN : HULL_ART.PAD_BOW;
  const padR = isStation ? HULL_ART.PAD_STERN : isPlayer ? HULL_ART.PAD_BOW : HULL_ART.PAD_STERN;
  const box = { x: b.x - padL, y: b.y - HULL_ART.PAD_Y,
                w: b.w + padL + padR, h: b.h + 2 * HULL_ART.PAD_Y };
  const plate = rooms.map(r => ({ x: r.x - M, y: r.y - M, w: r.w + 2 * M, h: r.h + 2 * M }));
  shaftXs.forEach(cx => plate.push({
    x: cx - G.SHAFT_W / 2 - M, y: b.y - M, w: G.SHAFT_W + 2 * M, h: b.h + 2 * M }));

  // One entry per deck, top first: its top, height and how far it reaches.
  const decks = [];
  rooms.forEach(r => {
    let d = decks.find(o => o.y === r.y);
    if (!d) decks.push(d = { y: r.y, h: r.h, floor: r.floor, x0: r.x, x1: r.x + r.w });
    d.x0 = Math.min(d.x0, r.x); d.x1 = Math.max(d.x1, r.x + r.w);
  });
  decks.sort((a, c) => a.y - c.y);

  const engines = [], prows = [];
  if (!isStation) {
    const atBow   = d => isPlayer ? d.x1 === b.x + b.w : d.x0 === b.x;
    /* TWO NACELLES, ON TOP AND UNDERNEATH (update121). One along the
       top of the top deck, one along the underside of the bottom deck,
       each at that deck's stern end, sitting three pixels into the plate
       so it is bolted on, its nozzle a little past the stern. A one-deck
       hull carries both on the same deck. */
    const N = HULL_ART.NACELLE;
    [{ d: decks[0], side: 'top' }, { d: decks[decks.length - 1], side: 'bottom' }].forEach(({ d, side }) => {
      const sternEdge = isPlayer ? d.x0 - M : d.x1 + M;
      const x = isPlayer ? sternEdge - N.overhang : sternEdge + N.overhang - N.len;
      const y = side === 'top' ? d.y - M - N.h + 3 : d.y + d.h + M - 3;
      engines.push({ x, y, w: N.len, h: N.h, deck: d.floor, side,
                     exhaustX: isPlayer ? x : x + N.len });
    });
    let run = null;
    decks.forEach(d => {
      if (!atBow(d)) { run = null; return; }
      if (run && run.y + run.h === d.y) { run.h += d.h; return; }
      prows.push(run = { y: d.y, h: d.h });
    });
    prows.forEach(p => {
      p.x = isPlayer ? b.x + b.w + M : b.x - M - G.PROW_W;
      p.w = G.PROW_W;
    });
  }
  return { box, bounds: b, plate, engines, prows, isPlayer, isStation, decks };
}

/* ── WHO BUILT HER (update117) ─────────────────────────────
 *
 * Every hull comes off one corporation's yard, and you can tell which
 * from across the screen: the plate is painted in that corporation's
 * colour (the same `CORP_DEFS` colour its people wear), and the yard
 * has habits, which is what makes the colour worth reading (jj):
 *
 *   phoenix   red         good guns — the first barrel is often an
 *                         upgrade (a burst laser early, a heavy later)
 *   terra     orange      big reactors — power to spare, and a hotter
 *                         drive with it
 *   pegasus   pale blue   shields — always a bubble from sector 2, a
 *                         second layer from sector 3
 *   aquarius  blue        hospital ships — a medbay, always, and more
 *                         medicine in the hold
 *
 * The habits are fitted to ENEMY hulls when they spawn (`_spawnEnemy`).
 * The hulls you buy were designed to their yard already — Horus and
 * Thoth carry a medbay because Aquarius drew them — so for yours the
 * builder is the colour and the name, and the stats stay in the layout.
 *
 * The numbers live here and nowhere else.
 */
const BUILDER_TRAITS = {
  phoenix:  { blurb: 'Phoenix yard — better guns',     gunUpgradeOdds: 0.5,
              gunEarly: 'laser_burst', gunLate: 'laser_heavy' },
  terra:    { blurb: 'Terra yard — bigger reactor',    reactorSpare: 2, enginesBonus: 1 },
  pegasus:  { blurb: 'Pegasus yard — shielded',        shieldsFromSector: 2,
              extraLayerFromSector: 3 },
  aquarius: { blurb: 'Aquarius yard — hospital ship',  medkits: 2, medbayLevel: 2 },
};
/* THE INSIDE IN THE SHIP'S COLOURS (update120, jj: "całe wykończenie
   statku w środku… te same kolory co statek"). The ducts, the lift
   trunks, the doors and their frames are drawn in the yard's palette —
   the very numbers tools/hull_painter.js paints the plate with — instead
   of one blue for every ship of yours and one red for every enemy. */
const YARD_TRIM = {
  aquarius: { base: [36, 66, 112],  light: [92, 140, 204],  dark: [16, 30, 58], seam: [26, 46, 82] },
  pegasus:  { base: [104, 136, 160], light: [186, 216, 236], dark: [48, 66, 84], seam: [74, 98, 118] },
  terra:    { base: [128, 74, 36],  light: [208, 140, 78],  dark: [62, 34, 16], seam: [92, 52, 26] },
  phoenix:  { base: [112, 40, 36],  light: [184, 82, 70],   dark: [56, 18, 16], seam: [80, 28, 26] },
  // a hull nobody built (none today): the old blue of your side, the old red of theirs
  _you:     { base: [30, 58, 92],   light: [77, 184, 255],  dark: [10, 18, 32], seam: [24, 40, 64] },
  _them:    { base: [92, 30, 30],   light: [255, 90, 90],   dark: [32, 10, 10], seam: [64, 24, 24] },
};
/** An `rgba()` of a trim colour. */
function trimRgba(c, a = 1) { return `rgba(${c[0]},${c[1]},${c[2]},${a})`; }

/** The corporation that built a layout, or null. */
function hullBuilder(layoutKey) {
  const b = (SHIP_LAYOUTS?.[layoutKey] ?? (typeof STRUCTURE_LAYOUTS !== 'undefined' ? STRUCTURE_LAYOUTS[layoutKey] : null))?.builder;
  return b && BUILDER_TRAITS[b] ? b : null;
}

/* WHOSE DRAWN INSIDES A HULL HAS (update227, jj 10.11: „wstawmy to do pegasusa statków"): the v16 Aquarius set —
   modules, duct, lift — goes into Pegasus hulls too, to be tested there. The hull and its trim stay the yard's. */
const ART_YARD_AS = { pegasus: 'aquarius' };
function artYard(layoutKey) {
  const y = hullBuilder(layoutKey);
  return y ? (ART_YARD_AS[y] ?? y) : null;
}

/**
 * Expand a compact hull spec into the `rooms` / `elevators` shape the
 * rest of the engine already consumes, so nothing downstream had to
 * change when the grid arrived.
 *
 * Lift stops are DERIVED — every shaft stops on the crew walk line of
 * every deck it passes. They used to be hand-typed per hull, which is
 * how the boss station ended up with a cabin hanging out of the roof.
 */
/* ── THE HELM IN THE BOW, THE DRIVE AT THE STERN (update220, jj: "przenieś moduły pilotów na przód statków, aby
 * wyglądało bardziej naturalnie, a moduł silników zawsze przy silnikach") ─────────────────────────────────────
 * A layout is drawn bow to the right (col 0 is the stern, where the nozzles are). The cockpit trades places with
 * the room furthest forward — on its own deck if that deck reaches the bow, else the nearest deck that does — and
 * the engine room with the room furthest aft. Places stay; the rooms' names and kinds trade, and every door list
 * is renamed with them, so the hull, its picture and its doors are untouched. A station, a bunker or a walker has
 * no bow: left as it is. */
function _helmForward(spec) {
  const grid = spec.grid ?? [];
  if (spec.isStation || spec.grounded || spec.helmForward === false) return;
  const swap = (a, b) => {
    if (!a || !b || a === b) return;
    const ia = a.id, ib = b.id;
    [a.id, b.id] = [b.id, a.id]; [a.type, b.type] = [b.type, a.type]; [a.art, b.art] = [b.art, a.art];
    grid.forEach(r => { r.adjacent = (r.adjacent ?? []).map(x => x === ia ? ib : x === ib ? ia : x); });
  };
  const pick = (from, end) => {                    // end +1: the bow (max col), -1: the stern (min col)
    const best = Math.max(...grid.map(r => end * r.col));
    const ends = grid.filter(r => end * r.col === best);
    return ends.find(r => r.row === from.row) ?? ends.sort((p, q) => Math.abs(p.row - from.row) - Math.abs(q.row - from.row))[0];
  };
  const helm = grid.find(r => r.type === 'piloting');
  if (helm) swap(helm, pick(helm, 1));                           // the drive in the bow goes where the helm was…
  const eng = grid.find(r => r.type === 'engines');
  if (eng) { const t = pick(eng, -1); if (t && t.type !== 'piloting') swap(eng, t); }   // …and on to the stern
  /* THE BRIDGE ON TOP, AT THE STERN (update235, jj 13.11: „kokpit jest na tyłach nie przodzie", „kokpit na najwyższym
     poziomie"): a hull drawn to the new standard (`helmAft`) has her canopy over the top deck's stern-most module —
     the helm trades places with whatever is there (as on the blueprints GPT drew her from). */
  if (spec.helmAft) {
    const top = Math.max(...grid.map(r => r.row));
    const aftTop = grid.filter(r => r.row === top).sort((p, q) => p.col - q.col)[0];
    swap(grid.find(r => r.type === 'piloting'), aftTop);
  }
}

function buildHull(spec) {
  _helmForward(spec);
  const { originX, originY, decks, shaftAfter = [], grid = [] } = spec;
  const W = HULL_GRID.MODULE_W, H = HULL_GRID.MODULE_H;

  spec.floors = decks;
  spec.rooms = grid.map(r => ({
    id: r.id, type: r.type ?? 'empty',
    x: gridColX(originX, r.col, shaftAfter),
    y: gridRowY(originY, r.row, decks),
    w: W, h: H,
    floor: r.row,
    adjacent: r.adjacent ?? [],
    art: r.art ?? null,              // a room with no system, painted as one (update163: the block's rooms)
  }));

  /* A LIFT STOPS ONLY WHERE THERE IS A DECK TO STEP OFF ONTO (update95).
     Nephthys has a middle deck that is nothing but the trunk: the cabin
     rides through it and does not open its doors on open space. */
  const stops = [];
  for (let row = decks - 1; row >= 0; row--) {
    if (!grid.some(r => r.row === row)) continue;
    stops.push(gridRowY(originY, row, decks) + walkOffset());
  }
  spec.elevators = shaftAfter.map((afterCol, i) => ({
    id: 'ev' + i,
    x: gridShaftX(originX, afterCol, shaftAfter),
    floors: stops.slice(),
  }));
  return spec;
}

const SHIP_LAYOUTS = {

  /** FREE STARTER HULL — the same class of boat the ordinary raiders
   *  fly, refitted for you. Two decks, no medbay (field aid only),
   *  smaller reactor. The empty bay is the first real refit decision. */
  scout: buildHull({
    label: 'Bastet',
    helmAft: true,                 // update236: the new Terra hull (GPT) — the bridge on top at the stern, gun sockets
    builder: 'terra',
    spriteKey: 'ship_player',
    hullMax: 22,
    originX: 20, originY: 90, decks: 2, shaftAfter: [0],
    grid: [
      { id:'r_engines',  type:'engines',  col:0, row:0, adjacent:['r_weapons'] },
      { id:'r_weapons',  type:'weapons',  col:1, row:0, adjacent:['r_engines'] },
      { id:'r_piloting', type:'piloting', col:0, row:1, adjacent:['r_oxygen'] },
      { id:'r_oxygen',   type:'oxygen',   col:1, row:1, adjacent:['r_piloting','r_reactor'] },
      { id:'r_reactor',  type:'reactor',  col:2, row:1, adjacent:['r_oxygen','r_hold'] },
      /* SHE IS NOT A RECTANGLE ANY MORE (update73).
       *
       * Six modules, same as ever — but the free bay MOVED from the
       * lower deck's third column to a fourth column on the upper
       * deck, and nothing was put underneath it. A spur on top, a
       * notch below, and the first hull in this game with a profile
       * rather than an outline.
       *
       * Moved, not added, and that matters: the first attempt at this
       * put a NEW bay on the spur and left the old one where it was,
       * which quietly handed the starter ship a second free module —
       * "the empty bay is the first real refit decision" is what the
       * comment above this hull has always said, and two bays is not
       * a decision. Section 43 caught it on the next run. */
      { id:'r_hold',     type:'empty',    col:3, row:1, adjacent:['r_reactor'] },
    ],
    startSystems: ['engines','weapons','piloting','oxygen','reactor'],
    systemLevels: { oxygen: 2, weapons: 2, engines: 2 },
    startWeapons: ['laser_basic'],
    reactorLevel: 6,
    reactorMax: 12,
    weaponSlots: 1,
    cargoCols: 5, cargoRows: 3,
  }),

  /** Bought hull — Bastet's bigger sister: the same two-deck design
   *  with EIGHT bays instead of six, three of them starting empty. */
  hauler: buildHull({
    label: 'Hapi',
    helmAft: true,                 // update236: the new Terra hull (GPT) — the bridge on top at the stern, gun sockets
    builder: 'terra',
    spriteKey: 'ship_player',
    hullMax: 26,
    originX: 20, originY: 90, decks: 2, shaftAfter: [0],
    grid: [
      { id:'r_engines',  type:'engines',  col:0, row:0, adjacent:['r_weapons'] },
      { id:'r_weapons',  type:'weapons',  col:1, row:0, adjacent:['r_engines','r_hold1'] },
      { id:'r_hold1',    type:'empty',    col:2, row:0, adjacent:['r_weapons','r_hold2'] },
      { id:'r_hold2',    type:'empty',    col:3, row:0, adjacent:['r_hold1'] },
      { id:'r_piloting', type:'piloting', col:0, row:1, adjacent:['r_oxygen'] },
      { id:'r_oxygen',   type:'oxygen',   col:1, row:1, adjacent:['r_piloting','r_reactor'] },
      { id:'r_reactor',  type:'reactor',  col:2, row:1, adjacent:['r_oxygen','r_hold3'] },
      { id:'r_hold3',    type:'empty',    col:3, row:1, adjacent:['r_reactor'] },
    ],
    startSystems: ['engines','weapons','piloting','oxygen','reactor'],
    systemLevels: { oxygen: 2, weapons: 2, engines: 2 },
    startWeapons: ['laser_basic'],
    reactorLevel: 8,
    reactorMax: 14,
    weaponSlots: 1,
    cargoCols: 7, cargoRows: 5,
  }),

  /** Three decks and two lift trunks. The side bays on the top deck
   *  start EMPTY and become weapon modules at a station. */
  frigate: buildHull({
    label: 'Horus',
    helmAft: true,                 // update235: the new Aquarius hull — the bridge on top at the stern, a gun socket over every other top module
    builder: 'aquarius',
    spriteKey: 'ship_player',
    hullMax: 30,
    originX: 20, originY: 90, decks: 3, shaftAfter: [0, 1],
    grid: [
      { id:'r_engines',  type:'engines',  col:0, row:0, adjacent:['r_weapons'] },
      { id:'r_weapons',  type:'weapons',  col:1, row:0, adjacent:['r_engines','r_shields'] },
      { id:'r_shields',  type:'shields',  col:2, row:0, adjacent:['r_weapons'] },
      { id:'r_piloting', type:'piloting', col:0, row:1, adjacent:['r_oxygen'] },
      { id:'r_oxygen',   type:'oxygen',   col:1, row:1, adjacent:['r_piloting','r_medbay'] },
      { id:'r_medbay',   type:'medbay',   col:2, row:1, adjacent:['r_oxygen'] },
      { id:'r_crew1',    type:'empty',    col:0, row:2, adjacent:['r_reactor'] },
      { id:'r_reactor',  type:'reactor',  col:1, row:2, adjacent:['r_crew1','r_crew3'] },
      { id:'r_crew3',    type:'empty',    col:2, row:2, adjacent:['r_reactor'] },
    ],
    startSystems: ['engines','weapons','shields','piloting','oxygen','medbay','reactor'],
    systemLevels: { oxygen: 2, shields: 2, weapons: 2, engines: 2 },
    startWeapons: ['laser_basic'],
    reactorLevel: 8,
    reactorMax: 16,
    weaponSlots: 1,
    cargoCols: 6, cargoRows: 4,
  }),

  enemy_frigate: buildHull({
    label: 'Set',
    builder: 'pegasus',
    spriteKey: 'ship_enemy',
    hullMax: 20,
    originX: 20, originY: 90, decks: 2, shaftAfter: [0],
    grid: [
      { id:'r_engines',  type:'engines',  col:0, row:0, adjacent:['r_weapons'] },
      { id:'r_weapons',  type:'weapons',  col:1, row:0, adjacent:['r_engines','r_shields'] },
      { id:'r_shields',  type:'shields',  col:2, row:0, adjacent:['r_weapons'] },
      { id:'r_piloting', type:'piloting', col:0, row:1, adjacent:['r_oxygen'] },
      { id:'r_oxygen',   type:'oxygen',   col:1, row:1, adjacent:['r_piloting','r_reactor'] },
      { id:'r_reactor',  type:'reactor',  col:2, row:1, adjacent:['r_oxygen'] },
    ],
    startSystems: ['engines','weapons','shields','piloting','oxygen','reactor'],
    systemLevels: { oxygen: 2, shields: 2, weapons: 2, engines: 2 },
    startWeapons: ['laser_basic'],
    reactorLevel: 8,
    reactorMax: 12,
    weaponSlots: 1,
  }),

  /** TWO weapon bays — the hull elites favour. */
  enemy_gunship: buildHull({
    label: 'Sobek',
    builder: 'phoenix',
    spriteKey: 'ship_enemy',
    hullMax: 20,
    originX: 20, originY: 90, decks: 2, shaftAfter: [0],
    grid: [
      { id:'r_piloting', type:'piloting', col:0, row:0, adjacent:['r_reactor'] },
      { id:'r_reactor',  type:'reactor',  col:1, row:0, adjacent:['r_piloting','r_engines'] },
      { id:'r_engines',  type:'engines',  col:2, row:0, adjacent:['r_reactor'] },
      { id:'r_weapons',  type:'weapons',  col:0, row:1, adjacent:['r_weapons2'] },
      { id:'r_weapons2', type:'weapons',  col:1, row:1, adjacent:['r_weapons','r_oxygen'] },
      { id:'r_oxygen',   type:'oxygen',   col:2, row:1, adjacent:['r_weapons2','r_shields'] },
      { id:'r_shields',  type:'shields',  col:3, row:1, adjacent:['r_oxygen'] },
    ],
    startSystems: ['engines','weapons','shields','piloting','oxygen','reactor'],
    systemLevels: { oxygen: 2, shields: 2, weapons: 2, engines: 2 },
    startWeapons: ['laser_basic'],
    reactorLevel: 8,
    reactorMax: 14,
    weaponSlots: 2,
  }),

  enemy_raider: buildHull({
    label: 'Anubis',
    builder: 'phoenix',
    spriteKey: 'ship_enemy',
    hullMax: 20,
    originX: 20, originY: 90, decks: 2, shaftAfter: [0],
    grid: [
      { id:'r_weapons',  type:'weapons',  col:0, row:0, adjacent:['r_reactor'] },
      { id:'r_reactor',  type:'reactor',  col:1, row:0, adjacent:['r_weapons','r_engines'] },
      { id:'r_engines',  type:'engines',  col:2, row:0, adjacent:['r_reactor'] },
      { id:'r_shields',  type:'shields',  col:0, row:1, adjacent:['r_piloting'] },
      { id:'r_piloting', type:'piloting', col:1, row:1, adjacent:['r_shields','r_oxygen'] },
      { id:'r_oxygen',   type:'oxygen',   col:2, row:1, adjacent:['r_piloting'] },
    ],
    startSystems: ['engines','weapons','shields','piloting','oxygen','reactor'],
    systemLevels: { oxygen: 2, shields: 2, weapons: 2, engines: 2 },
    startWeapons: ['laser_basic'],
    reactorLevel: 8,
    reactorMax: 12,
    weaponSlots: 1,
  }),

  /* ══ EIGHT NEW HULLS, DRAWN BY THE PLAYER (update95) ═══════════
   *
   * jj sent eight floor plans: blue modules, a green trunk, all on the
   * same five columns — two modules, the lift, two modules. In grid
   * terms that is `shaftAfter: [1]`, columns 0-1 then 2-3, and the
   * top row of each picture is the HIGHEST row here (row 0 is the
   * bottom deck, as it always was).
   *
   * Three are for sale (Thoth, Isis, Osiris), five fly against you.
   * Several have a deck whose outermost module stands against the
   * trunk with nothing past it: the bare side of the trunk is plain
   * plating, not a hatch (his call), and the airlock goes on the other
   * wall. Nephthys has a middle deck that is ONLY the trunk — the
   * cabin rides through it without stopping.
   *
   * Enemy hulls carry no empty bay on purpose: `_seatCaptives` puts a
   * cell block into the first empty bay, and a spare one would quietly
   * raise how often enemies carry prisoners. The eighth room on the
   * bigger ones is a medbay instead. */

  /* THE YARD HULLS ARE NOT FITTED OUT (jj, 03.10). Each comes with the
   * five basics — engines, cockpit, air, reactor, one gun bay — plus ONE
   * extra module, a different one on each, and the rest of the bays
   * bare for the player to fill. The dearest, Osiris, is the warship:
   * its extra is a SECOND gun bay, and it comes with two guns. Each one
   * starts with a different gun, and the hold shrinks as the hull turns
   * into a warship. */

  /** For sale, 280. Extra: a medbay. A burst laser; hold 6x3. */
  thoth: buildHull({
    label: 'Thoth',
    helmAft: true,                 // update235: the new Aquarius hull — the bridge on top at the stern, a gun socket over every other top module
    builder: 'aquarius',
    spriteKey: 'ship_player',
    hullMax: 28,
    originX: 20, originY: 90, decks: 3, shaftAfter: [1],
    grid: [
      { id:'r_weapons',  type:'weapons',  col:1, row:2, adjacent:['r_hold1'] },
      { id:'r_hold1',    type:'empty',    col:2, row:2, adjacent:['r_hold2','r_weapons'] },
      { id:'r_hold2',    type:'empty',    col:3, row:2, adjacent:['r_hold1'] },
      { id:'r_engines',  type:'engines',  col:0, row:1, adjacent:['r_piloting'] },
      { id:'r_piloting', type:'piloting', col:1, row:1, adjacent:['r_engines'] },
      { id:'r_reactor',  type:'reactor',  col:1, row:0, adjacent:['r_oxygen'] },
      { id:'r_oxygen',   type:'oxygen',   col:2, row:0, adjacent:['r_medbay','r_reactor'] },
      { id:'r_medbay',   type:'medbay',   col:3, row:0, adjacent:['r_oxygen'] },
    ],
    startSystems: ['engines','weapons','piloting','oxygen','reactor','medbay'],
    systemLevels: { oxygen: 2, weapons: 2, engines: 2 },
    startWeapons: ['laser_burst'],
    reactorLevel: 8,      // engines 2, gun 2, cockpit 1, air 2, medbay 1
    reactorMax: 16,
    weaponSlots: 1,
    cargoCols: 6, cargoRows: 3,
  }),

  /** For sale, 380. Extra: shields (one layer). A heavy laser; hold 7x4. */
  isis: buildHull({
    label: 'Isis',
    builder: 'pegasus',
    spriteKey: 'ship_player',
    hullMax: 32,
    originX: 20, originY: 90, decks: 3, shaftAfter: [1],
    grid: [
      { id:'r_weapons',  type:'weapons',  col:0, row:2, adjacent:['r_shields'] },
      { id:'r_shields',  type:'shields',  col:1, row:2, adjacent:['r_weapons','r_hold1'] },
      { id:'r_hold1',    type:'empty',    col:2, row:2, adjacent:['r_hold2','r_shields'] },
      { id:'r_hold2',    type:'empty',    col:3, row:2, adjacent:['r_hold1'] },
      { id:'r_piloting', type:'piloting', col:1, row:1, adjacent:['r_hold4'] },
      { id:'r_hold4',    type:'empty',    col:2, row:1, adjacent:['r_piloting'] },
      { id:'r_engines',  type:'engines',  col:0, row:0, adjacent:['r_reactor'] },
      { id:'r_reactor',  type:'reactor',  col:1, row:0, adjacent:['r_engines','r_oxygen'] },
      { id:'r_oxygen',   type:'oxygen',   col:2, row:0, adjacent:['r_hold3','r_reactor'] },
      { id:'r_hold3',    type:'empty',    col:3, row:0, adjacent:['r_oxygen'] },
    ],
    startSystems: ['engines','weapons','shields','piloting','oxygen','reactor'],
    systemLevels: { oxygen: 2, shields: 2, weapons: 2, engines: 2 },
    startWeapons: ['laser_heavy'],
    reactorLevel: 9,      // engines 2, gun 2, shields 2, cockpit 1, air 2
    reactorMax: 18,
    weaponSlots: 1,
    cargoCols: 7, cargoRows: 4,
  }),

  /** For sale, 420 — the warship. Extra: a SECOND gun bay, and both
   *  armed: a heavy laser and a burst laser. Hold 6x4. */
  osiris: buildHull({
    label: 'Osiris',
    builder: 'phoenix',
    spriteKey: 'ship_player',
    hullMax: 34,
    originX: 20, originY: 90, decks: 3, shaftAfter: [1],
    grid: [
      { id:'r_weapons',  type:'weapons',  col:0, row:2, adjacent:['r_weapons2'] },
      { id:'r_weapons2', type:'weapons',  col:1, row:2, adjacent:['r_weapons','r_hold1'] },
      { id:'r_hold1',    type:'empty',    col:2, row:2, adjacent:['r_hold2','r_weapons2'] },
      { id:'r_hold2',    type:'empty',    col:3, row:2, adjacent:['r_hold1'] },
      { id:'r_engines',  type:'engines',  col:0, row:1, adjacent:['r_piloting'] },
      { id:'r_piloting', type:'piloting', col:1, row:1, adjacent:['r_engines'] },
      { id:'r_reactor',  type:'reactor',  col:0, row:0, adjacent:['r_oxygen'] },
      { id:'r_oxygen',   type:'oxygen',   col:1, row:0, adjacent:['r_reactor','r_hold3'] },
      { id:'r_hold3',    type:'empty',    col:2, row:0, adjacent:['r_hold4','r_oxygen'] },
      { id:'r_hold4',    type:'empty',    col:3, row:0, adjacent:['r_hold3'] },
    ],
    startSystems: ['engines','weapons','weapons','piloting','oxygen','reactor'],
    systemLevels: { oxygen: 2, weapons: 2, engines: 2 },
    startWeapons: ['laser_heavy', 'laser_burst'],
    reactorLevel: 10,     // engines 2, two guns 2+2, cockpit 1, air 2
    reactorMax: 20,
    weaponSlots: 2,
    cargoCols: 6, cargoRows: 4,
  }),

  /** Enemy. A C round the lift: a medbay alone on the middle deck. */
  enemy_ra: buildHull({
    label: 'Ra',
    helmAft: true,                 // update235: the new Aquarius hull — the bridge on top at the stern, a gun socket over every other top module
    builder: 'aquarius',
    spriteKey: 'ship_enemy',
    hullMax: 20,
    originX: 20, originY: 90, decks: 3, shaftAfter: [1],
    grid: [
      { id:'r_piloting', type:'piloting', col:1, row:2, adjacent:['r_weapons'] },
      { id:'r_weapons',  type:'weapons',  col:2, row:2, adjacent:['r_shields','r_piloting'] },
      { id:'r_shields',  type:'shields',  col:3, row:2, adjacent:['r_weapons'] },
      { id:'r_medbay',   type:'medbay',   col:1, row:1, adjacent:[] },
      { id:'r_oxygen',   type:'oxygen',   col:1, row:0, adjacent:['r_reactor'] },
      { id:'r_reactor',  type:'reactor',  col:2, row:0, adjacent:['r_engines','r_oxygen'] },
      { id:'r_engines',  type:'engines',  col:3, row:0, adjacent:['r_reactor'] },
    ],
    startSystems: ['engines','weapons','shields','piloting','oxygen','medbay','reactor'],
    systemLevels: { oxygen: 2, shields: 2, weapons: 2, engines: 2 },
    startWeapons: ['laser_basic'],
    reactorLevel: 8,
    reactorMax: 14,
    weaponSlots: 1,
  }),

  /** Enemy, two guns. Two full decks and nothing between them but the
   *  trunk — the cabin rides through the middle without stopping. */
  enemy_nephthys: buildHull({
    label: 'Nephthys',
    helmAft: true,                 // update235: the new Aquarius hull — the bridge on top at the stern, a gun socket over every other top module
    builder: 'aquarius',
    spriteKey: 'ship_enemy',
    hullMax: 20,
    originX: 20, originY: 90, decks: 3, shaftAfter: [1],
    grid: [
      { id:'r_weapons',  type:'weapons',  col:0, row:2, adjacent:['r_piloting'] },
      { id:'r_piloting', type:'piloting', col:1, row:2, adjacent:['r_weapons','r_shields'] },
      { id:'r_shields',  type:'shields',  col:2, row:2, adjacent:['r_weapons2','r_piloting'] },
      { id:'r_weapons2', type:'weapons',  col:3, row:2, adjacent:['r_shields'] },
      { id:'r_medbay',   type:'medbay',   col:0, row:0, adjacent:['r_oxygen'] },
      { id:'r_oxygen',   type:'oxygen',   col:1, row:0, adjacent:['r_medbay','r_reactor'] },
      { id:'r_reactor',  type:'reactor',  col:2, row:0, adjacent:['r_engines','r_oxygen'] },
      { id:'r_engines',  type:'engines',  col:3, row:0, adjacent:['r_reactor'] },
    ],
    startSystems: ['engines','weapons','shields','piloting','oxygen','medbay','reactor'],
    systemLevels: { oxygen: 2, shields: 2, weapons: 2, engines: 2 },
    startWeapons: ['laser_basic'],
    reactorLevel: 8,
    reactorMax: 16,
    weaponSlots: 2,
  }),

  /** Enemy. LUNAR CUSTOMS (update171): a long, heavy cruiser with a
   *  tractor beam on its upper deck. It holds you; it does not chase a
   *  fight. Lots of hull and an armoured skin — winning is not the way
   *  out, breaking the TRACTOR is.
   *  THE LUNAR PATROL (update231): she flies the patrol now (js/patrol.js). */
  customs_cruiser: buildHull({
    label: 'Maat',          // the goddess of order — and of the scales
    helmAft: true,                 // update236: the new Terra hull (GPT) — the bridge on top at the stern, gun sockets
    builder: 'terra',
    spriteKey: 'ship_enemy',
    hullMax: 30,
    armor: 2,
    customs: true,
    originX: 20, originY: 90, decks: 3, shaftAfter: [1],
    grid: [
      { id:'r_piloting', type:'piloting', col:0, row:2, adjacent:['r_tractor'] },
      { id:'r_tractor',  type:'tractor',  col:1, row:2, adjacent:['r_piloting','r_weapons'] },
      { id:'r_weapons',  type:'weapons',  col:2, row:2, adjacent:['r_tractor','r_weapons2'] },
      { id:'r_weapons2', type:'weapons',  col:3, row:2, adjacent:['r_weapons'] },
      { id:'r_shields',  type:'shields',  col:1, row:1, adjacent:['r_medbay'] },
      { id:'r_medbay',   type:'medbay',   col:2, row:1, adjacent:['r_shields'] },
      { id:'r_oxygen',   type:'oxygen',   col:0, row:0, adjacent:['r_reactor'] },
      { id:'r_reactor',  type:'reactor',  col:1, row:0, adjacent:['r_oxygen','r_engines'] },
      { id:'r_engines',  type:'engines',  col:2, row:0, adjacent:['r_reactor'] },
    ],
    startSystems: ['engines','weapons','tractor','shields','piloting','oxygen','medbay','reactor'],
    systemLevels: { oxygen: 2, shields: 2, weapons: 2, engines: 2, tractor: 2 },
    startWeapons: ['laser_basic', 'laser_basic'],
    reactorLevel: 14,     // engines 2, guns 2+2, tractor 2, shields 2, cockpit 1, air 2, one spare
    reactorMax: 18,
    weaponSlots: 2,
  }),

  /** Enemy. A staircase: every deck steps one column along the lift. */
  enemy_khnum: buildHull({
    label: 'Khnum',
    helmAft: true,                 // update236: the new Terra hull (GPT) — the bridge on top at the stern, gun sockets
    builder: 'terra',
    spriteKey: 'ship_enemy',
    hullMax: 20,
    originX: 20, originY: 90, decks: 3, shaftAfter: [1],
    grid: [
      { id:'r_weapons',  type:'weapons',  col:2, row:2, adjacent:['r_engines'] },
      { id:'r_engines',  type:'engines',  col:3, row:2, adjacent:['r_weapons'] },
      { id:'r_shields',  type:'shields',  col:1, row:1, adjacent:['r_reactor'] },
      { id:'r_reactor',  type:'reactor',  col:2, row:1, adjacent:['r_shields'] },
      { id:'r_piloting', type:'piloting', col:0, row:0, adjacent:['r_oxygen'] },
      { id:'r_oxygen',   type:'oxygen',   col:1, row:0, adjacent:['r_piloting'] },
    ],
    startSystems: ['engines','weapons','shields','piloting','oxygen','reactor'],
    systemLevels: { oxygen: 2, shields: 2, weapons: 2, engines: 2 },
    startWeapons: ['laser_basic'],
    reactorLevel: 8,
    reactorMax: 12,
    weaponSlots: 1,
  }),

  /** Enemy. A long upper deck over a short lower one. */
  enemy_hathor: buildHull({
    label: 'Hathor',
    builder: 'pegasus',
    spriteKey: 'ship_enemy',
    hullMax: 20,
    originX: 20, originY: 90, decks: 2, shaftAfter: [1],
    grid: [
      { id:'r_piloting', type:'piloting', col:0, row:1, adjacent:['r_weapons'] },
      { id:'r_weapons',  type:'weapons',  col:1, row:1, adjacent:['r_piloting','r_shields'] },
      { id:'r_shields',  type:'shields',  col:2, row:1, adjacent:['r_engines','r_weapons'] },
      { id:'r_engines',  type:'engines',  col:3, row:1, adjacent:['r_shields'] },
      { id:'r_oxygen',   type:'oxygen',   col:0, row:0, adjacent:['r_reactor'] },
      { id:'r_reactor',  type:'reactor',  col:1, row:0, adjacent:['r_oxygen'] },
    ],
    startSystems: ['engines','weapons','shields','piloting','oxygen','reactor'],
    systemLevels: { oxygen: 2, shields: 2, weapons: 2, engines: 2 },
    startWeapons: ['laser_basic'],
    reactorLevel: 8,
    reactorMax: 12,
    weaponSlots: 1,
  }),

  /** Enemy. Two decks slid one column apart. */
  enemy_montu: buildHull({
    label: 'Montu',
    helmAft: true,                 // update236: the new Terra hull (GPT) — the bridge on top at the stern, gun sockets
    builder: 'terra',
    spriteKey: 'ship_enemy',
    hullMax: 20,
    originX: 20, originY: 90, decks: 2, shaftAfter: [1],
    grid: [
      { id:'r_piloting', type:'piloting', col:1, row:1, adjacent:[] },
      { id:'r_weapons',  type:'weapons',  col:2, row:1, adjacent:['r_engines'] },
      { id:'r_engines',  type:'engines',  col:3, row:1, adjacent:['r_weapons'] },
      { id:'r_shields',  type:'shields',  col:0, row:0, adjacent:['r_oxygen'] },
      { id:'r_oxygen',   type:'oxygen',   col:1, row:0, adjacent:['r_shields','r_reactor'] },
      { id:'r_reactor',  type:'reactor',  col:2, row:0, adjacent:['r_oxygen'] },
    ],
    startSystems: ['engines','weapons','shields','piloting','oxygen','reactor'],
    systemLevels: { oxygen: 2, shields: 2, weapons: 2, engines: 2 },
    startWeapons: ['laser_basic'],
    reactorLevel: 8,
    reactorMax: 12,
    weaponSlots: 1,
  }),

  /* ══ BUNKERS AND MECHS (update94) ═════════════════════════════
   *
   * The plan for the demo, 01.10, and the player's numbers, 02.10:
   *   · ARMOUR — every hit on a module or the hull does 1 less (the
   *     hull bar too); the crew are hurt only when the hit goes THROUGH
   *     (stronger than the plate), and then by half. Only these carry it.
   *   · no shields, and they do not dodge: a bunker sits (`immobile`,
   *     evasion 0), a mech crawls (`slow`, half the evasion);
   *   · engines all the same — they hold the GRAVITY like on any hull
   *     (level 2 here, 3 on the big bunker, so it is not easy to knock off);
   *   · `grounded`: nothing on the ground jumps away — no run for it,
   *     not at 45% hull and not after a quiet minute;
   *   · `isStation` only hides the thrusters and the bow outside.
   * From sector 2, and rarer than ships (game.js, _spawnEnemy). */
  bunker_small: buildHull({
    label: 'Sekhmet',
    builder: 'terra',
    spriteKey: 'ship_enemy',
    hullMax: 24,
    isStation: true, grounded: true, immobile: true, armor: 1,
    originX: 20, originY: 90, decks: 2, shaftAfter: [0],
    grid: [
      { id:'r_weapons',  type:'weapons',  col:0, row:0, adjacent:['r_reactor'] },
      { id:'r_reactor',  type:'reactor',  col:1, row:0, adjacent:['r_weapons','r_weapons2'] },
      { id:'r_weapons2', type:'weapons',  col:2, row:0, adjacent:['r_reactor'] },
      { id:'r_piloting', type:'piloting', col:0, row:1, adjacent:['r_oxygen'] },
      { id:'r_oxygen',   type:'oxygen',   col:1, row:1, adjacent:['r_piloting','r_engines'] },
      { id:'r_engines',  type:'engines',  col:2, row:1, adjacent:['r_oxygen'] },
    ],
    startSystems: ['engines','weapons','piloting','oxygen','reactor'],
    systemLevels: { oxygen: 2, weapons: 2, engines: 2 },
    startWeapons: ['laser_basic'],
    reactorLevel: 10,   // two guns, the helm, air and the drive: 9
    reactorMax: 14,
    weaponSlots: 2,
  }),

  /** A MECH ON TRACKS — a small hull on two great treads (drawn under it). */
  enemy_mech: buildHull({
    label: 'Ptah',
    builder: 'terra',
    spriteKey: 'ship_enemy',
    hullMax: 20,
    isStation: true, grounded: true, slow: true, armor: 1, tracks: true,
    originX: 20, originY: 90, decks: 2, shaftAfter: [0],
    grid: [
      // a turret on top, the wide body below on the treads
      { id:'r_piloting', type:'piloting', col:0, row:1, adjacent:['r_weapons'] },
      { id:'r_weapons',  type:'weapons',  col:1, row:1, adjacent:['r_piloting'] },
      { id:'r_engines',  type:'engines',  col:0, row:0, adjacent:['r_reactor'] },
      { id:'r_reactor',  type:'reactor',  col:1, row:0, adjacent:['r_engines','r_oxygen'] },
      { id:'r_oxygen',   type:'oxygen',   col:2, row:0, adjacent:['r_reactor'] },
    ],
    startSystems: ['engines','weapons','piloting','oxygen','reactor'],
    systemLevels: { oxygen: 2, weapons: 2, engines: 2 },
    startWeapons: ['laser_basic'],
    reactorLevel: 8,
    reactorMax: 12,
    weaponSlots: 1,
  }),

  /** APOPHIS — a STATION, not a ship: no engines hung off the stern,
   *  no bow. Five decks of two bays, ten compartments, one trunk up
   *  the middle. It used to be six decks of 96x60 compartments, which
   *  was the only reason a third module size existed at all. */
  boss_station: buildHull({
    label: 'Apophis',
    builder: 'phoenix',
    spriteKey: 'ship_enemy',
    hullMax: 40,
    /* THE BIG BUNKER (update94): the boss of the third contract stands,
       does not dodge, has no shields and wears armour. Engines at 3. */
    isStation: true, grounded: true, immobile: true, armor: 1,
    originX: 40, originY: 20, decks: 5, shaftAfter: [0],
    grid: [
      { id:'r_engines',  type:'engines',  col:0, row:0, adjacent:['r_medbay'] },
      { id:'r_medbay',   type:'medbay',   col:1, row:0, adjacent:['r_engines'] },
      { id:'r_reactor',  type:'reactor',  col:0, row:1, adjacent:['r_oxygen'] },
      { id:'r_oxygen',   type:'oxygen',   col:1, row:1, adjacent:['r_reactor'] },
      { id:'r_weapons3', type:'weapons',  col:0, row:2, adjacent:['r_shields'] },
      { id:'r_shields',  type:'empty',    col:1, row:2, adjacent:['r_weapons3'] },
      { id:'r_weapons',  type:'weapons',  col:0, row:3, adjacent:['r_weapons2'] },
      { id:'r_weapons2', type:'weapons',  col:1, row:3, adjacent:['r_weapons'] },
      { id:'r_piloting', type:'piloting', col:0, row:4, adjacent:['r_top'] },
      { id:'r_top',      type:'empty',    col:1, row:4, adjacent:['r_piloting'] },
    ],
    startSystems: ['engines','medbay','reactor','oxygen','weapons','piloting'],
    systemLevels: { engines: 3, piloting: 2, oxygen: 2, medbay: 2, weapons: 2 },
    startWeapons: [],
    reactorLevel: 8,
    reactorMax: 20,
    weaponSlots: 3,
  }),
};

/* ── STRUCTURES (update163) ─────────────────────────────────
 * jj: a prison "na podstawie modułów statków, ta sama wielkość, plus
 * winda … taki standard". A place in the world is a HULL — the same
 * modules, lifts, plating and drawing as a ship — but it never flies,
 * is never an enemy and is never sold, so it lives in a book of its own
 * that every list of ships leaves alone. `layoutOf` reads both. */
const STRUCTURE_LAYOUTS = {};
function layoutOf(key) { return SHIP_LAYOUTS[key] ?? STRUCTURE_LAYOUTS[key] ?? null; }

/**
 * The layout a hull is built from, flown by you or at you (update175).
 *
 * A SHAPED hull flown at you is her picture MIRRORED (her bow points
 * left), and a mirrored picture has its windows mirrored: Set's shaft
 * after the first column, Hathor's short lower deck, would land on the
 * wrong side of her. So her ROOMS are mirrored with the picture — the
 * same rooms, the same neighbours, the same doors and lift, each one
 * where the picture has its window. Only with the picture on disk: a
 * hull painted in code is painted round the rooms as they are.
 */
/* THEY RUN, WE CHASE (update215, jj 6.11: "statki wroga obrócone tyłem do nas — uciekają, my gonimy —
   jak w menu głównym"). A ship flown at you faces AWAY now: her stern to you, her bow to the right, the
   way your own hull flies — her picture and her rooms unmirrored, her engines burning at you. Her guns
   still point at you (`gunsFace`), over her stern, as yours do in the title screen's chase. Anything on
   the ground or bolted down — a port, a bunker, a mech, the mothership's station — still faces you.
   `Ship.FOE_AWAY.on` false (the suites before it): every enemy faces you, as before. */
function hullFacesRight(key, isPlayer = true) {
  if (isPlayer) return true;
  if (typeof Ship === 'undefined' || !Ship.FOE_AWAY || !Ship.FOE_AWAY.on) return false;
  const L = layoutOf(key);
  return !!L && !L.isStation && !L.grounded && !L.immobile && !L.structure;
}

function layoutFor(key, isPlayer = true) {
  const L = layoutOf(key);
  if (!L || isPlayer || !HULL_SHAPED[key] || typeof Assets === 'undefined' || !Assets.source
      || Assets.source(HULL_ART.name(key, false)) !== 'file') return L;
  const x0 = Math.min(...L.rooms.map(r => r.x)), x1 = Math.max(...L.rooms.map(r => r.x + r.w));
  return {
    ...L, mirrored: true,
    rooms: L.rooms.map(r => ({ ...r, x: x0 + x1 - r.x - r.w })),
    elevators: (L.elevators ?? []).map(e => ({ ...e, x: x0 + x1 - e.x })),
  };
}

class Ship {
  /**
   * How far ABOVE the floor's walk line the console operator stands.
   *
   * Enough to read as "at the console" and — the part that matters for
   * input — to keep him off the exact middle of the room, so the floor
   * underneath him stays free for module orders. Clicking a crewman
   * always selects that crewman (that is the gesture players reach for
   * most), so ordering crew INTO a manned module means clicking the
   * part of it nobody is standing on. Sitting him high leaves most of
   * the room to click.
   */
  /* 14 → 5 (update120, jj: "obniż załoganta, za wysoko w stosunku do
     konsoli"): the operator stands just behind the side places, at the
     big display, not up on top of a desk. */
  static get OPERATOR_LIFT() { return 5; }

  /** How hard each kind of hit shakes the screen (update126). */
  static get HIT_SHAKE() {
    return { laser: 5, heavy: 7, ion: 3, flak: 4, missile: 8, cannon: 10, torpedo: 12 };
  }

  /** Does this gun's shot go straight through a shield? A property of
   *  the GUN; the old type list is the fallback for a def without it.
   *  receiveHit and the bubble check in Combat ask the same question. */
  static piercesShields(def) {
    return def.pierceShields ?? (def.type === 'missile' || def.type === 'cannon' || def.type === 'beam');
  }

  /** Hand an effect to WeaponArt, if it is there (update126). */
  static _fx(fx) {
    return typeof WeaponArt !== 'undefined' ? WeaponArt.add(fx) : null;
  }

  /**
   * @param {string}  layoutKey  - key into SHIP_LAYOUTS
   * @param {boolean} isPlayer
   * @param {number}  worldX     - ship world X origin
   * @param {number}  worldY     - ship world Y origin
   */
  constructor(layoutKey, isPlayer = true, worldX = 0, worldY = 0) {
    this.layoutKey = layoutKey;
    /* which way she points (update215): yours and a fleeing enemy to the right, the rest to the left */
    this.facesRight = hullFacesRight(layoutKey, isPlayer);
    this.layout    = layoutFor(layoutKey, this.facesRight);      // a shaped hull flown at you is mirrored (update175)
    /* ARMOUR (update94): points taken off every hit on a module and on
       the hull. 0 for everything that flies; bunkers and mechs carry it. */
    this.armor     = this.layout?.armor ?? 0;
    if (!this.layout) throw new Error(`Unknown ship layout: ${layoutKey}`);

    this.isPlayer = isPlayer;
    this.worldX   = worldX;
    this.worldY   = worldY;
    /* HOW CLOSED SHE IS (update118): 0 the cutaway, 1 the roof on.
       A drawing state, never saved — whoever shows the ship sets it. */
    this.roofAlpha = 0;

    this.label    = this.layout.label;
    this.hull     = this.layout.hullMax;
    this.hullMax  = this.layout.hullMax;

    // ── Build rooms ──────────────────────────────────────
    this.rooms = this.layout.rooms.map(cfg => new Room({
      ...cfg,
      x: worldX + cfg.x,
      y: worldY + cfg.y,
    }));

    // ── Build systems — ONE per system-type room ──────────
    // Multiple rooms of the same type (e.g. two 'weapons' modules)
    // each get their OWN independent system instance.
    this.systems = [];
    this.reactor  = new Reactor(this.layout.reactorLevel,
                                this.layout.reactorMax ?? 16);
    this.reactorHeat = 0;           // 0–100 (update92, REACTOR_HEAT_CONFIG)

    this.rooms.forEach(room => {
      if (room.type === 'empty' || !SYSTEM_DEFS[room.type]) return;
      const lvl = room.type === 'reactor'
        ? this.reactor.capacity
        : (this.layout.systemLevels ?? {})[room.type] ?? 1;
      const sys = new ShipSystem(room.type, lvl);
      this.systems.push(sys);

      // Link to room
      room.system = sys;
      this._fitSystemToRoom(sys, room);
    });

    // Link the reactor budget object to its room system —
    // from now on damage to the reactor ROOM = lost power.
    this.reactor.sys = this.getSystem('reactor');

    // Default power allocation
    this._allocateDefaultPower();

    /* ── Weapon mounts — ONE gun per weapon module room ────
     *
     * `weaponCargo` DELETED (update75). It was a bare list of gun keys
     * that weighed nothing, took no space and was drawn nowhere the
     * player could point at — a second warehouse standing beside the
     * grid hold, which already holds boxed guns as ordinary crates.
     *
     * Two lists for one thing drift, and this pair drifted in public:
     * a gun handed over by a surrendering crew went onto the rack and
     * the player never saw it; the station had to push a gun onto the
     * rack, box it, and then splice it back OFF the rack, three lines
     * of reconciliation for one move; and the shop drew the same gun
     * twice, once per list, with buttons to shuffle it between them.
     *
     * There is now exactly one answer to "where is that gun": BOLTED
     * ON, or IN A CRATE IN THE HOLD. */
    this.weapons     = [];

    /* ── The brig's cells. NOT crew, deliberately — see takePrisoner. */
    this.prisoners   = [];

    // ── Cargo hold ──────────────────────────────────────
    // A grid, not a list: salvage has a shape, so hull choice and hold
    // upgrades finally mean something. Sized by the layout. (cargo.js
    // may be absent in a stripped-down test — degrade, do not explode.)
    this.cargo = (typeof CargoGrid !== 'undefined')
      ? new CargoGrid(this.layout.cargoCols ?? 5, this.layout.cargoRows ?? 4)
      : null;

    // Slots = number of weapon MODULE rooms (boss may override upward)
    this.weaponSlots = Math.max(this.weaponRooms.length,
                                this.layout.weaponSlots ?? 0);
    this.layout.startWeapons.forEach((wk, i) => {
      this.installWeapon(wk, i);
    });

    // ── Crew ────────────────────────────────────────────
    this.crew = [];

    // ── Subsystems ──────────────────────────────────────
    this.oxygen   = new OxygenManager();
    this.rooms.forEach(r => this.oxygen.addRoom(r.id));

    this.fires    = new FireManager();
    /* WHAT LIVES IN THE DUCTS (update84): rats and spiders. NOT crew —
       see pests.js for why they were moved out of `this.crew`. */
    this.pests    = [];
    /** The repair bay's drones (update229) — rebuilt from the bay, never saved. */
    this.drones   = [];
    this.breaches = new BreachManager();
    // Expose breaches list directly for compatibility
    Object.defineProperty(this, 'breachesList', {
      get: () => this.breaches.breaches
    });

    // ── Elevators ────────────────────────────────────────
    this.elevators = new ElevatorManager();
    (this.layout.elevators ?? []).forEach(ev => {
      this.elevators.addShaft(ev.id, worldX + ev.x,
        ev.floors.map(fy => worldY + fy));
    });

    // Shafts are air columns: give each one an oxygen cell so open
    // shaft doors equalise O2 between the rooms on either side
    // (replaces the old direct doors that used to cross the shaft).
    this.elevators.shafts.forEach(s => this.oxygen.addRoom(`shaft_${s.id}`, { duct: false }));

    /* The split above ran before there were any lifts to keep power for
       (update90): now that there are, do it again. */
    this._allocateDefaultPower();

    // ── Doors between horizontally adjacent rooms ───────
    // If an elevator shaft sits in the gap between two rooms, they get
    // NO direct door — passage/airflow goes through the shaft's own
    // doors instead (a shaft and a room never share space).
    this.doors = [];
    const donePairs = new Set();
    this.rooms.forEach(room => {
      room.adjacent.forEach(adjId => {
        const other = this.getRoomById(adjId);
        if (!other || other.floor !== room.floor) return;
        const key = [room.id, other.id].sort().join('|');
        if (donePairs.has(key)) return;
        donePairs.add(key);
        if (this._shaftBetween(room, other)) return;   // shaft occupies the gap
        // Door at shared vertical edge, hung on the floor's door line
        const doorX = room.x < other.x ? room.x + room.w : other.x + other.w;
        const doorY = this.floorDoorY(room.floor, room.y + room.h * 0.5);
        // Only if rooms actually touch horizontally
        if (Math.abs((room.x + room.w) - other.x) < 30 ||
            Math.abs((other.x + other.w) - room.x) < 30) {
          this.doors.push(new Door(room.id, other.id, doorX, doorY));
        }
      });
    });

    // Elevator shaft doors — each shaft gets a door on BOTH sides
    // at every floor it serves (shaft is its own vertical module)
    this.elevators.shafts.forEach(shaft => {
      // Hand the shaft the line its doors sit on, so the landing plates
      // and the cabin are drawn level with them instead of a dozen
      // pixels lower on the crew walk line. Presentation only.
      shaft.setDoorYs?.(shaft.floorYs.map(fy =>
        this.floorDoorY(this.floorAtY(fy), fy)));
      // …and how far the hull runs, so the trunk spans the ship exactly
      // rather than by a constant tuned for one deck height.
      shaft.setExtent?.(Math.min(...this.rooms.map(r => r.y)),
                        Math.max(...this.rooms.map(r => r.y + r.h)));
      shaft.floorYs.forEach(fy => {
        // Find rooms adjacent to shaft on this floor (left and right)
        const floorIdx = this.floorAtY(fy);
        const onFloor  = this.rooms.filter(r => r.floor === floorIdx);
        const shaftDoorY = this.floorDoorY(floorIdx, fy);
        onFloor.forEach(room => {
          const touchesLeft  = Math.abs((room.x + room.w) - (shaft.x - shaft.width/2)) < 26;
          const touchesRight = Math.abs(room.x - (shaft.x + shaft.width/2)) < 26;
          if (touchesLeft) {
            this.doors.push(new Door(room.id, `shaft_${shaft.id}`,
              shaft.x - shaft.width/2, shaftDoorY, false));
            this.doors[this.doors.length - 1].shaftSide = 1;    // the trunk is on its right (update226)
          }
          if (touchesRight) {
            this.doors.push(new Door(room.id, `shaft_${shaft.id}`,
              shaft.x + shaft.width/2, shaftDoorY, false));
            this.doors[this.doors.length - 1].shaftSide = -1;   // …on its left
          }
        });
      });
    });

    // Airlocks — one on the outer wall of the leftmost and rightmost
    // room of each floor (FTL-style venting hatches)
    /* …BUT ONLY ON A WALL THAT IS HULL (update95). The new hulls have
       decks whose outermost module sits against a lift trunk, with the
       trunk's far side bare: that wall is the shaft door, not space, and
       an airlock hung there would sit on top of it. The bare side of the
       trunk is plain plating — the player's call. */
    const wallOnShaft = x => this.elevators.shafts.some(s =>
      Math.abs(x - (s.x - s.width / 2)) < 26 || Math.abs(x - (s.x + s.width / 2)) < 26);
    const floors = [...new Set(this.rooms.map(r => r.floor))];
    floors.forEach(f => {
      const onFloor = this.rooms.filter(r => r.floor === f);
      if (!onFloor.length) return;
      const leftmost  = onFloor.reduce((a, r) => r.x < a.x ? r : a);
      const rightmost = onFloor.reduce((a, r) => r.x + r.w > a.x + a.w ? r : a);
      const airY = this.floorDoorY(f, leftmost.y + leftmost.h * 0.5);
      if (!wallOnShaft(leftmost.x)) {
        this.doors.push(new Door(leftmost.id,  null, leftmost.x,               airY, true));
      }
      if (rightmost.id !== leftmost.id && !wallOnShaft(rightmost.x + rightmost.w)) {
        this.doors.push(new Door(rightmost.id, null, rightmost.x + rightmost.w, airY, true));
      }
    });

    // ── In-flight projectiles ───────────────────────────
    this.projectiles = [];

    // ── Visual body = room bounding box ──────────────────
    const _b = this.roomBounds();
    this.spriteW = _b.w + 28;
    this.spriteH = _b.h + 28;

    // Shield visual
    this._shieldPulse = null;
    this._shieldAlpha = 0;

    // Destruction
    this.destroyed    = false;
    this._deathTimer  = 0;
    this._explosionTimer = new Utils.Interval(0.18);
  }

  // ── Accessors ────────────────────────────────────────────

  getSystem(type) { return this.systems.find(s => s.type === type) || null; }
  getRoomById(id) { return this.rooms.find(r => r.id === id) || null; }

  getAdjacentRooms(roomId) {
    const room = this.getRoomById(roomId);
    if (!room) return [];
    return room.adjacent.map(id => this.getRoomById(id)).filter(Boolean);
  }

  /** Elevator shaft standing in the horizontal gap between two rooms, or null */
  _shaftBetween(a, b) {
    if (!this.elevators) return null;
    const left  = a.x < b.x ? a : b;
    const right = a.x < b.x ? b : a;
    return this.elevators.shafts.find(s =>
      s.x >= left.x + left.w && s.x <= right.x) || null;
  }

  /** Both shaft-side doors open at the given room pair's floor? */
  _shaftChannelOpen(shaft, roomA, roomB) {
    const sid  = `shaft_${shaft.id}`;
    const near = (d, room) =>
      d.roomB === sid && d.roomA === room.id &&
      d.y > room.y - 6 && d.y < room.y + room.h + 6;
    const dA = this.doors.find(d => near(d, roomA));
    const dB = this.doors.find(d => near(d, roomB));
    return !!(dA && dB && dA.open && dB.open);
  }

  /**
   * Every same-floor neighbour, each tagged with whether the way in is
   * actually OPEN. Fire uses this (update42).
   *
   * `getOpenAdjacentRooms` below is the strict version and had exactly
   * zero callers: fire.js spread through walls unconditionally, so
   * shutting a door did nothing at all and the doors were decoration in
   * a fire. Heat DOES cross a shut bulkhead — just far more slowly —
   * so fire needs the whole list plus the state of each way through,
   * not a pre-filtered one.
   */
  adjacentThermal(roomId) {
    const room = this.getRoomById(roomId);
    if (!room) return [];
    const openIds = new Set(this.getOpenAdjacentRooms(roomId).map(r => r.id));
    return (room.adjacent ?? [])
      .map(id => this.getRoomById(id))
      .filter(r => r && r.floor === room.floor)
      .map(r => ({ room: r, open: openIds.has(r.id) }));
  }

  /** Adjacent rooms reachable through OPEN doors (fire spread uses this) */
  getOpenAdjacentRooms(roomId) {
    const room = this.getRoomById(roomId);
    if (!room) return [];
    return room.adjacent
      .map(id => this.getRoomById(id))
      .filter(r => {
        if (!r) return false;
        // Different floor — no door, fire cannot spread vertically
        if (r.floor !== room.floor) return false;
        const door = this.doors.find(d =>
          (d.roomA === roomId && d.roomB === r.id) ||
          (d.roomB === roomId && d.roomA === r.id));
        if (door) return door.open;
        // Rooms separated by an elevator shaft: fire crosses only
        // when BOTH shaft doors on this floor are open.
        const shaft = this._shaftBetween(room, r);
        if (shaft) return this._shaftChannelOpen(shaft, room, r);
        return true;  // genuinely touching, no door = open corridor
      });
  }

  /** Which floor index is at world Y? Returns -1 if outside */
  floorAtY(wy) {
    let best = -1, bestDist = Infinity;
    this.rooms.forEach(r => {
      if (wy >= r.y - 10 && wy <= r.y + r.h + 10) {
        const d = Math.abs(r.cy - wy);
        if (d < bestDist) { bestDist = d; best = r.floor; }
      }
    });
    return best;
  }

  /** Canonical door centre-line for a floor.
   *  EVERY hatch on a floor — interior, elevator and airlock — hangs
   *  here. Each door used to take the centre of whichever room spawned
   *  it, so rooms of different heights pushed their doors to different
   *  levels and the outer airlocks sat visibly off from the interior
   *  doors on every hull in the game. */
  floorDoorY(floorIndex, fallbackY = 0) {
    const roomsOnFloor = this.rooms.filter(r => r.floor === floorIndex);
    if (!roomsOnFloor.length) return fallbackY;
    /* The middle of the DOORWAY, which is the middle of the walkable
       compartment and not of the module (update73) — a hatch does not
       run up into the ceiling duct any more than a man does. Still
       deliberately a different line from `floorWalkY`: movement goes
       by the feet, doors and the lift cabin are drawn by this one,
       and confusing the two is the "empty trunk lower than the doors"
       bug from update34. */
    /* ON THE DECK (update120): the doorway stands on the same floor the
       crew stand on — its sill at their boots — now that the walk line
       came down. Centred in the compartment it hung over their feet. */
    const top = Math.min(...roomsOnFloor.map(r => r.floorTop));
    const DH = (typeof ElevatorShaft !== 'undefined') ? ElevatorShaft.DOOR_H : Door.H;
    return top + (HULL_GRID.MODULE_H - HULL_GRID.VENT_H) * HULL_GRID.WALK_FRAC
               + HULL_GRID.FEET - DH / 2;
  }

  /* ── WHERE A MODULE SITS IN ITS ROOM (update73) ───────────
   *
   * Three copies of these six lines stood in this file — the hull
   * builder and both of the refit paths. Once the duct arrived all
   * three needed the same correction, which is three chances to
   * correct two of them. One method now.
   *
   * A system occupies the room's INTERIOR. The duct along the ceiling
   * is not part of the compartment, and the first screenshot of this
   * package showed exactly why it matters: the module badge was drawn
   * at `room.y + 3`, which is now inside the grille, so O₂ read as a
   * letter hidden behind a vent.
   */
  _fitSystemToRoom(sys, room) {
    sys.roomId = room.id;
    sys.roomX  = room.x;
    sys.roomY  = room.floorTop;
    sys.roomW  = room.w;
    sys.roomH  = room.floorH;
    sys.cx     = room.cx;
    sys.cy     = room.floorTop + room.floorH / 2;
    sys.yard   = artYard(this.layoutKey);         // whose colours its picture is in (update120; 227: the set it has)
  }

  /** Walking Y line for a floor (crew feet level).
   *
   *  Reads `walkOffset()` — the SAME function the lift stops are built
   *  from. It used to carry its own `0.65` written out longhand, which
   *  was the second copy of a number the grid already owned. */
  floorWalkY(floorIndex, fallbackY = 0) {
    const roomsOnFloor = this.rooms.filter(r => r.floor === floorIndex);
    if (!roomsOnFloor.length) return fallbackY;
    return roomsOnFloor[0].y + walkOffset();
  }

  get shieldBars() {
    const ss = this.getSystem('shields');
    return ss ? ss.shieldBars : 0;
  }

  get shieldMax() {
    const ss = this.getSystem('shields');
    return ss ? ss.shieldMax : 0;
  }

  get evasion() {
    const pilot = this.getSystem('piloting');
    const eng   = this.getSystem('engines');

    // FTL rule: no pilot in cockpit = no evasion at all. `alive` is the
    // one liveness test used throughout here — the old code mixed
    // `!dead && !dying` for the gate with a bare `!dead` for the bonus,
    // so a crewman bleeding out on the cockpit floor still flew the ship.
    const pilotRoom = pilot ? this.getRoomById(pilot.roomId) : null;
    // crewOperating: our own pilot, and only while nobody is fighting
    // him for the chair.
    const hasPilot = pilotRoom ? this.crewOperating(pilotRoom.id).length > 0 : false;
    if (!hasPilot) return 0;
    // A bunker does not dodge (update94).
    if (this.layout?.immobile) return 0;

    const pilotPct = pilot ? pilot.effectivePower() * Ship.EVADE_PILOT  : 0;
    // a dry He2 tank: the drive is dead, it gives nothing (update203)
    const engPct   = eng && !(typeof Tanks !== 'undefined' && Tanks.dry?.(this)) ? eng.effectivePower() * Ship.EVADE_ENGINE : 0;
    const cloak    = this.getSystem('cloaking');
    // Cloak now gives a big evasion spike ONLY while actively cloaked.
    const cloakPct = (cloak && cloak.cloakActive) ? 0.60 : 0;

    // ── Crew skill bonuses ──
    // The pilots at the helm, AND the engine gang keeping the drive
    // responsive. Engine crew have always EARNED engines XP on every
    // dodge (see receiveHit) and CrewMember.engineBonus() has always
    // existed — but nothing ever called it, so levelling Engines paid
    // out exactly nothing in evasion. Terra crews even get double
    // engines XP, which made the dead end worse. The loop is closed now.
    // ONE pilot at the helm, ONE engineer at the drive console
    // (update43) — a crowded cockpit no longer stacks evasion.
    const helm     = this.consoleOperator(pilotRoom.id);
    const skillPct = helm ? helm.pilotBonus() : 0;
    const engRoom  = eng ? this.getRoomById(eng.roomId) : null;
    const engHand  = engRoom ? this.consoleOperator(engRoom.id) : null;
    const engSkill = engHand ? engHand.engineBonus() : 0;

    /* A COMMANDER'S ORDER, while it is running (update53). It goes
       through Commander.orderBonus like every other "what is the boss
       worth right now" question, and it is INSIDE the same clamp as
       everything else — an order that could push evasion past the cap
       would be a different rule for one source, which is how caps stop
       meaning anything. Only OUR hull: the accessor answers for the
       active commander, and the enemy has his own. */
    const order = (this.isPlayer && typeof Commander !== 'undefined'
                   && Commander.orderBonus) ? Commander.orderBonus('evasion') : 0;
    /* …and a running tablet (update99: the Golden Ratio), inside the
       same clamp for the same reason. Ours only — the enemy reads none. */
    const tablet = (this.isPlayer && typeof Chips !== 'undefined' && Chips.runningValue)
      ? Chips.runningValue('evasion') : 0;

    const cap = (cloak && cloak.cloakActive) ? 0.9 : 0.75;
    // A mech crawls (update94): half of what a ship would make of it.
    const slow = this.layout?.slow ? 0.5 : 1;
    return Utils.clamp((pilotPct + engPct + cloakPct + skillPct + engSkill + order + tablet) * slow,
                       0, cap);
  }

  /**
   * WHAT THE COCKPIT AND THE ENGINES EACH ADD TO EVASION (update120) —
   * the two shares `evasion` sums, before the cap, for their displays.
   * No pilot at the helm: both are 0, because the ship does not dodge.
   */
  evasionShares() {
    const pilot = this.getSystem('piloting'), eng = this.getSystem('engines');
    const pilotRoom = pilot ? this.getRoomById(pilot.roomId) : null;
    const hasPilot = pilotRoom ? this.crewOperating(pilotRoom.id).length > 0 : false;
    if (!hasPilot || this.layout?.immobile) return { hasPilot, cockpit: 0, engines: 0 };
    const crawl = this.layout?.slow ? 0.5 : 1;   // a mech
    const helm = this.consoleOperator(pilotRoom.id);
    const engRoom = eng ? this.getRoomById(eng.roomId) : null;
    const engHand = engRoom ? this.consoleOperator(engRoom.id) : null;
    return {
      hasPilot,
      cockpit: ((pilot ? pilot.effectivePower() * Ship.EVADE_PILOT : 0) + (helm ? helm.pilotBonus() : 0)) * crawl,
      engines: ((eng ? eng.effectivePower() * Ship.EVADE_ENGINE : 0) + (engHand ? engHand.engineBonus() : 0)) * crawl,
    };
  }

  /** Our chance to hit `foe` with a shot now (update120): his evasion, the other way round. */
  hitChanceOn(foe) {
    if (!foe) return null;
    const cl = foe.getSystem?.('cloaking');
    if (cl && cl.cloakActive) return 0;
    return Utils.clamp(1 - (foe.evasion ?? 0), 0, 1);
  }

  get hullPct() { return this.hull / this.hullMax; }

  // ── Crew helpers ─────────────────────────────────────────

  addCrew(member, keepPosition = false) {
    // Never add the same member twice (boarding recovery could
    // otherwise duplicate crew on the roster).
    if (this.crew.includes(member)) return;
    if (keepPosition) {
      // Caller already placed x/y/roomId precisely (e.g. a boarder
      // storming into the room they just breached) — don't scramble it.
      member.targetX = member.x;
      member.targetY = member.y;
      this.crew.push(member);
      return;
    }
    // Place each crew member in a different room (cycle through rooms)
    const idx  = this.crew.length % this.rooms.length;
    const room = this.rooms[idx] || this.rooms[0];
    if (room) {
      const [sx, sy] = this.stationSpot(room);
      member.x = sx;
      member.y = sy;
      member.roomId = room.id;
      // A recruit with no station never settles anywhere and reads as
      // "broken" to the player — give them the room they walked into.
      if (!member.homeRoomId) member.homeRoomId = room.id;
    } else {
      member.x = this.worldX + 100;
      member.y = this.worldY + 100;
    }
    member.targetX = member.x;
    member.targetY = member.y;
    this.crew.push(member);
  }

  /**
   * Assign home stations by priority:
   * cockpit → engines → shields → weapons → oxygen → medbay.
   * Prefers crew whose corporation matches the module.
   */
  assignStations() {
    // Weapons need a live OPERATOR per module now — stations cover
    // piloting first, then EVERY weapon room, then the rest.
    const prefer = { piloting:'pegasus', engines:'terra', shields:'aquarius', weapons:'phoenix' };
    // The cat does not stand watches — nor does a passenger (update162).
    const unassigned = this.crew.filter(c => !c.dead && !c.isPet && !c.isPassenger);
    const posts = [];
    const pilot = this.getSystem('piloting');
    if (pilot?.roomId) posts.push({ type:'piloting', roomId: pilot.roomId });
    this.weaponRooms.forEach(r => posts.push({ type:'weapons', roomId: r.id }));
    ['shields','engines','oxygen','medbay'].forEach(t => {
      const sys = this.getSystem(t);
      if (sys?.roomId) posts.push({ type: t, roomId: sys.roomId });
    });

    /* WHO GETS THE CONSOLE (update43).
       Since only the operator at slot 0 supplies the module's bonus,
       picking by CORPORATION alone would sit a Phoenix rookie at the
       gun while a mastered Aquarius gunner stood behind him doing
       nothing. Rank by the skill the post actually uses, and keep the
       corporation preference as the tiebreak it was always meant to
       be — a Terra crew still gravitates to the engine room. */
    const POST_SKILL = { piloting: 'piloting', engines: 'engines',
                         shields: 'shields',   weapons: 'weapons' };
    posts.forEach(post => {
      if (!unassigned.length) return;
      const skill = POST_SKILL[post.type];
      let idx = 0, bestScore = -1;
      unassigned.forEach((cand, i) => {
        const lvl   = skill ? cand.getSkillLevel(skill) : 0;
        const score = lvl * 10 + (cand.race === prefer[post.type] ? 1 : 0);
        if (score > bestScore) { bestScore = score; idx = i; }
      });
      const c = unassigned.splice(idx, 1)[0];
      const room = this.getRoomById(post.roomId);
      // Ask which SPOT is free, not how many heads are in there. The
      // head count once handed the first man into an empty module the
      // LEFT flank (because setting homeRoomId first counted him as an
      // occupant of his own room) and left the console unmanned.
      c.homeRoomId = post.roomId;
      if (room) c.moveToOnShip(this, ...this.stationSpot(room, null, c));
    });
  }

  /**
   * STARTING POSTS CHOSEN BY THE PLAYER (update113).
   *
   * jj: drop a man on a room in the loadout and that is where he starts.
   * `posts` is { crewId: roomId }. Applied AFTER assignStations, so the
   * automatic pass still mans every console nobody chose for; a posted
   * man walks to his room and takes a free place there. A room that is
   * already full of men the player did not move takes as many as fit —
   * the rest keep their automatic post rather than being left nowhere.
   * Returns how many men were posted.
   */
  applyPosts(posts) {
    if (!posts) return 0;
    const byRoom = new Map();
    this.crew.forEach(c => {
      if (!c || c.dead || c.isPet || !c.isPlayer) return;
      const rid = posts[c.id];
      const room = rid != null ? this.getRoomById(rid) : null;
      if (!room) return;
      if (!byRoom.has(room.id)) byRoom.set(room.id, { room, movers: [] });
      byRoom.get(room.id).movers.push(c);
    });
    let n = 0;
    byRoom.forEach(({ room, movers }) => {
      const free = this.roomSpaceFor(room.id, true, movers);
      const go = movers.slice(0, free);
      const picks = this.allocStationSlots(room, go);
      go.forEach((c, i) => {
        c.homeRoomId = room.id;
        c.moveToOnShip(this, ...this.stationSlot(room, picks[i]));
        n++;
      });
    });
    return n;
  }

  /**
   * Where a crew member should STAND in a room.
   *
   *      empty room   →  the console, dead centre and a little high
   *      one already  →  the newcomer takes the LEFT of him
   *      two already  →  the third takes the RIGHT
   *
   * That order matters: walking into an empty module and standing off
   * to one side of the console looked like the man had missed his post,
   * which is why hitting RETURN (which sends everyone to room.cx/cy)
   * always "looked right" and ordinary orders did not.
   *
   * The old comment here warned that a crewman on the exact centre
   * swallowed every click aimed at the module. That was true when the
   * pick radius was 20px around a point 14px above his head; the
   * operator now stands OPERATOR_LIFT pixels above the walk line, up at
   * the console, which leaves the whole lower half of the room clear
   * for module clicks.
   */
  stationSpot(room, forCrew = null) {
    /* THE HEAD-COUNT BRANCH IS GONE (update79). This used to take an
       `occupants` number and answer `min(occupants, 2)` — a second way
       of picking a spot, by counting people instead of asking which
       spots are held. Nothing had called it with a number for many
       packages; both callers passed null and fell through to the line
       below. An unreachable second answer to a question that already
       has one is worse than no code, because the next person to read
       it believes there are two ways to place a man. */
    return this.stationSlot(
      room, this.freeStationSlot(room, forCrew ? [forCrew] : [],
                                 forCrew ? forCrew.isPlayer : this.isPlayer));
  }

  /**
   * HOW MANY PEOPLE FIT IN A MODULE, and it is per SIDE (update79).
   *
   * There used to be two answers to this and they disagreed. At home
   * the count filtered on `alive` alone, so two boarders standing in
   * your medbay meant you could send ONE medic — the intruders ate
   * your places. On the enemy hull the very same rule filtered on
   * `isPlayer`, so three of yours could walk into a room that already
   * held four defenders. Two rules, written out by hand at two click
   * sites, and the player met both of them in one fight.
   *
   * One rule now, and it is the player's: THREE A SIDE. A module holds
   * three of yours and three of theirs — six men in a brawl — and
   * neither side can lock the other out by standing there.
   *
   * Downed bodies do not count. A room with three wounded on its floor
   * used to read as full and silently refused every repair order, which
   * is how a breached, shot-out module could look unfixable.
   */
  roomSpaceFor(roomId, side, exclude = []) {
    /* AND A CAT IS NOT ONE OF THE THREE (update83). This counted every
       living body on the side, so the ship's cat sitting in the engine
       room cost you a mechanic. `takenStationSlots` — the other half of
       the same question, "who is holding a place in here" — has
       excluded animals since update43, so the two halves of one rule
       disagreed: the cat blocked an order without ever holding a spot
       for it. She has no station and no console; she does not take a
       place at one. */
    const here = this.crew.filter(c =>
      c && c.alive && !c.isPet && c.isPlayer === side && !exclude.includes(c) &&
      (c.roomId === roomId || c.homeRoomId === roomId)).length;
    return Math.max(0, Ship.ROOM_SLOTS - here);
  }

  /** Standing spots per side in one module. The one number. */
  static get ROOM_SLOTS() { return 3; }

  /** The i-th standing spot in a room: 0 = console, 1 = left, 2 = right. */
  stationSlot(room, i = 0) {
    const slot = [0, -1, 1][Utils.clamp(i, 0, Ship.ROOM_SLOTS - 1)];
    const x = Utils.clamp(room.cx + slot * 26, room.x + 14, room.x + room.w - 14);
    const y = this.floorWalkY(room.floor, room.cy)
            - (slot === 0 ? Ship.OPERATOR_LIFT : 0);
    return [x, y];
  }

  /** How close to a slot counts as standing on it. */
  static get SLOT_GRIP() { return 13; }

  /**
   * Which of the three standing spots in `room` is a crewman on (or
   * heading for)? -1 if he is somewhere else in the room entirely.
   */
  slotIndexAt(x, y, room, tol = Ship.SLOT_GRIP) {
    let best = -1, bd = tol;
    for (let i = 0; i < Ship.ROOM_SLOTS; i++) {
      const [sx, sy] = this.stationSlot(room, i);
      const d = Math.hypot(x - sx, y - sy);
      if (d < bd) { bd = d; best = i; }
    }
    return best;
  }

  /**
   * The set of spots in `room` that are spoken for.
   *
   * "Spoken for" means somebody is standing on it OR walking to it —
   * see CrewMember.destPoint. Counting heads instead of spots is what
   * used to stack crew: the count said "one man in here, you take slot
   * 1", but that man might himself be standing on slot 1 because the
   * room was busier when HE was sent.
   *
   * @param {Room} room
   * @param {CrewMember[]} exclude  people whose claim does not count
   * @param {boolean} residentsOnly  count only crew POSTED to this room —
   *        used to decide whether a stack is real. Somebody merely
   *        crossing the room stands in the way (so you do not walk into
   *        him) but he never owns the console and never evicts anyone.
   */
  takenStationSlots(room, exclude = [], residentsOnly = false,
                    side = this.isPlayer) {
    const taken = new Set();
    if (!room) return taken;
    this.crew.forEach(c => {
      if (!c.alive || c.isPet || exclude.includes(c)) return;
      /* A MAN COMPETES FOR SPOTS ONLY WITH HIS OWN SIDE (update79).
         This had no side filter at all, so an intruder standing on the
         console HELD slot 0 against your own crew — your gunner was
         shoved onto the flank of his own bay by the man who came to
         kill him. Now that six can share a module the filter is not
         cosmetic: without it the two sides would have three places
         between them and the loser of the race would stand nowhere. */
      if (c.isPlayer !== side) return;
      if (residentsOnly && c.homeRoomId !== room.id) return;
      // Only people who belong in, or are inside, this room can hold a
      // spot in it — somebody in another room is irrelevant.
      if (c.roomId !== room.id && c.homeRoomId !== room.id) return;
      const p = c.destPoint ? c.destPoint() : { x: c.x, y: c.y };
      const i = this.slotIndexAt(p.x, p.y, room);
      if (i !== -1) taken.add(i);
    });
    return taken;
  }

  /**
   * The best FREE spot in `room`: the console first, then the left
   * flank, then the right. Falls back to the right flank when all
   * three are held (the room is full and the caller should have
   * stopped earlier).
   */
  freeStationSlot(room, exclude = [], side = this.isPlayer) {
    const taken = this.takenStationSlots(room, exclude, false, side);
    for (let i = 0; i < Ship.ROOM_SLOTS; i++) if (!taken.has(i)) return i;
    return Ship.ROOM_SLOTS - 1;
  }

  /**
   * Hand out one free spot per crew member, in order.
   *
   * This is the ONLY correct way to place several people into the same
   * module at once: each pick has to see the picks made before it, or
   * the whole group lands on the console together.
   *
   * @returns {number[]} slot index per member of `movers`
   */
  allocStationSlots(room, movers = []) {
    /* A group order is always one side's, so the side is read off the
       men being moved rather than passed in as a fourth argument
       nobody would remember to give. */
    const side = movers.length ? movers[0].isPlayer : this.isPlayer;
    const taken = this.takenStationSlots(room, movers, false, side);
    return movers.map(() => {
      let i = 0;
      while (i < Ship.ROOM_SLOTS - 1 && taken.has(i)) i++;
      taken.add(i);
      return i;
    });
  }

  /**
   * OUR crew, able, in this room.
   *
   * The `isPlayer === this.isPlayer` filter is the important half and it
   * was missing entirely. `this.crew` holds everyone physically aboard —
   * including enemy boarders, who are added to the DEFENDING ship's
   * roster when they come through the airlock. Without the filter an
   * intruder standing in your weapons bay MANNED YOUR GUN, one in the
   * shield room sped up YOUR recharge and earned YOUR shields XP, one in
   * the medbay was healed by YOUR doctors, and one in the cockpit added
   * his piloting skill to YOUR evasion.
   */
  crewInRoom(roomId) {
    // Only fully-able crew count for manning/repairs — the downed
    // and the dead lie on the floor (see bodiesInRoom).
    return this.crew.filter(c =>
      c.roomId === roomId && c.alive && c.inRoom !== false &&
      c.isPlayer === this.isPlayer);
  }

  /**
   * A battle is beginning aboard this hull.
   *
   * Done HERE rather than in markCombatStart because CombatManager.begin
   * is the one place every fight passes through exactly once, for both
   * ships — game.js calls markCombatStart from three different places
   * and would have counted some battles twice.
   */
  /** After a fight (update242): every door ends where its mode says — an airlock not opened by hand shut — and
   *  no lock is anybody's but ours. */
  settleDoors() {
    (this.doors ?? []).forEach(d => {
      d._tempT = 0; d.hackT = 0; d.resetHacks?.();
      if (d.breached) return;
      const shut = d.isAirlock ? d.mode !== 'open' : d.mode === 'closed';
      if (shut) { d.openness = 0; d.open = false; }
    });
  }

  onBattleStart() {
    // Every lock is a stranger's lock again: boarders work for the ship
    // a second time rather than strolling through last fight's holes.
    this.doors.forEach(d => d.resetHacks?.());
    // And everyone still standing has one more action on their record.
    this.crew.forEach(c => { if (c.alive) c.battles = (c.battles ?? 0) + 1; });
  }

  /** EVERYONE physically in the room, whoever's side they are on.
   *  Weapons fire, stun and fire burns do not care whose uniform you
   *  are wearing — only manning does. */
  occupantsOf(roomId) {
    return this.crew.filter(c => c.roomId === roomId && c.alive && c.inRoom !== false);
  }

  /** Hostiles from both sides sharing a room: nobody is working. */
  roomContested(roomId) {
    const here = this.occupantsOf(roomId);
    return here.some(c => c.isPlayer) && here.some(c => !c.isPlayer);
  }

  /**
   * Who is actually OPERATING the module in this room.
   *
   * A module with a fight going on in it is not being run: the crew are
   * swinging at each other, not flying the ship. A contested cockpit
   * gives no evasion, a contested weapons bay stops charging, contested
   * shields stop recharging — which is what makes boarding a way to shut
   * a ship down rather than only a way to chip at its hull.
   */
  /**
   * THE PEOPLE WORKING THIS MODULE.
   *
   * Empty for a CONTESTED room, and — since update45 — never the
   * cat. She is OURS, so the side check does not keep her out, and a
   * cat that mans the gun is not a joke the player would enjoy twice.
   */
  crewOperating(roomId) {
    if (this.roomContested(roomId)) return [];
    /* AND NOT A MAN WHOSE HANDS ARE FULL (update78). The busy clock
       is new and for one package nothing read it: a gunner could eat
       a ration and still be the gunner, a medic could be kneeling
       over a casualty and still be piloting. Standing in the room was
       the whole test, so "busy" was a word in the panel and nothing
       in the fight.
       This is the one place that answers "who is WORKING here", so it
       is the one place that has to know. The cost falls out of it
       everywhere at once — the gun goes quiet, the cyborg's +1 drops,
       the console mark leaves his row — because all three ask this. */
    return this.crewInRoom(roomId).filter(c => !c.isPet && !c.busy && !c.isPassenger);   // a passenger on the bridge is not its pilot (update162)
  }

  /**
   * WHO A POWERED MEDBAY TREATS (update54).
   *
   * Not `crewOperating` — that answers "who is WORKING here", and it
   * throws out the animals so the cat cannot man a gun. A medbay is
   * not a console: lying on the table is not a job, and the ship's cat
   * bleeds like everybody else. It used to be the only creature aboard
   * that could not be patched up anywhere, on the ship or at a station.
   *
   * The contested check stays, and it is the same one: a compartment
   * being fought over is not treating anybody. That is the ship-side
   * half of "the fight comes first, the bandages come after".
   *
   * Side is already settled by `crewInRoom`, so enemy boarders standing
   * in your medbay are not healed by it — and vermin, being nobody's
   * crew, are not either.
   */
  medbayPatients(roomId) {
    if (this.roomContested(roomId)) return [];
    /* ABLE AND DOWN ALIKE (update78). This returned `crewInRoom`,
       which is the ABLE only — so the one function in the file named
       for "who a powered medbay treats" left out the casualties lying
       on its floor, and the healing loop had to ask `bodiesInRoom`
       instead and therefore never touched anybody on his feet.
       Two lists, each missing half the patients, and between them the
       medbay could not do the job it is bought for. */
    return this.crew.filter(c =>
      c && !c.dead && c.roomId === roomId && c.inRoom !== false &&
      c.isPlayer === this.isPlayer);
  }

  /**
   * WHO IS ACTUALLY AT THE CONSOLE (update43).
   *
   * Every skill bonus a module grants — gunnery, shields, piloting,
   * engines — used to be the SUM over everyone standing in the room.
   * Three mastered gunners came to 0.9 and were stopped only by the
   * 0.75 clamp, which exists to keep `dt / 0` from killing the frame.
   * So the strongest move in the game was to shove three people into
   * one compartment: nobody designed that, and the player could not
   * see it. A module has ONE console (slot 0, the raised spot), and
   * the man sitting at it is the one working it.
   *
   * The other two in the room are not useless — they fight boarders,
   * put out fires and repair the module — they just do not make the
   * gun charge faster.
   *
   * Returns null for an empty or CONTESTED room, exactly like
   * crewOperating(), so an invaded compartment stops paying out.
   */
  consoleOperator(roomId) {
    const room = this.getRoomById(roomId);
    if (!room) return null;
    const manned = this.crewOperating(roomId);
    if (!manned.length) return null;
    return manned.find(c => this.slotIndexAt(c.x, c.y, room) === 0) || null;
  }

  /* SIDE MATTERS FOR BODIES TOO (update42). This used to return every
     downed body in the room regardless of whose it was, which is how
     your crew ended up stretchering enemy boarders to your medbay and
     your medbay healed them back onto their feet — mid-boarding. Pass
     `false` only where you genuinely mean "everyone lying here". */
  bodiesInRoom(roomId, ownSideOnly = true) {
    return this.crew.filter(c =>
      c.roomId === roomId && c.down && c.inRoom !== false &&
      (!ownSideOnly || c.isPlayer === this.isPlayer));
  }

  /** Called by Game whenever a new battle begins: unburied corpses
   *  start to ROT — and rotting corpses spread the plague. */
  markCombatStart() {
    this.crew.forEach(c => {
      if (!c.dead) return;
      c._deadCombats = (c._deadCombats ?? 0) + 1;
      if (c._deadCombats >= 1 && !c.decaying) {
        this._startDecay(c);
      }
    });
  }

  _startDecay(c) {
    if (c.decaying) return;
    c.decaying = true;
    if (this.isPlayer && typeof UI !== 'undefined') {
      UI.notify(c.isPlayer === this.isPlayer
        ? `${c.name}'s body is DECAYING — eject it or bag it.`
        : 'An enemy body is DECAYING on our deck — eject it or bag it.', 'alert');
    }
  }

  /* ══ WHAT TO DO WITH A BODY (update65) ═════════════════════
   *
   * Three answers, and the player gives them. The machinery that
   * carries people around is untouched — what changed is who decides
   * where a corpse goes. `bodyOrder` is that decision and the ONLY
   * thing that moves a dead man off the deck.
   */

  /** Can this body be treated / vented / bagged right now, and if not,
   *  why not? ONE function, so the menu greys exactly what the order
   *  would refuse — a button that looks live and then does nothing is
   *  the bug this shape exists to prevent. */
  bodyRefusal(body, act) {
    if (!body) return 'nobody there';
    if (act === 'treat') {
      if (body.dead) return 'he is dead';
      const med = this.getSystem('medbay');
      if (!med) return 'no medbay aboard';
      return null;
    }
    /* ── THE MEDKIT (update78) ────────────────────────────────
     * The one way to get a man back on his feet on a hull with no
     * medbay — which is most hulls, and both of the ones the player
     * starts in. It costs supplies, not a module. */
    if (act === 'medkit') {
      if (body.dead) return 'he is dead';
      if (!body.down && body.hp >= body.maxHp) return 'he is not hurt';
      if (!this.hasDoses(Ship.MEDKIT_DOSES)) {
        return `not enough medical supplies (needs ${Ship.MEDKIT_DOSES}, `
             + `you have ${this.doseCount()})`;
      }
      return null;
    }
    if (act === 'eject') {
      if (!body.dead) return 'he is still alive';
      /* NOT "is a hatch open" any more (update68) — the man carrying
         him opens one. The only thing that can refuse a burial now is
         a hull with no airlock at all. */
      if (!this.doors.some(d => d.isAirlock)) return 'no airlock on this hull';
      return null;
    }
    if (act === 'bag') {
      if (!body.dead) return 'he is still alive';
      /* NOT "is somebody standing there" any more (update68). The order
         SENDS a man, exactly like every other order on this ship — the
         player's words: "jeżeli mamy zaznaczonego załoganta i najedziemy
         na trupa i damy bag lub vent to on to zrobi niezależnie w którym
         jest module". What can still refuse it is having nobody free to
         send, and a hold with no room in it. */
      const hands = this.crew.some(c =>
        c && c.alive && c.isPlayer === this.isPlayer && !c.carrying);
      if (!hands) return 'nobody free to do it';
      if (!this.cargo) return 'no hold';
      const probe = CargoGrid.deserialise(this.cargo.serialise());
      if (!probe.add(Ship.bagKeyFor(body))) return 'no room in the hold';
      return null;
    }
    return 'unknown order';
  }

  /**
   * A BOARDER IN THE CELL BLOCK LETS THEM OUT (update72).
   *
   * No order, no button: walking in IS the rescue. Anything else would
   * be a second decision on top of the one the player already made —
   * he sent people across a vacuum to a hull with a brig on it, which
   * is the decision.
   *
   * What a freed man becomes is the trick that keeps this small: he
   * turns into one of OURS, standing on THEIR hull. The recovery that
   * brings a boarding party home already sweeps up every `isPlayer`
   * crewman left on the enemy ship, so the ride home, the docking, the
   * barracks and the report are all machinery that already exists. He
   * is not cargo, not a passenger list and not a second register —
   * he is a man on a deck, like everybody else in this game.
   */
  freeCaptives() {
    /* ONE GUARD, and it is `_breakingOut` — a man who has just kicked
       his own cell door open is not waiting to be rescued. An
       `isPlayer` early-out on top of it read as belt and braces and
       was really a mask: it made this filter unreachable on the only
       hull where the difference matters. */
    /* …and not a man still in a slab (update93): he is in no room, so
       nobody is standing with him. The bay has to let him go first. */
    const held = this.crew.filter(c => c.isPrisoner && c.alive && !c._breakingOut && !c.frozen);
    if (!held.length) return 0;
    let freed = 0;
    held.forEach(p => {
      const saviour = this.crew.find(c =>
        c.isPlayer && c.alive && !c.isPet && c.roomId === p.roomId);
      if (!saviour) return;
      p.isPrisoner = false;
      p.isPlayer   = true;
      p.rescued    = true;
      /* HIS OWN NAME AND HIS OWN CORPORATION. He was drawn in hostile
         red while he was theirs; the moment he is ours he is drawn as
         one of ours, because that is what he is. */
      if (p.race === 'hostile' && typeof CORP_KEYS !== 'undefined') {
        p.race = Utils.pick(CORP_KEYS);
      }
      p.homeRoomId = p.roomId;
      freed++;
      if (typeof UI !== 'undefined') {
        UI.notify(`${saviour.name} got the cell open — ${p.name} is with us.`, 'good');
      }
    });
    return freed;
  }

  /**
   * WHAT A LOOSE PRISONER DOES (update72).
   *
   * On somebody ELSE'S hull — an enemy's cell — nothing at all: he
   * waits to be found. On OURS he is a man who has just got the cell
   * door open, and the player's own decision was that he does not
   * fight: "uciekinier NIE WALCZY — biegnie do śluzy i ucieka".
   *
   * So: the nearest airlock, and out. He walks there like anybody
   * else, which is the whole point — a closed door stops him, and a
   * player who is watching can trap him in a compartment and have him
   * put back. That is why this is a WALK and not the line of text it
   * used to be: text cannot be interrupted.
   */
  _prisonerWalk(c, dt) {
    if (!c || !c.alive) return;
    if (!c._breakingOut) return;           // somebody else's prisoner: he sits
    const air = this.doors.filter(d => d.isAirlock)
      .sort((a, b) => Utils.dist(c.x, c.y, a.x, a.y) -
                      Utils.dist(c.x, c.y, b.x, b.y))[0];
    if (!air) return;                      // no way off this hull; he waits
    /* ── HE IS "THERE" WHEN HE IS IN THE AIRLOCK'S ROOM ───────
     *
     * Not "within 24 pixels of the hatch": an airlock is bolted to a
     * WALL, and the crew step-inside rule nudges anybody who reaches
     * one back into the compartment — so a radius around the door
     * turned into a man bouncing in and out of it, picking the lock
     * for one frame in thirteen and never finishing. The room he is
     * standing in does not flicker. */
    if (c.roomId === air.roomA || Utils.dist(c.x, c.y, air.x, air.y) < 24) {
      /* ── HE WORKS THE OUTER LOCK, LIKE ANY INTRUDER ─────────
       *
       * Not a free exit. He got the CELL open, so he can get this one
       * open too — but it costs him the same `Door.HACK_TIME` a
       * boarding party pays for a strange door, and that is the time
       * the player was promised: shut the hatch in his face and you
       * have seconds to get a hand to him and put him back.
       *
       * The same lock, the same clock, the same side ('enemy' — he is
       * not ours while he is running): no second mechanic for a door
       * that already knows how to be picked. */
      if (air.mode === 'open' && air.open) {
        this._prisonerGone(c);
      } else if (air.hackBy('enemy', dt)) {
        air.mode = 'open'; air.open = true;
      }
      return;
    }
    if (!c._waypoints?.length) c.moveToOnShip?.(this, air.x, air.y);
  }

  /** Off the hull for good — and back onto the board if he was on it. */
  _prisonerGone(c) {
    this.crew = this.crew.filter(k => k !== c);
    /* THE BOARD IS WRITTEN HERE, and only here — the moment he is off
       the hull. A man still walking the corridor has not escaped yet,
       and the update67 version wrote the poster the instant the cell
       door opened, which is why trapping him could never have meant
       anything. A prisoner who was never on the board goes up for the
       first time; `reWanted` has always known how to do both. */
    let poster = null;
    if (this.isPlayer && typeof Save !== 'undefined' && Save.reWanted) {
      poster = Save.reWanted({ wantedId: c.wantedId ?? null, name: c.name,
                               bounty: c.bounty, level: c.level, race: c.race });
    }
    /* A CONVICT GOT AWAY (update163): his transport has failed, now. */
    if (this.isPlayer && c.jobId && typeof Base !== 'undefined' && Base.convictGone) Base.convictGone(c.jobId);
    if (this.isPlayer && typeof UI !== 'undefined') {
      UI.notify(poster
        ? `${c.name} is out the airlock and away — back on the board at ${poster.bounty} CC.`
        : `${c.name} is out the airlock and away.`, 'alert');
    }
    return poster;
  }

  /**
   * PUT HIM BACK (update72).
   *
   * The other half of making the escape a walk: a player who shut a
   * door in his face has caught him, and catching him has to be worth
   * something. One free cell and a powered brig, and he goes back in —
   * the same `takePrisoner` the fight uses, so a man re-taken is worth
   * exactly what he was worth before.
   */
  /**
   * WHAT THE BAY ITSELF SAYS NO TO — the half of the question that is
   * the same whoever is going in: is there a bay, is it lit, is there
   * a slab left.
   *
   * Written once (update77). `cellRefusal` and `freezeRefusal` had
   * three identical lines each; the first time one of them gained a
   * condition the two would have started answering differently about
   * the same module, which is the whole reason a convict and a
   * crewman spend the SAME capacity.
   */
  _slabRefusal() {
    const pod = this.getSystem('carbonite');
    if (!pod) return 'no carbonite bay on this hull';
    /* `isDisabled()` DELETED from here (update77). Since capacity is
       min(levels, power), a dark bay has no slabs at all — so that
       check could never be the reason any more and the player was
       being told "every slab is taken" about a module with nothing in
       it. The capacity is the honest question, and it answers for a
       shot-out bay and a browned-out one with the same sentence. */
    if (this.carboniteCapacity() <= 0) return 'the carbonite bay is cold — no power';
    if (this.freeCells() <= 0) return 'every slab is taken';
    return null;
  }

  cellRefusal(c) {
    if (!c || !c.isPrisoner || !c.alive) return 'nobody to lock up';
    return this._slabRefusal();
  }

  returnToCell(c) {
    const why = this.cellRefusal(c);
    if (why) return { ok: false, message: `Cannot jail: ${why}.` };
    const ok = this.takePrisoner({
      id: c.wantedId ?? c.id, name: c.name, bounty: c.bounty ?? 0,
      wantedId: c.wantedId ?? null, jobId: c.jobId ?? null, race: c.race, level: c.level,
    });
    if (!ok) return { ok: false, message: 'No free cell.' };
    this.crew = this.crew.filter(k => k !== c);
    return { ok: true, message: `${c.name} is back in the cell.` };
  }

  /** A cat is one cell, a man is two. Same tag, so one rule at the
   *  dock covers both — only the shape differs. */
  static bagKeyFor(body) { return body && body.isPet ? 'pet_bag' : 'body_bag'; }

  /**
   * Give the order. Returns {ok, message} like every other order in
   * this game, and refuses out loud rather than doing nothing.
   */
  orderBody(body, act, doer = null) {
    const why = this.bodyRefusal(body, act);
    if (why) return { ok: false, message: `Cannot ${act}: ${why}.` };

    /* WHO DOES IT. The man the player has selected, if he is fit for
       it; otherwise the nearest free hand. Every other order on this
       ship works that way and the player asked for this one to as
       well — before update68 BAG simply refused unless somebody
       already happened to be standing over the body. */
    const pick = (doer && doer.alive && doer.isPlayer === this.isPlayer &&
                  !doer.carrying && doer !== body)
      ? doer
      : this.crew.filter(c => c && c.alive && c.isPlayer === this.isPlayer &&
                              !c.carrying && c !== body)
          .sort((a, b) => Utils.dist(a.x, a.y, body.x, body.y) -
                          Utils.dist(b.x, b.y, body.x, body.y))[0];

    if (act === 'bag') {
      /* Already over him? Do it now. Otherwise walk him over and the
         ship finishes the job when he arrives. */
      if (pick && pick.roomId === body.roomId) return this._bagBody(body);
      if (!pick) return { ok: false, message: 'Nobody free to do it.' };
      body.bodyOrder = 'bag';
      pick._bagTargetId  = body.id;
      pick._errandRoomId = body.roomId;
      pick.moveToOnShip?.(this, body.x, body.y);
      return { ok: true, message: `${pick.name} is going for ${body.name}.` };
    }

    body.bodyOrder = act;
    /* AND HE WALKS. Setting the claim without sending him was the whole
       reason VENT looked dead in update67: the man was assigned and
       stayed exactly where he stood, because the only code that moved
       anybody was the automatic dispatch for bodies nobody was near. */
    if (pick) {
      pick._rescueId     = body.id;
      pick._errandRoomId = body.roomId;
      pick.moveToOnShip?.(this, body.x, body.y);
    }
    return { ok: true, message: act === 'treat'
      ? `${body.name} — stretcher on the way.`
      : `${pick ? pick.name : 'A hand'} is carrying ${body.name} to the airlock.` };
  }

  /* ══ THE ENEMY PLAYS BY THE SAME RULES (update93) ══════════
   *
   * The player's list, point 18: "wróg gra według tych samych zasad
   * (apteczki, ranni)". Everything that carries, bandages, doses and
   * vents already worked for both hulls — what the enemy never had was
   * somebody to GIVE the orders the player gives through the body menu.
   * This is that somebody, and it gives nothing but those orders:
   *
   *   • a man of theirs on the floor gets a MEDKIT while the hull has
   *     two doses and no lit ward (a lit ward is fetched to by the
   *     dispatch on its own, as on ours);
   *   • a man of theirs who is dead goes out the airlock after
   *     `AI_VENT_SECONDS` — no name, no bag, no burial; nobody on a
   *     pirate hull is bringing anybody home.
   *
   * Only the order is new. Who walks, who kneels, which hatch opens,
   * the doses spent and the time it takes are the same lines that do
   * it for the player, so the two sides cannot drift apart. */
  static get AI_VENT_SECONDS() { return 8; }

  /* ONE COUNTER, ticked by anything that hurts the player's side: a
     landed shot (`receiveHit`) and a blow from one of theirs
     (`CrewMember.strike`). Combat only compares it with the value it
     saw last, so nothing has to be reset between fights. */
  static noteHarmToPlayer() { Ship._harmToPlayer = (Ship._harmToPlayer ?? 0) + 1; }
  static harmToPlayer() { return Ship._harmToPlayer ?? 0; }

  _aiBodyOrders(dt) {
    if (this.isPlayer || this.isDerelict || this.isPreview) return;
    const own = c => c && c.isPlayer === this.isPlayer && !c.isPet && !c.isPrisoner &&
                     !c.frozen && !c.ejected;
    const ward = this._wardIsOpen();
    const airlock = this.doors.some(d => d.isAirlock);
    this.crew.forEach(c => {
      if (!own(c) || c.carriedBy) return;
      /* The box ran dry with the order still on him: withdraw it, or
         the medic sent for it would stand over him for good. */
      if (c.bodyOrder === 'medkit' && !this.hasDoses(Ship.MEDKIT_DOSES)) c.bodyOrder = null;
      if (c.dead) {
        /* ONLY A FREE HAND CARRIES HIM OUT (update93a). The player:
           "wróg wyrzuca ciało tylko wtedy, kiedy ma wolnego załoganta,
           tak jakby szedł naprawiać czy gasić pożar". So the AI picks
           the man the way it picks a repairer — idle, not the pilot,
           not the last gunner — and sends HIM; nobody else touches the
           body (the pickup below asks for his claim on this hull). No
           free hand, no burial: he lies there, and rots. */
        if (!airlock || !(c.decaying || (c._rotT ?? 0) >= Ship.AI_VENT_SECONDS)) return;
        if (this.crew.some(k => k && k.alive && k._rescueId === c.id)) return;
        const hand = this._aiFreeHand(c);
        if (!hand) return;
        c.bodyOrder = 'eject';
        hand._rescueId     = c.id;
        hand._errandRoomId = c.roomId;
        hand.moveToOnShip?.(this, c.x, c.y);
        return;
      }
      if (c.bodyOrder) return;
      if (c.down && !ward && this.hasDoses(Ship.MEDKIT_DOSES)) c.bodyOrder = 'medkit';
    });
  }

  /** A man the enemy can spare for an errand: the same rule its combat
   *  AI uses for a repair (combat.js, pickBest) — idle, not in the
   *  cockpit, not the last man on a gun, not already carrying or sent
   *  somewhere. Nearest to `near` first. */
  _aiFreeHand(near) {
    const pilotRoom = this.getSystem('piloting')?.roomId ?? null;
    const gunRooms = (this.weaponRooms ?? []).map(r => r.id);
    const gunners = this.crew.filter(k => k && k.alive && k.isPlayer === this.isPlayer &&
                                           gunRooms.includes(k.roomId));
    const lastGunner = gunners.length === 1 ? gunners[0] : null;
    return this.crew.filter(k => k && k.alive && k.isPlayer === this.isPlayer &&
        !k.isPet && !k.isPrisoner && !k.frozen && !k.carrying && !k._rescueId &&
        !k._bagTargetId && !k.stunned && k.task === TASK.IDLE &&
        k.roomId !== pilotRoom && k !== lastGunner && k !== near)
      .sort((a, b) => Utils.dist(a.x, a.y, near.x, near.y) - Utils.dist(b.x, b.y, near.x, near.y))[0] ?? null;
  }

  /* ── THE BITE AND THE EGG, BOTH ON A CLOCK (update69) ──────
   *
   * This used to live in game.js and fire once per WON FIGHT, which
   * made the whole thing a between-battles bookkeeping step: a man
   * could not turn at the gun, and an egg could not hatch in the
   * middle of a boarding action. The player asked for exactly that —
   * "czas jest liczony tylko podczas kontraktu, tak aby to moglo sie
   * stac w kazdym momencie walki".
   *
   * It lives HERE because this is the only clock that runs when the
   * ship is flying and stops when she is docked: the base does not
   * update the hull, so a contract is precisely the time that counts.
   * No second timer, no "are we in a run" flag to get out of step.
   */
  infectionTick(dt) {
    if (!this.isPlayer) return;

    // ── the bitten ──
    this.crew.forEach(c => {
      /* THE CLOCK STOPS IN THE SLAB (update77) — and it is a STOP, not
         a reset: `virusT` is left exactly where it stood, so he comes
         out as ill as he went in. Carbonite does not cure anybody. It
         buys the time to reach somewhere that can. */
      if (!c || !c.isPlayer || c.dead || c.frozen || !c.virus) return;
      const before = c.virusT ?? VIRUS_SECONDS;
      c.virusT = before - dt;
      // One warning at the halfway mark and one near the end — a line
      // every second would bury the log it is trying to warn from.
      [VIRUS_SECONDS / 2, 60].forEach(mark => {
        if (before > mark && c.virusT <= mark && typeof UI !== 'undefined') {
          UI.notify(`${c.name} is getting worse — ${Math.round(mark)}s left. `
                  + 'A research post can still cure it.', 'warn');
        }
      });
      if (c.virusT > 0) return;
      this._hatchFrom(c);
    });

    // ── the eggs ──
    (this.cargo?.items ?? []).filter(it => it.def?.tag === 'egg').forEach(egg => {
      const m = (egg.meta && typeof egg.meta === 'object') ? egg.meta : null;
      if (!m) { egg.meta = { hatchT: EGG_SECONDS }; return; }
      m.hatchT = (m.hatchT ?? EGG_SECONDS) - dt;
      if (m.hatchT > 0) return;
      this._splitEgg(egg);
    });
  }

  /**
   * HE DOES NOT LEAVE A BODY (update69).
   *
   * The old version killed him where he stood and then ALSO put an egg
   * in the hold, so the player had a corpse to bury and a case to sell
   * out of one man — "jak sie zamieni w jajko to nie ma ciala, znika".
   * There is one of him: what is left is the case.
   *
   * The memorial still gets his name, with the note that says what
   * happened to him, because the one thing worse than no gravestone is
   * a gravestone that cannot explain itself.
   */
  _hatchFrom(c) {
    const egg = this.cargo?.add('spider_egg', {
      name: c.name,
      /* WHERE HE FELL. The drawing reads this, so the case the player
         can see in the duct and the case in his hold are ONE item —
         sell it, or let the cat at it, and it is gone from both. */
      roomId: c.roomId,
      x: c.x,
      hatchT: EGG_SECONDS,
    });
    c.virus = false;
    c.hp = 0;
    c.state = 'dead';
    c.dead = true;
    /* THE NOTE ON THE STONE (update69). The memorial already prints
       "killed by …", so what happened to him goes THERE rather than
       into a field of its own — the player asked for "na cmentarzu
       tylko notatka co sie stalo, male info", and a second column for
       one sentence would be a register to keep in step for nothing. */
    c.killedBy = 'the void-spider virus — he left an egg case';
    c._waypoints = [];
    if (typeof Save !== 'undefined' && !c._graved) {
      Save.addToGraveyard?.(c);
      c._graved = true;
    }
    /* OFF THE DECK, NOT ONTO IT. `bagged` is the same flag a body bag
       uses: it says "he is no longer a thing lying in a room", which
       is what keeps the corpse rules, the airlock and the stretcher
       crew from finding a man who is not there any more. */
    c.bagged = true;
    this.crew = this.crew.filter(k => k !== c);
    if (typeof UI !== 'undefined') {
      UI.notify(egg
        ? `${c.name} did not make it — there is an egg case where he fell.`
        : `${c.name} did not make it, and the hold had no room for what came out of him.`,
        'alert');
    }
    return !!egg;
  }

  /** The case splits and they are loose aboard. */
  _splitEgg(egg) {
    const m = (egg.meta && typeof egg.meta === 'object') ? egg.meta : {};
    this.cargo.remove(egg);
    const home = this.getRoomById(m.roomId) ||
                 Utils.pick(this.rooms.filter(r => r.system)) || this.rooms[0];
    const n = Utils.randInt(1, 4);            // 1..3
    /* INTO THE DUCT IT WAS LYING IN (update84). They used to be dropped
       on the deck as hostile crew; the case is in the duct now, and so
       is what comes out of it. */
    for (let i = 0; i < n; i++) {
      this.addPest(new Pest({
        kind: 'spider', roomId: home?.id ?? null,
        x: home ? Utils.clamp((m.x ?? home.cx) + Utils.randFloat(-14, 14),
                              home.x + Pest.EDGE, home.x + home.w - Pest.EDGE) : 0,
      }));
    }
    if (typeof UI !== 'undefined') {
      UI.notify(`The egg case split open — ${n} spider${n > 1 ? 's' : ''} in the ducts!`,
                'alert');
    }
    if (typeof Audio !== 'undefined') Audio.sfx?.bossWarning?.();
    return n;
  }

  /** A man sent to bag a body finishes the job when he gets there. */
  bagArrivals() {
    this.crew.forEach(c => {
      if (!c || !c._bagTargetId || !c.alive) return;
      const body = this.crew.find(b => b && b.id === c._bagTargetId);
      if (!body || !body.dead) { c._bagTargetId = null; return; }
      if (c.roomId !== body.roomId) return;
      c._bagTargetId  = null;
      c._errandRoomId = null;
      const r = this._bagBody(body);
      if (!r.ok && this.isPlayer && typeof UI !== 'undefined') {
        UI.notify(r.message, 'warn');
      }
    });
  }

  /**
   * Bag him where he lies. No walk: the order already required a hand
   * in the room, so the man doing it is standing over the body — and
   * inventing a second carry destination for a job that happens on the
   * spot would have been a road with nothing at the end of it.
   */
  _bagBody(body) {
    /* ONE OF THEIRS (update93): a grave without a name. Not his name
       (nobody aboard knows it), not a bounty (nobody posted one) and
       not `crewBody` (he is not ours) — the dock buries him unmarked. */
    const theirs = body.isPlayer !== this.isPlayer;
    const it = this.cargo.add(Ship.bagKeyFor(body), theirs
      ? { name: 'Unknown', enemyBody: true, bounty: 0 }
      : {
      name: body.name,
      crewId: body.id,
      /* HIS OWN, not a bounty. The dock reads this to tell a man
         brought home for burial from a man brought in for money —
         one item, one rule at the till, two reasons to be in it. */
      crewBody: true,
    });
    if (!it) return { ok: false, message: 'No room in the hold.' };
    if (theirs) {
      body.bagged = true;
      this.crew = this.crew.filter(c => c !== body);
      if (this.isPlayer && typeof UI !== 'undefined') {
        UI.notify('An enemy body is bagged — he gets a grave without a name.', 'good');
      }
      return { ok: true, message: 'Enemy body bagged.' };
    }
    /* OFF THE DECK HERE, not by way of the `ejected` flag. Setting that
       would hand him to the airlock cleanup in `_updateBodies`, which
       would announce "body committed to space" over a man who is
       safely in the hold — and charge the venting karma for it. */
    body.bagged = true;
    this.crew = this.crew.filter(c => c !== body);
    if (this.isPlayer && typeof UI !== 'undefined') {
      UI.notify(`${body.name} is bagged and stowed. He comes home.`, 'good');
    }
    return { ok: true, message: `${body.name} bagged.` };
  }

  /** Is there anywhere to actually put a corpse right now?
   *  You cannot throw a body through a shut hatch (update42). */
  hasOpenAirlock() {
    return this.doors.some(d => d.isAirlock && d.mode === 'open');
  }

  /** Carry the wounded to the medbay, carry the dead to an airlock,
   *  rot unburied corpses onto the crew, remove the ejected. */
  _updateBodies(dt) {
    // Remove anyone who went out the airlock (self-ejected plague
    // victims and committed corpses alike) — the roster entry goes.
    const ejected = this.crew.filter(c => c.ejected);
    ejected.forEach(c => {
      if (c.carriedBy) c.carriedBy.carrying = null;
      if (this.isPlayer && typeof UI !== 'undefined') {
        UI.notify(c.dead ? (c.isPlayer === this.isPlayer ? `${c.name}'s body committed to space.`
                                                         : 'An enemy body is out the airlock.') :
                           `${c.name} walked out of the airlock…`, c.dead ? 'info' : 'alert');
      }
      /* ── THE PRICE OF THE AIRLOCK (update65) ────────────────
       *
       * Only for a body the player ORDERED out, and only his own
       * people — `bagged` men never come through here, and a plague
       * victim who walked out on his own is not a decision anybody
       * made. Karma is for what you do to those who cannot answer,
       * and this is the cheapest way to be rid of one of your own.
       */
      /* ONLY OUR OWN (update93): an enemy corpse thrown out of our
         airlock is a boarder, not a crewman denied his grave. */
      if (this.isPlayer && c.isPlayer && c.dead && c.bodyOrder === 'eject' &&
          typeof Commander !== 'undefined' && Commander.active && Commander.active()) {
        Commander.shift(Commander.active(), Ship.EJECT_KARMA);
        if (typeof UI !== 'undefined') {
          UI.notify(`No burial for ${c.name}. (${Ship.EJECT_KARMA} karma)`, 'warn');
        }
      }
      Particles.emit?.({ x: c.x, y: c.y, vx: this.isPlayer ? -60 : 60, vy: -10,
        ay: 0, color: '#aaccee', size: 3, sizeEnd: 0, life: 1, alpha: 0.8, alphaEnd: 0 });
    });
    if (ejected.length) this.crew = this.crew.filter(c => !c.ejected);

    const medbay = this.getSystem('medbay');
    const medRoom = medbay ? this.getRoomById(medbay.roomId) : null;

    const medPowered = medbay && medRoom && medbay.effectivePower() > 0;

    const medUsable = !!medRoom && !!medPowered;

    /* ── ROT IS A CLOCK NOW (update42) ────────────────────────
       Decay used to be a COMBAT COUNTER: a corpse only began to rot at
       the start of the NEXT fight. Combined with the pickup rule below
       — which hauled a corpse to the airlock the instant anybody walked
       into the room — that meant a body was always gone long before it
       could rot, and the entire plague subsystem never fired once in a
       real game. A corpse left aboard now starts to stink on its own. */
    this.crew.forEach(c => {
      if (!c.dead || c.decaying || c.ejected) return;
      c._rotT = (c._rotT ?? 0) + dt;
      if (c._rotT >= Ship.DECAY_SECONDS) this._startDecay(c);
    });

    /* ── BLEEDING OUT (update42) ─────────────────────────────
       A downed crew member used to lie there indefinitely. That was a
       soft-lock: the last enemy standing goes DOWN instead of dying,
       nobody on his ship is left to treat him, and the fight can never
       end. Being down is now a countdown — save them, or lose them. */
    this.crew.forEach(c => {
      if (c.dead || !c.down) { if (c._bleedT) c._bleedT = 0; return; }
      /* A BANDAGED MAN IS NOT ON A CLOCK ANY MORE (update78). He is
         still down, still helpless and still one hit from dead — he
         has simply stopped running out of time. */
      if (c._bandaged) { c._bleedT = 0; return; }
      /* AND NEITHER IS A MAN ON THE TABLE. A powered medbay is
         treatment; a clock that kept running while the ward worked on
         him would have been the ward losing a race against its own
         patient. Found by the test that carries a casualty across the
         ship: he arrived, and died on the table with the bay lit. */
      if (this._wardIsOpen() && c.roomId === this.getSystem('medbay')?.roomId) {
        c._bleedT = 0; return;
      }
      /* THE SHIP'S CAT SITS WITH HIM (update45). It cannot treat a
         wound — it is a cat — but a body somebody is beside is a body
         somebody notices, and the clock runs slower while it is there.
         40 s becomes about 66. This is what an animal does on the
         nine jumps out of ten when there are no rats to hunt. */
      const vigil = (typeof CAT_TUNING !== 'undefined' && this.petVigilOver(c))
        ? CAT_TUNING.VIGIL_FACTOR : 1;

      /* THE CLOCK IS STAMPED WHEN HE FALLS (update49). The Golden Hour
         chip that lengthened it went with the chips (update99); the
         stamp stays, so anything that lengthens it later is read once,
         on the first tick of the count. */
      if (!(c._bleedT > 0)) c._bleedMax = Ship.BLEEDOUT_SECONDS;
      c._bleedT = (c._bleedT ?? 0) + dt * vigil;
      if (c._bleedT >= (c._bleedMax ?? Ship.BLEEDOUT_SECONDS)) {
        c._bleedT = 0;
        c.killOutright?.();
        if (this.isPlayer && typeof UI !== 'undefined') {
          UI.notify(`${c.name} bled out.`, 'alert');
        }
      }
    });

    const airOpen = this.hasOpenAirlock();

    /* THE ENEMY GIVES ITS OWN ORDERS (update93) — the same orders the
       player gives with the body menu, so everything below carries them
       out exactly as it does for ours. */
    this._aiBodyOrders(dt);

    // ── RESCUE DISPATCH ──────────────────────────────────────
    // Pickup below only ever triggers for a body in the SAME room, so a
    // crew member who went down somewhere else just bled out while the
    // rest of the ship carried on (the enemy pilot ignoring his downed
    // gunner). Send the nearest able hand to them — to carry them to a
    // medbay if the ship has one, or to patch them up on the spot if it
    // doesn't (most enemy hulls carry no medbay at all).
    {
      // Drop stale claims first (target rescued, dead or already lifted)
      this.crew.forEach(c => {
        if (!c._rescueId) return;
        const t = this.crew.find(b => b.id === c._rescueId);
        // A claim on a DECAYING corpse is a body-collection order and is
        // valid precisely because the target is dead (update42).
        const corpseRun = !!t && t.dead && t.bodyOrder === 'eject';
        /* ── THE JOB IS DONE WHEN THE BLEEDING STOPS (update78) ──
         *
         * The claim used to be released when the man GOT UP, which
         * was the only outcome field aid had. A bandage leaves him on
         * the floor, so that condition never came true and the medic
         * stood over him for the rest of the contract — his console
         * empty, his post forgotten. Found by the test that watches a
         * stretcher-bearer go back to work.
         *
         * A stretcher order (`treat`) and a medkit order are still
         * jobs, so they keep the claim; a plain bandage is finished. */
        const stillWanted = !!t && (t.bodyOrder === 'treat' || t.bodyOrder === 'medkit');
        const patched = !!t && t._bandaged && !stillWanted;
        if (!t || patched || (!corpseRun && (t.dead || !t.down)) || t.carriedBy || !c.alive) {
          c._rescueId = null;
          /* AND HIS POST IS HIS AGAIN (update69). The errand room is
             cleared with the claim that created it, so the moment the
             job is off him the idle walk below takes him back to the
             console he was assigned to. */
          c._errandRoomId = null;
        }
      });

      /* AND SOMEONE GOES TO FETCH A ROTTING BODY (update42).
         Corpse collection was purely opportunistic — a body was only
         ever lifted by somebody who happened to already be standing in
         its room — so a corpse in a compartment nobody visits rotted
         forever and the only cure was to walk a crew member there by
         hand. Opening an airlock is now an ORDER: it sends a hand to
         carry the thing out. */
      /* update65: the order is VENT, not the open hatch. Same dispatch,
         and it no longer waits for the body to start rotting either —
         the player has already said what he wants done. */
      this.crew.forEach(body => {
        if (this.isPlayer && body.dead && body.bodyOrder === 'eject' && !body.carriedBy &&
            !this.crew.some(c => c._rescueId === body.id) &&
            this.crewInRoom(body.roomId).length === 0) {
          const hand = this.crew
            .filter(c => c.alive && !c.carrying && !c._rescueId && !c.isPet && !c.isPassenger &&
                         c.isPlayer === this.isPlayer &&
                         c.task !== TASK.REPAIR && c.task !== TASK.BREACH &&
                         c.task !== TASK.FIRE && c.task !== TASK.FIGHT)
            .sort((a, b) => Utils.dist(a.x, a.y, body.x, body.y) -
                            Utils.dist(b.x, b.y, body.x, body.y))[0];
          if (hand) {
            hand._rescueId     = body.id;
            hand._errandRoomId = body.roomId;
            hand.moveToOnShip(this, body.x, body.y);
          }
          return;
        }
        if (body.dead || !body.down || body.carriedBy) return;
        /* ── A BANDAGED MAN IS NOT AN EMERGENCY (update78) ─────
         *
         * The dispatch sends a hand to anybody who is DOWN, and with
         * field aid a man stopped being down as soon as he was
         * treated. He stays down now, so without this the ship sent
         * somebody to him again the moment the last one walked away —
         * for ever, one man permanently off his post per casualty.
         * Caught by the test that watches a stretcher-bearer go back
         * to his gun.
         *
         * A stretcher (`treat`) or a medkit is still a job worth
         * crossing the ship for, and so is a WORKING MEDBAY: that is
         * the only thing aboard that makes him whole, so a hull that
         * has one keeps fetching him. A hull that has not, and a man
         * who has stopped bleeding, is a man who can wait. */
        const wardOpen = !!medRoom && medPowered;
        if (body._bandaged && body.bodyOrder !== 'treat'
            && body.bodyOrder !== 'medkit' && !wardOpen) return;
        // Nobody runs across the ship to rescue an enemy boarder (update42).
        if (body.isPlayer !== this.isPlayer || body.isPet) return;
        if (body.roomId === medRoom?.id && medPowered) return;  // already being treated
        if (this.crewInRoom(body.roomId).length > 0) return;    // someone's there already
        if (this.crew.some(c => c._rescueId === body.id)) return;

        const helper = this.crew
          .filter(c => c.alive && !c.carrying && !c._rescueId &&
                       c.isPlayer === this.isPlayer && !c.isPet &&
                       c.task !== TASK.REPAIR && c.task !== TASK.BREACH &&
                       c.task !== TASK.FIRE && c.task !== TASK.FIGHT)
          .sort((a, b) => Utils.dist(a.x, a.y, body.x, body.y) -
                          Utils.dist(b.x, b.y, body.x, body.y))[0];
        if (!helper) return;
        helper._rescueId     = body.id;
        helper._errandRoomId = body.roomId;  // walk there; pickup/field aid takes over
        helper.moveToOnShip(this, body.x, body.y);
      });
    }

    this.crew.forEach(c => {
      if (!c.alive) return;
      /* THE ERRAND ENDS WHERE IT WAS DONE (update69). Nothing to
         carry, nobody claimed, and he is standing in the room he was
         sent to: the job is over and his own post is his again. One
         line, no timer, and it cannot leak — a man with no errand is
         simply a man at his station. */
      if (c._errandRoomId && !c.carrying && !c._rescueId && !c._bagTargetId &&
          c.roomId === c._errandRoomId) {
        c._errandRoomId = null;
      }
      /* ── A PRISONER HAS HIS OWN ONE JOB (update72) ───────────
       *
       * He does not repair, does not carry, does not man anything and
       * does not take orders — so he leaves this loop before any of
       * it. What he DOES do is his own three lines, below: sit still
       * in a cell that is not his, or, if this is the hull he has just
       * broken out of, walk to the nearest airlock and leave. */
      if (c.isPrisoner) { this._prisonerWalk(c, dt); return; }
      // Spiders are not a repair crew. They do not fix the wreck they
      // live in, do not haul bodies and do not man stations — they sit
      // in their rooms and kill whatever comes through the door.
      if (c.isPet) return;
      // An EXPLICIT emergency job outranks opportunistic body-hauling.
      // Without this, a crew member sent to seal a breach or fix a
      // module would scoop up a wounded body on arrival and walk off to
      // the medbay, so the damage never got repaired at all.
      const onEmergency = c.task === TASK.REPAIR || c.task === TASK.BREACH ||
                          c.task === TASK.FIRE;
      // Same reasoning for the room they're standing in: while it is
      // burning, holed or shot out, that work comes first — otherwise
      // they seal the breach and immediately wander off with a body,
      // leaving the module broken.
      const hereRoom = this.getRoomById(c.roomId);
      const roomBusy = !!hereRoom && (
        this.fires.getFiresInRoom(hereRoom.id).length > 0 ||
        this.breaches.hasBreachInRoom(hereRoom.id) ||
        (hereRoom.system && hereRoom.system.damagedLevels > 0));
      // Pick up a body sharing the room (wounded first) — but NOT a
      // wounded crew member already lying in a working medbay (that
      // caused the endless carry-back-and-forth jitter), and only if
      // there's actually somewhere useful to take them.
      if (!c.carrying && !onEmergency && !roomBusy) {
        /* THEIR DEAD TOO, once the player has said VENT (update93) —
           the order is what makes him ours to carry. Their living stay
           off our stretchers: `ownSideOnly` was the whole of that rule,
           and it is kept for everybody but a corpse with an order. */
        const body = this.bodiesInRoom(c.roomId, false)
          .filter(b => b.isPlayer === this.isPlayer || (b.dead && b.bodyOrder === 'eject'))
          .filter(b => !b.carriedBy)
          .filter(b => {
            /* NOBODY LIFTS A CORPSE WITH NOWHERE TO PUT IT (update42).
               This used to be an unconditional `return true`, so a body
               was scooped up and shoved through a SHUT airlock — the
               hatch never even opened. Now the player has to open one,
               which is also what finally lets a corpse sit long enough
               to rot. */
            /* A CORPSE GOES NOWHERE WITHOUT AN ORDER (update65).
               This used to be "is an airlock open?", which made the
               PLAYER'S HATCH the decision: open one to fight a fire and
               your dead were quietly thrown out with it. The decay
               alert told him to open an airlock and the game did the
               rest — so the one moment in the game where a body is
               still his to do something about passed without a
               question being asked.
               Now he says VENT and this carries it out. The wounded are
               untouched: they are still picked up and taken to the
               medbay on their own, because a man bleeding on the floor
               is not a decision, he is an emergency. */
            /* On the enemy's hull only the man it SENT lifts a corpse
               (update93a) — a gunner who happens to share the room
               stays on his gun. */
            if (b.dead) return b.bodyOrder === 'eject' && (this.isPlayer || c._rescueId === b.id);
            // wounded: skip if already in a powered medbay (healing)
            /* A MAN ALREADY IN THE WARD IS NOT CARGO (update69). The
               `medPowered` half of this made a DARK medbay a pickup
               spot: the bearer laid him down, the filter let him pick
               the same man straight back up, and the two of them
               shuffled on the spot forever. Whether the lamp is on
               decides whether he HEALS, never whether he is lifted
               again — and now that an errand no longer re-posts the
               bearer, that loop had nothing holding it back. */
            if (medRoom && b.roomId === medRoom.id) return false;
            // wounded: pointless to carry if there's no medbay at all
            return !!medRoom;
          })
          .sort((a, b) => (a.dead ? 1 : 0) - (b.dead ? 1 : 0))[0];
        if (body) { body.carriedBy = c; c.carrying = body; c._rescueId = null; }
      }
      const body = c.carrying;
      if (!body) return;
      // The body rides on the carrier's shoulders
      body.x = c.x; body.y = c.y - 10; body.roomId = c.roomId;
      /* A SURVIVOR OFF A WRECK IS CARRIED WHERE THE PLAYER SAYS (update90b)
         — to the docking hatch (game.js, _survivorTick) — not to whatever
         medbay this hull happens to have. */
      if (body._survivor) return;

      if (!body.dead) {
        // WOUNDED → medbay
        if (medRoom) {
          if (c.roomId === medRoom.id ||
              Utils.dist(c.x, c.y, medRoom.cx, medRoom.cy) < 30) {
            // Arrived: lay them down and STOP (carrier stays put so it
            // doesn't wander off and re-trigger a pickup next frame).
            body.carriedBy = null; c.carrying = null;
            body.x = medRoom.cx + Utils.randFloat(-16, 16);
            body.y = medRoom.cy + 10;
            body.roomId = medRoom.id;
            c._waypoints = [];
            /* HE STANDS STILL FOR A BEAT, THEN GOES BACK TO WORK
               (update69). Parking him here used to mean re-STATIONING
               him here: the man who carried one casualty in never
               returned to his gun. The errand holds him just long
               enough not to scoop the same body up again next frame,
               and `_errandDone` hands his own post back to him. */
            c._errandRoomId = medRoom.id;
          } else if (!c._waypoints.length) {
            c.moveToOnShip(this, medRoom.cx, medRoom.cy);
          }
        }
      } else {
        /* ── DEAD → THE NEAREST AIRLOCK, AND HE WORKS IT HIMSELF
         *    (rebuilt update68)
         *
         * This used to need an airlock the PLAYER had already opened,
         * which made VENT look broken: you gave the order, nothing
         * happened, and the row sat greyed out with no way to guess
         * that the hatch was the missing half. The player's words:
         * "powinno być wyrzuć ciało i wtedy podnosi i zanosi do
         * najbliższego vent, najpierw go otwiera, wyrzuca ciało a
         * następnie zamyka".
         *
         * So the order is now the WHOLE job: walk, open, put him out,
         * shut it again. Any airlock will do — the man carrying the
         * body is the one who opens it.
         *
         * Shutting it again matters: an airlock left open vents the
         * room it is attached to, and a player who asked for a burial
         * did not ask to lose the air in his cargo hold. */
        const air = this.doors.filter(d => d.isAirlock)
          .sort((a, b) => Utils.dist(c.x, c.y, a.x, a.y) -
                          Utils.dist(c.x, c.y, b.x, b.y))[0];
        if (air) {
          c._ejectWaitT = 0;
          if (Utils.dist(c.x, c.y, air.x, air.y) < 26) {
            if (air.mode !== 'open') {
              // Arrived with the body: crack the hatch and wait a beat.
              air.mode = 'open'; air.open = true;
            } else {
              body.ejected = true;
              body.carriedBy = null; c.carrying = null;
              /* AND SHUT IT BEHIND HIM. Only the hatch this order
                 opened — `_ventedBy` marks it, so a hatch the player
                 opened himself to fight a fire is left exactly as he
                 set it. */
              if (c._ventOpened === air.id) { air.mode = 'closed'; air.open = false; }
              c._ventOpened = null;
            }
            if (air.mode === 'open' && c._ventOpened == null) c._ventOpened = air.id;
          } else if (!c._waypoints.length) {
            c.moveToOnShip(this, air.x, air.y);
          }
        } else {
          // A hull with no airlock at all. Put him down rather than
          // stand there holding him forever.
          c._ejectWaitT = (c._ejectWaitT ?? 0) + dt;
          if (c._ejectWaitT >= Ship.CORPSE_HOLD_SECONDS) {
            c._ejectWaitT = 0;
            body.carriedBy = null; c.carrying = null; c._waypoints = [];
          }
        }
      }
    });

    /* ══ THE MEDBAY'S OWN JOB (update78) ════════════════════════
     *
     * Two things changed and together they are the whole reason to buy
     * one.
     *
     * IT IS THE ONLY MEDBAY LOOP NOW. There were two: this one, which
     * healed the men on the FLOOR, and one inside `ShipSystem.update`,
     * which healed the ones on their FEET. Two halves of one patient
     * list in two files, at two rates, agreeing only by accident —
     * and `medbayPatients`, the one function named for the answer,
     * was wired to neither of them.
     *
     * AND IT IS WHAT MAKES A MAN WHOLE. Field aid used to end with the
     * same sentence this loop ends with — up at 30% — so the module
     * was a faster bandage. A bandage stops the bleeding, a medkit
     * gets him up, and only this heals him to full.
     */
    /* THE CURE CLOCK RUNS OVER EVERYBODY, not only over the men in the
       ward (update82). It has to: the clock is reset by LEAVING, and a
       loop that only visits the patients never visits the man who just
       walked out — his half-finished course would sit on him until he
       came back, which is exactly the instalment plan this is not. */
    const inWard = (medbay && medRoom && medbay.effectivePower() > 0)
      ? this.medbayPatients(medRoom.id) : [];
    this.crew.forEach(c => this._cureTick(c, dt, inWard.includes(c)));

    if (medbay && medRoom && medbay.effectivePower() > 0) {
      inWard.forEach(b => {
        if (!b || b.dead) return;
        if (b.hp >= b.maxHp) return;
        b.hp = Math.min(b.maxHp, b.hp + Ship.MEDBAY_HPS * dt * medbay.effectivePower());
        if (b.down && b.hp >= b.maxHp * Ship.MEDKIT_SHARE) {
          b.state = 'ok';
          b._bleedT = 0;
          b._bandaged = false;
          b.bodyOrder = null;
          if (this.isPlayer && typeof UI !== 'undefined') {
            UI.notify(`${b.name} is back on their feet!`, 'good');
          }
        }
      });
    }

    /* ══ FIELD AID IS A BANDAGE, NOT A CURE (update78) ══════
     *
     * It used to heal 2.2 HP/s and STAND HIM UP at 30% — which is the
     * same sentence the medbay's own loop ends with, three times
     * slower. Two things doing one job means the expensive one does
     * not exist: a medbay was a faster bandage and nothing else.
     *
     * A bandage now does exactly what a bandage does. It STOPS THE
     * BLEEDING and leaves him on the floor. Getting him back on his
     * feet is a MEDKIT (any hull) or the MEDBAY (if you have one) —
     * see `_finishMedkit` and the medbay loop above.
     *
     * AND IT COSTS A DOSE. The player's call, and the reason is the
     * whole bleed-out clock: free automatic aid meant the clock never
     * ran out on anybody who fell within reach of a crewmate, so it
     * was a rule that almost never fired. Supplies turn it into the
     * question it was always meant to be — who do I spend the last
     * dose on.
     */
    this.crew.forEach(body => {
      if (body.dead || !body.down || body.carriedBy) return;
      /* NOBODY BANDAGES THE MAN WHO CAME TO BOARD HIM (update54).
         `crewInRoom` below is side-filtered, but this loop walks
         `this.crew`, which holds BOTH sides while a boarding action is
         on — so a downed enemy lying on our deck was quietly patched
         back up by our own hands, and ours by theirs on their hull. */
      if (body.isPlayer !== this.isPlayer) return;
      /* AND NOBODY KNEELS DOWN IN THE MIDDLE OF A FIGHT (update54).
         The same predicate `crewOperating` uses to refuse to man a
         console mid-brawl, so "a fight stops the room's other work" is
         one rule in one place. */
      if (this.roomContested(body.roomId)) return;
      const medic = this.crewInRoom(body.roomId)
        .find(c => !c.carrying && !c.isPet && !c.isPassenger && !c.busy && c !== body);
      if (!medic) return;

      /* THE PLAYER ASKED FOR A MEDKIT ON THIS MAN. Same loop, same
         pair of hands, a different box: the order rides on `bodyOrder`
         exactly like BAG and EJECT do, so there is ONE place that
         knows "a free hand is standing over a casualty" and the order
         decides what he does with them. */
      if (body.bodyOrder === 'medkit' && this.hasDoses(Ship.MEDKIT_DOSES)) {
        this._startBusy(medic, 'medkit', body.id);
        return;
      }
      if (body._bandaged) return;

      /* NO SUPPLIES, NO BANDAGE — and said once, when it matters,
         rather than every frame he lies there. */
      if (!this.hasDoses(Ship.AID_DOSES)) {
        if (this.isPlayer && !body._noAidWarned && typeof UI !== 'undefined') {
          body._noAidWarned = true;
          UI.notify(`No medical supplies for ${body.name} — he is still bleeding.`, 'alert');
        }
        return;
      }
      this._startBusy(medic, 'aid', body.id);
    });

    /* ── THE PLAGUE TRAVELS THROUGH THE VENTS (update42) ──────
       Infection used to reach only `crewInRoom(body.roomId)` — stand
       one door away and you were untouchable, which made the plague a
       non-event. A ship shares one air loop, so a rotting body taints
       the whole hull: fast in the room it lies in, slowly everywhere
       else, and the ship-wide half only while life support is actually
       circulating air. Cutting oxygen contains the outbreak — at the
       obvious price. */
    const vents = (this.getSystem('oxygen')?.effectivePower() ?? 0) > 0;
    const rotting = this.crew.filter(b => b.dead && b.decaying);
    if (rotting.length) {
      const rotRooms = new Set(rotting.map(b => b.roomId));
      const n = rotting.length;
      /* ── ALONG THE DUCTS (update93a) ─────────────────────────
         The player: "mamy wentylację, to choroba zakaźna powinna się w
         miarę łatwo rozprzestrzeniać przez wentylację". Since update90
         the ship HAS a duct network (`ductLinks` — duct to duct past
         every door and up and down the lift shafts), so the air carries
         it the way it carries smoke: the nearer along the ducts, the
         surer. Hops are counted once per frame from the rotting rooms;
         with life support dark nothing moves in the ducts and the
         plague stays in the room it lies in. */
      const hops = new Map();
      if (vents) {
        const queue = [...rotRooms].filter(Boolean);
        queue.forEach(id => hops.set(id, 0));
        for (let qi = 0; qi < queue.length; qi++) {
          const id = queue[qi], d = hops.get(id);
          this.ductLinks(id).forEach(l => {
            if (!l.room || hops.has(l.room.id)) return;
            hops.set(l.room.id, d + 1);
            queue.push(l.room.id);
          });
        }
      }
      const R = Ship.PLAGUE_VENT_RATES;
      this.crew.forEach(c => {
        if (c.infected || !c.alive || c.isPet) return;
        if (c.isPlayer !== this.isPlayer) return;
        const near = rotRooms.has(c.roomId);
        const h = hops.get(c.roomId);
        const rate = near ? Ship.PLAGUE_RATE_ROOM
                   : vents ? (h != null ? R[Math.min(h, R.length) - 1] : Ship.PLAGUE_RATE_VENT)
                   : 0;
        if (rate <= 0) return;
        if (Math.random() < dt * rate * n) {
          c.infected = true;
          if (this.isPlayer && typeof UI !== 'undefined') {
            UI.notify(near ? `${c.name} caught the corpse plague! ☣`
                           : `${c.name} caught the plague through the VENTS! ☣`, 'alert');
          }
        }
      });
    }
  }

  /** Instantly charge shields to full (used at combat start) */
  /** A new fight: nothing learned from a bubble lost LAST time (update44). */
  resetShieldDebt() {
    const ss = this.getSystem('shields');
    if (ss) ss._shieldDebt = 0;
  }

  /**
   * EVERYBODY AT HIS POST, NOW (update97). An enemy crew starts a fight
   * already standing at their consoles — `assignStations` decides who
   * goes where; this puts them there instead of letting them walk. A
   * man without a post (or whose post is gone) is left where he is.
   */
  snapToStations() {
    this.crew.forEach(c => {
      if (!c || !c.alive || c.isPet || c.isPrisoner || c.carrying || c.down) return;
      const room = this.getRoomById(c.homeRoomId);
      if (!room) return;
      this.elevators?.release?.(c);
      c._waypoints = [];
      if (typeof TASK !== 'undefined' && c.task === TASK.MOVE) c.task = TASK.IDLE;   // he has arrived
      c.roomId = room.id; c.inRoom = true;
      const [x, y] = this.stationSpot(room, c);
      c.x = x; c.y = y;
    });
  }

  prechargeShields() {
    const ss = this.getSystem('shields');
    if (!ss) return;
    const layers = Math.floor(ss.effectivePower() / (ss.def.powerPerLayer ?? 2));
    ss._shieldMax  = layers;
    ss._shieldBars = layers;
    ss._shieldTimer = 0;
    // A bubble knocked down LAST fight is not a lesson owed in this
    // one — the debt starts every battle at zero (update44).
    ss._shieldDebt = 0;
  }

  /** World Y of a deck's top edge. */
  _deckY(row) {
    const r = this.rooms.find(o => o.floor === row);
    return r ? r.y : this.roomBounds().y;
  }

  /**
   * THE EXTERIOR TILE SLOTS (update41).
   *
   * The hull is assembled like LEGO, one row per deck:
   *
   *     [engine][module][module][shaft][module][module][prow]
   *
   * The modules and the shaft are the interior, and the engine and the
   * prow are exterior tiles hung off either end — one per deck, every
   * deck the same. These two methods say exactly where they go, so the
   * art can be dropped in without anybody re-deriving the geometry.
   *
   * A STATION has neither: Apophis does not go anywhere.
   */
  engineSlots() {
    if (this.layout.isStation) return [];
    const G = HULL_GRID, b = this.roomBounds();
    // The stern faces AWAY from the enemy: left for you, right for them.
    const x = this.facesRight ? b.x - G.ENGINE_W : b.x + b.w;
    const out = [];
    for (let row = this.layout.floors - 1; row >= 0; row--) {
      out.push({ x, y: this._deckY(row), w: G.ENGINE_W, h: G.MODULE_H,
                 deck: row, flip: !this.facesRight });
    }
    return out;
  }

  /**
   * The bow, one tile per deck. Unlike the engine these are NOT all the
   * same tile: a nose is a taper, so the slice you need depends on how
   * tall the hull is and where in it you are —
   *
   *     1 deck   solo
   *     2 decks  top, bot
   *     3 decks  top, mid, bot
   *
   * `slice` names the tile to draw; `decks` names the set it comes from.
   */
  prowSlots() {
    if (this.layout.isStation) return [];
    const G = HULL_GRID, b = this.roomBounds();
    const decks = this.layout.floors;
    const x = this.facesRight ? b.x + b.w : b.x - G.PROW_W;
    const out = [];
    for (let row = decks - 1; row >= 0; row--) {
      const slice = decks === 1 ? 'solo'
                  : row === decks - 1 ? 'top'
                  : row === 0 ? 'bot' : 'mid';
      out.push({ x, y: this._deckY(row), w: G.PROW_W, h: G.MODULE_H,
                 deck: row, decks, slice, flip: !this.facesRight });
    }
    return out;
  }

  /** The gun bays in slot order (slot i ↔ i-th bay): the weapons modules, then the ARTILLERY module
   *  (update228, jj 10.11: „normalny moduł broni — reszta broni; artyleria — moduł dla rakiet i torped").
   *  The artillery bay comes last, so fitting one never renumbers the guns already aboard. */
  get weaponRooms() {
    return [...this.rooms.filter(r => r.type === 'weapons'), ...this.rooms.filter(r => r.type === 'artillery')];
  }
  /** How many WEAPONS modules (the hull takes three; the artillery bay is not one of them). */
  get weaponModuleCount() { return this.rooms.filter(r => r.type === 'weapons').length; }

  /** A launcher: fires missiles or torpedoes (update228). The mass driver eats missiles too, but it is a gun. */
  static isOrdnance(defKey) {
    const t = (typeof WEAPON_DEFS !== 'undefined' ? WEAPON_DEFS[defKey] : null)?.type;
    return t === 'missile' || t === 'torpedo';
  }
  /** Does this bay take that gun? Launchers go in the artillery bay and nowhere else; everything else in a
   *  weapons module. Your ships only — the enemy's hulls are armed as they were (and a boss's overflow slots
   *  have no bay at all). */
  bayTakes(room, defKey) {
    if (!room || !this.isPlayer) return true;
    return (room.type === 'artillery') === Ship.isOrdnance(defKey);
  }
  /** The first free slot that takes this gun, or -1. `want`: that slot, if it is free and takes it. */
  freeBayFor(defKey, want = null) {
    const ok = i => i >= 0 && i < this.weaponSlots && !this.weapons[i] && this.bayTakes(this.weaponRooms[i] ?? null, defKey);
    if (want != null && ok(want)) return want;
    for (let i = 0; i < this.weaponSlots; i++) if (ok(i)) return i;
    return -1;
  }
  /** Why a gun has nowhere to go, in words (update228). */
  noBayReason(defKey) {
    if (!this.isPlayer) return 'No free weapon mount.';
    if (Ship.isOrdnance(defKey)) {
      return this.rooms.some(r => r.type === 'artillery')
        ? 'The artillery bay already has a launcher.'
        : 'Missile and torpedo launchers need an Artillery module.';
    }
    return this.weaponModuleCount ? 'No free weapons module.' : 'No weapons module.';
  }
  /** After a bay is added: every gun back on the slot of the bay it is bolted into (update228). */
  _reslotGuns() {
    const bays = this.weaponRooms, old = this.weapons.filter(Boolean), next = [];
    const loose = [];
    old.forEach(w => {
      const i = w.roomId ? bays.findIndex(r => r.id === w.roomId) : -1;
      if (i >= 0 && !next[i]) { next[i] = w; w.slot = i; } else loose.push(w);
    });
    loose.forEach(w => {                      // a boss's overflow guns keep their numbers where they can
      let i = w.slot;
      while (next[i]) i++;
      next[i] = w; w.slot = i;
    });
    for (let i = 0; i < next.length; i++) if (!next[i]) next[i] = null;
    this.weapons = next;
  }

  /**
   * WHICH MODULE IS THIS GUN BOLTED INTO? (update60)
   *
   * A gun used to find its module by POSITION: `weaponRooms[slot]`,
   * where `weaponRooms` is `rooms.filter(type === 'weapons')` — a list
   * that is rebuilt from the room table every time it is read. Nothing
   * anchored a gun to a place; the pairing was an accident of ordering.
   * Add a weapons module in a room that sorts EARLIER than an existing
   * one and every gun aboard silently starts drawing power and crew
   * from somebody else's bay. No current hull can do it (checked all
   * three: none has an empty room before its weapons room), which is
   * exactly what makes it the kind of trap that goes off years later,
   * on the first layout somebody adds.
   *
   * A gun now remembers its ROOM. The fallback to the old positional
   * rule stays for two real cases: a save written before update60, and
   * the boss hulls, which mount more guns than they have bays.
   */
  weaponRoomFor(w) {
    if (!w) return null;
    if (w.roomId) {
      const room = this.getRoomById(w.roomId);
      if (room && (room.type === 'weapons' || room.type === 'artillery')) return room;
    }
    return this.weaponRooms[w.slot] ?? null;
  }

  /** The weapon system powering slot i (its own module room).
   *  Kept slot-based for the boss overflow path; everything that has a
   *  WEAPON in hand should go through weaponRoomFor instead. */
  weaponSystemFor(slot) {
    return this.weaponRooms[slot]?.system ?? null;
  }

  /** Charge bonus for a SPECIFIC weapon: the gunner AT ITS CONSOLE.
   *  Used to sum over everyone in the bay — see consoleOperator(). */
  weaponCrewBonusFor(slot) {
    // Resolve through the GUN when there is one in this slot, so the
    // bonus comes from the bay the gun is actually in (update60).
    const room = this.weaponRoomFor(this.weapons[slot]) ?? this.weaponRooms[slot];
    if (!room) return 0;
    const gunner = this.consoleOperator(room.id);
    return gunner ? gunner.weaponChargeBonus() : 0;
  }

  weaponCrewBonus() {   // legacy aggregate (kept for compatibility)
    return this.weapons.reduce((a, w, i) =>
      Math.max(a, w ? this.weaponCrewBonusFor(i) : 0), 0);
  }

  // ── Weapons ──────────────────────────────────────────────

  /** ONE gun per weapon module. Fails if the slot is occupied or
   *  there is no module room for it (boss ships may override slots). */
  installWeapon(defKey, slot, { force = false } = {}) {
    if (slot >= this.weaponSlots) return false;
    if (this.weapons[slot]) return false;
    /* launchers in the artillery bay, guns in the weapons modules (update228); `force`: a save from before */
    if (!force && !this.bayTakes(this.weaponRooms[slot] ?? null, defKey)) return false;
    const w = new Weapon(defKey, slot);
    // The bay it is being bolted into, remembered on the gun (update60).
    w.roomId = this.weaponRooms[slot]?.id ?? null;
    this.weapons[slot] = w;
    this._reallocWeaponPower();
    return true;
  }

  /** STATION UPGRADE: convert the first empty room into a brand-new
   *  MODULE of the given type (level 1 system). Weapons cap at 3 per
   *  hull; other module types cap at 1. */
  addModule(type) {
    type = systemType(type);      // an old save may still say 'brig'
    if (!SYSTEM_DEFS[type]) return false;
    if (type === 'weapons') {
      if (this.weaponModuleCount >= 3) return false;
    } else if (this.getSystem(type)) {
      return false;   // only one cloak / repair bay etc.
    }
    const room = this.rooms.find(r => r.type === 'empty');
    if (!room) return false;
    room.type = type;
    // Some modules are worthless at one pip — shields need a whole
    // 2-power layer before they can raise anything at all.
    const sys = new ShipSystem(type, SYSTEM_DEFS[type].startLevel ?? 1);
    sys.power = 0; sys.desiredPower = 0;   // new modules start UNPOWERED
    room.system = sys;
    this._fitSystemToRoom(sys, room);
    this.systems.push(sys);
    this._extraModules = this._extraModules ?? [];
    this._extraModules.push(type);
    if (type === 'weapons' || type === 'artillery') {
      this.weaponSlots = Math.max(this.weaponSlots, this.weaponRooms.length);
      if (this.rooms.some(r => r.type === 'artillery')) this._reslotGuns();   // the artillery bay stays last
    }
    return true;
  }

  addWeaponModule() { return this.addModule('weapons'); }

  /** Same as addModule, but into a SPECIFIC empty room chosen by the
   *  player on the station's ship diagram. */
  addModuleAt(type, roomId) {
    type = systemType(type);      // an old save may still say 'brig'
    if (!SYSTEM_DEFS[type]) return false;
    if (type === 'weapons') {
      if (this.weaponModuleCount >= 3) return false;
    } else if (this.getSystem(type)) {
      return false;
    }
    const room = this.getRoomById(roomId);
    if (!room || room.type !== 'empty') return false;
    room.type = type;
    // Some modules are worthless at one pip — shields need a whole
    // 2-power layer before they can raise anything at all.
    const sys = new ShipSystem(type, SYSTEM_DEFS[type].startLevel ?? 1);
    sys.power = 0; sys.desiredPower = 0;   // new modules start UNPOWERED
    room.system = sys;
    this._fitSystemToRoom(sys, room);
    this.systems.push(sys);
    this._extraModules = this._extraModules ?? [];
    this._extraModules.push({ type, roomId });
    if (type === 'weapons' || type === 'artillery') {
      this.weaponSlots = Math.max(this.weaponSlots, this.weaponRooms.length);
      if (this.rooms.some(r => r.type === 'artillery')) this._reslotGuns();   // the artillery bay stays last
    }
    return true;
  }

  /* ══ THE BRIG (update63) ═══════════════════════════════════
   *
   * A prisoner is NOT crew and never goes in `crew`. That list is
   * walked by station assignment, medbay hauling, the roster panel,
   * hunger, the victory check, docking and the barracks — update45
   * put a CAT in it and the game offered the animal a console. A man
   * who wants to kill you is a worse thing to hand that list.
   *
   * So: their own array, their own three rules, and one door in and
   * one door out.
   */

  /**
   * SLABS THAT ARE ACTUALLY COLD.
   *
   * One per working level AND one unit of power each — the player's
   * rule, and the whole shape of the decision: "1 poziom = 1 miejsce =
   * 1 prąd". Cutting a unit takes a slab away while the module is
   * still standing, which is what makes this a dial rather than a
   * switch. A shot-out bay is smaller before it is empty; a browned-out
   * one is smaller before it is dark.
   *
   * It used to read `workingLevels` alone, so power was all-or-nothing
   * and three cells stayed three cells right up until the lights went
   * out.
   */
  carboniteCapacity() {
    const b = this.getSystem('carbonite');
    if (!b) return 0;
    return Math.max(0, Math.min(b.workingLevels, b.effectivePower()));
  }

  /** Everyone in a slab: convicts you are hauling in, and your own men
   *  whose clock you have stopped. One list would have been wrong —
   *  a prisoner is not crew (see the note above) — but there is only
   *  ONE capacity, and both kinds spend it. */
  frozenCrew() { return this.crew.filter(c => c && c.frozen && !c.dead); }

  /** A medbay that is aboard, undamaged enough to work, and lit. One
   *  question, asked by the bleed clock, the dispatch and the healing
   *  loop alike (update78). */
  _wardIsOpen() {
    const med = this.getSystem('medbay');
    return !!med && !med.isDisabled() && med.effectivePower() > 0;
  }

  /**
   * HOW GOOD THIS WARD ACTUALLY IS, RIGHT NOW (update82).
   *
   * Not `level` — what you PAID for is not what you HAVE. A ward is
   * as good as the smaller of what is built and what is running, the
   * same expression carbonite counts its slabs with since update77,
   * and for the same reason: a shot-out pip and an unpowered pip take
   * a bed away just as surely as a bed that was never installed.
   *
   * That cuts both ways, and the player asked for both. A hit takes
   * the quarantine bench away mid-fight — but a level 5 ward with one
   * pip shot out is still a level 4 ward, which is the whole argument
   * for buying the upgrade before you can afford to run it: "nawet jak
   * nie ma wystarczajaco energi do modulu to warto miec nieraz wyzszy
   * poziom aby w razie uszkodzenia paipa dalej mozna bylo uzywac".
   */
  wardLevel() {
    const med = this.getSystem('medbay');
    if (!med || med.isDisabled()) return 0;
    return Math.max(0, Math.min(med.workingLevels, med.effectivePower()));
  }

  /**
   * WHAT A WARD OF THIS SIZE CAN CURE (update82).
   *
   * The player's ladder, and the steps are two levels apart on his
   * instruction: "co 2 lev jest dodatkowo zalanczane usdrownienie,
   * czyli 3 lev leczy epidemie po zwlokach jak sie rozklada a 5 lev
   * narazie dodatkowo jeszcze virusa pajaka".
   *
   *   1  hit points, which is what a ward has always done
   *   3  + the corpse plague
   *   5  + the void-spider virus
   *   7  + reserved, and deliberately empty
   *
   * THE EMPTY RUNGS ARE NOT AN OVERSIGHT. `maxLevel` stays 8 because
   * a level you cannot yet use is still a level that survives a hit —
   * see `wardLevel`. Filling 7 and 8 later costs one line each.
   *
   * ONE TABLE, so the cure loop, the refusal text and any future shop
   * blurb cannot disagree about which bench does what.
   */
  static get CURE_LEVELS() { return { plague: 3, virus: 5 }; }

  /** Seconds on the table before a disease lets go. */
  static get CURE_SECONDS() { return 20; }

  /** Can this hull treat `what` at all right now? */
  canCure(what) {
    const need = Ship.CURE_LEVELS[what];
    return !!need && this.wardLevel() >= need;
  }

  /**
   * ONE MAN, ONE SPELL ON THE TABLE (update82).
   *
   * A CURE IS TIME, NOT A BUTTON. Clearing the disease the frame he
   * walks in would make a level 5 ward a switch, and would make
   * carrying a sick man to it free — the whole cost of treating
   * somebody is the twenty seconds his hands are not on a console.
   * It is the same shape as everything else this ship asks of the
   * player since update78: the price is the time.
   *
   * ONE CLOCK for both diseases, because a man is on the table or he
   * is not — two timers would be two answers to "how long has he been
   * lying there". Walking out resets it: treatment is not something
   * you bank in instalments between fights.
   *
   * NOT SERIALISED, on purpose. A reload puts him back at the start of
   * the twenty seconds, which costs the player time and can never gain
   * him any — the safe direction for a field that is only ever a
   * countdown.
   */
  _cureTick(b, dt, inWard) {
    if (!b) return;
    if (!inWard) { b._cureT = 0; return; }
    const what = b.virus ? 'virus' : (b.infected ? 'plague' : null);
    if (!what || !this.canCure(what)) { b._cureT = 0; return; }

    b._cureT = (b._cureT ?? 0) + dt;
    if (b._cureT < Ship.CURE_SECONDS) return;
    b._cureT = 0;

    if (what === 'virus') {
      /* THE CLOCK STOPS AND THE EGG NEVER COMES. `virusT` is what
         `_virusBurst` counts down, so putting it back where a healthy
         man's sits is the cure — there is no second "is he ill" flag
         to clear and go stale. */
      b.virus  = false;
      b.virusT = (typeof VIRUS_SECONDS !== 'undefined') ? VIRUS_SECONDS : 0;
    } else {
      b.infected = false;
      b._infT    = 0;
    }
    if (this.isPlayer && typeof UI !== 'undefined') {
      UI.notify(what === 'virus'
        ? `${b.name} is clear of the virus — the ward caught it in time.`
        : `${b.name} is over the plague.`, 'good');
    }
  }

  /** Slabs with nobody in them. */
  freeCells() {
    return Math.max(0, this.carboniteCapacity()
                     - this.prisoners.length - this.frozenCrew().length);
  }

  /**
   * WHY YOU CANNOT FREEZE THIS MAN. Null means you can.
   *
   * Asked by the button AND by the order, so a row can never look live
   * and then do nothing — the same contract the body menu has kept
   * since update68.
   *
   * He has to BE in the bay. Carbonite is a place, not a button: the
   * walk there is the cost you pay before the decision, in the seconds
   * his hands are off a console and in the risk of sending him across
   * a burning ship. Freezing a man from anywhere would make it free.
   */
  freezeRefusal(c) {
    if (!c || c.dead || !c.isPlayer) return 'not one of your crew';
    if (c.isPet) return 'not an animal';
    if (c.frozen)  return 'already in a slab';
    const bay = this._slabRefusal();
    if (bay) return bay;
    // …and the half that is only about HIM: carbonite is a place.
    if (c.roomId !== this.getSystem('carbonite').roomId) {
      return 'he is not in the carbonite bay';
    }
    return null;
  }

  /** Put him under. Returns {ok, message} — the shape every order in
   *  this file answers in. */
  freezeCrew(c) {
    const why = this.freezeRefusal(c);
    if (why) return { ok: false, message: `Cannot freeze: ${why}.` };
    /* WHICH SLAB WENT IN LAST, so thawing can be last-in-first-out
       when the power drops — a rule the player can work out before he
       pulls the pip rather than after.
       COMPUTED from the men already under, not kept in a counter on
       the ship: a counter would be a second register that has to be
       saved, reloaded and kept in step with the crew it describes, and
       the crew already carry the answer.
       Read BEFORE he joins them, or he would be counting himself. */
    this._slabIn(c);
    if (this.isPlayer && typeof UI !== 'undefined') {
      UI.notify(`${c.name} is under. Nothing moves for him now.`, 'good');
    }
    return { ok: true, message: `${c.name} frozen.` };
  }

  /** Into a slab — ONE body of code for the player's order and for the
   *  enemy's captives (update93), so a man frozen either way is frozen
   *  the same way and thaws by the same rule. */
  _slabIn(c) {
    c._slabSeq = 1 + this.frozenCrew()
      .reduce((m, x) => Math.max(m, x._slabSeq ?? 0), 0);
    c.frozen = true;
    c._slabRoom = c.roomId;
    /* OUT OF EVERY ROOM QUERY. He keeps his x and y — the player can
       see him in the slab and click him to thaw him — but nothing that
       searches a ROOM finds him, so he cannot man a console, be shot
       at, catch fire, breathe or be counted as a defender. */
    c.roomId = null; c.inRoom = false;
    c.target = null; c.path = null;     // he was walking; now he is not
    c._waypoints = [];
    this._placeSlabs();                  // into a window of the bay (update128)
  }

  /**
   * THEIR PRISONERS ARE IN CARBONITE (update93) — the player's list,
   * point 27. A captive on an enemy hull goes into a slab of the bay he
   * sits in, and comes out by the rule every slab keeps
   * (`carboniteTick`): the bay loses power, or a level of it is shot
   * out or broken by a boarder, and the last one in is the first one
   * out. Only a THAWED man can be walked out of the bay by one of ours
   * (`freeCaptives` finds people by room, and a man in a slab is in
   * none) — so a rescue is now a bay to knock out first: from the guns,
   * or by the boarder who stands in it and wrecks it.
   */
  freezeCaptive(c) {
    if (!c || !c.isPrisoner || c.dead || c.frozen) return false;
    /* Slabs BUILT, not slabs lit: the hull is still being put together
       when he is seated and its power has not flowed yet. If the bay
       turns out to be dark, the first `carboniteTick` lets him out —
       the rule, not a special case. */
    const bay = this.getSystem('carbonite');
    if (!bay || this.frozenCrew().length + this.prisoners.length >= bay.workingLevels) return false;
    this._slabIn(c);
    return true;
  }

  /** Bring him back, exactly as he went in. */
  thawCrew(c, why = 'thawed') {
    if (!c || !c.frozen) return { ok: false, message: 'He is not in a slab.' };
    c.frozen = false;
    c._slabSeq = null;
    c._slabIdx = null; c._slab = null;
    c._meltT = 0; c._meltWarned = false;
    const pod  = this.getSystem('carbonite');
    const room = this.getRoomById(c._slabRoom ?? pod?.roomId) || this.rooms[0];
    if (room) {
      c.roomId = room.id;
      c.x = room.cx;
      c.y = this.floorWalkY(room.floor, room.cy);
      c.homeRoomId = c.homeRoomId ?? room.id;
    }
    if (this.isPlayer && typeof UI !== 'undefined') {
      UI.notify(`${c.name} is out of the slab — ${why}.`,
                why === 'thawed' ? 'good' : 'warn');
    }
    return { ok: true, message: `${c.name} thawed.` };
  }

  /**
   * THE SLAB THAT LOST ITS POWER LETS GO.
   *
   * The player's rule, word for word: "dwóch zamrożonych, ucinasz
   * jeden prąd → jeden się rozmraża, drugi nie". Capacity is a live
   * number now, so this is just "put back whoever no longer has a
   * slab" — LAST IN FIRST OUT, so which man it is, is something the
   * player can work out before he pulls the pip rather than after.
   *
   * Prisoners are NOT thawed here: a convict whose cell goes cold
   * starts working the lock instead, which is `prisonerTick`, and that
   * rule was already right.
   */
  carboniteTick(dt = 0) {
    const over = (this.prisoners.length + this.frozenCrew().length)
               - this.carboniteCapacity();
    /* ── A SLAB MELTS, IT DOES NOT POP (update127, jj) ───────────
     * "rozmrażanie trwa jakieś 20 s, może 30 s — teraz strzelam w moduł
     * przeciwnika i on od razu się rozmraża, nikt nie ma szans na
     * naprawienie modułu". A slab that loses its unit starts to WARM:
     * `SLAB_MELT_SECONDS` of it, and only then is he out. Power back
     * in time (a repair, a pip) and the clock goes back to zero — the
     * same rule as a brig cell. Still LAST IN, FIRST OUT. */
    const queue = this.frozenCrew().sort((a, b) => (b._slabSeq ?? 0) - (a._slabSeq ?? 0));
    const melting = new Set(queue.slice(0, Math.max(0, over)));
    const done = [];
    queue.forEach(c => {
      if (!melting.has(c)) { c._meltT = 0; c._meltWarned = false; return; }
      c._meltT = (c._meltT ?? 0) + Math.max(0, dt);
      if (!c._meltWarned) {
        c._meltWarned = true;
        if (typeof UI !== 'undefined') {
          const S = Ship.SLAB_MELT_SECONDS;
          if (this.isPlayer) UI.notify(`${c.name}'s slab has lost power — he thaws in ${S} s unless it comes back.`, 'warn');
          else if (c.isPrisoner) UI.notify(`Their carbonite bay is failing — our man thaws in ${S} s.`, 'good');
        }
      }
      if (c._meltT >= Ship.SLAB_MELT_SECONDS) done.push(c);
    });
    done.forEach(c => {
      c._meltT = 0; c._meltWarned = false;
      this.thawCrew(c, 'his slab lost power');
      /* THEIR PRISONER IS OUT OF THE ICE (update93) — and since update107
         (jj) he does not wait to be fetched: a few seconds to come round,
         then he breaks out and makes for our ship, fighting whoever stands
         in his way (`_breakOut`, game.js sends him home). */
      if (!this.isPlayer && c.isPrisoner) {
        this._startBusy(c, 'thaw', null, Ship.THAW_SECONDS);
        c._waypoints = []; c.task = TASK.IDLE;
        if (typeof UI !== 'undefined') {
          UI.notify(`A prisoner on their hull is out of the carbonite — in ${Ship.THAW_SECONDS} s he breaks for our ship!`, 'good');
        }
      }
    });
  }

  /**
   * Lock a man up. Refuses rather than overfilling — the caller is a
   * player decision and has to be able to say "you have no room".
   */
  takePrisoner(rec) {
    if (!rec || this.freeCells() <= 0) return false;
    this.prisoners.push({
      id: rec.id ?? `p${this.prisoners.length}`,
      name: rec.name ?? 'Prisoner',
      bounty: Math.max(0, Math.round(rec.bounty ?? 0)),
      /* Which poster he came off, or null. The ID, never a copy of the
         record — the list is the one place he lives. */
      wantedId: rec.wantedId ?? null,
      /* A CONVICT ON TRANSPORT (update163): his job, his house — he is
         handed over at a prison, not at the bounty office. */
      jobId: rec.jobId ?? null,
      race: rec.race ?? null,
      level: rec.level,
      escapeT: 0,
      warned: false,
    });
    return true;
  }

  /**
   * WHAT KEEPS THEM IN IS POWER, NOT THE WALL.
   *
   * A powered brig is a room they sit in. Cut its power — or shoot it
   * out — and the clock starts; restore it and the clock goes back to
   * zero, because a man interrupted at a lock has to start again. Only
   * when the clock runs out is he gone, and the player is warned well
   * before that so it is never a silent loss.
   */
  prisonerTick(dt) {
    if (!this.prisoners.length) return;
    /* ── A SLAB EACH, NOT A DOOR FOR EVERYBODY (update77) ────
     *
     * This asked one yes-or-no question — is the bay powered — so
     * three convicts in a bay browned out from three units to one
     * stayed put, because the module was not DISABLED. Slabs are
     * counted now, so losing two units frees exactly two men to start
     * working their locks and leaves the third cold.
     *
     * PRISONERS HAVE THE FIRST CLAIM on what slabs remain, and your
     * own frozen men are the ones who come out (`carboniteTick`) —
     * a thaw can be undone, an escape cannot.
     *
     * Earliest taken keeps his slab, so the man who has been aboard
     * longest is not the one who gets a chance. */
    const slabs = Math.min(this.prisoners.length, this.carboniteCapacity());
    this.prisoners.slice(0, slabs).forEach(p => { p.escapeT = 0; p.warned = false; });
    const loose = this.prisoners.slice(slabs);
    if (!loose.length) return;
    const gone = [];
    loose.forEach(p => {
      p.escapeT += dt;
      if (!p.warned && p.escapeT >= Ship.ESCAPE_SECONDS * 0.4) {
        p.warned = true;
        if (this.isPlayer && typeof UI !== 'undefined') {
          UI.notify(`${p.name} is working the cell door — get the carbonite bay powered!`, 'alert');
        }
      }
      if (p.escapeT >= Ship.ESCAPE_SECONDS) gone.push(p);
    });
    gone.forEach(p => {
      this.prisoners.splice(this.prisoners.indexOf(p), 1);
      /* ── HE WALKS OUT, HE DOES NOT VANISH (update72) ────────
       *
       * update67 made the escape a LINE OF TEXT: the cell clock ran
       * out, a notification appeared and the man ceased to exist. The
       * player's own design said otherwise — "biegnie do śluzy i
       * ucieka… gracz ma realny czas, żeby go zablokować drzwiami" —
       * and text cannot be interrupted by a door.
       *
       * So he becomes what he always was: a man, standing in the brig,
       * heading for the nearest airlock. Shut the right door and he is
       * still aboard; order a hand to walk him back and he is back in
       * the cell at the same price. The board is written only when he
       * is actually GONE, which is now a thing that can fail to happen.
       */
      const brig = this.getRoomById(this.getSystem('carbonite')?.roomId) || this.rooms[0];
      const runner = new CrewMember({
        name: p.name, race: p.race || 'hostile',
        isPlayer: false, isPrisoner: true,
      });
      runner.wantedId = p.wantedId ?? null;
      runner.bounty   = p.bounty ?? 0;
      runner.jobId    = p.jobId ?? null;          // a convict on transport stays one (update163)
      /* LEFT UNDEFINED WHEN THE CELL RECORD HAS NO LEVEL, on purpose:
         `reWanted` falls back to 5 for a man nobody has rated, and
         writing 1 here would have put every escaped commander on the
         board as a beginner. */
      runner.level    = p.level;
      runner.escapes  = p.escapes ?? 0;
      runner._breakingOut = true;
      runner.roomId = brig?.id;
      runner.x = brig ? brig.cx : 0;
      runner.y = brig ? this.floorWalkY(brig.floor, brig.cy) : 0;
      runner.homeRoomId = brig?.id;
      this.addCrew(runner, true);
      if (this.isPlayer && typeof UI !== 'undefined') {
        UI.notify(`${p.name} is OUT of the cell and making for an airlock — `
                + 'shut a door on him.', 'alert');
      }
    });
  }

  /**
   * A PRISONER EATS (update67).
   *
   * One meal per sector, taken out of the hold like anybody else's —
   * which is the real cost of carrying a man home: not the cell, the
   * RATIONS. A hold packed with ore and no food is a hold that starves
   * your bounty on the way back.
   *
   * Called once per jump, not per frame: hunger for prisoners is a
   * decision at the jump ("do I have food for him?"), and a meter of
   * its own would be a second hunger system beside the crew's.
   *
   * A man with nothing to eat dies, and a dead prisoner is a BODY —
   * still worth half, if the hold has room for him. That is the same
   * pair of prices as everywhere else, and it means starving him is a
   * loss, not a clean escape from the problem.
   */
  feedPrisoners() {
    const out = { fed: 0, starved: [], bagged: 0 };
    if (!this.prisoners.length) return out;
    this.prisoners.slice().forEach(p => {
      const meal = this.cargo?.items?.find(it =>
        it.def?.tag === 'food' && !it.damaged);
      if (meal) {
        if ((meal.qty ?? 0) > 1) meal.qty--; else this.cargo.remove(meal);
        out.fed++;
        return;
      }
      this.prisoners.splice(this.prisoners.indexOf(p), 1);
      out.starved.push(p.name);
      /* HIS BODY, IF THERE IS ROOM. Half his price, the same rule as
         a commander finished off in his cockpit. */
      const bag = this.cargo?.add?.('body_bag', {
        name: p.name, bounty: Math.round((p.bounty ?? 0) / 2),
        wantedId: p.wantedId ?? null,
      });
      if (bag) out.bagged++;
    });
    if (this.isPlayer && typeof UI !== 'undefined') {
      if (out.starved.length) {
        UI.notify(`${out.starved.join(', ')} starved in the cells.`, 'alert');
      } else if (out.fed) {
        UI.notify(`${out.fed} prisoner meal${out.fed > 1 ? 's' : ''} out of the hold.`,
                  'info');
      }
    }
    return out;
  }

  /** Missiles are physical: the racks in the hold ARE the ammo count. */
  missileCount() { return this.cargo?.countOf?.('missiles') ?? 0; }
  torpedoCount() { return this.cargo?.countOf?.('torpedoes') ?? 0; }

  /** He2 is physical too (update39): the cells in the hold ARE the tank.
   *  No canisters aboard, no jump — exactly like the missile racks. */
  fuelCount() { return this.cargo?.countOf?.('fuel') ?? 0; }

  /**
   * Box a gun and stow it in the grid hold. A gun can only ever be
   * MOUNTED or BOXED — there is no weightless rack it can live on.
   * Returns the crate, or null if the hold has no room for it.
   */
  /**
   * Every spare gun aboard, as the crates they actually are.
   *
   * ONE definition of "a boxed gun" (update75). The filter — a crate
   * whose kind is `weapon` and which remembers WHICH gun in `meta` —
   * was written out by hand in the station screen twice, in the yard
   * and in the distress-beacon code. Four copies of one sentence is
   * four chances for one of them to start meaning something else.
   */
  boxedGuns() {
    return (this.cargo?.items ?? [])
      .filter(it => it.def?.kind === 'weapon' && it.meta);
  }

  boxWeapon(defKey, dest = this.cargo) {
    if (!dest || typeof cargoCrateForWeapon !== 'function') return null;
    return dest.add(cargoCrateForWeapon(defKey), defKey);
  }

  /**
   * Unbolt a gun and box it. Returns the gun's defKey, or null if the
   * mount was empty OR the crate would not fit — in which case THE GUN
   * STAYS BOLTED ON.
   *
   * `dest` is which grid the crate lands in: the ship's own hold out on
   * a contract, the base's armoury shelf when she is in the hangar.
   * ONE function unbolts a gun, and it is the one that holds the rule
   * that matters: if the crate cannot be placed, nothing moves at all —
   * a gun is never in the air between the mount and a shelf. The two
   * callers used to each carry their own copy of that check (update75).
   */
  uninstallWeapon(slot, dest = this.cargo) {
    const w = this.weapons[slot];
    if (!w) return null;
    if (!this.boxWeapon(w.defKey, dest)) return null;  // no room — she keeps her gun
    this.weapons[slot] = null;
    this._reallocWeaponPower();
    return w.defKey;
  }

  /**
   * Strip a bay while a hull is still being BUILT. The gun is not
   * stowed anywhere — it is gone, because it never really existed: this
   * is for swapping the layout's default gun out of an enemy hull
   * before anybody has seen her.
   *
   * It exists so that the destruction is written down (update75).
   * Enemy setup used to call `uninstallWeapon` for this and rely on the
   * gun landing in `weaponCargo`, a list nothing ever read on an enemy
   * — destruction by side effect, in a function whose whole promise is
   * that the gun is kept. With the rack gone, that call would have
   * boxed a crate into the enemy's hold, turning her starter laser into
   * loot the player was never meant to find, and would have FAILED on a
   * full hold, leaving the bay occupied and the swap silently undone.
   *
   * Never call this on a ship anybody owns. Taking a gun off a mount
   * and keeping it is `uninstallWeapon`, and that is the only one the
   * station and the hangar are allowed to use.
   */
  scrapWeapon(slot) {
    if (!this.weapons[slot]) return false;
    this.weapons[slot] = null;
    this._reallocWeaponPower();
    return true;
  }

  /* removeWeapon(slot) DELETED (update40).
   *
   * It sat directly below `uninstallWeapon(slot)` with no call sites and
   * the opposite behaviour: uninstall KEPT the gun, removeWeapon
   * DESTROYED it. Two contradictory rules for one action, one of them
   * silently confiscating a weapon the day anybody wired it up by
   * mistake. Still deleted, and now there is only one place a gun can
   * go when it comes off a mount, so the pair cannot grow back.
   */

  _reallocWeaponPower() {
    // Each gun draws power from ITS OWN weapon module. A damaged or
    // ionised module de-powers only the gun mounted in it (FTL rule,
    // one gun per module). Overflow slots without a room (boss ships)
    // share the FIRST module's leftover power.
    let sharedLeft = null;
    this.weapons.forEach((w, i) => {
      if (!w) return;
      const sys = this.weaponRoomFor(w)?.system ?? null;
      if (sys) {
        w.power = Math.min(w.powerCost, sys.effectivePower());
      } else {
        if (sharedLeft === null) {
          const first = this.weaponSystemFor(0);
          sharedLeft = first ? Math.max(0, first.effectivePower()
            - (this.weapons[0]?.power ?? 0)) : 0;
        }
        const give = Math.min(w.powerCost, sharedLeft);
        w.power    = give;
        sharedLeft -= give;
      }
    });
  }

  // ── Power management ──────────────────────────────────────

  /** Has this ship's power ever been laid out (by the auto-spread or
   *  by the player)? Used so a new battle does NOT stomp the layout the
   *  player set up in the previous one. */
  hasPowerPreference() {
    return this.systems.some(s => s.type !== 'reactor' && s.desiredPower > 0);
  }

  /** Evasion per POWERED level — read by `evasion` and by the module
   *  tooltip, so the number on screen is the number in the maths. */
  static get EVADE_PILOT()  { return 0.03; }
  static get EVADE_ENGINE() { return 0.02; }
  /** One drone mends like half a crewman (update229: it was the whole bay's rate per level). */
  static get AUTOREPAIR_RATE() { return typeof DRONE_TUNING !== 'undefined' ? DRONE_TUNING.RATE : 0.5; }

  /**
   * WHAT THIS MODULE DOES, LEVEL BY LEVEL (update88).
   *
   * The player: "medyczny moduł powinien mieć info, jaki lev jest
   * aktualnie i co daje każdy lev — teraz gracz nie ma pojęcia, że leczy
   * choroby; tak samo dla wszystkich modułów". Every number here is READ
   * from the rule it describes (Ship.CURE_LEVELS, OXYGEN.PER_POWER,
   * Ship.EVADE_*, SYSTEM_DEFS…), not typed in again — so the tooltip
   * cannot say one thing while the game does another. Several of the
   * SYSTEM_DEFS descriptions had drifted exactly like that (the O2 one
   * still promised a faster refill).
   *
   * Returns { title, status, rows: [{ text, on }] } — `on` when the
   * module, as it stands, already does that.
   */
  moduleInfo(sys) {
    if (!sys) return null;
    const lvl = sys.level, dmg = sys.damagedLevels ?? 0;
    const pw  = sys.type === 'reactor' ? (this.reactor?.totalPower ?? 0) : sys.effectivePower();
    const pct = (x) => `${Math.round(x * 100)}%`;
    const rows = [];
    const row = (text, on) => rows.push({ text, on: !!on });
    let status = `level ${lvl} · powered ${pw}` + (dmg ? ` · ${dmg} shot out` : '');
    switch (sys.type) {
      case 'reactor': {
        status = `level ${lvl} · output ${pw}` + (dmg ? ` · ${dmg} shot out` : '');
        row('1 unit of power per working level', true);
        row('A Terra cyborg at its console: +1 unit', (this.reactor?.cyborgBonus ?? 0) > 0);
        row(`Now: ${pw} units, ${this.availablePower?.() ?? 0} unspent`, true);
        // update92: the heat, and which way it is going.
        {
          const load = Math.round(this.reactorLoad * 100), heat = Math.round(this.reactorHeat ?? 0);
          const rate = this.reactorHeatRate();
          const C = REACTOR_HEAT_CONFIG.maxCelsius;
          row(`Core ${heatCelsius(heat)} °C of ${C} · load ${load}% (modules) — ${rate > 0 ? 'heating' : rate < 0 ? 'cooling' : 'holding'}`, rate <= 0);
          row('Heats from 80% load; cools with 30%+ of it free', rate < 0);
          {
            const cool = REACTOR_HEAT_CONFIG.consoleCoolPerSec * REACTOR_HEAT_CONFIG.maxCelsius / 100;
            row(this.consoleCoolRate() > 0
              ? `A hand at the console: −${cool.toFixed(1)} °C/s`
              : `Man the console: −${cool.toFixed(1)} °C/s`, this.consoleCoolRate() > 0);
          }
          row(`${C} °C: OVERHEAT — a reactor level lost, back to ${heatCelsius(REACTOR_HEAT_CONFIG.overheatResetHeat)} °C`, heat < 100);
          // update93c: the hold's share, when there is one
          const items = this.cargo?.items ?? [];
          const cores = items.filter(it => it.def?.tag === 'rad').length;
          const cools = items.filter(it => it.def?.tag === 'cool').length;
          if (cores || cools) {
            const net = cores - cools;
            row(`Hold: ${cores} unstable core${cores === 1 ? '' : 's'}, ${cools} cooler${cools === 1 ? '' : 's'} — `
              + (net > 0 ? 'heating the reactor' : net < 0 ? 'cooling the reactor' : 'cancelled out'), net <= 0);
          }
        }
        break;
      }
      case 'shields': {
        const per = SYSTEM_DEFS.shields.powerPerLayer ?? 2;
        const layers = Math.floor(pw / per);
        for (let L = 1; L <= Math.floor((SYSTEM_DEFS.shields.maxLevel ?? 6) / per); L++) {
          row(`${L * per} power: ${L} layer${L > 1 ? 's' : ''}`, layers >= L);
        }
        row(`A layer recharges in ${SYSTEM_DEFS.shields.rechargeTime}s — faster with a skilled hand`, true);
        break;
      }
      case 'engines': {
        row(`+${pct(Ship.EVADE_ENGINE)} evasion per powered level`, pw > 0);
        row('Powered at all: the ship can jump and retreat', pw > 0);
        row('No pilot in the cockpit: no evasion at all', true);
        row(`Now: +${pct(pw * Ship.EVADE_ENGINE)}`, pw > 0);
        // update91: the engines carry the ship's gravity.
        row(this.gravityActive ? 'Gravity ON — one working, powered level holds it'
                               : 'ZERO-G — give the engines one working, powered level',
            this.gravityActive);
        break;
      }
      case 'piloting': {
        row(`+${pct(Ship.EVADE_PILOT)} evasion per powered level`, pw > 0);
        row('Needs a pilot at the console to dodge, jump or retreat', true);
        row(`Now: +${pct(pw * Ship.EVADE_PILOT)}`, pw > 0);
        break;
      }
      case 'oxygen': {
        const per = OXYGEN.PER_POWER / OXYGEN.BREATHING;
        row(`1 powered level = air for ${per} people`, pw > 0);
        row('A cat breathes half a man, a rat a quarter, a spider nothing', true);
        const mouths = this.crew.filter(c => c && !c.dead && !c.dying && !c.frozen && c.inRoom !== false).length;
        row(`Now: air for ${pw * per} — ${mouths} aboard`, pw * per >= mouths);
        break;
      }
      case 'medbay': {
        const ward = this.wardLevel();
        const C = Ship.CURE_LEVELS;
        row(`Level 1+: heals ${Ship.MEDBAY_HPS} hp/s per powered level, stands the downed up`, ward >= 1);
        row(`Level ${C.plague}+: cures the corpse plague (${Ship.CURE_SECONDS}s in the ward)`, ward >= C.plague);
        row(`Level ${C.virus}+: cures the spider virus (${Ship.CURE_SECONDS}s in the ward)`, ward >= C.virus);
        row(`Now: ward level ${ward} — ${ward * Ship.MEDBAY_HPS} hp/s`, ward > 0);
        break;
      }
      case 'weapons': {
        const i = this.weaponRooms.findIndex(r => r.id === sys.roomId);
        const w = i >= 0 ? this.weapons[i] : null;
        row(w ? `Runs the ${w.label}: it needs ${w.powerCost} power` : 'No gun fitted in this bay', w && pw >= w.powerCost);
        row('Needs a gunner in the bay to charge', true);
        row('Power above the gun\'s cost does nothing', true);
        row('Takes any gun but a missile or torpedo launcher (those: Artillery)', true);
        break;
      }
      case 'artillery': {
        const i = this.weaponRooms.findIndex(r => r.id === sys.roomId);
        const w = i >= 0 ? this.weapons[i] : null;
        row(w ? `Runs the ${w.label}: it needs ${w.powerCost} power` : 'No launcher fitted in this bay', w && pw >= w.powerCost);
        row('The only bay that takes a missile or torpedo launcher', true);
        row('Needs a gunner in the bay to charge', true);
        row(`Magazine: ${this.missileCount()} missile(s), ${this.torpedoCount()} torpedo(es) aboard`, true);
        break;
      }
      case 'carbonite': {
        const slabs = this.carboniteCapacity();
        row('1 slab per powered level — time stops for whoever is in it', pw > 0);
        row('Cut the power and the last one in thaws first', true);
        row(`Now: ${slabs} slab${slabs === 1 ? '' : 's'}`, slabs > 0);
        break;
      }
      case 'cloaking': {
        const d = SYSTEM_DEFS.cloaking;
        (d.cloakLevels ?? []).forEach((L, i) => {
          row(`Level ${i + 1}: ${L.dur}s invisible, then ${L.cd}s to recharge`, pw === i + 1 || (pw > i + 1 && i === d.cloakLevels.length - 1));
        });
        row('Every hit misses while it holds', pw > 0);
        row('Switched off or broken: the charge starts again', true);
        break;
      }
      case 'autorepair': {
        const built = this.builtDrones(), fly = this.activeDrones();
        const per = Math.round(1 / (Ship.AUTOREPAIR_RATE * 0.12));
        row(`One repair drone per level — ${built} built`, built > 0);
        row('Each drone flies to a fire, or to a damaged module, on its own', true);
        row('A fire comes before any repair', true);
        row(`A drone mends a broken level in ~${per}s — two of them are a crewman`, true);
        row(fly > 0 ? `Now: ${fly} of ${built} flying, each on its own module`
                    : 'Nothing flying: a drone needs a working level AND a unit of power', fly > 0);
        break;
      }
      default:
        row(SYSTEM_DEFS[sys.type]?.description ?? '', true);
    }
    return { title: (sys.label || sys.type).toUpperCase(), status, rows };
  }

  /** How long a bandage or a medkit keeps a man's hands full. */
  static get AID_SECONDS() { return 3; }

  /** The least life support any hull flies with (update87). */
  static get O2_MIN_LEVEL() { return 2; }

  /**
   * LIFE SUPPORT FOR THE CREW ABOARD (update87) — enemies and bosses.
   *
   * One pip carries three men (OXYGEN.PER_POWER). A raider with four
   * aboard on a one-pip module suffocated its own crew. Level: enough
   * for the headcount, never under 2, 3 at least for a boss, 4 at most;
   * and the reactor gets the extra pips on top, so buying air does not
   * cost the ship its guns. The PLAYER gets the level-2 floor from the
   * layout and nothing else — his power is his to spend.
   */
  sizeAirForCrew(crewN, { boss = false } = {}) {
    const o2 = this.getSystem('oxygen');
    if (!o2) return 0;
    const want = Utils.clamp(Math.ceil(crewN / 3), boss ? 3 : Ship.O2_MIN_LEVEL, 4);
    o2.level = Math.max(o2.level, want);
    o2.desiredPower = o2.level;
    // The reactor covers every module at full, air included — past the
    // hull's usual cap if it has to. That is the "extra power".
    const need = this.systems.filter(x => x.type !== 'reactor').reduce((a, x) => a + x.maxPower, 0)
               + this.liftPowerNeed();      // update90: and a spare unit for each lift
    const extra = Math.max(0, need - this.reactor.capacity);
    if (extra) {
      this.reactor.maxLevel = Math.max(this.reactor.maxLevel, need);
      this.reactor.level = need;
    }
    this._allocateDefaultPower();
    return extra;
  }

  /** Who gets the reactor first, by module type — lower first. */
  static get POWER_PRIO() {
    return { oxygen:0, piloting:1, shields:2, weapons:3, engines:4, medbay:5, artillery:6 };
  }

  /** Spare reactor units a lift needs to run (update90, pkt 10). */
  static get LIFT_POWER() { return 1; }

  /** What every lift aboard takes together, when they are all lit. */
  liftPowerNeed() {
    return (this.elevators?.shafts?.length ?? 0) * Ship.LIFT_POWER;
  }

  /**
   * THE DEFAULT SPLIT OF THE REACTOR (update90 — the lifts are in it now).
   *
   * Life support and helm first — the starting reactor cannot feed
   * everything, and an unpowered O2 system suffocates. A lift runs only on
   * SPARE power (Ship._powerLifts), and the old default handed every unit
   * to the modules, so every lift on every hull would have stood dark from
   * the start. The player's call, 01.10, for the 8-unit frigate with two
   * lifts: the engines keep their one (she must be able to jump), the LEFT
   * lift gets its unit, and the guns pay for it — 1 of 2. In order:
   *
   *   oxygen, helm, shields  — full
   *   engines                — 1
   *   the leftmost lift      — its unit, kept spare
   *   every weapon module    — 1
   *   weapons, then engines  — full
   *   the other lifts        — their units, left to right
   *   medbay, artillery, the rest — full, by POWER_PRIO
   *
   * Returns `{ power: Map(system → units), liftUnits }` without touching
   * anything; `_allocateDefaultPower` applies it.
   */
  _defaultPowerPlan() {
    const prio = Ship.POWER_PRIO;
    const mods = this.systems.filter(x => x.type !== 'reactor');
    const power = new Map(mods.map(x => [x, 0]));
    let remaining = this.reactor.totalPower;
    let liftUnits = 0;
    const lifts = this.elevators?.shafts?.length ?? 0;
    const upTo = (type, n) => mods.filter(x => x.type === type).forEach(x => {
      const cap = n == null ? x.maxPower : Math.min(n, x.maxPower);
      const add = Math.max(0, Math.min(cap - power.get(x), remaining));
      power.set(x, power.get(x) + add);
      remaining -= add;
    });
    const lift = (count) => {
      for (let i = 0; i < count && liftUnits < lifts * Ship.LIFT_POWER &&
                      remaining >= Ship.LIFT_POWER; i++) {
        liftUnits += Ship.LIFT_POWER;
        remaining -= Ship.LIFT_POWER;
      }
    };
    upTo('oxygen'); upTo('piloting'); upTo('shields');
    upTo('engines', 1);
    lift(1);
    upTo('weapons', 1);
    upTo('weapons'); upTo('engines');
    lift(lifts);
    [...mods].sort((a, b) => (prio[a.type] ?? 9) - (prio[b.type] ?? 9))
      .forEach(x => {
        const add = Math.max(0, Math.min(x.maxPower - power.get(x), remaining));
        power.set(x, power.get(x) + add);
        remaining -= add;
      });
    return { power, liftUnits };
  }

  _allocateDefaultPower() {
    const { power } = this._defaultPowerPlan();
    power.forEach((units, sys) => { sys.power = units; sys.desiredPower = units; });
  }

  /**
   * HER FIRST FLIGHT, THE CORE WITH ROOM TO BREATHE (update208, jj 6.11:
   * "reaktor ~70% tylko na starcie, raz; potem zapisuje się każde ustawienie").
   * The default plan feeds every module to the brim — 83–93% of the core, the
   * band that heats — and a new player does not know to take power off.
   * Units come off until the load is at most `target`: the air (it has its
   * tank), then the shields, the guns, the drive — never below one level of
   * those — and anything else to none. Never the helm, never the lifts.
   * Called once, on a hull's first launch; after that her own setting flies.
   */
  easeFirstFlight(target = 0.7) {
    const floor = (x) => (['oxygen', 'shields', 'weapons', 'engines'].includes(x.type) ? 1 : 0);
    const order = ['oxygen', 'shields', 'weapons', 'engines'];
    const rank = (x) => { const i = order.indexOf(x.type); return i < 0 ? -1 : i; };
    const pool = this.systems.filter(x => x.type !== 'reactor' && x.type !== 'piloting').sort((a, b) => rank(a) - rank(b));
    let guard = 64;
    while (this.reactorLoad > target + 1e-9 && guard-- > 0) {
      const v = pool.find(x => x.power > floor(x));
      if (!v) break;
      v.power -= 1; v.desiredPower = v.power;
    }
    return this.reactorLoad;
  }

  /**
   * A HULL SAVED BEFORE update90 handed every unit to the modules, and
   * would come out of the hangar with every lift dark. Free as many units
   * as the default would keep for lifts on this hull, taken from the
   * modules it feeds LAST — the guns first (the player's call), never
   * life support or the helm, never the engines below the one a jump
   * needs. Once, when it is loaded.
   */
  _reserveLiftPower() {
    const prio = Ship.POWER_PRIO;
    const want = this._defaultPowerPlan().liftUnits;
    const floor = x => (x.type === 'engines' ? 1 : 0);
    const rank = x => x.type === 'weapons' ? -100 : x.type === 'engines' ? 50
                    : x.type === 'shields' ? 60 : -(prio[x.type] ?? 9) - 10;
    const order = this.systems
      .filter(x => x.type !== 'reactor' && x.type !== 'oxygen' && x.type !== 'piloting')
      .sort((a, b) => rank(a) - rank(b));
    let guard = 64;
    while (this.reactor.distribute(this.systems) < want && guard-- > 0) {
      const v = order.find(x => x.power > floor(x));
      if (!v) break;
      v.power -= 1;
      v.desiredPower = v.power;
    }
  }

  /* ══ REACTOR HEAT (update92) — see REACTOR_HEAT_CONFIG ══════ */

  /** What the modules draw, over what the reactor gives (0..1). The lifts'
   *  spare units are not load. A reactor giving nothing has no load. */
  get reactorLoad() {
    const total = this.reactor?.totalPower ?? 0;
    if (total <= 0) return 0;
    const used = this.systems.reduce((a, sys) => a + (sys.type === 'reactor' ? 0 : sys.reactorDraw()), 0);
    return Utils.clamp(used / total, 0, 1);
  }

  /** Heat change per second at this load, after the thermal multiplier. */
  /** The hold's share of the heat (update93c): cores minus coolers. */
  cargoHeatRate() {
    const items = this.cargo?.items ?? [];
    const cores = items.filter(it => it.def?.tag === 'rad').length;
    const cool  = items.filter(it => it.def?.tag === 'cool').length;
    const C = REACTOR_HEAT_CONFIG.cargo;
    return cores * C.corePerSec - cool * C.coolerPerSec;
  }

  reactorHeatRate() {
    if (!this.reactor) return 0;
    return this._loadHeatRate() + this.cargoHeatRate() - this.consoleCoolRate();
  }

  /** The man at the reactor console (update105): his share of cooling. */
  consoleCoolRate() {
    const sys = this.getSystem('reactor');
    if (!sys || sys.roomId == null) return 0;
    return this.consoleOperator(sys.roomId) ? REACTOR_HEAT_CONFIG.consoleCoolPerSec : 0;
  }

  /** The reactor's own heat from its load — the update92 bands. */
  _loadHeatRate() {
    const H = REACTOR_HEAT_CONFIG;
    const r = this.reactor;
    if (!r) return 0;
    if (r.offline || r.totalPower <= 0) return -H.scramCoolPerSec;
    const load = this.reactorLoad, free = 1 - load, eps = 1e-9;
    const up = H.heatBands.find(b => load >= b.load - eps);
    if (up) {
      const mult = (H.thermal.find(t => r.capacity <= t.upTo) ?? H.thermal[H.thermal.length - 1]).mult;
      return up.perSec * mult;
    }
    const down = H.coolBands.find(b => free >= b.free - eps);
    return down ? -down.perSec : 0;
  }

  _heatTick(dt) {
    const H = REACTOR_HEAT_CONFIG;
    if (!this.reactor || this.isPreview) return;
    const before = this.reactorHeat ?? 0;
    let heat = Utils.clamp(before + this.reactorHeatRate() * dt, 0, 100);
    this.reactorHeat = heat;
    const room = this.getRoomById(this.getSystem('reactor')?.roomId);

    // Crossing the lines upward is said once, each time it happens.
    if (this.isPlayer) {
      if (before < H.criticalHeat && heat >= H.criticalHeat && heat < 100) {
        if (typeof UI !== 'undefined') UI.notify('⚠ REACTOR CRITICAL — take power off or it will overheat', 'alert');
        if (typeof Audio !== 'undefined') Audio.sfx?.reactorCritical?.();
      } else if (before < H.warnHeat && heat >= H.warnHeat) {
        if (typeof UI !== 'undefined') UI.notify('Reactor running hot — free some power to cool it', 'warn');
        if (typeof Audio !== 'undefined') Audio.sfx?.reactorWarn?.();
      }
    }

    // OVERHEAT: once, at 100 — then back to 90, so it cannot fire every frame.
    if (heat >= 100) {
      this.reactorHeat = H.overheatResetHeat;
      const sys = this.getSystem('reactor');
      if (sys) sys.damageLevel(H.overheatDamage);
      this._overheatFlashT = 2.5;
      if (room) {
        Particles.explosion?.(room.cx, room.cy, 0.6);
        if (Math.random() < H.overheatFireChance) this.fires.start(room.id, room.cx, room.cy);
      }
      if (this.isPlayer) {
        if (typeof UI !== 'undefined') UI.notify('☢ REACTOR OVERHEAT — a reactor level is gone', 'alert');
        if (typeof Audio !== 'undefined') Audio.sfx?.reactorOverheat?.();
        if (typeof Camera !== 'undefined') Camera.shake?.(6, 0.35);
      }
    }
    if (this._overheatFlashT > 0) this._overheatFlashT -= dt;

    // Fire rolls: on a clock, never per frame.
    this._heatHazardT = (this._heatHazardT ?? 0) + dt;
    while (this._heatHazardT >= H.hazardInterval) {
      this._heatHazardT -= H.hazardInterval;
      const band = H.fireChance.find(b => this.reactorHeat >= b.heat);
      if (band && room && Math.random() < band.p) {
        this.fires.start(room.id, room.cx, room.cy);
        if (this.isPlayer && typeof UI !== 'undefined') UI.notify('The reactor is so hot its room caught fire!', 'alert');
      }
      // Sparks over a hot core — more as it climbs. Drawing only.
      if (room && this.reactorHeat >= H.warnHeat) {
        const n = this.reactorHeat >= H.criticalHeat ? 3 : this.reactorHeat >= 80 ? 2 : 1;
        for (let k = 0; k < n; k++) {
          Particles.repairSparks?.(room.cx + Utils.randFloat(-room.w * 0.35, room.w * 0.35),
                                   room.cy + Utils.randFloat(-10, 10));
        }
      }
    }
  }

  /* ══ THE ENEMY'S HAND ON ITS OWN REACTOR (update93) ══════════
   *
   * Before this the enemy ran everything flat out and overheated in
   * about six minutes — a long fight was won by its own core. It now
   * does what the player is asked to do: watch the bar and take power
   * off. What it takes, in order, is what it needs least —
   *
   *   medbay → cloak → repair bay → engines above 1 → guns (never the
   *   last one powered) → shields above one bar → life support above 1
   *
   * — and it remembers what it took (`_aiShed`), so it gives back the
   * same units, last first, once the core is cool. Only `desiredPower`
   * moves: the flow in `update` does the rest, the same as for a
   * click on the player's bar. */
  _plannedLoad() {
    const total = this.reactor?.totalPower ?? 0;
    if (total <= 0) return 0;
    const used = this.systems.reduce((a, x) => a + (x.type === 'reactor' ? 0
      : x.reactorDraw(Math.max(0, Math.min(x.desiredPower ?? 0, x.workingLevels)))), 0);
    return used / total;
  }

  _aiShedPick() {
    const order = ['medbay', 'cloaking', 'autorepair', 'engines', 'weapons', 'shields', 'oxygen'];
    const floor = (x) => x.type === 'engines' || x.type === 'oxygen' ? 1
                       : x.type === 'shields' ? 2 : 0;
    const guns = this.systems.filter(x => x.type === 'weapons' && (x.desiredPower ?? 0) > 0);
    for (const type of order) {
      const cands = this.systems.filter(x => x.type === type && (x.desiredPower ?? 0) > floor(x))
        .filter(x => !(x.type === 'cloaking' && x.cloakActive))
        .filter(x => !(x.type === 'weapons' && guns.length <= 1));
      if (cands.length) return cands[cands.length - 1];
    }
    return null;
  }

  coolingAI(dt) {
    if (this.isPlayer || this.isDerelict || !this.reactor) return;
    const A = REACTOR_HEAT_CONFIG.ai;
    this._aiShed = this._aiShed ?? [];
    this._aiCoolT = (this._aiCoolT ?? 0) + dt;
    if (this._aiCoolT < A.stepSeconds) return;
    this._aiCoolT = 0;
    const heat = this.reactorHeat ?? 0;
    if (heat >= A.shedAt || (this._aiShed.length && heat > A.restoreAt &&
                             this._plannedLoad() > A.targetLoad + 1e-9)) {
      if (this._plannedLoad() <= A.targetLoad + 1e-9) return;
      const x = this._aiShedPick();
      if (!x) return;
      x.desiredPower -= 1;
      this._aiShed.push(x);
      return;
    }
    if (heat <= A.restoreAt && this._aiShed.length) {
      const x = this._aiShed.pop();
      if (x && this.systems.includes(x)) x.desiredPower = Math.min(x.maxPower, (x.desiredPower ?? 0) + 1);
    }
  }

  /* ── THE ENEMY PUTS ITS POWER BACK (update127, jj: "przeciwnik raz nie
   * miał energii w broni module i nie strzelał") ──────────────────────
   * Units leave a module for reasons that have nothing to do with the
   * AI's wishes: a Terra stepping off a full console takes his +1 with
   * him (update93a) and the module drops a unit; a shot reactor cuts the
   * flow. The PLAYER clicks them back. The enemy never did, so a one-
   * level gun stayed dark for the rest of the fight. Once a second, with
   * the core not being cooled, every spare unit goes back where a
   * captain would want it — guns first. Only `desiredPower` moves. */
  static get ENEMY_POWER_WANT() {
    return ['weapons', 'tractor', 'piloting', 'shields', 'engines', 'oxygen', 'cloaking',
            'medbay', 'autorepair', 'artillery'];
  }

  rePowerAI(dt) {
    if (this.isPlayer || this.isDerelict || !this.reactor) return;
    this._aiPowT = (this._aiPowT ?? 0) + dt;
    if (this._aiPowT < 1) return;
    this._aiPowT = 0;
    if (this._aiShed?.length) return;                          // the cooling AI has the bar
    const A = REACTOR_HEAT_CONFIG.ai;
    if ((this.reactorHeat ?? 0) >= A.restoreAt) return;
    const want = Ship.ENEMY_POWER_WANT;
    const total = this.reactor.totalPower - Math.min(this.reactor.totalPower, this.liftPowerNeed?.() ?? 0);
    const planned = () => this.systems.reduce((a, x) => a + (x.type === 'reactor' ? 0
      : x.reactorDraw(Math.max(0, Math.min(x.desiredPower ?? 0, x.workingLevels)))), 0);
    const mods = this.systems.filter(x => x.type !== 'reactor' && want.includes(x.type))
      .sort((a, b) => want.indexOf(a.type) - want.indexOf(b.type));
    for (const x of mods) {
      while ((x.desiredPower ?? 0) < x.workingLevels) {
        const before = x.desiredPower ?? 0;
        x.desiredPower = before + 1;
        if (planned() > total) { x.desiredPower = before; break; }
      }
    }
    /* A DARK GUN TAKES A UNIT FROM A LUXURY. A small core already full
       of engines and medbay had nothing spare for a gun that came back
       from repair. Never the helm, never a cloak that is up, never life
       support or engines below one, never shields below one bar. */
    const floor = (x) => x.type === 'engines' || x.type === 'oxygen' ? 1 : x.type === 'shields' ? 2 : 0;
    const donors = ['medbay', 'autorepair', 'artillery', 'cloaking', 'engines', 'oxygen', 'shields'];
    this.systems.filter(g => g.type === 'weapons' && (g.desiredPower ?? 0) <= 0 && g.workingLevels > 0)
      .forEach(g => {
        const d = donors.map(t => this.systems.find(x => x.type === t && (x.desiredPower ?? 0) > floor(x)
                                       && !(x.type === 'cloaking' && x.cloakActive))).find(Boolean);
        if (!d) return;
        d.desiredPower -= 1; g.desiredPower = 1;
        if (planned() > total) { g.desiredPower = 0; d.desiredPower += 1; }
      });
  }

  /** How far off the deck a body hangs in zero-G, now (update91). */
  static floatOffset(t, i, down = false) {
    const lift = down ? 2 : 4, bob = down ? 1.2 : 2.2;
    return -lift + Math.sin(t * 2.1 + i * 1.7) * bob;
  }

  /** Dust hanging in the air of every compartment in zero-G (update91). Cheap:
   *  a handful of dots per room, placed by time, nothing simulated. */
  _drawZeroGMotes(ctx, t) {
    ctx.save();
    ctx.fillStyle = 'rgba(200,225,255,0.35)';
    this.rooms.forEach((r, ri) => {
      const top = r.floorTop ?? r.y, h = r.floorH ?? r.h;
      for (let k = 0; k < 4; k++) {
        const ph = ri * 3.1 + k * 2.3;
        const x = r.x + 6 + ((Math.sin(t * 0.21 + ph) * 0.5 + 0.5) * (r.w - 12));
        const y = top + 4 + ((Math.cos(t * 0.17 + ph * 1.3) * 0.5 + 0.5) * (h - 8));
        ctx.fillRect(x, y, 1.5, 1.5);
      }
    });
    ctx.restore();
  }

  /** GRAVITY (update91): the engines have a working level and are running.
   *  Ion-locked engines are not running. No engines, no gravity.
   *
   *  ONE UNIT FROM THE REACTOR, NOT FROM A MAN (update104). jj in a
   *  nebula: their reactor half shot out, the engine pips dark — and their
   *  gravity still on, until the whole core was gone. A Terra cyborg at
   *  their engine console was running the module on his +1, which the
   *  column does not draw. jj's rule: no unit of energy in the engines, or
   *  engines wrecked outright, and the gravity is off. The cyborg still
   *  pushes the ship (evasion, a jump); the gravity wants the reactor. */
  get gravityActive() {
    const e = this.getSystem('engines');
    if (!e || e.workingLevels < 1) return false;
    const fed = Math.min(e.power, e.workingLevels) - (e.ionDamage > 0 ? e.ionDamage : 0);
    return fed >= 1;
  }

  get zeroG() { return !this.gravityActive; }

  /** How fast a body moves aboard, as a fraction of its walk (update91). */
  moveFactor(c) {
    const G = GRAVITY_CONFIG, zg = this.zeroG;
    if (c?.carrying) return zg ? G.zeroGWoundedCarrySpeed : G.normalWoundedCarrySpeed;
    return zg ? G.crewMovementMultiplier : 1;
  }

  /** The repair and breach-patching rates in this ship's gravity (update91). */
  repairFactor() { return this.zeroG ? GRAVITY_CONFIG.normalRepairMultiplier : 1; }
  breachFactor() { return this.zeroG ? GRAVITY_CONFIG.breachRepairMultiplier : 1; }

  /**
   * GRAVITY, ONCE A FRAME (update91): say so when it changes — once, never
   * every frame — and run the hold's two hazard clocks while it is off.
   * The first frame only notes the state: a hull that starts in zero-G (a
   * load, a wreck) is not "losing" gravity.
   */
  _gravityTick(dt) {
    const on = this.gravityActive;
    this.crew.forEach(c => { if (c) c._zeroG = !on; });
    if (this._gravityWas === undefined) { this._gravityWas = on; return; }
    if (on !== this._gravityWas) {
      this._gravityWas = on;
      this._zgDamageT = 0; this._zgLossT = 0;
      if (this.isPlayer && typeof UI !== 'undefined') {
        UI.notify(on ? 'GRAVITY RESTORED' : '⚠ GRAVITY LOST — ZERO-G', on ? 'good' : 'alert');
      }
      if (this.isPlayer && typeof Audio !== 'undefined') {
        on ? Audio.sfx?.gravityOn?.() : Audio.sfx?.gravityOff?.();
      }
      if (on && this.isPlayer && typeof Camera !== 'undefined') Camera.shake?.(3, 0.2);
    }
    if (!on && !this.isPreview) this._zeroGCargoTick(dt);
  }

  /** The hold in zero-G (update91) — see GRAVITY_CONFIG. Timed, not per frame. */
  _zeroGCargoTick(dt) {
    const hold = this.cargo;
    if (!hold) return;
    const G = GRAVITY_CONFIG;
    const say = (m) => { if (this.isPlayer && typeof UI !== 'undefined') UI.notify(m, 'warn'); };

    this._zgDamageT = (this._zgDamageT ?? 0) + dt;
    while (this._zgDamageT >= G.cargoDamageCheckInterval) {
      this._zgDamageT -= G.cargoDamageCheckInterval;
      if (Math.random() >= G.cargoDamageProbability) continue;
      /* An egg case is not on the list: a damaged one does not hatch
         (`_hatchTick` skips it), so damage there would be a cure. */
      const ok = hold.items.filter(it => !it.damaged && it.def?.tag !== 'egg');
      if (!ok.length) continue;
      const it = Utils.pick(ok);
      it.damaged = true;
      say(`CARGO DAMAGED: ${it.label}`);
    }

    const holed = (this.breaches?.breaches ?? []).some(b => !b.sealed);
    if (!holed) { this._zgLossT = 0; return; }
    this._zgLossT = (this._zgLossT ?? 0) + dt;
    while (this._zgLossT >= G.cargoLossCheckInterval) {
      this._zgLossT -= G.cargoLossCheckInterval;
      if (Math.random() >= G.cargoLossProbability) continue;
      if (!hold.items.length) continue;
      const it = Utils.pick(hold.items);
      if (it.isStack && it.qty > 1) it.qty -= 1;
      else hold.remove(it);
      say(`CARGO LOST: ${it.label}`);
      if (this.isPlayer && typeof Audio !== 'undefined') Audio.sfx?.hullBreach?.();
    }
  }

  /**
   * LIFTS RUN ON SPARE POWER (update90, pkt 10). `spare` is what the
   * modules left of the reactor this frame. Each lift takes LIFT_POWER,
   * counting from the LEFT — the player's rule: "pierwsza z lewej dostaje
   * prąd pierwsza". The SAME on a wreck (update90a): it has half a
   * reactor now, and what life support and the engines leave runs its
   * lifts like anybody's (see makeDerelict).
   */
  _powerLifts(spare) {
    const shafts = this.elevators?.shafts ?? [];
    let left = Math.max(0, spare);
    [...shafts].sort((a, b) => a.x - b.x).forEach(s => {
      s.powered = left >= Ship.LIFT_POWER;
      if (s.powered) left -= Ship.LIFT_POWER;
    });
  }

  /** How many lifts are lit right now. */
  liftsPowered() {
    return (this.elevators?.shafts ?? []).filter(s => s.powered !== false).length;
  }

  setPower(systemType, power) {
    const sys = this.getSystem(systemType);
    if (!sys) return;
    this.setPowerAt(this.systems.indexOf(sys), power);
  }

  /** Index-based power control — needed because a ship can carry
   *  SEVERAL systems of the same type (one per weapon module). */
  setPowerAt(sysIndex, power) {
    const sys = this.systems[sysIndex];
    if (!sys || sys.type === 'reactor') return;
    const before = sys.power;
    this.reactor.setPower(sys, power, this.systems);
    sys.desiredPower = sys.power;   // remember intent — restored after repair
    // The last module given power is the first to lose it (update90a).
    if (sys.power > before) sys._powerStamp = (this._powerSeq = (this._powerSeq ?? 0) + 1);
    if (sys.type === 'weapons' || sys.type === 'artillery') this._reallocWeaponPower();
    Audio.sfx.powerUp();
  }

  /**
   * THE POWER FLOW, as one method (update98). It ran only inside
   * `update`, so anything that shrank the reactor between two frames —
   * the nebula's −2 set in `_startCombat` — left one frame where the
   * modules still held the old units and the reactor read "-1/6".
   * Whoever changes the budget can now settle it on the spot, through
   * the same arithmetic the frame uses.
   */
  reflowPower() {
    /* WHO LOSES WHEN THE REACTOR SHRINKS (update90a).
     *
     * Every module asks for its desired power (capped by its working
     * levels). If the reactor cannot pay for all of it, units are taken
     * back from the module that was powered up MOST RECENTLY first —
     * `_powerStamp`, set in setPowerAt — and only then from the end of
     * the list, which is the order the old greedy loop starved them in.
     *
     * The player's report: a Terra cyborg at the reactor console adds a
     * unit; he gives it to the shields; the cyborg walks off — and the
     * shields KEPT it while the medbay at the end of the list went
     * dark. The unit he added is the one that goes now, exactly as a
     * cyborg's +1 leaves the module he walks out of.
     *
     * Cost is counted with ShipSystem.reactorDraw (the cyborg's
     * substitution rule), the same as Reactor.distribute and setPower. */
    const total = this.reactor.totalPower;
    /* THE ENEMY'S LIFTS COME FIRST (update93a). One hit on their
       reactor took the last spare unit, the lift went dark, and a crew
       split across two decks could no longer reach the reactor to fix
       it — a one-shot win. The player's proposal: on their hull the
       lifts keep their units while the core gives anything at all, so
       stopping them means wrecking the whole reactor. The modules pay
       for it. Ours stay as they were — the player decides his split. */
    const liftFirst = this.isPlayer ? 0 : Math.min(total, this.liftPowerNeed());
    const budget = total - liftFirst;
    const mods  = this.systems;
    const want  = mods.map(sys => Math.max(0, Math.min(sys.desiredPower ?? 0, sys.workingLevels)));
    const drawn = () => mods.reduce((a, sys, i) => a + sys.reactorDraw(want[i]), 0);
    /* THE ENEMY KEEPS ITS GUNS (update127). Cut by the stamp of the last
       click — which on the enemy is nobody's, so it was simply the module
       last in the list, often the gun. On their hull the luxuries go
       first and the guns and the helm last. Ours: the player's order. */
    const keep = Ship.ENEMY_POWER_WANT;
    const rank = (i) => keep.includes(mods[i].type) ? keep.indexOf(mods[i].type) : keep.length;
    const order = mods.map((_, i) => i).sort((a, b) => this.isPlayer
      ? (((mods[b]._powerStamp ?? 0) - (mods[a]._powerStamp ?? 0)) || (b - a))
      : ((rank(b) - rank(a)) || (b - a)));
    for (let guard = 256; drawn() > budget && guard > 0; guard--) {
      const i = order.find(k => want[k] > 0);
      if (i == null) break;
      want[i]--;
    }
    mods.forEach((sys, i) => { sys.power = want[i]; });
    this._powerLifts(total - drawn());     // update90: what is left lights the lifts
  }

  availablePower() {
    return this.reactor.distribute(this.systems);
  }

  // ── Damage resolution ────────────────────────────────────

  /**
   * Receive a projectile hit.
   * Returns { absorbed, hullDamage, roomHit }
   */
  receiveHit(proj) {
    const def = proj.def;

    // ACTIVE CLOAK: nothing lands while the field is up. Not a high
    // evasion roll — a guaranteed miss for the whole duration. That is
    // the point of spending a cooldown on it.
    {
      const cl = this.getSystem('cloaking');
      if (cl && cl.cloakActive) {
        Particles.floatText(proj.x, proj.y - 6, 'CLOAKED', '#cc44ff', 12);
        return { absorbed: true, dodged: true, hullDamage: 0 };
      }
    }

    // Evasion dodge — pilot and engine crew gain XP (FTL)
    if (Math.random() < this.evasion) {
      Particles.floatText(proj.x, proj.y - 6, 'MISS', '#8fd4ff', 12);
      Ship._fx({ kind: 'miss', x: proj.x, y: proj.y });
      Audio.sfx.shotMiss();
      const pSys = this.getSystem('piloting');
      if (pSys) pSys._dodge = { t: _motionNow(), dir: Math.random() < 0.5 ? -1 : 1 };   // update242: the helm's yokes swing
      const eSys = this.getSystem('engines');
      const helmHand = pSys ? this.consoleOperator(pSys.roomId) : null;
      const engHand2  = eSys ? this.consoleOperator(eSys.roomId) : null;
      if (helmHand) helmHand.addXP('piloting', XP_RATES.piloting);
      if (engHand2) engHand2.addXP('engines',  XP_RATES.engines);
      return { absorbed: true, dodged: true, hullDamage: 0 };
    }

    // Who ignores shields: it is a property of the GUN now, not a list
    // of type names scattered through the damage code.
    const pierces   = Ship.piercesShields(def);

    // Shield check. A bolt stopped by the bubble strips shieldDamage
    // BARS, not one — that is what makes an ion cannon or a flak burst
    // a shield-breaker rather than a slightly worse laser.
    if (!pierces && this.shieldBars > 0) {
      const shSys = this.getSystem('shields');
      const strip = Math.max(1, def.shieldDamage ?? def.shield_damage ?? 1);
      for (let i = 0; i < strip && this.shieldBars > 0; i++) shSys.hitShield();
      Particles.shieldHit(proj.x, proj.y);
      // the bubble lights up where it was struck (update126); a wave
      // runs out over ITS cells, round the hull (update142)
      Ship._fx({ kind: 'shield', x: proj.x, y: proj.y });
      this.shieldStruck(proj.x, proj.y);
      if (strip > 1) Particles.floatText(proj.x, proj.y - 6, `-${strip} SHIELD`, '#4db8ff', 11);
      this._shieldAlpha = 1;
      Camera.shake(4, 0.15);
      return { absorbed: true, hullDamage: 0, shieldStripped: strip };
    }

    // Damage lands in the room the projectile actually reached.
    // (Previously a random room was picked — targeting was cosmetic
    //  and fires appeared in modules that were never hit.)
    const roomHit =
      this.rooms.find(r => r.contains(proj.x, proj.y)) ||
      this.rooms.find(r => r.contains(proj.targetX, proj.targetY)) ||
      Utils.pick(this.rooms);

    /* EVERY EFFECT IS ITS OWN NUMBER.
       `damage` used to do four jobs at once — hull points, module levels,
       a multiplier on crew injury and, by implication, the breach roll —
       so there was no way to describe a gun that strips shields and
       harms nothing, or one that cuts up crew but leaves modules alone.
       Each one is a separate field on the def now (see WEAPON_DEFS). */
    let dmg = def.hull_damage ?? def.damage ?? 1;
    /* ── A CRITICAL HIT (update173) ────────────────────────────
       The best gunner at the gun rolls his `critChance('weapons')` —
       skill and specialisation. A crit doubles what the bolt does to
       the module and puts one more point through the hull. */
    const ace = (proj.gunners ?? []).filter(g => g && g.alive !== false && g.critChance)
      .sort((a, b) => b.critChance('weapons') - a.critChance('weapons'))[0];
    const critP = ace ? ace.critChance('weapons') : 0;
    const crit = critP > 0 && Math.random() < critP;
    if (crit && dmg > 0) dmg += 1;
    /* ── ARMOUR (update94) ─────────────────────────────────────
       One less on the hull and one less on the module, per point of
       plate; the crew are hurt only by a hit that goes THROUGH — one
       stronger than the plate — and then by half. A basic laser
       rings off a bunker; a missile, a heavy laser, the cannon and the
       torpedo get in. */
    const armor = this.armor ?? 0;
    const rawMod = (def.moduleDamage ?? def.damage ?? 1) * (crit ? 2 : 1);
    let crewShare = 1;
    if (armor > 0) {
      const through = Math.max(dmg, rawMod) > armor;
      crewShare = through ? 0.5 : 0;
      dmg = Math.max(0, dmg - armor);
      if (!through) {
        Particles.floatText(proj.x, proj.y - 6, 'ARMOUR', '#c8d8f0', 11);
        Ship._fx({ kind: 'armour', x: proj.x, y: proj.y });
      }
    }
    this.hull = Math.max(0, this.hull - dmg);

    // Floating damage feedback
    if (roomHit.type === 'reactor' && roomHit.system && dmg > 0) {
      Particles.floatText(roomHit.cx, roomHit.y + 10, `-${dmg} POWER`, '#ffb020', 12);
    } else if (dmg > 0) {
      // a harder hit, a bigger number (update173) — gold when it was a crit
      Particles.floatText(roomHit.cx, roomHit.y + 10, `-${dmg}`, crit ? '#ffb020' : '#ff5566', Math.min(18, 11 + dmg * 2));
    }
    if (crit) Particles.floatText(roomHit.cx + 22, roomHit.y + 4, 'CRIT!', '#ffe36b', 10);

    // Module levels knocked out. 0 means this gun cannot break a module
    // at all, however hard it lands (ion, flak).
    const modDmg = Math.max(0, rawMod - armor);
    const wasWorking = roomHit.system ? (roomHit.system.workingLevels ?? 0) > 0 : false;
    if (roomHit.system && modDmg > 0) roomHit.system.damageLevel(modDmg);
    /* THE MODULE THAT JUST WENT (update173): said over it, and — when it
       was their module and our gun — a blow in the streak. */
    if (wasWorking && roomHit.system.workingLevels <= 0) {
      Particles.floatText(roomHit.cx, roomHit.y + 34, 'WRECKED', '#ff3b4e', 9);
      if (!this.isPlayer && (proj.gunners ?? []).length && typeof CrewTalk !== 'undefined') CrewTalk.noteWreck(roomHit.system, proj.gunners);
    }

    // Crew in the hit room. An explicit [min,max] per weapon, so a flak
    // burst can hurt people without touching the machinery.
    const cd = def.crewDamage ?? [10 * dmg, 25 * dmg];
    if ((cd[1] ?? 0) > 0 && crewShare > 0) {
      let downed = 0;                                   // update180: one shell, how many of theirs
      this.occupantsOf(roomHit.id).forEach(c => {
        const before = c.alive;
        // crewDamage is an inclusive range in WEAPON_DEFS, and the
        // stat chip prints it as one — so roll it as one.
        c.takeDamage(Utils.randIn(cd[0], cd[1]) * crewShare, 'weapons fire');
        // Credit the gunner who actually pulled the trigger — that is
        // what the memorial means by "kills".
        if (before && !c.alive) {
          (proj.gunners ?? []).forEach(g => g.creditKill?.(c));
          // one shot, one blow in the streak, credited to the best gun hand (update173)
          if (ace && typeof CrewTalk !== 'undefined') CrewTalk.noteKill(ace, c, 'weapons');
          else if (proj.gunners?.[0] && typeof CrewTalk !== 'undefined') CrewTalk.noteKill(proj.gunners[0], c, 'weapons');
          if (!c.isPlayer && !c.isPet && (proj.gunners ?? []).some(g => g?.isPlayer)) downed++;
        }
      });
      /* DOUBLE TAP / TRIPLE TAP (update180) — two or three of theirs off one shell */
      if (downed >= 2 && typeof CrewTalk !== 'undefined') CrewTalk.noteMultiKill?.(downed, ace ?? proj.gunners?.[0] ?? null);
    }

    // STUN — the module and everyone in it. One second per ion bolt.
    const stun = def.stunTime ?? (def.type === 'ion' ? 1 : 0);
    if (stun > 0) {
      if (roomHit.system) roomHit.system.ionHit(stun);
      this.occupantsOf(roomHit.id).forEach(c => c.stun?.(stun));
      Particles.floatText(roomHit.cx, roomHit.y + 22, 'STUNNED', '#8fd4ff', 11);
    }

    // Breach chance — per weapon now. It used to be "missiles always,
    // any 2+ hit 25% of the time", which made every heavy laser a hull
    // breacher and gave the designer no way to say otherwise.
    const breachP = def.breachChance ?? (pierces ? 0.5 : dmg >= 2 ? 0.25 : 0);
    if (breachP > 0 && Math.random() < breachP) {
      this.breaches.open(
        roomHit.id,
        roomHit.x + Utils.randFloat(8, roomHit.w - 8),
        roomHit.y + Utils.randFloat(8, roomHit.h - 8)
      );
    }

    // Fire chance — per weapon, 25% unless the def says otherwise
    // (the starting laser is deliberately tamer, see WEAPON_DEFS).
    if (Math.random() < (def.fireChance ?? 0.25)) {
      this.fires.start(roomHit.id, roomHit.cx, roomHit.cy);
    }

    /* EVERY HIT ITS OWN BLAST (update126). This was one orange puff
       for everything that landed — a laser and a torpedo looked the
       same. WeaponArt paints the kind; a hit that harmed the plate
       leaves a scorch on it, and the heavy ones shake the screen
       harder. */
    const kind = (typeof WeaponArt !== 'undefined') ? WeaponArt.hitKind(proj.type, proj.defKey) : null;
    if (kind) {
      Ship._fx({ kind, x: proj.x, y: proj.y });
      if (dmg > 0 || modDmg > 0) Ship._fx({ kind: 'scorch', x: proj.x, y: proj.y });
    } else {
      Particles.explosion(proj.x, proj.y, 0.7);
    }
    Camera.shake(Ship.HIT_SHAKE[kind] ?? 6, 0.2);
    /* …AND HEARD (update172): the same kind of blast, or the ring of a
       bolt off the plate when a gun meant to hurt got nothing through. */
    const rang = armor > 0 && dmg === 0 && modDmg === 0 && (def.hull_damage ?? def.damage ?? 1) > 0;
    Audio.sfx.hullImpact(rang ? 'armour' : (kind || 'laser'), dmg);

    /* THE SECOND DAMAGE NUMBER IS GONE (update40).
       There were two floatText calls for one hit, at the same point:
       the guarded one above (`else if (dmg > 0)`) and an unguarded one
       here. Every laser hit painted two overlapping numbers in two
       sizes, which read as a smeared bold figure — and because ion and
       flak have hull_damage 0, the unguarded one proudly rendered
       "-0" over the room for the two guns whose whole identity is that
       they harm nothing. */
    roomHit._hitFlash = 1;          // drawn by Room.draw, fades out

    /* WHAT THE ENEMY'S 60-SECOND CLOCK LISTENS FOR (update93): a hit
       that reached the player's hull and did something — hull, a module
       level or a man. A miss, a shield bar or an empty ion buzz is not
       harm. */
    /* A rock out of an asteroid field is nobody's shot (update100): it
       must not reset the enemy's 60-second clock as if HE had hit us. */
    if (this.isPlayer && !proj.fromField && (dmg > 0 || (roomHit.system && modDmg > 0) ||
        ((cd[1] ?? 0) > 0 && this.occupantsOf(roomHit.id).length > 0))) {
      Ship.noteHarmToPlayer();
    }

    if (this.hull <= 0) this._beginDestruction();

    return { absorbed: false, hullDamage: dmg, roomHit };
  }

  _beginDestruction() {
    if (this.destroyed) return;
    this.destroyed = false;   // will flip after death animation
    this._deathTimer = 0;
    Audio.sfx.explosion();
    Camera.shake(20, 0.8);
    /* WHOSE HULL JUST WENT (update71). `recordKill` counted ANY ship
       breaking up — including the player's own — so the campaign's
       "enemies killed" went up by one every time he lost. It is the
       enemy's destruction that is a kill, and the same line feeds the
       side objective. */
    if (!this.isPlayer) {
      Save.recordKill();
    }
  }

  // ── Update ───────────────────────────────────────────────

  /* ══ THE DUCTS: RATS, SPIDERS AND THE CAT (update84) ════════
   *
   * `hatchNests` and `verminTick` stood here. Both walked `this.crew`
   * looking for crewmen who were not crewmen, and between them they
   * leant on the room brawl to do the actual killing. The pests have
   * their own list now (`this.pests`, see pests.js), and this is the
   * one tick that runs it: sacs, air, fire, the cat, moving, chewing
   * and the drop. One place, in that order, because each step can end
   * the pest before the next one looks at it.
   */
  pestTick(dt) {
    if (!this.pests.length) return;
    // Anything that stopped moving goes: nobody holds a service for a rat.
    this.pests = this.pests.filter(p => !p.dead);
    this._hatchTick(dt);
    this.pests.forEach(p => {
      if (!p.alive) return;
      p.anim?.update?.(dt);
      if (this._pestHazards(p, dt)) return;       // it died of the ship
      if (this._pestVsCat(p, dt)) return;         // cornered, or killed
      this._pestMove(p, dt);
      if (p.isRat && this._ratLife(p, dt)) return;   // starved
      this._pestDrop(p, dt);
    });
    this.pests = this.pests.filter(p => !p.dead);
  }

  /** Put a pest in a duct. `roomId` and `x` are the caller's to set. */
  addPest(pest) {
    if (!pest || this.pests.includes(pest)) return pest;
    if (pest.roomId == null) {
      const room = Utils.pick(this.rooms);
      pest.roomId = room?.id ?? null;
      pest.x = room ? room.cx : 0;
    }
    this.pests.push(pest);
    return pest;
  }

  /** The living pests in one compartment's duct. */
  pestsIn(roomId) {
    return this.pests.filter(p => p.alive && p.roomId === roomId);
  }

  /** Who a spider in `roomId`'s duct can drop on: a person standing below. */
  _pestVictims(roomId) {
    return this.crew.filter(c => c && c.isPlayer && c.alive && !c.isPet &&
      !c.frozen && !c.isPrisoner && c.inRoom !== false && c.roomId === roomId);
  }

  /**
   * EGG SACS SPLIT ONCE THERE IS PREY ABOARD (moved from hatchNests).
   *
   * Anyone standing under a sac sets it off six times faster; the rest
   * hatch on their own stagger, so a boarding party can never be stuck
   * unable to finish because one sac sits over a room nobody visits.
   */
  _hatchTick(dt) {
    const sacs = this.pests.filter(p => p.dormant && !p.dead);
    if (!sacs.length) return 0;
    const intruders = this.crew.filter(c => c.isPlayer && !c.dead && !c.down && !c.isPet);
    if (!intruders.length) return 0;      // still nobody aboard

    let hatched = 0;
    sacs.forEach(sac => {
      const inRoom = intruders.some(p => p.roomId === sac.roomId);
      /* WALKING IN IS HOW YOU FIND THEM. A sac is invisible until
         somebody is in the room under it — the wreck reads as empty
         and the nests are something you discover. */
      if (inRoom) sac.revealed = true;
      /* THE CAT SMELLS THEM THROUGH THE BULKHEAD (update45). One room
         of warning, revealed WITHOUT speeding it up — knowing is not
         the same as disturbing. */
      if (!sac.revealed) {
        const nearCat = this.crew.some(c => c.isPet && c.alive &&
          (c.roomId === sac.roomId ||
           this.adjacentThermal(c.roomId).some(a => a.room?.id === sac.roomId)));
        if (nearCat) {
          sac.revealed = true;
          sac.sensedByCat = true;
        }
      }
      sac.hatchT -= dt * (inRoom ? 6 : 1);
      if (sac.hatchT <= 0 && sac.hatch()) {
        hatched++;
        Particles.burst?.(sac.x, this.getRoomById(sac.roomId)?.ventY ?? 0, '#9fff7a', 14);
      }
    });
    if (hatched && typeof UI !== 'undefined') {
      UI.notify?.(`${hatched} egg sac${hatched > 1 ? 's' : ''} just split open in the ducts!`, 'alert');
      Audio.sfx?.bossWarning?.();
    }
    return hatched;
  }

  /**
   * WHAT THE SHIP ITSELF DOES TO A PEST: air and fire.
   *
   * VACUUM kills a rat and nothing else — a rat has no bottle, so it
   * starts dying the moment its compartment is empty, at the rate a
   * man does once his bottle is dry. The spider has no lungs and does
   * not care. The duct shares the compartment's air in this package;
   * the duct emptying FIRST is update85 (U11).
   *
   * FIRE in the module below reaches the duct, because the duct is its
   * ceiling — at the rate it burns a man. It is the only thing besides
   * the cat that kills a spider. (A fire burning INSIDE the duct, and
   * spreading along it, is update85 as well.)
   *
   * Returns true when the pest died of it.
   */
  _pestHazards(p, dt) {
    if (p.breathes()) {
      /* The DUCT's air, not the room's (update85): the two empty in
         different orders now — see OXYGEN.DUCT_THIN. */
      const ro = this.oxygen?.getRoom?.(p.roomId);
      /* A BREATH HELD (update86b). It used to start dying the instant
         the duct was dry, which made a rat far easier to kill than a man
         in a suit; it holds a normal suit's worth now, and gets it back
         as fast as a suit refills once there is air again. */
      const T = RAT_TUNING;
      /* Thinner than ROOM_EMPTY is no air (update90) — the vent network
         empties a duct ever more slowly and would never quite reach 0. */
      const dry = ro && ro.duct <= OXYGEN.ROOM_EMPTY;
      if (ro && !dry && typeof SUIT_AIR !== 'undefined') {
        p.air = Math.min(T.AIR_SECONDS, (p.air ?? T.AIR_SECONDS) + SUIT_AIR.REFILL_PER_SEC * dt);
      } else if (dry && (p.air = Math.max(0, (p.air ?? T.AIR_SECONDS) - dt)) <= 0 &&
                 typeof SUIT_AIR !== 'undefined') {
        if (p.takeDamage(SUIT_AIR.DAMAGE_PER_SEC * dt, 'vacuum')) {
          this._pestDied(p, `A ${p.label.toLowerCase()} suffocated in the duct.`);
          return true;
        }
      }
    }
    // The duct burning, not the room (update85): it catches a few
    // seconds after the module does, and not at all without air.
    if (this.fires?.ductBurning?.(this, p.roomId) && typeof FIRE_DEFS !== 'undefined') {
      if (p.takeDamage(FIRE_DEFS.CREW_DAMAGE * dt, 'fire')) {
        this._pestDied(p, `A ${p.label.toLowerCase()} burned in the duct.`);
        return true;
      }
    }
    return false;
  }

  _pestDied(p, line) {
    const cat = p._catId ? this.crew.find(c => c && c.id === p._catId) : null;
    if (cat) this._catLetGo(cat);
    p._catId = null;
    const room = this.getRoomById(p.roomId);
    if (room) Particles.floatText?.(p.x, room.ventY, '✕', '#ffd780', 10);
    if (this.isPlayer && line && typeof UI !== 'undefined') UI.notify?.(line, 'good');
  }

  /* ── THE CAT GOES UP AFTER IT ─────────────────────────────
   *
   * This was the room brawl: the cat walked in, the rat was hostile
   * crew in the same room, and CrewMember.update did the rest. There is
   * no brawl in a duct, so this IS the fight — and it is the only one
   * a pest ever loses to something alive.
   *
   * She takes it when she is standing in the room under it and has
   * stopped walking. From then on the pest is HELD: it does not crawl
   * off and it does not drop on anybody, and a spider bites back. She
   * is drawn up in the duct with it (CrewMember.draw reads `_ductY`),
   * because a fight the player cannot see is not one he knows is on.
   *
   * Returns true while the pest is held (or has just been killed).
   */
  _pestVsCat(p, dt) {
    if (p._climb) return false;          // in the shaft: nobody can reach it there
    let cat = p._catId ? this.crew.find(c => c && c.id === p._catId) : null;
    if (cat && !(cat.alive && cat.roomId === p.roomId && !cat._waypoints?.length && !cat.busy)) {
      this._catLetGo(cat);
      p._catId = null;
      cat = null;
    }
    if (!cat) {
      // A fed cat walks under it and leaves it be (update90b).
      const fed = (c) => typeof HUNGER !== 'undefined' && (c.hunger ?? 0) >= HUNGER.FED;
      cat = this.crew.find(c => c && c.isPet && c.alive && !c.busy && !fed(c) &&
        c.roomId === p.roomId && c.inRoom !== false &&
        !c._waypoints?.length && !c._ductPestId);
      if (!cat) return false;
      p._catId = cat.id;
      p._via = null; p._tx = null; p._pounce = null;
      p._biteBackT = 0;
      cat._ductPestId = p.id;
      cat._facing = (p.x >= cat.x) ? 1 : -1;
    }
    const room = this.getRoomById(p.roomId);
    cat._ductY = room ? Pest.ductFloor(room) - Pest.FEET : null;
    cat.x = Utils.clamp(p.x - 10 * (cat._facing || 1), room ? room.x + 8 : cat.x,
                        room ? room.x + room.w - 8 : cat.x);
    cat._setAnim?.('fight');
    p._setAnim('fight');

    if (cat.attackTimer?.tick(dt)) {
      if (p.takeDamage(cat.meleeDamage(), 'cat')) {
        this._catCaught(cat, p);
        return true;
      }
    }
    if (p.isSpider) {
      p._biteBackT += dt;
      if (p._biteBackT >= PEST_TUNING.BITE_BACK_EVERY) {
        p._biteBackT = 0;
        cat.takeDamage(p.biteDamage(), 'spider');
        Particles.floatText?.(cat.x, (cat._ductY ?? cat.y) - 10, 'BITTEN', '#9fff7a', 10);
        if (!cat.alive) {
          this._catLetGo(cat);
          p._catId = null;
          if (this.isPlayer && typeof UI !== 'undefined') {
            UI.notify?.(`${cat.name} went up after a spider and did not come back down.`, 'alert');
          }
        }
      }
    }
    return true;
  }

  /** She comes back down to the deck — the fight is over either way. */
  _catLetGo(cat) {
    if (!cat) return;
    cat._ductPestId = null;
    cat._ductY = null;
    cat._setAnim?.('idle');
  }

  /**
   * A CAT EATS WHAT IT CATCHES (update45) — moved here from
   * CrewMember.creditKill, which was the brawl's choke point and is
   * not where a cat kills anything any more. The notch on her record is
   * the same `kills` the memorial reads, so no second tally.
   */
  /** What a caught pest is worth to the cat (update90b, HUNGER.PREY). */
  static preyFood(p) {
    const P = HUNGER.PREY;
    if (p.isSpider) return P.spider;
    return P.rat[Utils.clamp((p.level ?? 1) - 1, 0, P.rat.length - 1)];
  }

  _catCaught(cat, p) {
    this._catLetGo(cat);
    p._catId = null;
    cat.kills = (cat.kills ?? 0) + 1;
    if (typeof HUNGER !== 'undefined') {
      const food = Ship.preyFood(p);
      cat.hunger = Utils.clamp((cat.hunger ?? 0) + food.hunger, 0, 100);
      cat.hp     = Math.min(cat.maxHp, cat.hp + food.hp);
    }
    const room = this.getRoomById(p.roomId);
    if (room) Particles.floatText?.(p.x, room.ventY, 'CAUGHT', '#ffc861', 10);
    if (this.isPlayer && typeof UI !== 'undefined') {
      UI.notify?.(`${cat.name} caught the ${p.label.toLowerCase()}.`, 'good');
    }
  }

  /**
   * WHERE A PEST CAN GO FROM A DUCT (update86a).
   *
   * Sideways: `Room.adjacent`, the U9 network — the rooms beside it on
   * its own deck. Up and down: the LIFT SHAFT. The player's call, 29.09:
   * "mamy winde wiec beda uzywac tego jako szyb". A room whose end wall
   * is on a shaft links, through that shaft, to the room on the deck
   * above and the deck below that also back onto it — one deck per hop,
   * so the graph stays as local as the sideways one. (update84 measured
   * that `adjacent` has no link between decks on any hull; this is that
   * link, and it is the shaft.)
   *
   * Worked out once per hull and kept: rooms and shafts do not move.
   */
  ductLinks(roomId) {
    if (!this._ductLinkMap) {
      const map = new Map();
      const add = (a, link) => { if (!map.has(a)) map.set(a, []); map.get(a).push(link); };
      this.rooms.forEach(r => (r.adjacent ?? []).forEach(id => {
        const to = this.getRoomById(id);
        if (to) add(r.id, { room: to, shaft: null });
      }));
      (this.elevators?.shafts ?? []).forEach(sh => {
        const top = sh.extentTop ?? sh.topY ?? -Infinity;
        const bot = sh.extentBottom ?? sh.bottomY ?? Infinity;
        // The rooms whose end wall is on this shaft, one side or the other.
        const onIt = this.rooms.filter(r =>
          (Math.abs(r.x + r.w - sh.x) <= Ship.SHAFT_REACH || Math.abs(r.x - sh.x) <= Ship.SHAFT_REACH) &&
          r.y + r.h > top && r.y < bot);
        onIt.forEach(a => {
          const side = Math.sign(a.cx - sh.x);
          const decks = onIt.filter(b => b.floor !== a.floor && Math.sign(b.cx - sh.x) === side);
          [a.floor - 1, a.floor + 1].forEach(f => {
            const b = decks.find(r => r.floor === f);
            if (b) add(a.id, { room: b, shaft: sh });
          });
        });
      });
      this._ductLinkMap = map;
    }
    return this._ductLinkMap.get(roomId) ?? [];
  }

  /** How far from a shaft's centre line a room's end wall may be and still open onto it. */
  static get SHAFT_REACH() { return 20; }

  /**
   * ALONG THE DUCT, AND THROUGH IT INTO THE NEXT ONE.
   *
   * It crawls to the end of its own duct facing the way it is going
   * and comes out at the near end of the next. A deck change goes the
   * same way, with the climb in the middle: to the end wall on the
   * shaft, up or down the shaft (drawn there, head first — `_climb`),
   * and out into the other deck's duct at the same wall.
   *
   * A spider goes where the people are: if the room it is over has
   * nobody in it and a neighbour does — beside it or up the shaft —
   * that is the way it goes.
   */
  _pestMove(p, dt) {
    if (p._pounce) return;
    if (p._climb) { this._pestClimb(p, dt); return; }
    const room = this.getRoomById(p.roomId);
    if (!room) return;
    const E = Pest.EDGE;

    /* A SPIDER WITH SOMEBODY UNDER IT STAYS. It went where the people
       are to drop on them; wandering off to a random neighbour first
       raced the move clock (8-18 s) against the drop clock (6-14 s) and
       lost about half the time, so a man could stand under one for
       twenty seconds and never be touched. */
    if (p._tx == null && p.isSpider && this._pestVictims(room.id).length) {
      p._setAnim('idle');
      return;
    }
    if (p._tx == null) {
      p._moveT -= dt;
      if (p._moveT <= 0) {
        p._moveT = Utils.randFloat(PEST_TUNING.MOVE_MIN, PEST_TUNING.MOVE_MAX);
        const next = this.ductLinks(room.id);
        let go = null;
        if (p.isSpider && !this._pestVictims(room.id).length) {
          go = next.find(l => this._pestVictims(l.room.id).length) || null;
        }
        if (!go && next.length) go = Utils.pick(next);
        if (go) {
          p._via = go.room.id;
          p._viaShaft = go.shaft;
          const toward = go.shaft ? go.shaft.x : go.room.cx;
          p._tx = toward >= room.cx ? room.x + room.w - E : room.x + E;
        } else {
          p._tx = Utils.randFloat(room.x + E, room.x + room.w - E);   // a turn in its own duct
        }
      } else {
        p._setAnim('idle');
        return;
      }
    }

    const step = p.def.speed * dt;
    const d = p._tx - p.x;
    p._facing = d >= 0 ? 1 : -1;
    p._setAnim('walk');
    if (Math.abs(d) > step) { p.x += Math.sign(d) * step; return; }
    p.x = p._tx;
    p._tx = null;
    if (p._via != null) {
      const to = this.getRoomById(p._via);
      const shaft = p._viaShaft;
      p._via = null; p._viaShaft = null;
      if (to && shaft) {
        const y0 = Pest.ductFloor(room), y1 = Pest.ductFloor(to);
        p._climb = { x: shaft.x, y0, y1, t: 0, dur: Math.abs(y1 - y0) / p.def.speed, to: to.id,
                     exitX: to.cx < shaft.x ? to.x + to.w - E : to.x + E };
        p._setAnim('walk');
        return;
      }
      if (to) {
        p.roomId = to.id;
        p.x = room.cx < to.cx ? to.x + E : to.x + to.w - E;
      }
    }
    p._setAnim('idle');
  }

  /** Up or down the shaft, and out into the other deck's duct. */
  _pestClimb(p, dt) {
    const c = p._climb;
    c.t += dt;
    p._setAnim('walk');
    if (c.t < c.dur) return;
    p._climb = null;
    p.roomId = c.to;
    p.x = c.exitX;
    p._setAnim('idle');
  }

  /**
   * CAN THE PLAYER SEE INTO THIS DUCT (update86a)?
   *
   * The player's rule, 29.09: rats, spiders and eggs are seen only in a
   * compartment where one of his people — or the cat — is standing.
   * What they DO is still reported (the chewed loom, the split sac):
   * the body is hidden, the consequence is not.
   */
  pestVisible(roomId) {
    return this.crew.some(c => c && (c.isPlayer || c.isPet) && c.alive && !c.frozen &&
                               c.inRoom !== false && c.roomId === roomId);
  }

  /**
   * A RAT'S LIFE (update86, U10B) — see RAT_TUNING for the table.
   *
   * It gets hungry, it eats from the hold (the ONE chooser, `mealFor`,
   * so an egg goes first and then the worst box), and each meal grows
   * it: young → breeding → adult, with a litter on the way. An ADULT
   * with nothing aboard it will eat chews the loom under it — a whole
   * level off the module, slowly. The old three-second short, and the
   * rule that it only happened in a fight, went: the player's rule is
   * that food in the hold is what keeps the cables whole, so the hold
   * is the switch, not the battle.
   *
   * Returns true if it starved to death this tick.
   */
  _ratLife(rat, dt) {
    const T = RAT_TUNING;
    rat.fullness = Math.max(0, (rat.fullness ?? 100) - T.HUNGER_PER_SEC * (rat.metab ?? 1) * dt);

    // Long, slow starvation: a point of hide every half a minute.
    if (rat.fullness <= 0) {
      rat._starveT = (rat._starveT ?? 0) + dt;
      if (rat._starveT >= T.STARVE_EVERY) {
        rat._starveT = 0;
        if (rat.takeDamage(1, 'starvation')) {
          this._pestDied(rat, 'A rat starved to death in the ducts.');
          return true;
        }
      }
    } else {
      rat._starveT = 0;
    }

    if (rat.fullness < T.EAT_BELOW) this._ratEat(rat);

    // THE RULE: nothing chews while there is something to eat.
    const hungryForWire = !this._ratFood(rat);
    if (rat.level >= 3 && hungryForWire) this._ratAct(rat, dt);
    else rat._chewT = null;
    if (rat.level === 2 && hungryForWire) this._ratShort(rat, dt);
    else rat._shortT = null;
    return false;
  }

  /**
   * AN ADULT'S MOVE (update89). The player: "dorosłe szczury też nieraz
   * wyskakują na gracza, a nieraz psują moduł". One clock per rat, each
   * started at its own random point, and when it runs out a coin: a
   * hungry rat with a man in the room below drops on him (DROP_SHARE of
   * the time), otherwise it chews the loom.
   */
  _ratAct(rat, dt) {
    const T = RAT_TUNING;
    rat._chewT = (rat._chewT ?? Utils.randFloat(T.CHEW_MIN, T.CHEW_MAX)) - dt;
    if (rat._chewT > 0) return false;
    rat._chewT = Utils.randFloat(T.CHEW_MIN, T.CHEW_MAX);
    const below = this._pestVictims(rat.roomId);
    if (below.length && this._ratAngry(rat) && Math.random() < T.DROP_SHARE) {
      this._startDrop(rat, Utils.pick(below));
      return true;
    }
    return this._ratChewNow(rat);
  }

  /**
   * A BREEDING RAT SHORTS THE LOOM IN A FIGHT (update89) — the old
   * pre-update86 bite, back for the middle size: the module under it is
   * dead for a few seconds (the ion path), the men in it stunned. Only
   * with nothing to eat, like every other thing a rat does to wiring.
   */
  _ratShort(rat, dt) {
    const T = RAT_TUNING;
    rat._shortT = (rat._shortT ?? Utils.randFloat(T.SHORT_MIN, T.SHORT_MAX)) - dt;
    if (rat._shortT > 0) return false;
    rat._shortT = Utils.randFloat(T.SHORT_MIN, T.SHORT_MAX);
    const fighting = (typeof CombatManager !== 'undefined') && (CombatManager.isActive?.() ?? false);
    const room = this.getRoomById(rat.roomId);
    const sys = room?.system;
    if (!fighting || !sys || sys.stunLeft > 0) return false;
    sys.ionHit(T.SHORT_SECONDS, sys.level);   // a shorted loom: the whole module, as before
    this.occupantsOf(room.id).forEach(c => c.stun?.(T.SHORT_SECONDS));
    Particles.floatText?.(room.cx, room.y + 22, 'SHORTED', '#ffd780', 11);
    if (this.isPlayer) Audio.sfx.ratChew?.();
    if (this.isPlayer && typeof UI !== 'undefined') {
      UI.notify(`Something shorted the ${sys.label} loom — it is dead for ${T.SHORT_SECONDS}s!`, 'alert');
    }
    return true;
  }

  /** What a rat in this duct would eat next, or null. */
  _ratFood(rat) {
    const sac = this.pests.find(q => q !== rat && q.dormant && !q.dead && q.roomId === rat.roomId);
    return sac || this.mealFor(rat);
  }

  /** One meal: a sac in its own duct, else the hold, egg first. */
  _ratEat(rat) {
    const meal = this._ratFood(rat);
    if (!meal) return false;
    if (meal instanceof Pest) {
      meal.takeDamage(meal.hp + 1, 'rat');         // a sac, eaten where it lay
      this._pestDied(meal, null);
    } else {
      const isEgg = meal.def?.tag === 'egg';
      // One unit out of a stack, exactly as a man eats — see _finishMeal.
      if (!isEgg && (meal.qty ?? 0) > 1) meal.qty--;
      else this.cargo.remove(meal);
      if (this.isPlayer && typeof UI !== 'undefined') {
        UI.notify(isEgg ? 'Something in the ducts got at a spider egg.'
                        : `Something in the ducts got into the ${meal.def?.label ?? 'rations'}.`,
                  isEgg ? 'info' : 'warn');
      }
    }
    rat.fullness = Math.min(100, rat.fullness + RAT_TUNING.MEAL);
    this._ratGrow(rat);
    return true;
  }

  /** Every meal grows it; from breeding age on, every meal is a litter
   *  as well — the ADULT's too (update86b, the player: "dorosły też
   *  powinien się rozmnażać po zjedzeniu porcji"). MAX_ABOARD is what
   *  stops it. */
  _ratGrow(rat) {
    if (rat.level >= 2) this._ratLitter(rat);
    rat.growUp();
  }

  _ratLitter(rat) {
    const T = RAT_TUNING;
    const room = this.getRoomById(rat.roomId);
    const aboard = this.pests.filter(q => q.isRat && q.alive).length;
    const n = Math.min(Utils.randInt(T.LITTER_MIN, T.LITTER_MAX + 1), T.MAX_ABOARD - aboard);
    if (!room || n <= 0) return 0;
    for (let i = 0; i < n; i++) {
      const pup = this.addPest(new Pest({
        kind: 'rat', level: 1, roomId: room.id,
        fullness: Utils.randFloat(T.PUP_FULL_MIN, 100),   // not one belly for the litter
        x: Utils.clamp(rat.x + Utils.randFloat(-12, 12),
                       room.x + Pest.EDGE, room.x + room.w - Pest.EDGE),
      }));
      pup._moveT = Utils.randFloat(2, 6);         // they scatter
    }
    if (this.isPlayer && typeof UI !== 'undefined') {
      UI.notify(`Squeaking in the ducts over the ${room.system?.label ?? 'deck'} — a litter of ${n}.`, 'alert');
    }
    return n;
  }

  /** The chew itself: a level off the module under it. */
  _ratChewNow(rat) {
    const room = this.getRoomById(rat.roomId);
    const sys = room?.system;
    if (!sys || sys.damagedLevels >= sys.level) return false;
    sys.damageLevel(1);
    Particles.floatText?.(room.cx, room.y + 22, 'CHEWED', '#ffd780', 11);
    if (this.isPlayer) Audio.sfx.ratChew?.();
    if (this.isPlayer && typeof UI !== 'undefined') {
      UI.notify(`Something chewed through the ${sys.label} loom — it lost a level.`, 'alert');
    }
    return true;
  }

  /**
   * THE SPIDER DROPS, BITES AND GOES BACK UP (U10A, the player's rule).
   *
   * "Pająk czasem wyskakuje z wentylacji i atakuje załoganta. Szczur
   * nigdy." It is the one time a pest touches a person, and the man it
   * bites cannot hit back: by the time he turns round it is in the
   * duct again. The bite is the old one — damage, and the same odds of
   * the virus the room brawl rolled in CrewMember.strike.
   */
  /**
   * …AND SINCE update86 A HUNGRY ADULT RAT DOES IT TOO, rarely: the
   * player's "szczury rzadko atakują załogantów", which U10B had as
   * "agresywny NA GŁODZIE". Only an adult, only with nothing in the hold
   * it could eat, only when it is hungry — and no virus, a rat is not a
   * spider. One drop, two kinds of bite.
   */
  _pestDrop(sp, dt) {
    if (sp._climb) return;               // it cannot drop out of a lift shaft
    if (sp._pounce) {
      const P = sp._pounce;
      P.t += dt;
      const victim = this.crew.find(c => c && c.id === P.victimId);
      if (!P.bitten && P.t >= PEST_TUNING.POUNCE_SECONDS / 2) {
        P.bitten = true;
        if (victim && victim.alive && victim.roomId === sp.roomId) {
          /* AN ATTEMPT, NOT A CERTAINTY (update89). A man can twist
             away: BITE_HIT of the drops land, the rest miss. */
          if (Math.random() >= PEST_TUNING.BITE_HIT) {
            Particles.floatText?.(victim.x, victim.y - 18, 'MISSED', '#8fa0b8', 11);
          } else if (sp.isSpider) this._spiderBite(sp, victim);
          else this._ratBite(sp, victim);
        }
      }
      if (P.t >= PEST_TUNING.POUNCE_SECONDS) sp._pounce = null;
      return;
    }
    // A rat's drop is one of the moves on its own clock — `_ratAct`.
    if (sp.isRat) return;
    const below = this._pestVictims(sp.roomId);
    if (!below.length) return;
    const lo = PEST_TUNING.POUNCE_MIN, hi = PEST_TUNING.POUNCE_MAX;
    sp._pounceT = (sp._pounceT ?? Utils.randFloat(lo, hi)) - dt;
    if (sp._pounceT > 0) return;
    sp._pounceT = Utils.randFloat(lo, hi);
    this._startDrop(sp, Utils.pick(below));
  }

  /** Down out of the duct onto one man. */
  _startDrop(sp, victim) {
    sp._tx = null; sp._via = null;
    sp.x = victim.x;
    sp._pounce = { t: 0, victimId: victim.id, bitten: false };
    sp._setAnim('fight');
  }

  /** Adult and hungry: the only rat that bites.
   *  "…and nothing aboard to eat" needs no clause of its own: a rat
   *  with food in reach eats first (`_ratLife`), and a meal puts it far
   *  above HUNGRY. The first break run proved it — the clause could be
   *  deleted and nothing changed — so it was. */
  _ratAngry(rat) {
    return rat.level >= 3 && rat.fullness < RAT_TUNING.HUNGRY;
  }

  _ratBite(rat, victim) {
    victim.takeDamage(RAT_TUNING.BITE, 'rat');
    Particles.floatText?.(victim.x, victim.y - 18, 'BITTEN', '#b3a189', 12);
  }

  _spiderBite(sp, victim) {
    victim.takeDamage(sp.biteDamage(), 'spider');
    Particles.laserHit?.(victim.x, victim.y - 10);
    if (!victim.virus && !victim.dead && Math.random() < SPIDER_INFECT_CHANCE) {
      victim.virus = true;
      victim.virusT = VIRUS_SECONDS;
      Particles.floatText?.(victim.x, victim.y - 18, 'BITTEN', '#9fff7a', 13);
      if (typeof UI !== 'undefined') {
        UI.notify?.(`${victim.name} was bitten — something got into the wound.`, 'alert');
      }
    }
  }

  /* ── A WRECK IS SEARCHED, NOT CLEARED (update84) ──────────
   *
   * A derelict's hold used to open when the last spider on it was dead.
   * The spiders are in the ducts now and nobody in a boarding party can
   * reach one, so that condition could never come true. The player's
   * call: the hold is yours once your people have been into every
   * compartment. The spiders' part is what they do on the way round.
   */
  searchTick() {
    if (!this.isDerelict) return;
    this._searched = this._searched ?? new Set();
    this.crew.forEach(c => {
      if (c && c.isPlayer && c.alive && !c.isPet && c.inRoom !== false && c.roomId != null) {
        this._searched.add(c.roomId);
      }
    });
  }

  /** Has somebody stood in every compartment of this hulk? */
  searchedAll() {
    if (!this.isDerelict || !this.rooms.length) return false;
    const s = this._searched;
    return !!s && this.rooms.every(r => s.has(r.id));
  }

  isSearched(roomId) { return !!this._searched?.has(roomId); }

  /* ── Casualty clocks (update42) ──────────────────────────
     Every one of these used to be an inline literal buried in
     _updateBodies, and two of them didn't exist at all. */
  /** Seconds a corpse lies aboard before it starts to rot. */
  static get DECAY_SECONDS() { return 40; }
  /** Seconds a DOWNED crew member has before they bleed out. */
  static get BLEEDOUT_SECONDS() { return 40; }
  /* ── THE PRICE LIST OF A BOX OF SUPPLIES (update78) ────────
   *
   * `FIELD_AID_HPS` DELETED. A bandage does not restore hit points any
   * more, so an HP-per-second for it was a number describing something
   * that no longer happens — and the medbay's own rate, three times
   * larger, is the one that heals.
   *
   * One box, two prices, and the automatic one is the cheap one so
   * that the expensive one stays a decision. */
  /** HP/s per unit of power a medbay restores — the only thing aboard
   *  that heals past the point a man stands up. */
  static get MEDBAY_HPS()   { return 6; }
  static get AID_DOSES()    { return 1; }   // stop the bleeding
  static get MEDKIT_DOSES() { return 2; }   // …and get him up
  /** What a medkit puts him back on his feet at, as a share of max. */
  static get MEDKIT_SHARE() { return 0.30; }
  /** Infection chance per second, sharing a room with a rotting body. */
  static get PLAGUE_RATE_ROOM() { return 0.05; }
  /** …and anywhere else on the ship, carried by the air handlers. */
  static get PLAGUE_RATE_VENT() { return 0.008; }
  /** Through the ducts (update93a), by hops from the rotting room:
   *  next door, two away, further. Anything the ducts do not reach
   *  falls back to PLAGUE_RATE_VENT. */
  static get PLAGUE_VENT_RATES() { return [0.03, 0.02, 0.012]; }
  /** How long a bearer waits with a body when every hatch is shut. */
  static get CORPSE_HOLD_SECONDS() { return 6; }

  /* ── WHERE THE TWO HULLS STAND IN A FIGHT (update73) ──────
   *
   * Written out FOUR times in game.js before this — `180, 180` at
   * three places where the player's hull is built or loaded, and
   * `850, 200` where the enemy is spawned. Four literals for two
   * positions, and every one of them needed the same correction when
   * the module got wider, which is four chances to correct three.
   *
   * MEASURED, not chosen. The widest player hull and the widest enemy
   * hull are 520px each and the canvas is 1280, so 240px is all there
   * is to divide. The orders panel on the left ends around x=120 and
   * the hull may not sit on top of it, which fixes the left margin at
   * about 140 and leaves 100 to split between the gap the shells
   * cross and the right-hand edge. 70 and 30.
   *
   * The enemy came in from 850, where he no longer fitted: at four
   * columns his stern ran eighty pixels off the right of the screen.
   */
  /* Further apart (update121): the engines moved off the sterns onto
     the top and the underside, so each hull needs about 30 px less at
     its outer end — and that room went to the gap the shells cross.
     The player's nozzles still clear the orders panel (x 125). */
  static get PLAYER_STATION() { return { x: 145, y: 180 }; }
  static get ENEMY_STATION()  { return { x: 780, y: 200 }; }
  /* A SHAPED HULL HAS HER OWN PLACE (update175). Isis drawn whole is
     593 units across and Hathor 618 — 1211 of the 1280 there are, with
     the stern, the ridges and the bow round the modules — so neither
     fits the old station: Hathor's stern ran off the right of the
     screen, Isis's went under the orders panel. A shaped hull is placed
     by her PICTURE instead: yours from the left edge, theirs to the
     right edge (jj, 29.10: "rozstawienie, żeby się zmieściły"), and the
     two pictures then just clear each other (Isis ends at 655, Hathor
     starts at 658). Measured on the real screen (Full HD, update175):
       · the orders panel ends at x 115, y 250 — and Isis's stern inside
         that width starts 37 below the top of her picture, so her
         picture's top is 214 and no higher;
       · the crew bar starts at y 540, the enemy's status panel ends at
         157, the log's tab starts at 475. */
  static get SHAPED_STATION() {
    return { playerLeft: 62, playerTop: 214, enemyRight: 1276, enemyBottom: 472 };
  }
  /** Where a hull of this layout is put, flown by you or at you: the
   *  station, or for a SHAPED hull with her picture on disk, her picture
   *  against the edge of the screen. */
  static stationFor(layoutKey, isPlayer = true) {
    const base = isPlayer ? Ship.PLAYER_STATION : Ship.ENEMY_STATION;
    const fr = hullFacesRight(layoutKey, isPlayer);                       // a fleeing enemy (update215)
    const L = layoutFor(layoutKey, fr);
    if (!L || !HULL_SHAPED[layoutKey]) return base;
    const g = HULL_ART.withPicture(hullArtGeometry(L.rooms, (L.elevators ?? []).map(e => e.x), fr, !!L.isStation),
                                   layoutKey, fr);
    if (!g?.shaped) return base;
    const S = Ship.SHAPED_STATION;
    return isPlayer
      ? { x: Math.round(S.playerLeft - g.box.x), y: Math.round(S.playerTop - g.box.y) }
      : { x: Math.round(S.enemyRight - (g.box.x + g.box.w)), y: Math.round(S.enemyBottom - (g.box.y + g.box.h)) };
  }
  /* Out the airlock is free in CC and costs you your name. The other
     half of this pair is the burial at the dock — see base.js.

     `VENT_KARMA` RENAMED to EJECT_KARMA (update75). Since update73 a
     "vent" is the duct along every ceiling — where the fire runs and
     the rats live — and the order that throws a body into the black
     had the same word. The airlock stays dangerous (player's call,
     22.09): the man carrying the body stands in vacuum for a few
     seconds and his suit holds eight, so the burial can cost you the
     bearer. That is the price of the decision, not a bug. */
  static get EJECT_KARMA()   { return -3; }
  static get BURIAL_KARMA() { return  3; }
  /** A grave without a name for one of THEIRS, brought home (update93). */
  static get UNKNOWN_BURIAL_KARMA() { return 1; }
  /* How long a man needs on an unpowered cell door. Long enough that
     restoring power is a real save, short enough that ignoring the
     warning costs you the bounty. */
  static get ESCAPE_SECONDS() { return 25; }

  /* ── HOW LONG A SALVAGE TEAM HAS (update74) ───────────────
   *
   * Fifty seconds, written out in FIVE places in game.js — three
   * `?? 50` defaults, a `_wreckSecs` initialiser and a floor of 20 —
   * which is five chances to change four of them.
   *
   * Fifty is also too long, and that is the player's report: *„za dużo
   * mamy teraz czasu do namysłu"*. In fifty seconds a hold can be
   * solved like a Tetris board, at leisure, which is the opposite of
   * what a clock on a derelict is for. Thirty makes it a decision
   * about what to take; the floor stops a booby trap or a bad roll
   * from turning it into no decision at all.
   *
   * One number, one place. Both are tuning dials — expect to move them
   * once he has flown with them. */
  static get LOOT_SECONDS() { return 30; }
  static get LOOT_SECONDS_MIN() { return 15; }


  /* ── THE SHIP'S CAT (update45) ────────────────────────────
   *
   * A cat is a passenger with an opinion. Nobody gives it orders it
   * has to obey — though the player CAN send it to a compartment, and
   * that beats whatever it had planned — and it works down a short
   * list of its own priorities:
   *
   *   1. eat, if it is in the middle of eating
   *   2. hunt, if there is vermin aboard
   *   3. sit with a downed crewman  ← what it does most of the time
   *   4. find food, if it is hungry
   *   5. wander
   *
   * Priority 3 is the whole reason a cat is worth a pen. Rats appear
   * on maybe a fifth of jumps, so an animal that only hunted them
   * would sit idle for entire contracts; sitting with the wounded
   * gives it work in every fight, and it costs nothing to explain —
   * the animal is simply there when somebody is bleeding.
   */
  petTick(dt) {
    const cats = this.crew.filter(c => c.isPet && !c.dead);
    if (!cats.length) return;
    const H = (typeof HUNGER !== 'undefined') ? HUNGER : null;
    if (!H) return;

    cats.forEach(cat => {
      if (!cat.alive) return;

      /* THE STOMACH MOVED OUT (update47). Draining the meter, the
         starvation damage and the warnings used to be written right
         here, for cats only. The crew eat now, and a second copy of
         the same arithmetic for people is exactly the two-registers
         mistake this project keeps paying for — so all of it went to
         hungerTick, for every mouth aboard, and petTick is left with
         what it was always about: what a CAT does. */

      // ── 1. Mid-meal ── (the timer itself ticks in hungerTick)
      if (cat.busy) return;

      /* UP IN THE DUCT WITH ONE ALREADY (update84) — `_pestVsCat`
         owns her until it is dead or she is. Without this she would be
         called off it by the next pest on the list. */
      if (cat._ductPestId) return;

      /* PREY IS IN THE DUCTS NOW, and it is spiders as well as rats:
         the cat is one of the only two things that can kill a spider.
         The one over her own room first, so she is not sent across the
         ship past the one she is standing under. */
      /* A FED CAT DOES NOT HUNT (update90b) — the player's rule: she goes
         up after them when she has room for one, which is what the prey
         points in HUNGER.PREY are for. */
      const live = (cat.hunger ?? 0) >= H.FED ? [] : this.pests.filter(p => p.alive);
      const prey = live.find(p => p.roomId === cat.roomId) || live[0] || null;
      const hurt = this.crew.find(c => c.isPlayer && c.down && !c.dead && c.inRoom !== false);
      const starving = cat.hunger < H.HUNGRY;

      /* ── A STANDING ORDER, AND WHAT BREAKS IT (update83) ───
       *
       * This flag has been read here since update45 and NOTHING EVER
       * WROTE IT. So the branch was dead, and what the player saw was
       * the cat taking his order and abandoning it — instantly if
       * there was a rat aboard, and otherwise the moment the roam
       * timer ran out a few seconds later: "kot chodzi tam gdzie mu
       * sie pokazuje, nastepnie po chwili chodzi gdzie chce".
       *
       * Now the order HOLDS. She walks there and she stays there, and
       * she keeps standing there when the roam timer fires, because
       * the order is checked before the roam and returns.
       *
       * THREE THINGS OUTRANK IT, and the first two are the player's
       * own rule — "dopóki nie pojawi się szczur albo ranny":
       *
       *   - vermin aboard: hunting is what she is FOR
       *   - a man on the floor: the vigil slows his bleed-out (update45)
       *   - her own hunger: a cat starving at her post would be an
       *     order that kills her, which is not an order the player
       *     thinks he is giving
       *
       * The flag is cleared when one of them fires, so she goes back to
       * her own life for good rather than snapping back to the post
       * afterwards. Wanting her there again is one more click, and one
       * more click is cheaper than a cat you cannot call off.
       *
       * AND IT APPLIES MID-WALK. There used to be a line above this
       * one — `if (cat._waypoints.length) return` — that made the
       * order absolute until she arrived. The breaking run could not
       * break it, which is how it was found: with nothing outranking
       * the order the test below returns anyway, so the line only ever
       * changed what happens when a rat appears while she is still
       * crossing the ship. Marching her into an empty room to turn
       * round there is not better behaviour, it is just more code —
       * so the line is gone and a rat diverts her wherever she is.
       */
      if (cat._ordered) {
        if (!prey && !hurt && !starving) return;     // posted, and staying
        cat._ordered = false;
      }

      // ── 2. Vermin aboard ──
      if (prey) {
        if (cat.roomId === prey.roomId) return;    // _pestVsCat takes it from here
        this._petSendTo(cat, prey.roomId);
        return;
      }

      // ── 3. Sit with the wounded ──
      if (hurt) {
        if (cat.roomId !== hurt.roomId) this._petSendTo(cat, hurt.roomId);
        return;
      }

      // ── 4. Hungry: go and find something ──
      if (starving && this._startMeal(cat)) return;

      // ── 5. Wander ──
      cat._roamT = (cat._roamT ?? Utils.randFloat(3, 9)) - dt;
      if (cat._roamT <= 0) {
        cat._roamT = Utils.randFloat(6, 14);
        const room = Utils.pick(this.rooms);
        if (room && room.id !== cat.roomId) this._petSendTo(cat, room.id);
      }
    });
  }

  /** Walk the cat to a room, the same way any crew order works.
   *
   * ONCE, NOT EVERY FRAME (update84). The hunt and the vigil both call
   * this on every tick until she arrives, and each call re-planned her
   * route from scratch — which is harmless on one deck and fatal on
   * two: a re-plan while she is waiting at or riding a lift turns the
   * cabin round and restarts the ride, so a cat sent to a rat on the
   * other deck stood at the shaft for ever. It went unseen while the
   * rats were crew, because the only test of the hunt looked for a
   * route, not an arrival. Moving the rats into the ducts made the
   * arrival the whole point, and the first test that waited for it
   * found her still at the lift two minutes later. */
  _petSendTo(cat, roomId) {
    const room = this.getRoomById(roomId);
    if (!room) return false;
    const tx = room.cx, ty = this.floorWalkY(room.floor, room.cy);
    /* "Already on her way" is read off her ROUTE, not off a note of
       where she was last sent: the player can re-order her in between,
       and a note would then say she was going somewhere she is not. */
    const last = cat._waypoints?.[cat._waypoints.length - 1];
    if (last && Math.abs(last.x - tx) < 1 && Math.abs(last.y - ty) < 1) return true;
    cat.moveToOnShip?.(this, tx, ty);
    return true;
  }

  /**
   * Start a meal if there is anything in the hold this mouth will eat.
   *
   * EGGS BEFORE RATIONS for the cat, deliberately: a spider egg eaten
   * is a fight that never happens, and the player is far happier to
   * lose one of those than a ration pack he was counting on. The crew
   * do not eat spider eggs. There are limits.
   */
  _startMeal(who) {
    /* ONE CHOOSER (update81). This used to pick its own meal — the egg,
       or else the first ration in grid order — while the player's FEED
       order picked through `mealFor`. Two answers to "what does this
       mouth open next", and they did not even agree about the egg: the
       cat helped herself to one, and FEED told the player there was
       "nothing aboard she will eat". */
    const meal = this.mealFor(who);
    if (!meal) return false;
    who._meal = meal;
    this._startBusy(who, 'eat');
    return true;
  }

  /**
   * WILL THIS MOUTH TOUCH THIS BOX (update66)?
   *
   * One question, asked by the cat's own meal and by the player's FEED
   * order alike, so a hand can never be ordered to eat something he
   * would not have taken on his own.
   *
   * Today it has exactly one rule and one live consumer: THE CAT does
   * not eat vat greens. That matters — it is what keeps `meat` from
   * being a flag with nothing reading it, waiting for religions to
   * arrive. When crew beliefs land, they add rules HERE and nowhere
   * else.
   */
  /**
   * THE WORST BOX ABOARD THIS MOUTH WILL OPEN (update81).
   *
   * It used to be the FIRST one in the grid, which is not a choice at
   * all — it is wherever the crate happened to land when it was
   * packed. The player's rule, and it is the right way round: "od
   * najgorszych potraw po lepsze".
   *
   * That is the opposite of what a player does by hand, and that is
   * the point. The automatic mouth clears out the protein paste that
   * would have gone off anyway; the field meals and the good rations
   * are still there when YOU decide who gets them. Eating up from the
   * bottom is also the only order that makes four kinds of ration a
   * packing decision rather than a shopping list.
   *
   * ONE CHOOSER for the order and for the automatic meal alike — see
   * `_startMeal`. `hunger` is the box's own nutrition, so this cannot
   * drift from what the meal is actually worth.
   *
   * AN EGG IS NOT ON THE LADDER — it jumps it. A cat takes an egg
   * before anything else, and that is not a statement about how tasty
   * it is: an egg left in the hold HATCHES, and the cat eating one is
   * a fight that never happens. Crew are not offered eggs at all;
   * `willEat` is where that rule lives.
   *
   * Asking it HERE rather than in `_startMeal` is the point of this
   * package's clean-up: the cat used to help herself to an egg through
   * one path while FEED, asking the other, told the player there was
   * "nothing aboard she will eat".
   */
  mealFor(who) {
    const hold = this.cargo?.items ?? [];
    if (who?.isPet || who?.isRat) {       // the rats too (update86, U10B)
      const egg = hold.find(it => it && it.def?.tag === 'egg' && !it.damaged);
      if (egg) return egg;
    }
    const edible = hold.filter(it =>
      it && it.def?.tag === 'food' && !it.damaged && this.willEat(who, it));
    if (!edible.length) return null;
    return edible.reduce((a, b) =>
      ((b.def?.hunger ?? 50) < (a.def?.hunger ?? 50) ? b : a));
  }

  /**
   * Why FEED would refuse, or null. The menu greys the row with this
   * and `feedCrew` refuses with it — the same shape as `bodyRefusal`,
   * and for the same reason: a row that looks live and then does
   * nothing is the bug both of them exist to prevent.
   */
  feedRefusal(who, item = null) {
    if (!who || who.dead) return 'nobody there';
    if (who.down) return `${who.name} is down — treat him first`;
    if (who.busy) return `${who.name} has his hands full`;
    if ((who.hunger ?? 100) >= 100) return `${who.name} is not hungry`;
    const meal = item || this.mealFor(who);
    if (!meal) return `nothing aboard ${who.name} will eat`;
    if (!this.willEat(who, meal)) return `${who.name} will not touch the ${meal.def.label}`;
    return null;
  }

  /** ONE door for every row of the crew menu, whoever it belongs to. */
  menuRefusal(person, act) {
    if (act === 'heal')   return this.healRefusal(person);
    if (act === 'cell')   return this.cellRefusal(person);
    if (act === 'freeze') return this.freezeRefusal(person);
    if (act === 'thaw')   return person?.frozen ? null : 'he is not in a slab';
    /* SEARCH A BODY (update187, jj 31.10: "dodać akcję przeszukania martwego
       ciała"): one of theirs, dead on our deck, not yet gone through. */
    if (act === 'search') {
      if (!person?.dead) return 'only the dead are searched';
      if (person.isPet) return 'a cat carries nothing';
      if (person.searched) return 'already searched';
      return null;
    }
    return act === 'feed' ? this.feedRefusal(person) : this.bodyRefusal(person, act);
  }

  willEat(who, item) {
    if (!who || !item) return false;
    if (item.def?.tag === 'egg') return !!(who.isPet || who.isRat);   // crew have limits
    if (item.def?.tag !== 'food') return false;
    if (who.isPet && item.def.meat === false) return false;
    return true;
  }

  /**
   * FEED THIS ONE, NOW (update66).
   *
   * A hungry man helps himself, which is right — but it means the last
   * box on the shelf goes to whoever got hungry first, and the player
   * never gets a say. This is the say: name a mouth, and he eats next.
   * Refuses out loud, like every other order.
   */
  /* ══ ONE DOSE, ON HIS FEET (update97) ══════════════════════
   *
   * jj: the medicine should be used from the man's own menu, the way a
   * meal is. FEED names a mouth; HEAL names a patient. One dose, a few
   * seconds of his hands, and it does what a dose has done from the hold
   * since update68 — the corpse plague first (the spider's virus stays a
   * clinic's job), otherwise HEAL_HP of his wounds. A man on the floor is
   * the MEDKIT row's business (two doses, up on his feet). */
  static get HEAL_HP() { return 25; }
  /** Seconds a dose takes (update107, jj: "kilka sekund", like a meal). */
  static get HEAL_SECONDS() { return 5; }
  /** Seconds a man out of a slab needs to come round (update107). */
  static get THAW_SECONDS() { return 5; }
  /* THE THREE SLABS AS PAINTED (update128) — tools/room_painter.js draws
     them at these places on its 100x50 picture of the bay: centres at
     24/50/76, the window from y 11 to 41, 16 wide. A frozen man is put
     IN a window, so the ice and the picture are one thing (jj: "osoby
     zamrożone dalej nie są na równo z ilustracją modułu, za duży lód"). */
  static get SLAB_ART() { return { xs: [24, 50, 76], top: 11, bottom: 41, w: 16, W: 100, H: 50 }; }

  /** Slab `i` of a bay room, in world pixels: { x, y, w, h } (top-left). */
  slabRect(room, i) {
    /* the windows of this yard's drawn bay, where it has one (update219) */
    const own = typeof moduleSpots === 'function' && typeof artYard === 'function' ? moduleSpots('carbonite', artYard(this.layoutKey))?.slabs : null;
    const A = own ? { ...Ship.SLAB_ART, ...own } : Ship.SLAB_ART;
    const sx = room.w / A.W, sy = room.floorH / A.H;
    const cx = room.x + A.xs[Math.max(0, Math.min(2, i))] * sx;
    const w = A.w * sx, h = (A.bottom - A.top) * sy;
    return { x: cx - w / 2, y: room.floorTop + A.top * sy, w, h };
  }

  /** Every frozen man in a window of his bay — a slab each, kept. */
  _placeSlabs() {
    const frozen = this.frozenCrew();
    if (!frozen.length) return;
    const byRoom = new Map();
    frozen.forEach(c => {
      const rid = c._slabRoom ?? this.getSystem('carbonite')?.roomId;
      if (!byRoom.has(rid)) byRoom.set(rid, []);
      byRoom.get(rid).push(c);
    });
    byRoom.forEach((men, rid) => {
      const room = this.getRoomById(rid);
      if (!room) return;
      const taken = new Set();
      men.sort((a, b) => (a._slabSeq ?? 0) - (b._slabSeq ?? 0));
      men.forEach(c => { if (c._slabIdx != null && c._slabIdx < 3 && !taken.has(c._slabIdx)) taken.add(c._slabIdx); else c._slabIdx = null; });
      men.forEach(c => {
        if (c._slabIdx == null) { c._slabIdx = [0, 1, 2].find(i => !taken.has(i)) ?? 0; taken.add(c._slabIdx); }
        const r = this.slabRect(room, c._slabIdx);
        c._slab = r;
        c.x = r.x + r.w / 2;
        c.y = r.y + r.h / 2;
      });
    });
  }
  /** How long a slab with no unit takes to let its man go (update127). */
  static get SLAB_MELT_SECONDS() { return 25; }

  /**
   * HE BREAKS OUT (update107, jj). A captive thawed on an enemy hull turns
   * into one of OURS standing on their deck — exactly what `freeCaptives`
   * makes of a man our boarder lets out — and marked `_escapee`, so the
   * fight sends him across to our ship (game.js). On their hull he is an
   * intruder: their crew fight him, and he fights back.
   */
  _breakOut(c) {
    if (!c || c.dead || !c.isPrisoner || this.isPlayer) return false;
    c.isPrisoner = false;
    c.isPlayer   = true;
    c.rescued    = true;
    c._escapee   = true;
    if (c.race === 'hostile' && typeof CORP_KEYS !== 'undefined') c.race = Utils.pick(CORP_KEYS);
    c.homeRoomId = c.roomId;
    if (typeof UI !== 'undefined') UI.notify(`${c.name} broke out of their brig — he is making for our ship!`, 'good');
    return true;
  }

  healRefusal(who) {
    if (!who || who.dead) return 'he is dead';
    if (who.down) return 'he is down — that is the MEDKIT';
    if (who._busyT > 0) return `${who.name} has his hands full`;
    const plague = who.infected && !who.virus;
    if (!plague && who.hp >= who.maxHp) return 'he is not hurt';
    if (!this.hasDoses(1)) return 'no medical supplies in the hold';
    return null;
  }

  healCrew(who) {
    const why = this.healRefusal(who);
    if (why) return { ok: false, message: why };
    this._startBusy(who, 'heal', who.id, Ship.HEAL_SECONDS);
    who._waypoints = [];                 // he stops where he is (update107)
    if (who.task === TASK.MOVE) who.task = TASK.IDLE;
    return { ok: true, message: `${who.name} is taking a dose — ${Ship.HEAL_SECONDS} s.` };
  }

  _finishHeal(who) {
    if (!who || who.dead || who.down) return;
    if (!this.spendDoses(1)) return;   // the last one went elsewhere
    if (who.infected && !who.virus) {
      who.infected = false; who._infT = 0;
      if (this.isPlayer && typeof UI !== 'undefined') UI.notify(`${who.name} is over the plague.`, 'good');
      return;
    }
    who.hp = Math.min(who.maxHp, who.hp + Ship.HEAL_HP);
  }

  feedCrew(who, item = null) {
    const why = this.feedRefusal(who, item);
    if (why) return { ok: false, message: why };
    const meal = item || this.mealFor(who);
    who._meal = meal;
    this._startBusy(who, 'eat');
    return { ok: true, message: `${who.name} is eating the ${meal.def.label}.` };
  }

  /* ══ ONE TIMER FOR EVERY ACTION THAT TAKES A MOMENT (update78) ══
   *
   * The player's rule: eating, bandaging and opening a medkit each
   * take a couple of seconds. They share ONE timer on the man doing
   * them, because the first thing any of them needs to ask is "are
   * your hands already full" — and three separate timers is three
   * places for that one question to be answered differently.
   *
   * `act` says what finishes when it runs out; `onId` is the man it is
   * being done TO, as an ID, because he can die, be carried away or go
   * out an airlock while the seconds run.
   */
  _startBusy(who, act, onId = null, secs = null) {
    if (!who) return false;
    /* ONE timer, but not one LENGTH (update87). Eating went to six
       seconds at the player's ask; the bandage and the medkit borrowed
       the meal's number, so they doubled with it — a side effect the
       player did not ask for. The meal keeps HUNGER.EAT_SECONDS; the
       hands-on medical work keeps its three. */
    const len = act === 'eat'
      ? ((typeof HUNGER !== 'undefined') ? HUNGER.EAT_SECONDS : 6)
      : Ship.AID_SECONDS;
    who._busyT   = secs ?? len;
    who._busyAct = act;
    who._busyOn  = onId;
    return true;
  }

  _cancelBusy(who) {
    if (!who) return;
    who._busyT = 0; who._busyAct = null; who._busyOn = null; who._meal = null;
  }

  _busyTick(dt) {
    this.crew.forEach(c => {
      if (!c || !(c._busyT > 0)) return;
      /* A MAN WHO DIED MID-ACTION FINISHES NOTHING. Checked here and
         not in each finisher, so a new action cannot forget it. */
      if (c.dead) { this._cancelBusy(c); return; }
      c._busyT -= dt;
      if (c._busyT > 0) return;
      const act = c._busyAct, onId = c._busyOn;
      c._busyT = 0; c._busyAct = null; c._busyOn = null;
      const on = onId ? this.crew.find(x => x && x.id === onId) : null;
      if (act === 'eat')    this._finishMeal(c);
      if (act === 'aid')    this._finishAid(c, on);
      if (act === 'medkit') this._finishMedkit(c, on);
      if (act === 'heal')   this._finishHeal(on ?? c);
      if (act === 'thaw')   this._breakOut(c);
    });
  }

  /* ══ MEDICAL SUPPLIES: ONE BOX, TWO PRICES (update78) ══════
   *
   * A bandage costs ONE dose and stops a man bleeding. A MEDKIT costs
   * TWO and puts him back on his feet. One item in the hold, so there
   * is nothing to tell apart on the shelf and no second icon — and the
   * decision is sharp, because the automatic bandaging eats the same
   * doses the player is hoarding to stand people up.
   */
  doseCount() {
    return (this.cargo?.items ?? [])
      .filter(it => it.def?.kind === 'heal')
      .reduce((n, it) => n + (it.qty ?? 1), 0);
  }

  hasDoses(n = 1) { return this.doseCount() >= n; }

  /** Spend `n` doses. All or nothing: it never half-pays. */
  spendDoses(n = 1) {
    if (!this.hasDoses(n)) return false;
    let left = n;
    const hold = this.cargo;
    (hold?.items ?? []).filter(it => it.def?.kind === 'heal').forEach(it => {
      if (left <= 0) return;
      const take = Math.min(left, it.qty ?? 1);
      left -= take;
      if ((it.qty ?? 1) > take) it.qty -= take;
      else hold.remove(it);
    });
    return true;
  }

  /** The bandage is on: the clock stops, and he is still on the floor. */
  _finishAid(medic, body) {
    if (!body || body.dead || !body.down) return;
    if (body._bandaged) return;
    if (!this.spendDoses(Ship.AID_DOSES)) return;   // somebody used the last one
    body._bandaged = true;
    body._bleedT   = 0;
    medic?.addXP?.('repair', 5);
    if (this.isPlayer && typeof UI !== 'undefined') {
      UI.notify(`${medic?.name ?? 'Somebody'} stopped ${body.name}'s bleeding — `
              + 'he still needs a medkit or the medbay.', 'good');
    }
  }

  /** The medkit is open: he is on his feet, and the box is two lighter. */
  _finishMedkit(medic, body) {
    if (!body || body.dead) return;
    if (!this.spendDoses(Ship.MEDKIT_DOSES)) return;   // supplies went elsewhere
    const floor = Math.round(body.maxHp * Ship.MEDKIT_SHARE);
    /* NEVER DOWNWARDS. A man at half health who takes a medkit is not
       pushed back to thirty percent — the dose is a floor, not a
       setting. */
    body.hp     = Math.max(body.hp, floor);
    body.state  = 'ok';
    body._bleedT = 0;
    body._bandaged = false;        // nothing left to stop
    body.bodyOrder = null;
    medic?.addXP?.('repair', 8);
    if (this.isPlayer && typeof UI !== 'undefined') {
      UI.notify(`${body.name} is back on his feet — ${Ship.MEDKIT_DOSES} doses gone.`, 'good');
    }
  }

  /** The meal is over: the item leaves the hold ONCE and feeds ONCE. */
  _finishMeal(who) {
    const meal = who._meal;
    who._meal = null;
    const hold = this.cargo;
    if (!meal || !hold?.items?.includes(meal)) return;   // somebody moved it
    const isEgg = meal.def?.tag === 'egg';
    /* THE MEAL SAYS WHAT IT IS WORTH (update66). Rations carry their
       own `hunger` now — there are four of them and no such thing as
       "the" ration to look up. Eggs and rats are not cargo, so they
       stay in HUNGER.FOOD where they always were: a split by KIND, not
       two copies of one number. */
    const food  = isEgg ? HUNGER.FOOD.spider_egg
                        : { hunger: meal.def?.hunger ?? 50, hp: 4 };
    /* A RATION PACK IS A STACK, not a parcel: one man eats ONE unit
       out of it and the rest stays on the shelf. Removing the whole
       item would throw away four meals to serve one. */
    if (!isEgg && (meal.qty ?? 0) > 1) meal.qty--;
    else hold.remove(meal);
    who.hunger = Utils.clamp((who.hunger ?? 0) + food.hunger, 0, 100);
    who.hp     = Math.min(who.maxHp, who.hp + food.hp);
    if (this.isPlayer && typeof UI !== 'undefined') {
      UI.notify(isEgg ? `${who.name} ate a spider egg.`
                      : `${who.name} ate a ration.`, isEgg ? 'good' : 'info');
    }
  }

  /* ── EVERY MOUTH ABOARD (update47) ────────────────────────
   *
   * One stomach loop for the crew and the cat alike. It drains the
   * meter, starves whoever hits zero, keeps the meal timers, and
   * lets a hungry CREWMAN reach for a ration by himself — the cat's
   * own meals are started by petTick, because for a cat eating sits
   * in a priority list against hunting and sitting with the wounded.
   *
   * A man eats where he stands. He does not walk to the hold: the
   * whole point of a ration pack is that you tear it open at your
   * post, and a gunner who abandoned his console to have lunch in
   * the middle of a fight would be a bug, not a feature.
   */
  hungerTick(dt) {
    const H = (typeof HUNGER !== 'undefined') ? HUNGER : null;
    if (!H) return;

    this.crew.forEach(c => {
      // A frozen man does not get hungry either (update77). Every
      // clock he carries is stopped, not just the one that kills him.
      if (!c || c.dead || c.frozen) return;

      // Mid-meal — for everybody, cat included. The timer itself is
      // `_busyTick`, which every timed action shares.
      if (c.busy && c._busyAct === 'eat') return;

      const rate = c.hungerPerSec ? c.hungerPerSec() : 0;
      if (!rate) return;
      c.hunger = Utils.clamp((c.hunger ?? 100) - rate * dt, 0, 100);

      if (c.hunger <= 0) {
        /* STARVATION IS A SLOPE, NOT A CLIFF. It takes the better
           part of three minutes at zero to kill, and the warning has
           been up since the meter hit STARVING — nobody loses a hand
           or an animal without having been told. */
        c.takeDamage?.(H.STARVE_HP_PER_SEC * dt, 'starvation');
        if (c.dead) {
          if (this.isPlayer && typeof UI !== 'undefined') {
            UI.notify(`${c.name} starved.`, 'alert');
          }
          return;
        }
      }
      if (c.hunger <= H.STARVING && !c._starveWarned) {
        c._starveWarned = true;
        if (this.isPlayer && typeof UI !== 'undefined') {
          UI.notify(`${c.name} is starving — there are rations in the hold.`, 'warn');
        }
      }
      if (c.hunger > H.HUNGRY) c._starveWarned = false;

      /* ── A HUNGRY MAN HELPS HIMSELF AGAIN (update81) ───────
       *
       * This is a REVERSAL of update69, and it is worth saying why,
       * because update69 removed automatic eating for a good reason.
       * The player's complaint then: "jedzenie jest dalej zjadane
       * automatycznie a nie powinno" — a hungry man reached into the
       * hold by himself, so the four rations, the FEED order and the
       * decision about what to carry were all decoration.
       *
       * His instruction now: "wrocimy do mechaniki ze jak jest
       * jedzenie w ladowni to w momecie jak sa glodni automatycznie
       * jedza, poczawszy od najgoryszych potraw po lepsze, oczywiscie
       * dalej mozesz dac rozkaz jedzenia zalagantowi manualnie".
       *
       * What changed in between is why it is not the same mistake:
       *
       *  - update70 gave hunger a MIDDLE. A hungry man works slower,
       *    so a ration buys something other than "not dying", and the
       *    hold no longer empties into a meter nobody watches.
       *  - update78 made a meal TAKE TIME, and update79 took a busy
       *    man off his console. So the automatic mouth costs seconds
       *    of work in the middle of a fight — it is a price, not a
       *    silent subtraction.
       *  - update81 eats the WORST box first (see `mealFor`). The good
       *    rations are still on the shelf when the player decides who
       *    gets them, which is the decision update69 was protecting.
       *
       * FEED stays, and stays exactly as it was. The automatic meal
       * takes the CLICKING away, not the choice.
       *
       * THE FIGHT COMES FIRST. Nobody opens a ration in a compartment
       * with a boarder in it — the same predicate that stops the
       * room's other work stops this too, so "a brawl pre-empts
       * everything" has one answer aboard this ship. Putting out a
       * fire does NOT stop him, and that is the player's own call:
       * "zostawi gaszenie czy zazadzanie modulem na rzecz jedzenia".
       *
       * The CAT is not here. She feeds herself in `petTick`, which is
       * where everything a cat decides lives, and a second caller for
       * the same meal would be the two-registers mistake again.
       */
      /* ONLY WHEN IT STARTS TO HURT (update87). He used to reach for a
         ration the moment he went under HUNGRY — so a hungry icon came
         up and a meal started in the same breath, two food marks side by
         side and nothing for the player to decide. Now a man carries on
         hungry (and slower for it — HUNGER.EFFORT) until his stomach
         starts costing him hide; feeding him before that is the FEED
         order, which is the player's call. */
      if (c.hunger <= 0 && !c.busy && !c.isPet && !c.down
          && c.isPlayer === this.isPlayer
          && !this.roomContested(c.roomId)) {
        this._startMeal(c);
      }
    });
  }
  /** Is a cat sitting with this body? Bleeding out runs slower if so. */
  petVigilOver(body) {
    if (!body?.roomId) return false;
    return this.crew.some(c => c.isPet && c.alive && c.roomId === body.roomId);
  }

  update(dt) {
    if (this.destroyed) return;

    /* A PICTURE IN THE HANGAR IS NOT A CONTRACT (update89 fix). The base
       builds a preview of the hull and walks the crew to their posts —
       and that ran the ducts, the stomachs and the egg clock on a copy
       of the ship, with the real notices: a case close to splitting
       "hatched" in the yard, again every time the preview was rebuilt,
       and the spam came with it. The clocks only run on the real hull,
       in flight; at the dock they stop (see infectionTick). */
    const live = !this.isPreview;
    if (live) this.pestTick(dt);
    this.searchTick();
    if (live) this.hungerTick(dt);
    this.petTick(dt);

    // Death animation
    if (this.hull <= 0) {
      this._deathTimer += dt;
      if (this._explosionTimer.tick(dt)) {
        const db = this.roomBounds();
        const rx = db.x + Utils.randFloat(0, db.w);
        const ry = db.y + Utils.randFloat(0, db.h);
        Particles.explosion(rx, ry, Utils.randFloat(0.5, 1.5));
      }
      if (this._deathTimer > 2.5) {
        this.destroyed = true;
      }
      return;
    }

    // ── Bodies: carrying, medbay healing, decay plague, ejection ──
    this._updateBodies(dt);

    // ── The carbonite: cells, and the men working the locks ──
    this.prisonerTick(dt);
    this._busyTick(dt);

    // ── A man sent to bag a body, arriving ──
    this.bagArrivals();

    // ── The bite and the egg case, both on the clock ──
    if (live) this.infectionTick(dt);

    // ── Anybody's prisoners, found by somebody else's boarders ──
    this.freeCaptives();

    // Sync crew presence into each system (bonuses, cyborg power, medbay)
    this.systems.forEach(sys => {
      // A medbay reads its OCCUPANTS (cat included); every other module
      // reads its OPERATORS. See medbayPatients (update54).
      sys.crew = sys.roomId
        /* A MEDBAY'S CREW IS ITS STAFF, NOT ITS PATIENTS (update78).
           This asked `medbayPatients` because the healing used to live
           in ShipSystem.update and needed the list — the healing is in
           Ship.update now, so what is left of `sys.crew` is what it is
           for every other module: who is WORKING it. A man lying on
           the table was counting as an operator, which among other
           things let a wounded Terra cyborg keep the module lit while
           he was unconscious on its floor. */
        ? this.crewOperating(sys.roomId)
        : [];
      // WHO IS AT THE CONSOLE (update43) — the only one whose skill
      // counts, and the only one who learns from the module's work.
      sys.consoleCrew = sys.roomId ? this.consoleOperator(sys.roomId) : null;
      sys.shipIsPlayer = this.isPlayer;   // so a system can talk to the UI
      if (sys.type === 'reactor') sys._offline = !!this.reactor?.offline;   // the badge (update93c)
      /* HIS UNIT LEAVES WITH HIM (update93a). On a module that was full
         his +1 stood in for a reactor unit; when he stepped off the
         console the module simply took a unit from the bank instead, so
         the player saw the power "stay in the old module" while the
         reactor he walked to gained one — two units out of one man. The
         module now drops the unit he was covering, and only that one. */
      const cy = sys.type !== 'reactor' && sys.hasCyborg && sys.workingLevels > 0;
      if (sys._hadCyborg && !cy && sys.type !== 'reactor' &&
          (sys.desiredPower ?? 0) >= sys.workingLevels && sys.workingLevels > 0 &&
          sys._cyborgCovered) {
        sys.desiredPower = Math.max(0, sys.desiredPower - 1);
        sys.power = Math.min(sys.power, sys.desiredPower);
      }
      sys._cyborgCovered = cy && (sys.desiredPower ?? 0) >= sys.workingLevels;
      sys._hadCyborg = cy;
    });

    // Systems
    /* The Golden Ratio IV charges OUR shields faster while it runs
       (update99). A system does not know whose hull it is on, so the
       hull hands it the number before it updates. */
    if (this.isPlayer && typeof Chips !== 'undefined' && Chips.runningValue) {
      const boost = Chips.runningValue('shieldCharge');
      this.systems.forEach(sys => { if (sys.type === 'shields') sys._tabletCharge = boost; });
    }
    this.systems.forEach(sys => sys.update(dt));

    // FTL power flow: each system draws up to its DESIRED power,
    // limited by working (undamaged) levels and reactor budget.
    // → repairing a module automatically re-lights its bars.
    this.reflowPower();
    // Gravity answers to this frame's power (update91), like the lifts.
    this._gravityTick(dt);
    // …and so does the reactor's heat (update92).
    this._heatTick(dt);

    /* THE SLABS ANSWER TO THE POWER THIS FRAME (update77), so this
       runs AFTER the flow above and not with the other per-frame
       ticks. Put before it, `carboniteTick` read last frame's budget
       and a man whose slab had just gone cold stayed under for one
       more frame — harmless on its own, and exactly the kind of
       one-frame lie that turns into "sometimes he does not wake up"
       the moment anything else reads the same number. */
    this.carboniteTick(dt);
    this._placeSlabs();                  // the frozen stay in their windows (update128)

    // The repair bay's drones fly to what is broken and mend it (update229).
    this._updateDrones(dt);

    this._reallocWeaponPower();   // damaged weapon module instantly de-powers ITS gun
    this.weapons.forEach((w, i) => {
      if (!w) return;
      // OPERATOR RULE: a gun charges only while a crew member stands
      // in ITS weapon module (slots without a room fall back to any
      // weapons-room operator — legacy boss overflow).
      const room   = this.weaponRoomFor(w);
      const manned = room
        ? this.crewOperating(room.id).length > 0
        : this.weaponRooms.some(r => this.crewOperating(r.id).length > 0);
      // (Forced Fire's chip bonus went with the chips — update99.)
      w.update(dt, this.weaponCrewBonusFor(i), manned);
    });

    // Hit flashes fade; wrecked modules smoke so a broken ship LOOKS
    // broken even when you are not reading the power bar.
    this.rooms.forEach(room => {
      if (room._hitFlash > 0) room._hitFlash = Math.max(0, room._hitFlash - dt * 3.5);
      const sys = room.system;
      if (sys && sys.damagedLevels > 0 && Math.random() < dt * (1.2 * sys.damagedLevels)) {
        Particles.damageSmoke?.(room.cx + Utils.randFloat(-14, 14), room.cy);
      }
    });

    // Crew update and room assignment
    this.crew.forEach(c => {
      if (c.dead) return;
      /* ── A MAN IN A SLAB IS NOT IN A ROOM (update77) ────────
       *
       * ONE guard, here, and it is what makes carbonite mean anything:
       * he does not walk, does not fight, does not breathe, cannot be
       * set on fire and cannot be picked as the man at a console —
       * because everything that finds people finds them BY ROOM, and
       * this loop is the only thing that puts him in one.
       *
       * The alternative was `if (c.frozen) return;` in a dozen loops,
       * and the thirteenth loop written next month without one. */
      if (c.frozen) return;
      /* FIGHTS BELONG IN ROOMS, NOT IN THE WALLS (update42).
         `roomId` was never cleared when a crew member stepped OUT of
         every room rectangle — and there is real floor that belongs to
         no room: the 28px elevator trunk. Waiting for a cabin or riding
         one, a boarder kept the stale id of the room he had left, so
         melee matched him against someone on the other side of a wall,
         the brawl cancelled his ride, and if he lost, the corpse lay in
         the shaft while bodiesInRoom still reported him inside. Melee
         and the body loops now require you to actually BE in a room.

         Resolved BEFORE c.update, not after: melee runs inside update
         and has to judge where the man is standing NOW, not where he
         was last frame — and on his very first frame aboard there is
         no last frame at all. */
      const at = this.rooms.find(r => r.contains(c.x, c.y));
      c.inRoom = !!at;
      if (at) c.roomId = at.id;

      c.update(dt, this);

      // …and again afterwards, so everything that reads the roster
      // between frames sees where he ended up.
      const now = this.rooms.find(r => r.contains(c.x, c.y));
      c.inRoom = !!now;
      if (now) c.roomId = now.id;
    });
    /* CORPSES STAY (update40).
     *
     * This line was `filter(c => !c.dead)` — unconditional, and run at
     * the end of every single update, in the SAME call in which
     * CrewMember.update flips dying → dead. `_updateBodies` runs
     * BEFORE the crew loop, so it never once saw a body that had just
     * died, and the body was gone by the next frame.
     *
     * That quietly deleted an entire subsystem the game keeps telling
     * the player about: carrying the dead to an airlock, the
     * "…body is DECAYING — eject it before the crew gets sick!" warning
     * in markCombatStart, the corpse plague that spreads from a rotting
     * body to everyone in the room, the ☠/☣ head markers in
     * CrewMember.draw and the DECAYING tag in the crew panel. None of
     * it could ever fire. (The wounded half still worked, which is what
     * made the contradiction so easy to miss.)
     *
     * A body now lies where it fell until somebody carries it out —
     * `_updateBodies` removes the EJECTED, and that is the only way off
     * the ship. Animals are the exception: nobody holds a service for a
     * spider, and a hull that had been cleared of vermin should not
     * carry a list of little corpses for the rest of the run.
     *
     * Everything that counts people already filters `!c.dead`
     * (_playerCrewAliveCount, returnFromRun, crewInRoom, occupantsOf,
     * takenStationSlots, the wreck-cleared check), so keeping them in
     * the roster changes no count.
     */
    this.crew = this.crew.filter(c => !(c.dead && c.isPet));

    // O2
    this.oxygen.update(dt, this);

    // Fires
    this.fires.update(dt, this);

    // Breaches
    this.breaches.update(dt);

    // Elevators — a cabin of OURS settling at its floor clunks (update172);
    // a picture of a ship (the title screen, the hangar) and the enemy do not.
    const liftsMoving = () => (this.elevators.shafts ?? []).filter(sh => sh._moving).length;
    const movingBefore = liftsMoving();
    this.elevators.update(dt);
    if (this.isPlayer && !this.isPreview && liftsMoving() < movingBefore) Audio.sfx.liftStop();

    // Doors
    this.doors.forEach(d => d.update(dt, this.crew));

    // Rooms with an open airlock are venting to space
    this.rooms.forEach(room => {
      room.isVacuum = this.doors.some(d =>
        d.isAirlock && d.open && d.roomA === room.id);
    });

    // Shield fade
    this._shieldAlpha = Math.max(0, this._shieldAlpha - dt * 2);
    this._ageShieldWaves(dt);

    // Shield pulse
    if (this._shieldPulse) {
      this._shieldPulse.update(dt);
      if (this._shieldPulse.done) this._shieldPulse = null;
    }
  }

  // ── Draw ─────────────────────────────────────────────────

  /** Bounding box of all rooms (the visual ship body) */
  /** Two treads under the hull (update94, the player: "na spodzie dołóż
   *  wielkie gąsienice imitujące ruch i jazdę"). Drawing only. */
  _drawTracks(ctx, b) {
    const t = (typeof performance !== 'undefined' ? performance.now() : 0) / 1000;
    const y = b.y + b.h + HULL_GRID.MARGIN - 4, h = 26, inset = 6;
    const x0 = b.x + inset, x1 = b.x + b.w - inset;
    ctx.save();
    // the tread belt
    ctx.fillStyle = '#2b2f38';
    ctx.beginPath(); ctx.roundRect(x0, y, x1 - x0, h, h / 2); ctx.fill();
    ctx.strokeStyle = '#5a6070'; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.roundRect(x0, y, x1 - x0, h, h / 2); ctx.stroke();
    // links creeping along the belt
    ctx.strokeStyle = '#7a8090'; ctx.lineWidth = 1.5;
    const pitch = 9, off = (t * 14) % pitch;
    for (let x = x0 + h / 2 + off; x < x1 - h / 2; x += pitch) {
      ctx.beginPath(); ctx.moveTo(x, y + 1); ctx.lineTo(x, y + 4);
      ctx.moveTo(x, y + h - 4); ctx.lineTo(x, y + h - 1); ctx.stroke();
    }
    // road wheels
    const n = Math.max(3, Math.round((x1 - x0) / 34));
    for (let i = 0; i < n; i++) {
      const cx = x0 + h / 2 + (x1 - x0 - h) * i / (n - 1);
      ctx.fillStyle = '#3d4250';
      ctx.beginPath(); ctx.arc(cx, y + h / 2, h / 2 - 4, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = '#8a90a0'; ctx.lineWidth = 1.5; ctx.stroke();
      ctx.save(); ctx.translate(cx, y + h / 2); ctx.rotate(-t * 1.6);
      ctx.beginPath(); ctx.moveTo(-5, 0); ctx.lineTo(5, 0); ctx.moveTo(0, -5); ctx.lineTo(0, 5); ctx.stroke();
      ctx.restore();
    }
    ctx.restore();
  }

  /**
   * THE WHOLE HULL SLIDES SIDEWAYS (update188, the chase). Everything that
   * stands at a place on her moves with her: the rooms, the doors, the lift
   * shafts, her people and where they are walking to, her fires, her
   * breaches, what lives in her ducts. Everything else (the picture, the
   * shield, the guns' mounts) is worked out from the rooms each frame.
   */
  shiftX(dx) {
    if (!dx) return this;
    this.worldX += dx;
    this.rooms.forEach(r => { r.x += dx; r.cx += dx; });
    (this.doors ?? []).forEach(d => { d.x += dx; });
    (this.elevators?.shafts ?? []).forEach(s => { s.x += dx; if (s.cabin && typeof s.cabin.x === 'number') s.cabin.x += dx; });
    (this.crew ?? []).forEach(c => {
      c.x += dx; if (typeof c.targetX === 'number') c.targetX += dx;
      (c._waypoints ?? []).forEach(w => { w.x += dx; });
    });
    (this.fires?.fires ?? []).forEach(f => { f.x += dx; });
    (this.breaches?.breaches ?? []).forEach(b => { b.x += dx; });
    (this.pests ?? []).forEach(p => { if (typeof p.x === 'number') p.x += dx; });
    // the modules keep their own copy of where their room is (_fitSystemToRoom)
    (this.systems ? Object.values(this.systems) : []).forEach(sys => {
      if (!sys) return;
      if (typeof sys.roomX === 'number') sys.roomX += dx;
      if (typeof sys.cx === 'number') sys.cx += dx;
    });
    return this;
  }

  roomBounds() {
    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    this.rooms.forEach(r => {
      minX = Math.min(minX, r.x);      minY = Math.min(minY, r.y);
      maxX = Math.max(maxX, r.x + r.w); maxY = Math.max(maxY, r.y + r.h);
    });
    return { x: minX, y: minY, w: maxX - minX, h: maxY - minY };
  }

  /** The yard's palette for the inside of this hull (update120). */
  trim() {
    const y = hullBuilder(this.layoutKey);
    return YARD_TRIM[y] ?? (this.isPlayer ? YARD_TRIM._you : YARD_TRIM._them);
  }

  /** Where this hull's picture goes, from its live rooms (update116). */
  hullArtGeometry() {
    const g = hullArtGeometry(this.rooms, (this.elevators?.shafts ?? []).map(s => s.x),
                           this.facesRight, !!this.layout?.isStation);
    return HULL_ART.withPicture(g, this.layoutKey, this.facesRight);      // a shaped hull (update175); her way (update215)
  }

  /**
   * The drawn hull, or null for "draw the plate in code". Null too when
   * the picture is the wrong size for these modules: a hull drawn for
   * last week's layout would put its rim through the rooms, and the code
   * plate is always right.
   */
  hullArt() {
    if (typeof Assets === 'undefined' || !Assets.source) return null;
    const name = HULL_ART.name(this.layoutKey, this.facesRight);
    if (Assets.source(name) !== 'file') return null;
    const img = Assets.get(name), g = this.hullArtGeometry();
    if (g?.shaped) return HULL_ART.fits(img, g) ? { img, geom: g } : null;   // update175
    if (!img || !g || img.width !== g.box.w || img.height !== g.box.h) return null;
    return { img, geom: g };
  }

  /**
   * The roof over this hull's compartments (update118), or null for
   * "close her in code". The same rule as the hull: a file, and the
   * size of the box, or nothing — a roof cut for last week's layout
   * would leave a compartment open or cover open space.
   */
  roofArt() {
    if (typeof Assets === 'undefined' || !Assets.source) return null;
    const name = HULL_ART.roofName(this.layoutKey, this.facesRight);
    if (Assets.source(name) !== 'file') return null;
    const img = Assets.get(name), g = this.hullArtGeometry();
    if (g?.shaped) return HULL_ART.fits(img, g) ? { img, geom: g } : null;   // update175
    if (!g || !img || img.width !== g.box.w || img.height !== g.box.h) return null;
    return { img, geom: g };
  }

  /**
   * ARE HER ENGINES RUNNING (update176)? jj: "jak silniki nie działają w
   * hangarze czy podczas walki, widać to na animacji — wyłącza się". The
   * test the jump charge uses (combat.js): an engines module that is not
   * disabled — `isDisabled` is no working level OR no power in it — and
   * a hull that is still a ship.
   */
  enginesRunning() {
    if ((this.hull ?? 1) <= 0) return false;
    const e = this.getSystem?.('engines');
    if (!e) return false;
    if (typeof Tanks !== 'undefined' && Tanks.dry?.(this)) return false;   // nothing to burn (update203)
    return !e.isDisabled();                 // no working level, or no power in one (systems.js)
  }

  /**
   * Her thrusters, burning (update176): the big drives at the stern and
   * the small ones on the bow, the top and the underside, where GPT drew
   * them (`geom.thrusters`). Each one a flame out of its nozzle — a white
   * core, a cyan body, a soft glow — that flickers; off, a cold nozzle and
   * nothing more. `on` false: off. `clock` for the tests.
   */
  _drawThrusters(ctx, geom, on, clock = null) {
    drawThrusterFlames(ctx, geom?.thrusters ?? [], on, clock ?? ((typeof performance !== 'undefined' ? performance.now() : 0) / 1000), 1,
                       thrusterFlameFor(this.layout?.builder));
  }

  /* ── THE C's NOTCH STAYS OPEN (update222) ── update219 plated it over from her roof (demo review C14); jj on
   * Osiris, Isis, Thoth: "załadowałeś powłoki w miejscach, gdzie nie powinno być modułów" — the plates read as
   * rooms that aren't there. Her picture's shape is her shape: nothing is drawn into the bite. */

  /** The roof, at `alpha`: the picture, or a plain skin over every
   *  compartment and lift trunk in the hull's colour. */
  _drawRoof(ctx, alpha) {
    ctx.save();
    const was = ctx.globalAlpha;
    ctx.globalAlpha = was * alpha;
    const art = this.roofArt();
    if (art) {
      const B = art.geom.box;                                     // on the hull's own box
      ctx.drawImage(art.img, B.x, B.y, B.w, B.h);                 // …at 1.5 px a unit when shaped (update175)
    } else {
      const b = this.roomBounds();
      ctx.fillStyle = this.isPlayer ? '#2a4a70' : '#6a2a2a';
      this.rooms.forEach(r => ctx.fillRect(r.x, r.y, r.w, r.h));
      (this.elevators?.shafts ?? []).forEach(sh =>
        ctx.fillRect(sh.x - HULL_GRID.SHAFT_W / 2, b.y, HULL_GRID.SHAFT_W, b.h));
      ctx.strokeStyle = 'rgba(0,0,0,0.45)';
      ctx.lineWidth = 1;
      this.rooms.forEach(r => ctx.strokeRect(r.x + 0.5, r.y + 0.5, r.w - 1, r.h - 1));
    }
    ctx.globalAlpha = was;          // by hand as well: restore() is not always a real one
    ctx.restore();
  }

  /* ── AN EGG CASE IS A THING IN A ROOM (update69) ───────────
   *
   * It used to exist only as a line in the hold, which is how the
   * player ended up with a crewman who vanished and a crate that
   * appeared: "jezeli zalogant zamieni sie w jajko to one powinno byc
   * na statku w formie graficznej, nie tylko w ladowni".
   *
   * There is still only ONE of them — the cargo item. This draws that
   * item at the spot stored on it, so selling it, dumping it or
   * letting the cat at it takes the thing off the deck as well, with
   * nothing to keep in step.
   */
  /** One path covering every module, grown by the hull margin.
   *  `inset` shrinks it, which is how the rim is drawn (see draw). */
  _hullPlatePath(ctx, inset = 0) {
    const M = HULL_GRID.MARGIN - inset;
    const R = Math.max(2, HULL_GRID.TILE + 4 - inset);
    ctx.beginPath();
    this.rooms.forEach(r => {
      ctx.roundRect(r.x - M, r.y - M, r.w + M * 2, r.h + M * 2, R);
    });

    /* THE LIFT TRUNKS ARE INSIDE THE HULL, so the plate has to cross
       them. A shaft is SHAFT_W wide and the modules either side are
       grown by MARGIN — 30 against 2x10, which leaves a ten-pixel
       notch bitten out of the hull at every lift. Harmless while the
       plate was one rectangle over the bounding box; visible the
       moment it started following the modules. */
    const b = this.roomBounds();
    const half = HULL_GRID.SHAFT_W / 2 + M;
    (this.elevators?.shafts ?? []).forEach(sh => {
      ctx.roundRect(sh.x - half, b.y - M, half * 2, b.h + M * 2, R);
    });
  }

  /* ── THE DUCT, DRAWN (update73) ───────────────────────────
   *
   * It has to be SEEN, and that is not decoration — it is the whole
   * reason this is safe to build. Rats and spiders are moving into the
   * duct, and a threat the player cannot see is a threat he does not
   * know he has. The same rule the karma wall is waiting on: a
   * consequence is shown, not reported.
   *
   * It does a second job for free. DECK_GAP is 0 now, so without this
   * band two decks meet on a hairline and a two-deck hull reads as one
   * tall grid. The duct IS the seam between decks.
   *
   * Drawn after the rooms so the grille sits over the floor plate, and
   * before the doors, which are taller than it and should cross it.
   */
  /* WHAT IS HAPPENING IN THE DUCTS (update85): how much air each one
     has, and whether it is burning. A duct emptying before its room is
     the whole of U11, and the player has to be able to see it. */
  _drawDuctState(ctx, layer = 'both') {
    const H = HULL_GRID.VENT_H;
    const t = (typeof performance !== 'undefined' ? performance.now() : Date.now()) / 1000;
    this.rooms.forEach(room => {
      // the air gauge is a tint over the grille: in front
      if (layer !== 'back') this.oxygen?.getRoom?.(room.id)?.drawDuct?.(ctx, room.x, room.ventY, room.w, H);
      if (layer === 'front') return;
      if (!this.fires?.ductBurning?.(this, room.id)) return;
      Ship.drawDuctFire(ctx, room.x, room.ventY + 3, room.w, H - 3, t, room.x, this.fires.ductStarved?.(this, room.id));
    });
  }

  /* A DUCT ON FIRE (update128): a glow filling the duct, tongues of
     flame licking up from its floor, sparks — all behind the slats. */
  /* …BLUE WHEN IT STARVES (update189, jj: "jak nie ma powietrza, ogień
     powinien być niebieski, w wentylacji również"): the same flame, in the
     colours a room's starved fire has had since update97. */
  static drawDuctFire(ctx, x, y, w, h, t, seed = 0, starved = false) {
    const C = starved ? Ship.DUCT_FIRE_BLUE : Ship.DUCT_FIRE;
    ctx.save();
    ctx.beginPath(); ctx.rect(x, y, w, h); ctx.clip();
    const g = ctx.createLinearGradient(0, y, 0, y + h);
    g.addColorStop(0, C.top);
    g.addColorStop(1, C.bottom);
    ctx.fillStyle = g;
    ctx.fillRect(x, y, w, h);
    for (let fx = x + 3; fx < x + w - 2; fx += 6) {
      const k = Math.sin(t * 9 + fx * 0.9 + seed) * 0.5 + 0.5;
      const k2 = Math.sin(t * 13 + fx * 1.7) * 0.5 + 0.5;
      const fh = h * (0.45 + 0.5 * k);
      ctx.fillStyle = C.tongue;
      ctx.beginPath();
      ctx.moveTo(fx - 3, y + h);
      ctx.quadraticCurveTo(fx - 2 + k2 * 2, y + h - fh * 0.6, fx + (k - 0.5) * 2, y + h - fh);
      ctx.quadraticCurveTo(fx + 2 - k2 * 2, y + h - fh * 0.5, fx + 3, y + h);
      ctx.fill();
      ctx.fillStyle = C.core;
      ctx.fillRect(fx - 1, y + h - fh * 0.45, 2, fh * 0.45);
    }
    const n = Math.floor(w / 14);
    for (let i = 0; i < n; i++) {
      const ph = (t * 1.6 + i * 0.37) % 1;
      ctx.fillStyle = `rgba(${C.spark},${(1 - ph).toFixed(2)})`;
      ctx.fillRect(x + ((i * 37 + seed * 3) % w), y + h - ph * h, 1, 1);
    }
    ctx.restore();
  }

  /**
   * WHAT EACH MODULE IS DOING, ON ITS OWN DISPLAY (update120, jj: "jak
   * już lecimy z info na ekranie dla O2, zróbmy dla większości modułów").
   * The big display in each module's picture (`moduleScreens`) sits on
   * the wall above the crew's heads, so nobody standing at a post hides
   * it. A module with no power shows nothing — its lights are down.
   *
   *   oxygen    the ship's air, and a bar
   *   piloting  what the helm adds to evasion — or NO PILOT
   *   engines   what the drive adds to evasion; GRAV OFF when the
   *             gravity is down
   *   weapons   the chance a shot hits the ship we are fighting
   *   shields   layers up, and the next one charging
   *   reactor   core temperature (left) and its heat bar (right)
   *   cloaking  READY, the field's seconds, or the cooldown
   *
   * `foe` is set by the fight (game.js) — the ship our guns point at.
   */
  /* ── THE REACTOR'S PIPS ON ITS CORE (update122) ────────────
   *
   * jj: "jedynie co możesz zrobić to umieścić te info w module reaktora
   * na środku, będzie pokazywało to samo co na dole". The tall core in
   * the middle of the reactor's picture becomes the readout: the same
   * pips as the reactor column on the power bar (Renderer.reactorPips,
   * one list for both), bottom first — orange unspent, dark spent, blue
   * a lit lift's, cyan the cyborg's, violet the nebula's, red broken.
   * Up the core, bottom first, one column (past eight, two to a row).
   * Only on a module drawn from its picture — the code tile has no core
   * to put them on.
   */
  static get REACTOR_CORE() {
    /* the core's glass in a 100 x 50 inside (tools/room_painter.js: the
       core box is 43,7 + 14x38, its light 46..53 x 9..42). The operator
       stands in front of it and hides part of it — jj: "nieważne, że
       będzie zasłonięte, jak będzie operator". */
    return { x: 45, y: 8, w: 10, h: 36, gap: 1 };
  }

  /** Where each pip goes on the core, in world space, bottom first: one
   *  column up the core, as on the bar; past eight, two to a row. */
  reactorCoreRects() {
    const sys = this.reactor?.sys;
    if (!sys || typeof Renderer === 'undefined' || !Renderer.reactorPips) return { panel: null, pips: [] };
    const n = Renderer.reactorPips(this).length;
    /* update237: the drawn Terra reactor's middle window (jj: „środek powinien być reaktor, miejsce na pipy") */
    const own = typeof moduleSpots === 'function' ? moduleSpots('reactor', sys.yard ?? null)?.pips : null;
    const C = own ? { ...own, gap: 1 } : Ship.REACTOR_CORE;
    const W = HULL_GRID.MODULE_W, H = HULL_GRID.MODULE_H - HULL_GRID.VENT_H;
    const kx = (sys.roomW || W) / W, ky = (sys.roomH || H) / H;
    const panel = { x: Math.round(sys.roomX + C.x * kx), y: Math.round(sys.roomY + C.y * ky), w: C.w, h: Math.round(C.h * ky) };
    if (!n) return { panel, pips: [] };
    const cols = n > 8 ? 2 : 1, rows = Math.ceil(n / cols);
    const pw = Math.floor((panel.w - C.gap * (cols + 1)) / cols);
    const ph = Math.max(1, Math.floor((panel.h - C.gap * (rows + 1)) / rows));
    const used = rows * (ph + C.gap) + C.gap;
    const bottom = panel.y + panel.h - Math.floor((panel.h - used) / 2);
    const pips = [];
    for (let p = 0; p < n; p++) {
      const c = p % cols, r = Math.floor(p / cols);
      pips.push({ x: panel.x + C.gap + c * (pw + C.gap), y: bottom - (r + 1) * (ph + C.gap), w: pw, h: ph });
    }
    return { panel, pips };
  }

  _drawReactorCore(ctx) {
    const sys = this.reactor?.sys;
    if (!sys || typeof moduleArt !== 'function' || !moduleArt('reactor', sys.yard ?? null)) return;
    const { panel, pips } = this.reactorCoreRects();
    if (!panel) return;
    const list = Renderer.reactorPips(this);
    ctx.save();
    ctx.fillStyle = 'rgba(6,8,14,0.95)';
    ctx.fillRect(panel.x, panel.y, panel.w, panel.h);
    pips.forEach((r, i) => {
      const pip = list[i];
      ctx.fillStyle = pip.fill;
      ctx.fillRect(r.x, r.y, r.w, r.h);
      if (pip.repairing && typeof Renderer.repairFill === 'function') {
        Renderer.repairFill(ctx, r.x, r.y, r.w, r.h, sys.repairProgress);
      }
    });
    ctx.restore();
  }

  /** What the weapons module's capacitors show (update242): the charge of the most charged powered gun, and
   *  whether one is ready. Read by drawModuleMotion. */
  _feedModuleMotion() {
    const ws = this.getSystem?.('weapons');
    if (!ws) return;
    const guns = (this.weapons ?? []).filter(w => w && w.powered);
    ws._gunCharge = guns.length ? { charge: Math.max(...guns.map(w => w.armed ? 1 : (w.charge ?? 0))), armed: guns.some(w => w.armed) } : null;
  }

  _drawModuleScreens(ctx) {
    if (typeof moduleArt !== 'function') return;
    const pct = v => Math.round(Utils.clamp(v, 0, 1) * 100) + '%';
    this.systems.forEach(sys => {
      const screens = moduleScreens(sys.type, sys.yard ?? null);
      if (!screens.length || !moduleArt(sys.type, sys.yard ?? null)) return;
      const powered = sys.type === 'reactor' ? (sys.workingLevels > 0 && !sys._offline) : !sys.isDisabled();
      if (!powered) return;
      const lines = this._screenLines(sys, pct);
      if (!lines) return;
      screens.forEach((d, k) => {
        const own = lines[k];
        if (!own) return;
        const x = sys.roomX + d.x, y = sys.roomY + d.y;
        ctx.save();
        ctx.fillStyle = 'rgba(4,8,12,0.75)';
        ctx.fillRect(x + 1, y + 1, d.w - 2, d.h - 2);
        ctx.textAlign = 'center';
        ctx.fillStyle = own.col;
        /* THE TEMPLATE'S SCREENS (15 high, 12 the reactor's) keep their hand; a drawn room's (update219: 4.5 to
           16 high) lays its lines out by its height — the line, then the small one or the bar under it */
        const tpl = d.h === 15 || d.h === 12;
        const sub = own.sub && (tpl || d.h >= 8), bar = own.bar != null && (tpl || d.h >= 7);
        if (tpl) {
          ctx.font = (d.w < 20 ? '6px' : '7px') + ' Share Tech Mono, monospace';
          ctx.fillText(own.t, x + d.w / 2, y + (own.sub ? 7 : 9));
        } else {
          const fs = Utils.clamp(d.h * (sub || bar ? 0.46 : 0.62), 3.5, 7);
          ctx.font = fs.toFixed(1) + 'px Share Tech Mono, monospace';
          ctx.fillText(own.t, x + d.w / 2, sub || bar ? y + d.h * 0.12 + fs * 0.8 : y + d.h / 2 + fs * 0.36);
        }
        if (sub) {
          ctx.fillStyle = own.subCol ?? own.col;
          const fs2 = tpl ? 6 : Utils.clamp(d.h * 0.32, 3.5, 6);
          ctx.font = fs2.toFixed(1) + 'px Share Tech Mono, monospace';
          ctx.fillText(own.sub, x + d.w / 2, y + d.h - (tpl ? 3 : d.h * 0.14));
        }
        if (bar) {
          const by = tpl ? y + d.h - 5 : y + d.h * 0.72, bh = tpl ? 2 : Math.max(1, d.h * 0.12);
          ctx.fillStyle = 'rgba(143,228,255,0.18)';
          ctx.fillRect(x + 3, by, d.w - 6, bh);
          ctx.fillStyle = own.col;
          ctx.fillRect(x + 3, by, Math.round((d.w - 6) * Utils.clamp(own.bar, 0, 1)), bh);
        }
        ctx.restore();
      });
    });
  }

  /** The line(s) a module's display shows, one per display — or null. */
  _screenLines(sys, pct) {
    const OK = '#8fe4ff', WARN = '#ffd700', BAD = '#ff2d44';
    switch (sys.type) {
      case 'oxygen': {
        const o2 = this.oxygen?.averageO2?.() ?? 1;
        return [{ t: `O₂ ${pct(o2)}`, col: o2 < 0.25 ? BAD : o2 < 0.6 ? WARN : OK, bar: o2 }];
      }
      case 'piloting': {
        const e = this.evasionShares();
        return [e.hasPilot ? { t: `EVD +${pct(e.cockpit)}`, col: OK, sub: 'helm' }
                           : { t: 'NO PILOT', col: BAD, sub: 'evd 0%' }];
      }
      case 'engines': {
        const e = this.evasionShares();
        return [{ t: `EVD +${pct(e.engines)}`, col: e.hasPilot ? OK : WARN,
                  sub: this.zeroG ? 'GRAV OFF' : (e.hasPilot ? 'drive' : 'no pilot'),
                  subCol: this.zeroG ? WARN : undefined }];
      }
      case 'weapons': {
        const h = this.hitChanceOn(this.foe ?? null);
        return [h == null ? { t: 'NO TARGET', col: '#7a90a8' } : { t: `HIT ${pct(h)}`, col: h < 0.5 ? WARN : OK }];
      }
      case 'autorepair': {                      // how many drones are out (update229)
        const fly = this.activeDrones(), built = this.builtDrones();
        const busy = this.drones.filter(d => d.working).length;
        const burn = this.drones.some(d => d.working && d.onFire);
        const hole = this.drones.some(d => d.working && d.onBreach);        // update233
        return [{ t: `DRN ${fly}/${built}`, col: fly > 0 ? OK : '#7a90a8',
                  sub: burn ? 'ON THE FIRE' : hole ? 'PATCHING' : busy > 0 ? `${busy} AT WORK` : fly > 0 ? 'STANDBY' : 'DOCKED',
                  subCol: burn ? '#ff7c20' : hole ? '#8fe4ff' : busy > 0 ? '#ffd700' : undefined }];
      }
      case 'artillery': {                       // what is in the magazine (update228)
        const m = this.missileCount(), t = this.torpedoCount();
        return [{ t: `MSL ${m}`, col: m > 0 ? OK : '#7a90a8', sub: `TRP ${t}`, subCol: t > 0 ? '#4dd8c0' : '#7a90a8' }];
      }
      case 'shields': {
        const bars = sys.shieldBars ?? 0, max = sys.shieldMax ?? 0;
        return [{ t: `SHD ${bars}/${max}`, col: bars > 0 ? OK : WARN,
                  bar: bars < max ? sys.shieldChargeProgress : null }];
      }
      case 'reactor': {
        const heat = Utils.clamp(this.reactorHeat ?? 0, 0, 100);
        const H = (typeof REACTOR_HEAT_CONFIG !== 'undefined') ? REACTOR_HEAT_CONFIG : { warnHeat: 70, criticalHeat: 90 };
        const col = heat >= H.criticalHeat ? BAD : heat >= H.warnHeat ? WARN : OK;
        return [{ t: `${heatCelsius(heat)}°`, col }, { t: `${Math.round(heat)}%`, col, bar: heat / 100 }];
      }
      case 'cloaking': {
        const t = sys.cloakActive ? `ON ${Math.ceil(sys.cloakTimer ?? 0)}s`
                : (sys.cloakCd ?? 0) > 0 ? `WAIT ${Math.ceil(sys.cloakCd)}s` : 'READY';
        return [{ t, col: sys.cloakActive ? '#cc44ff' : (sys.cloakCd ?? 0) > 0 ? WARN : OK }];
      }
      default: return null;
    }
  }

  /**
   * THE BULKHEADS (update120, jj: "nie widać granicy i drzwi… powinno być
   * widać, że są odseparowane, znaczy połączone, ale modułowo"). Every
   * compartment ends in a wall: a steel frame BULKHEAD px wide on each
   * of its sides, from its ceiling down to the deck, in the yard's trim,
   * with its rivets. The door between two compartments is set into the
   * one wall they share (Door.draw cuts the opening), so two modules side
   * by side read as two rooms joined by a door — not one long room and
   * not two boxes with frames round them. Drawn once per edge.
   */
  _drawBulkheads(ctx) {
    /* none on a drawn wall (update238, jj: „pomarańczowe linie między modułami raczej niepotrzebne"): its picture has
       its own plain doorway at each end, the yard's orange trim posts were drawn over them */
    if (typeof artYard === 'function' && Door.onDrawnWall(artYard(this.layoutKey))) return false;
    const T = this.trim(), B = Ship.BULKHEAD, half = B / 2;
    const face = trimRgba(T.base, 1), lit = trimRgba(T.light, 0.75), dark = trimRgba(T.dark, 1);
    const seen = new Set();
    this.rooms.forEach(room => {
      [room.x, room.x + room.w].forEach(ex => {
        const key = room.floor + '|' + ex;
        if (seen.has(key)) return;
        seen.add(key);
        const top = room.floorTop, h = room.floorH;
        ctx.fillStyle = face;
        ctx.fillRect(ex - half, top, B, h);
        ctx.fillStyle = lit;
        ctx.fillRect(ex - half, top, 1, h);
        ctx.fillStyle = dark;
        ctx.fillRect(ex + half - 1, top, 1, h);
        ctx.fillStyle = lit;
        for (let ry = top + 4; ry < top + h - 2; ry += 9) ctx.fillRect(ex - 1, ry, 1, 1);
      });
    });
  }

  /** How thick the wall between two compartments is drawn (update120). */
  /* 4, not 8 (jj, 12.10: "za grube… lampki i logo nachodzą na ramę"):
     two pixels into each room, so nothing painted in a corner of the
     room is covered by the wall. */
  static get BULKHEAD() { return 4; }

  /* THE DECK OVER THE DUCT (update120, jj: "wentylacja na podłodze…
     poprzednia grafika wentylacji była lepsza, dodać trochę kratki do
     podłogi"). The duct runs under the deck now. On top, the walkway the
     crew stand on — a steel plate with a small grate in it every so
     often; under it the duct as it looked on the ceiling: a channel
     between two lit rails, louvred all along, a joint plate every half
     module. Every line in the yard's trim (`Ship#trim`). */
  /* ── WHAT IS IN THE DUCT IS BEHIND THE GRILLE (update128, jj: "ogień
   * w wentylacji umieść za kratkami, tak aby był w środku, nie przed;
   * tak samo szczury, pająki, jaja i kot — wszystko za kratkami") ────
   * The duct is drawn in two layers now: the BACK (the walkway on top
   * and the dark inside) and, after whatever lives or burns in there,
   * the FRONT (rails and slats). The slats are thinner than they were
   * (1 px in 5, not 3 in 4) so what is behind them can be seen. */
  /* THE DUCT IS PAINTED ONCE (update189, jj: "przycinki, jak zaczęłem
     walczyć"). Every slat of every duct was its own fillRect, both layers,
     every frame — the most of what a combat frame drew. A duct of a width
     in a trim always looks the same, so each layer of it is painted once on
     a little canvas and stamped after that. */
  _drawVents(ctx, layer = 'both') {
    if (this._drawVentArt(ctx, layer)) return;
    const T = this.trim();
    if (!Ship._ventCache || !Ship.cacheVents()) return this._paintVents(ctx, layer);
    let byTrim = Ship._ventCache.get(T);
    if (!byTrim) Ship._ventCache.set(T, (byTrim = new Map()));
    const layers = layer === 'both' ? ['back', 'front'] : [layer];
    this.rooms.forEach(room => {
      layers.forEach(L => {
        const key = `${room.w}|${L}`;
        let c = byTrim.get(key);
        if (c === undefined) {
          c = null;
          try {
            const cv = document.createElement('canvas');
            cv.width = Math.ceil(room.w); cv.height = HULL_GRID.VENT_H;
            const g = cv.getContext && cv.getContext('2d');
            if (g) { this._paintVents(g, L, [{ x: 0, w: room.w, ventY: 0 }]); c = cv; }
          } catch (e) { c = null; }
          byTrim.set(key, c);
        }
        if (c) ctx.drawImage(c, room.x, room.ventY);
        else this._paintVents(ctx, L, [room]);
      });
    });
  }

  /* ══ THE REPAIR DRONES (update229) ══════════════════════════════════
   * One drone a level, flying only while that level works and has power. Each takes a
   * job of its own — a FIRE before any module (update230), then the most broken module
   * — and works it at half a crewman; when more drones than jobs are out they double up,
   * and when there is nothing to do they hover in their cradles in the bay. The bay
   * does NOT mend itself — a broken repair bay is a job for a hand. */

  /** Drones the bay has built: one a level. */
  builtDrones() {
    const bay = this.getSystem('autorepair');
    const max = typeof DRONE_TUNING !== 'undefined' ? DRONE_TUNING.MAX : 8;
    return bay ? Utils.clamp(bay.level, 0, max) : 0;
  }
  /** …and how many of those are in the air: working levels that have power. */
  activeDrones() {
    const bay = this.getSystem('autorepair');
    if (!bay) return 0;
    return Utils.clamp(Math.min(bay.effectivePower(), bay.workingLevels), 0, this.builtDrones());
  }
  /* WHAT THE DRONES GO TO, in the order they take it (update230, jj: „tak" — a drone
     fights fires too). A FIRE FIRST, always, and the fiercest of them first: a fire
     breaks the module again a second after a drone has mended it, takes the air out of
     the room and kills whoever is standing there. Then the broken modules. */
  droneJobs() {
    const fires = ((this.fires?.fires) ?? [])
      .filter(f => !f.out && f.roomId)
      .sort((a, b) => (b.intensity ?? 0) - (a.intensity ?? 0));
    /* …AND THE HOLES (update233, jj 13.11: „czy dron ma też łatać dziury — tak"): after the fires, before
       the modules — the order a crewman keeps (fire > breach > repair). A drone patches at its own rate
       (half a crewman's, `Ship.AUTOREPAIR_RATE`), and two on one hole are as good as one man. */
    const holes = ((this.breaches?.breaches) ?? []).filter(b => !b.sealed && b.roomId);
    return [
      ...fires.map(f => ({ kind: 'fire', fire: f, roomId: f.roomId })),
      ...holes.map(b => ({ kind: 'breach', breach: b, roomId: b.roomId })),
      ...this.droneTargets().map(s => ({ kind: 'module', sys: s, roomId: s.roomId })),
    ];
  }

  /** What the drones should be mending, the worst first (never their own bay). */
  droneTargets() {
    const bay = this.getSystem('autorepair');
    return this.systems
      .filter(s => s !== bay && s.damagedLevels > 0 && s.roomId)
      .sort((a, b) => (b.damagedLevels - a.damagedLevels) || String(a.roomId).localeCompare(String(b.roomId)));
  }

  _updateDrones(dt) {
    if (typeof RepairDrone === 'undefined') return;
    const bay = this.getSystem('autorepair');
    const built = this.builtDrones();
    if (!bay || built <= 0) { this.drones.length = 0; return; }
    const bayRoom = this.getRoomById(bay.roomId) ?? this.rooms[0];
    if (!bayRoom) return;
    while (this.drones.length < built) this.drones.push(new RepairDrone({ index: this.drones.length }));
    if (this.drones.length > built) this.drones.length = built;

    const live = this.activeDrones();
    const jobs = this.droneJobs();
    const cradles = (typeof moduleSpots === 'function' && bayRoom.w <= HULL_GRID.MODULE_W) ? moduleSpots('autorepair', artYard(this.layoutKey))?.drones ?? null : null;   // update237
    this.drones.forEach((d, i) => {
      const dock = d.dockPoint(bayRoom, built, cradles);
      if (!d._placed) { d.x = dock.x; d.y = dock.y; d._placed = true; }
      const job = i < live && jobs.length ? jobs[i % jobs.length] : null;
      const room = job ? this.getRoomById(job.roomId) : null;
      d.flying = i < live;
      if (!job || !room) {              // grounded, or nothing to do: home to its cradle
        d.working = false;
        d.onFire = false;
        d.onBreach = false;
        d.roomId = null;
        d.moveTo(dock.x, dock.y, dt);
        return;
      }
      d.roomId = job.roomId;
      d.onFire = job.kind === 'fire';
      d.onBreach = job.kind === 'breach';
      const p = d.onFire ? RepairDrone.firePoint(job.fire)
              : d.onBreach ? RepairDrone.breachPoint(job.breach, room) : RepairDrone.workPoint(room);
      d.working = d.moveTo(p.x, p.y, dt);
      if (!d.working) return;
      if (d.onFire) job.fire.suppress(dt * Ship.AUTOREPAIR_RATE);
      else if (d.onBreach) job.breach.repair(dt * Ship.AUTOREPAIR_RATE, null);
      else job.sys.repair(dt * Ship.AUTOREPAIR_RATE);
    });
  }

  /* THE MAGAZINE IN THE ARTILLERY BAY (update228, jj: „moduł artylerii ma gotowe miejsca na torpedy i rakiety,
     4 torpedy max, 8 rakiet max… gracz będzie widział, czy ma pełny magazynek albo ile sztuk"): the drawn room
     has a rack of eight cradles and four torpedo cells — a missile stands in a cradle and a torpedo lies in a
     cell for each one aboard (a rack's worth: 8 and 4). Only where that picture is the one drawn. */
  magazineView(room) {
    const M = typeof moduleSpots === 'function' ? moduleSpots('artillery', artYard(this.layoutKey))?.magazine : null;
    if (!M || room?.type !== 'artillery') return null;
    const sx = room.w / 100, sy = room.floorH / 50;
    const P = r => ({ x: room.x + r.x * sx, y: room.floorTop + r.y * sy, w: r.w * sx, h: r.h * sy });
    return { missiles: M.missiles.slice(0, Math.min(M.missiles.length, this.missileCount())).map(P),
             torpedoes: M.torpedoes.slice(0, Math.min(M.torpedoes.length, this.torpedoCount())).map(P) };
  }
  _drawMagazine(ctx, room) {
    const V = this.magazineView(room);
    if (!V) return;
    V.missiles.forEach(r => {                      // standing, nose up
      const cx = r.x + r.w / 2;
      ctx.fillStyle = '#dfe6ee'; ctx.fillRect(cx - r.w * 0.28, r.y + r.h * 0.26, r.w * 0.56, r.h * 0.62);
      ctx.fillStyle = '#ff7c20';
      ctx.beginPath(); ctx.moveTo(cx, r.y); ctx.lineTo(cx + r.w * 0.28, r.y + r.h * 0.26); ctx.lineTo(cx - r.w * 0.28, r.y + r.h * 0.26); ctx.closePath(); ctx.fill();
      ctx.fillStyle = '#7a8796'; ctx.fillRect(cx - r.w * 0.45, r.y + r.h * 0.84, r.w * 0.9, r.h * 0.16);
    });
    V.torpedoes.forEach(r => {                     // lying, nose to the right
      const cy = r.y + r.h / 2, hh = r.h * 0.3;
      ctx.fillStyle = '#2b3a48'; ctx.fillRect(r.x + r.w * 0.08, cy - hh, r.w * 0.66, hh * 2);
      ctx.fillStyle = '#4dd8c0';
      ctx.beginPath(); ctx.moveTo(r.x + r.w * 0.74, cy - hh); ctx.lineTo(r.x + r.w * 0.94, cy); ctx.lineTo(r.x + r.w * 0.74, cy + hh); ctx.closePath(); ctx.fill();
      ctx.fillRect(r.x + r.w * 0.3, cy - hh, r.w * 0.06, hh * 2);
      ctx.fillStyle = '#ffb020'; ctx.fillRect(r.x + r.w * 0.04, cy - hh * 0.6, r.w * 0.05, hh * 1.2);
    });
  }

  /** Whose drawn doors, ducts and lift this hull has (update226): her builder, when GPT v15 drew that yard. */
  partYard() {
    const y = typeof artYard === 'function' ? artYard(this.layoutKey) : null;
    return (y && typeof PART_ART !== 'undefined' && PART_ART.shaft[y]) ? y : null;
  }

  /* THE DRAWN DUCT (update226, GPT v15): the yard's duct, one picture a module (100 x 20), the back (inside: pipes,
     fans) under what crawls in it and the front (the grille) over it. A room wider than a module repeats it. */
  _drawVentArt(ctx, layer) {
    const yard = this.partYard();
    if (!yard) return false;
    const back = partArt('duct_back', yard), front = partArt('duct_front', yard);
    if (!back || !front) return false;
    const W = HULL_GRID.MODULE_W, H = HULL_GRID.VENT_H;
    const imgs = layer === 'both' ? [back, front] : [layer === 'back' ? back : front];
    this.rooms.forEach(room => {
      imgs.forEach(img => {
        for (let x = 0; x < room.w - 0.5; x += W) {
          const w = Math.min(W, room.w - x);
          drawPart(ctx, img, room.x + x, room.ventY, w, H, 0, 0, img.width * w / W, img.height);
        }
      });
    });
    return true;
  }

  _paintVents(ctx, layer = 'both', rooms = this.rooms) {
    const H = HULL_GRID.VENT_H, T = this.trim(), WALK = 3;
    const shell = trimRgba(T.dark.map(v => Math.round(v * 0.45)), 0.97);
    const rail  = trimRgba(T.seam, 1), lit = trimRgba(T.light, 0.55);
    const slat  = trimRgba(T.base, 0.9), slatD = trimRgba(T.dark.map(v => Math.round(v * 0.4)), 1);
    const plate = trimRgba(T.base, 1), plateL = trimRgba(T.light, 0.75), plateD = trimRgba(T.dark, 1);
    const back = layer !== 'front', front = layer !== 'back';
    rooms.forEach(room => {
      const x = room.x, w = room.w, top = room.ventY;
      const y = top + WALK, D = H - WALK;
      if (back) {
        // the walkway, with a small grate in it every 25 px
        ctx.fillStyle = plate;
        ctx.fillRect(x, top, w, WALK);
        ctx.fillStyle = plateL;
        ctx.fillRect(x, top, w, 1);
        for (let gx = x + 9; gx + 7 <= x + w; gx += 25) {
          ctx.fillStyle = plateD;
          ctx.fillRect(gx, top + 1, 7, WALK - 1);
          ctx.fillStyle = plate;
          for (let k = 1; k < 7; k += 2) ctx.fillRect(gx + k, top + 1, 1, WALK - 1);
        }
        // the inside of the duct
        ctx.fillStyle = shell;
        ctx.fillRect(x, y, w, D);
        ctx.fillStyle = 'rgba(0,0,0,0.35)';
        ctx.fillRect(x, y + 3, w, 2);                    // the shadow under the top rail
      }
      if (front) {
        ctx.fillStyle = rail;
        ctx.fillRect(x, y + 1, w, 2);
        ctx.fillRect(x, y + D - 3, w, 2);
        ctx.fillStyle = lit;
        ctx.fillRect(x, y + 1, w, 1);
        ctx.fillRect(x, y + D - 3, w, 1);
        for (let tx = x + 3; tx < x + w - 3; tx += 5) {
          ctx.fillStyle = slatD;
          ctx.fillRect(tx, y + 3, 1, D - 6);
          ctx.fillStyle = slat;
          ctx.fillRect(tx + 1, y + 3, 1, D - 6);
        }
        for (let jx = x; jx < x + w; jx += HULL_GRID.MODULE_W / 2) {
          ctx.fillStyle = rail;
          ctx.fillRect(jx, y, 3, D - 1);
          ctx.fillStyle = lit;
          ctx.fillRect(jx + 1, y + 2, 1, 1);
          ctx.fillRect(jx + 1, y + D - 4, 1, 1);
        }
        ctx.fillStyle = trimRgba(T.base, 0.95);
        ctx.fillRect(x, top + H - 1, w, 1);
      }
    });
  }

  /* WHAT IS LEFT TO SEARCH ON A WRECK (update84). The hold opens when
     every compartment has had somebody in it, so which ones have not
     is the thing the player is steering by — shown on the hull, not in
     a counter. */
  _drawSearch(ctx) {
    if (!this.isDerelict) return;
    this.rooms.forEach(room => {
      if (this.isSearched(room.id)) return;
      ctx.fillStyle = 'rgba(0,0,0,0.38)';
      ctx.fillRect(room.x, room.floorTop, room.w, room.floorH);
      ctx.fillStyle = 'rgba(255,200,97,0.75)';
      ctx.font = '9px Share Tech Mono, monospace';
      ctx.textAlign = 'center';
      ctx.fillText('UNSEARCHED', room.cx, room.floorTop + room.floorH - 4);
    });
  }

  _drawEggs(ctx) {
    const eggs = (this.cargo?.items ?? []).filter(it =>
      it.def?.tag === 'egg' && it.meta && typeof it.meta === 'object' &&
      it.meta.roomId != null);
    if (!eggs.length) return;
    const t = (typeof performance !== 'undefined' ? performance.now() : 0) * 0.003;
    eggs.forEach(egg => {
      // Seen only where somebody is standing (update86a), like the pests.
      if (!this.pestVisible(egg.meta.roomId)) return;
      const room = this.getRoomById(egg.meta.roomId);
      if (!room) return;
      /* IN THE DUCT OVER WHERE HE FELL (update84, U10A: "jaja pająków
         pojawiają się w wentylacji"). Still the cargo item and nothing
         else — selling it takes it out of the duct as well. The x he
         fell at is kept, clamped inside the duct; the `y` an older save
         carries was the deck and is simply not read any more. */
      const x = Utils.clamp(egg.meta.x ?? room.cx, room.x + 8, room.x + room.w - 8);
      const y = room.ventY + room.ventH / 2;
      // The nearer it is to splitting, the harder it moves.
      const left = Utils.clamp((egg.meta.hatchT ?? EGG_SECONDS) / EGG_SECONDS, 0, 1);
      const beat = 1 + 0.12 * (1 - left) * Math.sin(t * (2 + (1 - left) * 6));
      ctx.save();
      ctx.globalAlpha = 0.85;
      ctx.fillStyle = 'rgba(30,60,26,0.9)';
      ctx.beginPath();
      ctx.ellipse(x, y, 5 * beat, 7 * beat, Math.PI / 2, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = egg.def.col || '#9fff7a';
      ctx.lineWidth = 1.5;
      ctx.stroke();
      ctx.globalAlpha = 1;
      ctx.fillStyle = egg.def.col || '#9fff7a';
      ctx.font = '9px monospace';
      ctx.textAlign = 'center';
      ctx.fillText('◓', x, y + 3);
      ctx.restore();
    });
  }

  draw(ctx) {
    // Cloaking field: powered cloak renders the whole ship as a
    // shimmering phantom (visual feedback for the evasion bonus)
    const cloakSys = this.getSystem('cloaking');
    const cloaked  = !!(cloakSys && cloakSys.cloakActive);
    if (cloaked) {
      /* A STEADY VEIL, NOT A BREATHING ONE (update90a). The whole hull
         used to pulse between 43% and 67% opacity, slowly, for as long as
         the cloak ran — the player saw an enemy ship whose lights kept
         going down and up again ("ciemnieje jakby światło gasło, dziwnie
         miga") and nothing on it said why. Now it is simply dimmed, and
         the outline and the word CLOAKED below say what it is. */
      ctx.save();
      ctx.globalAlpha = Ship.CLOAK_ALPHA;
    }

    /* ── THE PLATE FOLLOWS THE MODULES (update73) ───────────
     *
     * It used to be ONE rounded rectangle around `roomBounds()`, which
     * was fine while every hull in the game was a solid block. The
     * moment Bastet grew a spur on her upper deck the plate covered
     * the empty square beneath it, and the starter ship looked like a
     * ship with a hole in her — a bug, not a silhouette.
     *
     * So the plate is the UNION of the modules. Each room contributes
     * its own rounded rectangle to one path; overlapping fills merge
     * under nonzero winding, so what is left is an outline that walks
     * round the actual hull, notches and spurs included.
     *
     * The rim is done by filling twice rather than stroking, because
     * stroking a path of overlapping rectangles draws every internal
     * edge as well: fill the union in the rim colour, then fill it
     * again three pixels smaller in the plate colour.
     *
     * The 14 that used to be written here was MARGIN before MARGIN was
     * a tile wide. One more copy of a number the grid already owned. */
    const b = this.roomBounds();
    /* TRACKS UNDER A MECH (update94) — drawn first, so the hull sits on
       them: two long treads with road wheels, the links creeping along. */
    /* …unless her own picture has its treads (update198: Ptah as drawn) */
    if (this.layout?.tracks && !this.hullArtGeometry?.()?.shaped) this._drawTracks(ctx, b);
    /* ARMOUR (update94): a thick steel rim before the plate — a bunker
       or a mech reads as armoured before anybody reads a number. */
    if ((this.armor ?? 0) > 0) {
      this._hullPlatePath(ctx, -4);
      ctx.fillStyle = '#6a7180';
      ctx.fill();
    }
    /* THE DRAWN HULL (update116), when there is one for this hull and
       it fits: the picture IS the plate, the rim and the nacelles. The
       armour rim above still goes under it, the damage glow and the
       cloak still go over it — those are states, not the ship. */
    const art = this.hullArt();
    /* her thrusters burn UNDER the picture: the nozzle's metal is GPT's,
       on top; the flame comes out of it (update176) */
    if (art?.geom?.shaped && !this.layout?.grounded) this._drawThrusters(ctx, art.geom, this.enginesRunning() && !this.isMoored());
    if (art) {
      const B = art.geom.box;
      ctx.drawImage(art.img, B.x, B.y, B.w, B.h);       // a shaped one is 1.5 px a unit (update175)
    } else {
      this._hullPlatePath(ctx, 0);
      ctx.fillStyle = this.isPlayer ? '#1e3a5c' : '#5c1e1e';
      ctx.fill();
      this._hullPlatePath(ctx, 3);
      ctx.fillStyle = 'rgba(10,14,26,0.97)';
      ctx.fill();
    }

    // Engine glow at rear — nothing burns at the stern of a thing on the ground.
    // With a drawn hull it burns where the nozzles are: one per nacelle.
    if (!this.layout?.grounded && !art?.geom?.shaped) {     // a shaped hull burns her own (update176)
      const glows = art
        ? art.geom.engines.map(e => ({ x: e.exhaustX + (this.facesRight ? -4 : 4), y: e.y + e.h / 2 }))
        : [{ x: this.facesRight ? b.x - 14 : b.x + b.w + 14, y: b.y + b.h / 2 }];
      glows.forEach(p => {
        const R = art ? 18 : 30;                // a nacelle's nozzle is small (update121)
        const g = ctx.createRadialGradient(p.x, p.y, 2, p.x, p.y, R);
        g.addColorStop(0, this.isPlayer ? 'rgba(26,255,140,0.6)' : 'rgba(255,80,40,0.6)');
        g.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.fillStyle = g;
        ctx.fillRect(p.x - R, p.y - R, R * 2, R * 2);
      });
    }

    /* THE WINDOW'S SLACK (update238, jj: „mała przerwa na dole i na górze między modułami a kadłubem, tło przelatuje"):
       a drawn hull's window is cut a hair larger than the modules — a dark strip under it, the rooms over it. */
    if (art?.geom?.shaped) {
      ctx.fillStyle = '#16130f';
      this.rooms.forEach(r => ctx.fillRect(r.x - 2, r.y - 1.5, r.w + 4, r.h + 3));     // update240: 2 at the sides (jj: black gaps by the duct)
      const b0 = this.roomBounds();
      (this.elevators?.shafts ?? []).forEach(sh => ctx.fillRect(sh.x - HULL_GRID.SHAFT_W / 2 - 1, b0.y - 1.5, HULL_GRID.SHAFT_W + 2, b0.h + 3));
    }
    // Rooms (with systems, O2, fire, breach overlays)
    this._feedModuleMotion();
    this.rooms.forEach(room => {
      if (room.system) {
        room.system.draw(ctx);
        if (room.type === 'artillery') this._drawMagazine(ctx, room);
      } else {
        // Empty module — floor tile + visible frame (crew quarters,
        // or an enemy hull slot with no system installed)
        this._drawEmptyRoom(ctx, room);
      }

      // O2 overlay
      const ro = this.oxygen.getRoom(room.id);
      if (ro) ro.draw(ctx, room.x, room.y, room.w, room.h,
        typeof moduleLamps === 'function' ? moduleLamps(room.system?.type ?? room.art ?? 'empty', artYard(this.layoutKey)) : null);

      // HIT FLASH — a shell landing here lights the compartment for a
      // moment. Without it a hit on a far room is easy to miss entirely.
      if (room._hitFlash > 0) {
        ctx.fillStyle = `rgba(255,255,255,${0.55 * room._hitFlash})`;
        ctx.fillRect(room.x, room.y, room.w, room.h);
        ctx.strokeStyle = `rgba(255,90,110,${room._hitFlash})`;
        ctx.lineWidth = 2;
        ctx.strokeRect(room.x + 1, room.y + 1, room.w - 2, room.h - 2);
      }
    });

    // What each module is doing, on its own display (update120).
    this._drawModuleScreens(ctx);
    // …and the reactor's pips on its core (update122).
    this._drawReactorCore(ctx);
    /* …and the TANKS beside their modules (update191): the air by the O₂,
       the He2 by the engines — pips for what is left, a drip when it leaks. */
    if (typeof Tanks !== 'undefined' && !this.isDerelict) {
      const tt = (typeof performance !== 'undefined' ? performance.now() : Date.now()) / 1000;
      Tanks.drawOnModule(ctx, this, 'air', tt); Tanks.drawOnModule(ctx, this, 'he2', tt);
    }

    // The ceiling ducts — over the floor plates, under the doors.
    this._drawVents(ctx, 'back');
    this._drawDuctState(ctx, 'back');
    /* …and what is in them (update84): egg cases, sacs, rats, spiders —
       and since update128 the cat on a hunt — BEHIND the slats, which
       are drawn over them next. A spider on its way down is drawn here
       too and passes behind nothing that matters. */
    this._drawEggs(ctx);
    this.pests.forEach(p => { if (!p._climb) p.draw(ctx, this); });
    this.crew.forEach(c => { if (c && c.isPet && c._ductY != null && !c.dead) c.draw(ctx); });
    this._drawVents(ctx, 'front');
    this._drawDuctState(ctx, 'front');
    this._drawSearch(ctx);

    // The bulkheads between compartments, with the doorways in them (update120)
    this._drawBulkheads(ctx);

    // Elevators — in the ship's trim (update120)
    this.elevators.trim = this.trim();
    this.elevators.yard = this.partYard();          // the drawn trunk and cabin, when the yard has them (update226)
    this.elevators.draw(ctx);
    /* …and whatever is climbing a shaft goes on top of it (update86a).
       Drawn with the others it was painted over by the shaft itself —
       the first screenshot of a climbing rat showed an empty shaft. */
    this.pests.forEach(p => { if (p._climb) p.draw(ctx, this); });

    // Doors
    const trim = this.trim();
    const pyard = this.partYard();
    this.doors.forEach(d => d.draw(ctx, trim, pyard));

    // Crew (particles below crew)
    Particles.draw(ctx, 0);
    /* ZERO-G (update91): nobody stands on the deck — everybody hangs a
       little off it and bobs, each on his own phase. Drawing only: where
       a man IS does not change, the rules aboard read the same x and y.
       A cabin carries its rider and a cat in the duct is drawn there. */
    const zg = this.zeroG;
    const now = (typeof performance !== 'undefined' ? performance.now() : 0) / 1000;
    if (zg) this._drawZeroGMotes(ctx, now);
    this.crew.forEach((c, i) => {
      if (c && c.isPet && c._ductY != null && !c.dead) return;   // drawn in the duct, behind the grille
      if (zg && c && !c._ridingShaft && c._ductY == null) {
        ctx.save();
        ctx.translate(0, Ship.floatOffset(now, i, c.down));
        c.draw(ctx);
        ctx.restore();
      } else c.draw(ctx);
    });
    /* THE WEAPONS GO ON TOP (update174): every hand's knife or gun, the
       shots in flight and the charges, after every man is drawn — a duel
       partner standing in front no longer hides the blade. */
    if (typeof CrewArms !== 'undefined') {
      this.crew.forEach((c, i) => {
        if (!c || !(c.sidearm || c._shot) || c.dead || (c.isPet && c._ductY != null)) return;
        const lift = (zg && !c._ridingShaft && c._ductY == null) ? Ship.floatOffset(now, i, c.down) : 0;
        if (lift) { ctx.save(); ctx.translate(0, lift); }
        CrewArms.drawHeld(ctx, c);
        CrewArms.drawOver(ctx, c);
        if (lift) ctx.restore();
      });
    }

    // the drawn doors' lower leaf and threshold in front of whoever is in the doorway (update240)
    this.doors.forEach(d => d.drawLowerOver?.(ctx, pyard));
    /* The repair drones over everybody's heads (update229): they fly near the
       ceiling, so they are drawn after the crew and before the fires. */
    this.drones.forEach(d => d.draw(ctx, this));
    /* …and the patrol's inspectors searching our deck (update231): not crew of ours, not on the roster. */
    if (this.inspectors) this.inspectors.forEach(c => c?.draw?.(ctx));

    // Fires
    this.fires.draw(ctx);

    // Breaches
    this.breaches.draw(ctx);

    /* THE GUN STRIPS STAY SOLID UNDER A CLOAK (update54).
       Everything from here up was drawn through the cloak's pulsing
       globalAlpha, the charge boxes on the mounts included — so while
       either side was cloaked the one readout that says "how long until
       that gun fires" faded in and out at a third of its brightness and
       READ AS FROZEN. The guns were charging the whole time (nothing in
       the engine ties charge to a cloak, and section 173 nails that
       down); the player simply could not see them move. The field hides
       the hull, not its gunnery clock. */
    /* THE ROOF (update118) — over the compartments and everything in
       them, under the guns and the shield. 0 is the cutaway the fight
       is played on; the base and the jump show her closed, and the
       fight opens her (JumpScene fades this). */
    if (this.roofAlpha > 0) this._drawRoof(ctx, Math.min(1, this.roofAlpha));

    const cloakAlpha = ctx.globalAlpha;
    if (cloaked) ctx.globalAlpha = 1;
    this._drawWeaponMounts(ctx);
    if (cloaked) ctx.globalAlpha = cloakAlpha;

    // Shield ring
    this._drawShield(ctx);

    /* Hull damage glow — ON THE HULL (update97). It was a rectangle over
       the whole bounding box, so a hull with a notch or a spur glowed red
       over empty space where there are no modules at all (jj). The plate
       path is the union of the modules, the same outline the hull is
       drawn with, grown a little so the glow still reads as an aura. */
    if (this.hull / this.hullMax < 0.35) {
      const alpha = (0.35 - this.hull / this.hullMax) * 0.5;
      this._hullPlatePath(ctx, -4);
      ctx.fillStyle = `rgba(255,45,68,${alpha})`;
      ctx.fill();
    }

    if (cloaked) {
      ctx.restore();
      /* NO FRAME, NO LABEL (update127, jj: "zlikwidować purpurową
         obwódkę jak statek robi cloaked, tak samo napis info nachodzi na
         działo — usuń"). The see-through hull IS the sign; the seconds
         left are on the cloak's own pip in the power panel. */
    }
  }

  /** How see-through a cloaked hull is drawn — steady (update90a). */
  static get CLOAK_ALPHA() { return 0.45; }

  /** Empty room: tiled floor, subtle grid line, clear frame */
  _drawEmptyRoom(ctx, room) {
    /* The INTERIOR, not the module (update73) — the same rule
       `_fitSystemToRoom` applies to a fitted module. A bay's floor
       plate stops where the ceiling duct begins, or the grille ends up
       drawn on top of a floor that is pretending to be up there. */
    const x = room.x, y = room.floorTop, w = room.w, h = room.floorH;
    /* The empty bay's picture (update119): bare walls and a few crates. */
    const art = typeof moduleArt === 'function'
      ? (room.art && moduleArt(room.art, artYard(this.layoutKey))) || moduleArt('empty', artYard(this.layoutKey)) : null;
    const tile = !art && Assets.has('room_default') ? Assets.get('room_default') : null;
    if (art) {
      drawModuleArt(ctx, art, x, y, w, h);
    } else if (tile) {
      ctx.save();
      ctx.globalAlpha = 0.8;
      Assets.tileRect(ctx, tile, x, y, w, h, 48);
      ctx.restore();
    } else {
      ctx.fillStyle = 'rgba(16,22,38,0.9)';
      ctx.fillRect(x, y, w, h);
    }

    /* No frame round it (update120): a room is its walls, and between
       two rooms there is a door or an opening, nothing else. Only the
       code-drawn bay keeps one, so it still reads as a room at all. */
    if (!art) {
      ctx.strokeStyle = 'rgba(110,135,175,0.55)';
      ctx.lineWidth = 1.5;
      ctx.strokeRect(x + 0.5, y + 0.5, w - 1, h - 1);
    }
  }

  /**
   * Guns sit ON the hull, along the top edge, spread across its width —
   * they used to float off the nose in a vertical stack, which read as a
   * detached UI widget rather than as part of the ship.
   */
  /**
   * WHERE EVERY GUN ON THIS HULL IS — ONE ANSWER (update80).
   *
   * This layout used to live inside `_drawWeaponMounts` as a local
   * `gx` in a forEach, and the shot came out of `combat.js` at
   * `roomBounds().x + w + 10, y + h/2` — the corner of the rectangle
   * round the WHOLE ship. So the gun was drawn along the top edge and
   * fired from the flank, and every gun aboard fired from the same
   * pixel no matter which bay it was bolted into. Two positions for
   * one gun, in two files, that had never met.
   *
   * The player put it plainly: "a wystrzal rakieta lasery i wszytko
   * pociski powinny wychodzic z dzialek a nie z przodu statku".
   *
   * One function answers it now, and both the picture and the bolt
   * read it. `muzzle` is the tip of the barrel on the side the gun
   * points at — which is the enemy, because `dir` is the same flag
   * the sprite is drawn with.
   */
  weaponMounts() {
    const b = this.roomBounds();
    const mounted = this.weapons.filter(Boolean);
    if (!mounted.length) return [];

    // Space the mounts by whichever is wider — the gun or its charge
    // strip — so an 18-second cannon's boxes never run into its neighbour.
    const GW = 44, GH = 18, GAP = 14;
    /* the charge is inside the gun now (update138): the gun is the width */
    const widths = mounted.map(() => GW);
    const total = widths.reduce((a, b) => a + b, 0) + (mounted.length - 1) * GAP;
    /* ON THE PLATE (update121, jj: "broń wygląda, jakby nie była
       przyczepiona do kadłuba"). The gun sits down on the top of the
       hull — its underside two pixels into the plate, on a mount — and
       its charge boxes go ABOVE it. The row keeps clear of the top
       nacelle at the stern. */
    const geom = this.hullArtGeometry?.();
    const nac = geom?.engines?.find(e => e.side === 'top');
    let lo = b.x, hi = b.x + b.w;
    if (nac) {
      if (this.facesRight) lo = Math.max(lo, nac.x + nac.w + 6);       // her stern's nacelle, whichever way she points (update215)
      else hi = Math.min(hi, nac.x - 6);
    }
    const span = hi - lo;
    const startX = Math.round(lo + Math.max(6, (span - total) / 2));
    const y = Math.round(b.y - HULL_GRID.MARGIN - GH + 2);
    /* ON HER TOP (update176, jj: "broń zlewa się z kadłubem, przenieść
       wyżej"). A shaped hull's top is GPT's ridges, a deck's height of
       armour above the modules: the gun stands on the highest of it
       under its own feet, not sunk in it at the module line. */
    const onTop = (x) => {
      if (!geom?.shaped || !geom.topAt) return y;
      const t = geom.topAt(x + 4, x + GW - 4);
      return t == null ? y : Math.round(Math.min(y, t - GH + 3));
    };
    /* `gunsFace` (update131): the title screen's chase has YOUR hull
       shooting back over its stern at the raider behind it. */
    const dir = this.gunsFace ?? (this.isPlayer ? 1 : -1);      // point at the enemy

    /* ON HER SOCKETS (update235, jj 13.11: „każdy moduł na dachu ma slot na broń… kokpit nie"): a hull drawn to the
       new standard has a gun socket over every top-deck module but the bridge — the guns go onto them, the one
       nearest the bow first. */
    const sockets = geom?.sockets
      ? this.rooms.filter(r => r.y === Math.min(...this.rooms.map(q => q.y)) && r.type !== 'piloting')
          .map(r => Math.round(r.x + r.w / 2 - GW / 2)).sort((a, b) => this.facesRight ? b - a : a - b)
      : [];
    const out = [];
    let gx = startX;
    mounted.forEach((w, i) => {
      // draw() centres itself on the 44px gun box, so offset by the
      // difference when the strip is the wider of the two.
      const x = mounted.length <= sockets.length ? sockets[i] : gx + Math.round((widths[i] - GW) / 2);
      const my = onTop(x);
      /* A DRAWN GUN (update242): its base dropped into the socket ring under it (the ring nearest the mount, when
         her picture has rings), or stood on the roof where the old gun stood */
      const art = typeof Weapon !== 'undefined' && Weapon.hullArt ? Weapon.hullArt(w.defKey) : null;
      if (art) {
        const A = art.A, c0 = x + GW / 2;
        const ring = (geom?.rings ?? []).filter(r => Math.abs(r.cx - c0) < 30).sort((a, b) => Math.abs(a.cx - c0) - Math.abs(b.cx - c0))[0];
        const bcx = ring ? ring.cx : c0, bot = ring ? ring.top + GUN_ART.SEAT : my + GH + 2;
        const ax = dir > 0 ? bcx - A.base.cx : bcx - (A.w - A.base.cx), ay = bot - A.base.bottom;
        out.push({ weapon: w, x: ax, y: ay, w: A.w, h: A.h, dir, art, ring: ring ?? null,
                   muzzleX: dir > 0 ? ax + A.muzzle.x : ax + A.w - A.muzzle.x, muzzleY: ay + A.muzzle.y });
        gx += widths[i] + GAP;
        return;
      }
      out.push({
        weapon: w, x, y: my, w: GW, h: GH, dir,
        muzzleX: dir > 0 ? x + GW : x,
        muzzleY: my + GH / 2,
      });
      gx += widths[i] + GAP;
    });
    return out;
  }

  /** Where one weapon's barrel ends, or null if it is not mounted. */
  muzzleFor(weapon) {
    const m = this.weaponMounts().find(q => q.weapon === weapon);
    return m ? { x: m.muzzleX, y: m.muzzleY } : null;
  }

  _drawWeaponMounts(ctx) {
    const T = this.trim();
    this.weaponMounts().forEach(m => {
      if (m.art) { m.weapon.drawArt(ctx, m); return; }      // update242: the drawn gun, seated in its ring
      /* THE MOUNT (update121): a hardpoint on the plate under the gun's
         housing, in the ship's trim — a raised ring the turret turns on. */
      const back = m.dir > 0 ? m.x : m.x + m.w * 0.5;      // the housing half
      const mw = m.w * 0.5, top = m.y + m.h * 0.45, plate = m.y + m.h + 2;
      ctx.fillStyle = trimRgba(T.base, 1);
      ctx.beginPath();
      ctx.moveTo(back - 3, plate); ctx.lineTo(back + 2, top); ctx.lineTo(back + mw - 2, top); ctx.lineTo(back + mw + 3, plate);
      ctx.closePath(); ctx.fill();
      ctx.fillStyle = trimRgba(T.light, 0.8);
      ctx.fillRect(back + 2, top, mw - 4, 1);
      ctx.fillStyle = trimRgba(T.dark, 1);
      ctx.fillRect(back - 3, plate - 1, mw + 6, 1);
      m.weapon.draw(ctx, m.x, m.y, false, m.dir, { onHull: true });
    });
  }

  /* ── THE BUBBLE FOLLOWS THE HULL (update142, jj 20.10: „osłona
   * teraz jest jajowata, da się zrobić, aby obejmowała bryłę statku…
   * 1 warstwa to 1 rząd, aby nie była za gruba; weź pod uwagę broń na
   * górze, aby osłona nie zasłaniała broni") ────────────────────
   *
   * The shield is no longer an ellipse round the room box. It is the
   * set of points a fixed distance from the HULL — the plate round every
   * module and lift trunk, the nacelles, the bow, and the guns on the
   * roof — so it hugs an L-shaped hull as an L and goes OVER the guns
   * instead of cutting through them.
   *
   * The hull is a handful of rectangles, and the distance from a point
   * to a rectangle is two subtractions and a hypot, so the shape needs
   * no picture and no pixels: it is the same in the browser, in the
   * node harness and in every hit test. Layer k sits at
   * SHIELD_GAP + k * SHIELD_STEP from the hull and is ONE row of hexes.
   *
   * Everything is kept relative to the room box's corner, so a hull
   * that moves (the title chase, the jump films) keeps its cached cells.
   */
  static get SHIELD_HEX()  { return 4.5; }     // a cell of the honeycomb (update128)
  static get SHIELD_GAP()  { return 13; }      // hull → the first layer
  static get SHIELD_STEP() { return 9; }       // one layer → the next

  /** The rectangles the bubble keeps its distance from, relative to
   *  the room box's corner (`o`). */
  shieldShape() {
    const b = this.roomBounds();
    const o = { x: b.x, y: b.y };
    const g = this.hullArtGeometry?.();
    const abs = [];
    if (g) {
      g.plate.forEach(r => abs.push(r));
      g.engines.forEach(r => abs.push(r));
      g.prows.forEach(r => abs.push(r));
      /* a SHAPED hull (update175): the bubble goes round the picture,
         not through the ridges and the bow drawn round the modules */
      if (g.shaped) abs.push({ x: g.box.x + 6, y: g.box.y + 4, w: g.box.w - 12, h: g.box.h - 8 });
    } else {
      this.rooms.forEach(r => abs.push({ x: r.x, y: r.y, w: r.w, h: r.h }));
    }
    (this.weaponMounts?.() ?? []).forEach(m => abs.push({ x: m.x, y: m.y, w: m.w, h: m.h + 2 }));
    const rects = abs.map(r => ({ x: Math.round(r.x - o.x), y: Math.round(r.y - o.y),
                                  w: Math.round(r.w), h: Math.round(r.h) }));
    const key = rects.map(r => `${r.x},${r.y},${r.w},${r.h}`).join(';');
    if (!this._shieldCache || this._shieldCache.key !== key) {
      let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
      rects.forEach(r => { x0 = Math.min(x0, r.x); y0 = Math.min(y0, r.y);
                           x1 = Math.max(x1, r.x + r.w); y1 = Math.max(y1, r.y + r.h); });
      this._shieldCache = { key, rects, box: { x: x0, y: y0, w: x1 - x0, h: y1 - y0 }, cells: [] };
    }
    return { o, ...this._shieldCache };
  }

  /** How far (x, y) is from the hull — 0 on or inside it. */
  shieldDist(x, y, shape = this.shieldShape()) {
    const px = x - shape.o.x, py = y - shape.o.y;
    let best = Infinity;
    for (const r of shape.rects) {
      const dx = Math.max(r.x - px, 0, px - r.x - r.w);
      const dy = Math.max(r.y - py, 0, py - r.y - r.h);
      const d = dx * dx + dy * dy;
      if (d < best) best = d;
    }
    return Math.sqrt(best);
  }

  /** Layer k's distance from the hull (0 = the innermost). */
  static shieldRadius(k) { return Ship.SHIELD_GAP + k * Ship.SHIELD_STEP; }

  /** The hexes of layer k, relative to the room box's corner, cached:
   *  every cell of one honeycomb whose centre falls in that layer's
   *  band — a band one row of the lattice wide, so one row of cells. */
  shieldCells(k, shape = this.shieldShape()) {
    if (shape.cells[k]) return shape.cells[k];
    const HS = Ship.SHIELD_HEX, R = Ship.shieldRadius(k);
    const sx = HS * Math.sqrt(3), sy = HS * 1.5, half = sy / 2;
    const B = shape.box, pad = R + HS * 2;
    const out = [];
    const j0 = Math.floor((B.y - pad) / sy), j1 = Math.ceil((B.y + B.h + pad) / sy);
    for (let j = j0; j <= j1; j++) {
      const y = j * sy, off = (j & 1) ? sx / 2 : 0;
      const i0 = Math.floor((B.x - pad - off) / sx), i1 = Math.ceil((B.x + B.w + pad - off) / sx);
      for (let i = i0; i <= i1; i++) {
        const x = i * sx + off;
        const d = this.shieldDist(x + shape.o.x, y + shape.o.y, shape);
        if (d >= R - half && d < R + half) out.push({ x, y, i: (j * 131 + i) & 1023 });
      }
    }
    return (shape.cells[k] = out);
  }

  /** The box round the whole bubble as an ellipse's centre and half
   *  sizes — for aiming a test shot from outside it, nothing more. The
   *  bubble itself is `insideShield`. */
  shieldEllipse() {
    const s = this.shieldShape(), R = Ship.shieldRadius(Math.max(0, (this.shieldMax ?? 1) - 1)) + Ship.SHIELD_HEX;
    return { cx: s.o.x + s.box.x + s.box.w / 2, cy: s.o.y + s.box.y + s.box.h / 2,
             rx: s.box.w / 2 + R, ry: s.box.h / 2 + R };
  }

  /** Is (x, y) inside the bubble — inside its outermost standing layer? */
  insideShield(x, y) {
    const k = Math.max(0, (this.shieldBars ?? 0) - 1);
    return this.shieldDist(x, y) <= Ship.shieldRadius(k) + Ship.SHIELD_HEX * 0.75;
  }

  /** A shot struck the bubble at (x, y): a wave runs out over the cells. */
  shieldStruck(x, y) {
    const s = this.shieldShape();
    (this._shieldWaves ??= []).push({ x: x - s.o.x, y: y - s.o.y, age: 0 });
    if (this._shieldWaves.length > 6) this._shieldWaves.shift();
    this._shieldAlpha = 1;
  }

  /** The waves age with the fight's clock, not the wall clock. */
  _ageShieldWaves(dt) {
    if (!this._shieldWaves?.length) return;
    this._shieldWaves.forEach(w => { w.age += dt; });
    this._shieldWaves = this._shieldWaves.filter(w => w.age < Ship.SHIELD_WAVE_T);
  }
  static get SHIELD_WAVE_T() { return 0.7; }

  /** IN THE YARD OR IN A PORT (update177, jj: "statek w stoczni i porcie
   *  każdej ma wyłączoną osłonę i silniki"): a ship on the hangar's cradle
   *  or in a drydock is a picture of a ship at rest — no flames out of her
   *  nozzles, no bubble round her. The fight, the jump and the menu's
   *  duel are unchanged. `moored` is set on every hull a berth draws: the
   *  base's hangar and loadout, the yard's ships for sale, the port's
   *  drydock (round its drawing of your own ship), the hull moored at a
   *  station or a prison block. */
  isMoored() { return !!this.moored; }

  _drawShield(ctx) {
    if (this.isMoored()) return;
    const bars = this.shieldBars ?? 0;
    if (this._shieldAlpha <= 0 && bars <= 0) return;
    const shape = this.shieldShape(), o = shape.o;
    const alpha = Math.max(this._shieldAlpha, bars > 0 ? 0.3 : 0);
    const t = (typeof performance !== 'undefined' ? performance.now() : 0) / 1000;
    const HS = Ship.SHIELD_HEX;
    const hex = (x, y, r) => {
      for (let k = 0; k < 6; k++) {
        const a = Math.PI / 6 + k * Math.PI / 3;          // pointy top, the lattice's own way up
        const px = o.x + x + Math.cos(a) * r, py = o.y + y + Math.sin(a) * r;
        k ? ctx.lineTo(px, py) : ctx.moveTo(px, py);
      }
      ctx.closePath();
    };
    const waves = this._shieldWaves ?? [];

    ctx.save();
    // A layer just knocked down still flashes once where it stood.
    const layers = Math.max(bars, this._shieldAlpha > 0.05 ? 1 : 0);
    for (let k = 0; k < layers; k++) {
      const cells = this.shieldCells(k, shape);
      const up = k < bars;
      const la = alpha * (up ? 1 : this._shieldAlpha);
      // the haze: the cells themselves, faintly filled
      ctx.globalAlpha = la;
      ctx.fillStyle = 'rgba(26,140,255,0.14)';
      ctx.beginPath(); cells.forEach(c => hex(c.x, c.y, HS)); ctx.fill();
      // the lattice
      ctx.globalAlpha = la * 0.85;
      ctx.strokeStyle = '#4db8ff'; ctx.lineWidth = 1;
      ctx.beginPath(); cells.forEach(c => hex(c.x, c.y, HS)); ctx.stroke();
      // a few cells lit, in turn
      ctx.globalAlpha = la;
      ctx.fillStyle = 'rgba(143,212,255,0.35)';
      ctx.beginPath();
      cells.forEach(c => { if (Math.sin(t * 1.7 + c.i * 0.61 + k * 2.1) > 0.93) hex(c.x, c.y, HS - 0.5); });
      ctx.fill();
      // where it was struck: a ring of bright cells running outwards
      if (waves.length) {
        ctx.fillStyle = 'rgba(191,232,255,0.8)';
        ctx.beginPath();
        let any = false;
        cells.forEach(c => {
          for (const w of waves) {
            const a = w.age / Ship.SHIELD_WAVE_T, rad = 6 + a * 120;
            if (Math.abs(Math.hypot(c.x - w.x, c.y - w.y) - rad) < HS * 1.2 * (1 - a * 0.5)) { hex(c.x, c.y, HS - 0.5); any = true; break; }
          }
        });
        if (any) { ctx.globalAlpha = la * 0.9; ctx.fill(); }
      }
    }
    ctx.globalAlpha = 1;
    ctx.restore();
  }
  // ── Serialise ────────────────────────────────────────────

  serialise() {
    return {
      layoutKey: this.layoutKey,
      hull: this.hull,
      // Systems serialised BY INDEX — layouts are deterministic, and a
      // ship can carry several systems of the same type (weapon modules).
      // Save the DESIRED allocation, not the momentary one: a module
      // that happened to be shot out when we jumped would otherwise
      // come back permanently switched off after repairs.
      systems: this.systems.map(s => ({
        type: s.type, level: s.level, power: Math.max(s.power, s.desiredPower ?? 0),
      })),
      weapons: this.weapons.map(w => w ? { defKey: w.defKey, slot: w.slot, roomId: w.roomId ?? null } : null),
      // `weaponCargo` is NOT written any more (update75) — a boxed gun
      // is a crate in `cargo`, like every other thing aboard.
      cargo: this.cargo ? this.cargo.serialise() : null,
      extraModules: [...(this._extraModules ?? [])],
      prisoners: this.prisoners.map(p => ({ ...p })),
      /* THE DUCTS (update84). An infestation survives a reload — it
         did when the rats were crew records, and moving them must not
         turn saving into a free fumigation. */
      pests: this.pests.filter(p => !p.dead).map(p => p.serialise()),
      reactor: this.reactor.level,
      // Heat is state, not derived (update92); a whole number is plenty.
      heat: Math.round(this.reactorHeat ?? 0),
      // her tanks (update191): what is left in them — refilled only in a port or the base
      tanks: (typeof Tanks !== 'undefined') ? Tanks.serialise(this) : null,
      /* Written since update90: the power above already keeps the lifts'
         spare units free. A save without it is from before, and gets
         them taken back once (Ship._reserveLiftPower). */
      lifts: 1,
    };
  }

  static deserialise(data, isPlayer, wx, wy) {
    const ship = new Ship(data.layoutKey, isPlayer, wx, wy);
    ship.hull  = data.hull;
    ship.reactor.level = data.reactor;
    ship.reactorHeat = Utils.clamp(data.heat ?? 0, 0, 100);   // an old save: cold

    // Re-apply purchased modules IN ORDER before restoring systems so
    // the systems array lines up index-for-index with the save.
    (data.extraModules ?? []).forEach(e => {
      if (typeof e === 'string') ship.addModule(e);
      else ship.addModuleAt(e.type, e.roomId) || ship.addModule(e.type);
    });

    data.systems.forEach((sd, i) => {
      const sys = ship.systems[i];
      // `systemType` so a hull saved with a 'brig' still lines up with
      // the carbonite bay the modules loop above just rebuilt.
      if (!sys || sys.type !== systemType(sd.type)) return;   // layout mismatch guard
      if (sd.type === 'reactor') return;  // pips derive from module level
      sys.level = sd.level; sys.power = sd.power; sys.desiredPower = sd.power;
      /* O2 IS LEVEL 2 AT LEAST (update87). Every hull was built with a
         one-pip life support, which carries three men — and a starting
         crew of four ran a deficit from the first minute. A hull saved
         before this comes out of the hangar with the floor applied; its
         power is the player's to give it. */
      if (sys.type === 'oxygen' && sys.level < Ship.O2_MIN_LEVEL) sys.level = Ship.O2_MIN_LEVEL;
    });
    // A hull saved before update90 gives its lifts their spare units back.
    if (data.lifts == null) ship._reserveLiftPower();
    /* Prisoners ride home in the hull's record. A save written before
       the brig existed simply has none. */
    ship.prisoners = (data.prisoners ?? []).map(p => ({
      id: p.id, name: p.name, bounty: p.bounty ?? 0, escapeT: 0, warned: false,
    }));
    // A save written before update84 has none here — its rats are in
    // the crew list, and game.js converts those as it loads them.
    (data.pests ?? []).forEach(pd => ship.addPest(Pest.deserialise(pd)));
    /* HER TANKS (update191). A save from before them: full — what she had
       aboard as cells is still in her hold, to be poured in at a port. */
    if (typeof Tanks !== 'undefined') { if (data.tanks) Tanks.restore(ship, data.tanks); else Tanks.ensure(ship); }

    // Saves written before the grid hold existed simply have no `cargo`
    // key — those ships keep the empty grid the constructor built.
    if (data.cargo && typeof CargoGrid !== 'undefined') {
      ship.cargo = CargoGrid.deserialise(data.cargo);
    }

    /* ── THE OLD RACK, EMPTIED INTO THE HOLD (update75) ──────
     *
     * A save written before the rack was deleted carries `weaponCargo`:
     * gun keys with no crate anywhere. Box each one now.
     *
     * AFTER the hold is restored, not before — boxing into the empty
     * grid the constructor built would put the crates somewhere that is
     * thrown away two lines later, and the guns would be gone with no
     * error anywhere to say so.
     *
     * A gun that will not fit is SAID OUT LOUD. The alternative is to
     * keep a second list alive to carry it, which is the exact thing
     * being deleted. */
    (data.weaponCargo ?? []).forEach(key => {
      if (ship.boxWeapon(key)) return;
      const label = (typeof WEAPON_DEFS !== 'undefined' && WEAPON_DEFS[key]?.label) || key;
      if (typeof UI !== 'undefined') {
        UI.notify?.(`${label} had no crate and the hold is full — it was left at the dock.`, 'warn');
      }
    });

    ship.weapons = [];
    data.weapons.forEach(wd => {
      if (wd) {
        ship.installWeapon(wd.defKey, wd.slot, { force: true });   // as she was saved (update228)
        /* A SAVE FROM BEFORE update60 carries no roomId; installWeapon
           has just stamped the positional one, which IS what that save
           meant. A newer save overrides it with the bay the gun was
           really in. */
        if (wd.roomId && ship.weapons[wd.slot]) ship.weapons[wd.slot].roomId = wd.roomId;
      }
    });

    return ship;
  }
}

/** A duct's flame, and the same starved of air (update189). */
Ship.DUCT_FIRE      = { top: 'rgba(255,90,20,0.25)', bottom: 'rgba(255,170,40,0.75)', tongue: 'rgba(255,110,20,0.9)', core: 'rgba(255,230,120,0.95)', spark: '255,220,120' };
Ship.DUCT_FIRE_BLUE = { top: 'rgba(40,90,255,0.25)', bottom: 'rgba(90,160,255,0.7)', tongue: 'rgba(70,140,255,0.9)', core: 'rgba(200,230,255,0.95)', spark: '170,210,255' };

/** The painted ducts, by trim and by width (update189 — `_drawVents`). */
Ship._ventCache = (typeof WeakMap !== 'undefined') ? new WeakMap() : null;
/** Only on a real page: a test's canvas stub records each stroke instead. */
Ship.cacheVents = () => typeof document !== 'undefined' && !!document.createElement;
/** Enemy ships fly away from you, stern first (update215); the suites before it turn it off (tests/harness.js). */
Ship.FOE_AWAY = { on: true };

/* The grid is the contract between the code and the art kit — the
   brief that the module, shaft, engine and prow tiles are cut to reads
   these numbers, so they have to be reachable from a test. */
if (typeof window !== 'undefined') {
  window.GRAVITY_CONFIG = GRAVITY_CONFIG;
  window.REACTOR_HEAT_CONFIG = REACTOR_HEAT_CONFIG;
  window.heatCelsius = heatCelsius;
  window.HULL_GRID = HULL_GRID;
  window.buildHull = buildHull;
  window.HULL_ART = HULL_ART;
  window.BUILDER_TRAITS = BUILDER_TRAITS;
  window.hullBuilder = hullBuilder;
  window.hullArtGeometry = hullArtGeometry;
  window.HULL_SHAPED = HULL_SHAPED;
  window.layoutFor = layoutFor;
  window.shapedHullGeometry = shapedHullGeometry;
  window.drawThrusterFlames = drawThrusterFlames;
  window.thrusterFlameFor = thrusterFlameFor;
  window.THRUSTER_FLAME = THRUSTER_FLAME;
  window.STRUCTURE_LAYOUTS = STRUCTURE_LAYOUTS;
  window.layoutOf = layoutOf;
}
