# MOON WARS: prompty GPT v17 (21.11.2026): kadłuby Pegasusa i Phoenixa, boss, lotniskowce, hangar w środku, wnętrza Aquariusa

jj 21.11: najpierw kadłuby i wnętrza, bez mechaniki. Kolejność:
- **A** kadłuby Pegasusa i Phoenixa, boss Apophis, po jednym lotniskowcu;
- **B** płyty zamknięte;
- **C** hangar w środku (wszystkie 4 stocznie);
- **D** wnętrza Aquariusa od nowa, tak jak u Terry.

**Zasada:** każdy obrazek w NOWEJ rozmowie z GPT. Gdy pierwszy statek serii jest dobry, dołączaj go do następnych jako ostatni załącznik (zdanie „sisters” na dole).
Wynik przyślij mi tutaj. Dociągnięcie pól do siatki, wnęki i gniazda zrobię narzędziami.

Lotniskowiec Terry **Geb** jest już narysowany (`_wspolne/4_przyklad_lotniskowca_GEB_terra.png`). Lotniskowiec Aquariusa też jest.

---

## A. KADŁUBY (otwarte)

| statek | stocznia | moduły | gniazda | nogi | uwagi |
|---|---|---|---|---|---|
| SET | Pegasus | 6 | 2 | 2 | |
| ISIS | Pegasus | 10 | 3 | 3 | twój statek do kupienia |
| HATHOR | Pegasus | 6 | 3 | 2 | |
| TEFNUT | Pegasus | 9 | 2 | 3 | **lotniskowiec**, 2 hangary (nazwa robocza) |
| SOBEK | Phoenix | 7 | 3 | 2 | |
| ANUBIS | Phoenix | 6 | 2 | 2 | |
| OSIRIS | Phoenix | 10 | 3 | 3 | twój statek do kupienia |
| SOPDET | Phoenix | 12 | 1 | 3 | **lotniskowiec**, 4 pokłady, 2 hangary (nazwa robocza) |
| APOPHIS | Phoenix | 10 | 1 | – | **boss**: stacja na ziemi, 5 pokładów |

**Na blueprintach:**
- niebieskie pola = moduły (szerokie pole = hangar 200 u, jedno okno);
- zielone = szyb windy;
- cyjanowy pasek = kopułka mostka (mostek zawsze na górze z tyłu);
- pomarańczowe = gniazda dział;
- magenta = wnęki podwozia 64×24 u.

**Załączniki w tej kolejności:**
1. `1_blueprint_<STATEK>.png`
2. `2_przyklad_<stocznia>.png` (Maat Terry przemalowany na kolory stoczni: wzór stylu i kształtu)
3. `3_ref_kolor_<stocznia>.png` (paleta na dole)
4. `4_obecny_<STATEK>.png`, a dla lotniskowców `_wspolne/4_przyklad_lotniskowca_GEB_terra.png`
5. od drugiego statku: gotowy pierwszy statek tej stoczni

### PROMPT A
W `<<KOLORY>>` wstaw akapit stoczni (niżej).

```
Draw the armoured HULL of this spaceship — side view, stern on the left, detailed pixel-art game style.
STYLE: the style of the ship in the second image — chunky industrial armour, pipes and conduits along the hull, heavy angled corner braces, raised armoured housings on the roof, round ribbed engine nozzles.
<<KOLORY>>
The first image is the exact LAYOUT GUIDE. Do NOT move, resize, merge or split anything in it:
- Every BLUE rectangle is a window cut through the hull — keep it FLAT BLUE, exactly its size and place. The GREEN strip is the lift shaft: keep it flat green, exactly its size.
- Between touching fields only a thin dark line, about 2 pixels — NO beams or posts between the windows; the armour runs only AROUND the outside of the fields.
- The hull follows the shape of the fields exactly: where a deck is shorter than the others, the hull steps in around it and the empty space stays open (flat dark background).
- The ORANGE bars: low, flat gun sockets (round turret rings, empty) on the top roof — exactly one on every orange bar, centred on it, all the same. No other gun sockets.
- The CYAN bar on the roof: the bridge canopy — a low armoured glass canopy exactly where the cyan bar is, centred on it, the same width. Nowhere else.
- STERN: one short, compact engine pod at the stern end of every deck that reaches the stern.
- BOW: one short armoured bow at the bow end of the decks.
- KEEL: a thick armoured keel under the bottom deck, the same style as the roof; the landing-gear BAYS are the MAGENTA shapes — exactly their shape, size, number and place, flat magenta, open at the bottom. No legs, no hangar doors, no hatches, no airlock.
- Roof and keel in the SAME style and rhythm of details. Bold, readable shapes — the picture is shown at about two thirds of this size.
The fourth image only shows roughly how this ship looks today — take from it only the idea of its shape and its character, not its beams, pads or layout.
Flat dark background. No people, no text, no letters, no numbers. Same canvas size as the first image.
```

**`<<KOLORY>>` PEGASUS:**
```
COLOURS: PEGASUS — pale silver-white and light steel-grey armour with pale blue-grey panels, like the second and third images; darker slate only in the gaps and pipes. Its mark: big curved ARC RIBS sweeping over the hull with round lamp nodes at their ends, like the ships in the fourth image. Only a few thin pale-cyan light strips. Use only the colours of the swatches at the bottom of the third image. No orange, no red.
```
**`<<KOLORY>>` PHOENIX:**
```
COLOURS: PHOENIX — black steel and DARK RED armour plates, like the second and third images; angular and aggressive: sharp blades and spikes on the bow and the roof edges, red-orange lights, small hazard chevrons, like the ships in the fourth image. Use only the colours of the swatches at the bottom of the third image. No blue, no cyan.
```

**Dopisek dla lotniskowców (TEFNUT, SOPDET), na końcu promptu:**
```
This ship is a CARRIER: each WIDE blue field on the bottom deck is a fighter HANGAR — one window, no post inside it; keep it flat blue. No hangar doors in the keel (the game draws the launch). The fourth image is a carrier of another shipyard, already finished — take from it the idea of a carrier's shape, not its colours.
```

**Dopisek dla APOPHIS (zamiast linijek STERN, BOW i KEEL):**
```
- This is the BOSS FORTRESS, a ground station, not a flying ship: NO engines and NO nozzles. A tall armoured tower of five decks with sloped armoured buttresses on both sides, a heavy armoured base at the bottom that sits on the ground (a low mound of dark rubble and earth around it), blades and spikes on its crown. No landing-gear bays.
```

**Dopisek od drugiego statku stoczni:**
```
The last image is the first ship of this same series, already finished — match its style, colours, armour, engines, keel and level of detail EXACTLY, so the ships look like sisters from one shipyard.
```

Gdy GPT narysuje belki między polami, dopisz: `Again, with NO beams or posts between the blue fields — only the thin 2-pixel line. Keep everything else.`

---

## B. PŁYTY ZAMKNIĘTEGO KADŁUBA (Pegasus i Phoenix; Terra i Aquarius już są)

Wykonaj w tej samej rozmowie co pierwszy gotowy kadłub stoczni. Załączniki:
1. `B_plyty/g8_plates.png`
2. `_wspolne/przyklad_plyty_terra.png` (tak wyszło u Terry)
3. gotowy kadłub tej stoczni
4. `3_ref_kolor_<stocznia>.png`

```
Draw the ARMOUR COVER PLATES of this ship (the third image): what the outside of its hull looks like over each window when the ship is seen closed. Same detailed pixel-art, same style and colours as the third and fourth images. The second image shows how the same plates came out for another shipyard — copy their layout and kind of detail, not their colours.
The first image is the exact LAYOUT GUIDE, at 4x the game's size: draw ONLY inside the grey-blue fields, edge to edge; keep the MAGENTA plain flat magenta.
- Top left and top middle: two variants of the cover of ONE compartment — an armour plate with corner brackets, bolts and one small window strip where the CYAN mark is.
- Top right, narrow: the cover of the lift shaft — a slim plate with a vertical window strip.
- Bottom, wide: the cover of the fighter HANGAR — one long plate with a long window strip.
- The darker band at the bottom of every part: the cover of the ventilation duct under the compartment — a slimmer band with small vents.
These plates sit side by side and stacked deck on deck with a thin line between them — no thick frame of their own; left edge continues into the right edge.
No people, no text, no letters, no numbers. Same canvas size as the first image.
```

---

## C. HANGAR W ŚRODKU (tylna ściana hangaru 200×50 u; podłogę i kanał bierzemy z modułów)

Wykonaj osobno dla **TERRA, AQUARIUS, PEGASUS, PHOENIX**. Załączniki:
1. `C_hangar_wnetrze/g7_hangar.png`
2. wzór wnętrza stoczni:
   - Terra: `_wspolne/ref_wnetrze_terra.png`
   - Aquarius: `_wspolne/style_room_aquarius.png`
   - Pegasus i Phoenix: `_wspolne/ref_wnetrze_terra.png` (budowa) + `2_przyklad_<stocznia>.png` (kolory)
3. `_wspolne/ref_ingame_aquarius.png` (skala ludzi)

```
Draw the BACK WALL of a fighter HANGAR inside a spaceship, side view, flat front-on wall, detailed pixel-art game style — the same style, materials and level of detail as the inside of the compartments in the second image, <<KOLORY_WNETRZE>>.
The first image is the exact LAYOUT GUIDE, at 6x the game's size. Draw ONLY in the grey-blue field; keep the MAGENTA plain flat magenta.
- A wide, tall bay: heavy structural ribs, fuel and power lines along the wall, a refuelling arm folded against the wall, tool racks, hazard stripes low on the wall, small work lights.
- The top band is the ceiling beam with a gantry rail running along it.
- The PURPLE square: a small plate with the hangar's symbol painted in the wall. The four YELLOW dots: four small air lamps in the wall, switched OFF.
- The CYAN rectangle: a dark, empty console screen in a frame (the game writes on it).
- The WHITE dashed box: where the fighter stands on its cradle — the game draws them; keep the wall behind it plain enough that a ship reads in front of it.
- The BROWN band at the bottom: the deck — draw it as the same metal grating as the floor of the second image.
No fighter, no people, no text, no letters, no numbers. Same canvas size as the first image.
```

**`<<KOLORY_WNETRZE>>`:**
- **TERRA:** `in TERRA colours: dark warm gunmetal steel, copper and bronze pipes, black rubber and cables, small amber and green lights`
- **AQUARIUS:** `in AQUARIUS colours: pale blue-grey and white steel, navy panels, thin cyan light strips, brass details, rounded edges`
- **PEGASUS:** `in PEGASUS colours: pale silver-white steel, light blue-grey panels, curved ribs with round lamp nodes, few thin pale-cyan lights`
- **PHOENIX:** `in PHOENIX colours: black steel and dark red panels, angular braces, red-orange lights, hazard chevrons`

---

## D. WNĘTRZA AQUARIUSA OD NOWA (warstwami, tak jak Terra)

Każda część w nowej rozmowie. Załączniki do każdej:
1. szablon `g*`
2. `_wspolne/ref_wnetrze_terra.png` (budowa: tak to robimy u Terry)
3. `_wspolne/style_room_aquarius.png` (materiały Aquariusa)
4. `_wspolne/ref_ingame_aquarius.png`

**Akapit kolorów** (wszędzie, gdzie jest `<<AQ>>`):
`in the AQUARIUS shipyard's colours and materials of the third image: pale blue-grey and white steel, navy panels, thin cyan light strips, brass details, rounded edges. Built the same way as the TERRA pieces in the second image (copy their layout and kind of detail, not their colours).`

### D1. Ściana modułu (`g1_wall.png`): JEDNA ściana dla każdego modułu
```
Draw the BACK WALL of one compartment of a spaceship, side view, flat front-on, detailed pixel-art game style, <<AQ>>
The first image is the exact LAYOUT GUIDE, at 12x the game's size. Draw ONLY in the coloured field; keep the MAGENTA plain flat magenta.
- A calm wall of steel panels: the top band is the ceiling beam; the PURPLE square is a small plate where the game paints the module's symbol — draw an empty plate; the four YELLOW dots are four small air lamps, switched OFF.
- The WHITE dashed boxes: where the crew stand — keep the wall plain there (no machines; the machines are a separate picture).
- The BROWN band at the bottom: the deck — the same metal grating as the floor of the third image.
The left edge must continue into the right edge with no seam: the game puts compartments side by side. No machines, no people, no text, no letters, no numbers. Same canvas size as the first image.
```

### D2. Podłoga (`g2_floor.png`)
```
Draw the DECK of a spaceship compartment and the lift's landing, side view, detailed pixel-art game style, <<AQ>>
The first image is the exact LAYOUT GUIDE, at 12x the game's size. Draw ONLY in the BROWN strips; keep the MAGENTA plain flat magenta.
- The long strip: the deck — a metal grating floor with a thick front edge; the crew walk on its top edge. Its left edge continues into its right edge.
- The short strip: the same floor, the lift's landing plate.
No people, no text, no letters, no numbers. Same canvas size as the first image.
```

### D3. Kanał wentylacyjny (`g3_duct.png`)
```
Draw the VENTILATION DUCT that runs under the deck of every compartment, side view, detailed pixel-art game style, <<AQ>>
The first image is the exact LAYOUT GUIDE, at 12x the game's size; keep the MAGENTA plain flat magenta.
- TOP: the duct's front GRILLE — a frame with UPRIGHT slots; the MAGENTA openings are where one looks into the duct: keep them magenta.
- BOTTOM: the INSIDE of the duct behind the grille — a calm dark wall with a pipe, cables and three small lamps; a little lighter than black so a rat shows against it.
Both continue left into right with no seam (the game repeats them under every compartment). No rats, no text, no letters, no numbers. Same canvas size as the first image.
```

### D4. Szyb windy i kabina (`g4_shaft.png`)
```
Draw the LIFT SHAFT of a spaceship and its CABIN, side view, detailed pixel-art game style, <<AQ>>
The first image is the exact LAYOUT GUIDE, at 10x the game's size; keep the MAGENTA plain flat magenta.
- Three columns, one deck each: LEFT = the TOP deck (with the hoist winch, GREEN, under the ceiling), MIDDLE = a middle deck (repeats deck over deck — its top continues into its bottom), RIGHT = the BOTTOM deck (with the buffers in the grey box under it). In each: the shaft's back wall with the two CYAN guide rails, the BROWN landing plate (deck grating), the dark band under it is the duct level.
- Far right: the open CAGE cabin — GREEN its roof with the hoist, BROWN its floor (deck grating), CYAN the cable going up; the WHITE dashed outline is where a crewman stands: keep it open, only thin bars and a hand rail behind him.
No people, no text, no letters, no numbers. Same canvas size as the first image.
```

### D5. Drzwi (`g5_doors.png`) i śluza (`g6_airlock.png`)
```
Draw the parts of a spaceship's <<INTERIOR DOOR | AIRLOCK HATCH to open space>>, side view, detailed pixel-art game style, <<AQ>>
The first image is the exact LAYOUT GUIDE; draw ONLY in the coloured shapes, keep the MAGENTA plain flat magenta.
- GREEN: the door's head with the frame; the YELLOW circle a status lamp, switched OFF; the dark part is the open doorway — keep it dark. BROWN: the sill (deck grating).
- The two tall coloured bars: the UPPER and the LOWER sliding leaf; the WHITE edge is where they meet when shut — a rubber seal (airlock: a yellow-and-black hazard band and a thick seal, heavier armour).
Flat side view, no perspective. No people, no text, no letters, no numbers. Same canvas size as the first image.
```

### D6. Wyposażenie modułów (`g9_equipment.png` + `wyposazenie/ref_<moduł>_terra.png`): 12 modułów
To samo urządzenie co u Terry, w stylu Aquariusa, na magencie. Załączniki:
1. `g9_equipment.png`
2. `wyposazenie/ref_<moduł>_terra.png`
3. `_wspolne/style_room_aquarius.png`

```
Draw the MACHINES of one spaceship compartment — <<MODUŁ>> — side view, flat front-on, detailed pixel-art game style, in the AQUARIUS colours and materials of the third image: pale blue-grey and white steel, navy panels, thin cyan light strips, brass details, rounded edges.
The second image shows the same machines as the TERRA shipyard drew them, at the same place and size — draw the same kind of machines in the same place, same size and same height, but as AQUARIUS would build them.
The first image is the LAYOUT GUIDE: draw ONLY inside the grey-blue box; everything else stays plain flat MAGENTA (the wall behind is a separate picture). The machines stand on the brown line (the deck).
Any screen: dark and empty, in a frame (the game writes on it). No people, no text, no letters, no numbers. Same canvas size as the first image.
```

**Moduły:**

| plik `ref_` | `<<MODUŁ>>` |
|---|---|
| piloting | the bridge: two pilots' stations and the captain's table |
| engines | the engine room: drive machinery and controls |
| weapons | the weapons room: gun loaders and control desk |
| shields | the shield generator |
| oxygen | the life support: air tanks and pumps |
| medbay | the medical bay: a healing pod and instruments |
| reactor | the reactor core with its controls |
| artillery | the artillery room: a heavy shell loader |
| autorepair | the auto-repair bay: repair arms and parts racks |
| carbonite | the carbonite freezing chamber with three pods |
| cloaking | the cloaking device |
| tractor | the tractor beam generator |

---

## Lista kontrolna (20 s)
- Niebieskie i zielone pola płaskie, w swoich miejscach? Między nimi tylko cienka linia?
- Gniazda dokładnie nad pomarańczowymi paskami, kopułka nad cyjanowym?
- Magentowe wnęki puste, nigdzie nie ma narysowanych nóg?
- Kolory stoczni, mało świateł, brak napisów?
- Szablony wnętrz: rysunek tylko w polach, wokół czysta magenta?
